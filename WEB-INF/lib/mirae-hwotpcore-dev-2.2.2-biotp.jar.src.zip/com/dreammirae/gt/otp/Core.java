package com.dreammirae.gt.otp;

import com.dreammirae.gt.otp.cipher.CipherImpl;
import com.dreammirae.gt.otp.cipher.CipherInterface;
import com.dreammirae.gt.otp.hmac.HmacImpl;
import com.dreammirae.gt.otp.hmac.HmacInterface;
import com.dreammirae.gt.otp.md.MDIterface;
import com.dreammirae.gt.otp.md.MdImpl;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class Core implements CoreInterface {
  private static Core a = null;
  
  private Policy b = new Policy();
  
  private HmacInterface c = (HmacInterface)new HmacImpl();
  
  private MDIterface d = (MDIterface)new MdImpl();
  
  private CipherInterface e = (CipherInterface)new CipherImpl();
  
  public byte[] HMAC(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
    return this.c.hmac(paramArrayOfbyte1, paramArrayOfbyte2);
  }
  
  public byte[] DIGEST(String paramString, byte[] paramArrayOfbyte) throws Exception {
    return this.d.digest(paramString, paramArrayOfbyte);
  }
  
  public byte[] ENCRYPT(String paramString1, String paramString2, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws Exception {
    return this.e.enCrypt(paramString1, paramString2, paramArrayOfbyte1, paramArrayOfbyte2, paramArrayOfbyte3);
  }
  
  public byte[] DECRYPT(String paramString1, String paramString2, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws Exception {
    return this.e.deCrypt(paramString1, paramString2, paramArrayOfbyte1, paramArrayOfbyte2, paramArrayOfbyte3);
  }
  
  public HmacInterface getHmac() {
    return this.c;
  }
  
  public void setHmac(HmacInterface paramHmacInterface) {
    this.c = paramHmacInterface;
  }
  
  public MDIterface getMd() {
    return this.d;
  }
  
  public void setMd(MDIterface paramMDIterface) {
    this.d = paramMDIterface;
  }
  
  public CipherInterface getCipher() {
    return this.e;
  }
  
  public void setCipher(CipherInterface paramCipherInterface) {
    this.e = paramCipherInterface;
  }
  
  private boolean a(String paramString) {
    try {
      Class<?> clazz = Class.forName(paramString);
      this.c = (HmacInterface)clazz.newInstance();
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } catch (ClassCastException classCastException) {
      return false;
    } catch (Exception exception) {
      return false;
    } 
    return true;
  }
  
  private boolean b(String paramString) {
    try {
      Class<?> clazz = Class.forName(paramString);
      this.d = (MDIterface)clazz.newInstance();
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } catch (ClassCastException classCastException) {
      return false;
    } catch (Exception exception) {
      return false;
    } 
    return true;
  }
  
  private boolean c(String paramString) {
    try {
      Class<?> clazz = Class.forName(paramString);
      this.e = (CipherInterface)clazz.newInstance();
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } catch (ClassCastException classCastException) {
      return false;
    } catch (Exception exception) {
      return false;
    } 
    return true;
  }
  
  public static synchronized Core getInstance() {
    if (a == null)
      a = new Core(); 
    return a;
  }
  
  public static synchronized Core getInstance(String paramString1, String paramString2, String paramString3) {
    if (a == null) {
      a = new Core();
      if (a.a(paramString1, paramString2, paramString3))
        throw new RuntimeException("instace init error"); 
    } 
    return a;
  }
  
  private boolean a(String paramString1, String paramString2, String paramString3) {
    return !(a(paramString1) && b(paramString2) && c(paramString3));
  }
  
  public static void coreClear() {
    a = null;
  }
  
  private String a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
    String str = "";
    byte[] arrayOfByte = new byte[10];
    int i = paramInt2;
    try {
      System.arraycopy(Tool.orgCode2Byte(paramInt1), 0, arrayOfByte, 0, 2);
      System.arraycopy(Tool.toBytesFromInt(i), 0, arrayOfByte, 2, 4);
      System.arraycopy(Tool.toBytesFromInt(paramInt3), 0, arrayOfByte, 6, 4);
      str = a(paramArrayOfbyte, arrayOfByte);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
    return str;
  }
  
  private String a(byte[] paramArrayOfbyte, long paramLong) {
    String str = "";
    byte[] arrayOfByte = Tool.toBytesFromLong(paramLong);
    try {
      str = a(paramArrayOfbyte, arrayOfByte);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
    return str;
  }
  
  private String a(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) {
    String str = "";
    byte[] arrayOfByte = new byte[36];
    try {
      System.arraycopy(Tool.toBytesFromInt(paramInt), 0, arrayOfByte, 0, 4);
      System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, 4, 32);
      str = a(paramArrayOfbyte1, arrayOfByte);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
    return str;
  }
  
  private String a(TransMode paramTransMode, byte paramByte, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt) {
    String str = "";
    byte[] arrayOfByte = (TransMode.OFF == paramTransMode) ? new byte[8] : new byte[40];
    try {
      arrayOfByte[0] = paramByte;
      System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 1, 3);
      System.arraycopy(Tool.toBytesFromInt(paramInt), 0, arrayOfByte, 4, 4);
      if (TransMode.ON == paramTransMode)
        System.arraycopy(paramArrayOfbyte3, 0, arrayOfByte, 8, 32); 
      str = a(paramArrayOfbyte2, arrayOfByte);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
    return str;
  }
  
  private String a(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    String str = "";
    byte b = 6;
    byte[] arrayOfByte = null;
    try {
      arrayOfByte = HMAC(paramArrayOfbyte1, paramArrayOfbyte2);
      int i = arrayOfByte[arrayOfByte.length - 1] & 0xF;
      int j = (arrayOfByte[i] & Byte.MAX_VALUE) << 24 | (arrayOfByte[i + 1] & 0xFF) << 16 | (arrayOfByte[i + 2] & 0xFF) << 8 | arrayOfByte[i + 3] & 0xFF;
      int k = j % Constant.z[b];
      for (str = Integer.toString(k); str.length() < b; str = "0" + str);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
  
  private String b(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    String str = "";
    byte b = 4;
    try {
      byte[] arrayOfByte = HMAC(paramArrayOfbyte1, paramArrayOfbyte2);
      int i = arrayOfByte[arrayOfByte.length - 1] & 0xF;
      int j = (arrayOfByte[i] & Byte.MAX_VALUE) << 8 | arrayOfByte[i + 1] & 0xFF;
      int k = j % 10000;
      for (str = Integer.toString(k); str.length() < b; str = "0" + str);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
  
  public OtpResult verifyOTP(String paramString, Token paramToken) {
    return verifyOTPVer2(TransMode.OFF, null, null, paramString, paramToken);
  }
  
  public OtpResult verifyOTPVer2(TransMode paramTransMode, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, String paramString, Token paramToken) {
    OtpResult otpResult = new OtpResult();
    int i = 0;
    int j = 0;
    byte b1 = 0;
    if (this.b == null) {
      otpResult.setReturnCode(6012);
      otpResult.setErrMsg("policy is null");
      return otpResult;
    } 
    if (paramString == null || paramString.length() != 6) {
      otpResult.setReturnCode(6010);
      otpResult.setErrMsg("otpCode is null or length error or not numberic");
      return otpResult;
    } 
    if (!Tool.isNumber(paramString)) {
      otpResult.setReturnCode(6010);
      otpResult.setErrMsg("otpCode not numberic");
      return otpResult;
    } 
    if (paramToken == null || paramToken.getSecret() == null || paramToken.getSn() == null || paramToken.getIntOrgCd() == null || paramToken.getAlg() == null) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("TokenBase is null or seed is null");
      return otpResult;
    } 
    otpResult.setSn(paramToken.getSn());
    String str = paramToken.getSn().substring(0, 3);
    if ("429".equals(str))
      paramToken.setModelCd("12"); 
    if ("6".equals(paramToken.getAlg())) {
      b1 = 2;
      i = this.b.getNormAuthTmSkew();
      paramToken.setTimeSkew(0);
    } else if (paramToken.getLastAuthTm() == 0) {
      b1 = 0;
      i = this.b.getInitAuthTmSkew();
    } else if (Tool.isAuthLong(this.b, paramToken.getLastAuthTm(), paramToken.getTimeSkew()) == true) {
      b1 = 1;
      i = this.b.getLongAuthTmSkew();
    } else {
      b1 = 2;
      i = this.b.getUserSyncTmSkew();
    } 
    otpResult.setAuthType(b1);
    if ("6".equals(paramToken.getAlg())) {
      if (paramArrayOfbyte1 == null) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("orgCode must not be null");
        return otpResult;
      } 
      if (paramArrayOfbyte1.length != 3) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("orgCode must be 3 bytes");
        return otpResult;
      } 
    } 
    if (TransMode.ON == paramTransMode) {
      if (paramArrayOfbyte2 == null) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("tranSha256 must not be null");
        return otpResult;
      } 
      if (paramArrayOfbyte2.length != 32) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("tranSha256 must be 3 bytes");
        return otpResult;
      } 
    } 
    j = Tool.getCycle(paramToken.getCycle());
    long l = Tool.getOtpTokenTime(this.b, paramToken.getTimeSkew());
    int[] arrayOfInt = Tool.getFindSkew(i, j);
    if ("T".equals(paramToken.getAlg()))
      l = Tool.getOtpTokenTimeTOTP(this.b, paramToken.getTimeSkew()); 
    for (byte b2 = 0; b2 < arrayOfInt.length; b2++) {
      long l1 = l + arrayOfInt[b2];
      String str1 = "";
      if (TransMode.OFF == paramTransMode) {
        if ("6".equals(paramToken.getAlg())) {
          str1 = a(paramTransMode, (byte)1, paramArrayOfbyte1, paramToken.getSecret(), (byte[])null, (int)(l1 / 60L));
        } else if ("1".equals(paramToken.getAlg())) {
          str1 = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), 6, j, (int)l1);
        } else if ("T".equals(paramToken.getAlg())) {
          str1 = a(paramToken.getSecret(), l1 / j);
        } else {
          str1 = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), (int)(l1 / j));
        } 
      } else if ("5".equals(paramToken.getAlg())) {
        str1 = a(paramToken.getSecret(), paramArrayOfbyte2, (int)(l1 / j));
      } else if ("6".equals(paramToken.getAlg())) {
        str1 = a(paramTransMode, (byte)1, paramArrayOfbyte1, paramToken.getSecret(), paramArrayOfbyte2, (int)(l1 / 60L));
      } 
      if (str1.equals(paramString)) {
        int k = (int)(l1 / j);
        int m = paramToken.getLastAuthTm() / j;
        if (k == m) {
          if (TransMode.ON == paramTransMode && !paramString.equals(paramToken.getLastOtp())) {
            otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
            otpResult.setLastAuthTm((int)l1);
            otpResult.setReturnCode(0);
          } else {
            otpResult.setReturnCode(6001);
          } 
        } else if (k < m) {
          otpResult.setReturnCode(6000);
        } else if (b1 == 2) {
          if (Math.abs(arrayOfInt[b2]) > this.b.getNormAuthTmSkew() * 60 && Math.abs(arrayOfInt[b2]) <= this.b.getUserSyncTmSkew() * 60) {
            if ("12".equals(paramToken.getModelCd())) {
              if (Math.abs(arrayOfInt[b2]) <= 120) {
                otpResult.setLastAuthTm((int)l1);
                otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
                otpResult.setReturnCode(0);
              } else {
                otpResult.setReturnCode(6002);
                otpResult.setLastAuthTm((int)l1);
              } 
            } else if ("6".equals(paramToken.getAlg())) {
              otpResult.setReturnCode(6000);
            } else {
              otpResult.setReturnCode(6002);
              otpResult.setLastAuthTm((int)l1);
            } 
          } else {
            if ("6".equals(paramToken.getAlg())) {
              otpResult.setSkew(0);
            } else {
              otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
            } 
            otpResult.setLastAuthTm((int)l1);
            otpResult.setReturnCode(0);
          } 
        } else {
          otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
          otpResult.setLastAuthTm((int)l1);
          otpResult.setReturnCode(0);
        } 
        return otpResult;
      } 
    } 
    otpResult.setReturnCode(6000);
    return otpResult;
  }
  
  public OtpResult syncOTPUser(String paramString, Token paramToken) {
    OtpResult otpResult = new OtpResult();
    int i = 0;
    int j = 0;
    if (this.b == null) {
      otpResult.setReturnCode(6012);
      otpResult.setErrMsg("policy is null");
      return otpResult;
    } 
    if (paramString == null || paramString.length() != 6) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("otpCode is null or length error or not numberic");
      return otpResult;
    } 
    if (!Tool.isNumber(paramString)) {
      otpResult.setReturnCode(6010);
      otpResult.setErrMsg("otpCode not numberic");
      return otpResult;
    } 
    if (paramToken == null || paramToken.getSecret() == null || paramToken.getSn() == null || paramToken.getIntOrgCd() == null) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("TokenBase is null or seed is null");
      return otpResult;
    } 
    if ("6".equals(paramToken.getAlg())) {
      otpResult.setReturnCode(6003);
      return otpResult;
    } 
    otpResult.setSn(paramToken.getSn());
    i = this.b.getUserSyncTmSkew();
    j = Tool.getCycle(paramToken.getCycle());
    int k = Tool.getOtpTokenTime(this.b, paramToken.getTimeSkew());
    int[] arrayOfInt = Tool.getFindSkew(i, j);
    if ("T".equals(paramToken.getAlg()))
      k = Tool.getOtpTokenTimeTOTP(this.b, paramToken.getTimeSkew()); 
    for (byte b = 0; b < arrayOfInt.length; b++) {
      int m = k + arrayOfInt[b];
      String str = "";
      if ("1".equals(paramToken.getAlg())) {
        str = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), 6, j, m);
      } else if ("T".equals(paramToken.getAlg())) {
        str = a(paramToken.getSecret(), (m / j));
      } else {
        str = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), m / j);
      } 
      if (str.equals(paramString)) {
        int n = m / j;
        int i1 = paramToken.getLastAuthTm() / j;
        if (n == i1) {
          otpResult.setReturnCode(6004);
        } else if (n < i1) {
          otpResult.setReturnCode(6003);
        } else {
          otpResult.setReturnCode(0);
          otpResult.setLastAuthTm(m);
          otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b]);
        } 
        return otpResult;
      } 
    } 
    otpResult.setReturnCode(6003);
    return otpResult;
  }
  
  public OtpResult syncOtpAdmin(String paramString1, String paramString2, Token paramToken) {
    OtpResult otpResult = new OtpResult();
    int i = 0;
    int j = 0;
    if (this.b == null) {
      otpResult.setReturnCode(6012);
      otpResult.setErrMsg("policy is null");
      return otpResult;
    } 
    if (paramString1 == null || paramString1.length() != 6 || paramString2 == null || paramString2.length() != 6) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("otpCode is null or length error or not numberic");
      return otpResult;
    } 
    if (!Tool.isNumber(paramString1) || !Tool.isNumber(paramString2)) {
      otpResult.setReturnCode(6010);
      otpResult.setErrMsg("otpCode not numberic");
      return otpResult;
    } 
    if (paramToken == null || paramToken.getSecret() == null || paramToken.getSn() == null || paramToken.getIntOrgCd() == null) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("TokenBase is null or seed is null");
      return otpResult;
    } 
    if ("6".equals(paramToken.getAlg())) {
      otpResult.setReturnCode(6003);
      return otpResult;
    } 
    otpResult.setSn(paramToken.getSn());
    i = this.b.getAdminSyncTmSkew();
    j = Tool.getCycle(paramToken.getCycle());
    int k = Tool.getOtpTokenTime(this.b, paramToken.getTimeSkew());
    int[] arrayOfInt = Tool.getFindSkew(i, j);
    if ("T".equals(paramToken.getAlg()))
      k = Tool.getOtpTokenTimeTOTP(this.b, paramToken.getTimeSkew()); 
    for (byte b = 0; b < arrayOfInt.length; b++) {
      int m = k + arrayOfInt[b];
      String str1 = "";
      String str2 = "";
      if ("1".equals(paramToken.getAlg())) {
        str2 = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), 6, j, m);
      } else if ("T".equals(paramToken.getAlg())) {
        str2 = a(paramToken.getSecret(), (m / j));
      } else {
        str2 = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), m / j);
      } 
      if (str2.equals(paramString2)) {
        int n = m / j;
        int i1 = paramToken.getLastAuthTm() / j;
        if (n == i1) {
          otpResult.setReturnCode(6004);
          return otpResult;
        } 
        if (n < i1) {
          otpResult.setReturnCode(6003);
          return otpResult;
        } 
        int i2 = k + arrayOfInt[b] - j;
        if ("1".equals(paramToken.getAlg())) {
          str1 = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), 6, j, i2);
        } else if ("T".equals(paramToken.getAlg())) {
          str1 = a(paramToken.getSecret(), (i2 / j));
        } else {
          str1 = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), i2 / j);
        } 
        if (str1.equals(paramString1)) {
          int i3 = i2 / j;
          if (i3 == i1) {
            otpResult.setReturnCode(6004);
          } else if (i3 < i1) {
            otpResult.setReturnCode(6003);
          } else {
            otpResult.setReturnCode(0);
            otpResult.setLastAuthTm(m);
            otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b]);
          } 
          return otpResult;
        } 
        otpResult.setReturnCode(6003);
        return otpResult;
      } 
    } 
    otpResult.setReturnCode(6003);
    return otpResult;
  }
  
  public OtpResult genOTPUnlockCode(Token paramToken) {
    OtpResult otpResult = new OtpResult();
    int i = 0;
    if (this.b == null) {
      otpResult.setReturnCode(6012);
      otpResult.setErrMsg("policy is null");
      return otpResult;
    } 
    if (paramToken == null || paramToken.getSecret() == null || paramToken.getSn() == null || paramToken.getIntOrgCd() == null) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("TokenBase is null or seed is null");
      return otpResult;
    } 
    if ("6".equals(paramToken.getAlg()))
      paramToken.setTimeSkew(0); 
    i = Tool.getCycle(paramToken.getCycle());
    int j = Tool.getOtpTokenTime(this.b, paramToken.getTimeSkew());
    String str = "";
    if ("6".equals(paramToken.getAlg())) {
      str = a(TransMode.OFF, (byte)2, Constant.J, paramToken.getSecret(), (byte[])null, j / i);
    } else if ("1".equals(paramToken.getAlg())) {
      str = a(0, Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), 6, i, j);
    } else {
      str = a(0, Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), j / i);
    } 
    otpResult.setReturnCode(0);
    otpResult.setUnlockCode(str);
    return otpResult;
  }
  
  public OtpResult setPolicy(Policy paramPolicy) {
    OtpResult otpResult = new OtpResult();
    if (paramPolicy == null) {
      otpResult.setErrMsg("policy is null or chgDate is null");
      otpResult.setReturnCode(6011);
      return otpResult;
    } 
    if (!paramPolicy.isValidate()) {
      otpResult.setErrMsg("invalid policy");
      otpResult.setReturnCode(6011);
      return otpResult;
    } 
    this.b = paramPolicy;
    otpResult.setReturnCode(0);
    return otpResult;
  }
  
  public Policy getPolicy() {
    return this.b;
  }
  
  public OtpResult mngOTPAuthPolicy(Policy paramPolicy) {
    OtpResult otpResult = new OtpResult();
    otpResult.setReturnCode(0);
    return otpResult;
  }
  
  public String getSeedEncKeyData(String paramString) {
    return (paramString == null) ? null : ("citibank".equals(paramString.toLowerCase()) ? "EA5EEFBD8537C0A5E6C7CC11538167E1E959D86CB1D25B7987AE2A46B1BAAD13" : ("kbstar".equals(paramString.toLowerCase()) ? "818F2FA17D1531AEE7870C4014F6A4348AA1ED1FB2E413F2E8D6194C415FDD90" : ("hanabank".equals(paramString.toLowerCase()) ? "76767C048D4AA6BB742F0E01867CBFC813CF4B0AB30A4E02C5EB228AE4EFE872" : ("ibk".equals(paramString.toLowerCase()) ? "EB6DAE80D024075EE6CD665393B8E34F79EDF843649DBD2CD80EDA62489DEBEC" : ("kftc".equals(paramString.toLowerCase()) ? "89267888AFB82A6DCC38D00B8F793FEE374B127BB1F9CC74F433EC55C37F615D" : ("kbank".equals(paramString.toLowerCase()) ? "49C55BCCB9232801843D0183063E5155C34143216A1F64536F367E4181ABCC9F" : ("woori".equals(paramString.toLowerCase()) ? "D68771690ECAFE4CE2688C5514E61D489BB73E4E055FA7E6AFAE95138CA889C4" : ("biotp".equals(paramString.toLowerCase()) ? "9F276FD2E36C4911129C5A675597A2D61BD2A4758489DF198E052D5ADD3242D6" : "043A5F8A118493CB74CB2956DCA683B361123E4D9E6E7D050DCE7072C565DC19"))))))));
  }
  
  public byte[] getSeedEncKey(String paramString1, String paramString2) {
    byte[] arrayOfByte = null;
    try {
      arrayOfByte = Tool.AES(paramString2, Tool.hexToByteArray(getSeedEncKeyData(paramString1)), 2);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return arrayOfByte;
  }
  
  public byte[] getSeedEncKey() {
    byte[] arrayOfByte = null;
    try {
      arrayOfByte = Tool.AES("DA61F5F1F0168E5898E1C9020E82B9BC", Tool.hexToByteArray(getSeedEncKeyData("woori")), 2);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return arrayOfByte;
  }
  
  public OtpResult genOPIN(TransMode paramTransMode, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, Token paramToken) {
    OtpResult otpResult = new OtpResult();
    byte[] arrayOfByte1 = null;
    byte[] arrayOfByte2 = null;
    int i = 60;
    try {
      if (paramTransMode == null) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("orgCode must not be null");
        return otpResult;
      } 
      if (paramArrayOfbyte1 == null) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("orgCode must not be null");
        return otpResult;
      } 
      if (paramArrayOfbyte1.length != 3) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("orgCode must be 3 bytes");
        return otpResult;
      } 
      if (paramToken == null) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("token must not be null");
        return otpResult;
      } 
      if (paramToken.getSecret() == null) {
        otpResult.setReturnCode(6007);
        otpResult.setErrMsg("token secret must not be null");
        return otpResult;
      } 
      if (paramTransMode == TransMode.ON) {
        if (paramArrayOfbyte2 == null) {
          otpResult.setReturnCode(6007);
          otpResult.setErrMsg("tranSha256 must not be null");
          return otpResult;
        } 
        if (paramArrayOfbyte2.length != 32) {
          otpResult.setReturnCode(6007);
          otpResult.setErrMsg("tranSha256 must be 32 bytes");
          return otpResult;
        } 
      } 
      i = Tool.getCycle(paramToken.getCycle());
      arrayOfByte2 = Tool.toBytesFromInt(Tool.getOtpTokenTime(this.b, 0) / i);
      arrayOfByte1 = (paramTransMode == TransMode.OFF) ? new byte[8] : new byte[40];
      arrayOfByte1[0] = 3;
      System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte1, 1, 3);
      System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 4, 4);
      if (paramTransMode == TransMode.ON)
        System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte1, 8, 32); 
      otpResult.setOpin(b(paramToken.getSecret(), arrayOfByte1));
      otpResult.setReturnCode(0);
    } catch (Throwable throwable) {
      otpResult.setErrMsg(throwable.toString());
    } 
    return otpResult;
  }
  
  private List<String> a(Date paramDate1, Date paramDate2, Token paramToken) {
    ArrayList<String> arrayList = new ArrayList();
    Date date1 = null;
    Date date2 = null;
    String str1 = "2015-04-01 00:00:00";
    String str2 = "2015-06-09 00:00:00";
    try {
      date2 = Tool.str2Date(str1, "yyyy-MM-dd HH:mm:ss", Tool.DFT_TIME_ZONE);
      date1 = Tool.str2Date(str2, "yyyy-MM-dd HH:mm:ss", Tool.DFT_TIME_ZONE);
      if (paramDate1 == null || paramDate2 == null)
        throw new IllegalArgumentException("start_date or end_date must be not null"); 
      if (paramDate2.compareTo(paramDate1) <= 0)
        throw new IllegalArgumentException("end_date must be after start_date"); 
      if (paramDate1.compareTo(date2) < 0)
        throw new IllegalArgumentException("start_date must be after 2015-06-06 00:00:00"); 
      if (paramDate2.compareTo(date1) > 0)
        throw new IllegalArgumentException("end_date must be before 2015-06-06 00:00:00"); 
      if (paramToken.getSeed() == null || "".equals(paramToken.getSeed().trim()))
        throw new IllegalArgumentException("seed"); 
      int i = Tool.stringToInt(paramToken.getIntOrgCd(), 0);
      int j = Tool.stringToInt(paramToken.getSn(), 0);
      int k = Tool.getCycle(paramToken.getCycle());
      long l1 = paramDate1.getTime() / 1000L;
      long l2 = paramDate2.getTime() / 1000L;
      byte[] arrayOfByte = getSeedEncKey("kftc", "c0d4dda8a8966d3372c23e0086c63a72");
      paramToken.setSecret(DECRYPT(null, null, arrayOfByte, null, Tool.hexToByteArray(paramToken.getSeed())));
      int m = 0;
      Date date = null;
      while (l1 < l2) {
        date = new Date(l1 * 1000L);
        m = (int)(l1 - 946652400L);
        String str = a(i, j, paramToken.getSecret(), m / k);
        System.out.println(String.format("%s,%s", new Object[] { Tool.date2Str(date), str }));
        l1 += k;
      } 
    } catch (ParseException parseException) {
      throw new IllegalArgumentException(parseException);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw illegalArgumentException;
    } catch (Throwable throwable) {}
    return arrayList;
  }
  
  public OtpResult exPostReconcile(Date paramDate, String paramString, Token paramToken, Policy paramPolicy) {
    OtpResult otpResult = new OtpResult();
    int i = 0;
    int j = 0;
    byte b1 = 0;
    TransMode transMode = TransMode.OFF;
    if (paramPolicy == null) {
      otpResult.setReturnCode(6012);
      otpResult.setErrMsg("policy is null");
      return otpResult;
    } 
    if (paramString == null || paramString.length() != 6) {
      otpResult.setReturnCode(6010);
      otpResult.setErrMsg("otpCode is null or length error or not numberic");
      return otpResult;
    } 
    if (!Tool.isNumber(paramString)) {
      otpResult.setReturnCode(6010);
      otpResult.setErrMsg("otpCode not numberic");
      return otpResult;
    } 
    if (paramToken == null || paramToken.getSecret() == null || paramToken.getSn() == null || paramToken.getIntOrgCd() == null) {
      otpResult.setReturnCode(6007);
      otpResult.setErrMsg("TokenBase is null or seed is null");
      return otpResult;
    } 
    if (paramDate.compareTo(new Date()) > 0) {
      otpResult.setReturnCode(6007);
      return otpResult;
    } 
    otpResult.setSn(paramToken.getSn());
    if ("6".equals(paramToken.getAlg())) {
      b1 = 2;
      i = paramPolicy.getNormAuthTmSkew();
    } else if (paramToken.getLastAuthTm() == 0) {
      b1 = 0;
      i = paramPolicy.getInitAuthTmSkew();
    } else if (Tool.isAuthLong(this.b, paramToken.getLastAuthTm(), paramToken.getTimeSkew()) == true) {
      b1 = 1;
      i = paramPolicy.getLongAuthTmSkew();
    } else {
      b1 = 2;
      i = paramPolicy.getUserSyncTmSkew();
    } 
    otpResult.setAuthType(b1);
    if (!"2".equals(paramToken.getAlg()) && !"1".equals(paramToken.getAlg())) {
      otpResult.setReturnCode(6000);
      return otpResult;
    } 
    j = Tool.getCycle(paramToken.getCycle());
    int k = (int)(paramDate.getTime() / 1000L);
    int m = k - 946652400 + this.b.getServerTmSkew() * 60 + paramToken.getTimeSkew();
    int[] arrayOfInt = Tool.getFindSkew(i, j);
    for (byte b2 = 0; b2 < arrayOfInt.length; b2++) {
      int n = m + arrayOfInt[b2];
      String str = "";
      if (TransMode.OFF == transMode)
        if ("1".equals(paramToken.getAlg())) {
          str = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), 6, j, n);
        } else {
          str = a(Tool.stringToInt(paramToken.getIntOrgCd(), 0), Tool.stringToInt(paramToken.getSn(), 0), paramToken.getSecret(), n / j);
        }  
      if (str.equals(paramString)) {
        int i1 = n / j;
        int i2 = paramToken.getLastAuthTm() / j;
        if (i1 == i2) {
          if (TransMode.ON == transMode && !paramString.equals(paramToken.getLastOtp())) {
            otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
            otpResult.setLastAuthTm(n);
            otpResult.setReturnCode(0);
          } else {
            otpResult.setReturnCode(6001);
          } 
        } else if (i1 < i2) {
          otpResult.setReturnCode(6000);
        } else if (b1 == 2) {
          if (Math.abs(arrayOfInt[b2]) > paramPolicy.getNormAuthTmSkew() * 60 && Math.abs(arrayOfInt[b2]) <= paramPolicy.getUserSyncTmSkew() * 60) {
            if ("6".equals(paramToken.getAlg())) {
              otpResult.setReturnCode(6000);
            } else {
              otpResult.setReturnCode(6002);
              otpResult.setLastAuthTm(n);
            } 
          } else {
            otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
            otpResult.setLastAuthTm(n);
            otpResult.setReturnCode(0);
          } 
        } else {
          otpResult.setSkew(paramToken.getTimeSkew() + arrayOfInt[b2]);
          otpResult.setLastAuthTm(n);
          otpResult.setReturnCode(0);
        } 
        return otpResult;
      } 
    } 
    otpResult.setReturnCode(6000);
    return otpResult;
  }
  
  private String a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5) {
    String str = "";
    int[] arrayOfInt = { 0, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };
    byte[] arrayOfByte1 = new byte[30];
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt5 / paramInt4;
    byte[] arrayOfByte2 = { (byte)(i >> 8 & 0xFF), (byte)(i & 0xFF) };
    byte[] arrayOfByte3 = Tool.toBytesFromInt(j);
    byte[] arrayOfByte4 = Tool.toBytesFromInt(k);
    try {
      System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, 2);
      System.arraycopy(arrayOfByte3, 0, arrayOfByte1, 2, 4);
      System.arraycopy(arrayOfByte4, 0, arrayOfByte1, 6, 4);
      System.arraycopy(paramArrayOfbyte, 0, arrayOfByte1, 10, 20);
      byte[] arrayOfByte5 = DIGEST("md2", arrayOfByte1);
      byte[] arrayOfByte6 = { 0, 0, 0, 0, 0, 0, 0, 0 };
      System.arraycopy(arrayOfByte5, 12, arrayOfByte6, 4, 4);
      long l = Tool.byteArrayToLong(arrayOfByte6);
      l %= arrayOfInt[paramInt3];
      for (str = Long.toString(l); str.length() < paramInt3; str = "0" + str);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Info:").append("Mirae technology TimeOtp Core Library(java), ver:2.0.1").append(",hmacImpl=").append(this.c.getInfo()).append(",mdImpl=").append(this.d.getInfo()).append(",cipherImpl=").append(this.e.getInfo());
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\Core.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */