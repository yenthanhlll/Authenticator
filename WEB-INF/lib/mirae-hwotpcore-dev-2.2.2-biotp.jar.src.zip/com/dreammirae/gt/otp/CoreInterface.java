package com.dreammirae.gt.otp;

import java.util.Date;

public interface CoreInterface {
  OtpResult verifyOTPVer2(TransMode paramTransMode, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, String paramString, Token paramToken);
  
  OtpResult verifyOTP(String paramString, Token paramToken);
  
  OtpResult genOTPUnlockCode(Token paramToken);
  
  OtpResult syncOtpAdmin(String paramString1, String paramString2, Token paramToken);
  
  OtpResult syncOTPUser(String paramString, Token paramToken);
  
  OtpResult genOPIN(TransMode paramTransMode, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, Token paramToken);
  
  OtpResult exPostReconcile(Date paramDate, String paramString, Token paramToken, Policy paramPolicy);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\CoreInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */