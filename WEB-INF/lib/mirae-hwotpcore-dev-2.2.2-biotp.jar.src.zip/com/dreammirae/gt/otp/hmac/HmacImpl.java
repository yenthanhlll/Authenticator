package com.dreammirae.gt.otp.hmac;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class HmacImpl implements HmacInterface {
  private String a = "HmacSHA1";
  
  public byte[] hmac(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
    Mac mac = Mac.getInstance(this.a);
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "RAW");
    mac.init(secretKeySpec);
    return mac.doFinal(paramArrayOfbyte2);
  }
  
  public String getAlgorithm() {
    return this.a;
  }
  
  public String getInfo() {
    return getClass().getName() + "-Use JCE(JavaTM Cryptography Extension)";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\hmac\HmacImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */