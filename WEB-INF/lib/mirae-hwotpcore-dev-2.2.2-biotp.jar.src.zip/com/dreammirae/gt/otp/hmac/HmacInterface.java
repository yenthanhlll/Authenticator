package com.dreammirae.gt.otp.hmac;

public interface HmacInterface {
  byte[] hmac(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception;
  
  String getAlgorithm();
  
  String getInfo();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\hmac\HmacInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */