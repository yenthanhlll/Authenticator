package com.dreammirae.gt.otp;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Date;

public class Policy {
  public static final int MIN_NORM_AUTH_TM_SKEW = 0;
  
  public static final int MIN_USER_SYNC_TM_SKEW = 3;
  
  public static final int MIN_ADMIN_SYNC_TM_SKEW = 5;
  
  public static final int MIN_INIT_AUTH_TM_SKEW = 1;
  
  public static final int MIN_LONG_AUTH_TM_SKEW = 3;
  
  public static final int MIN_LONG_TERM = 30;
  
  public static final int DFT_NORM_AUTH_TM_SKEW = 1;
  
  public static final int DFT_USER_SYNC_TM_SKEW = 5;
  
  public static final int DFT_ADMIN_SYNC_TM_SKEW = 120;
  
  public static final int DFT_INIT_AUTH_TM_SKEW = 30;
  
  public static final int DFT_LONG_AUTH_TM_SKEW = 10;
  
  public static final int DFT_LONG_TERM = 60;
  
  public static final int DFT_SERVER_TM_SKEW = 0;
  
  public static final int MAX_NORM_AUTH_TM_SKEW = 10;
  
  public static final int MAX_USER_SYNC_TM_SKEW = 50;
  
  public static final int MAX_ADMIN_SYNC_TM_SKEW = 360;
  
  public static final int MAX_INIT_AUTH_TM_SKEW = 50;
  
  public static final int MAX_LONG_AUTH_TM_SKEW = 50;
  
  public static final int MAX_LONG_TERM = 365;
  
  private int a = 1;
  
  private int b = 5;
  
  private int c = 120;
  
  private int d = 30;
  
  private int e = 10;
  
  private int f = 60;
  
  private int g = 0;
  
  private Date h = null;
  
  public boolean isValidate() {
    return (this.a >= this.b) ? false : (!(this.b >= this.c));
  }
  
  public int getAdminSyncTmSkew() {
    return this.c;
  }
  
  public void setAdminSyncTmSkew(int paramInt) {
    if (paramInt < 5 || paramInt > 360)
      throw new IllegalArgumentException("adminSyncTmSkew:" + paramInt + " " + '\005' + "<= adminSyncTmSkew <=" + 'Ũ'); 
    this.c = paramInt;
  }
  
  public Date getChgDate() {
    return this.h;
  }
  
  public void setChgDate(Date paramDate) {
    if (paramDate == null)
      return; 
    if (this.h != null && this.h.compareTo(paramDate) > 0)
      return; 
    this.h = paramDate;
  }
  
  public int getInitAuthTmSkew() {
    return this.d;
  }
  
  public void setInitAuthTmSkew(int paramInt) {
    if (paramInt < 1 || paramInt > 50)
      throw new IllegalArgumentException("initAuthTmSkew:" + paramInt + " " + '\001' + "<= initAuthTmSkew <=" + '2'); 
    this.d = paramInt;
  }
  
  public int getLongAuthTmSkew() {
    return this.e;
  }
  
  public void setLongAuthTmSkew(int paramInt) {
    if (paramInt < 3 || paramInt > 50)
      throw new IllegalArgumentException("longAuthTmSkew:" + paramInt + " " + '\003' + "<= longAuthTmSkew <=" + '2'); 
    this.e = paramInt;
  }
  
  public int getLongTerm() {
    return this.f;
  }
  
  public void setLongTerm(int paramInt) {
    if (paramInt < 30 || paramInt > 365)
      throw new IllegalArgumentException("longTerm:" + paramInt + " " + '\036' + "<= adminSyncTmSkew <=" + 'ŭ'); 
    this.f = paramInt;
  }
  
  public int getNormAuthTmSkew() {
    return this.a;
  }
  
  public void setNormAuthTmSkew(int paramInt) {
    if (paramInt < 0 || paramInt > 10)
      throw new IllegalArgumentException("normAutmTmSkew:" + paramInt + " " + Character.MIN_VALUE + "<= normAutmTmSkew <=" + '\n'); 
    this.a = paramInt;
  }
  
  public int getServerTmSkew() {
    return this.g;
  }
  
  public void setServerTmSkew(int paramInt) {
    this.g = paramInt;
  }
  
  public int getUserSyncTmSkew() {
    return this.b;
  }
  
  public void setUserSyncTmSkew(int paramInt) {
    if (paramInt < 3 || paramInt > 50)
      throw new IllegalArgumentException("userSyncTmSkew:" + paramInt + " " + '\003' + "<= userSyncTmSkew <=" + '2'); 
    this.b = paramInt;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("normAuthTmSkew=").append(this.a).append(",").append("userSyncTmSkew=").append(this.b).append(",").append("adminSyncTmSkew=").append(this.c).append(",").append("initAuthTmSkew=").append(this.d).append(",").append("longAuthTmSkew=").append(this.e).append(",").append("longTerm=").append(this.f).append(",").append("serverTmSkew=").append(this.g).append(",").append("chgDate=").append(this.h);
    return stringBuffer.toString();
  }
  
  public Policy toObject(String paramString) {
    Policy policy = new Policy();
    if (paramString == null)
      return policy; 
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      policy = (Policy)objectMapper.readValue(paramString, Policy.class);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    return policy;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\Policy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */