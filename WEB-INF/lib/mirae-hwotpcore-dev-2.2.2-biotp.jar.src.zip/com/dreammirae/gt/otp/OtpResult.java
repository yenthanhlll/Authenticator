package com.dreammirae.gt.otp;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class OtpResult {
  private int a = 0;
  
  private int b = 0;
  
  private int c = 0;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  private int g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private static SimpleDateFormat k = new SimpleDateFormat("yyyyMMdd");
  
  private static SimpleDateFormat l = new SimpleDateFormat("HHmmss");
  
  public OtpResult() {
    this.a = 6005;
  }
  
  public int getAuthType() {
    return this.g;
  }
  
  public void setAuthType(int paramInt) {
    this.g = paramInt;
  }
  
  public String getErrMsg() {
    return this.f;
  }
  
  public void setErrMsg(String paramString) {
    if (paramString == null)
      return; 
    this.f = paramString;
  }
  
  public int getLastAuthTm() {
    return this.c;
  }
  
  public void setLastAuthTm(int paramInt) {
    if (paramInt < 0)
      return; 
    this.c = paramInt;
    long l = (paramInt + 946652400) * 1000L;
    Date date = new Date(l);
    setFsaLastAuthDt(k.format(date));
    setFsaLastAuthTm(l.format(date));
  }
  
  public int getSkew() {
    return this.b;
  }
  
  public void setSkew(int paramInt) {
    this.b = paramInt;
  }
  
  public int getReturnCode() {
    return this.a;
  }
  
  public void setReturnCode(int paramInt) {
    this.a = paramInt;
  }
  
  public String getUnlockCode() {
    return this.d;
  }
  
  public void setUnlockCode(String paramString) {
    if (paramString == null)
      return; 
    this.d = paramString;
  }
  
  public String getSn() {
    return this.e;
  }
  
  public void setSn(String paramString) {
    if (paramString == null)
      return; 
    this.e = paramString;
  }
  
  public String getFsaLastAuthDt() {
    return this.h;
  }
  
  public String getFsaLastAuthTm() {
    return this.i;
  }
  
  public void setFsaLastAuthDt(String paramString) {
    this.h = paramString;
  }
  
  public void setFsaLastAuthTm(String paramString) {
    this.i = paramString;
  }
  
  public String getOpin() {
    return this.j;
  }
  
  public void setOpin(String paramString) {
    this.j = paramString;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("returnCode:").append(this.a).append(",").append("authType:").append(this.g).append(",").append("sn:").append(this.e).append(",").append("skew:").append(this.b).append(",").append("lastAuthTm:").append(this.c).append(",").append("unlockCode:").append(this.d).append(",").append("opin:").append(this.j).append(",").append("errMsg:").append(this.f).append("");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\OtpResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */