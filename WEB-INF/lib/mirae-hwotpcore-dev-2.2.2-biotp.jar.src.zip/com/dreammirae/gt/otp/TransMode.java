package com.dreammirae.gt.otp;

public enum TransMode {
  ON, OFF;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\TransMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */