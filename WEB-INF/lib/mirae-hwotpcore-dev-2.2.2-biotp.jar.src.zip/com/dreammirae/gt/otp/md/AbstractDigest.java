package com.dreammirae.gt.otp.md;

abstract class AbstractDigest implements Digest {
  private final String a;
  
  private final int b;
  
  AbstractDigest(String paramString, int paramInt) {
    this.a = paramString;
    this.b = paramInt;
  }
  
  public int length() {
    return this.b;
  }
  
  public Digest update(byte... paramVarArgs) {
    return update(paramVarArgs, 0, paramVarArgs.length);
  }
  
  public String toString() {
    return this.a;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\md\AbstractDigest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */