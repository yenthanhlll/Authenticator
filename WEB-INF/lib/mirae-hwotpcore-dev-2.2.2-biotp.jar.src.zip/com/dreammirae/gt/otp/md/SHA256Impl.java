package com.dreammirae.gt.otp.md;

import java.security.NoSuchAlgorithmException;

public class SHA256Impl implements MDIterface {
  private static SHA2 a = null;
  
  public byte[] digest(String paramString, byte[] paramArrayOfbyte) throws Exception {
    return (a != null) ? a.digest(paramArrayOfbyte) : null;
  }
  
  public String getInfo() {
    return getClass().getName() + " sha256";
  }
  
  static {
    try {
      a = new SHA2("SHA-256");
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      noSuchAlgorithmException.printStackTrace();
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\md\SHA256Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */