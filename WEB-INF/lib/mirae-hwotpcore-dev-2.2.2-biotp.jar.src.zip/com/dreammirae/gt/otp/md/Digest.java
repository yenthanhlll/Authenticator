package com.dreammirae.gt.otp.md;

public interface Digest {
  int length();
  
  Digest reset();
  
  Digest update(byte paramByte);
  
  Digest update(byte... paramVarArgs);
  
  Digest update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  byte[] digest();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\md\Digest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */