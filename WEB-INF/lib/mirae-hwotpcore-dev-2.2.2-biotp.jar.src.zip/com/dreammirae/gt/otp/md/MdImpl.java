package com.dreammirae.gt.otp.md;

import java.security.MessageDigest;

public final class MdImpl implements MDIterface {
  public byte[] digest(String paramString, byte[] paramArrayOfbyte) throws Exception {
    byte[] arrayOfByte = null;
    if ("md2".equalsIgnoreCase(paramString)) {
      MD5 mD5 = new MD5();
      mD5.update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      arrayOfByte = mD5.digest();
    } else {
      MessageDigest messageDigest = MessageDigest.getInstance(paramString);
      messageDigest.update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      arrayOfByte = messageDigest.digest();
    } 
    return arrayOfByte;
  }
  
  public String getInfo() {
    return getClass().getName() + "-Use java.security.MessageDigest";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\md\MdImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */