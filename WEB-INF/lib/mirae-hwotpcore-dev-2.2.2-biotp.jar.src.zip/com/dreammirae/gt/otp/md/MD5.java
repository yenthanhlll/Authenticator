package com.dreammirae.gt.otp.md;

public class MD5 extends AbstractDigest {
  private static final int a = 16;
  
  private static final int b = 16;
  
  private static final byte[] c = new byte[] { 
      41, 46, 67, -55, -94, -40, 124, 1, 61, 54, 
      84, -95, -20, -16, 6, 19, 98, -89, 5, -13, 
      -64, -57, 115, -116, -104, -109, 43, -39, -68, 76, 
      -126, -54, 30, -101, 87, 60, -3, -44, -32, 22, 
      103, 66, 111, 24, -118, 23, -27, 18, -66, 78, 
      -60, -42, -38, -98, -34, 73, -96, -5, -11, -114, 
      -69, 47, -18, 122, -87, 104, 121, -111, 21, -78, 
      7, 63, -108, -62, 16, -119, 11, 34, 95, 33, 
      Byte.MIN_VALUE, Byte.MAX_VALUE, 93, -102, 90, -112, 50, 39, 53, 62, 
      -52, -25, -65, -9, -105, 3, -1, 25, 48, -77, 
      72, -91, -75, -47, -41, 94, -110, 42, -84, 86, 
      -86, -58, 79, -72, 56, -46, -106, -92, 125, -74, 
      118, -4, 107, -30, -100, 116, 4, -15, 69, -99, 
      112, 89, 100, 113, -121, 32, -122, 91, -49, 101, 
      -26, 45, -88, 2, 27, 96, 37, -83, -82, -80, 
      -71, -10, 28, 70, 97, 105, 52, 64, 126, 15, 
      85, 71, -93, 35, -35, 81, -81, 58, -61, 92, 
      -7, -50, -70, -59, -22, 38, 44, 83, 13, 110, 
      -123, 40, -124, 9, -45, -33, -51, -12, 65, -127, 
      77, 82, 106, -36, 55, -56, 108, -63, -85, -6, 
      36, -31, 123, 8, 12, -67, -79, 74, 120, -120, 
      -107, -117, -29, 99, -24, 109, -23, -53, -43, -2, 
      59, 0, 29, 57, -14, -17, -73, 14, 102, 88, 
      -48, -28, -90, 119, 114, -8, -21, 117, 75, 10, 
      49, 68, 80, -76, -113, -19, 31, 26, -37, -103, 
      -115, 51, -97, 17, -125, 20 };
  
  private final byte[] d = new byte[16];
  
  private byte[] e;
  
  private byte[] f;
  
  private int g;
  
  public MD5() {
    super("MD2", 16);
    reset();
  }
  
  public Digest reset() {
    this.g = 0;
    this.e = new byte[16];
    this.f = new byte[48];
    return this;
  }
  
  public Digest update(byte paramByte) {
    this.d[this.g] = paramByte;
    if (++this.g == 16)
      c(); 
    return this;
  }
  
  public Digest update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    while (paramInt2 > 0) {
      int i = Math.min(16 - this.g, paramInt2);
      System.arraycopy(paramArrayOfbyte, paramInt1, this.d, this.g, i);
      this.g += i;
      paramInt1 += i;
      paramInt2 -= i;
      if (this.g == 16)
        c(); 
    } 
    return this;
  }
  
  public byte[] digest() {
    a();
    c();
    d();
    byte[] arrayOfByte = new byte[16];
    System.arraycopy(this.f, 0, arrayOfByte, 0, 16);
    reset();
    return arrayOfByte;
  }
  
  private void a() {
    int i = 16 - this.g;
    for (int j = this.g; j < 16; j++)
      this.d[j] = (byte)i; 
  }
  
  private void b() {
    byte b = this.e[15];
    for (byte b1 = 0; b1 < 16; b1++) {
      b = (byte)(this.e[b1] ^ c[(this.d[b1] ^ b) & 0xFF]);
      this.e[b1] = b;
    } 
  }
  
  private void c() {
    b();
    a(this.d);
    this.g = 0;
  }
  
  private void d() {
    a(this.e);
  }
  
  private void a(byte[] paramArrayOfbyte) {
    byte b;
    for (b = 0; b < 16; b++) {
      byte b2 = paramArrayOfbyte[b];
      this.f[16 + b] = b2;
      this.f[32 + b] = (byte)(this.f[b] ^ b2);
    } 
    b = 0;
    for (byte b1 = 0; b1 < 18; b1++) {
      for (byte b2 = 0; b2 < 48; b2++) {
        b = (byte)(this.f[b2] ^ c[b & 0xFF]);
        this.f[b2] = b;
      } 
      b = (byte)(b + b1);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\md\MD5.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */