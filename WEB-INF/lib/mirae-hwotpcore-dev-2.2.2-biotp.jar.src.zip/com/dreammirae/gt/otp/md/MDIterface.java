package com.dreammirae.gt.otp.md;

public interface MDIterface {
  byte[] digest(String paramString, byte[] paramArrayOfbyte) throws Exception;
  
  String getInfo();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\md\MDIterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */