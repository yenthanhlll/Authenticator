package com.dreammirae.gt.otp;

public class Token {
  private String a;
  
  private String b;
  
  private byte[] c;
  
  private int d;
  
  private int e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private String k;
  
  private String l;
  
  public String getSeed() {
    return this.k;
  }
  
  public void setSeed(String paramString) {
    this.k = paramString;
  }
  
  public String getExpireDt() {
    return this.j;
  }
  
  public void setExpireDt(String paramString) {
    this.j = paramString;
  }
  
  public String getModelCd() {
    return this.h;
  }
  
  public void setModelCd(String paramString) {
    this.h = paramString;
  }
  
  public String getProdDt() {
    return this.i;
  }
  
  public void setProdDt(String paramString) {
    this.i = paramString;
  }
  
  public String getAlg() {
    return this.f;
  }
  
  public void setAlg(String paramString) {
    this.f = paramString;
  }
  
  public String getCycle() {
    return this.g;
  }
  
  public void setCycle(String paramString) {
    this.g = paramString;
  }
  
  public int getLastAuthTm() {
    return this.d;
  }
  
  public void setLastAuthTm(int paramInt) {
    this.d = paramInt;
  }
  
  public int getTimeSkew() {
    return this.e;
  }
  
  public void setTimeSkew(int paramInt) {
    this.e = paramInt;
  }
  
  public String getIntOrgCd() {
    return this.a;
  }
  
  public void setIntOrgCd(String paramString) {
    this.a = paramString;
  }
  
  public byte[] getSecret() {
    return this.c;
  }
  
  public void setSecret(byte[] paramArrayOfbyte) {
    this.c = paramArrayOfbyte;
  }
  
  public String getSn() {
    return this.b;
  }
  
  public void setSn(String paramString) {
    this.b = paramString;
  }
  
  public String getLastOtp() {
    return this.l;
  }
  
  public void setLastOtp(String paramString) {
    this.l = paramString;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\Token.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */