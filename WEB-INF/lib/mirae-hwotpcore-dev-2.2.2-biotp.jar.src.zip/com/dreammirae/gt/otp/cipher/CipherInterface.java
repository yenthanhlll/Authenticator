package com.dreammirae.gt.otp.cipher;

public interface CipherInterface {
  byte[] enCrypt(String paramString1, String paramString2, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws Exception;
  
  byte[] deCrypt(String paramString1, String paramString2, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws Exception;
  
  String getInfo();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\cipher\CipherInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */