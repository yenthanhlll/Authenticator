package com.dreammirae.gt.otp.cipher;

import com.dreammirae.gt.otp.seed.SeedxEngine;

public final class CipherImpl implements CipherInterface {
  public byte[] enCrypt(String paramString1, String paramString2, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws Exception {
    byte[] arrayOfByte = new byte[32];
    SeedxEngine.cipherTokenKey(paramArrayOfbyte1, arrayOfByte, paramArrayOfbyte3);
    return arrayOfByte;
  }
  
  public byte[] deCrypt(String paramString1, String paramString2, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws Exception {
    byte[] arrayOfByte = new byte[20];
    SeedxEngine.decipherTokenKey(paramArrayOfbyte1, arrayOfByte, paramArrayOfbyte3);
    return arrayOfByte;
  }
  
  public String getInfo() {
    return getClass().getName() + "-Use com.dreammirae.gtotp.seed.SeedxEngine";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\cipher\CipherImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */