package com.dreammirae.gt.otp.keyfile;

import com.dreammirae.gt.otp.Core;
import com.dreammirae.gt.otp.Tool;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

public final class TokenFileFactory {
  public static TokenFile getTokenFile(String paramString1, String paramString2) throws Exception {
    Parseable parseable = a(paramString1, paramString2);
    if (parseable != null)
      return parseable.getTokenFile(); 
    throw new Exception("not support keyfile version!");
  }
  
  private static Parseable a(String paramString1, String paramString2) throws Exception {
    String str1 = "";
    String str2 = "";
    String str3 = "";
    File file = new File(paramString1);
    BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
    str1 = a(bufferedInputStream);
    if (str1 == null || str1.length() != 6)
      throw new InvalidTokenFormatException(); 
    str2 = str1.substring(0, 4);
    str3 = str1.substring(4, 6);
    if (!"_STR".equals(str2))
      throw new InvalidTokenFormatException(); 
    bufferedInputStream.close();
    return (Parseable)(("20".equals(str3) || "21".equals(str3) || "22".equals(str3)) ? new V22Parser(paramString1, paramString2, str3) : ("23".equals(str3) ? new V23Parser(paramString1, paramString2, str3) : null));
  }
  
  private static String a(BufferedInputStream paramBufferedInputStream) throws Exception {
    byte b = 6;
    byte[] arrayOfByte = new byte[b];
    String str = null;
    try {
      paramBufferedInputStream.mark(b);
      int i = paramBufferedInputStream.read(arrayOfByte);
      if (i == arrayOfByte.length)
        str = new String(arrayOfByte); 
      paramBufferedInputStream.reset();
    } catch (Exception exception) {
      exception.printStackTrace();
      throw exception;
    } 
    return str;
  }
  
  public static void main(String[] paramArrayOfString) {
    Core core = Core.getInstance();
    byte[] arrayOfByte = null;
    String str1 = "C:\\Users\\stariki\\key\\SMS OTP 개발 샘플키\\mir_99991000_99991009_v22.ttk";
    String str2 = "D4F0A2E6079A68AA";
    try {
      TokenFile tokenFile = getTokenFile(str1, str2);
      System.out.println(tokenFile.toString());
      String str3 = "";
      String str4 = "";
      String str5 = "";
      String str6 = "";
      String str7 = "";
      String str8 = "";
      String str9 = "";
      str5 = tokenFile.getHeader().getOrgCode();
      str6 = tokenFile.getHeader().getExtOrgCode();
      str8 = tokenFile.getHeader().getCycle();
      str7 = tokenFile.getHeader().getTokenType();
      Body[] arrayOfBody = tokenFile.getBody();
      for (byte b = 0; b < arrayOfBody.length; b++) {
        str3 = arrayOfBody[b].getSn();
        str4 = Tool.toString(core.ENCRYPT(null, null, arrayOfByte, null, arrayOfBody[b].getSeed()));
        str9 = str4 + str5 + str6 + str7 + str8;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\TokenFileFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */