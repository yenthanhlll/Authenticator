package com.dreammirae.gt.otp.keyfile;

import com.dreammirae.gt.otp.Tool;
import com.dreammirae.gt.otp.hmac.HmacImpl;
import com.dreammirae.gt.otp.md.MdImpl;
import com.dreammirae.gt.otp.seed.SeedxEngine;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;

public final class V22Parser implements Parseable {
  private TokenFile c = null;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  MdImpl a = new MdImpl();
  
  HmacImpl b = new HmacImpl();
  
  protected V22Parser(String paramString1, String paramString2, String paramString3) {
    this.c = new TokenFile();
    this.d = paramString1;
    this.e = paramString2;
    this.f = paramString3;
  }
  
  public TokenFile getTokenFile() throws Exception {
    File file = new File(this.d);
    Header header = new Header();
    BufferedInputStream bufferedInputStream = null;
    byte[] arrayOfByte1 = new byte[20];
    byte[] arrayOfByte2 = new byte[16];
    byte[] arrayOfByte3 = new byte[180];
    byte[] arrayOfByte4 = new byte[20];
    byte[] arrayOfByte5 = new byte[5];
    byte[] arrayOfByte6 = new byte[5];
    byte[] arrayOfByte7 = new byte[2];
    byte[] arrayOfByte8 = new byte[2];
    byte[] arrayOfByte9 = new byte[10];
    byte[] arrayOfByte10 = new byte[10];
    byte[] arrayOfByte11 = new byte[8];
    byte[] arrayOfByte12 = new byte[8];
    byte[] arrayOfByte13 = new byte[2];
    byte[] arrayOfByte14 = new byte[1];
    byte[] arrayOfByte15 = new byte[1];
    byte[] arrayOfByte16 = new byte[1];
    byte[] arrayOfByte17 = new byte[80];
    byte[] arrayOfByte18 = new byte[1];
    byte[] arrayOfByte19 = new byte[1];
    byte[] arrayOfByte20 = new byte[37];
    byte[] arrayOfByte21 = new byte[20];
    try {
      bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
      byte[] arrayOfByte = new byte[200];
      int i = 0;
      i = bufferedInputStream.read(arrayOfByte);
      if (i != 200)
        throw new InvalidTokenFormatException(); 
      int j = 0;
      System.arraycopy(arrayOfByte, 6, arrayOfByte5, 0, 5);
      System.arraycopy(arrayOfByte, 11, arrayOfByte6, 0, 5);
      System.arraycopy(arrayOfByte, 16, arrayOfByte7, 0, 2);
      System.arraycopy(arrayOfByte, 18, arrayOfByte8, 0, 2);
      System.arraycopy(arrayOfByte, 20, arrayOfByte9, 0, 10);
      System.arraycopy(arrayOfByte, 30, arrayOfByte10, 0, 10);
      System.arraycopy(arrayOfByte, 40, arrayOfByte11, 0, 8);
      System.arraycopy(arrayOfByte, 48, arrayOfByte12, 0, 8);
      System.arraycopy(arrayOfByte, 56, arrayOfByte13, 0, 2);
      System.arraycopy(arrayOfByte, 58, arrayOfByte14, 0, 1);
      System.arraycopy(arrayOfByte, 59, arrayOfByte15, 0, 1);
      System.arraycopy(arrayOfByte, 60, arrayOfByte16, 0, 1);
      System.arraycopy(arrayOfByte, 61, arrayOfByte17, 0, 80);
      System.arraycopy(arrayOfByte, 141, arrayOfByte18, 0, 1);
      System.arraycopy(arrayOfByte, 142, arrayOfByte19, 0, 1);
      System.arraycopy(arrayOfByte, 143, arrayOfByte20, 0, 37);
      System.arraycopy(arrayOfByte, 180, arrayOfByte21, 0, 20);
      arrayOfByte1 = this.a.digest("sha1", this.e.getBytes());
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, 16);
      System.arraycopy(arrayOfByte, 0, arrayOfByte3, 0, 180);
      arrayOfByte4 = this.b.hmac(arrayOfByte2, arrayOfByte3);
      if (!Arrays.equals(arrayOfByte4, arrayOfByte21))
        throw new InvalidPinException(); 
      header.p(this.f);
      header.i(new String(arrayOfByte5));
      header.f(new String(arrayOfByte6));
      header.l(new String(arrayOfByte7));
      header.h(new String(arrayOfByte8));
      header.m(new String(arrayOfByte9));
      header.d(new String(arrayOfByte10));
      header.c(new String(arrayOfByte11));
      header.e(new String(arrayOfByte12));
      header.n(new String(arrayOfByte13));
      header.j(new String(arrayOfByte14));
      header.a(new String(arrayOfByte15));
      header.o(new String(arrayOfByte16));
      header.b(new String(arrayOfByte17, "ms949"));
      header.q(new String(arrayOfByte18));
      header.setDeviceExpire(new String(arrayOfByte19));
      header.g(new String(arrayOfByte20));
      header.a(arrayOfByte21);
      this.c.a(header);
      j = Integer.parseInt(header.getEndSn()) - Integer.parseInt(header.getStartSn()) + 1;
      Body[] arrayOfBody = new Body[j];
      for (byte b = 0; b < j; b++) {
        byte[] arrayOfByte22 = new byte[100];
        byte[] arrayOfByte23 = new byte[4];
        byte[] arrayOfByte24 = new byte[32];
        byte[] arrayOfByte25 = new byte[44];
        byte[] arrayOfByte26 = new byte[20];
        byte[] arrayOfByte27 = new byte[80];
        i = bufferedInputStream.read(arrayOfByte22);
        if (i != 100)
          throw new InvalidTokenFormatException(); 
        System.arraycopy(arrayOfByte22, 0, arrayOfByte27, 0, 80);
        System.arraycopy(arrayOfByte22, 80, arrayOfByte26, 0, 20);
        arrayOfByte4 = this.b.hmac(arrayOfByte2, arrayOfByte27);
        if (!Arrays.equals(arrayOfByte4, arrayOfByte26))
          throw new InvalidCheckSumException(); 
        System.arraycopy(arrayOfByte22, 0, arrayOfByte23, 0, 4);
        System.arraycopy(arrayOfByte22, 4, arrayOfByte24, 0, 32);
        System.arraycopy(arrayOfByte22, 36, arrayOfByte25, 0, 44);
        byte[] arrayOfByte28 = new byte[20];
        SeedxEngine.decipherTokenKey(arrayOfByte2, arrayOfByte28, arrayOfByte24);
        arrayOfBody[b] = new Body();
        arrayOfBody[b].b(Integer.toString(Tool.byteArrayToInt(arrayOfByte23)));
        arrayOfBody[b].b(arrayOfByte28);
        arrayOfBody[b].a(arrayOfByte26);
        arrayOfBody[b].a(new String(arrayOfByte25));
      } 
      this.c.a(arrayOfBody);
      Tail tail = new Tail();
      this.c.a(tail);
      this.c.a(file.getName());
    } finally {
      if (bufferedInputStream != null)
        bufferedInputStream.close(); 
    } 
    return this.c;
  }
  
  public String getInfo() {
    return "v22 paser";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\V22Parser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */