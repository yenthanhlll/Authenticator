package com.dreammirae.gt.otp.keyfile;

public final class TokenFile {
  private Header a = null;
  
  private Body[] b = null;
  
  private Tail c = null;
  
  private String d = null;
  
  public TokenFile() {}
  
  public TokenFile(Header paramHeader, Body[] paramArrayOfBody, Tail paramTail) {
    this.a = paramHeader;
    this.b = paramArrayOfBody;
    this.c = paramTail;
  }
  
  public Body[] getBody() {
    return this.b;
  }
  
  protected void a(Body[] paramArrayOfBody) {
    this.b = paramArrayOfBody;
  }
  
  public Header getHeader() {
    return this.a;
  }
  
  protected void a(Header paramHeader) {
    this.a = paramHeader;
  }
  
  public Tail getTail() {
    return this.c;
  }
  
  protected void a(Tail paramTail) {
    this.c = paramTail;
  }
  
  public String getFileName() {
    return this.d;
  }
  
  protected void a(String paramString) {
    this.d = paramString;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("-----------------------------").append(KeyfileConstant.RN).append("#HEADER INFO").append(KeyfileConstant.RN).append("-----------------------------").append(KeyfileConstant.RN).append(this.a.toString()).append(KeyfileConstant.RN).append("-----------------------------").append(KeyfileConstant.RN).append("#BODY INFO").append(KeyfileConstant.RN).append("-----------------------------").append(KeyfileConstant.RN);
    for (byte b = 0; b < this.b.length; b++)
      stringBuffer.append(this.b[b].toString()); 
    stringBuffer.append("-----------------------------").append(KeyfileConstant.RN);
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\TokenFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */