package com.dreammirae.gt.otp.keyfile;

import com.dreammirae.gt.otp.Tool;

public final class Body {
  private byte[] a = new byte[20];
  
  private byte[] b;
  
  private String c = "";
  
  private String d = "";
  
  private byte[] e = new byte[20];
  
  public byte[] getChecksum() {
    return this.e;
  }
  
  protected void a(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null)
      return; 
    if (paramArrayOfbyte.length != 20)
      return; 
    this.e = paramArrayOfbyte;
  }
  
  public String getFiller() {
    return this.d;
  }
  
  protected void a(String paramString) {
    this.d = paramString;
  }
  
  public byte[] getSeed() {
    return this.a;
  }
  
  protected void b(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null)
      return; 
    if (paramArrayOfbyte.length != 20)
      return; 
    this.a = paramArrayOfbyte;
  }
  
  public String getSn() {
    return this.c;
  }
  
  protected void b(String paramString) {
    if (paramString == null)
      return; 
    this.c = paramString;
  }
  
  public byte[] getSeed2() {
    return this.b;
  }
  
  public void setSeed2(byte[] paramArrayOfbyte) {
    this.b = paramArrayOfbyte;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(this.c).append(",").append(Tool.toString(this.a)).append(",");
    if (this.b != null)
      stringBuffer.append(Tool.toString(this.b)); 
    stringBuffer.append(",").append(Tool.toString(this.e)).append(KeyfileConstant.RN);
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\Body.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */