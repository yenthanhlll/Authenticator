package com.dreammirae.gt.otp.keyfile;

import com.dreammirae.gt.otp.Tool;
import java.io.Serializable;

public final class Header implements Serializable {
  private static final long a = -6464620534419785365L;
  
  private String b = "_STR";
  
  private String c = "";
  
  private String d = "";
  
  private String e = "";
  
  private String f = "";
  
  private String g = "";
  
  private String h = "";
  
  private String i = "";
  
  private String j = "";
  
  private String k = "";
  
  private String l = "";
  
  private String m = "";
  
  private String n = "";
  
  private String o = "";
  
  private String p = "0";
  
  private String q = "";
  
  private String r = "";
  
  private String s = "";
  
  private byte[] t = new byte[20];
  
  public String getAlgType() {
    return this.n;
  }
  
  protected void a(String paramString) {
    if (paramString == null)
      return; 
    this.n = paramString;
  }
  
  public byte[] getChecksum() {
    return this.t;
  }
  
  protected void a(byte[] paramArrayOfbyte) {
    this.t = paramArrayOfbyte;
  }
  
  public String getComment() {
    return this.q;
  }
  
  protected void b(String paramString) {
    this.q = paramString;
  }
  
  public String getCrDate() {
    return this.j;
  }
  
  protected void c(String paramString) {
    this.j = paramString;
  }
  
  public String getEndSn() {
    return this.i;
  }
  
  protected void d(String paramString) {
    this.i = paramString;
  }
  
  public String getExDate() {
    return this.k;
  }
  
  protected void e(String paramString) {
    this.k = paramString;
  }
  
  public String getExtOrgCode() {
    return this.e;
  }
  
  protected void f(String paramString) {
    this.e = paramString;
  }
  
  public String getFiller() {
    return this.s;
  }
  
  protected void g(String paramString) {
    this.s = paramString;
  }
  
  public String getMaxPinFail() {
    return this.g;
  }
  
  protected void h(String paramString) {
    this.g = paramString;
  }
  
  public String getOrgCode() {
    return this.d;
  }
  
  protected void i(String paramString) {
    this.d = paramString;
  }
  
  public String getPinType() {
    return this.m;
  }
  
  protected void j(String paramString) {
    this.m = paramString;
  }
  
  public String getSignature() {
    return this.b;
  }
  
  protected void k(String paramString) {
    this.b = paramString;
  }
  
  public String getSnLength() {
    return this.f;
  }
  
  protected void l(String paramString) {
    this.f = paramString;
  }
  
  public String getStartSn() {
    return this.h;
  }
  
  protected void m(String paramString) {
    this.h = paramString;
  }
  
  public String getTokenType() {
    return this.l;
  }
  
  protected void n(String paramString) {
    this.l = paramString;
  }
  
  public String getUseType() {
    return this.o;
  }
  
  protected void o(String paramString) {
    this.o = paramString;
  }
  
  public String getVersion() {
    return this.c;
  }
  
  protected void p(String paramString) {
    this.c = paramString;
  }
  
  public String getCycle() {
    return this.p;
  }
  
  protected void q(String paramString) {
    if ("1".equals(paramString) || "2".equals(paramString)) {
      this.p = paramString;
    } else {
      this.p = "0";
    } 
  }
  
  public String getDeviceExpire() {
    return this.r;
  }
  
  public void setDeviceExpire(String paramString) {
    this.r = paramString;
  }
  
  public int getTotalBody() {
    return Integer.parseInt(this.i) - Integer.parseInt(this.h) + 1;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("signature=[").append(this.b).append("]").append(KeyfileConstant.RN).append("ver=[").append(this.c).append("]").append(KeyfileConstant.RN).append("orgcode=[").append(this.d).append("]").append(KeyfileConstant.RN).append("extOrgCode=[").append(this.e).append("]").append(KeyfileConstant.RN).append("snLength=[").append(this.f).append("]").append(KeyfileConstant.RN).append("maxPinFail=[").append(this.g).append("]").append(KeyfileConstant.RN).append("startSn=[").append(this.h).append("]").append(KeyfileConstant.RN).append("endSn=[").append(this.i).append("]").append(KeyfileConstant.RN).append("crDate=[").append(this.j).append("]").append(KeyfileConstant.RN).append("exDate=[").append(this.k).append("]").append(KeyfileConstant.RN).append("tokenType=[").append(this.l).append("]").append(KeyfileConstant.RN).append("pinType=[").append(this.m).append("]").append(KeyfileConstant.RN).append("algType=[").append(this.n).append("]").append(KeyfileConstant.RN).append("useType=[").append(this.o).append("]").append(KeyfileConstant.RN).append("comment=[").append(this.q).append("]").append(KeyfileConstant.RN).append("cycle=[").append(this.p).append("]").append(KeyfileConstant.RN).append("deviceExpire=[").append(this.r).append("]").append(KeyfileConstant.RN).append("filler=[").append(this.s).append("]").append(KeyfileConstant.RN).append("chksum=[").append(Tool.toString(this.t)).append("]");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */