package com.dreammirae.gt.otp.keyfile;

public final class Tail {
  private String a = "_END";
  
  private String b = "";
  
  protected Tail() {
    this.b = "";
  }
  
  public String getFiller() {
    return this.b;
  }
  
  protected void a(String paramString) {
    this.b = paramString;
  }
  
  public String getSignature() {
    return this.a;
  }
  
  protected void b(String paramString) {
    this.a = paramString;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\Tail.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */