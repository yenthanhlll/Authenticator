package com.dreammirae.gt.otp.keyfile;

import com.dreammirae.gt.otp.Tool;
import com.dreammirae.gt.otp.hmac.HmacImpl;
import com.dreammirae.gt.otp.md.MdImpl;
import com.dreammirae.gt.otp.seed.SeedxEngine;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;

public final class V21Parser implements Parseable {
  private TokenFile c = null;
  
  private String d = null;
  
  private String e = null;
  
  private String f = null;
  
  MdImpl a = new MdImpl();
  
  HmacImpl b = new HmacImpl();
  
  protected V21Parser(String paramString1, String paramString2, String paramString3) {
    this.c = new TokenFile();
    this.d = paramString1;
    this.e = paramString2;
    this.f = paramString3;
  }
  
  public TokenFile getTokenFile() throws Exception {
    File file = new File(this.d);
    Header header = new Header();
    BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
    byte[] arrayOfByte1 = new byte[200];
    int i = 0;
    i = bufferedInputStream.read(arrayOfByte1);
    if (i != 200)
      throw new InvalidTokenFormatException(); 
    byte[] arrayOfByte2 = new byte[20];
    byte[] arrayOfByte3 = new byte[16];
    byte[] arrayOfByte4 = new byte[180];
    byte[] arrayOfByte5 = new byte[20];
    byte[] arrayOfByte6 = new byte[5];
    byte[] arrayOfByte7 = new byte[5];
    byte[] arrayOfByte8 = new byte[2];
    byte[] arrayOfByte9 = new byte[2];
    byte[] arrayOfByte10 = new byte[10];
    byte[] arrayOfByte11 = new byte[10];
    byte[] arrayOfByte12 = new byte[8];
    byte[] arrayOfByte13 = new byte[8];
    byte[] arrayOfByte14 = new byte[2];
    byte[] arrayOfByte15 = new byte[1];
    byte[] arrayOfByte16 = new byte[1];
    byte[] arrayOfByte17 = new byte[1];
    byte[] arrayOfByte18 = new byte[80];
    byte[] arrayOfByte19 = new byte[37];
    byte[] arrayOfByte20 = new byte[20];
    int j = 0;
    System.arraycopy(arrayOfByte1, 6, arrayOfByte6, 0, 5);
    System.arraycopy(arrayOfByte1, 11, arrayOfByte7, 0, 5);
    System.arraycopy(arrayOfByte1, 16, arrayOfByte8, 0, 2);
    System.arraycopy(arrayOfByte1, 18, arrayOfByte9, 0, 2);
    System.arraycopy(arrayOfByte1, 20, arrayOfByte10, 0, 10);
    System.arraycopy(arrayOfByte1, 30, arrayOfByte11, 0, 10);
    System.arraycopy(arrayOfByte1, 40, arrayOfByte12, 0, 8);
    System.arraycopy(arrayOfByte1, 48, arrayOfByte13, 0, 8);
    System.arraycopy(arrayOfByte1, 56, arrayOfByte14, 0, 2);
    System.arraycopy(arrayOfByte1, 58, arrayOfByte15, 0, 1);
    System.arraycopy(arrayOfByte1, 59, arrayOfByte16, 0, 1);
    System.arraycopy(arrayOfByte1, 60, arrayOfByte17, 0, 1);
    System.arraycopy(arrayOfByte1, 61, arrayOfByte18, 0, 80);
    System.arraycopy(arrayOfByte1, 141, arrayOfByte19, 0, 37);
    System.arraycopy(arrayOfByte1, 180, arrayOfByte20, 0, 20);
    arrayOfByte2 = this.a.digest("sha1", this.e.getBytes());
    System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, 16);
    System.arraycopy(arrayOfByte1, 0, arrayOfByte4, 0, 180);
    arrayOfByte5 = this.b.hmac(arrayOfByte3, arrayOfByte4);
    if (!Arrays.equals(arrayOfByte5, arrayOfByte20))
      throw new InvalidPinException(); 
    header.p(this.f);
    header.i(new String(arrayOfByte6));
    header.f(new String(arrayOfByte7));
    header.l(new String(arrayOfByte8));
    header.h(new String(arrayOfByte9));
    header.m(new String(arrayOfByte10));
    header.d(new String(arrayOfByte11));
    header.c(new String(arrayOfByte12));
    header.e(new String(arrayOfByte13));
    header.n(new String(arrayOfByte14));
    header.j(new String(arrayOfByte15));
    header.a(new String(arrayOfByte16));
    header.o(new String(arrayOfByte17));
    header.b(new String(arrayOfByte18, "ms949"));
    header.g(new String(arrayOfByte19));
    header.a(arrayOfByte20);
    header.q((new String(arrayOfByte19)).substring(0, 1));
    this.c.a(header);
    j = Integer.parseInt(header.getEndSn()) - Integer.parseInt(header.getStartSn()) + 1;
    Body[] arrayOfBody = new Body[j];
    for (byte b = 0; b < j; b++) {
      byte[] arrayOfByte21 = new byte[100];
      byte[] arrayOfByte22 = new byte[4];
      byte[] arrayOfByte23 = new byte[32];
      byte[] arrayOfByte24 = new byte[44];
      byte[] arrayOfByte25 = new byte[20];
      byte[] arrayOfByte26 = new byte[80];
      i = bufferedInputStream.read(arrayOfByte21);
      if (i != 100)
        throw new InvalidTokenFormatException(); 
      System.arraycopy(arrayOfByte21, 0, arrayOfByte26, 0, 80);
      System.arraycopy(arrayOfByte21, 80, arrayOfByte25, 0, 20);
      arrayOfByte5 = this.b.hmac(arrayOfByte3, arrayOfByte26);
      if (!Arrays.equals(arrayOfByte5, arrayOfByte25))
        throw new InvalidCheckSumException(); 
      System.arraycopy(arrayOfByte21, 0, arrayOfByte22, 0, 4);
      System.arraycopy(arrayOfByte21, 4, arrayOfByte23, 0, 32);
      System.arraycopy(arrayOfByte21, 36, arrayOfByte24, 0, 44);
      byte[] arrayOfByte27 = new byte[20];
      SeedxEngine.decipherTokenKey(arrayOfByte3, arrayOfByte27, arrayOfByte23);
      arrayOfBody[b] = new Body();
      arrayOfBody[b].b(Integer.toString(Tool.byteArrayToInt(arrayOfByte22)));
      arrayOfBody[b].b(arrayOfByte27);
      arrayOfBody[b].a(arrayOfByte25);
      arrayOfBody[b].a(new String(arrayOfByte24));
    } 
    this.c.a(arrayOfBody);
    Tail tail = new Tail();
    this.c.a(tail);
    this.c.a(file.getName());
    return this.c;
  }
  
  public String getInfo() {
    return "v21paser";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\V21Parser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */