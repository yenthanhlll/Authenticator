package com.dreammirae.gt.otp.keyfile;

public class KeyfileConstant {
  public static final String RN = System.getProperty("line.separator");
  
  public static final int HEADER_SIZE = 200;
  
  public static final int BODY_SIZE = 100;
  
  public static final int TAIL_SIZE = 100;
  
  public static final int CSUM_SIZE = 20;
  
  public static final int HEADER_START_LEN = 4;
  
  public static final int HERADER_VER_LEN = 2;
  
  public static final int HERADER_IORG_LEN = 5;
  
  public static final int HERADER_EORG_LEN = 5;
  
  public static final int HEADER_SN_LEN = 2;
  
  public static final int HEADER_MAX_PIN_LEN = 2;
  
  public static final int HEADER_START_SN_LEN = 10;
  
  public static final int HEADER_END_SN_LEN = 10;
  
  public static final int HEADER_CT_DATE_LEN = 8;
  
  public static final int HEADER_EX_DATE_LEN = 8;
  
  public static final int HEADER_TOKEN_TYPE_LEN = 2;
  
  public static final int HEADER_PIN_TYPE_LEN = 1;
  
  public static final int HEADER_ALG_TYPE_LEN = 1;
  
  public static final int HEADER_USE_TYPE_LEN = 1;
  
  public static final int HEADER_COMMENT_LEN = 80;
  
  public static final int HEADER_CYCLE_LEN = 1;
  
  public static final int HEADER_EXPIRE_LEN = 1;
  
  public static final int HEADER_FILLER_LEN = 37;
  
  public static final int HEADER_CHKSUM_LEN = 20;
  
  public static final int BODY_SN_LEN = 4;
  
  public static final int BODY_ENC_KEY_LEN = 32;
  
  public static final int BODY_FILLER_LEN = 44;
  
  public static final int BODY_CHKSUM_LEN = 20;
  
  public static final int BODY_RAW_KEY_LEN = 20;
  
  public static final String START_SIGNATURE = "_STR";
  
  public static final String END_SIGNATURE = "_END";
  
  public static final String VER_20 = "20";
  
  public static final String VER_21 = "21";
  
  public static final String VER_22 = "22";
  
  public static final String VER_23 = "23";
  
  public static final String SN_LEN_8 = "08";
  
  public static final String SN_LEN_9 = "09";
  
  public static final String MRT_100P = "01";
  
  public static final String MRT_200P = "02";
  
  public static final String MRT_300nP = "03";
  
  public static final String MRC_400nP = "04";
  
  public static final String MRT_400nP = "07";
  
  public static final String ANY_OTP = "08";
  
  public static final String MRT_600nP = "09";
  
  public static final String SMS_OTP = "11";
  
  public static final String HW_PIN = "1";
  
  public static final String SW_PIN = "2";
  
  public static final String ALG_MD5 = "1";
  
  public static final String ALG_HMAC_SHA1 = "2";
  
  public static final String ALG_ANY_OTP = "3";
  
  public static final String ALG_SMS_OTP = "4";
  
  public static final String USE_OF_SERVICE = "1";
  
  public static final String USE_OF_SAMPLE = "2";
  
  public static final String USE_OF_TEST_FOR_MR = "3";
  
  public static final String USE_OF_AUTH_FOR_MR = "4";
  
  public static final String OTP_CYCLE_60_SEC = "0";
  
  public static final String OTP_CYCLE_30_SEC = "1";
  
  public static final String OTP_CYCLE_15_SEC = "2";
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\keyfile\KeyfileConstant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */