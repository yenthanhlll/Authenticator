package com.dreammirae.gt.otp;

public final class Constant {
  protected static final String a = "2";
  
  protected static final String b = "0.1";
  
  protected static final String c = "2.0.1";
  
  protected static final String d = "Mirae technology TimeOtp Core Library(java)";
  
  public static final String JAR_INFO = "Mirae technology TimeOtp Core Library(java), ver:2.0.1";
  
  protected static final String e = "HmacSHA1";
  
  protected static final String f = "com.dreammirae.gt.otp.hmac.HmacImpl";
  
  protected static final String g = "com.dreammirae.gt.otp.md.MdImpl";
  
  protected static final String h = "com.dreammirae.gt.otp.cipher.CipherImpl";
  
  protected static final int i = 0;
  
  protected static final int j = 0;
  
  protected static final int k = 0;
  
  protected static final int l = 0;
  
  protected static final int m = 0;
  
  protected static final int n = 6000;
  
  protected static final int o = 6001;
  
  protected static final int p = 6002;
  
  protected static final int q = 6003;
  
  protected static final int r = 6004;
  
  protected static final int s = 6005;
  
  protected static final int t = 6007;
  
  protected static final int u = 6010;
  
  protected static final int v = 6011;
  
  protected static final int w = 6012;
  
  protected static final int x = 946652400;
  
  protected static final int y = 6;
  
  protected static int[] z = new int[] { 0, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };
  
  protected static final int A = 0;
  
  protected static final int B = 1;
  
  protected static final int C = 2;
  
  protected static final String D = "0";
  
  protected static final String E = "1";
  
  protected static final String F = "2";
  
  protected static final byte G = 1;
  
  protected static final byte H = 2;
  
  protected static final byte I = 3;
  
  protected static final byte[] J = new byte[] { 0, 0, 0 };
  
  protected static final String K = "1";
  
  protected static final String L = "2";
  
  protected static final String M = "5";
  
  protected static final String N = "6";
  
  protected static final String O = "6";
  
  protected static final String P = "H";
  
  protected static final String Q = "T";
  
  protected static final String R = "12";
  
  protected static final String S = "278";
  
  protected static final String T = "429";
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\Constant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */