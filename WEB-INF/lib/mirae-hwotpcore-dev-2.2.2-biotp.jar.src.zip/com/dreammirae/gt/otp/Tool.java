package com.dreammirae.gt.otp;

import com.dreammirae.gt.otp.md.MDIterface;
import com.dreammirae.gt.otp.md.SHA256Impl;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Tool {
  private static TimeZone a = TimeZone.getTimeZone("Asia/Seoul");
  
  private static final char[] b = "0123456789ABCDEF".toCharArray();
  
  private static final MDIterface c = (MDIterface)new SHA256Impl();
  
  public static final TimeZone DFT_TIME_ZONE = TimeZone.getTimeZone("Asia/Seoul");
  
  public static TimeZone defaultTimeZone() {
    return DFT_TIME_ZONE;
  }
  
  public static long byteArrayToLong(byte[] paramArrayOfbyte) {
    return byteArrayToLong(paramArrayOfbyte, 0);
  }
  
  public static long byteArrayToLong(byte[] paramArrayOfbyte, int paramInt) {
    long l = 0L;
    for (byte b = 0; b < 8; b++) {
      int i = (7 - b) * 8;
      l += (paramArrayOfbyte[b + paramInt] & 0xFF) << i;
    } 
    return l;
  }
  
  public static Date str2Date(String paramString) throws ParseException {
    return str2Date(paramString, "yyyyMMdd", DFT_TIME_ZONE);
  }
  
  public static Date str2Date(String paramString1, String paramString2, TimeZone paramTimeZone) throws ParseException {
    Date date = null;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString2);
    try {
      simpleDateFormat.setTimeZone(paramTimeZone);
      date = simpleDateFormat.parse(paramString1);
    } catch (ParseException parseException) {
      throw parseException;
    } 
    return date;
  }
  
  public static String date2Str(Date paramDate) {
    return date2Str(paramDate, "yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("Asia/Seoul"));
  }
  
  public static String date2Str(Date paramDate, String paramString, TimeZone paramTimeZone) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString);
    String str = "";
    try {
      simpleDateFormat.setTimeZone(paramTimeZone);
      str = simpleDateFormat.format(paramDate);
    } catch (Exception exception) {
      return null;
    } 
    return str;
  }
  
  public static byte[] orgCode2Byte(int paramInt) {
    return new byte[] { (byte)(paramInt >> 8 & 0xFF), (byte)(paramInt & 0xFF) };
  }
  
  public static byte[] orgCode3Byte(int paramInt) {
    byte[] arrayOfByte = new byte[3];
    System.arraycopy(toBytesFromInt(paramInt), 1, arrayOfByte, 0, 3);
    return arrayOfByte;
  }
  
  public static byte[] orgCode3Byte(String paramString) {
    byte[] arrayOfByte = new byte[3];
    try {
      byte[] arrayOfByte1 = toBytesFromInt(Integer.parseInt(paramString));
      System.arraycopy(arrayOfByte1, 1, arrayOfByte, 0, 3);
    } catch (NumberFormatException numberFormatException) {}
    return arrayOfByte;
  }
  
  public static String onlyNum(String paramString) {
    return (paramString == null) ? null : paramString.replaceAll("[^0-9]", "");
  }
  
  public static byte[] transSHA256(String paramString1, String paramString2) {
    String str = null;
    try {
      if (paramString1 == null)
        throw new IllegalArgumentException("account must be not null"); 
      paramString1 = onlyNum(paramString1);
      if (paramString1.length() >= 16)
        paramString1 = paramString1.substring(0, 16); 
      if (paramString2 == null || "".equals(onlyNum(paramString2))) {
        str = String.format("%s#", new Object[] { paramString1 });
      } else {
        paramString2 = onlyNum(paramString2);
        if (paramString2.length() >= 16)
          paramString2 = paramString2.substring(0, 16); 
        str = String.format("%s#%s#", new Object[] { paramString1, paramString2 });
      } 
      return c.digest(null, str.getBytes());
    } catch (IllegalArgumentException illegalArgumentException) {
      throw illegalArgumentException;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static String transSHA256(String paramString) {
    try {
      return toString(c.digest(null, paramString.getBytes("ms949")));
    } catch (IllegalArgumentException illegalArgumentException) {
      throw illegalArgumentException;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static int kst2otp(String paramString1, String paramString2) {
    int i;
    try {
      Calendar calendar = Calendar.getInstance(a);
      int j = stringToInt(paramString1.substring(0, 4), 0);
      int k = stringToInt(paramString1.substring(4, 6), 0) - 1;
      int m = stringToInt(paramString1.substring(6, 8), 0);
      int n = stringToInt(paramString2.substring(0, 2), 0);
      int i1 = stringToInt(paramString2.substring(2, 4), 0);
      int i2 = stringToInt(paramString2.substring(4, 6), 0);
      calendar.set(1, j);
      calendar.set(2, k);
      calendar.set(9, 0);
      calendar.set(5, m);
      calendar.set(10, n);
      calendar.set(12, i1);
      calendar.set(13, i2);
      i = convertOtpSysTime(calendar);
    } catch (Exception exception) {
      return -1;
    } 
    return i;
  }
  
  public static int getCycle(String paramString) {
    return "2".equals(paramString) ? 15 : ("1".equals(paramString) ? 30 : 60);
  }
  
  public static int[] getFindSkew(int paramInt1, int paramInt2) {
    if (paramInt2 != 60 && paramInt2 != 30 && paramInt2 != 15)
      return new int[1]; 
    byte b1 = (paramInt1 == 0) ? 1 : (paramInt1 * 60 / paramInt2 * 2 + 1);
    int[] arrayOfInt = new int[b1];
    for (byte b2 = 0; b2 < b1; b2++) {
      int i = (b2 % 2 == 0) ? (b2 / 2) : (-(b2 / 2) - 1);
      i *= paramInt2;
      arrayOfInt[b2] = i;
    } 
    return arrayOfInt;
  }
  
  public static int convertOtpSysTime(Calendar paramCalendar) {
    int i = (int)(paramCalendar.getTime().getTime() / 1000L);
    return i - 946652400;
  }
  
  public static int getOtpSysTime() {
    null = 0;
    int i = (int)((new Date()).getTime() / 1000L);
    return i - 946652400;
  }
  
  public static int getOtpSvrTime(Policy paramPolicy) {
    int i = 0;
    int j = getOtpSysTime();
    if (paramPolicy != null)
      i = j + paramPolicy.getServerTmSkew() * 60; 
    return i;
  }
  
  public static int getOtpTokenTime(Policy paramPolicy, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramPolicy != null) {
      j = (int)((new Date()).getTime() / 1000L);
      i = j - 946652400 + paramPolicy.getServerTmSkew() * 60 + paramInt;
    } 
    return i;
  }
  
  public static int getOtpTokenTimeTOTP(Policy paramPolicy, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramPolicy != null) {
      j = (int)((new Date()).getTime() / 1000L);
      i = j + paramPolicy.getServerTmSkew() * 60 + paramInt;
    } 
    return i;
  }
  
  public static boolean isAuthLong(Policy paramPolicy, int paramInt1, int paramInt2) {
    int i = getOtpTokenTime(paramPolicy, paramInt2) / 86400;
    int j = paramInt1 / 86400;
    return (i - j >= paramPolicy.getLongTerm());
  }
  
  public static Date stringToDate(String paramString1, String paramString2) {
    Date date = null;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString1);
    try {
      date = simpleDateFormat.parse(paramString2);
    } catch (Exception exception) {}
    return date;
  }
  
  public static void String2file(String paramString1, String paramString2) {
    try {
      BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(paramString1), "UTF-8"));
      bufferedWriter.write(paramString2);
      bufferedWriter.close();
    } catch (Exception exception) {}
  }
  
  public static byte[] readFile(String paramString) {
    byte[] arrayOfByte = null;
    FileInputStream fileInputStream = null;
    try {
      fileInputStream = new FileInputStream(new File(paramString));
      int i = fileInputStream.available();
      arrayOfByte = new byte[i];
      fileInputStream.read(arrayOfByte);
      fileInputStream.close();
    } catch (IOException iOException) {
      return null;
    } finally {
      try {
        fileInputStream.close();
      } catch (Exception exception) {}
    } 
    return arrayOfByte;
  }
  
  public static boolean isNumber(String paramString) {
    if (paramString == null)
      return false; 
    try {
      Long.parseLong(paramString);
      return true;
    } catch (NumberFormatException numberFormatException) {
      return false;
    } 
  }
  
  public static String b64Encode(byte[] paramArrayOfbyte) {
    return Base64Util.encode(paramArrayOfbyte);
  }
  
  public static byte[] b64Decode(String paramString) throws IOException {
    return Base64Util.decode(paramString);
  }
  
  public static byte[] hash(String paramString, byte[] paramArrayOfbyte) throws NoSuchAlgorithmException {
    MessageDigest messageDigest = MessageDigest.getInstance(paramString);
    null = null;
    messageDigest.update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    return messageDigest.digest();
  }
  
  private static Key a(String paramString, byte[] paramArrayOfbyte) throws NoSuchAlgorithmException {
    return new SecretKeySpec(paramArrayOfbyte, paramString);
  }
  
  public static byte[] AES(String paramString, byte[] paramArrayOfbyte, int paramInt) throws Exception {
    if (paramArrayOfbyte == null)
      return null; 
    if (paramInt != 1 && paramInt != 2)
      return null; 
    byte[] arrayOfByte1 = new byte[20];
    byte[] arrayOfByte2 = new byte[16];
    byte[] arrayOfByte3 = new byte[16];
    byte[] arrayOfByte4 = new byte[4];
    arrayOfByte1 = hash("SHA-1", paramString.getBytes());
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, 16);
    System.arraycopy(arrayOfByte1, 16, arrayOfByte4, 0, 4);
    arrayOfByte1 = hash("SHA-1", arrayOfByte4);
    System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, 16);
    return AES(arrayOfByte2, arrayOfByte3, paramArrayOfbyte, paramInt);
  }
  
  public static byte[] AES(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt) throws Exception {
    null = null;
    Key key = a("AES", paramArrayOfbyte1);
    IvParameterSpec ivParameterSpec = new IvParameterSpec(paramArrayOfbyte2);
    String str = "AES/CBC/PKCS5Padding";
    Cipher cipher = Cipher.getInstance(str);
    cipher.init(paramInt, key, ivParameterSpec);
    return cipher.doFinal(paramArrayOfbyte3);
  }
  
  public static byte[] hexToByteArray(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return null; 
    byte[] arrayOfByte = new byte[paramString.length() / 2];
    for (byte b = 0; b < arrayOfByte.length; b++)
      arrayOfByte[b] = (byte)Integer.parseInt(paramString.substring(2 * b, 2 * b + 2), 16); 
    return arrayOfByte;
  }
  
  public static String toString(byte[] paramArrayOfbyte) {
    return toString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static final String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    char[] arrayOfChar = new char[paramInt2 * 2];
    byte b1 = 0;
    byte b2 = 0;
    while (b1 < paramInt2) {
      byte b = paramArrayOfbyte[paramInt1 + b1++];
      arrayOfChar[b2++] = b[b >>> 4 & 0xF];
      arrayOfChar[b2++] = b[b & 0xF];
    } 
    return new String(arrayOfChar);
  }
  
  public static String toReversedString(byte[] paramArrayOfbyte) {
    return toReversedString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static final String toReversedString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    char[] arrayOfChar = new char[paramInt2 * 2];
    int i = paramInt1 + paramInt2 - 1;
    byte b = 0;
    while (i >= paramInt1) {
      byte b1 = paramArrayOfbyte[paramInt1 + i--];
      arrayOfChar[b++] = b[b1 >>> 4 & 0xF];
      arrayOfChar[b++] = b[b1 & 0xF];
    } 
    return new String(arrayOfChar);
  }
  
  public static byte[] toBytesFromString(String paramString) {
    int i = paramString.length();
    byte[] arrayOfByte = new byte[(i + 1) / 2];
    byte b1 = 0;
    byte b2 = 0;
    if (i % 2 == 1)
      arrayOfByte[b2++] = (byte)fromDigit(paramString.charAt(b1++)); 
    while (b1 < i) {
      arrayOfByte[b2] = (byte)(fromDigit(paramString.charAt(b1++)) << 4);
      arrayOfByte[b2++] = (byte)(arrayOfByte[b2++] | (byte)fromDigit(paramString.charAt(b1++)));
    } 
    return arrayOfByte;
  }
  
  public static byte[] toReversedBytesFromString(String paramString) {
    int i = paramString.length();
    byte[] arrayOfByte = new byte[(i + 1) / 2];
    byte b = 0;
    if (i % 2 == 1)
      arrayOfByte[b++] = (byte)fromDigit(paramString.charAt(--i)); 
    while (i > 0) {
      arrayOfByte[b] = (byte)fromDigit(paramString.charAt(--i));
      arrayOfByte[b++] = (byte)(arrayOfByte[b++] | (byte)(fromDigit(paramString.charAt(--i)) << 4));
    } 
    return arrayOfByte;
  }
  
  public static int fromDigit(char paramChar) {
    if (paramChar >= '0' && paramChar <= '9')
      return paramChar - 48; 
    if (paramChar >= 'A' && paramChar <= 'F')
      return paramChar - 65 + 10; 
    if (paramChar >= 'a' && paramChar <= 'f')
      return paramChar - 97 + 10; 
    throw new IllegalArgumentException("Invalid hexadecimal digit: " + paramChar);
  }
  
  public static int stringToInt(String paramString, int paramInt) {
    try {
      return Integer.parseInt(paramString.trim());
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public static String toString(int paramInt) {
    char[] arrayOfChar = new char[8];
    for (byte b = 7; b >= 0; b--) {
      arrayOfChar[b] = b[paramInt & 0xF];
      paramInt >>>= 4;
    } 
    return new String(arrayOfChar);
  }
  
  public static String toString(int[] paramArrayOfint) {
    int i = paramArrayOfint.length;
    char[] arrayOfChar = new char[i * 8];
    byte b1 = 0;
    byte b2 = 0;
    while (b1 < i) {
      int j = paramArrayOfint[b1];
      arrayOfChar[b2++] = b[j >>> 28 & 0xF];
      arrayOfChar[b2++] = b[j >>> 24 & 0xF];
      arrayOfChar[b2++] = b[j >>> 20 & 0xF];
      arrayOfChar[b2++] = b[j >>> 16 & 0xF];
      arrayOfChar[b2++] = b[j >>> 12 & 0xF];
      arrayOfChar[b2++] = b[j >>> 8 & 0xF];
      arrayOfChar[b2++] = b[j >>> 4 & 0xF];
      arrayOfChar[b2++] = b[j & 0xF];
      b1++;
    } 
    return new String(arrayOfChar);
  }
  
  public static String toString(long paramLong) {
    char[] arrayOfChar = new char[16];
    for (byte b = 15; b >= 0; b--) {
      arrayOfChar[b] = b[(int)(paramLong & 0xFL)];
      paramLong >>>= 4L;
    } 
    return new String(arrayOfChar);
  }
  
  public static String toUnicodeString(byte[] paramArrayOfbyte) {
    return toUnicodeString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static final String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b1 = 0;
    byte b2 = 0;
    stringBuffer.append('\n').append("\"");
    while (b1 < paramInt2) {
      stringBuffer.append("\\u");
      byte b = paramArrayOfbyte[paramInt1 + b1++];
      stringBuffer.append(b[b >>> 4 & 0xF]);
      stringBuffer.append(b[b & 0xF]);
      b = paramArrayOfbyte[paramInt1 + b1++];
      stringBuffer.append(b[b >>> 4 & 0xF]);
      stringBuffer.append(b[b & 0xF]);
      if (++b2 % 8 == 0)
        stringBuffer.append("\"+").append('\n').append("\""); 
    } 
    stringBuffer.append("\"").append('\n');
    return stringBuffer.toString();
  }
  
  public static String toUnicodeString(int[] paramArrayOfint) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b1 = 0;
    byte b2 = 0;
    stringBuffer.append('\n').append("\"");
    while (b1 < paramArrayOfint.length) {
      int i = paramArrayOfint[b1++];
      stringBuffer.append("\\u");
      stringBuffer.append(b[i >>> 28 & 0xF]);
      stringBuffer.append(b[i >>> 24 & 0xF]);
      stringBuffer.append(b[i >>> 20 & 0xF]);
      stringBuffer.append(b[i >>> 16 & 0xF]);
      stringBuffer.append("\\u");
      stringBuffer.append(b[i >>> 12 & 0xF]);
      stringBuffer.append(b[i >>> 8 & 0xF]);
      stringBuffer.append(b[i >>> 4 & 0xF]);
      stringBuffer.append(b[i & 0xF]);
      if (++b2 % 4 == 0)
        stringBuffer.append("\"+").append('\n').append("\""); 
    } 
    stringBuffer.append("\"").append('\n');
    return stringBuffer.toString();
  }
  
  public static byte[] toBytesFromUnicode(String paramString) {
    int i = paramString.length() * 2;
    byte[] arrayOfByte = new byte[i];
    for (byte b = 0; b < i; b++) {
      char c = paramString.charAt(b >>> 1);
      arrayOfByte[b] = (byte)(((b & 0x1) == 0) ? (c >>> 8) : c);
    } 
    return arrayOfByte;
  }
  
  public static String dumpString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, String paramString) {
    if (paramArrayOfbyte == null)
      return paramString + "null\n"; 
    StringBuffer stringBuffer = new StringBuffer(paramInt2 * 3);
    if (paramInt2 > 32)
      stringBuffer.append(paramString).append("Hexadecimal dump of ").append(paramInt2).append(" bytes...\n"); 
    int i = paramInt1 + paramInt2;
    int j = Integer.toString(paramInt2).length();
    if (j < 4)
      j = 4; 
    while (paramInt1 < i) {
      if (paramInt2 > 32) {
        String str = "         " + paramInt1;
        stringBuffer.append(paramString).append(str.substring(str.length() - j)).append(": ");
      } 
      byte b;
      for (b = 0; b < 32 && paramInt1 + b + 7 < i; b += 8)
        stringBuffer.append(toString(paramArrayOfbyte, paramInt1 + b, 8)).append(' '); 
      if (b < 32)
        while (b < 32 && paramInt1 + b < i) {
          stringBuffer.append(byteToString(paramArrayOfbyte[paramInt1 + b]));
          b++;
        }  
      stringBuffer.append('\n');
      paramInt1 += 32;
    } 
    return stringBuffer.toString();
  }
  
  public static String dumpString(byte[] paramArrayOfbyte) {
    return (paramArrayOfbyte == null) ? "null\n" : dumpString(paramArrayOfbyte, 0, paramArrayOfbyte.length, "");
  }
  
  public static String dumpString(byte[] paramArrayOfbyte, String paramString) {
    return (paramArrayOfbyte == null) ? "null\n" : dumpString(paramArrayOfbyte, 0, paramArrayOfbyte.length, paramString);
  }
  
  public static String dumpString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return dumpString(paramArrayOfbyte, paramInt1, paramInt2, "");
  }
  
  public static String byteToString(int paramInt) {
    char[] arrayOfChar = { b[paramInt >>> 4 & 0xF], b[paramInt & 0xF] };
    return new String(arrayOfChar);
  }
  
  public static final byte[] trim(BigInteger paramBigInteger) {
    byte[] arrayOfByte1 = paramBigInteger.toByteArray();
    if (arrayOfByte1.length == 0 || arrayOfByte1[0] != 0)
      return arrayOfByte1; 
    int i = arrayOfByte1.length;
    byte b;
    for (b = 1; arrayOfByte1[b] == 0 && b < i; b++);
    byte[] arrayOfByte2 = new byte[i - b];
    System.arraycopy(arrayOfByte1, b, arrayOfByte2, 0, i - b);
    return arrayOfByte2;
  }
  
  public static final String dump(BigInteger paramBigInteger) {
    return dumpString(trim(paramBigInteger));
  }
  
  public static byte[] toBytesFromLong(long paramLong) {
    byte[] arrayOfByte = new byte[8];
    arrayOfByte[7] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[6] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[5] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[4] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[3] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[2] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[1] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[0] = (byte)(int)paramLong;
    return arrayOfByte;
  }
  
  public static byte[] toBytesFromInt(int paramInt) {
    return new byte[] { (byte)(paramInt >>> 24), (byte)(paramInt >> 16 & 0xFF), (byte)(paramInt >> 8 & 0xFF), (byte)(paramInt & 0xFF) };
  }
  
  public static int byteArrayToInt(byte[] paramArrayOfbyte) {
    return byteArrayToInt(paramArrayOfbyte, 0);
  }
  
  public static int byteArrayToInt(byte[] paramArrayOfbyte, int paramInt) {
    int i = 0;
    for (byte b = 0; b < 4; b++) {
      int j = (3 - b) * 8;
      i += (paramArrayOfbyte[b + paramInt] & 0xFF) << j;
    } 
    return i;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\Tool.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */