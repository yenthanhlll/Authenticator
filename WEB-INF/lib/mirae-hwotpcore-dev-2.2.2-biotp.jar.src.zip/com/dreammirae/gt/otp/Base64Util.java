package com.dreammirae.gt.otp;

public class Base64Util {
  private static final char[] a = new char[] { 
      'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
      'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
      'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 
      'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
      'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
      'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
      '8', '9', '+', '/' };
  
  private static final char b = '=';
  
  private static final byte[] c = new byte[128];
  
  private static int a(char[] paramArrayOfchar, byte[] paramArrayOfbyte, int paramInt) {
    byte b = 3;
    if (paramArrayOfchar[3] == '=')
      b = 2; 
    if (paramArrayOfchar[2] == '=')
      b = 1; 
    byte b1 = c[paramArrayOfchar[0]];
    byte b2 = c[paramArrayOfchar[1]];
    byte b3 = c[paramArrayOfchar[2]];
    byte b4 = c[paramArrayOfchar[3]];
    switch (b) {
      case 1:
        paramArrayOfbyte[paramInt] = (byte)(b1 << 2 & 0xFC | b2 >> 4 & 0x3);
        return 1;
      case 2:
        paramArrayOfbyte[paramInt++] = (byte)(b1 << 2 & 0xFC | b2 >> 4 & 0x3);
        paramArrayOfbyte[paramInt] = (byte)(b2 << 4 & 0xF0 | b3 >> 2 & 0xF);
        return 2;
      case 3:
        paramArrayOfbyte[paramInt++] = (byte)(b1 << 2 & 0xFC | b2 >> 4 & 0x3);
        paramArrayOfbyte[paramInt++] = (byte)(b2 << 4 & 0xF0 | b3 >> 2 & 0xF);
        paramArrayOfbyte[paramInt] = (byte)(b3 << 6 & 0xC0 | b4 & 0x3F);
        return 3;
    } 
    throw new RuntimeException("Internal Error");
  }
  
  public static byte[] decode(String paramString) {
    char[] arrayOfChar = new char[4];
    byte b1 = 0;
    byte[] arrayOfByte1 = new byte[paramString.length() / 4 * 3 + 3];
    int i = 0;
    for (byte b2 = 0; b2 < paramString.length(); b2++) {
      char c = paramString.charAt(b2);
      if (c == '=' || (c < c.length && c[c] != Byte.MAX_VALUE)) {
        arrayOfChar[b1++] = c;
        if (b1 == arrayOfChar.length) {
          b1 = 0;
          i += a(arrayOfChar, arrayOfByte1, i);
        } 
      } 
    } 
    if (i == arrayOfByte1.length)
      return arrayOfByte1; 
    byte[] arrayOfByte2 = new byte[i];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
    return arrayOfByte2;
  }
  
  public static String encode(String paramString) {
    return (paramString == null) ? null : encode(paramString.getBytes());
  }
  
  public static String encode(byte[] paramArrayOfbyte) {
    int i = paramArrayOfbyte.length;
    if (i <= 0)
      return ""; 
    char[] arrayOfChar = new char[i / 3 * 4 + 4];
    byte b1 = 0;
    byte b2 = 0;
    int j;
    for (j = i; j >= 3; j -= 3) {
      int k = ((paramArrayOfbyte[b1] & 0xFF) << 16) + ((paramArrayOfbyte[b1 + 1] & 0xFF) << 8) + (paramArrayOfbyte[b1 + 2] & 0xFF);
      arrayOfChar[b2++] = a[k >> 18];
      arrayOfChar[b2++] = a[k >> 12 & 0x3F];
      arrayOfChar[b2++] = a[k >> 6 & 0x3F];
      arrayOfChar[b2++] = a[k & 0x3F];
      b1 += 3;
    } 
    if (j == 1) {
      int k = paramArrayOfbyte[b1] & 0xFF;
      arrayOfChar[b2++] = a[k >> 2];
      arrayOfChar[b2++] = a[k << 4 & 0x3F];
      arrayOfChar[b2++] = '=';
      arrayOfChar[b2++] = '=';
    } else if (j == 2) {
      int k = ((paramArrayOfbyte[b1] & 0xFF) << 8) + (paramArrayOfbyte[b1 + 1] & 0xFF);
      arrayOfChar[b2++] = a[k >> 10];
      arrayOfChar[b2++] = a[k >> 4 & 0x3F];
      arrayOfChar[b2++] = a[k << 2 & 0x3F];
      arrayOfChar[b2++] = '=';
    } 
    return new String(arrayOfChar, 0, b2);
  }
  
  public static boolean isValidBase64Encoding(String paramString) {
    byte b = 0;
    while (b < paramString.length()) {
      char c = paramString.charAt(b);
      if (c == '=' || (c < c.length && c[c] != Byte.MAX_VALUE) || c == '\r' || c == '\n') {
        b++;
        continue;
      } 
      return false;
    } 
    return true;
  }
  
  static {
    byte b;
    for (b = 0; b < c.length; b++)
      c[b] = Byte.MAX_VALUE; 
    for (b = 0; b < a.length; b++)
      c[a[b]] = (byte)b; 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotpcore-dev-2.2.2-biotp.jar!\com\dreammirae\gt\otp\Base64Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */