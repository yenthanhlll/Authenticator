/*      */ package oracle.jdbc.pool;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import javax.sql.ConnectionPoolDataSource;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.ons.ONS;
/*      */ import oracle.ons.ONSException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleConnectionCacheManager
/*      */ {
/*   59 */   private static OracleConnectionCacheManager cacheManagerInstance = null;
/*      */   
/*   61 */   protected Hashtable m_connCache = null;
/*      */ 
/*      */   
/*      */   public static final int REFRESH_INVALID_CONNECTIONS = 4096;
/*      */ 
/*      */   
/*      */   public static final int REFRESH_ALL_CONNECTIONS = 8192;
/*      */ 
/*      */   
/*      */   public static final String PHYSICAL_CONNECTION_CREATED_COUNT = "PhysicalConnectionCreatedCount";
/*      */ 
/*      */   
/*      */   public static final String PHYSICAL_CONNECTION_CLOSED_COUNT = "PhysicalConnectionClosedCount";
/*      */ 
/*      */   
/*      */   protected static final int FAILOVER_EVENT_TYPE_SERVICE = 256;
/*      */ 
/*      */   
/*      */   protected static final int FAILOVER_EVENT_TYPE_HOST = 512;
/*      */   
/*      */   protected static final String EVENT_DELIMITER = "{} =";
/*      */   
/*   83 */   protected OracleFailoverEventHandlerThread failoverEventHandlerThread = null;
/*      */   
/*      */   private static boolean isONSInitializedForRemoteSubscription = false;
/*      */   
/*      */   static final int ORAERROR_END_OF_FILE_ON_COM_CHANNEL = 3113;
/*      */   
/*      */   static final int ORAERROR_NOT_CONNECTED_TO_ORACLE = 3114;
/*      */   
/*      */   static final int ORAERROR_INIT_SHUTDOWN_IN_PROGRESS = 1033;
/*      */   
/*      */   static final int ORAERROR_ORACLE_NOT_AVAILABLE = 1034;
/*      */   
/*      */   static final int ORAERROR_IMMEDIATE_SHUTDOWN_IN_PROGRESS = 1089;
/*      */   
/*      */   static final int ORAERROR_SHUTDOWN_IN_PROGRESS_NO_CONN = 1090;
/*      */   
/*      */   static final int ORAERROR_NET_IO_EXCEPTION = 17002;
/*      */   
/*  101 */   protected int[] fatalErrorCodes = null;
/*  102 */   protected int failoverEnabledCacheCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static AtomicInteger UNNAMED_CACHE_COUNT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OracleConnectionCacheManager() {
/*  114 */     this.m_connCache = new Hashtable<Object, Object>();
/*      */ 
/*      */     
/*  117 */     UNNAMED_CACHE_COUNT = new AtomicInteger();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized OracleConnectionCacheManager getConnectionCacheManagerInstance() throws SQLException {
/*      */     try {
/*  138 */       if (cacheManagerInstance == null) {
/*  139 */         cacheManagerInstance = new OracleConnectionCacheManager();
/*      */       }
/*  141 */     } catch (RuntimeException runtimeException) {}
/*      */ 
/*      */ 
/*      */     
/*  145 */     return cacheManagerInstance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String createCache(OracleDataSource paramOracleDataSource, Properties paramProperties) throws SQLException {
/*  166 */     String str = null;
/*      */     
/*  168 */     if (paramOracleDataSource == null || !paramOracleDataSource.getConnectionCachingEnabled()) {
/*      */ 
/*      */       
/*  171 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
/*  172 */       sQLException.fillInStackTrace();
/*  173 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     if (paramOracleDataSource.connCacheName != null) {
/*      */       
/*  183 */       str = paramOracleDataSource.connCacheName;
/*      */     }
/*      */     else {
/*      */       
/*  187 */       str = paramOracleDataSource.dataSourceName + "#0x" + Integer.toHexString(UNNAMED_CACHE_COUNT.getAndIncrement());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  192 */     createCache(str, paramOracleDataSource, paramProperties);
/*      */     
/*  194 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createCache(String paramString, OracleDataSource paramOracleDataSource, Properties paramProperties) throws SQLException {
/*  216 */     if (paramOracleDataSource == null || !paramOracleDataSource.getConnectionCachingEnabled()) {
/*      */ 
/*      */       
/*  219 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
/*  220 */       sQLException.fillInStackTrace();
/*  221 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  225 */     if (paramString == null) {
/*      */ 
/*      */       
/*  228 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 138);
/*  229 */       sQLException.fillInStackTrace();
/*  230 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  235 */     if (this.m_connCache.containsKey(paramString)) {
/*      */ 
/*      */       
/*  238 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 140);
/*  239 */       sQLException.fillInStackTrace();
/*  240 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  244 */     boolean bool = paramOracleDataSource.getFastConnectionFailoverEnabled();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  252 */     if (bool && this.failoverEventHandlerThread == null) {
/*      */ 
/*      */ 
/*      */       
/*  256 */       final String onsConfigStr = paramOracleDataSource.getONSConfiguration();
/*      */ 
/*      */ 
/*      */       
/*  260 */       if (str != null && !str.equals(""))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  268 */         synchronized (this) {
/*      */           
/*  270 */           if (!isONSInitializedForRemoteSubscription) {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/*  275 */               AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */                   {
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                     public Object run() throws ONSException
/*      */                     {
/*  283 */                       ONS oNS = new ONS(onsConfigStr);
/*  284 */                       return null;
/*      */                     }
/*      */                   });
/*      */             }
/*  288 */             catch (PrivilegedActionException privilegedActionException) {
/*      */ 
/*      */               
/*  291 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 175, privilegedActionException);
/*  292 */               sQLException.fillInStackTrace();
/*  293 */               throw sQLException;
/*      */             } 
/*      */ 
/*      */             
/*  297 */             isONSInitializedForRemoteSubscription = true;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  302 */       this.failoverEventHandlerThread = new OracleFailoverEventHandlerThread();
/*      */     } 
/*      */ 
/*      */     
/*  306 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = new OracleImplicitConnectionCache(paramOracleDataSource, paramProperties);
/*      */ 
/*      */     
/*  309 */     oracleImplicitConnectionCache.cacheName = paramString;
/*  310 */     paramOracleDataSource.odsCache = oracleImplicitConnectionCache;
/*      */ 
/*      */     
/*  313 */     this.m_connCache.put(paramString, oracleImplicitConnectionCache);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     if (bool)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  326 */       checkAndStartThread(this.failoverEventHandlerThread);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeCache(String paramString, long paramLong) throws SQLException {
/*  357 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.remove(paramString) : null;
/*      */ 
/*      */     
/*  360 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  362 */       oracleImplicitConnectionCache.disableConnectionCache();
/*      */ 
/*      */       
/*  365 */       if (paramLong > 0L) {
/*      */         
/*      */         try {
/*      */           
/*  369 */           Thread.currentThread(); Thread.sleep(paramLong * 1000L);
/*      */         }
/*  371 */         catch (InterruptedException interruptedException) {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  378 */       if (oracleImplicitConnectionCache.cacheEnabledDS.getFastConnectionFailoverEnabled()) {
/*  379 */         cleanupFCFThreads(oracleImplicitConnectionCache);
/*      */       }
/*      */       
/*  382 */       oracleImplicitConnectionCache.closeConnectionCache((paramLong < 0L) ? 32 : 1);
/*      */       
/*  384 */       oracleImplicitConnectionCache = null;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  389 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  390 */       sQLException.fillInStackTrace();
/*  391 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reinitializeCache(String paramString, Properties paramProperties) throws SQLException {
/*  412 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  415 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  417 */       disableCache(paramString);
/*  418 */       oracleImplicitConnectionCache.reinitializeCacheConnections(paramProperties);
/*  419 */       enableCache(paramString);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  424 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  425 */       sQLException.fillInStackTrace();
/*  426 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean existsCache(String paramString) throws SQLException {
/*  444 */     return this.m_connCache.containsKey(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableCache(String paramString) throws SQLException {
/*  461 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  464 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  466 */       oracleImplicitConnectionCache.enableConnectionCache();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  471 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  472 */       sQLException.fillInStackTrace();
/*  473 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void disableCache(String paramString) throws SQLException {
/*  492 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  495 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  497 */       oracleImplicitConnectionCache.disableConnectionCache();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  502 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  503 */       sQLException.fillInStackTrace();
/*  504 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshCache(String paramString, int paramInt) throws SQLException {
/*  528 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  531 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  533 */       switch (paramInt) {
/*      */         
/*      */         case 4096:
/*      */         case 8192:
/*  537 */           oracleImplicitConnectionCache.refreshCacheConnections(paramInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*  542 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  543 */       sQLException1.fillInStackTrace();
/*  544 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  551 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  552 */     sQLException.fillInStackTrace();
/*  553 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void purgeCache(String paramString, boolean paramBoolean) throws SQLException {
/*  575 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  578 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  580 */       oracleImplicitConnectionCache.purgeCacheConnections(paramBoolean, 1);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  586 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  587 */       sQLException.fillInStackTrace();
/*  588 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getCacheProperties(String paramString) throws SQLException {
/*  608 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  611 */     if (oracleImplicitConnectionCache != null)
/*      */     {
/*  613 */       return oracleImplicitConnectionCache.getConnectionCacheProperties();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  618 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  619 */     sQLException.fillInStackTrace();
/*  620 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getCacheNameList() throws SQLException {
/*  638 */     return (String[])this.m_connCache.keySet().toArray((Object[])new String[this.m_connCache.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfAvailableConnections(String paramString) throws SQLException {
/*  658 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  661 */     if (oracleImplicitConnectionCache != null)
/*      */     {
/*  663 */       return oracleImplicitConnectionCache.cacheSize;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  668 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  669 */     sQLException.fillInStackTrace();
/*  670 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfActiveConnections(String paramString) throws SQLException {
/*  689 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  692 */     if (oracleImplicitConnectionCache != null)
/*      */     {
/*  694 */       return oracleImplicitConnectionCache.getNumberOfCheckedOutConnections();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  699 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  700 */     sQLException.fillInStackTrace();
/*  701 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnectionPoolDataSource(String paramString, ConnectionPoolDataSource paramConnectionPoolDataSource) throws SQLException {
/*  729 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;
/*      */ 
/*      */     
/*  732 */     if (oracleImplicitConnectionCache != null) {
/*      */       
/*  734 */       if (oracleImplicitConnectionCache.cacheSize > 0) {
/*      */ 
/*      */         
/*  737 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 78);
/*  738 */         sQLException.fillInStackTrace();
/*  739 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  744 */       ((OracleConnectionPoolDataSource)paramConnectionPoolDataSource).makeURL();
/*  745 */       ((OracleConnectionPoolDataSource)paramConnectionPoolDataSource).setURL(((OracleConnectionPoolDataSource)paramConnectionPoolDataSource).url);
/*      */       
/*  747 */       oracleImplicitConnectionCache.connectionPoolDS = (OracleConnectionPoolDataSource)paramConnectionPoolDataSource;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  753 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
/*  754 */       sQLException.fillInStackTrace();
/*  755 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void verifyAndHandleEvent(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  777 */     String str1 = null;
/*  778 */     String str2 = null;
/*  779 */     String str3 = null;
/*  780 */     String str4 = null;
/*  781 */     String str5 = null;
/*      */     
/*  783 */     int i = 0;
/*  784 */     StringTokenizer stringTokenizer = null;
/*      */ 
/*      */     
/*      */     try {
/*  788 */       stringTokenizer = new StringTokenizer(new String(paramArrayOfbyte, "UTF-8"), "{} =", true);
/*      */     }
/*  790 */     catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  795 */     String str6 = null;
/*  796 */     String str7 = null;
/*  797 */     String str8 = null;
/*      */ 
/*      */ 
/*      */     
/*  801 */     while (stringTokenizer.hasMoreTokens()) {
/*      */       
/*  803 */       str7 = null;
/*  804 */       str6 = stringTokenizer.nextToken();
/*  805 */       if (str6.equals("=") && stringTokenizer.hasMoreTokens()) {
/*      */         
/*  807 */         str7 = stringTokenizer.nextToken();
/*      */       }
/*      */       else {
/*      */         
/*  811 */         str8 = str6;
/*      */       } 
/*      */       
/*  814 */       if (str8.equalsIgnoreCase("version") && str7 != null && !str7.equals("1.0")) {
/*      */ 
/*      */ 
/*      */         
/*  818 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 146);
/*  819 */         sQLException.fillInStackTrace();
/*  820 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  824 */       if (str8.equalsIgnoreCase("service") && str7 != null) {
/*  825 */         str1 = str7;
/*      */       }
/*  827 */       if (str8.equalsIgnoreCase("instance") && str7 != null && !str7.equals(" "))
/*      */       {
/*      */         
/*  830 */         str2 = str7.toLowerCase().intern();
/*      */       }
/*      */       
/*  833 */       if (str8.equalsIgnoreCase("database") && str7 != null) {
/*  834 */         str3 = str7.toLowerCase().intern();
/*      */       }
/*  836 */       if (str8.equalsIgnoreCase("host") && str7 != null) {
/*  837 */         str4 = str7.toLowerCase().intern();
/*      */       }
/*  839 */       if (str8.equalsIgnoreCase("status") && str7 != null) {
/*  840 */         str5 = str7;
/*      */       }
/*  842 */       if (str8.equalsIgnoreCase("card") && str7 != null) {
/*      */         
/*      */         try {
/*      */           
/*  846 */           i = Integer.parseInt(str7);
/*      */         }
/*  848 */         catch (NumberFormatException numberFormatException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  855 */     invokeFailoverProcessingThreads(paramInt, str1, str2, str3, str4, str5, i);
/*      */ 
/*      */     
/*  858 */     stringTokenizer = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeFailoverProcessingThreads(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt2) throws SQLException {
/*  875 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = null;
/*  876 */     boolean bool1 = false;
/*  877 */     boolean bool2 = false;
/*      */     
/*  879 */     if (paramInt1 == 256) {
/*  880 */       bool1 = true;
/*      */     }
/*  882 */     if (paramInt1 == 512) {
/*  883 */       bool2 = true;
/*      */     }
/*  885 */     Iterator<OracleImplicitConnectionCache> iterator = this.m_connCache.values().iterator();
/*      */     
/*  887 */     while (iterator.hasNext()) {
/*      */       
/*  889 */       oracleImplicitConnectionCache = iterator.next();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  899 */       if ((bool1 && paramString1.equalsIgnoreCase(oracleImplicitConnectionCache.dataSourceServiceName)) || bool2) {
/*      */ 
/*      */ 
/*      */         
/*  903 */         OracleFailoverWorkerThread oracleFailoverWorkerThread = new OracleFailoverWorkerThread(oracleImplicitConnectionCache, paramInt1, paramString2, paramString3, paramString4, paramString5, paramInt2);
/*      */ 
/*      */ 
/*      */         
/*  907 */         checkAndStartThread(oracleFailoverWorkerThread);
/*      */         
/*  909 */         oracleImplicitConnectionCache.failoverWorkerThread = oracleFailoverWorkerThread;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkAndStartThread(Thread paramThread) throws SQLException {
/*      */     try {
/*  927 */       if (!paramThread.isAlive())
/*      */       {
/*  929 */         paramThread.setDaemon(true);
/*  930 */         paramThread.start();
/*      */       }
/*      */     
/*  933 */     } catch (IllegalThreadStateException illegalThreadStateException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean failoverEnabledCacheExists() {
/*  948 */     if (this.failoverEnabledCacheCount > 0) {
/*  949 */       return true;
/*      */     }
/*  951 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseRuntimeLoadBalancingEvent(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  964 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = null;
/*  965 */     Enumeration<OracleImplicitConnectionCache> enumeration = this.m_connCache.elements();
/*      */     
/*  967 */     while (enumeration.hasMoreElements()) {
/*      */ 
/*      */       
/*      */       try {
/*  971 */         oracleImplicitConnectionCache = enumeration.nextElement();
/*  972 */         if (paramString.equalsIgnoreCase(oracleImplicitConnectionCache.dataSourceServiceName))
/*      */         {
/*  974 */           if (paramArrayOfbyte == null) {
/*  975 */             oracleImplicitConnectionCache.zapRLBInfo(); continue;
/*      */           } 
/*  977 */           retrieveServiceMetrics(oracleImplicitConnectionCache, paramArrayOfbyte);
/*      */         }
/*      */       
/*  980 */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void retrieveServiceMetrics(OracleImplicitConnectionCache paramOracleImplicitConnectionCache, byte[] paramArrayOfbyte) throws SQLException {
/* 1000 */     StringTokenizer stringTokenizer = null;
/* 1001 */     String str1 = null;
/* 1002 */     String str2 = null;
/* 1003 */     int i = 0;
/* 1004 */     byte b = 0;
/* 1005 */     boolean bool = false;
/*      */ 
/*      */     
/*      */     try {
/* 1009 */       stringTokenizer = new StringTokenizer(new String(paramArrayOfbyte, "UTF-8"), "{} =", true);
/*      */     
/*      */     }
/* 1012 */     catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1017 */     String str3 = null;
/* 1018 */     String str4 = null;
/* 1019 */     String str5 = null;
/*      */     
/* 1021 */     while (stringTokenizer.hasMoreTokens()) {
/*      */       
/* 1023 */       str4 = null;
/* 1024 */       str3 = stringTokenizer.nextToken();
/*      */       
/* 1026 */       if (str3.equals("=") && stringTokenizer.hasMoreTokens()) {
/*      */         
/* 1028 */         str4 = stringTokenizer.nextToken();
/*      */       } else {
/* 1030 */         if (str3.equals("}")) {
/*      */ 
/*      */           
/* 1033 */           if (bool) {
/*      */             
/* 1035 */             paramOracleImplicitConnectionCache.updateDatabaseInstance(str2, str1, i, b);
/* 1036 */             bool = false;
/*      */           } 
/*      */           continue;
/*      */         } 
/* 1040 */         if (str3.equals("{") || str3.equals(" ")) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1046 */         str5 = str3;
/* 1047 */         bool = true;
/*      */       } 
/*      */       
/* 1050 */       if (str5.equalsIgnoreCase("version") && str4 != null)
/*      */       {
/* 1052 */         if (!str4.equals("1.0")) {
/*      */ 
/*      */           
/* 1055 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 146);
/* 1056 */           sQLException.fillInStackTrace();
/* 1057 */           throw sQLException;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1062 */       if (str5.equalsIgnoreCase("database") && str4 != null) {
/* 1063 */         str2 = str4.toLowerCase().intern();
/*      */       }
/* 1065 */       if (str5.equalsIgnoreCase("instance") && str4 != null) {
/* 1066 */         str1 = str4.toLowerCase().intern();
/*      */       }
/* 1068 */       if (str5.equalsIgnoreCase("percent") && str4 != null) {
/*      */         
/*      */         try {
/*      */           
/* 1072 */           i = Integer.parseInt(str4);
/* 1073 */           if (i == 0) i = 1;
/*      */         
/* 1075 */         } catch (NumberFormatException numberFormatException) {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1081 */       if (str5.equalsIgnoreCase("flag") && str4 != null) {
/*      */         
/* 1083 */         if (str4.equalsIgnoreCase("good")) {
/* 1084 */           b = 1; continue;
/* 1085 */         }  if (str4.equalsIgnoreCase("violating")) {
/* 1086 */           b = 3; continue;
/* 1087 */         }  if (str4.equalsIgnoreCase("NO_DATA")) {
/* 1088 */           b = 4; continue;
/* 1089 */         }  if (str4.equalsIgnoreCase("UNKNOWN")) {
/* 1090 */           b = 2; continue;
/* 1091 */         }  if (str4.equalsIgnoreCase("BLOCKED")) {
/* 1092 */           b = 5;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1097 */     paramOracleImplicitConnectionCache.processDatabaseInstances();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanupFCFThreads(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
/* 1110 */     cleanupFCFWorkerThread(paramOracleImplicitConnectionCache);
/* 1111 */     paramOracleImplicitConnectionCache.cleanupRLBThreads();
/*      */ 
/*      */     
/* 1114 */     if (this.failoverEnabledCacheCount <= 0) {
/* 1115 */       cleanupFCFEventHandlerThread();
/*      */     }
/*      */     
/* 1118 */     this.failoverEnabledCacheCount--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanupFCFWorkerThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
/* 1133 */     if (paramOracleImplicitConnectionCache.failoverWorkerThread != null) {
/*      */ 
/*      */       
/*      */       try {
/* 1137 */         if (paramOracleImplicitConnectionCache.failoverWorkerThread.isAlive()) {
/* 1138 */           paramOracleImplicitConnectionCache.failoverWorkerThread.join();
/*      */         }
/* 1140 */       } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1145 */       paramOracleImplicitConnectionCache.failoverWorkerThread = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanupFCFEventHandlerThread() throws SQLException {
/* 1163 */     if (this.failoverEventHandlerThread != null) {
/*      */ 
/*      */       
/*      */       try {
/* 1167 */         this.failoverEventHandlerThread.interrupt();
/*      */       }
/* 1169 */       catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1174 */       this.failoverEventHandlerThread = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFatalConnectionError(SQLException paramSQLException) {
/* 1192 */     boolean bool = false;
/* 1193 */     int i = paramSQLException.getErrorCode();
/*      */ 
/*      */     
/* 1196 */     if (i == 3113 || i == 3114 || i == 1033 || i == 1034 || i == 1089 || i == 1090 || i == 17002)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1204 */       bool = true;
/*      */     }
/*      */ 
/*      */     
/* 1208 */     if (!bool && this.fatalErrorCodes != null)
/*      */     {
/* 1210 */       for (byte b = 0; b < this.fatalErrorCodes.length; b++) {
/* 1211 */         if (i == this.fatalErrorCodes[b]) {
/*      */           
/* 1213 */           bool = true;
/*      */           break;
/*      */         } 
/*      */       }  } 
/* 1217 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnectionErrorCodes(int[] paramArrayOfint) throws SQLException {
/* 1232 */     if (paramArrayOfint != null) {
/* 1233 */       this.fatalErrorCodes = paramArrayOfint;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getConnectionErrorCodes() throws SQLException {
/* 1248 */     return this.fatalErrorCodes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getStatistics(String paramString) throws SQLException {
/* 1269 */     Map map = null;
/* 1270 */     OracleImplicitConnectionCache oracleImplicitConnectionCache = null;
/*      */     
/* 1272 */     if (this.m_connCache != null && (oracleImplicitConnectionCache = (OracleImplicitConnectionCache)this.m_connCache.get(paramString)) != null)
/*      */     {
/* 1274 */       map = oracleImplicitConnectionCache.getStatistics();
/*      */     }
/* 1276 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1291 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1296 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\pool\OracleConnectionCacheManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */