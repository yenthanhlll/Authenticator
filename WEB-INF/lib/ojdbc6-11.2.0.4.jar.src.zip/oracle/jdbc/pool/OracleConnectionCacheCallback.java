package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

public interface OracleConnectionCacheCallback {
  boolean handleAbandonedConnection(OracleConnection paramOracleConnection, Object paramObject);
  
  void releaseConnection(OracleConnection paramOracleConnection, Object paramObject);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\pool\OracleConnectionCacheCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */