package oracle.jdbc.pool;

import java.sql.SQLException;
import javax.sql.DataSource;
import javax.sql.PooledConnection;

public interface OracleConnectionCache extends DataSource {
  void reusePooledConnection(PooledConnection paramPooledConnection) throws SQLException;
  
  void closePooledConnection(PooledConnection paramPooledConnection) throws SQLException;
  
  void close() throws SQLException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\pool\OracleConnectionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */