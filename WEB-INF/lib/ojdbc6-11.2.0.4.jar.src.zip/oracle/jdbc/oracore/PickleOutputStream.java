/*    */ package oracle.jdbc.oracore;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PickleOutputStream
/*    */   extends ByteArrayOutputStream
/*    */ {
/*    */   public PickleOutputStream() {}
/*    */   
/*    */   public PickleOutputStream(int paramInt) {
/* 26 */     super(paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized int offset() {
/* 34 */     return this.count;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void overwrite(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) {
/* 43 */     if (paramInt2 < 0 || paramInt2 > paramArrayOfbyte.length || paramInt3 < 0 || paramInt2 + paramInt3 > paramArrayOfbyte.length || paramInt2 + paramInt3 < 0 || paramInt1 + paramInt3 > this.buf.length)
/*    */     {
/*    */       
/* 46 */       throw new IndexOutOfBoundsException();
/*    */     }
/* 48 */     if (paramInt3 == 0) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 53 */     for (byte b = 0; b < paramInt3; b++)
/*    */     {
/* 55 */       this.buf[paramInt1 + b] = paramArrayOfbyte[paramInt2 + b];
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\oracore\PickleOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */