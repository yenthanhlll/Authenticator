/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.INTERVALDS;
/*     */ import oracle.sql.INTERVALYM;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeINTERVAL
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 1394800182554224957L;
/*     */   static final int LDIINTYEARMONTH = 7;
/*     */   static final int LDIINTDAYSECOND = 10;
/*     */   static final int SIZE_INTERVAL_YM = 5;
/*     */   static final int SIZE_INTERVAL_DS = 11;
/*  65 */   byte typeId = 0;
/*  66 */   int scale = 0;
/*  67 */   int precision = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleTypeINTERVAL() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeINTERVAL(OracleConnection paramOracleConnection) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/*  96 */     if (this.typeId == 7)
/*  97 */       return -103; 
/*  98 */     if (this.typeId == 10) {
/*  99 */       return -104;
/*     */     }
/* 101 */     return 1111;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/* 109 */     this.typeId = paramTDSReader.readByte();
/* 110 */     this.precision = paramTDSReader.readByte();
/* 111 */     this.scale = paramTDSReader.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale() throws SQLException {
/* 118 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision() throws SQLException {
/* 125 */     return this.precision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 134 */     this.typeId = paramObjectInputStream.readByte();
/* 135 */     this.precision = paramObjectInputStream.readByte();
/* 136 */     this.scale = paramObjectInputStream.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 144 */     paramObjectOutputStream.writeByte(this.typeId);
/* 145 */     paramObjectOutputStream.writeByte(this.precision);
/* 146 */     paramObjectOutputStream.writeByte(this.scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 154 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 155 */       return null;
/*     */     }
/* 157 */     switch (paramInt) {
/*     */ 
/*     */       
/*     */       case 1:
/* 161 */         if (paramArrayOfbyte.length == 5)
/* 162 */           return new INTERVALYM(paramArrayOfbyte); 
/* 163 */         if (paramArrayOfbyte.length == 11) {
/* 164 */           return new INTERVALDS(paramArrayOfbyte);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 187 */         return null;case 2: if (paramArrayOfbyte.length == 5) return INTERVALYM.toString(paramArrayOfbyte);  if (paramArrayOfbyte.length == 11) return INTERVALDS.toString(paramArrayOfbyte);  return null;
/*     */       case 3:
/*     */         return paramArrayOfbyte;
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*     */     INTERVALYM iNTERVALYM;
/* 202 */     Datum datum = null;
/*     */     
/* 204 */     if (paramObject != null)
/*     */     {
/* 206 */       if (paramObject instanceof INTERVALYM || paramObject instanceof INTERVALDS) {
/*     */         
/* 208 */         datum = (Datum)paramObject;
/* 209 */       } else if (paramObject instanceof String) {
/*     */         
/*     */         try
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 216 */           INTERVALDS iNTERVALDS = new INTERVALDS((String)paramObject);
/*     */         }
/* 218 */         catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException)
/*     */         {
/* 220 */           iNTERVALYM = new INTERVALYM((String)paramObject);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 225 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 226 */         sQLException.fillInStackTrace();
/* 227 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */     
/* 231 */     return (Datum)iNTERVALYM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object unpickle81rec(UnpickleContext paramUnpickleContext, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/* 245 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 246 */     sQLException.fillInStackTrace();
/* 247 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\oracore\OracleTypeINTERVAL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */