/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   static void checkNextByte(InputStream paramInputStream, byte paramByte) throws SQLException {
/*     */     try {
/*  37 */       if (paramInputStream.read() != paramByte)
/*     */       {
/*  39 */         SQLException sQLException = DatabaseError.createSqlException(null, 47, "parseTDS");
/*  40 */         sQLException.fillInStackTrace();
/*  41 */         throw sQLException;
/*     */       }
/*     */     
/*  44 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/*  47 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/*  48 */       sQLException.fillInStackTrace();
/*  49 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] toJavaUnsignedBytes(byte[] paramArrayOfbyte) {
/*  66 */     int[] arrayOfInt = new int[paramArrayOfbyte.length];
/*     */     
/*  68 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*  69 */       arrayOfInt[b] = paramArrayOfbyte[b] & 0xFF;
/*     */     }
/*  71 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] readBytes(InputStream paramInputStream, int paramInt) throws SQLException {
/*  78 */     byte[] arrayOfByte = new byte[paramInt];
/*     */ 
/*     */     
/*     */     try {
/*  82 */       int i = paramInputStream.read(arrayOfByte);
/*     */       
/*  84 */       if (i != paramInt)
/*     */       {
/*  86 */         byte[] arrayOfByte1 = new byte[i];
/*     */         
/*  88 */         System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
/*     */         
/*  90 */         return arrayOfByte1;
/*     */       }
/*     */     
/*  93 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/*  96 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/*  97 */       sQLException.fillInStackTrace();
/*  98 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 102 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeBytes(OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws SQLException {
/*     */     try {
/* 111 */       paramOutputStream.write(paramArrayOfbyte);
/*     */     }
/* 113 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 116 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/* 117 */       sQLException.fillInStackTrace();
/* 118 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void skipBytes(InputStream paramInputStream, int paramInt) throws SQLException {
/*     */     try {
/* 129 */       paramInputStream.skip(paramInt);
/*     */     }
/* 131 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 134 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/* 135 */       sQLException.fillInStackTrace();
/* 136 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long readLong(InputStream paramInputStream) throws SQLException {
/* 145 */     byte[] arrayOfByte = new byte[4];
/*     */ 
/*     */     
/*     */     try {
/* 149 */       paramInputStream.read(arrayOfByte);
/*     */       
/* 151 */       return ((((arrayOfByte[0] & 0xFF) * 256 + (arrayOfByte[1] & 0xFF)) * 256 + (arrayOfByte[2] & 0xFF)) * 256 + (arrayOfByte[3] & 0xFF));
/*     */     
/*     */     }
/* 154 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 157 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/* 158 */       sQLException.fillInStackTrace();
/* 159 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static short readShort(InputStream paramInputStream) throws SQLException {
/* 169 */     byte[] arrayOfByte = new byte[2];
/*     */ 
/*     */     
/*     */     try {
/* 173 */       paramInputStream.read(arrayOfByte);
/*     */       
/* 175 */       return (short)((arrayOfByte[0] & 0xFF) * 256 + (arrayOfByte[1] & 0xFF));
/*     */     }
/* 177 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 180 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/* 181 */       sQLException.fillInStackTrace();
/* 182 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte readByte(InputStream paramInputStream) throws SQLException {
/*     */     try {
/* 194 */       return (byte)paramInputStream.read();
/*     */     }
/* 196 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 199 */       SQLException sQLException = DatabaseError.createSqlException(null, iOException);
/* 200 */       sQLException.fillInStackTrace();
/* 201 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte fdoGetSize(byte[] paramArrayOfbyte, int paramInt) {
/* 214 */     byte b = fdoGetEntry(paramArrayOfbyte, paramInt);
/*     */ 
/*     */     
/* 217 */     return (byte)(b >> 3 & 0x1F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte fdoGetAlign(byte[] paramArrayOfbyte, int paramInt) {
/* 227 */     byte b = fdoGetEntry(paramArrayOfbyte, paramInt);
/*     */ 
/*     */     
/* 230 */     return (byte)(b & 0x7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int ldsRound(int paramInt1, int paramInt2) {
/* 242 */     int i = ldsRoundTable[paramInt2];
/*     */     
/* 244 */     return (paramInt1 >> i) + 1 << i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte fdoGetEntry(byte[] paramArrayOfbyte, int paramInt) {
/* 254 */     short s = getUnsignedByte(paramArrayOfbyte[5]);
/* 255 */     return paramArrayOfbyte[6 + s + paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   private static int[] ldsRoundTable = new int[] { 0, 1, 0, 2, 0, 0, 0, 3, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short getUnsignedByte(byte paramByte) {
/* 269 */     return (short)(paramByte & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] serializeObject(Object paramObject) throws IOException {
/* 276 */     if (paramObject == null) {
/* 277 */       return null;
/*     */     }
/* 279 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 280 */     ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
/*     */     
/* 282 */     objectOutputStream.writeObject(paramObject);
/* 283 */     objectOutputStream.flush();
/*     */     
/* 285 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object deserializeObject(byte[] paramArrayOfbyte) throws IOException, ClassNotFoundException {
/* 293 */     if (paramArrayOfbyte == null) {
/* 294 */       return null;
/*     */     }
/* 296 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/*     */     
/* 298 */     return (new ObjectInputStream(byteArrayInputStream)).readObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printByteArray(byte[] paramArrayOfbyte) {
/* 306 */     System.out.println("DONT CALL THIS -- oracle.jdbc.oracore.Util.printByteArray");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 320 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 347 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\oracore\Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */