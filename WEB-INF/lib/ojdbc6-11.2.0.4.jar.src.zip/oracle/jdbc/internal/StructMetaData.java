package oracle.jdbc.internal;

import oracle.jdbc.StructMetaData;

public interface StructMetaData extends StructMetaData {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\internal\StructMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */