package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleBfile;
import oracle.sql.BFILE;
import oracle.sql.BfileDBAccess;

public interface OracleBfile extends OracleDatumWithConnection, OracleBfile {
  long position(BFILE paramBFILE, long paramLong) throws SQLException;
  
  byte[] getLocator();
  
  void setLocator(byte[] paramArrayOfbyte);
  
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Reader characterStreamValue() throws SQLException;
  
  InputStream asciiStreamValue() throws SQLException;
  
  InputStream binaryStreamValue() throws SQLException;
  
  Object makeJdbcArray(int paramInt);
  
  BfileDBAccess getDBAccess() throws SQLException;
  
  void setLength(long paramLong);
  
  Connection getJavaSqlConnection() throws SQLException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\internal\OracleBfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */