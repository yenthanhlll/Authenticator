package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.OracleResultSet;

public interface OracleResultSet extends OracleResultSet {
  void closeStatementOnClose() throws SQLException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\internal\OracleResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */