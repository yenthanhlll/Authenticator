/*      */ package oracle.jdbc.proxy;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import oracle.jdbc.proxy.annotation.GetCreator;
/*      */ import oracle.jdbc.proxy.annotation.GetDelegate;
/*      */ import oracle.jdbc.proxy.annotation.GetProxy;
/*      */ import oracle.jdbc.proxy.annotation.Methods;
/*      */ import oracle.jdbc.proxy.annotation.OnError;
/*      */ import oracle.jdbc.proxy.annotation.Post;
/*      */ import oracle.jdbc.proxy.annotation.Pre;
/*      */ import oracle.jdbc.proxy.annotation.ProxyFor;
/*      */ import oracle.jdbc.proxy.annotation.ProxyLocale;
/*      */ import oracle.jdbc.proxy.annotation.ProxyResult;
/*      */ import oracle.jdbc.proxy.annotation.ProxyResultPolicy;
/*      */ import oracle.jdbc.proxy.annotation.SetDelegate;
/*      */ import oracle.jdbc.proxy.annotation.Signature;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class AnnotationsRegistry
/*      */ {
/*      */   private static class SyntaxError
/*      */     extends RuntimeException
/*      */   {
/*      */     SyntaxError(String param1String) {
/*   51 */       super(param1String);
/*      */     }
/*      */     
/*   54 */     private static final SyntaxError onlyOneAllowed = new SyntaxError("only one @Pre/@Post/@OnError/@GetDelegate/@SetDelegate/@GetCreator/@GetProxy allowed");
/*      */ 
/*      */     
/*   57 */     private static final SyntaxError onlyOneMethodslessAllowed = new SyntaxError("only one @Methods-less @Pre/@Post/@OnError allowed");
/*      */ 
/*      */     
/*   60 */     private static final SyntaxError wrongMethodsContext = new SyntaxError("wrong context for @Methods");
/*      */ 
/*      */     
/*   63 */     private static final SyntaxError wrongPre = new SyntaxError("wrong @Pre");
/*      */ 
/*      */     
/*   66 */     private static final SyntaxError wrongPost = new SyntaxError("wrong @Post");
/*      */ 
/*      */     
/*   69 */     private static final SyntaxError wrongOnError = new SyntaxError("wrong @OnError");
/*      */ 
/*      */     
/*   72 */     private static final SyntaxError onlyOneOnErrorExceptionTypeAllowed = new SyntaxError("only one @OnError Exception type allowed for a given method");
/*      */ 
/*      */     
/*   75 */     private static final SyntaxError wrongGetCreator = new SyntaxError("wrong @GetCreator");
/*      */ 
/*      */     
/*   78 */     private static final SyntaxError wrongGetCreatorMustBeProtected = new SyntaxError("wrong @GetCreator: must be protected");
/*      */ 
/*      */     
/*   81 */     private static final SyntaxError wrongGetCreatorMustBeAbstract = new SyntaxError("wrong @GetCreator: must be abstract");
/*      */ 
/*      */     
/*   84 */     private static final SyntaxError wrongGetDelegate = new SyntaxError("wrong @GetDelegate");
/*      */ 
/*      */     
/*   87 */     private static final SyntaxError wrongGetDelegateMustBeProtected = new SyntaxError("wrong @GetDelegate: must be protected");
/*      */ 
/*      */     
/*   90 */     private static final SyntaxError wrongGetDelegateMustBeAbstract = new SyntaxError("wrong @GetDelegate: must be abstract");
/*      */ 
/*      */     
/*   93 */     private static final SyntaxError wrongGetProxy = new SyntaxError("wrong @GetProxy");
/*      */ 
/*      */     
/*   96 */     private static final SyntaxError wrongGetProxyMustBeProtected = new SyntaxError("wrong @GetProxy: must be protected");
/*      */ 
/*      */     
/*   99 */     private static final SyntaxError wrongGetProxyMustBeAbstract = new SyntaxError("wrong @GetProxy: must be abstract");
/*      */ 
/*      */     
/*  102 */     private static final SyntaxError wrongSetDelegate = new SyntaxError("wrong @SetDelegate");
/*      */ 
/*      */     
/*  105 */     private static final SyntaxError wrongSetDelegateMustBeProtected = new SyntaxError("wrong @SetDelegate: must be protected");
/*      */ 
/*      */     
/*  108 */     private static final SyntaxError wrongSetDelegateMustBeAbstract = new SyntaxError("wrong @SetDelegate: must be abstract");
/*      */ 
/*      */ 
/*      */     
/*      */     private static SyntaxError mustBeClass(Class param1Class) {
/*  113 */       return new SyntaxError(param1Class.getName() + " must be an abstract or concrete class");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static SyntaxError mustBeIface(Class param1Class) {
/*  119 */       return new SyntaxError(param1Class.getName() + " must be an interface");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static SyntaxError annotationDefinedMoreThanOnce(String param1String) {
/*  125 */       return new SyntaxError(param1String + " is defined more than once for the same method");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static SyntaxError noProxyForClass(Class param1Class) {
/*  131 */       return new SyntaxError("no @ProxyFor for class " + param1Class.getName());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static SyntaxError returnTypeMismatch(Method param1Method1, Method param1Method2) {
/*  138 */       return new SyntaxError("interceptor " + param1Method1.getName() + " and interceptee " + param1Method2.getName() + ": have different return types (" + param1Method1.getReturnType().getName() + " and " + param1Method2.getReturnType().getName() + ")");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   private Map<Class, Value> ifacesToAnnotatedSuperclasses = (Map)new HashMap<Class<?>, Value>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void register(Class... paramVarArgs) {
/*  155 */     for (Class clazz : paramVarArgs) {
/*      */       
/*  157 */       if (clazz.isInterface()) {
/*  158 */         throw SyntaxError.mustBeClass(clazz);
/*      */       }
/*  160 */       Value value = new Value(clazz);
/*      */       
/*  162 */       for (Class clazz1 : value.getIfacesToProxy()) {
/*  163 */         this.ifacesToAnnotatedSuperclasses.put(clazz1, value);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   Value get(Class paramClass) {
/*  169 */     return this.ifacesToAnnotatedSuperclasses.get(paramClass);
/*      */   }
/*      */ 
/*      */   
/*      */   Set<Class> keySet() {
/*  174 */     return this.ifacesToAnnotatedSuperclasses.keySet();
/*      */   }
/*      */ 
/*      */   
/*      */   Collection<Value> values() {
/*  179 */     return this.ifacesToAnnotatedSuperclasses.values();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean containsKey(Object paramObject) {
/*  184 */     return this.ifacesToAnnotatedSuperclasses.containsKey(paramObject);
/*      */   }
/*      */   
/*      */   static class Value {
/*      */     private final Class superclass;
/*      */     
/*      */     static final class Pres extends MethodSpecific<Method> {
/*  191 */       Pres() { super("@Pre"); }
/*  192 */     } static final class VoidPosts extends MethodSpecific<Method> { VoidPosts() { super("Void @Post"); } } static final class ReturningPosts extends MethodSpecific<Method> {
/*  193 */       ReturningPosts() { super("Returning @Post"); }
/*  194 */     } static final class VoidOnErrors extends MethodSpecific<Map<Class, Method>> { VoidOnErrors() { super("Void @OnError"); } } private static class MethodSpecific<T> { static final class Pres extends MethodSpecific<Method> { Pres() { super("@Pre"); } } static final class VoidPosts extends MethodSpecific<Method> { VoidPosts() { super("Void @Post"); } } static final class ReturningPosts extends MethodSpecific<Method> { ReturningPosts() { super("Returning @Post"); } } static final class VoidOnErrors extends MethodSpecific<Map<Class, Method>> { VoidOnErrors() { super("Void @OnError"); } } static final class ReturningOnErrors extends MethodSpecific<Map<Class, Method>> { ReturningOnErrors() {
/*  195 */           super("Returning @OnError");
/*      */         } }
/*  197 */       private final Map<MethodSignature, T> ref = new HashMap<MethodSignature, T>();
/*      */ 
/*      */       
/*      */       private final String annotationType;
/*      */ 
/*      */       
/*      */       private MethodSpecific(String param2String) {
/*  204 */         this.annotationType = param2String;
/*      */       }
/*      */ 
/*      */       
/*      */       void put(MethodSignature param2MethodSignature, T param2T) {
/*  209 */         if (null != this.ref.put(param2MethodSignature, param2T)) {
/*  210 */           throw AnnotationsRegistry.SyntaxError.annotationDefinedMoreThanOnce(this.annotationType);
/*      */         }
/*      */       }
/*      */       
/*      */       T get(MethodSignature param2MethodSignature) {
/*  215 */         return this.ref.get(param2MethodSignature);
/*      */       } }
/*      */ 
/*      */ 
/*      */     
/*      */     static final class ReturningOnErrors
/*      */       extends MethodSpecific<Map<Class, Method>>
/*      */     {
/*      */       ReturningOnErrors() {
/*      */         super("Returning @OnError");
/*      */       }
/*      */     }
/*      */     
/*      */     private static class Rest
/*      */     {
/*      */       private final Method pre;
/*      */       private final Method voidPost;
/*      */       private final Method returningPost;
/*      */       private final Map<Class, Method> voidOnErrorsMap;
/*      */       private final Map<Class, Method> returningOnErrorsMap;
/*      */       
/*      */       Rest(Method param2Method1, Method param2Method2, Method param2Method3, Map<Class, Method> param2Map1, Map<Class, Method> param2Map2) {
/*  237 */         this.pre = param2Method1;
/*  238 */         this.voidPost = param2Method2;
/*  239 */         this.returningPost = param2Method3;
/*  240 */         this.voidOnErrorsMap = param2Map1;
/*  241 */         this.returningOnErrorsMap = param2Map2;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Method getPre() {
/*  249 */         return this.pre;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Map<Class, Method> getReturningOnError() {
/*  257 */         return this.returningOnErrorsMap;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Method getReturningPost() {
/*  265 */         return this.returningPost;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Map<Class, Method> getVoidOnError() {
/*  273 */         return this.voidOnErrorsMap;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Method getVoidPost() {
/*  281 */         return this.voidPost;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  286 */     private final List<Class> ifacesToProxy = (List)new ArrayList<Class<?>>();
/*      */     
/*  288 */     private final MethodSpecific.Pres pres = new MethodSpecific.Pres();
/*  289 */     private final MethodSpecific.VoidPosts voidPosts = new MethodSpecific.VoidPosts();
/*  290 */     private final MethodSpecific.ReturningPosts returningPosts = new MethodSpecific.ReturningPosts();
/*  291 */     private final MethodSpecific.VoidOnErrors voidOnErrors = new MethodSpecific.VoidOnErrors();
/*  292 */     private final MethodSpecific.ReturningOnErrors returningOnErrors = new MethodSpecific.ReturningOnErrors();
/*      */     
/*      */     private final Rest rest;
/*      */     
/*  296 */     private Method methodGetCreator = null;
/*  297 */     private Method methodGetDelegate = null;
/*  298 */     private Method methodGetProxy = null;
/*  299 */     private Method methodSetDelegate = null;
/*      */     private boolean isProxyLocale = false;
/*  301 */     private ProxyResultPolicy proxyResultPolicy = ProxyResultPolicy.CACHE;
/*      */     private Method pre;
/*      */     private Method voidPost;
/*      */     private Method returningPost;
/*      */     private Map<Class, Method> voidOnErrorsMap;
/*      */     private Map<Class, Method> returningOnErrorsMap;
/*      */     
/*      */     Value(Class param1Class) {
/*  309 */       this.pre = null; this.voidPost = null; this.returningPost = null;
/*  310 */       this.voidOnErrorsMap = (Map)new HashMap<Class<?>, Method>(); this.returningOnErrorsMap = (Map)new HashMap<Class<?>, Method>();
/*      */       this.superclass = param1Class;
/*      */       this.rest = parseAnnotations();
/*      */     }
/*      */     
/*      */     private void parseAnnotationTypeProxyResult() {
/*  316 */       if (this.superclass.isAnnotationPresent((Class)ProxyResult.class)) {
/*      */         
/*  318 */         ProxyResult proxyResult = (ProxyResult)this.superclass.getAnnotation(ProxyResult.class);
/*  319 */         this.proxyResultPolicy = proxyResult.value();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void parseAnnotationProxyLocale() {
/*  325 */       if (this.superclass.isAnnotationPresent((Class)ProxyLocale.class)) {
/*  326 */         this.isProxyLocale = true;
/*      */       }
/*      */     }
/*      */     
/*      */     private void parseAnnotationProxyFor() {
/*  331 */       if (this.superclass.isAnnotationPresent((Class)ProxyFor.class)) {
/*      */         
/*  333 */         ProxyFor proxyFor = (ProxyFor)this.superclass.getAnnotation(ProxyFor.class);
/*      */         
/*  335 */         for (Class clazz : proxyFor.value()) {
/*      */           
/*  337 */           if (!clazz.isInterface()) {
/*  338 */             throw AnnotationsRegistry.SyntaxError.mustBeIface(clazz);
/*      */           }
/*  340 */           this.ifacesToProxy.add(clazz);
/*      */         } 
/*      */       } else {
/*      */         
/*  344 */         throw AnnotationsRegistry.SyntaxError.noProxyForClass(this.superclass);
/*      */       } 
/*      */     }
/*  347 */     private static final Class[] listOfMethodOperators = new Class[] { Pre.class, Post.class, OnError.class, GetCreator.class, GetDelegate.class, GetProxy.class, SetDelegate.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void checkIsSingle(Method param1Method, Class param1Class) {
/*  355 */       for (Class<? extends Annotation> clazz : listOfMethodOperators) {
/*  356 */         if (!clazz.equals(param1Class) && 
/*  357 */           param1Method.isAnnotationPresent(clazz))
/*  358 */           throw AnnotationsRegistry.SyntaxError.onlyOneAllowed; 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void parseAnnotationPre(Method param1Method) {
/*  363 */       if (param1Method.isAnnotationPresent((Class)Pre.class)) {
/*      */         
/*  365 */         checkIsSingle(param1Method, Pre.class);
/*      */         
/*  367 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])param1Method.getExceptionTypes()))
/*      */         {
/*      */           
/*  370 */           throw AnnotationsRegistry.SyntaxError.wrongPre;
/*      */         }
/*  372 */         if (!Arrays.deepEquals((Object[])new Class[] { Method.class, Object.class, Object[].class }, (Object[])param1Method.getParameterTypes()))
/*      */         {
/*      */           
/*  375 */           throw AnnotationsRegistry.SyntaxError.wrongPre;
/*      */         }
/*  377 */         if (!void.class.equals(param1Method.getReturnType())) {
/*  378 */           throw AnnotationsRegistry.SyntaxError.wrongPre;
/*      */         }
/*  380 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  381 */           for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*  382 */             this.pres.put(new MethodSignature(signature.name(), signature.args(), null), param1Method);
/*      */           }
/*      */         } else {
/*  385 */           if (null != this.pre) throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed; 
/*  386 */           this.pre = param1Method;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private Class doAutoBoxing(Class param1Class) {
/*  393 */       if (boolean.class.equals(param1Class)) {
/*  394 */         return Boolean.class;
/*      */       }
/*  396 */       if (char.class.equals(param1Class)) {
/*  397 */         return Character.class;
/*      */       }
/*  399 */       if (byte.class.equals(param1Class)) {
/*  400 */         return Byte.class;
/*      */       }
/*  402 */       if (short.class.equals(param1Class)) {
/*  403 */         return Short.class;
/*      */       }
/*  405 */       if (int.class.equals(param1Class)) {
/*  406 */         return Integer.class;
/*      */       }
/*  408 */       if (long.class.equals(param1Class)) {
/*  409 */         return Long.class;
/*      */       }
/*  411 */       if (float.class.equals(param1Class)) {
/*  412 */         return Float.class;
/*      */       }
/*  414 */       if (double.class.equals(param1Class)) {
/*  415 */         return Double.class;
/*      */       }
/*  417 */       return param1Class;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void checkReturnTypesMismatch(MethodSignature param1MethodSignature, Method param1Method) {
/*  430 */       Method method = null;
/*      */       
/*  432 */       Class clazz = doAutoBoxing(param1Method.getReturnType());
/*      */ 
/*      */       
/*  435 */       for (Class clazz1 : getIfacesToProxy()) {
/*      */         
/*      */         try {
/*  438 */           method = clazz1.getDeclaredMethod(param1MethodSignature.getName(), param1MethodSignature.getParameterTypes());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  443 */           Class clazz2 = doAutoBoxing(method.getReturnType());
/*      */ 
/*      */           
/*  446 */           if (void.class.equals(clazz2)) {
/*      */             continue;
/*      */           }
/*  449 */           clazz.asSubclass(clazz2);
/*      */         }
/*  451 */         catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */         
/*      */         }
/*  455 */         catch (ClassCastException classCastException) {
/*      */           
/*  457 */           throw AnnotationsRegistry.SyntaxError.returnTypeMismatch(param1Method, method);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void checkReturnTypesMismatch(Method param1Method) {
/*  472 */       Class clazz = doAutoBoxing(param1Method.getReturnType());
/*      */ 
/*      */       
/*  475 */       for (Class clazz1 : getIfacesToProxy()) {
/*  476 */         for (Method method : clazz1.getDeclaredMethods()) {
/*      */           
/*  478 */           Class clazz2 = doAutoBoxing(method.getReturnType());
/*      */ 
/*      */           
/*  481 */           if (!void.class.equals(clazz2)) {
/*      */             
/*      */             try {
/*      */ 
/*      */               
/*  486 */               clazz2.asSubclass(clazz);
/*      */             }
/*  488 */             catch (ClassCastException classCastException) {
/*      */               
/*  490 */               throw AnnotationsRegistry.SyntaxError.returnTypeMismatch(param1Method, method);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void parseAnnotationPost(Method param1Method) {
/*  499 */       if (param1Method.isAnnotationPresent((Class)Post.class)) {
/*      */         
/*  501 */         checkIsSingle(param1Method, Post.class);
/*      */         
/*  503 */         Class<?> clazz = param1Method.getReturnType();
/*  504 */         Class[] arrayOfClass1 = param1Method.getParameterTypes();
/*  505 */         Class[] arrayOfClass2 = param1Method.getExceptionTypes();
/*      */         
/*  507 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])arrayOfClass2)) {
/*  508 */           throw AnnotationsRegistry.SyntaxError.wrongPost;
/*      */         }
/*  510 */         if (void.class.equals(clazz) && Arrays.deepEquals((Object[])new Class[] { Method.class }, (Object[])arrayOfClass1)) {
/*      */ 
/*      */           
/*  513 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  514 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*  515 */               this.voidPosts.put(new MethodSignature(signature.name(), signature.args(), null), param1Method);
/*      */             }
/*      */           } else {
/*  518 */             if (null != this.voidPost) throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed; 
/*  519 */             this.voidPost = param1Method;
/*      */           }
/*      */         
/*  522 */         } else if (!void.class.equals(clazz) && Arrays.deepEquals((Object[])new Class[] { Method.class, clazz }, (Object[])arrayOfClass1)) {
/*      */ 
/*      */           
/*  525 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  526 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*      */               
/*  528 */               MethodSignature methodSignature = new MethodSignature(signature.name(), signature.args(), null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  534 */               checkReturnTypesMismatch(methodSignature, param1Method);
/*  535 */               this.returningPosts.put(methodSignature, param1Method);
/*      */             } 
/*      */           } else {
/*      */             
/*  539 */             checkReturnTypesMismatch(param1Method);
/*      */             
/*  541 */             if (null != this.returningPost) throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed; 
/*  542 */             this.returningPost = param1Method;
/*      */           } 
/*      */         } else {
/*      */           
/*  546 */           throw AnnotationsRegistry.SyntaxError.wrongPost;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void parseAnnotationOnError(Method param1Method) {
/*  552 */       if (param1Method.isAnnotationPresent((Class)OnError.class)) {
/*      */         
/*  554 */         checkIsSingle(param1Method, OnError.class);
/*      */         
/*  556 */         Class<?> clazz = param1Method.getReturnType();
/*  557 */         Class[] arrayOfClass1 = param1Method.getParameterTypes();
/*  558 */         Class[] arrayOfClass2 = param1Method.getExceptionTypes();
/*      */         
/*  560 */         OnError onError = param1Method.<OnError>getAnnotation(OnError.class);
/*  561 */         Class clazz1 = onError.value();
/*      */         
/*  563 */         if (Arrays.deepEquals((Object[])new Class[] { Method.class, clazz1 }, (Object[])arrayOfClass1) && Arrays.deepEquals((Object[])new Class[] { clazz1 }, (Object[])arrayOfClass2) && void.class.equals(clazz)) {
/*      */ 
/*      */ 
/*      */           
/*  567 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  568 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*      */               
/*  570 */               MethodSignature methodSignature = new MethodSignature(signature.name(), signature.args(), null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  576 */               Map<Class, Method> map = this.voidOnErrors.get(methodSignature);
/*  577 */               if (null == map) {
/*  578 */                 this.voidOnErrors.put(methodSignature, map = (Map)new HashMap<Class<?>, Method>());
/*      */               }
/*  580 */               if (null != map.put(clazz1, param1Method)) {
/*  581 */                 throw AnnotationsRegistry.SyntaxError.onlyOneOnErrorExceptionTypeAllowed;
/*      */               }
/*      */             } 
/*  584 */           } else if (null != this.voidOnErrorsMap.put(clazz1, param1Method)) {
/*  585 */             throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed;
/*      */           } 
/*  587 */         } else if (Arrays.deepEquals((Object[])new Class[] { Method.class, clazz1 }, (Object[])arrayOfClass1) && Arrays.deepEquals((Object[])new Class[] { clazz1 }, (Object[])arrayOfClass2) && !void.class.equals(clazz)) {
/*      */ 
/*      */ 
/*      */           
/*  591 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  592 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*      */               
/*  594 */               MethodSignature methodSignature = new MethodSignature(signature.name(), signature.args(), null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  600 */               checkReturnTypesMismatch(methodSignature, param1Method);
/*      */               
/*  602 */               Map<Class, Method> map = this.returningOnErrors.get(methodSignature);
/*  603 */               if (null == map) {
/*  604 */                 this.returningOnErrors.put(methodSignature, map = (Map)new HashMap<Class<?>, Method>());
/*      */               }
/*  606 */               if (null != map.put(clazz1, param1Method)) {
/*  607 */                 throw AnnotationsRegistry.SyntaxError.onlyOneOnErrorExceptionTypeAllowed;
/*      */               }
/*      */             } 
/*      */           } else {
/*  611 */             checkReturnTypesMismatch(param1Method);
/*      */             
/*  613 */             if (null != this.returningOnErrorsMap.put(clazz1, param1Method)) {
/*  614 */               throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed;
/*      */             }
/*      */           } 
/*      */         } else {
/*  618 */           throw AnnotationsRegistry.SyntaxError.wrongOnError;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void parseAnnotationGetCreator(Method param1Method) {
/*  624 */       if (param1Method.isAnnotationPresent((Class)GetCreator.class)) {
/*      */         
/*  626 */         checkIsSingle(param1Method, GetCreator.class);
/*      */         
/*  628 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  629 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*      */         }
/*  631 */         int i = param1Method.getModifiers();
/*      */         
/*  633 */         if (!Modifier.isProtected(i)) {
/*  634 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreatorMustBeProtected;
/*      */         }
/*  636 */         if (!Modifier.isAbstract(i)) {
/*  637 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreatorMustBeAbstract;
/*      */         }
/*  639 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])param1Method.getParameterTypes())) {
/*  640 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreator;
/*      */         }
/*  642 */         if (!Object.class.equals(param1Method.getReturnType())) {
/*  643 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreator;
/*      */         }
/*  645 */         this.methodGetCreator = param1Method;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void parseAnnotationGetProxy(Method param1Method) {
/*  651 */       if (param1Method.isAnnotationPresent((Class)GetProxy.class)) {
/*      */         
/*  653 */         checkIsSingle(param1Method, GetProxy.class);
/*      */         
/*  655 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  656 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*      */         }
/*  658 */         int i = param1Method.getModifiers();
/*      */         
/*  660 */         if (!Modifier.isProtected(i)) {
/*  661 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxyMustBeProtected;
/*      */         }
/*  663 */         if (!Modifier.isAbstract(i)) {
/*  664 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxyMustBeAbstract;
/*      */         }
/*  666 */         if (!Arrays.deepEquals((Object[])new Class[] { Object.class, Object.class }, (Object[])param1Method.getParameterTypes()))
/*      */         {
/*      */           
/*  669 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxy;
/*      */         }
/*  671 */         if (!Object.class.equals(param1Method.getReturnType())) {
/*  672 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxy;
/*      */         }
/*  674 */         this.methodGetProxy = param1Method;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void parseAnnotationGetDelegate(Method param1Method) {
/*  680 */       if (param1Method.isAnnotationPresent((Class)GetDelegate.class)) {
/*      */         
/*  682 */         checkIsSingle(param1Method, GetDelegate.class);
/*      */         
/*  684 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  685 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*      */         }
/*  687 */         int i = param1Method.getModifiers();
/*      */         
/*  689 */         if (!Modifier.isProtected(i)) {
/*  690 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegateMustBeProtected;
/*      */         }
/*  692 */         if (!Modifier.isAbstract(i)) {
/*  693 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegateMustBeAbstract;
/*      */         }
/*  695 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])param1Method.getParameterTypes())) {
/*  696 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegate;
/*      */         }
/*  698 */         if (void.class.equals(param1Method.getReturnType())) {
/*  699 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegate;
/*      */         }
/*  701 */         this.methodGetDelegate = param1Method;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void parseAnnotationSetDelegate(Method param1Method) {
/*  707 */       if (param1Method.isAnnotationPresent((Class)SetDelegate.class)) {
/*      */         
/*  709 */         checkIsSingle(param1Method, SetDelegate.class);
/*      */         
/*  711 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/*  712 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*      */         }
/*  714 */         int i = param1Method.getModifiers();
/*      */         
/*  716 */         if (!Modifier.isProtected(i)) {
/*  717 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegateMustBeProtected;
/*      */         }
/*  719 */         if (!Modifier.isAbstract(i)) {
/*  720 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegateMustBeAbstract;
/*      */         }
/*  722 */         if (1 != (param1Method.getParameterTypes()).length) {
/*  723 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegate;
/*      */         }
/*  725 */         if (!void.class.equals(param1Method.getReturnType())) {
/*  726 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegate;
/*      */         }
/*  728 */         this.methodSetDelegate = param1Method;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private Rest parseAnnotations() {
/*  734 */       parseAnnotationProxyFor();
/*  735 */       parseAnnotationProxyLocale();
/*  736 */       parseAnnotationTypeProxyResult();
/*      */       
/*  738 */       for (Method method : this.superclass.getDeclaredMethods()) {
/*      */         
/*  740 */         parseAnnotationPre(method);
/*  741 */         parseAnnotationPost(method);
/*  742 */         parseAnnotationOnError(method);
/*  743 */         parseAnnotationGetCreator(method);
/*  744 */         parseAnnotationGetProxy(method);
/*  745 */         parseAnnotationGetDelegate(method);
/*  746 */         parseAnnotationSetDelegate(method);
/*      */       } 
/*      */       
/*  749 */       return new Rest(this.pre, this.voidPost, this.returningPost, this.voidOnErrorsMap, this.returningOnErrorsMap);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean belongsToIfaceToProxy(Class param1Class, MethodSignature param1MethodSignature) {
/*  764 */       for (Class clazz : this.ifacesToProxy) {
/*      */         
/*      */         try {
/*  767 */           param1Class.asSubclass(clazz);
/*      */           
/*  769 */           if (isMethodDeclared(clazz, param1MethodSignature)) {
/*  770 */             return true;
/*      */           }
/*  772 */         } catch (ClassCastException classCastException) {}
/*      */       } 
/*  774 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean isMethodDeclared(Class param1Class, MethodSignature param1MethodSignature) {
/*      */       try {
/*  783 */         if (null != param1Class.getDeclaredMethod(param1MethodSignature.getName(), param1MethodSignature.getParameterTypes()))
/*      */         {
/*      */           
/*  786 */           return true;
/*      */         }
/*  788 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*      */       
/*  790 */       for (Class<?> clazz : param1Class.getInterfaces()) {
/*  791 */         if (isMethodDeclared(clazz, param1MethodSignature))
/*  792 */           return true; 
/*      */       } 
/*  794 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodPre(Class param1Class, MethodSignature param1MethodSignature) {
/*  810 */       Method method = this.pres.get(param1MethodSignature);
/*      */ 
/*      */       
/*  813 */       if (null != method) {
/*  814 */         return method;
/*      */       }
/*  816 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getPre() : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodVoidPost(Class param1Class, MethodSignature param1MethodSignature) {
/*  834 */       Method method = this.voidPosts.get(param1MethodSignature);
/*      */ 
/*      */       
/*  837 */       if (null != method) {
/*  838 */         return method;
/*      */       }
/*  840 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getVoidPost() : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodReturningPost(Class param1Class, MethodSignature param1MethodSignature) {
/*  858 */       Method method = this.returningPosts.get(param1MethodSignature);
/*      */ 
/*      */       
/*  861 */       if (null != method) {
/*  862 */         return method;
/*      */       }
/*  864 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getReturningPost() : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Map<Class, Method> getMapVoidOnError(Class param1Class, MethodSignature param1MethodSignature) {
/*  882 */       Map<Class, Method> map = this.voidOnErrors.get(param1MethodSignature);
/*      */ 
/*      */       
/*  885 */       if (null != map) {
/*  886 */         return map;
/*      */       }
/*  888 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getVoidOnError() : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Map<Class, Method> getMapReturningOnError(Class param1Class, MethodSignature param1MethodSignature) {
/*  906 */       Map<Class, Method> map = this.returningOnErrors.get(param1MethodSignature);
/*      */ 
/*      */       
/*  909 */       if (null != map) {
/*  910 */         return map;
/*      */       }
/*  912 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getReturningOnError() : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodGetCreator() {
/*  922 */       return this.methodGetCreator;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodGetDelegate() {
/*  930 */       return this.methodGetDelegate;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodGetProxy() {
/*  938 */       return this.methodGetProxy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method getMethodSetDelegate() {
/*  946 */       return this.methodSetDelegate;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     List<Class> getIfacesToProxy() {
/*  954 */       return this.ifacesToProxy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Class getSuperclass() {
/*  962 */       return this.superclass;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isProxyLocale() {
/*  970 */       return this.isProxyLocale;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyResultPolicy getProxyResultPolicy() {
/*  979 */       return this.proxyResultPolicy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyResultPolicy getProxyResultPolicy(Method param1Method) {
/*      */       Method method;
/*      */       try {
/*  994 */         method = this.superclass.getDeclaredMethod(param1Method.getName(), param1Method.getParameterTypes());
/*      */       }
/*  996 */       catch (NoSuchMethodException noSuchMethodException) {
/*      */         
/*  998 */         return this.proxyResultPolicy;
/*      */       } 
/*      */       
/* 1001 */       if (method.isAnnotationPresent((Class)ProxyResult.class)) {
/*      */         
/* 1003 */         ProxyResult proxyResult = method.<ProxyResult>getAnnotation(ProxyResult.class);
/* 1004 */         return proxyResult.value();
/*      */       } 
/*      */       
/* 1007 */       return this.proxyResultPolicy;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\AnnotationsRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */