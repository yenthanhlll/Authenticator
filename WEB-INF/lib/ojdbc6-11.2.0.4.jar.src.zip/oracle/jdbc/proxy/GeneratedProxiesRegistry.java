/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GeneratedProxiesRegistry
/*     */ {
/*     */   static class Key
/*     */   {
/*  35 */     private final String PREFIX = "oracle.jdbc.proxy.";
/*  36 */     private final String SUFFIX = "$$$Proxy";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class iface;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class superclass;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Integer hashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*  58 */       if (null == param1Object) {
/*  59 */         return false;
/*     */       }
/*     */       
/*     */       try {
/*  63 */         Key key = (Key)param1Object;
/*  64 */         return (this.iface.equals(key.iface) && this.superclass.equals(key.superclass));
/*     */       }
/*  66 */       catch (ClassCastException classCastException) {
/*     */         
/*  68 */         return false;
/*     */       } 
/*     */     }
/*  71 */     Key(Class param1Class1, Class param1Class2) { this.hashCode = null; this.iface = param1Class1; this.superclass = param1Class2; } Key(String param1String) { this.hashCode = null;
/*     */       this.iface = parseIface(param1String);
/*     */       this.superclass = parseSuperclass(param1String); }
/*     */      public int hashCode() {
/*  75 */       if (null == this.hashCode) {
/*     */         
/*  77 */         this.hashCode = Integer.valueOf(23);
/*  78 */         this.hashCode = Integer.valueOf(HashUtil.hash(this.hashCode.intValue(), this.iface));
/*  79 */         this.hashCode = Integer.valueOf(HashUtil.hash(this.hashCode.intValue(), this.superclass));
/*     */       } 
/*     */       
/*  82 */       return this.hashCode.intValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  87 */       return "oracle.jdbc.proxy." + this.superclass.getName().replace(".", "$1") + "$2" + this.iface.getName().replace(".", "$1") + "$$$Proxy";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Class parseSuperclass(String param1String) {
/*     */       try {
/*  98 */         String str1 = param1String.substring("oracle.jdbc.proxy.".length());
/*  99 */         String str2 = str1.replaceAll("\\$1", ".");
/* 100 */         String str3 = str2.substring(0, str2.indexOf("$2"));
/* 101 */         return Class.forName(str3);
/*     */       }
/* 103 */       catch (ClassNotFoundException classNotFoundException) {
/*     */         
/* 105 */         throw new RuntimeException(classNotFoundException);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Class parseIface(String param1String) {
/*     */       try {
/* 113 */         String str1 = param1String.substring("oracle.jdbc.proxy.".length());
/* 114 */         String str2 = str1.replaceAll("\\$1", ".");
/* 115 */         String str3 = str2.substring(str2.indexOf("$2") + 2, str2.indexOf("$$$Proxy"));
/* 116 */         return Class.forName(str3);
/*     */       }
/* 118 */       catch (ClassNotFoundException classNotFoundException) {
/*     */         
/* 120 */         throw new RuntimeException(classNotFoundException);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class getIface() {
/* 129 */       return this.iface;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class getSuperclass() {
/* 137 */       return this.superclass;
/*     */     }
/*     */ 
/*     */     
/*     */     public String makePathname() {
/* 142 */       return toString().replace(".", "/") + ".class";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Value
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String source;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class clazz;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Constructor constructor;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Value(String param1String1, String param1String2, Class param1Class, Constructor param1Constructor) {
/* 170 */       this.name = param1String1;
/* 171 */       this.source = param1String2;
/* 172 */       this.clazz = param1Class;
/* 173 */       this.constructor = param1Constructor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getName() {
/* 182 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getSource() {
/* 191 */       return this.source;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Class getClazz() {
/* 200 */       return this.clazz;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Constructor getConstructor() {
/* 209 */       return this.constructor;
/*     */     }
/*     */   }
/*     */   
/* 213 */   private Map<Key, Value> registry = Collections.synchronizedMap(new HashMap<Key, Value>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(Class paramClass1, Class paramClass2, Value paramValue) {
/* 223 */     this.registry.put(new Key(paramClass1, paramClass2), paramValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Value get(Class paramClass1, Class paramClass2) {
/* 234 */     return this.registry.get(new Key(paramClass1, paramClass2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 243 */     return this.registry.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<Key> keySet() {
/* 252 */     return this.registry.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<Value> values() {
/* 261 */     return this.registry.values();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\GeneratedProxiesRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */