/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.proxy.annotation.ProxyFor;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.Label;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassGenerator
/*     */ {
/*     */   private final AnnotationsForIface annotationsForIface;
/*     */   private final String proxyName;
/*     */   private final String superclassName;
/*     */   private final String ifaceName;
/*     */   private final String proxyType;
/*     */   private final String ifaceType;
/*     */   final Map<MethodSignature, MethodGenerator> members;
/*     */   
/*     */   static class AnnotationsForIface
/*     */   {
/*     */     private final AnnotationsRegistry registry;
/*     */     private final Class iface;
/*     */     private final AnnotationsRegistry.Value value;
/*     */     
/*     */     AnnotationsForIface(AnnotationsRegistry param1AnnotationsRegistry, Class param1Class, AnnotationsRegistry.Value param1Value) {
/*  80 */       this.registry = param1AnnotationsRegistry;
/*  81 */       this.iface = param1Class;
/*  82 */       this.value = param1Value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AnnotationsRegistry getRegistry() {
/*  90 */       return this.registry;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Class getIface() {
/*  98 */       return this.iface;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AnnotationsRegistry.Value getValue() {
/* 106 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassGenerator(AnnotationsForIface paramAnnotationsForIface, String paramString1, String paramString2, String paramString3, Map<MethodSignature, MethodGenerator> paramMap) {
/* 122 */     this.annotationsForIface = paramAnnotationsForIface;
/* 123 */     this.proxyName = Utils.makeSlashed(paramString1);
/* 124 */     this.proxyType = Utils.makeType(paramString1);
/* 125 */     this.superclassName = Utils.makeSlashed(paramString2);
/* 126 */     this.ifaceName = Utils.makeSlashed(paramString3);
/* 127 */     this.ifaceType = Utils.makeType(paramString3);
/* 128 */     this.members = paramMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getProxyName() {
/* 136 */     return this.proxyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getSuperclassName() {
/* 144 */     return this.superclassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getIfaceName() {
/* 152 */     return this.ifaceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getProxyType() {
/* 160 */     return this.proxyType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getIfaceType() {
/* 168 */     return this.ifaceType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> byte[] generateBytecode(GeneratedProxiesRegistry.Key paramKey, AnnotationsRegistry paramAnnotationsRegistry) {
/* 175 */     Class clazz1 = paramKey.getIface();
/* 176 */     final Class superclass = paramKey.getSuperclass();
/*     */     
/* 178 */     if (!clazz1.isInterface()) {
/* 179 */       new RuntimeException("iface must be interface");
/*     */     }
/* 181 */     if (clazz2.isInterface()) {
/* 182 */       new RuntimeException("sclass must not be interface");
/*     */     }
/* 184 */     HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
/*     */ 
/*     */     
/* 187 */     final HashMap<Object, Object> superclassMethods = new HashMap<Object, Object>();
/*     */ 
/*     */     
/* 190 */     AnnotationsForIface annotationsForIface = new AnnotationsForIface(paramAnnotationsRegistry, clazz1, paramAnnotationsRegistry.get(clazz1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     ClassGenerator classGenerator = new ClassGenerator(annotationsForIface, paramKey.toString(), clazz2.getName(), clazz1.getName(), (Map)hashMap1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     (new Runnable() {
/*     */         public void run() {
/* 206 */           traverse(superclass);
/*     */         }
/*     */         void traverse(Class param1Class) {
/* 209 */           if (null == param1Class) {
/*     */             return;
/*     */           }
/* 212 */           if (!param1Class.isAnnotationPresent((Class)ProxyFor.class)) {
/*     */             return;
/*     */           }
/* 215 */           for (Method method : param1Class.getDeclaredMethods()) {
/* 216 */             superclassMethods.put(new MethodSignature(method), method);
/*     */           }
/* 218 */           traverse(param1Class.getSuperclass());
/*     */         }
/*     */       }).run();
/*     */ 
/*     */     
/* 223 */     for (Method method1 : clazz1.getMethods()) {
/*     */       
/* 225 */       MethodSignature methodSignature = new MethodSignature(method1);
/*     */ 
/*     */       
/* 228 */       Method method2 = (Method)hashMap2.get(methodSignature);
/*     */ 
/*     */       
/* 231 */       hashMap1.put(methodSignature, new MethodGenerator(classGenerator, method1, (null == method2 || Modifier.isAbstract(method2.getModifiers()))));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     ClassWriter classWriter = new ClassWriter(3);
/*     */ 
/*     */     
/* 242 */     classGenerator.generate(classWriter);
/* 243 */     return classWriter.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Class generate(Class<T> paramClass, Class paramClass1, AnnotationsRegistry paramAnnotationsRegistry) {
/* 251 */     GeneratedProxiesRegistry.Key key = new GeneratedProxiesRegistry.Key(paramClass, paramClass1);
/*     */ 
/*     */     
/* 254 */     final byte[] bytecode = generateBytecode(key, paramAnnotationsRegistry);
/*     */ 
/*     */ 
/*     */     
/* 258 */     String str = System.getProperty("oracle.jdbc.proxy.asm.verify");
/* 259 */     if (null != str && 0 == "true".compareToIgnoreCase(str)) {
/*     */ 
/*     */       
/* 262 */       try { Class<?> clazz = Class.forName("org.objectweb.asm.util.CheckClassAdapter");
/*     */ 
/*     */         
/* 265 */         Method method = clazz.getMethod("verify", new Class[] { ClassReader.class, boolean.class, PrintWriter.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 272 */         method.invoke(null, new Object[] { new ClassReader(arrayOfByte), Boolean.valueOf(true), new PrintWriter(new OutputStreamWriter(System.out)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */          }
/*     */       
/* 281 */       catch (ClassNotFoundException classNotFoundException) {  }
/* 282 */       catch (NoSuchMethodException noSuchMethodException) {  }
/* 283 */       catch (IllegalAccessException illegalAccessException) {  }
/* 284 */       catch (InvocationTargetException invocationTargetException) {}
/*     */     }
/*     */     
/*     */     try {
/* 288 */       return Class.forName(key.toString(), false, new ClassLoader()
/*     */           {
/*     */ 
/*     */ 
/*     */             
/*     */             protected Class findClass(String param1String)
/*     */             {
/* 295 */               return defineClass(param1String, bytecode, 0, bytecode.length);
/*     */             }
/*     */           });
/*     */     }
/* 299 */     catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 301 */       throw new RuntimeException(classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void generate(ClassWriter paramClassWriter) {
/* 307 */     paramClassWriter.visit(50, 33, this.proxyName, null, this.superclassName, new String[] { this.ifaceName, Utils.makeSlashed(_Proxy_.class.getName()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     for (MethodGenerator methodGenerator : this.members.values()) {
/* 317 */       if (null != methodGenerator) {
/* 318 */         methodGenerator.generate(paramClassWriter);
/*     */       }
/*     */     } 
/*     */     
/* 322 */     MethodVisitor methodVisitor1 = paramClassWriter.visitMethod(1, "_getDelegate_", "()" + this.ifaceType, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     methodVisitor1.visitCode();
/* 331 */     methodVisitor1.visitVarInsn(25, 0);
/* 332 */     methodVisitor1.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     methodVisitor1.visitInsn(176);
/* 339 */     methodVisitor1.visitMaxs(0, 0);
/* 340 */     methodVisitor1.visitEnd();
/*     */ 
/*     */     
/* 343 */     methodVisitor1 = paramClassWriter.visitMethod(4161, "_getDelegate_", "()Ljava/lang/Object;", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 351 */     methodVisitor1.visitCode();
/* 352 */     methodVisitor1.visitVarInsn(25, 0);
/* 353 */     methodVisitor1.visitMethodInsn(182, this.proxyName, "_getDelegate_", "()" + this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 359 */     methodVisitor1.visitInsn(176);
/* 360 */     methodVisitor1.visitMaxs(0, 0);
/* 361 */     methodVisitor1.visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 366 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 369 */     if (null != value) {
/*     */ 
/*     */       
/* 372 */       Method method1 = value.getMethodGetDelegate();
/*     */ 
/*     */       
/* 375 */       if (null != method1) {
/*     */         
/* 377 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method1.getName(), "()" + Utils.makeType(method1.getReturnType()), null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 384 */         methodVisitor.visitCode();
/* 385 */         Label label1 = new Label();
/* 386 */         methodVisitor.visitLabel(label1);
/* 387 */         methodVisitor.visitVarInsn(25, 0);
/* 388 */         methodVisitor.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/* 389 */         methodVisitor.visitInsn(176);
/* 390 */         Label label2 = new Label();
/* 391 */         methodVisitor.visitLabel(label2);
/* 392 */         methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, 0);
/* 393 */         methodVisitor.visitMaxs(0, 0);
/* 394 */         methodVisitor.visitEnd();
/*     */       } 
/*     */ 
/*     */       
/* 398 */       Method method2 = value.getMethodSetDelegate();
/*     */ 
/*     */       
/* 401 */       if (null != method2) {
/*     */         
/* 403 */         Class[] arrayOfClass = method2.getParameterTypes();
/*     */         
/* 405 */         if (1 != arrayOfClass.length) {
/* 406 */           throw new RuntimeException("wrong delegate setter signature");
/*     */         }
/* 408 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method2.getName(), "(" + Utils.makeType(arrayOfClass[0]) + ")V", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 416 */         methodVisitor.visitCode();
/*     */         Label label1;
/* 418 */         methodVisitor.visitLabel(label1 = new Label());
/*     */         
/* 420 */         methodVisitor.visitVarInsn(25, 0);
/*     */         
/* 422 */         methodVisitor.visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 428 */         methodVisitor.visitVarInsn(25, 0);
/* 429 */         methodVisitor.visitVarInsn(25, 0);
/*     */         
/* 431 */         methodVisitor.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 437 */         methodVisitor.visitVarInsn(25, 1);
/*     */         
/* 439 */         methodVisitor.visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class), "updateDelegate", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 445 */         methodVisitor.visitVarInsn(25, 0);
/* 446 */         methodVisitor.visitVarInsn(25, 1);
/*     */         
/* 448 */         methodVisitor.visitFieldInsn(181, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 454 */         methodVisitor.visitInsn(177);
/*     */         Label label2;
/* 456 */         methodVisitor.visitLabel(label2 = new Label());
/*     */         
/* 458 */         methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 466 */         methodVisitor.visitLocalVariable("delegate", this.ifaceType, null, label1, label2, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 474 */         methodVisitor.visitMaxs(0, 0);
/* 475 */         methodVisitor.visitEnd();
/*     */       } 
/*     */ 
/*     */       
/* 479 */       Method method3 = value.getMethodGetCreator();
/*     */ 
/*     */       
/* 482 */       if (null != method3) {
/*     */         
/* 484 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method3.getName(), "()" + Utils.makeType(method3.getReturnType()), null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 492 */         methodVisitor.visitCode();
/* 493 */         Label label1 = new Label();
/* 494 */         methodVisitor.visitLabel(label1);
/* 495 */         methodVisitor.visitVarInsn(25, 0);
/* 496 */         methodVisitor.visitFieldInsn(180, this.proxyName, "creator", "Ljava/lang/Object;");
/* 497 */         methodVisitor.visitInsn(176);
/* 498 */         Label label2 = new Label();
/* 499 */         methodVisitor.visitLabel(label2);
/* 500 */         methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, 0);
/* 501 */         methodVisitor.visitMaxs(1, 1);
/* 502 */         methodVisitor.visitEnd();
/*     */       } 
/*     */ 
/*     */       
/* 506 */       Method method4 = value.getMethodGetProxy();
/*     */ 
/*     */       
/* 509 */       if (null != method4) {
/*     */         
/* 511 */         Class[] arrayOfClass = method4.getParameterTypes();
/*     */ 
/*     */         
/* 514 */         Class<?> clazz = method4.getReturnType();
/*     */ 
/*     */         
/* 517 */         if (!Arrays.deepEquals((Object[])new Class[] { Object.class, Object.class }, (Object[])arrayOfClass) || !Object.class.equals(clazz))
/*     */         {
/* 519 */           throw new RuntimeException("internal error: wrong @GetProxy method");
/*     */         }
/* 521 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method4.getName(), "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<T:Ljava/lang/Object;>(TT;Ljava/lang/Object;)TT;", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 529 */         methodVisitor.visitCode();
/* 530 */         methodVisitor.visitVarInsn(25, 0);
/*     */         
/* 532 */         methodVisitor.visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 538 */         methodVisitor.visitVarInsn(25, 1);
/* 539 */         methodVisitor.visitVarInsn(25, 2);
/*     */         
/* 541 */         methodVisitor.visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class), "proxyFor", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 547 */         methodVisitor.visitInsn(176);
/* 548 */         methodVisitor.visitMaxs(3, 3);
/* 549 */         methodVisitor.visitEnd();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 555 */     paramClassWriter.visitField(2, "delegate", this.ifaceType, null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 563 */     paramClassWriter.visitField(18, "creator", "Ljava/lang/Object;", null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 571 */     paramClassWriter.visitField(18, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()), null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 579 */     paramClassWriter.visitField(18, "proxyCache", "Ljava/util/Map;", "Ljava/util/Map<Ljava/lang/Object;Ljava/lang/Object;>;", null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 587 */     paramClassWriter.visitField(10, "zeroLengthObjectArray", "[Ljava/lang/Object;", null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 595 */     boolean bool = false;
/* 596 */     for (MethodGenerator methodGenerator : this.members.values()) {
/*     */       
/* 598 */       paramClassWriter.visitField(10, methodGenerator.getMethodObject(), "Ljava/lang/reflect/Method;", null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       bool = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 610 */     MethodVisitor methodVisitor2 = paramClassWriter.visitMethod(8, "<clinit>", "()V", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 618 */     methodVisitor2.visitCode();
/*     */ 
/*     */     
/* 621 */     Utils.loadConst(methodVisitor2, 0);
/* 622 */     methodVisitor2.visitTypeInsn(189, "java/lang/Object");
/* 623 */     methodVisitor2.visitFieldInsn(179, this.proxyName, "zeroLengthObjectArray", "[Ljava/lang/Object;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     if (bool) {
/*     */       Label label1, label2, label3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 636 */       methodVisitor2.visitTryCatchBlock(label1 = new Label(), label2 = new Label(), label3 = new Label(), "java/lang/Throwable");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 642 */       methodVisitor2.visitLabel(label1);
/*     */       
/* 644 */       for (MethodGenerator methodGenerator : this.members.values()) {
/* 645 */         methodGenerator.initializeMethodObject(methodVisitor2);
/*     */       }
/* 647 */       methodVisitor2.visitLabel(label2); Label label4;
/* 648 */       methodVisitor2.visitJumpInsn(167, label4 = new Label());
/* 649 */       methodVisitor2.visitLabel(label3);
/*     */       
/* 651 */       methodVisitor2.visitFrame(4, 0, null, 1, new Object[] { "java/lang/Throwable" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 658 */       methodVisitor2.visitVarInsn(58, 0);
/*     */       
/* 660 */       methodVisitor2.visitTypeInsn(187, "java/lang/RuntimeException");
/* 661 */       methodVisitor2.visitInsn(89);
/* 662 */       methodVisitor2.visitVarInsn(25, 0);
/*     */       
/* 664 */       methodVisitor2.visitMethodInsn(183, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 670 */       methodVisitor2.visitInsn(191);
/*     */       
/* 672 */       methodVisitor2.visitLabel(label4);
/* 673 */       methodVisitor2.visitFrame(3, 0, null, 0, null);
/*     */     } 
/*     */     
/* 676 */     methodVisitor2.visitInsn(177);
/* 677 */     methodVisitor2.visitMaxs(0, 0);
/* 678 */     methodVisitor2.visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 683 */     String str = "(" + this.ifaceType + "Ljava/lang/Object;" + Utils.makeType(ProxyFactory.class.getName()) + "Ljava/util/Map;" + ")V";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 691 */     MethodVisitor methodVisitor3 = paramClassWriter.visitMethod(1, "<init>", str, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 699 */     methodVisitor3.visitCode();
/* 700 */     methodVisitor3.visitVarInsn(25, 0);
/*     */     
/* 702 */     methodVisitor3.visitMethodInsn(183, this.superclassName, "<init>", "()V");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 708 */     methodVisitor3.visitVarInsn(25, 0);
/* 709 */     methodVisitor3.visitVarInsn(25, 1);
/*     */     
/* 711 */     methodVisitor3.visitFieldInsn(181, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 717 */     methodVisitor3.visitVarInsn(25, 0);
/* 718 */     methodVisitor3.visitVarInsn(25, 2);
/*     */     
/* 720 */     methodVisitor3.visitFieldInsn(181, this.proxyName, "creator", "Ljava/lang/Object;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 726 */     methodVisitor3.visitVarInsn(25, 0);
/* 727 */     methodVisitor3.visitVarInsn(25, 3);
/*     */     
/* 729 */     methodVisitor3.visitFieldInsn(181, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 735 */     methodVisitor3.visitVarInsn(25, 0);
/* 736 */     methodVisitor3.visitVarInsn(25, 4);
/*     */     
/* 738 */     methodVisitor3.visitFieldInsn(181, this.proxyName, "proxyCache", "Ljava/util/Map;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 744 */     methodVisitor3.visitInsn(177);
/* 745 */     methodVisitor3.visitMaxs(0, 0);
/* 746 */     methodVisitor3.visitEnd();
/*     */ 
/*     */     
/* 749 */     paramClassWriter.visitEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationsForIface getAnnotationsForIface() {
/* 757 */     return this.annotationsForIface;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\ClassGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */