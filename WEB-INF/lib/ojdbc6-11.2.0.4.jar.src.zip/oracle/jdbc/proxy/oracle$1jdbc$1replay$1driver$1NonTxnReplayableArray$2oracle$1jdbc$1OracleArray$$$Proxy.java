package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy extends NonTxnReplayableArray implements OracleArray, _Proxy_ {
  private OracleArray delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Object[] zeroLengthObjectArray = new Object[0];
  
  private static Method methodObject28230;
  
  private static Method methodObject28207;
  
  private static Method methodObject28224;
  
  private static Method methodObject28221;
  
  private static Method methodObject28214;
  
  private static Method methodObject28223;
  
  private static Method methodObject28212;
  
  private static Method methodObject28216;
  
  private static Method methodObject28219;
  
  private static Method methodObject28208;
  
  private static Method methodObject28222;
  
  private static Method methodObject28211;
  
  private static Method methodObject28231;
  
  private static Method methodObject28226;
  
  private static Method methodObject28213;
  
  private static Method methodObject28209;
  
  private static Method methodObject28220;
  
  private static Method methodObject28227;
  
  private static Method methodObject28218;
  
  private static Method methodObject28225;
  
  private static Method methodObject28217;
  
  private static Method methodObject28215;
  
  private static Method methodObject28210;
  
  private static Method methodObject28229;
  
  private static Method methodObject28228;
  
  public ResultSet getResultSet(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28230, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject28230, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0, arg1), this, (Map)this.proxyCache, methodObject28230));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28230, onErrorForAll(methodObject28230, e));
    } 
  }
  
  public int length() throws SQLException {
    try {
      preForAll(methodObject28207, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28207, Integer.valueOf(this.delegate.length()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28207, onErrorForAll(methodObject28207, e))).intValue();
    } 
  }
  
  public Object getArray(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject28224, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject28224, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject28224));
    } catch (SQLException e) {
      return postForAll(methodObject28224, onErrorForAll(methodObject28224, e));
    } 
  }
  
  public Object getArray() throws SQLException {
    try {
      preForAll(methodObject28221, this, zeroLengthObjectArray);
      return postForAll(methodObject28221, this.proxyFactory.proxyForCache(this.delegate.getArray(), this, (Map)this.proxyCache, methodObject28221));
    } catch (SQLException e) {
      return postForAll(methodObject28221, onErrorForAll(methodObject28221, e));
    } 
  }
  
  public double[] getDoubleArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28214, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (double[])postForAll(methodObject28214, this.delegate.getDoubleArray(arg0, arg1));
    } catch (SQLException e) {
      return (double[])postForAll(methodObject28214, onErrorForAll(methodObject28214, e));
    } 
  }
  
  public Object getArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28223, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject28223, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0, arg1), this, (Map)this.proxyCache, methodObject28223));
    } catch (SQLException e) {
      return postForAll(methodObject28223, onErrorForAll(methodObject28223, e));
    } 
  }
  
  public int[] getIntArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28212, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (int[])postForAll(methodObject28212, this.delegate.getIntArray(arg0, arg1));
    } catch (SQLException e) {
      return (int[])postForAll(methodObject28212, onErrorForAll(methodObject28212, e));
    } 
  }
  
  public short[] getShortArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28216, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (short[])postForAll(methodObject28216, this.delegate.getShortArray(arg0, arg1));
    } catch (SQLException e) {
      return (short[])postForAll(methodObject28216, onErrorForAll(methodObject28216, e));
    } 
  }
  
  public float[] getFloatArray() throws SQLException {
    try {
      preForAll(methodObject28219, this, zeroLengthObjectArray);
      return (float[])postForAll(methodObject28219, this.delegate.getFloatArray());
    } catch (SQLException e) {
      return (float[])postForAll(methodObject28219, onErrorForAll(methodObject28219, e));
    } 
  }
  
  public String getSQLTypeName() throws SQLException {
    try {
      preForAll(methodObject28208, this, zeroLengthObjectArray);
      return (String)postForAll(methodObject28208, this.delegate.getSQLTypeName());
    } catch (SQLException e) {
      return (String)postForAll(methodObject28208, onErrorForAll(methodObject28208, e));
    } 
  }
  
  public Object getArray(Map arg0) throws SQLException {
    try {
      preForAll(methodObject28222, this, new Object[] { arg0 });
      return postForAll(methodObject28222, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0), this, (Map)this.proxyCache, methodObject28222));
    } catch (SQLException e) {
      return postForAll(methodObject28222, onErrorForAll(methodObject28222, e));
    } 
  }
  
  public int[] getIntArray() throws SQLException {
    try {
      preForAll(methodObject28211, this, zeroLengthObjectArray);
      return (int[])postForAll(methodObject28211, this.delegate.getIntArray());
    } catch (SQLException e) {
      return (int[])postForAll(methodObject28211, onErrorForAll(methodObject28211, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject28231, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject28231, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject28231));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28231, onErrorForAll(methodObject28231, e));
    } 
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject28226, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28226, Integer.valueOf(this.delegate.getBaseType()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28226, onErrorForAll(methodObject28226, e))).intValue();
    } 
  }
  
  public double[] getDoubleArray() throws SQLException {
    try {
      preForAll(methodObject28213, this, zeroLengthObjectArray);
      return (double[])postForAll(methodObject28213, this.delegate.getDoubleArray());
    } catch (SQLException e) {
      return (double[])postForAll(methodObject28213, onErrorForAll(methodObject28213, e));
    } 
  }
  
  public Object toJdbc() throws SQLException {
    try {
      preForAll(methodObject28209, this, zeroLengthObjectArray);
      return postForAll(methodObject28209, this.proxyFactory.proxyForCache(this.delegate.toJdbc(), this, (Map)this.proxyCache, methodObject28209));
    } catch (SQLException e) {
      return postForAll(methodObject28209, onErrorForAll(methodObject28209, e));
    } 
  }
  
  public float[] getFloatArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28220, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (float[])postForAll(methodObject28220, this.delegate.getFloatArray(arg0, arg1));
    } catch (SQLException e) {
      return (float[])postForAll(methodObject28220, onErrorForAll(methodObject28220, e));
    } 
  }
  
  public String getBaseTypeName() throws SQLException {
    try {
      preForAll(methodObject28227, this, zeroLengthObjectArray);
      return (String)postForAll(methodObject28227, this.delegate.getBaseTypeName());
    } catch (SQLException e) {
      return (String)postForAll(methodObject28227, onErrorForAll(methodObject28227, e));
    } 
  }
  
  public long[] getLongArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28218, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (long[])postForAll(methodObject28218, this.delegate.getLongArray(arg0, arg1));
    } catch (SQLException e) {
      return (long[])postForAll(methodObject28218, onErrorForAll(methodObject28218, e));
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject28225, this, zeroLengthObjectArray);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28225, e);
      return;
    } 
  }
  
  public long[] getLongArray() throws SQLException {
    try {
      preForAll(methodObject28217, this, zeroLengthObjectArray);
      return (long[])postForAll(methodObject28217, this.delegate.getLongArray());
    } catch (SQLException e) {
      return (long[])postForAll(methodObject28217, onErrorForAll(methodObject28217, e));
    } 
  }
  
  public short[] getShortArray() throws SQLException {
    try {
      preForAll(methodObject28215, this, zeroLengthObjectArray);
      return (short[])postForAll(methodObject28215, this.delegate.getShortArray());
    } catch (SQLException e) {
      return (short[])postForAll(methodObject28215, onErrorForAll(methodObject28215, e));
    } 
  }
  
  public OracleTypeMetaData getOracleMetaData() throws SQLException {
    try {
      preForAll(methodObject28210, this, zeroLengthObjectArray);
      return (OracleTypeMetaData)postForAll(methodObject28210, this.proxyFactory.proxyForCache(this.delegate.getOracleMetaData(), this, (Map)this.proxyCache, methodObject28210));
    } catch (SQLException e) {
      return (OracleTypeMetaData)postForAll(methodObject28210, onErrorForAll(methodObject28210, e));
    } 
  }
  
  public ResultSet getResultSet(Map arg0) throws SQLException {
    try {
      preForAll(methodObject28229, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject28229, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0), this, (Map)this.proxyCache, methodObject28229));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28229, onErrorForAll(methodObject28229, e));
    } 
  }
  
  public ResultSet getResultSet() throws SQLException {
    try {
      preForAll(methodObject28228, this, zeroLengthObjectArray);
      return (ResultSet)postForAll(methodObject28228, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(), this, (Map)this.proxyCache, methodObject28228));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28228, onErrorForAll(methodObject28228, e));
    } 
  }
  
  public OracleArray _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleArray delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject28230 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class });
      methodObject28207 = OracleArray.class.getDeclaredMethod("length", new Class[0]);
      methodObject28224 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class, Map.class });
      methodObject28221 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject28214 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[] { long.class, int.class });
      methodObject28223 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class });
      methodObject28212 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[] { long.class, int.class });
      methodObject28216 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[] { long.class, int.class });
      methodObject28219 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[0]);
      methodObject28208 = OracleArray.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject28222 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject28211 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[0]);
      methodObject28231 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class, Map.class });
      methodObject28226 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject28213 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[0]);
      methodObject28209 = OracleArray.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject28220 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[] { long.class, int.class });
      methodObject28227 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject28218 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[] { long.class, int.class });
      methodObject28225 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject28217 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[0]);
      methodObject28215 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[0]);
      methodObject28210 = OracleArray.class.getDeclaredMethod("getOracleMetaData", new Class[0]);
      methodObject28229 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject28228 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy(OracleArray paramOracleArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */