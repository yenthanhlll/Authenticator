/*    */ package oracle.jdbc.proxy.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ProxyResultPolicy
/*    */ {
/* 23 */   MANUAL,
/* 24 */   CREATE,
/* 25 */   CACHE,
/* 26 */   CREATE_CACHE;
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\annotation\ProxyResultPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */