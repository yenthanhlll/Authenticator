package oracle.jdbc.proxy;

public interface OracleProxy {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\OracleProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */