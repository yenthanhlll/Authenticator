package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.internal.OracleArray;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy extends NonTxnReplayableArray implements OracleArray, _Proxy_ {
  private OracleArray delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Object[] zeroLengthObjectArray = new Object[0];
  
  private static Method methodObject28256;
  
  private static Method methodObject28239;
  
  private static Method methodObject28272;
  
  private static Method methodObject28309;
  
  private static Method methodObject28248;
  
  private static Method methodObject28299;
  
  private static Method methodObject28284;
  
  private static Method methodObject28308;
  
  private static Method methodObject28262;
  
  private static Method methodObject28297;
  
  private static Method methodObject28233;
  
  private static Method methodObject28234;
  
  private static Method methodObject28273;
  
  private static Method methodObject28278;
  
  private static Method methodObject28304;
  
  private static Method methodObject28261;
  
  private static Method methodObject28265;
  
  private static Method methodObject28293;
  
  private static Method methodObject28307;
  
  private static Method methodObject28296;
  
  private static Method methodObject28316;
  
  private static Method methodObject28235;
  
  private static Method methodObject28283;
  
  private static Method methodObject28311;
  
  private static Method methodObject28269;
  
  private static Method methodObject28298;
  
  private static Method methodObject28236;
  
  private static Method methodObject28277;
  
  private static Method methodObject28254;
  
  private static Method methodObject28310;
  
  private static Method methodObject28286;
  
  private static Method methodObject28302;
  
  private static Method methodObject28241;
  
  private static Method methodObject28274;
  
  private static Method methodObject28244;
  
  private static Method methodObject28267;
  
  private static Method methodObject28249;
  
  private static Method methodObject28246;
  
  private static Method methodObject28258;
  
  private static Method methodObject28300;
  
  private static Method methodObject28291;
  
  private static Method methodObject28251;
  
  private static Method methodObject28270;
  
  private static Method methodObject28282;
  
  private static Method methodObject28314;
  
  private static Method methodObject28315;
  
  private static Method methodObject28292;
  
  private static Method methodObject28290;
  
  private static Method methodObject28232;
  
  private static Method methodObject28238;
  
  private static Method methodObject28306;
  
  private static Method methodObject28252;
  
  private static Method methodObject28301;
  
  private static Method methodObject28264;
  
  private static Method methodObject28245;
  
  private static Method methodObject28257;
  
  private static Method methodObject28259;
  
  private static Method methodObject28287;
  
  private static Method methodObject28250;
  
  private static Method methodObject28242;
  
  private static Method methodObject28289;
  
  private static Method methodObject28305;
  
  private static Method methodObject28294;
  
  private static Method methodObject28312;
  
  private static Method methodObject28247;
  
  private static Method methodObject28303;
  
  private static Method methodObject28255;
  
  private static Method methodObject28260;
  
  private static Method methodObject28280;
  
  private static Method methodObject28275;
  
  private static Method methodObject28279;
  
  private static Method methodObject28295;
  
  private static Method methodObject28266;
  
  private static Method methodObject28285;
  
  private static Method methodObject28253;
  
  private static Method methodObject28268;
  
  private static Method methodObject28237;
  
  private static Method methodObject28240;
  
  private static Method methodObject28243;
  
  private static Method methodObject28276;
  
  private static Method methodObject28281;
  
  private static Method methodObject28263;
  
  private static Method methodObject28313;
  
  private static Method methodObject28271;
  
  public void setIndexOffset(long arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject28256, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      this.delegate.setIndexOffset(arg0, arg1);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28256, e);
      return;
    } 
  }
  
  public Datum[] getOracleArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28239, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (Datum[])postForAll(methodObject28239, this.delegate.getOracleArray(arg0, arg1));
    } catch (SQLException e) {
      return (Datum[])postForAll(methodObject28239, onErrorForAll(methodObject28239, e));
    } 
  }
  
  public void setBytes(byte[] arg0) {
    preForAll(methodObject28272, this, new Object[] { arg0 });
    this.delegate.setBytes(arg0);
  }
  
  public Object getArray(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject28309, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject28309, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject28309));
    } catch (SQLException e) {
      return postForAll(methodObject28309, onErrorForAll(methodObject28309, e));
    } 
  }
  
  public boolean isInline() {
    preForAll(methodObject28248, this, zeroLengthObjectArray);
    return ((Boolean)postForAll(methodObject28248, Boolean.valueOf(this.delegate.isInline()))).booleanValue();
  }
  
  public double[] getDoubleArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28299, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (double[])postForAll(methodObject28299, this.delegate.getDoubleArray(arg0, arg1));
    } catch (SQLException e) {
      return (double[])postForAll(methodObject28299, onErrorForAll(methodObject28299, e));
    } 
  }
  
  public Timestamp timestampValue(Calendar arg0) throws SQLException {
    try {
      preForAll(methodObject28284, this, new Object[] { arg0 });
      return (Timestamp)postForAll(methodObject28284, this.delegate.timestampValue(arg0));
    } catch (SQLException e) {
      return (Timestamp)postForAll(methodObject28284, onErrorForAll(methodObject28284, e));
    } 
  }
  
  public Object getArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28308, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject28308, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0, arg1), this, (Map)this.proxyCache, methodObject28308));
    } catch (SQLException e) {
      return postForAll(methodObject28308, onErrorForAll(methodObject28308, e));
    } 
  }
  
  public long getImageLength() {
    preForAll(methodObject28262, this, zeroLengthObjectArray);
    return ((Long)postForAll(methodObject28262, Long.valueOf(this.delegate.getImageLength()))).longValue();
  }
  
  public int[] getIntArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28297, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (int[])postForAll(methodObject28297, this.delegate.getIntArray(arg0, arg1));
    } catch (SQLException e) {
      return (int[])postForAll(methodObject28297, onErrorForAll(methodObject28297, e));
    } 
  }
  
  public void setLength(int arg0) {
    preForAll(methodObject28233, this, new Object[] { Integer.valueOf(arg0) });
    this.delegate.setLength(arg0);
  }
  
  public long getOffset(long arg0) throws SQLException {
    try {
      preForAll(methodObject28234, this, new Object[] { Long.valueOf(arg0) });
      return ((Long)postForAll(methodObject28234, Long.valueOf(this.delegate.getOffset(arg0)))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28234, onErrorForAll(methodObject28234, e))).longValue();
    } 
  }
  
  public Connection getJavaSqlConnection() throws SQLException {
    try {
      preForAll(methodObject28273, this, zeroLengthObjectArray);
      return (Connection)postForAll(methodObject28273, this.proxyFactory.proxyForCache(this.delegate.getJavaSqlConnection(), this, (Map)this.proxyCache, methodObject28273));
    } catch (SQLException e) {
      return (Connection)postForAll(methodObject28273, onErrorForAll(methodObject28273, e));
    } 
  }
  
  public String stringValue(Connection arg0) throws SQLException {
    try {
      preForAll(methodObject28278, this, new Object[] { arg0 });
      return (String)postForAll(methodObject28278, this.delegate.stringValue((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0));
    } catch (SQLException e) {
      return (String)postForAll(methodObject28278, onErrorForAll(methodObject28278, e));
    } 
  }
  
  public float[] getFloatArray() throws SQLException {
    try {
      preForAll(methodObject28304, this, zeroLengthObjectArray);
      return (float[])postForAll(methodObject28304, this.delegate.getFloatArray());
    } catch (SQLException e) {
      return (float[])postForAll(methodObject28304, onErrorForAll(methodObject28304, e));
    } 
  }
  
  public long getImageOffset() {
    preForAll(methodObject28261, this, zeroLengthObjectArray);
    return ((Long)postForAll(methodObject28261, Long.valueOf(this.delegate.getImageOffset()))).longValue();
  }
  
  public boolean booleanValue() throws SQLException {
    try {
      preForAll(methodObject28265, this, zeroLengthObjectArray);
      return ((Boolean)postForAll(methodObject28265, Boolean.valueOf(this.delegate.booleanValue()))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject28265, onErrorForAll(methodObject28265, e))).booleanValue();
    } 
  }
  
  public String getSQLTypeName() throws SQLException {
    try {
      preForAll(methodObject28293, this, zeroLengthObjectArray);
      return (String)postForAll(methodObject28293, this.delegate.getSQLTypeName());
    } catch (SQLException e) {
      return (String)postForAll(methodObject28293, onErrorForAll(methodObject28293, e));
    } 
  }
  
  public Object getArray(Map arg0) throws SQLException {
    try {
      preForAll(methodObject28307, this, new Object[] { arg0 });
      return postForAll(methodObject28307, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0), this, (Map)this.proxyCache, methodObject28307));
    } catch (SQLException e) {
      return postForAll(methodObject28307, onErrorForAll(methodObject28307, e));
    } 
  }
  
  public int[] getIntArray() throws SQLException {
    try {
      preForAll(methodObject28296, this, zeroLengthObjectArray);
      return (int[])postForAll(methodObject28296, this.delegate.getIntArray());
    } catch (SQLException e) {
      return (int[])postForAll(methodObject28296, onErrorForAll(methodObject28296, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject28316, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject28316, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject28316));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28316, onErrorForAll(methodObject28316, e));
    } 
  }
  
  public Map getMap() throws SQLException {
    try {
      preForAll(methodObject28235, this, zeroLengthObjectArray);
      return (Map)postForAll(methodObject28235, this.delegate.getMap());
    } catch (SQLException e) {
      return (Map)postForAll(methodObject28235, onErrorForAll(methodObject28235, e));
    } 
  }
  
  public Timestamp timestampValue() throws SQLException {
    try {
      preForAll(methodObject28283, this, zeroLengthObjectArray);
      return (Timestamp)postForAll(methodObject28283, this.delegate.timestampValue());
    } catch (SQLException e) {
      return (Timestamp)postForAll(methodObject28283, onErrorForAll(methodObject28283, e));
    } 
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject28311, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28311, Integer.valueOf(this.delegate.getBaseType()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28311, onErrorForAll(methodObject28311, e))).intValue();
    } 
  }
  
  public int intValue() throws SQLException {
    try {
      preForAll(methodObject28269, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28269, Integer.valueOf(this.delegate.intValue()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28269, onErrorForAll(methodObject28269, e))).intValue();
    } 
  }
  
  public double[] getDoubleArray() throws SQLException {
    try {
      preForAll(methodObject28298, this, zeroLengthObjectArray);
      return (double[])postForAll(methodObject28298, this.delegate.getDoubleArray());
    } catch (SQLException e) {
      return (double[])postForAll(methodObject28298, onErrorForAll(methodObject28298, e));
    } 
  }
  
  public boolean isConvertibleTo(Class arg0) {
    preForAll(methodObject28236, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject28236, Boolean.valueOf(this.delegate.isConvertibleTo(arg0)))).booleanValue();
  }
  
  public String stringValue() throws SQLException {
    try {
      preForAll(methodObject28277, this, zeroLengthObjectArray);
      return (String)postForAll(methodObject28277, this.delegate.stringValue());
    } catch (SQLException e) {
      return (String)postForAll(methodObject28277, onErrorForAll(methodObject28277, e));
    } 
  }
  
  public int getAccessDirection() throws SQLException {
    try {
      preForAll(methodObject28254, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28254, Integer.valueOf(this.delegate.getAccessDirection()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28254, onErrorForAll(methodObject28254, e))).intValue();
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject28310, this, zeroLengthObjectArray);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28310, e);
      return;
    } 
  }
  
  public InputStream asciiStreamValue() throws SQLException {
    try {
      preForAll(methodObject28286, this, zeroLengthObjectArray);
      return (InputStream)postForAll(methodObject28286, this.delegate.asciiStreamValue());
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject28286, onErrorForAll(methodObject28286, e));
    } 
  }
  
  public long[] getLongArray() throws SQLException {
    try {
      preForAll(methodObject28302, this, zeroLengthObjectArray);
      return (long[])postForAll(methodObject28302, this.delegate.getLongArray());
    } catch (SQLException e) {
      return (long[])postForAll(methodObject28302, onErrorForAll(methodObject28302, e));
    } 
  }
  
  public void setDatumArray(Datum[] arg0) {
    preForAll(methodObject28241, this, new Object[] { arg0 });
    this.delegate.setDatumArray(arg0);
  }
  
  public byte[] shareBytes() {
    preForAll(methodObject28274, this, zeroLengthObjectArray);
    return (byte[])postForAll(methodObject28274, this.delegate.shareBytes());
  }
  
  public void setPrefixSegment(byte[] arg0) {
    preForAll(methodObject28244, this, new Object[] { arg0 });
    this.delegate.setPrefixSegment(arg0);
  }
  
  public double doubleValue() throws SQLException {
    try {
      preForAll(methodObject28267, this, zeroLengthObjectArray);
      return ((Double)postForAll(methodObject28267, Double.valueOf(this.delegate.doubleValue()))).doubleValue();
    } catch (SQLException e) {
      return ((Double)postForAll(methodObject28267, onErrorForAll(methodObject28267, e))).doubleValue();
    } 
  }
  
  public void setAutoBuffering(boolean arg0) throws SQLException {
    try {
      preForAll(methodObject28249, this, new Object[] { Boolean.valueOf(arg0) });
      this.delegate.setAutoBuffering(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28249, e);
      return;
    } 
  }
  
  public byte[] getLocator() {
    preForAll(methodObject28246, this, zeroLengthObjectArray);
    return (byte[])postForAll(methodObject28246, this.delegate.getLocator());
  }
  
  public long getLastOffset() throws SQLException {
    try {
      preForAll(methodObject28258, this, zeroLengthObjectArray);
      return ((Long)postForAll(methodObject28258, Long.valueOf(this.delegate.getLastOffset()))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28258, onErrorForAll(methodObject28258, e))).longValue();
    } 
  }
  
  public short[] getShortArray() throws SQLException {
    try {
      preForAll(methodObject28300, this, zeroLengthObjectArray);
      return (short[])postForAll(methodObject28300, this.delegate.getShortArray());
    } catch (SQLException e) {
      return (short[])postForAll(methodObject28300, onErrorForAll(methodObject28300, e));
    } 
  }
  
  public void setPhysicalConnectionOf(Connection arg0) {
    preForAll(methodObject28291, this, new Object[] { arg0 });
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0);
  }
  
  public void setAutoIndexing(boolean arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28251, this, new Object[] { Boolean.valueOf(arg0), Integer.valueOf(arg1) });
      this.delegate.setAutoIndexing(arg0, arg1);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28251, e);
      return;
    } 
  }
  
  public long longValue() throws SQLException {
    try {
      preForAll(methodObject28270, this, zeroLengthObjectArray);
      return ((Long)postForAll(methodObject28270, Long.valueOf(this.delegate.longValue()))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28270, onErrorForAll(methodObject28270, e))).longValue();
    } 
  }
  
  public Time timeValue(Calendar arg0) throws SQLException {
    try {
      preForAll(methodObject28282, this, new Object[] { arg0 });
      return (Time)postForAll(methodObject28282, this.delegate.timeValue(arg0));
    } catch (SQLException e) {
      return (Time)postForAll(methodObject28282, onErrorForAll(methodObject28282, e));
    } 
  }
  
  public ResultSet getResultSet(Map arg0) throws SQLException {
    try {
      preForAll(methodObject28314, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject28314, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0), this, (Map)this.proxyCache, methodObject28314));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28314, onErrorForAll(methodObject28314, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28315, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject28315, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0, arg1), this, (Map)this.proxyCache, methodObject28315));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28315, onErrorForAll(methodObject28315, e));
    } 
  }
  
  public int length() throws SQLException {
    try {
      preForAll(methodObject28292, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28292, Integer.valueOf(this.delegate.length()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28292, onErrorForAll(methodObject28292, e))).intValue();
    } 
  }
  
  public OracleConnection getInternalConnection() throws SQLException {
    try {
      preForAll(methodObject28290, this, zeroLengthObjectArray);
      return (OracleConnection)postForAll(methodObject28290, this.proxyFactory.proxyForCache(this.delegate.getInternalConnection(), this, (Map)this.proxyCache, methodObject28290));
    } catch (SQLException e) {
      return (OracleConnection)postForAll(methodObject28290, onErrorForAll(methodObject28290, e));
    } 
  }
  
  public ArrayDescriptor getDescriptor() throws SQLException {
    try {
      preForAll(methodObject28232, this, zeroLengthObjectArray);
      return (ArrayDescriptor)postForAll(methodObject28232, this.delegate.getDescriptor());
    } catch (SQLException e) {
      return (ArrayDescriptor)postForAll(methodObject28232, onErrorForAll(methodObject28232, e));
    } 
  }
  
  public Datum[] getOracleArray() throws SQLException {
    try {
      preForAll(methodObject28238, this, zeroLengthObjectArray);
      return (Datum[])postForAll(methodObject28238, this.delegate.getOracleArray());
    } catch (SQLException e) {
      return (Datum[])postForAll(methodObject28238, onErrorForAll(methodObject28238, e));
    } 
  }
  
  public Object getArray() throws SQLException {
    try {
      preForAll(methodObject28306, this, zeroLengthObjectArray);
      return postForAll(methodObject28306, this.proxyFactory.proxyForCache(this.delegate.getArray(), this, (Map)this.proxyCache, methodObject28306));
    } catch (SQLException e) {
      return postForAll(methodObject28306, onErrorForAll(methodObject28306, e));
    } 
  }
  
  public void setAutoIndexing(boolean arg0) throws SQLException {
    try {
      preForAll(methodObject28252, this, new Object[] { Boolean.valueOf(arg0) });
      this.delegate.setAutoIndexing(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28252, e);
      return;
    } 
  }
  
  public short[] getShortArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28301, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (short[])postForAll(methodObject28301, this.delegate.getShortArray(arg0, arg1));
    } catch (SQLException e) {
      return (short[])postForAll(methodObject28301, onErrorForAll(methodObject28301, e));
    } 
  }
  
  public byte[] getBytes() {
    preForAll(methodObject28264, this, zeroLengthObjectArray);
    return (byte[])postForAll(methodObject28264, this.delegate.getBytes());
  }
  
  public void setPrefixFlag(byte arg0) {
    preForAll(methodObject28245, this, new Object[] { Byte.valueOf(arg0) });
    this.delegate.setPrefixFlag(arg0);
  }
  
  public long getLastIndex() throws SQLException {
    try {
      preForAll(methodObject28257, this, zeroLengthObjectArray);
      return ((Long)postForAll(methodObject28257, Long.valueOf(this.delegate.getLastIndex()))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28257, onErrorForAll(methodObject28257, e))).longValue();
    } 
  }
  
  public void setImage(byte[] arg0, long arg1, long arg2) throws SQLException {
    try {
      preForAll(methodObject28259, this, new Object[] { arg0, Long.valueOf(arg1), Long.valueOf(arg2) });
      this.delegate.setImage(arg0, arg1, arg2);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28259, e);
      return;
    } 
  }
  
  public InputStream binaryStreamValue() throws SQLException {
    try {
      preForAll(methodObject28287, this, zeroLengthObjectArray);
      return (InputStream)postForAll(methodObject28287, this.delegate.binaryStreamValue());
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject28287, onErrorForAll(methodObject28287, e));
    } 
  }
  
  public boolean getAutoBuffering() throws SQLException {
    try {
      preForAll(methodObject28250, this, zeroLengthObjectArray);
      return ((Boolean)postForAll(methodObject28250, Boolean.valueOf(this.delegate.getAutoBuffering()))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject28250, onErrorForAll(methodObject28250, e))).booleanValue();
    } 
  }
  
  public void setObjArray(Object arg0) throws SQLException {
    try {
      preForAll(methodObject28242, this, new Object[] { arg0 });
      this.delegate.setObjArray((arg0 instanceof _Proxy_) ? ((_Proxy_)arg0)._getDelegate_() : arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28242, e);
      return;
    } 
  }
  
  public OracleConnection getOracleConnection() throws SQLException {
    try {
      preForAll(methodObject28289, this, zeroLengthObjectArray);
      return (OracleConnection)postForAll(methodObject28289, this.proxyFactory.proxyForCache(this.delegate.getOracleConnection(), this, (Map)this.proxyCache, methodObject28289));
    } catch (SQLException e) {
      return (OracleConnection)postForAll(methodObject28289, onErrorForAll(methodObject28289, e));
    } 
  }
  
  public float[] getFloatArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28305, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (float[])postForAll(methodObject28305, this.delegate.getFloatArray(arg0, arg1));
    } catch (SQLException e) {
      return (float[])postForAll(methodObject28305, onErrorForAll(methodObject28305, e));
    } 
  }
  
  public Object toJdbc() throws SQLException {
    try {
      preForAll(methodObject28294, this, zeroLengthObjectArray);
      return postForAll(methodObject28294, this.proxyFactory.proxyForCache(this.delegate.toJdbc(), this, (Map)this.proxyCache, methodObject28294));
    } catch (SQLException e) {
      return postForAll(methodObject28294, onErrorForAll(methodObject28294, e));
    } 
  }
  
  public String getBaseTypeName() throws SQLException {
    try {
      preForAll(methodObject28312, this, zeroLengthObjectArray);
      return (String)postForAll(methodObject28312, this.delegate.getBaseTypeName());
    } catch (SQLException e) {
      return (String)postForAll(methodObject28312, onErrorForAll(methodObject28312, e));
    } 
  }
  
  public boolean hasDataSeg() {
    preForAll(methodObject28247, this, zeroLengthObjectArray);
    return ((Boolean)postForAll(methodObject28247, Boolean.valueOf(this.delegate.hasDataSeg()))).booleanValue();
  }
  
  public long[] getLongArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28303, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (long[])postForAll(methodObject28303, this.delegate.getLongArray(arg0, arg1));
    } catch (SQLException e) {
      return (long[])postForAll(methodObject28303, onErrorForAll(methodObject28303, e));
    } 
  }
  
  public void setLastIndexOffset(long arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject28255, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      this.delegate.setLastIndexOffset(arg0, arg1);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28255, e);
      return;
    } 
  }
  
  public void setImageLength(long arg0) throws SQLException {
    try {
      preForAll(methodObject28260, this, new Object[] { Long.valueOf(arg0) });
      this.delegate.setImageLength(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28260, e);
      return;
    } 
  }
  
  public Date dateValue() throws SQLException {
    try {
      preForAll(methodObject28280, this, zeroLengthObjectArray);
      return (Date)postForAll(methodObject28280, this.delegate.dateValue());
    } catch (SQLException e) {
      return (Date)postForAll(methodObject28280, onErrorForAll(methodObject28280, e));
    } 
  }
  
  public void setShareBytes(byte[] arg0) {
    preForAll(methodObject28275, this, new Object[] { arg0 });
    this.delegate.setShareBytes(arg0);
  }
  
  public BigDecimal bigDecimalValue() throws SQLException {
    try {
      preForAll(methodObject28279, this, zeroLengthObjectArray);
      return (BigDecimal)postForAll(methodObject28279, this.delegate.bigDecimalValue());
    } catch (SQLException e) {
      return (BigDecimal)postForAll(methodObject28279, onErrorForAll(methodObject28279, e));
    } 
  }
  
  public OracleTypeMetaData getOracleMetaData() throws SQLException {
    try {
      preForAll(methodObject28295, this, zeroLengthObjectArray);
      return (OracleTypeMetaData)postForAll(methodObject28295, this.proxyFactory.proxyForCache(this.delegate.getOracleMetaData(), this, (Map)this.proxyCache, methodObject28295));
    } catch (SQLException e) {
      return (OracleTypeMetaData)postForAll(methodObject28295, onErrorForAll(methodObject28295, e));
    } 
  }
  
  public byte byteValue() throws SQLException {
    try {
      preForAll(methodObject28266, this, zeroLengthObjectArray);
      return ((Byte)postForAll(methodObject28266, Byte.valueOf(this.delegate.byteValue()))).byteValue();
    } catch (SQLException e) {
      return ((Byte)postForAll(methodObject28266, onErrorForAll(methodObject28266, e))).byteValue();
    } 
  }
  
  public Reader characterStreamValue() throws SQLException {
    try {
      preForAll(methodObject28285, this, zeroLengthObjectArray);
      return (Reader)postForAll(methodObject28285, this.delegate.characterStreamValue());
    } catch (SQLException e) {
      return (Reader)postForAll(methodObject28285, onErrorForAll(methodObject28285, e));
    } 
  }
  
  public boolean getAutoIndexing() throws SQLException {
    try {
      preForAll(methodObject28253, this, zeroLengthObjectArray);
      return ((Boolean)postForAll(methodObject28253, Boolean.valueOf(this.delegate.getAutoIndexing()))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject28253, onErrorForAll(methodObject28253, e))).booleanValue();
    } 
  }
  
  public float floatValue() throws SQLException {
    try {
      preForAll(methodObject28268, this, zeroLengthObjectArray);
      return ((Float)postForAll(methodObject28268, Float.valueOf(this.delegate.floatValue()))).floatValue();
    } catch (SQLException e) {
      return ((Float)postForAll(methodObject28268, onErrorForAll(methodObject28268, e))).floatValue();
    } 
  }
  
  public Object makeJdbcArray(int arg0) {
    preForAll(methodObject28237, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject28237, this.proxyFactory.proxyForCache(this.delegate.makeJdbcArray(arg0), this, (Map)this.proxyCache, methodObject28237));
  }
  
  public byte[] toBytes() throws SQLException {
    try {
      preForAll(methodObject28240, this, zeroLengthObjectArray);
      return (byte[])postForAll(methodObject28240, this.delegate.toBytes());
    } catch (SQLException e) {
      return (byte[])postForAll(methodObject28240, onErrorForAll(methodObject28240, e));
    } 
  }
  
  public void setLocator(byte[] arg0) {
    preForAll(methodObject28243, this, new Object[] { arg0 });
    this.delegate.setLocator(arg0);
  }
  
  public InputStream getStream() throws SQLException {
    try {
      preForAll(methodObject28276, this, zeroLengthObjectArray);
      return (InputStream)postForAll(methodObject28276, this.delegate.getStream());
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject28276, onErrorForAll(methodObject28276, e));
    } 
  }
  
  public Time timeValue() throws SQLException {
    try {
      preForAll(methodObject28281, this, zeroLengthObjectArray);
      return (Time)postForAll(methodObject28281, this.delegate.timeValue());
    } catch (SQLException e) {
      return (Time)postForAll(methodObject28281, onErrorForAll(methodObject28281, e));
    } 
  }
  
  public long getLength() {
    preForAll(methodObject28263, this, zeroLengthObjectArray);
    return ((Long)postForAll(methodObject28263, Long.valueOf(this.delegate.getLength()))).longValue();
  }
  
  public ResultSet getResultSet() throws SQLException {
    try {
      preForAll(methodObject28313, this, zeroLengthObjectArray);
      return (ResultSet)postForAll(methodObject28313, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(), this, (Map)this.proxyCache, methodObject28313));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28313, onErrorForAll(methodObject28313, e));
    } 
  }
  
  public OracleConnection getConnection() throws SQLException {
    try {
      preForAll(methodObject28271, this, zeroLengthObjectArray);
      return (OracleConnection)postForAll(methodObject28271, this.delegate.getConnection());
    } catch (SQLException e) {
      return (OracleConnection)postForAll(methodObject28271, onErrorForAll(methodObject28271, e));
    } 
  }
  
  public OracleArray _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleArray delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject28256 = OracleArray.class.getDeclaredMethod("setIndexOffset", new Class[] { long.class, long.class });
      methodObject28239 = OracleArray.class.getDeclaredMethod("getOracleArray", new Class[] { long.class, int.class });
      methodObject28272 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject28309 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class, Map.class });
      methodObject28248 = OracleArray.class.getDeclaredMethod("isInline", new Class[0]);
      methodObject28299 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[] { long.class, int.class });
      methodObject28284 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject28308 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class });
      methodObject28262 = OracleArray.class.getDeclaredMethod("getImageLength", new Class[0]);
      methodObject28297 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[] { long.class, int.class });
      methodObject28233 = OracleArray.class.getDeclaredMethod("setLength", new Class[] { int.class });
      methodObject28234 = OracleArray.class.getDeclaredMethod("getOffset", new Class[] { long.class });
      methodObject28273 = OracleDatumWithConnection.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject28278 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject28304 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[0]);
      methodObject28261 = OracleArray.class.getDeclaredMethod("getImageOffset", new Class[0]);
      methodObject28265 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject28293 = OracleArray.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject28307 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject28296 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[0]);
      methodObject28316 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class, Map.class });
      methodObject28235 = OracleArray.class.getDeclaredMethod("getMap", new Class[0]);
      methodObject28283 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject28311 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject28269 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject28298 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[0]);
      methodObject28236 = OracleArray.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject28277 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject28254 = OracleArray.class.getDeclaredMethod("getAccessDirection", new Class[0]);
      methodObject28310 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject28286 = OracleDatumWithConnection.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject28302 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[0]);
      methodObject28241 = OracleArray.class.getDeclaredMethod("setDatumArray", new Class[] { Datum[].class });
      methodObject28274 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject28244 = OracleArray.class.getDeclaredMethod("setPrefixSegment", new Class[] { byte[].class });
      methodObject28267 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject28249 = OracleArray.class.getDeclaredMethod("setAutoBuffering", new Class[] { boolean.class });
      methodObject28246 = OracleArray.class.getDeclaredMethod("getLocator", new Class[0]);
      methodObject28258 = OracleArray.class.getDeclaredMethod("getLastOffset", new Class[0]);
      methodObject28300 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[0]);
      methodObject28291 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject28251 = OracleArray.class.getDeclaredMethod("setAutoIndexing", new Class[] { boolean.class, int.class });
      methodObject28270 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject28282 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject28314 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject28315 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class });
      methodObject28292 = OracleArray.class.getDeclaredMethod("length", new Class[0]);
      methodObject28290 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject28232 = OracleArray.class.getDeclaredMethod("getDescriptor", new Class[0]);
      methodObject28238 = OracleArray.class.getDeclaredMethod("getOracleArray", new Class[0]);
      methodObject28306 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject28252 = OracleArray.class.getDeclaredMethod("setAutoIndexing", new Class[] { boolean.class });
      methodObject28301 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[] { long.class, int.class });
      methodObject28264 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject28245 = OracleArray.class.getDeclaredMethod("setPrefixFlag", new Class[] { byte.class });
      methodObject28257 = OracleArray.class.getDeclaredMethod("getLastIndex", new Class[0]);
      methodObject28259 = OracleArray.class.getDeclaredMethod("setImage", new Class[] { byte[].class, long.class, long.class });
      methodObject28287 = OracleDatumWithConnection.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject28250 = OracleArray.class.getDeclaredMethod("getAutoBuffering", new Class[0]);
      methodObject28242 = OracleArray.class.getDeclaredMethod("setObjArray", new Class[] { Object.class });
      methodObject28289 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject28305 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[] { long.class, int.class });
      methodObject28294 = OracleArray.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject28312 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject28247 = OracleArray.class.getDeclaredMethod("hasDataSeg", new Class[0]);
      methodObject28303 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[] { long.class, int.class });
      methodObject28255 = OracleArray.class.getDeclaredMethod("setLastIndexOffset", new Class[] { long.class, long.class });
      methodObject28260 = OracleArray.class.getDeclaredMethod("setImageLength", new Class[] { long.class });
      methodObject28280 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject28275 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject28279 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject28295 = OracleArray.class.getDeclaredMethod("getOracleMetaData", new Class[0]);
      methodObject28266 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject28285 = OracleDatumWithConnection.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject28253 = OracleArray.class.getDeclaredMethod("getAutoIndexing", new Class[0]);
      methodObject28268 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject28237 = OracleArray.class.getDeclaredMethod("makeJdbcArray", new Class[] { int.class });
      methodObject28240 = OracleArray.class.getDeclaredMethod("toBytes", new Class[0]);
      methodObject28243 = OracleArray.class.getDeclaredMethod("setLocator", new Class[] { byte[].class });
      methodObject28276 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject28281 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject28263 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject28313 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
      methodObject28271 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy(OracleArray paramOracleArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */