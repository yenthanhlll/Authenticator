/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyFactory
/*     */ {
/*  32 */   final AnnotationsRegistry annotationsRegistry = new AnnotationsRegistry();
/*  33 */   private final GeneratedProxiesRegistry generatedRegistry = new GeneratedProxiesRegistry();
/*  34 */   private Map<Class, Class> delegateClassToProxyClass = Collections.synchronizedMap(new HashMap<Class<?>, Class<?>>());
/*  35 */   private final Map<Object, WeakReference<Object>> delegateToProxy = Collections.synchronizedMap(new WeakIdentityHashMap<Object, WeakReference<Object>>());
/*  36 */   private final Map<Class, Class> delegateToMostSuitableIface = Collections.synchronizedMap(new HashMap<Class<?>, Class<?>>());
/*     */   
/*  38 */   private static final Object STALE_DELEGATE = new Object();
/*     */   
/*  40 */   private static final Class EMPTY_VALUE = EMPTY_CLASS.class;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class EMPTY_CLASS {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProxyFactory createProxyFactory(Class... paramVarArgs) {
/*  51 */     ProxyFactory proxyFactory = new ProxyFactory();
/*  52 */     proxyFactory.annotationsRegistry.register(paramVarArgs);
/*  53 */     return proxyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProxyFactory createJDBCProxyFactory(Class... paramVarArgs) {
/*  67 */     ProxyFactory proxyFactory = new ProxyFactory();
/*  68 */     proxyFactory.annotationsRegistry.register(new Class[] { NullProxy.class });
/*  69 */     proxyFactory.annotationsRegistry.register(paramVarArgs);
/*  70 */     return proxyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isProxied(Class paramClass) {
/*  80 */     return this.annotationsRegistry.containsKey(paramClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyFor(T paramT) {
/*  92 */     return proxyFor(paramT, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyFor(T paramT, Object paramObject) {
/* 106 */     return proxyForCache(paramT, paramObject, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyForCreate(T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap, Method paramMethod) {
/* 139 */     if (null == paramT) {
/* 140 */       return null;
/*     */     }
/* 142 */     Class<?> clazz1 = paramT.getClass();
/* 143 */     Class<?> clazz2 = findMostSuitableIface(clazz1);
/*     */ 
/*     */     
/* 146 */     if (null != paramMethod && null != clazz2 && 
/* 147 */       !paramMethod.getReturnType().isAssignableFrom(clazz2)) {
/* 148 */       return paramT;
/*     */     }
/* 150 */     AnnotationsRegistry.Value value = this.annotationsRegistry.get(clazz2);
/* 151 */     if (null == value) {
/* 152 */       return paramT;
/*     */     }
/* 154 */     if (null == paramMap) {
/* 155 */       paramMap = value.isProxyLocale() ? new WeakIdentityHashMap<Object, WeakReference<Object>>() : this.delegateToProxy;
/*     */     }
/*     */ 
/*     */     
/* 159 */     Class<T> clazz = getProxyClass(clazz2, clazz1);
/* 160 */     if (null == clazz) {
/* 161 */       return createProxy(clazz2, paramT, paramObject, paramMap);
/*     */     }
/*     */     
/*     */     try {
/* 165 */       return clazz.getConstructor(new Class[] { clazz2, Object.class, ProxyFactory.class, Map.class }).newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 172 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 174 */       throw new RuntimeException(noSuchMethodException);
/*     */     }
/* 176 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 178 */       throw new RuntimeException(illegalAccessException);
/*     */     }
/* 180 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 182 */       throw new RuntimeException(invocationTargetException);
/*     */     }
/* 184 */     catch (InstantiationException instantiationException) {
/*     */       
/* 186 */       throw new RuntimeException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyForCache(T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap, Method paramMethod) {
/* 220 */     if (null == paramT) {
/* 221 */       return null;
/*     */     }
/* 223 */     Class<?> clazz1 = paramT.getClass();
/* 224 */     Class<?> clazz2 = findMostSuitableIface(clazz1);
/*     */ 
/*     */     
/* 227 */     if (null != paramMethod && null != clazz2 && 
/* 228 */       !paramMethod.getReturnType().isAssignableFrom(clazz2)) {
/* 229 */       return paramT;
/*     */     }
/* 231 */     AnnotationsRegistry.Value value = this.annotationsRegistry.get(clazz2);
/* 232 */     if (null == value) {
/* 233 */       return paramT;
/*     */     }
/* 235 */     if (null == paramMap) {
/* 236 */       paramMap = value.isProxyLocale() ? new WeakIdentityHashMap<Object, WeakReference<Object>>() : this.delegateToProxy;
/*     */     }
/*     */ 
/*     */     
/* 240 */     WeakReference<Object> weakReference = paramMap.get(paramT);
/* 241 */     if (null != weakReference) {
/*     */       
/* 243 */       T t = (T)weakReference.get();
/* 244 */       if (null != t) {
/*     */         
/* 246 */         if (STALE_DELEGATE == t) {
/* 247 */           throw new RuntimeException("stale delegate");
/*     */         }
/* 249 */         return t;
/*     */       } 
/*     */     } 
/*     */     
/* 253 */     Class<Object> clazz = getProxyClass(clazz2, clazz1);
/* 254 */     if (null == clazz) {
/*     */       
/* 256 */       T t = (T)createProxy(clazz2, (Object)paramT, paramObject, paramMap);
/* 257 */       paramMap.put(paramT, new WeakReference(t));
/* 258 */       return t;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 263 */       T t = (T)clazz.getConstructor(new Class[] { clazz2, Object.class, ProxyFactory.class, Map.class }).newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 270 */       paramMap.put(paramT, new WeakReference(t));
/* 271 */       return t;
/*     */     }
/* 273 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 275 */       throw new RuntimeException(noSuchMethodException);
/*     */     }
/* 277 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 279 */       throw new RuntimeException(illegalAccessException);
/*     */     }
/* 281 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 283 */       throw new RuntimeException(invocationTargetException);
/*     */     }
/* 285 */     catch (InstantiationException instantiationException) {
/*     */       
/* 287 */       throw new RuntimeException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyForCreateCache(T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap, Method paramMethod) {
/* 322 */     if (null == paramT) {
/* 323 */       return null;
/*     */     }
/* 325 */     Class<?> clazz1 = paramT.getClass();
/* 326 */     Class<?> clazz2 = findMostSuitableIface(clazz1);
/*     */ 
/*     */     
/* 329 */     if (null != paramMethod && null != clazz2 && 
/* 330 */       !paramMethod.getReturnType().isAssignableFrom(clazz2)) {
/* 331 */       return paramT;
/*     */     }
/* 333 */     AnnotationsRegistry.Value value = this.annotationsRegistry.get(clazz2);
/* 334 */     if (null == value) {
/* 335 */       return paramT;
/*     */     }
/* 337 */     if (null == paramMap) {
/* 338 */       paramMap = value.isProxyLocale() ? new WeakIdentityHashMap<Object, WeakReference<Object>>() : this.delegateToProxy;
/*     */     }
/*     */ 
/*     */     
/* 342 */     Class<Object> clazz = getProxyClass(clazz2, clazz1);
/* 343 */     if (null == clazz) {
/*     */       
/* 345 */       T t = (T)createProxy(clazz2, (Object)paramT, paramObject, paramMap);
/* 346 */       paramMap.put(paramT, new WeakReference(t));
/* 347 */       return t;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 352 */       T t = (T)clazz.getConstructor(new Class[] { clazz2, Object.class, ProxyFactory.class, Map.class }).newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 359 */       paramMap.put(paramT, new WeakReference(t));
/* 360 */       return t;
/*     */     }
/* 362 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 364 */       throw new RuntimeException(noSuchMethodException);
/*     */     }
/* 366 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 368 */       throw new RuntimeException(illegalAccessException);
/*     */     }
/* 370 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 372 */       throw new RuntimeException(invocationTargetException);
/*     */     }
/* 374 */     catch (InstantiationException instantiationException) {
/*     */       
/* 376 */       throw new RuntimeException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void updateDelegate(Object paramObject, T paramT1, T paramT2) {
/* 399 */     this.delegateToProxy.put(paramT1, new WeakReference(STALE_DELEGATE));
/* 400 */     this.delegateToProxy.put(paramT2, new WeakReference(paramObject));
/*     */   }
/*     */   
/* 403 */   private static final ExtractDelegatePermission EXTRACT_DELEGATE_PERMISSION = new ExtractDelegatePermission();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object extractDelegate(OracleProxy paramOracleProxy) {
/*     */     _Proxy_ _Proxy_;
/* 417 */     SecurityManager securityManager = System.getSecurityManager();
/* 418 */     if (null != securityManager) {
/* 419 */       securityManager.checkPermission(EXTRACT_DELEGATE_PERMISSION);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 425 */       _Proxy_ = (_Proxy_)paramOracleProxy;
/*     */     }
/* 427 */     catch (ClassCastException classCastException) {
/*     */       
/* 429 */       throw new IllegalArgumentException();
/*     */     } 
/*     */     
/* 432 */     return _Proxy_._getDelegate_();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T createProxy(Class paramClass, T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap) {
/* 449 */     if (null == paramClass) {
/* 450 */       return paramT;
/*     */     }
/* 452 */     AnnotationsRegistry.Value value = this.annotationsRegistry.get(paramClass);
/*     */     
/* 454 */     Class clazz = value.getSuperclass();
/*     */     
/* 456 */     GeneratedProxiesRegistry.Value value1 = this.generatedRegistry.get(paramClass, clazz);
/*     */ 
/*     */     
/* 459 */     Constructor<T> constructor = (null == value1) ? prepareProxy(paramClass, clazz) : value1.getConstructor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 466 */       return constructor.newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */     }
/* 468 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 470 */       throw new RuntimeException(invocationTargetException.getTargetException());
/*     */     }
/* 472 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 474 */       throw new RuntimeException(illegalAccessException);
/*     */     }
/* 476 */     catch (InstantiationException instantiationException) {
/*     */       
/* 478 */       throw new RuntimeException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor prepareProxy(Class<?> paramClass1, Class paramClass2) {
/*     */     Constructor<?> constructor;
/* 486 */     Class<?> clazz = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 491 */       clazz = Class.forName((new GeneratedProxiesRegistry.Key(paramClass1, paramClass2)).toString());
/*     */     
/*     */     }
/* 494 */     catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */       
/* 497 */       clazz = ClassGenerator.generate(paramClass1, paramClass2, this.annotationsRegistry);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 507 */       constructor = clazz.getConstructor(new Class[] { paramClass1, Object.class, ProxyFactory.class, Map.class });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 513 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 515 */       throw new RuntimeException(noSuchMethodException);
/*     */     } 
/*     */     
/* 518 */     this.generatedRegistry.put(paramClass1, paramClass2, new GeneratedProxiesRegistry.Value(null, null, clazz, constructor));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 525 */     return constructor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class getProxyClass(Class paramClass1, Class paramClass2) {
/* 532 */     if (null == paramClass2) {
/* 533 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 537 */     Class clazz1 = this.delegateClassToProxyClass.get(paramClass2);
/* 538 */     if (null != clazz1) {
/* 539 */       return (EMPTY_VALUE != clazz1) ? clazz1 : null;
/*     */     }
/*     */     
/* 542 */     if (null == paramClass1) {
/* 543 */       return null;
/*     */     }
/* 545 */     GeneratedProxiesRegistry.Value value = this.generatedRegistry.get(paramClass1, this.annotationsRegistry.get(paramClass1).getSuperclass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 550 */     if (null == value) {
/* 551 */       return null;
/*     */     }
/* 553 */     Class clazz2 = value.getClazz();
/*     */ 
/*     */     
/* 556 */     this.delegateClassToProxyClass.put(paramClass2, (null != clazz2) ? clazz2 : EMPTY_VALUE);
/*     */     
/* 558 */     return clazz2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class findMostSuitableIface(Class paramClass) {
/* 570 */     if (null == paramClass) {
/* 571 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 576 */     Class clazz1 = this.delegateToMostSuitableIface.get(paramClass);
/* 577 */     if (null != clazz1) {
/* 578 */       return (EMPTY_VALUE != clazz1) ? clazz1 : null;
/*     */     }
/*     */     
/* 581 */     int i = -1;
/* 582 */     Class clazz2 = null;
/* 583 */     for (Class clazz : this.annotationsRegistry.keySet()) {
/*     */       
/* 585 */       int j = intersectionCardinality(paramClass, clazz);
/* 586 */       if (j < 1)
/*     */         continue; 
/* 588 */       if (j <= i) {
/*     */         continue;
/*     */       }
/*     */       
/* 592 */       i = j;
/* 593 */       clazz2 = clazz;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 598 */     this.delegateToMostSuitableIface.put(paramClass, (null != clazz2) ? clazz2 : EMPTY_VALUE);
/*     */     
/* 600 */     return clazz2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int intersectionCardinality(Class paramClass1, Class paramClass2) {
/* 607 */     HashSet<Class> hashSet1 = new HashSet();
/*     */ 
/*     */     
/* 610 */     collectIfaces(paramClass2, hashSet1);
/*     */     
/* 612 */     HashSet<Class> hashSet2 = new HashSet();
/*     */ 
/*     */     
/* 615 */     collectIfaces(paramClass1, hashSet2);
/*     */     
/* 617 */     int i = hashSet1.size();
/* 618 */     hashSet1.removeAll(hashSet2);
/*     */     
/* 620 */     if (hashSet1.size() > 0) {
/* 621 */       return -1;
/*     */     }
/* 623 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectIfaces(Class paramClass, Set<Class> paramSet) {
/* 630 */     if (paramClass.isInterface()) {
/* 631 */       paramSet.add(paramClass);
/*     */     }
/* 633 */     for (Class<?> clazz1 : paramClass.getInterfaces()) {
/* 634 */       collectIfaces(clazz1, paramSet);
/*     */     }
/* 636 */     Class clazz = paramClass.getSuperclass();
/* 637 */     if (null != clazz)
/* 638 */       collectIfaces(clazz, paramSet); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\ProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */