package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy extends NonTxnReplayableArray implements Array, _Proxy_ {
  private Array delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Object[] zeroLengthObjectArray = new Object[0];
  
  private static Method methodObject28205;
  
  private static Method methodObject28202;
  
  private static Method methodObject28200;
  
  private static Method methodObject28199;
  
  private static Method methodObject28197;
  
  private static Method methodObject28196;
  
  private static Method methodObject28206;
  
  private static Method methodObject28198;
  
  private static Method methodObject28204;
  
  private static Method methodObject28201;
  
  private static Method methodObject28203;
  
  public ResultSet getResultSet(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28205, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject28205, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0, arg1), this, (Map)this.proxyCache, methodObject28205));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28205, onErrorForAll(methodObject28205, e));
    } 
  }
  
  public String getBaseTypeName() throws SQLException {
    try {
      preForAll(methodObject28202, this, zeroLengthObjectArray);
      return (String)postForAll(methodObject28202, this.delegate.getBaseTypeName());
    } catch (SQLException e) {
      return (String)postForAll(methodObject28202, onErrorForAll(methodObject28202, e));
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject28200, this, zeroLengthObjectArray);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28200, e);
      return;
    } 
  }
  
  public Object getArray(long arg0, int arg1, Map<String, Class<?>> arg2) throws SQLException {
    try {
      preForAll(methodObject28199, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject28199, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject28199));
    } catch (SQLException e) {
      return postForAll(methodObject28199, onErrorForAll(methodObject28199, e));
    } 
  }
  
  public Object getArray(Map<String, Class<?>> arg0) throws SQLException {
    try {
      preForAll(methodObject28197, this, new Object[] { arg0 });
      return postForAll(methodObject28197, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0), this, (Map)this.proxyCache, methodObject28197));
    } catch (SQLException e) {
      return postForAll(methodObject28197, onErrorForAll(methodObject28197, e));
    } 
  }
  
  public Object getArray() throws SQLException {
    try {
      preForAll(methodObject28196, this, zeroLengthObjectArray);
      return postForAll(methodObject28196, this.proxyFactory.proxyForCache(this.delegate.getArray(), this, (Map)this.proxyCache, methodObject28196));
    } catch (SQLException e) {
      return postForAll(methodObject28196, onErrorForAll(methodObject28196, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map<String, Class<?>> arg2) throws SQLException {
    try {
      preForAll(methodObject28206, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject28206, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject28206));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28206, onErrorForAll(methodObject28206, e));
    } 
  }
  
  public Object getArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28198, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject28198, this.proxyFactory.proxyForCache(this.delegate.getArray(arg0, arg1), this, (Map)this.proxyCache, methodObject28198));
    } catch (SQLException e) {
      return postForAll(methodObject28198, onErrorForAll(methodObject28198, e));
    } 
  }
  
  public ResultSet getResultSet(Map<String, Class<?>> arg0) throws SQLException {
    try {
      preForAll(methodObject28204, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject28204, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(arg0), this, (Map)this.proxyCache, methodObject28204));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28204, onErrorForAll(methodObject28204, e));
    } 
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject28201, this, zeroLengthObjectArray);
      return ((Integer)postForAll(methodObject28201, Integer.valueOf(this.delegate.getBaseType()))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28201, onErrorForAll(methodObject28201, e))).intValue();
    } 
  }
  
  public ResultSet getResultSet() throws SQLException {
    try {
      preForAll(methodObject28203, this, zeroLengthObjectArray);
      return (ResultSet)postForAll(methodObject28203, this.proxyFactory.proxyForCreate(this.delegate.getResultSet(), this, (Map)this.proxyCache, methodObject28203));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject28203, onErrorForAll(methodObject28203, e));
    } 
  }
  
  public Array _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(Array delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject28205 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class });
      methodObject28202 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject28200 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject28199 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class, Map.class });
      methodObject28197 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject28196 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject28206 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class, Map.class });
      methodObject28198 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class });
      methodObject28204 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject28201 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject28203 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy(Array paramArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */