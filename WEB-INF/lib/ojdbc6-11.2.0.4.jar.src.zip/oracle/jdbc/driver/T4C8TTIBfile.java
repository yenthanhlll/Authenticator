/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIBfile
/*     */   extends T4C8TTILob
/*     */ {
/*     */   T4C8TTIBfile(T4CConnection paramT4CConnection) {
/* 108 */     super(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 129 */     Object object = null;
/*     */ 
/*     */     
/* 132 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "cannot create a temporary BFILE", -1);
/* 133 */     sQLException.fillInStackTrace();
/* 134 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 154 */     boolean bool = false;
/*     */ 
/*     */     
/* 157 */     bool = _open(paramArrayOfbyte, 11, 256);
/*     */     
/* 159 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 177 */     boolean bool = false;
/*     */     
/* 179 */     bool = _close(paramArrayOfbyte, 512);
/*     */     
/* 181 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 200 */     return _isOpen(paramArrayOfbyte, 1024);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean doesExist(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 221 */     boolean bool = false;
/*     */ 
/*     */     
/* 224 */     initializeLobdef();
/*     */ 
/*     */     
/* 227 */     this.sourceLobLocator = paramArrayOfbyte;
/* 228 */     this.lobops = 2048L;
/* 229 */     this.nullO2U = true;
/*     */     
/* 231 */     doRPC();
/*     */ 
/*     */     
/* 234 */     bool = this.lobnull;
/* 235 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 240 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4C8TTIBfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */