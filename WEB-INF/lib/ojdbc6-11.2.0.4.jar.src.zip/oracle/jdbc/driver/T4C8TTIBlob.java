/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIBlob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   T4C8TTIBlob(T4CConnection paramT4CConnection) {
/* 116 */     super(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 140 */     if (paramInt == 12) {
/*     */       
/* 142 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 143 */       sQLException.fillInStackTrace();
/* 144 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 149 */     BLOB bLOB = null;
/*     */ 
/*     */     
/* 152 */     initializeLobdef();
/*     */ 
/*     */     
/* 155 */     this.lobops = 272L;
/* 156 */     this.sourceLobLocator = new byte[40];
/* 157 */     this.sourceLobLocator[1] = 84;
/*     */ 
/*     */     
/* 160 */     this.characterSet = 1;
/*     */ 
/*     */ 
/*     */     
/* 164 */     this.destinationOffset = 113L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     this.destinationLength = paramInt;
/*     */     
/* 171 */     this.lobamt = paramInt;
/* 172 */     this.sendLobamt = true;
/*     */ 
/*     */     
/* 175 */     this.nullO2U = true;
/*     */     
/* 177 */     if (this.connection.versionNumber >= 9000) {
/*     */       
/* 179 */       this.lobscn = new int[1];
/* 180 */       this.lobscn[0] = paramBoolean ? 1 : 0;
/* 181 */       this.lobscnl = 1;
/*     */     } 
/*     */     
/* 184 */     doRPC();
/*     */ 
/*     */ 
/*     */     
/* 188 */     if (this.sourceLobLocator != null)
/*     */     {
/* 190 */       bLOB = new BLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */     }
/*     */ 
/*     */     
/* 194 */     return (Datum)bLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 212 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 216 */     byte b = 2;
/*     */     
/* 218 */     if (paramInt == 0) {
/* 219 */       b = 1;
/*     */     }
/* 221 */     bool = _open(paramArrayOfbyte, b, 32768);
/*     */     
/* 223 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 241 */     boolean bool = false;
/*     */     
/* 243 */     bool = _close(paramArrayOfbyte, 65536);
/*     */     
/* 245 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 263 */     boolean bool = false;
/*     */     
/* 265 */     bool = _isOpen(paramArrayOfbyte, 69632);
/*     */     
/* 267 */     return bool;
/*     */   }
/*     */ 
/*     */   
/* 271 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4C8TTIBlob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */