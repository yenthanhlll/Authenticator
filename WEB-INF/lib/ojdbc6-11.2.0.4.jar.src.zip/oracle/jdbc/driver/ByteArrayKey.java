/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ByteArrayKey
/*    */ {
/*    */   private byte[] theBytes;
/* 24 */   private int cachedHashCode = -1;
/*    */ 
/*    */   
/*    */   public ByteArrayKey(byte[] paramArrayOfbyte) {
/* 28 */     this.theBytes = paramArrayOfbyte;
/* 29 */     for (byte b : this.theBytes) {
/* 30 */       this.cachedHashCode = this.cachedHashCode << 1 & ((this.cachedHashCode < 0) ? 1 : 0) ^ b;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 35 */     if (paramObject == this) {
/* 36 */       return true;
/*    */     }
/* 38 */     if (!(paramObject instanceof ByteArrayKey))
/*    */     {
/*    */       
/* 41 */       return false;
/*    */     }
/*    */     
/* 44 */     byte[] arrayOfByte = ((ByteArrayKey)paramObject).theBytes;
/*    */     
/* 46 */     if (this.theBytes.length != arrayOfByte.length) {
/* 47 */       return false;
/*    */     }
/* 49 */     for (byte b = 0; b < this.theBytes.length; b++) {
/* 50 */       if (this.theBytes[b] != arrayOfByte[b])
/* 51 */         return false; 
/*    */     } 
/* 53 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return this.cachedHashCode;
/*    */   }
/*    */ 
/*    */   
/* 62 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\ByteArrayKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */