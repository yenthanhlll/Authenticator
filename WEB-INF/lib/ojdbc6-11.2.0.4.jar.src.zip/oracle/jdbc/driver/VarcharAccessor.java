/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.OracleStatement;
/*    */ import oracle.sql.ROWID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VarcharAccessor
/*    */   extends CharCommonAccessor
/*    */ {
/*    */   VarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/* 24 */     char c = 'ྠ';
/*    */     
/* 26 */     if (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
/* 27 */       c = paramOracleStatement.connection.plsqlVarcharParameter4KOnly ? 'ྠ' : '翾';
/*    */     }
/*    */     
/* 30 */     init(paramOracleStatement, 1, 9, paramInt1, paramShort, paramInt2, paramBoolean, c, 2000);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   VarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/* 44 */     char c = 'ྠ';
/*    */     
/* 46 */     if (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
/* 47 */       c = paramOracleStatement.connection.plsqlVarcharParameter4KOnly ? 'ྠ' : '翾';
/*    */     }
/*    */     
/* 50 */     init(paramOracleStatement, 1, 9, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, c, 2000);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ROWID getROWID(int paramInt) throws SQLException {
/* 64 */     if (this.rowSpaceIndicator == null) {
/*    */ 
/*    */ 
/*    */       
/* 68 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 69 */       sQLException.fillInStackTrace();
/* 70 */       throw sQLException;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 75 */     ROWID rOWID = null;
/*    */     
/* 77 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*    */       
/* 79 */       byte[] arrayOfByte = getBytesInternal(paramInt);
/* 80 */       if (arrayOfByte != null)
/* 81 */         rOWID = new ROWID(arrayOfByte); 
/*    */     } 
/* 83 */     return rOWID;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 88 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\VarcharAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */