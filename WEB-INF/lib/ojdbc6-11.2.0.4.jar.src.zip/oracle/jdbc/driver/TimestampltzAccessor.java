/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.OffsetDST;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestampltzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  33 */     init(paramOracleStatement, 231, 231, paramShort, paramBoolean);
/*  34 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  43 */     init(paramOracleStatement, 231, 231, paramShort, false);
/*  44 */     initForDescribe(231, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  46 */     initForDataAccess(0, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  54 */     if (paramInt1 != 0) {
/*  55 */       this.externalType = paramInt1;
/*     */     }
/*  57 */     this.internalTypeMaxLength = 11;
/*     */     
/*  59 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  60 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  62 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*  70 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/*  74 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  75 */       sQLException.fillInStackTrace();
/*  76 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  83 */       return null;
/*     */     }
/*     */     
/*  86 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/*  90 */     String str1 = this.statement.connection.getSessionTimeZone();
/*     */     
/*  92 */     if (str1 == null) {
/*     */ 
/*     */       
/*  95 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/*  96 */       sQLException.fillInStackTrace();
/*  97 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 101 */     TimeZone timeZone = TimeZone.getTimeZone(str1);
/*     */     
/* 103 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 105 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 106 */     short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*     */     
/* 108 */     int j = oracleYear(i);
/*     */     
/* 110 */     calendar1.set(1, j);
/* 111 */     calendar1.set(2, oracleMonth(i));
/* 112 */     calendar1.set(5, oracleDay(i));
/* 113 */     calendar1.set(11, oracleHour(i));
/* 114 */     calendar1.set(12, oracleMin(i));
/* 115 */     calendar1.set(13, oracleSec(i));
/* 116 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 119 */     TimeZoneAdjust(calendar1, calendar2);
/*     */ 
/*     */     
/* 122 */     j = calendar2.get(1);
/*     */     
/* 124 */     int k = calendar2.get(2) + 1;
/* 125 */     int m = calendar2.get(5);
/* 126 */     int n = calendar2.get(11);
/* 127 */     int i1 = calendar2.get(12);
/* 128 */     int i2 = calendar2.get(13);
/* 129 */     int i3 = 0;
/* 130 */     boolean bool = (n < 12) ? true : false;
/* 131 */     String str2 = calendar2.getTimeZone().getID();
/* 132 */     if (str2.length() > 3 && str2.startsWith("GMT")) {
/* 133 */       str2 = str2.substring(3);
/*     */     }
/* 135 */     if (s == 11)
/*     */     {
/* 137 */       i3 = oracleNanos(i);
/*     */     }
/*     */     
/* 140 */     return toText(j, k, m, n, i1, i2, i3, bool, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 151 */     return getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 157 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 161 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 162 */       sQLException.fillInStackTrace();
/* 163 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 170 */       return null;
/*     */     }
/*     */     
/* 173 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 177 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 179 */     if (str == null) {
/*     */ 
/*     */       
/* 182 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 183 */       sQLException.fillInStackTrace();
/* 184 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 188 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/*     */     
/* 190 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 192 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 193 */     int j = oracleYear(i);
/*     */     
/* 195 */     calendar1.set(1, j);
/* 196 */     calendar1.set(2, oracleMonth(i));
/* 197 */     calendar1.set(5, oracleDay(i));
/* 198 */     calendar1.set(11, oracleHour(i));
/* 199 */     calendar1.set(12, oracleMin(i));
/* 200 */     calendar1.set(13, oracleSec(i));
/* 201 */     calendar1.set(14, 0);
/*     */     
/* 203 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 205 */     return new Date(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 214 */     return getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 220 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 224 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 225 */       sQLException.fillInStackTrace();
/* 226 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 231 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 232 */       return null;
/*     */     }
/*     */     
/* 235 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 239 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 241 */     if (str == null) {
/*     */ 
/*     */       
/* 244 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 245 */       sQLException.fillInStackTrace();
/* 246 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 250 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/*     */     
/* 252 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 254 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 255 */     int j = oracleYear(i);
/*     */     
/* 257 */     calendar1.set(1, j);
/* 258 */     calendar1.set(2, oracleMonth(i));
/* 259 */     calendar1.set(5, oracleDay(i));
/* 260 */     calendar1.set(11, oracleHour(i));
/* 261 */     calendar1.set(12, oracleMin(i));
/* 262 */     calendar1.set(13, oracleSec(i));
/* 263 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 266 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 268 */     return new Time(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 278 */     return getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 285 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 289 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 290 */       sQLException.fillInStackTrace();
/* 291 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 298 */       return null;
/*     */     }
/*     */     
/* 301 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 305 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 307 */     if (str == null) {
/*     */ 
/*     */       
/* 310 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 311 */       sQLException.fillInStackTrace();
/* 312 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 316 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/* 317 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 319 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 320 */     short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*     */     
/* 322 */     int j = oracleYear(i);
/*     */     
/* 324 */     calendar1.set(1, j);
/* 325 */     calendar1.set(2, oracleMonth(i));
/* 326 */     calendar1.set(5, oracleDay(i));
/* 327 */     calendar1.set(11, oracleHour(i));
/* 328 */     calendar1.set(12, oracleMin(i));
/* 329 */     calendar1.set(13, oracleSec(i));
/* 330 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 333 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 335 */     Timestamp timestamp = new Timestamp(l);
/*     */     
/* 337 */     if (s == 11)
/*     */     {
/* 339 */       timestamp.setNanos(oracleNanos(i));
/*     */     }
/*     */     
/* 342 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 350 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 358 */     return (Datum)getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 366 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 374 */     TIMESTAMPLTZ tIMESTAMPLTZ = null;
/*     */     
/* 376 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 380 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 381 */       sQLException.fillInStackTrace();
/* 382 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 390 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 391 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 392 */       byte[] arrayOfByte = new byte[s];
/*     */       
/* 394 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*     */       
/* 396 */       tIMESTAMPLTZ = new TIMESTAMPLTZ(arrayOfByte);
/*     */     } 
/*     */     
/* 399 */     return tIMESTAMPLTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 406 */     TIMESTAMPTZ tIMESTAMPTZ = null;
/*     */     
/* 408 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 412 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 413 */       sQLException.fillInStackTrace();
/* 414 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 420 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 422 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 423 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 424 */       byte[] arrayOfByte = new byte[s];
/*     */       
/* 426 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*     */       
/* 428 */       tIMESTAMPTZ = TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.statement.connection, arrayOfByte);
/*     */     } 
/*     */     
/* 431 */     return tIMESTAMPTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 437 */     TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 438 */     return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 443 */     TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 444 */     return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void TimeZoneAdjust(Calendar paramCalendar1, Calendar paramCalendar2) throws SQLException {
/* 454 */     String str1 = paramCalendar1.getTimeZone().getID();
/* 455 */     String str2 = paramCalendar2.getTimeZone().getID();
/*     */ 
/*     */     
/* 458 */     if (!str2.equals(str1)) {
/*     */       int i3;
/* 460 */       OffsetDST offsetDST = new OffsetDST();
/*     */ 
/*     */       
/* 463 */       byte b = getZoneOffset(paramCalendar1, offsetDST);
/*     */       
/* 465 */       int i4 = offsetDST.getOFFSET();
/*     */ 
/*     */       
/* 468 */       paramCalendar1.add(11, -(i4 / 3600000));
/* 469 */       paramCalendar1.add(12, -(i4 % 3600000) / 60000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 475 */       if (str2.equals("Custom") || (str2.startsWith("GMT") && str2.length() > 3)) {
/*     */ 
/*     */ 
/*     */         
/* 479 */         i3 = paramCalendar2.getTimeZone().getRawOffset();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 484 */         int i5 = ZONEIDMAP.getID(str2);
/*     */         
/* 486 */         if (!ZONEIDMAP.isValidID(i5)) {
/*     */           
/* 488 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 489 */           sQLException.fillInStackTrace();
/* 490 */           throw sQLException;
/*     */         } 
/*     */         
/* 493 */         TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 494 */         if (tIMEZONETAB.checkID(i5))
/*     */         {
/* 496 */           tIMEZONETAB.updateTable((Connection)this.statement.connection, i5);
/*     */         }
/*     */         
/* 499 */         Calendar calendar = this.statement.getGMTCalendar();
/*     */         
/* 501 */         calendar.set(1, paramCalendar1.get(1));
/* 502 */         calendar.set(2, paramCalendar1.get(2));
/* 503 */         calendar.set(5, paramCalendar1.get(5));
/* 504 */         calendar.set(11, paramCalendar1.get(11));
/* 505 */         calendar.set(12, paramCalendar1.get(12));
/* 506 */         calendar.set(13, paramCalendar1.get(13));
/* 507 */         calendar.set(14, paramCalendar1.get(14));
/*     */ 
/*     */         
/* 510 */         i3 = tIMEZONETAB.getOffset(calendar, i5);
/*     */       } 
/*     */ 
/*     */       
/* 514 */       paramCalendar1.add(11, i3 / 3600000);
/* 515 */       paramCalendar1.add(12, i3 % 3600000 / 60000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 522 */     if ((str2.equals("Custom") && str1.equals("Custom")) || (str2.startsWith("GMT") && str2.length() > 3 && str1.startsWith("GMT") && str1.length() > 3)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 527 */       int i3 = paramCalendar1.getTimeZone().getRawOffset();
/* 528 */       int i4 = paramCalendar2.getTimeZone().getRawOffset();
/* 529 */       int i5 = 0;
/*     */ 
/*     */       
/* 532 */       if (i3 != i4) {
/*     */ 
/*     */         
/* 535 */         i5 = i3 - i4;
/* 536 */         i5 = (i5 > 0) ? i5 : -i5;
/*     */       } 
/*     */       
/* 539 */       if (i3 > i4) {
/* 540 */         i5 = -i5;
/*     */       }
/* 542 */       paramCalendar1.add(11, i5 / 3600000);
/* 543 */       paramCalendar1.add(12, i5 % 3600000 / 60000);
/*     */     } 
/*     */ 
/*     */     
/* 547 */     int i = paramCalendar1.get(1);
/* 548 */     int j = paramCalendar1.get(2);
/* 549 */     int k = paramCalendar1.get(5);
/* 550 */     int m = paramCalendar1.get(11);
/* 551 */     int n = paramCalendar1.get(12);
/* 552 */     int i1 = paramCalendar1.get(13);
/* 553 */     int i2 = paramCalendar1.get(14);
/*     */ 
/*     */     
/* 556 */     paramCalendar2.set(1, i);
/* 557 */     paramCalendar2.set(2, j);
/* 558 */     paramCalendar2.set(5, k);
/* 559 */     paramCalendar2.set(11, m);
/* 560 */     paramCalendar2.set(12, n);
/* 561 */     paramCalendar2.set(13, i1);
/* 562 */     paramCalendar2.set(14, i2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long TimeZoneAdjustUTC(Calendar paramCalendar) throws SQLException {
/* 572 */     String str = paramCalendar.getTimeZone().getID();
/*     */     
/* 574 */     if (str.equals("Custom") || (str.startsWith("GMT") && str.length() > 3)) {
/*     */ 
/*     */ 
/*     */       
/* 578 */       int i3 = paramCalendar.getTimeZone().getRawOffset();
/* 579 */       paramCalendar.add(11, -(i3 / 3600000));
/* 580 */       paramCalendar.add(12, -(i3 % 3600000) / 60000);
/*     */     }
/* 582 */     else if (!str.equals("GMT") && !str.equals("UTC")) {
/*     */       
/* 584 */       OffsetDST offsetDST = new OffsetDST();
/*     */ 
/*     */       
/* 587 */       byte b = getZoneOffset(paramCalendar, offsetDST);
/*     */       
/* 589 */       int i3 = offsetDST.getOFFSET();
/*     */ 
/*     */ 
/*     */       
/* 593 */       paramCalendar.add(11, -(i3 / 3600000));
/* 594 */       paramCalendar.add(12, -(i3 % 3600000) / 60000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 602 */     int i = paramCalendar.get(1);
/* 603 */     int j = paramCalendar.get(2);
/* 604 */     int k = paramCalendar.get(5);
/* 605 */     int m = paramCalendar.get(11);
/* 606 */     int n = paramCalendar.get(12);
/* 607 */     int i1 = paramCalendar.get(13);
/* 608 */     int i2 = paramCalendar.get(14);
/*     */     
/* 610 */     Calendar calendar = this.statement.getGMTCalendar();
/*     */ 
/*     */     
/* 613 */     calendar.set(1, i);
/* 614 */     calendar.set(2, j);
/* 615 */     calendar.set(5, k);
/* 616 */     calendar.set(11, m);
/* 617 */     calendar.set(12, n);
/* 618 */     calendar.set(13, i1);
/* 619 */     calendar.set(14, i2);
/*     */     
/* 621 */     return calendar.getTimeInMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getZoneOffset(Calendar paramCalendar, OffsetDST paramOffsetDST) throws SQLException {
/* 631 */     byte b = 0;
/*     */ 
/*     */     
/* 634 */     String str = paramCalendar.getTimeZone().getID();
/*     */ 
/*     */     
/* 637 */     if (str == "Custom" || (str.startsWith("GMT") && str.length() > 3)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 642 */       paramOffsetDST.setOFFSET(paramCalendar.getTimeZone().getRawOffset());
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 648 */       int i = ZONEIDMAP.getID(str);
/*     */       
/* 650 */       if (!ZONEIDMAP.isValidID(i)) {
/*     */         
/* 652 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 653 */         sQLException.fillInStackTrace();
/* 654 */         throw sQLException;
/*     */       } 
/*     */       
/* 657 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 658 */       if (tIMEZONETAB.checkID(i)) {
/* 659 */         tIMEZONETAB.updateTable((Connection)this.statement.connection, i);
/*     */       }
/*     */ 
/*     */       
/* 663 */       b = tIMEZONETAB.getLocalOffset(paramCalendar, i, paramOffsetDST);
/*     */     } 
/*     */     
/* 666 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 671 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\TimestampltzAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */