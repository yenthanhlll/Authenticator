/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.sql.ANYDATA;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleCallableStatement
/*      */   extends OraclePreparedStatement
/*      */   implements OracleCallableStatement
/*      */ {
/*      */   boolean atLeastOneOrdinalParameter = false;
/*      */   boolean atLeastOneNamedParameter = false;
/*   60 */   String[] namedParameters = new String[8];
/*      */ 
/*      */   
/*   63 */   int parameterCount = 0;
/*      */ 
/*      */   
/*   66 */   final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   87 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  105 */     super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */     
/*  108 */     this.statementType = 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
/*  121 */     int i = paramInt1 - 1;
/*  122 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */       
/*  124 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  125 */       sQLException.fillInStackTrace();
/*  126 */       throw sQLException;
/*      */     } 
/*      */     
/*  129 */     if (paramInt2 == 0) {
/*      */       
/*  131 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  132 */       sQLException.fillInStackTrace();
/*  133 */       throw sQLException;
/*      */     } 
/*  135 */     int j = getInternalType(paramInt2);
/*      */     
/*  137 */     resetBatch();
/*  138 */     this.currentRowNeedToPrepareBinds = true;
/*      */     
/*  140 */     if (this.currentRowBindAccessors == null) {
/*  141 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/*      */     
/*  144 */     switch (paramInt2) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 70:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*  160 */         this.currentRowFormOfUse[i] = 2;
/*      */         break;
/*      */       case 2011:
/*  163 */         paramInt4 = 0;
/*  164 */         this.currentRowFormOfUse[i] = 2;
/*      */         break;
/*      */       case 2009:
/*  167 */         paramInt4 = 0;
/*  168 */         paramString = "SYS.XMLTYPE";
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  174 */         paramInt4 = 0;
/*      */         break;
/*      */     } 
/*      */     
/*  178 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  212 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/*  214 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*  215 */       sQLException.fillInStackTrace();
/*  216 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  222 */     synchronized (this.connection) {
/*  223 */       registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  252 */     synchronized (this.connection) {
/*      */       
/*  254 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  283 */     synchronized (this.connection) {
/*      */       
/*  285 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  302 */     synchronized (this.connection) {
/*      */       
/*  304 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  321 */     synchronized (this.connection) {
/*      */       
/*  323 */       registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOracleBatchStyle() {
/*  332 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetBatch() {
/*  342 */     this.batch = 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/*  371 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  374 */       return this.validRows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/*  393 */     registerOutParameter(paramInt1, paramInt2, 0, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  405 */     registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  413 */     return wasNullValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  423 */     if (this.closed) {
/*      */       
/*  425 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  426 */       sQLException.fillInStackTrace();
/*  427 */       throw sQLException;
/*      */     } 
/*      */     
/*  430 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  433 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  434 */       sQLException.fillInStackTrace();
/*  435 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  439 */     Accessor accessor = null;
/*  440 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  445 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  446 */       sQLException.fillInStackTrace();
/*  447 */       throw sQLException;
/*      */     } 
/*      */     
/*  450 */     this.lastIndex = paramInt;
/*      */     
/*  452 */     if (this.streamList != null) {
/*  453 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  456 */     return accessor.getString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  466 */     if (this.closed) {
/*      */       
/*  468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  469 */       sQLException.fillInStackTrace();
/*  470 */       throw sQLException;
/*      */     } 
/*      */     
/*  473 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  476 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  477 */       sQLException.fillInStackTrace();
/*  478 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  482 */     Accessor accessor = null;
/*  483 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  488 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  489 */       sQLException.fillInStackTrace();
/*  490 */       throw sQLException;
/*      */     } 
/*      */     
/*  493 */     this.lastIndex = paramInt;
/*      */     
/*  495 */     if (this.streamList != null) {
/*  496 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  499 */     return accessor.getOracleObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  509 */     if (this.closed) {
/*      */       
/*  511 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  512 */       sQLException.fillInStackTrace();
/*  513 */       throw sQLException;
/*      */     } 
/*      */     
/*  516 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  519 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  520 */       sQLException.fillInStackTrace();
/*  521 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  525 */     Accessor accessor = null;
/*  526 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  531 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  532 */       sQLException.fillInStackTrace();
/*  533 */       throw sQLException;
/*      */     } 
/*      */     
/*  536 */     this.lastIndex = paramInt;
/*      */     
/*  538 */     if (this.streamList != null) {
/*  539 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  542 */     return accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  552 */     if (this.closed) {
/*      */       
/*  554 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  555 */       sQLException.fillInStackTrace();
/*  556 */       throw sQLException;
/*      */     } 
/*      */     
/*  559 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  562 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  563 */       sQLException.fillInStackTrace();
/*  564 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  568 */     Accessor accessor = null;
/*  569 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  574 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  575 */       sQLException.fillInStackTrace();
/*  576 */       throw sQLException;
/*      */     } 
/*      */     
/*  579 */     this.lastIndex = paramInt;
/*      */     
/*  581 */     if (this.streamList != null) {
/*  582 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  585 */     return accessor.getNUMBER(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  595 */     if (this.closed) {
/*      */       
/*  597 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  598 */       sQLException.fillInStackTrace();
/*  599 */       throw sQLException;
/*      */     } 
/*      */     
/*  602 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  605 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  606 */       sQLException.fillInStackTrace();
/*  607 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  611 */     Accessor accessor = null;
/*  612 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  617 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  618 */       sQLException.fillInStackTrace();
/*  619 */       throw sQLException;
/*      */     } 
/*      */     
/*  622 */     this.lastIndex = paramInt;
/*      */     
/*  624 */     if (this.streamList != null) {
/*  625 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  628 */     return accessor.getDATE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  638 */     if (this.closed) {
/*      */       
/*  640 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  641 */       sQLException.fillInStackTrace();
/*  642 */       throw sQLException;
/*      */     } 
/*      */     
/*  645 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  649 */       sQLException.fillInStackTrace();
/*  650 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  654 */     Accessor accessor = null;
/*  655 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  660 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  661 */       sQLException.fillInStackTrace();
/*  662 */       throw sQLException;
/*      */     } 
/*      */     
/*  665 */     this.lastIndex = paramInt;
/*      */     
/*  667 */     if (this.streamList != null) {
/*  668 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  671 */     return accessor.getINTERVALYM(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  681 */     if (this.closed) {
/*      */       
/*  683 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  684 */       sQLException.fillInStackTrace();
/*  685 */       throw sQLException;
/*      */     } 
/*      */     
/*  688 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  691 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  692 */       sQLException.fillInStackTrace();
/*  693 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  697 */     Accessor accessor = null;
/*  698 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  703 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  704 */       sQLException.fillInStackTrace();
/*  705 */       throw sQLException;
/*      */     } 
/*      */     
/*  708 */     this.lastIndex = paramInt;
/*      */     
/*  710 */     if (this.streamList != null) {
/*  711 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  714 */     return accessor.getINTERVALDS(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  724 */     if (this.closed) {
/*      */       
/*  726 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  727 */       sQLException.fillInStackTrace();
/*  728 */       throw sQLException;
/*      */     } 
/*      */     
/*  731 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  734 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  735 */       sQLException.fillInStackTrace();
/*  736 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  740 */     Accessor accessor = null;
/*  741 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  746 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  747 */       sQLException.fillInStackTrace();
/*  748 */       throw sQLException;
/*      */     } 
/*      */     
/*  751 */     this.lastIndex = paramInt;
/*      */     
/*  753 */     if (this.streamList != null) {
/*  754 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  757 */     return accessor.getTIMESTAMP(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  767 */     if (this.closed) {
/*      */       
/*  769 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  770 */       sQLException.fillInStackTrace();
/*  771 */       throw sQLException;
/*      */     } 
/*      */     
/*  774 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  777 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  778 */       sQLException.fillInStackTrace();
/*  779 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  783 */     Accessor accessor = null;
/*  784 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  789 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  790 */       sQLException.fillInStackTrace();
/*  791 */       throw sQLException;
/*      */     } 
/*      */     
/*  794 */     this.lastIndex = paramInt;
/*      */     
/*  796 */     if (this.streamList != null) {
/*  797 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  800 */     return accessor.getTIMESTAMPTZ(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  810 */     if (this.closed) {
/*      */       
/*  812 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  813 */       sQLException.fillInStackTrace();
/*  814 */       throw sQLException;
/*      */     } 
/*      */     
/*  817 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  820 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  821 */       sQLException.fillInStackTrace();
/*  822 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  826 */     Accessor accessor = null;
/*  827 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  832 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  833 */       sQLException.fillInStackTrace();
/*  834 */       throw sQLException;
/*      */     } 
/*      */     
/*  837 */     this.lastIndex = paramInt;
/*      */     
/*  839 */     if (this.streamList != null) {
/*  840 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  843 */     return accessor.getTIMESTAMPLTZ(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/*  853 */     if (this.closed) {
/*      */       
/*  855 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  856 */       sQLException.fillInStackTrace();
/*  857 */       throw sQLException;
/*      */     } 
/*      */     
/*  860 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  863 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  864 */       sQLException.fillInStackTrace();
/*  865 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  869 */     Accessor accessor = null;
/*  870 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  875 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  876 */       sQLException.fillInStackTrace();
/*  877 */       throw sQLException;
/*      */     } 
/*      */     
/*  880 */     this.lastIndex = paramInt;
/*      */     
/*  882 */     if (this.streamList != null) {
/*  883 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  886 */     return accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  896 */     if (this.closed) {
/*      */       
/*  898 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  899 */       sQLException.fillInStackTrace();
/*  900 */       throw sQLException;
/*      */     } 
/*      */     
/*  903 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  906 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  907 */       sQLException.fillInStackTrace();
/*  908 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  912 */     Accessor accessor = null;
/*  913 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  918 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  919 */       sQLException.fillInStackTrace();
/*  920 */       throw sQLException;
/*      */     } 
/*      */     
/*  923 */     this.lastIndex = paramInt;
/*      */     
/*  925 */     if (this.streamList != null) {
/*  926 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  929 */     return accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  939 */     if (this.closed) {
/*      */       
/*  941 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  942 */       sQLException.fillInStackTrace();
/*  943 */       throw sQLException;
/*      */     } 
/*      */     
/*  946 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  949 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  950 */       sQLException.fillInStackTrace();
/*  951 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  955 */     Accessor accessor = null;
/*  956 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  961 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  962 */       sQLException.fillInStackTrace();
/*  963 */       throw sQLException;
/*      */     } 
/*      */     
/*  966 */     this.lastIndex = paramInt;
/*      */     
/*  968 */     if (this.streamList != null) {
/*  969 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  972 */     return accessor.getSTRUCT(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  982 */     if (this.closed) {
/*      */       
/*  984 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  985 */       sQLException.fillInStackTrace();
/*  986 */       throw sQLException;
/*      */     } 
/*      */     
/*  989 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  992 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  993 */       sQLException.fillInStackTrace();
/*  994 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  998 */     Accessor accessor = null;
/*  999 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1004 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1005 */       sQLException.fillInStackTrace();
/* 1006 */       throw sQLException;
/*      */     } 
/*      */     
/* 1009 */     this.lastIndex = paramInt;
/*      */     
/* 1011 */     if (this.streamList != null) {
/* 1012 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1015 */     return accessor.getOPAQUE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1025 */     if (this.closed) {
/*      */       
/* 1027 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1028 */       sQLException.fillInStackTrace();
/* 1029 */       throw sQLException;
/*      */     } 
/*      */     
/* 1032 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1035 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1036 */       sQLException.fillInStackTrace();
/* 1037 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1041 */     Accessor accessor = null;
/* 1042 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1047 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1048 */       sQLException.fillInStackTrace();
/* 1049 */       throw sQLException;
/*      */     } 
/*      */     
/* 1052 */     this.lastIndex = paramInt;
/*      */     
/* 1054 */     if (this.streamList != null) {
/* 1055 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1058 */     return accessor.getCHAR(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1069 */     if (this.closed) {
/*      */       
/* 1071 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1072 */       sQLException.fillInStackTrace();
/* 1073 */       throw sQLException;
/*      */     } 
/*      */     
/* 1076 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1079 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1080 */       sQLException.fillInStackTrace();
/* 1081 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1085 */     Accessor accessor = null;
/* 1086 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1091 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1092 */       sQLException.fillInStackTrace();
/* 1093 */       throw sQLException;
/*      */     } 
/*      */     
/* 1096 */     this.lastIndex = paramInt;
/*      */     
/* 1098 */     if (this.streamList != null) {
/* 1099 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1102 */     return accessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1112 */     if (this.closed) {
/*      */       
/* 1114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1115 */       sQLException.fillInStackTrace();
/* 1116 */       throw sQLException;
/*      */     } 
/*      */     
/* 1119 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1122 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1123 */       sQLException.fillInStackTrace();
/* 1124 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1128 */     Accessor accessor = null;
/* 1129 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1134 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1135 */       sQLException.fillInStackTrace();
/* 1136 */       throw sQLException;
/*      */     } 
/*      */     
/* 1139 */     this.lastIndex = paramInt;
/*      */     
/* 1141 */     if (this.streamList != null) {
/* 1142 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1145 */     return accessor.getRAW(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1156 */     if (this.closed) {
/*      */       
/* 1158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1159 */       sQLException.fillInStackTrace();
/* 1160 */       throw sQLException;
/*      */     } 
/*      */     
/* 1163 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1166 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1167 */       sQLException.fillInStackTrace();
/* 1168 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1172 */     Accessor accessor = null;
/* 1173 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1178 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1179 */       sQLException.fillInStackTrace();
/* 1180 */       throw sQLException;
/*      */     } 
/*      */     
/* 1183 */     this.lastIndex = paramInt;
/*      */     
/* 1185 */     if (this.streamList != null) {
/* 1186 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1189 */     return accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1199 */     if (this.closed) {
/*      */       
/* 1201 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1202 */       sQLException.fillInStackTrace();
/* 1203 */       throw sQLException;
/*      */     } 
/*      */     
/* 1206 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1209 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1210 */       sQLException.fillInStackTrace();
/* 1211 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1215 */     Accessor accessor = null;
/* 1216 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1221 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1222 */       sQLException.fillInStackTrace();
/* 1223 */       throw sQLException;
/*      */     } 
/*      */     
/* 1226 */     this.lastIndex = paramInt;
/*      */     
/* 1228 */     if (this.streamList != null) {
/* 1229 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1232 */     return accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1242 */     if (this.closed) {
/*      */       
/* 1244 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1245 */       sQLException.fillInStackTrace();
/* 1246 */       throw sQLException;
/*      */     } 
/*      */     
/* 1249 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1252 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1253 */       sQLException.fillInStackTrace();
/* 1254 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1258 */     Accessor accessor = null;
/* 1259 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1265 */       sQLException.fillInStackTrace();
/* 1266 */       throw sQLException;
/*      */     } 
/*      */     
/* 1269 */     this.lastIndex = paramInt;
/*      */     
/* 1271 */     if (this.streamList != null) {
/* 1272 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1275 */     return accessor.getBFILE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1285 */     if (this.closed) {
/*      */       
/* 1287 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1288 */       sQLException.fillInStackTrace();
/* 1289 */       throw sQLException;
/*      */     } 
/*      */     
/* 1292 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1295 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1296 */       sQLException.fillInStackTrace();
/* 1297 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1301 */     Accessor accessor = null;
/* 1302 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1307 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1308 */       sQLException.fillInStackTrace();
/* 1309 */       throw sQLException;
/*      */     } 
/*      */     
/* 1312 */     this.lastIndex = paramInt;
/*      */     
/* 1314 */     if (this.streamList != null) {
/* 1315 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1318 */     return accessor.getBFILE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/* 1328 */     if (this.closed) {
/*      */       
/* 1330 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1331 */       sQLException.fillInStackTrace();
/* 1332 */       throw sQLException;
/*      */     } 
/*      */     
/* 1335 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1338 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1339 */       sQLException.fillInStackTrace();
/* 1340 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1344 */     Accessor accessor = null;
/* 1345 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1350 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1351 */       sQLException.fillInStackTrace();
/* 1352 */       throw sQLException;
/*      */     } 
/*      */     
/* 1355 */     this.lastIndex = paramInt;
/*      */     
/* 1357 */     if (this.streamList != null) {
/* 1358 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1361 */     return accessor.getBoolean(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/* 1371 */     if (this.closed) {
/*      */       
/* 1373 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1374 */       sQLException.fillInStackTrace();
/* 1375 */       throw sQLException;
/*      */     } 
/*      */     
/* 1378 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1381 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1382 */       sQLException.fillInStackTrace();
/* 1383 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1387 */     Accessor accessor = null;
/* 1388 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1393 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1394 */       sQLException.fillInStackTrace();
/* 1395 */       throw sQLException;
/*      */     } 
/*      */     
/* 1398 */     this.lastIndex = paramInt;
/*      */     
/* 1400 */     if (this.streamList != null) {
/* 1401 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1404 */     return accessor.getByte(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 1414 */     if (this.closed) {
/*      */       
/* 1416 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1417 */       sQLException.fillInStackTrace();
/* 1418 */       throw sQLException;
/*      */     } 
/*      */     
/* 1421 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1424 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1425 */       sQLException.fillInStackTrace();
/* 1426 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1430 */     Accessor accessor = null;
/* 1431 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1436 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1437 */       sQLException.fillInStackTrace();
/* 1438 */       throw sQLException;
/*      */     } 
/*      */     
/* 1441 */     this.lastIndex = paramInt;
/*      */     
/* 1443 */     if (this.streamList != null) {
/* 1444 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1447 */     return accessor.getShort(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 1457 */     if (this.closed) {
/*      */       
/* 1459 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1460 */       sQLException.fillInStackTrace();
/* 1461 */       throw sQLException;
/*      */     } 
/*      */     
/* 1464 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1467 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1468 */       sQLException.fillInStackTrace();
/* 1469 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1473 */     Accessor accessor = null;
/* 1474 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1479 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1480 */       sQLException.fillInStackTrace();
/* 1481 */       throw sQLException;
/*      */     } 
/*      */     
/* 1484 */     this.lastIndex = paramInt;
/*      */     
/* 1486 */     if (this.streamList != null) {
/* 1487 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1490 */     return accessor.getInt(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 1500 */     if (this.closed) {
/*      */       
/* 1502 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1503 */       sQLException.fillInStackTrace();
/* 1504 */       throw sQLException;
/*      */     } 
/*      */     
/* 1507 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1511 */       sQLException.fillInStackTrace();
/* 1512 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1516 */     Accessor accessor = null;
/* 1517 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1522 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1523 */       sQLException.fillInStackTrace();
/* 1524 */       throw sQLException;
/*      */     } 
/*      */     
/* 1527 */     this.lastIndex = paramInt;
/*      */     
/* 1529 */     if (this.streamList != null) {
/* 1530 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1533 */     return accessor.getLong(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 1543 */     if (this.closed) {
/*      */       
/* 1545 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1546 */       sQLException.fillInStackTrace();
/* 1547 */       throw sQLException;
/*      */     } 
/*      */     
/* 1550 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1553 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1554 */       sQLException.fillInStackTrace();
/* 1555 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1559 */     Accessor accessor = null;
/* 1560 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1565 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1566 */       sQLException.fillInStackTrace();
/* 1567 */       throw sQLException;
/*      */     } 
/*      */     
/* 1570 */     this.lastIndex = paramInt;
/*      */     
/* 1572 */     if (this.streamList != null) {
/* 1573 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1576 */     return accessor.getFloat(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 1586 */     if (this.closed) {
/*      */       
/* 1588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1589 */       sQLException.fillInStackTrace();
/* 1590 */       throw sQLException;
/*      */     } 
/*      */     
/* 1593 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1596 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1597 */       sQLException.fillInStackTrace();
/* 1598 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1602 */     Accessor accessor = null;
/* 1603 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1608 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1609 */       sQLException.fillInStackTrace();
/* 1610 */       throw sQLException;
/*      */     } 
/*      */     
/* 1613 */     this.lastIndex = paramInt;
/*      */     
/* 1615 */     if (this.streamList != null) {
/* 1616 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1619 */     return accessor.getDouble(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 1629 */     if (this.closed) {
/*      */       
/* 1631 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1632 */       sQLException.fillInStackTrace();
/* 1633 */       throw sQLException;
/*      */     } 
/*      */     
/* 1636 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1639 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1640 */       sQLException.fillInStackTrace();
/* 1641 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1645 */     Accessor accessor = null;
/* 1646 */     if (paramInt1 <= 0 || paramInt1 > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt1 - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1651 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1652 */       sQLException.fillInStackTrace();
/* 1653 */       throw sQLException;
/*      */     } 
/*      */     
/* 1656 */     this.lastIndex = paramInt1;
/*      */     
/* 1658 */     if (this.streamList != null) {
/* 1659 */       closeUsedStreams(paramInt1);
/*      */     }
/*      */     
/* 1662 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 1672 */     if (this.closed) {
/*      */       
/* 1674 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1675 */       sQLException.fillInStackTrace();
/* 1676 */       throw sQLException;
/*      */     } 
/*      */     
/* 1679 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1682 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1683 */       sQLException.fillInStackTrace();
/* 1684 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1688 */     Accessor accessor = null;
/* 1689 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1694 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1695 */       sQLException.fillInStackTrace();
/* 1696 */       throw sQLException;
/*      */     } 
/*      */     
/* 1699 */     this.lastIndex = paramInt;
/*      */     
/* 1701 */     if (this.streamList != null) {
/* 1702 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1705 */     return accessor.getBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 1715 */     if (this.closed) {
/*      */       
/* 1717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1718 */       sQLException.fillInStackTrace();
/* 1719 */       throw sQLException;
/*      */     } 
/*      */     
/* 1722 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1725 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1726 */       sQLException.fillInStackTrace();
/* 1727 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1731 */     Accessor accessor = null;
/* 1732 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1737 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1738 */       sQLException.fillInStackTrace();
/* 1739 */       throw sQLException;
/*      */     } 
/*      */     
/* 1742 */     this.lastIndex = paramInt;
/*      */     
/* 1744 */     if (this.streamList != null) {
/* 1745 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1748 */     return accessor.privateGetBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 1758 */     if (this.closed) {
/*      */       
/* 1760 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1761 */       sQLException.fillInStackTrace();
/* 1762 */       throw sQLException;
/*      */     } 
/*      */     
/* 1765 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1768 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1769 */       sQLException.fillInStackTrace();
/* 1770 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1774 */     Accessor accessor = null;
/* 1775 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1780 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1781 */       sQLException.fillInStackTrace();
/* 1782 */       throw sQLException;
/*      */     } 
/*      */     
/* 1785 */     this.lastIndex = paramInt;
/*      */     
/* 1787 */     if (this.streamList != null) {
/* 1788 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1791 */     return accessor.getDate(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 1801 */     if (this.closed) {
/*      */       
/* 1803 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1804 */       sQLException.fillInStackTrace();
/* 1805 */       throw sQLException;
/*      */     } 
/*      */     
/* 1808 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1811 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1812 */       sQLException.fillInStackTrace();
/* 1813 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1817 */     Accessor accessor = null;
/* 1818 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1823 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1824 */       sQLException.fillInStackTrace();
/* 1825 */       throw sQLException;
/*      */     } 
/*      */     
/* 1828 */     this.lastIndex = paramInt;
/*      */     
/* 1830 */     if (this.streamList != null) {
/* 1831 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1834 */     return accessor.getTime(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 1844 */     if (this.closed) {
/*      */       
/* 1846 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1847 */       sQLException.fillInStackTrace();
/* 1848 */       throw sQLException;
/*      */     } 
/*      */     
/* 1851 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1854 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1855 */       sQLException.fillInStackTrace();
/* 1856 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1860 */     Accessor accessor = null;
/* 1861 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1866 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1867 */       sQLException.fillInStackTrace();
/* 1868 */       throw sQLException;
/*      */     } 
/*      */     
/* 1871 */     this.lastIndex = paramInt;
/*      */     
/* 1873 */     if (this.streamList != null) {
/* 1874 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1877 */     return accessor.getTimestamp(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1887 */     if (this.closed) {
/*      */       
/* 1889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1890 */       sQLException.fillInStackTrace();
/* 1891 */       throw sQLException;
/*      */     } 
/*      */     
/* 1894 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1897 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1898 */       sQLException.fillInStackTrace();
/* 1899 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1903 */     Accessor accessor = null;
/* 1904 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1909 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1910 */       sQLException.fillInStackTrace();
/* 1911 */       throw sQLException;
/*      */     } 
/*      */     
/* 1914 */     this.lastIndex = paramInt;
/*      */     
/* 1916 */     if (this.streamList != null) {
/* 1917 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1920 */     return accessor.getAsciiStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1930 */     if (this.closed) {
/*      */       
/* 1932 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1933 */       sQLException.fillInStackTrace();
/* 1934 */       throw sQLException;
/*      */     } 
/*      */     
/* 1937 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1940 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1941 */       sQLException.fillInStackTrace();
/* 1942 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1946 */     Accessor accessor = null;
/* 1947 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1952 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1953 */       sQLException.fillInStackTrace();
/* 1954 */       throw sQLException;
/*      */     } 
/*      */     
/* 1957 */     this.lastIndex = paramInt;
/*      */     
/* 1959 */     if (this.streamList != null) {
/* 1960 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1963 */     return accessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1973 */     if (this.closed) {
/*      */       
/* 1975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1976 */       sQLException.fillInStackTrace();
/* 1977 */       throw sQLException;
/*      */     } 
/*      */     
/* 1980 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1983 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1984 */       sQLException.fillInStackTrace();
/* 1985 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1989 */     Accessor accessor = null;
/* 1990 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1995 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1996 */       sQLException.fillInStackTrace();
/* 1997 */       throw sQLException;
/*      */     } 
/*      */     
/* 2000 */     this.lastIndex = paramInt;
/*      */     
/* 2002 */     if (this.streamList != null) {
/* 2003 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2006 */     return accessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 2016 */     if (this.closed) {
/*      */       
/* 2018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2019 */       sQLException.fillInStackTrace();
/* 2020 */       throw sQLException;
/*      */     } 
/*      */     
/* 2023 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2026 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2027 */       sQLException.fillInStackTrace();
/* 2028 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2032 */     Accessor accessor = null;
/* 2033 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2039 */       sQLException.fillInStackTrace();
/* 2040 */       throw sQLException;
/*      */     } 
/*      */     
/* 2043 */     this.lastIndex = paramInt;
/*      */     
/* 2045 */     if (this.streamList != null) {
/* 2046 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2049 */     return accessor.getObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 2058 */     Object object1 = null;
/* 2059 */     Object object2 = getObject(paramInt);
/* 2060 */     if (object2 instanceof ANYDATA) {
/*      */       
/* 2062 */       Datum datum = ((ANYDATA)object2).accessDatum();
/* 2063 */       if (datum != null) object1 = datum.toJdbc(); 
/*      */     } 
/* 2065 */     return object1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 2075 */     if (this.closed) {
/*      */       
/* 2077 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2078 */       sQLException.fillInStackTrace();
/* 2079 */       throw sQLException;
/*      */     } 
/*      */     
/* 2082 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2085 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2086 */       sQLException.fillInStackTrace();
/* 2087 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2091 */     Accessor accessor = null;
/* 2092 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2097 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2098 */       sQLException.fillInStackTrace();
/* 2099 */       throw sQLException;
/*      */     } 
/*      */     
/* 2102 */     this.lastIndex = paramInt;
/*      */     
/* 2104 */     if (this.streamList != null) {
/* 2105 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2108 */     return accessor.getCustomDatum(this.currentRank, paramCustomDatumFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 2117 */     if (this.closed) {
/*      */       
/* 2119 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2120 */       sQLException.fillInStackTrace();
/* 2121 */       throw sQLException;
/*      */     } 
/*      */     
/* 2124 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2127 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2128 */       sQLException.fillInStackTrace();
/* 2129 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2133 */     Accessor accessor = null;
/* 2134 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2139 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2140 */       sQLException.fillInStackTrace();
/* 2141 */       throw sQLException;
/*      */     } 
/*      */     
/* 2144 */     this.lastIndex = paramInt;
/*      */     
/* 2146 */     if (this.streamList != null) {
/* 2147 */       closeUsedStreams(paramInt);
/*      */     }
/* 2149 */     return accessor.getObject(this.currentRank, paramOracleDataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 2159 */     if (this.closed) {
/*      */       
/* 2161 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2162 */       sQLException.fillInStackTrace();
/* 2163 */       throw sQLException;
/*      */     } 
/*      */     
/* 2166 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2169 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2170 */       sQLException.fillInStackTrace();
/* 2171 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2175 */     Accessor accessor = null;
/* 2176 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2181 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2182 */       sQLException.fillInStackTrace();
/* 2183 */       throw sQLException;
/*      */     } 
/*      */     
/* 2186 */     this.lastIndex = paramInt;
/*      */     
/* 2188 */     if (this.streamList != null) {
/* 2189 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2192 */     return accessor.getORAData(this.currentRank, paramORADataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 2202 */     if (this.closed) {
/*      */       
/* 2204 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2205 */       sQLException.fillInStackTrace();
/* 2206 */       throw sQLException;
/*      */     } 
/*      */     
/* 2209 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2212 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2213 */       sQLException.fillInStackTrace();
/* 2214 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2218 */     Accessor accessor = null;
/* 2219 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2224 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2225 */       sQLException.fillInStackTrace();
/* 2226 */       throw sQLException;
/*      */     } 
/*      */     
/* 2229 */     this.lastIndex = paramInt;
/*      */     
/* 2231 */     if (this.streamList != null) {
/* 2232 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2235 */     return accessor.getCursor(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/* 2242 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2245 */       super.clearParameters();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 2266 */     if (this.closed) {
/*      */       
/* 2268 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2269 */       sQLException.fillInStackTrace();
/* 2270 */       throw sQLException;
/*      */     } 
/*      */     
/* 2273 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2276 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2277 */       sQLException.fillInStackTrace();
/* 2278 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2282 */     Accessor accessor = null;
/* 2283 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2288 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2289 */       sQLException.fillInStackTrace();
/* 2290 */       throw sQLException;
/*      */     } 
/*      */     
/* 2293 */     this.lastIndex = paramInt;
/*      */     
/* 2295 */     if (this.streamList != null) {
/* 2296 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2299 */     return accessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 2309 */     if (this.closed) {
/*      */       
/* 2311 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2312 */       sQLException.fillInStackTrace();
/* 2313 */       throw sQLException;
/*      */     } 
/*      */     
/* 2316 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2319 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2320 */       sQLException.fillInStackTrace();
/* 2321 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2325 */     Accessor accessor = null;
/* 2326 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2331 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2332 */       sQLException.fillInStackTrace();
/* 2333 */       throw sQLException;
/*      */     } 
/*      */     
/* 2336 */     this.lastIndex = paramInt;
/*      */     
/* 2338 */     if (this.streamList != null) {
/* 2339 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2342 */     return (Ref)accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 2352 */     if (this.closed) {
/*      */       
/* 2354 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2355 */       sQLException.fillInStackTrace();
/* 2356 */       throw sQLException;
/*      */     } 
/*      */     
/* 2359 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2362 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2363 */       sQLException.fillInStackTrace();
/* 2364 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2368 */     Accessor accessor = null;
/* 2369 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2374 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2375 */       sQLException.fillInStackTrace();
/* 2376 */       throw sQLException;
/*      */     } 
/*      */     
/* 2379 */     this.lastIndex = paramInt;
/*      */     
/* 2381 */     if (this.streamList != null) {
/* 2382 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2385 */     return (Blob)accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 2395 */     if (this.closed) {
/*      */       
/* 2397 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2398 */       sQLException.fillInStackTrace();
/* 2399 */       throw sQLException;
/*      */     } 
/*      */     
/* 2402 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2405 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2406 */       sQLException.fillInStackTrace();
/* 2407 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2411 */     Accessor accessor = null;
/* 2412 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2417 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2418 */       sQLException.fillInStackTrace();
/* 2419 */       throw sQLException;
/*      */     } 
/*      */     
/* 2422 */     this.lastIndex = paramInt;
/*      */     
/* 2424 */     if (this.streamList != null) {
/* 2425 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2428 */     return (Clob)accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 2438 */     if (this.closed) {
/*      */       
/* 2440 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2441 */       sQLException.fillInStackTrace();
/* 2442 */       throw sQLException;
/*      */     } 
/*      */     
/* 2445 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2448 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2449 */       sQLException.fillInStackTrace();
/* 2450 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2454 */     Accessor accessor = null;
/* 2455 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2460 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2461 */       sQLException.fillInStackTrace();
/* 2462 */       throw sQLException;
/*      */     } 
/*      */     
/* 2465 */     this.lastIndex = paramInt;
/*      */     
/* 2467 */     if (this.streamList != null) {
/* 2468 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2471 */     return (Array)accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 2481 */     if (this.closed) {
/*      */       
/* 2483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2484 */       sQLException.fillInStackTrace();
/* 2485 */       throw sQLException;
/*      */     } 
/*      */     
/* 2488 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2491 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2492 */       sQLException.fillInStackTrace();
/* 2493 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2497 */     Accessor accessor = null;
/* 2498 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2503 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2504 */       sQLException.fillInStackTrace();
/* 2505 */       throw sQLException;
/*      */     } 
/*      */     
/* 2508 */     this.lastIndex = paramInt;
/*      */     
/* 2510 */     if (this.streamList != null) {
/* 2511 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2514 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2524 */     if (this.closed) {
/*      */       
/* 2526 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2527 */       sQLException.fillInStackTrace();
/* 2528 */       throw sQLException;
/*      */     } 
/*      */     
/* 2531 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2534 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2535 */       sQLException.fillInStackTrace();
/* 2536 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2540 */     Accessor accessor = null;
/* 2541 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2546 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2547 */       sQLException.fillInStackTrace();
/* 2548 */       throw sQLException;
/*      */     } 
/*      */     
/* 2551 */     this.lastIndex = paramInt;
/*      */     
/* 2553 */     if (this.streamList != null) {
/* 2554 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2557 */     return accessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2567 */     if (this.closed) {
/*      */       
/* 2569 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2570 */       sQLException.fillInStackTrace();
/* 2571 */       throw sQLException;
/*      */     } 
/*      */     
/* 2574 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2577 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2578 */       sQLException.fillInStackTrace();
/* 2579 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2583 */     Accessor accessor = null;
/* 2584 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2589 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2590 */       sQLException.fillInStackTrace();
/* 2591 */       throw sQLException;
/*      */     } 
/*      */     
/* 2594 */     this.lastIndex = paramInt;
/*      */     
/* 2596 */     if (this.streamList != null) {
/* 2597 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2600 */     return accessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2610 */     if (this.closed) {
/*      */       
/* 2612 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2613 */       sQLException.fillInStackTrace();
/* 2614 */       throw sQLException;
/*      */     } 
/*      */     
/* 2617 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2620 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2621 */       sQLException.fillInStackTrace();
/* 2622 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2626 */     Accessor accessor = null;
/* 2627 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2632 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2633 */       sQLException.fillInStackTrace();
/* 2634 */       throw sQLException;
/*      */     } 
/*      */     
/* 2637 */     this.lastIndex = paramInt;
/*      */     
/* 2639 */     if (this.streamList != null) {
/* 2640 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2643 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 2689 */     if (this.currentRowBindAccessors != null) {
/*      */ 
/*      */       
/* 2692 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
/* 2693 */       sQLException.fillInStackTrace();
/* 2694 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2698 */     super.addBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void alwaysOnClose() throws SQLException {
/* 2708 */     this.sqlObject.resetNamedParameters();
/*      */ 
/*      */     
/* 2711 */     this.namedParameters = new String[8];
/* 2712 */     this.parameterCount = 0;
/* 2713 */     this.atLeastOneOrdinalParameter = false;
/* 2714 */     this.atLeastOneNamedParameter = false;
/*      */     
/* 2716 */     super.alwaysOnClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 2753 */     registerOutParameterInternal(paramString, paramInt, 0, -1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 2786 */     registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 2831 */     registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2) throws SQLException {
/* 2839 */     int i = addNamedPara(paramString1);
/* 2840 */     registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 2865 */     if (this.closed) {
/*      */       
/* 2867 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2868 */       sQLException.fillInStackTrace();
/* 2869 */       throw sQLException;
/*      */     } 
/*      */     
/* 2872 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2875 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2876 */       sQLException.fillInStackTrace();
/* 2877 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2881 */     Accessor accessor = null;
/* 2882 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2887 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2888 */       sQLException.fillInStackTrace();
/* 2889 */       throw sQLException;
/*      */     } 
/*      */     
/* 2892 */     this.lastIndex = paramInt;
/*      */     
/* 2894 */     if (this.streamList != null) {
/* 2895 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2898 */     return accessor.getURL(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 2925 */     int i = addNamedPara(paramString1);
/* 2926 */     if (paramString2 == null || paramString2.length() == 0) {
/*      */       
/* 2928 */       setNull(i, 2005);
/*      */       return;
/*      */     } 
/* 2931 */     setStringForClob(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/* 2950 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/* 2952 */       setNull(paramInt, 2005);
/*      */       return;
/*      */     } 
/* 2955 */     synchronized (this.connection) {
/* 2956 */       setStringForClobCritical(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 2981 */     int i = addNamedPara(paramString);
/* 2982 */     setBytesForBlob(i, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 3000 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/*      */       
/* 3002 */       setNull(paramInt, 2004);
/*      */       return;
/*      */     } 
/* 3005 */     synchronized (this.connection) {
/* 3006 */       setBytesForBlobCritical(paramInt, paramArrayOfbyte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 3035 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3039 */       sQLException.fillInStackTrace();
/* 3040 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3044 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3047 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3049 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3052 */     b++;
/*      */     
/* 3054 */     Accessor accessor = null;
/* 3055 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3060 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3061 */       sQLException.fillInStackTrace();
/* 3062 */       throw sQLException;
/*      */     } 
/*      */     
/* 3065 */     this.lastIndex = b;
/*      */     
/* 3067 */     if (this.streamList != null) {
/* 3068 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3071 */     return accessor.getString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 3092 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3095 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3096 */       sQLException.fillInStackTrace();
/* 3097 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3101 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3104 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3106 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3109 */     b++;
/*      */     
/* 3111 */     Accessor accessor = null;
/* 3112 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3117 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3118 */       sQLException.fillInStackTrace();
/* 3119 */       throw sQLException;
/*      */     } 
/*      */     
/* 3122 */     this.lastIndex = b;
/*      */     
/* 3124 */     if (this.streamList != null) {
/* 3125 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3128 */     return accessor.getBoolean(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 3149 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3152 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3153 */       sQLException.fillInStackTrace();
/* 3154 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3158 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3161 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3163 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3166 */     b++;
/*      */     
/* 3168 */     Accessor accessor = null;
/* 3169 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3174 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3175 */       sQLException.fillInStackTrace();
/* 3176 */       throw sQLException;
/*      */     } 
/*      */     
/* 3179 */     this.lastIndex = b;
/*      */     
/* 3181 */     if (this.streamList != null) {
/* 3182 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3185 */     return accessor.getByte(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 3206 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3209 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3210 */       sQLException.fillInStackTrace();
/* 3211 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3215 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3218 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3220 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3223 */     b++;
/*      */     
/* 3225 */     Accessor accessor = null;
/* 3226 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3231 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3232 */       sQLException.fillInStackTrace();
/* 3233 */       throw sQLException;
/*      */     } 
/*      */     
/* 3236 */     this.lastIndex = b;
/*      */     
/* 3238 */     if (this.streamList != null) {
/* 3239 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3242 */     return accessor.getShort(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 3264 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3267 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3268 */       sQLException.fillInStackTrace();
/* 3269 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3273 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3276 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3278 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3281 */     b++;
/*      */     
/* 3283 */     Accessor accessor = null;
/* 3284 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3289 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3290 */       sQLException.fillInStackTrace();
/* 3291 */       throw sQLException;
/*      */     } 
/*      */     
/* 3294 */     this.lastIndex = b;
/*      */     
/* 3296 */     if (this.streamList != null) {
/* 3297 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3300 */     return accessor.getInt(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 3322 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3325 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3326 */       sQLException.fillInStackTrace();
/* 3327 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3331 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3334 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3336 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3339 */     b++;
/*      */     
/* 3341 */     Accessor accessor = null;
/* 3342 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3347 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3348 */       sQLException.fillInStackTrace();
/* 3349 */       throw sQLException;
/*      */     } 
/*      */     
/* 3352 */     this.lastIndex = b;
/*      */     
/* 3354 */     if (this.streamList != null) {
/* 3355 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3358 */     return accessor.getLong(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 3379 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3382 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3383 */       sQLException.fillInStackTrace();
/* 3384 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3388 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3391 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3393 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3396 */     b++;
/*      */     
/* 3398 */     Accessor accessor = null;
/* 3399 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3404 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3405 */       sQLException.fillInStackTrace();
/* 3406 */       throw sQLException;
/*      */     } 
/*      */     
/* 3409 */     this.lastIndex = b;
/*      */     
/* 3411 */     if (this.streamList != null) {
/* 3412 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3415 */     return accessor.getFloat(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 3436 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3439 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3440 */       sQLException.fillInStackTrace();
/* 3441 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3445 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3448 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3450 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3453 */     b++;
/*      */     
/* 3455 */     Accessor accessor = null;
/* 3456 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3461 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3462 */       sQLException.fillInStackTrace();
/* 3463 */       throw sQLException;
/*      */     } 
/*      */     
/* 3466 */     this.lastIndex = b;
/*      */     
/* 3468 */     if (this.streamList != null) {
/* 3469 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3472 */     return accessor.getDouble(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 3494 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3497 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3498 */       sQLException.fillInStackTrace();
/* 3499 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3503 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3506 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3508 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3511 */     b++;
/*      */     
/* 3513 */     Accessor accessor = null;
/* 3514 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3519 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3520 */       sQLException.fillInStackTrace();
/* 3521 */       throw sQLException;
/*      */     } 
/*      */     
/* 3524 */     this.lastIndex = b;
/*      */     
/* 3526 */     if (this.streamList != null) {
/* 3527 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3530 */     return accessor.getBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 3551 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3554 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3555 */       sQLException.fillInStackTrace();
/* 3556 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3560 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3563 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3565 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3568 */     b++;
/*      */     
/* 3570 */     Accessor accessor = null;
/* 3571 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3576 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3577 */       sQLException.fillInStackTrace();
/* 3578 */       throw sQLException;
/*      */     } 
/*      */     
/* 3581 */     this.lastIndex = b;
/*      */     
/* 3583 */     if (this.streamList != null) {
/* 3584 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3587 */     return accessor.getDate(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 3608 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3612 */       sQLException.fillInStackTrace();
/* 3613 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3617 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3620 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3622 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3625 */     b++;
/*      */     
/* 3627 */     Accessor accessor = null;
/* 3628 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3633 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3634 */       sQLException.fillInStackTrace();
/* 3635 */       throw sQLException;
/*      */     } 
/*      */     
/* 3638 */     this.lastIndex = b;
/*      */     
/* 3640 */     if (this.streamList != null) {
/* 3641 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3644 */     return accessor.getTime(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 3665 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3668 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3669 */       sQLException.fillInStackTrace();
/* 3670 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3674 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3677 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3679 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3682 */     b++;
/*      */     
/* 3684 */     Accessor accessor = null;
/* 3685 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3690 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3691 */       sQLException.fillInStackTrace();
/* 3692 */       throw sQLException;
/*      */     } 
/*      */     
/* 3695 */     this.lastIndex = b;
/*      */     
/* 3697 */     if (this.streamList != null) {
/* 3698 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3701 */     return accessor.getTimestamp(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 3729 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3732 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3733 */       sQLException.fillInStackTrace();
/* 3734 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3738 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3741 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3743 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3746 */     b++;
/*      */     
/* 3748 */     Accessor accessor = null;
/* 3749 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3754 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3755 */       sQLException.fillInStackTrace();
/* 3756 */       throw sQLException;
/*      */     } 
/*      */     
/* 3759 */     this.lastIndex = b;
/*      */     
/* 3761 */     if (this.streamList != null) {
/* 3762 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3765 */     return accessor.getObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 3787 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3790 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3791 */       sQLException.fillInStackTrace();
/* 3792 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3796 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3799 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3801 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3804 */     b++;
/*      */     
/* 3806 */     Accessor accessor = null;
/* 3807 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3812 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3813 */       sQLException.fillInStackTrace();
/* 3814 */       throw sQLException;
/*      */     } 
/*      */     
/* 3817 */     this.lastIndex = b;
/*      */     
/* 3819 */     if (this.streamList != null) {
/* 3820 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3823 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 3832 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3835 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3836 */       sQLException.fillInStackTrace();
/* 3837 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3841 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3844 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3846 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3849 */     b++;
/*      */     
/* 3851 */     Accessor accessor = null;
/* 3852 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3857 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3858 */       sQLException.fillInStackTrace();
/* 3859 */       throw sQLException;
/*      */     } 
/*      */     
/* 3862 */     this.lastIndex = b;
/*      */     
/* 3864 */     if (this.streamList != null) {
/* 3865 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3868 */     return accessor.getBigDecimal(this.currentRank, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 3896 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3899 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3900 */       sQLException.fillInStackTrace();
/* 3901 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3905 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3908 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3910 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3913 */     b++;
/*      */     
/* 3915 */     Accessor accessor = null;
/* 3916 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3922 */       sQLException.fillInStackTrace();
/* 3923 */       throw sQLException;
/*      */     } 
/*      */     
/* 3926 */     this.lastIndex = b;
/*      */     
/* 3928 */     if (this.streamList != null) {
/* 3929 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3932 */     return accessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 3954 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3957 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3958 */       sQLException.fillInStackTrace();
/* 3959 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3963 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3966 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3968 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3971 */     b++;
/*      */     
/* 3973 */     Accessor accessor = null;
/* 3974 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3979 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3980 */       sQLException.fillInStackTrace();
/* 3981 */       throw sQLException;
/*      */     } 
/*      */     
/* 3984 */     this.lastIndex = b;
/*      */     
/* 3986 */     if (this.streamList != null) {
/* 3987 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3990 */     return (Ref)accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 4012 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4015 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4016 */       sQLException.fillInStackTrace();
/* 4017 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4021 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4024 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4026 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4029 */     b++;
/*      */     
/* 4031 */     Accessor accessor = null;
/* 4032 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4037 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4038 */       sQLException.fillInStackTrace();
/* 4039 */       throw sQLException;
/*      */     } 
/*      */     
/* 4042 */     this.lastIndex = b;
/*      */     
/* 4044 */     if (this.streamList != null) {
/* 4045 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4048 */     return (Blob)accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 4069 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4072 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4073 */       sQLException.fillInStackTrace();
/* 4074 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4078 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4081 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4083 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4086 */     b++;
/*      */     
/* 4088 */     Accessor accessor = null;
/* 4089 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4094 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4095 */       sQLException.fillInStackTrace();
/* 4096 */       throw sQLException;
/*      */     } 
/*      */     
/* 4099 */     this.lastIndex = b;
/*      */     
/* 4101 */     if (this.streamList != null) {
/* 4102 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4105 */     return (Clob)accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 4127 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4130 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4131 */       sQLException.fillInStackTrace();
/* 4132 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4136 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4139 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4141 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4144 */     b++;
/*      */     
/* 4146 */     Accessor accessor = null;
/* 4147 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4152 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4153 */       sQLException.fillInStackTrace();
/* 4154 */       throw sQLException;
/*      */     } 
/*      */     
/* 4157 */     this.lastIndex = b;
/*      */     
/* 4159 */     if (this.streamList != null) {
/* 4160 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4163 */     return (Array)accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 4193 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4196 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4197 */       sQLException.fillInStackTrace();
/* 4198 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4202 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4205 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4207 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4210 */     b++;
/*      */     
/* 4212 */     Accessor accessor = null;
/* 4213 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4218 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4219 */       sQLException.fillInStackTrace();
/* 4220 */       throw sQLException;
/*      */     } 
/*      */     
/* 4223 */     this.lastIndex = b;
/*      */     
/* 4225 */     if (this.streamList != null) {
/* 4226 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4229 */     return accessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 4259 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4262 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4263 */       sQLException.fillInStackTrace();
/* 4264 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4268 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4271 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4273 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4276 */     b++;
/*      */     
/* 4278 */     Accessor accessor = null;
/* 4279 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4284 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4285 */       sQLException.fillInStackTrace();
/* 4286 */       throw sQLException;
/*      */     } 
/*      */     
/* 4289 */     this.lastIndex = b;
/*      */     
/* 4291 */     if (this.streamList != null) {
/* 4292 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4295 */     return accessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 4326 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4329 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4330 */       sQLException.fillInStackTrace();
/* 4331 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4335 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4338 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4340 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4343 */     b++;
/*      */     
/* 4345 */     Accessor accessor = null;
/* 4346 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4351 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4352 */       sQLException.fillInStackTrace();
/* 4353 */       throw sQLException;
/*      */     } 
/*      */     
/* 4356 */     this.lastIndex = b;
/*      */     
/* 4358 */     if (this.streamList != null) {
/* 4359 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4362 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 4386 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4389 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4390 */       sQLException.fillInStackTrace();
/* 4391 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4395 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4398 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4400 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4403 */     b++;
/*      */     
/* 4405 */     Accessor accessor = null;
/* 4406 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4411 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4412 */       sQLException.fillInStackTrace();
/* 4413 */       throw sQLException;
/*      */     } 
/*      */     
/* 4416 */     this.lastIndex = b;
/*      */     
/* 4418 */     if (this.streamList != null) {
/* 4419 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4422 */     return accessor.getURL(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 4432 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4433 */     sQLException.fillInStackTrace();
/* 4434 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4473 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 4476 */       int i = paramInt1 - 1;
/* 4477 */       if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */         
/* 4479 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4480 */         sQLException.fillInStackTrace();
/* 4481 */         throw sQLException;
/*      */       } 
/*      */       
/* 4484 */       int j = getInternalType(paramInt3);
/*      */       
/* 4486 */       resetBatch();
/* 4487 */       this.currentRowNeedToPrepareBinds = true;
/*      */       
/* 4489 */       if (this.currentRowBindAccessors == null) {
/* 4490 */         this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */       }
/* 4492 */       this.currentRowBindAccessors[i] = allocateIndexTableAccessor(paramInt3, j, paramInt4, paramInt2, this.currentRowFormOfUse[i], true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4500 */       this.hasIbtBind = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
/* 4517 */     return new PlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 4541 */     synchronized (this.connection) {
/*      */       BigDecimal[] arrayOfBigDecimal;
/*      */       SQLException sQLException;
/* 4544 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4546 */       PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[paramInt - 1];
/*      */ 
/*      */       
/* 4549 */       int i = plsqlIndexTableAccessor.elementInternalType;
/*      */       
/* 4551 */       String[] arrayOfString = null;
/*      */       
/* 4553 */       switch (i) {
/*      */         
/*      */         case 9:
/* 4556 */           arrayOfString = new String[arrayOfDatum.length];
/*      */           break;
/*      */         case 6:
/* 4559 */           arrayOfBigDecimal = new BigDecimal[arrayOfDatum.length];
/*      */           break;
/*      */         
/*      */         default:
/* 4563 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
/* 4564 */           sQLException.fillInStackTrace();
/* 4565 */           throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4569 */       for (byte b = 0; b < arrayOfBigDecimal.length; b++) {
/* 4570 */         arrayOfBigDecimal[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (BigDecimal)arrayOfDatum[b].toJdbc() : null;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4575 */       return arrayOfBigDecimal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 4595 */     synchronized (this.connection) {
/*      */       
/* 4597 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4599 */       if (paramClass == null || !paramClass.isPrimitive()) {
/*      */         
/* 4601 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4602 */         sQLException1.fillInStackTrace();
/* 4603 */         throw sQLException1;
/*      */       } 
/*      */       
/* 4606 */       String str = paramClass.getName();
/*      */       
/* 4608 */       if (str.equals("byte")) {
/*      */         
/* 4610 */         byte[] arrayOfByte = new byte[arrayOfDatum.length];
/* 4611 */         for (byte b = 0; b < arrayOfDatum.length; b++)
/* 4612 */           arrayOfByte[b] = (arrayOfDatum[b] != null) ? arrayOfDatum[b].byteValue() : 0; 
/* 4613 */         return arrayOfByte;
/*      */       } 
/* 4615 */       if (str.equals("char")) {
/*      */         
/* 4617 */         char[] arrayOfChar = new char[arrayOfDatum.length];
/* 4618 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4619 */           arrayOfChar[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (char)arrayOfDatum[b].intValue() : Character.MIN_VALUE;
/*      */         }
/* 4621 */         return arrayOfChar;
/*      */       } 
/* 4623 */       if (str.equals("double")) {
/*      */         
/* 4625 */         double[] arrayOfDouble = new double[arrayOfDatum.length];
/* 4626 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4627 */           arrayOfDouble[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].doubleValue() : 0.0D;
/*      */         }
/* 4629 */         return arrayOfDouble;
/*      */       } 
/* 4631 */       if (str.equals("float")) {
/*      */         
/* 4633 */         float[] arrayOfFloat = new float[arrayOfDatum.length];
/* 4634 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4635 */           arrayOfFloat[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].floatValue() : 0.0F;
/*      */         }
/* 4637 */         return arrayOfFloat;
/*      */       } 
/* 4639 */       if (str.equals("int")) {
/*      */         
/* 4641 */         int[] arrayOfInt = new int[arrayOfDatum.length];
/* 4642 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4643 */           arrayOfInt[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].intValue() : 0;
/*      */         }
/* 4645 */         return arrayOfInt;
/*      */       } 
/* 4647 */       if (str.equals("long")) {
/*      */         
/* 4649 */         long[] arrayOfLong = new long[arrayOfDatum.length];
/* 4650 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4651 */           arrayOfLong[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].longValue() : 0L;
/*      */         }
/* 4653 */         return arrayOfLong;
/*      */       } 
/* 4655 */       if (str.equals("short")) {
/*      */         
/* 4657 */         short[] arrayOfShort = new short[arrayOfDatum.length];
/* 4658 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4659 */           arrayOfShort[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (short)arrayOfDatum[b].intValue() : 0;
/*      */         }
/* 4661 */         return arrayOfShort;
/*      */       } 
/* 4663 */       if (str.equals("boolean")) {
/*      */         
/* 4665 */         boolean[] arrayOfBoolean = new boolean[arrayOfDatum.length];
/* 4666 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4667 */           arrayOfBoolean[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].booleanValue() : false;
/*      */         }
/* 4669 */         return arrayOfBoolean;
/*      */       } 
/*      */ 
/*      */       
/* 4673 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4674 */       sQLException.fillInStackTrace();
/* 4675 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 4693 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4697 */       if (this.closed) {
/*      */         
/* 4699 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4700 */         sQLException.fillInStackTrace();
/* 4701 */         throw sQLException;
/*      */       } 
/*      */       
/* 4704 */       if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */         
/* 4707 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4708 */         sQLException.fillInStackTrace();
/* 4709 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4713 */       Accessor accessor = null;
/* 4714 */       if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4719 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4720 */         sQLException.fillInStackTrace();
/* 4721 */         throw sQLException;
/*      */       } 
/*      */       
/* 4724 */       this.lastIndex = paramInt;
/*      */       
/* 4726 */       if (this.streamList != null) {
/* 4727 */         closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 4730 */       return accessor.getOraclePlsqlIndexTable(this.currentRank);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 4745 */     synchronized (this.connection) {
/* 4746 */       ensureOpen();
/* 4747 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*      */         
/* 4749 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4750 */         sQLException.fillInStackTrace();
/* 4751 */         throw sQLException;
/*      */       } 
/* 4753 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4754 */         this.needToParse = true; 
/* 4755 */       return super.execute();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/* 4769 */     synchronized (this.connection) {
/*      */       
/* 4771 */       ensureOpen();
/* 4772 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*      */         
/* 4774 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4775 */         sQLException.fillInStackTrace();
/* 4776 */         throw sQLException;
/*      */       } 
/* 4778 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4779 */         this.needToParse = true; 
/* 4780 */       return super.executeUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 4787 */     if (this.outBindAccessors != null) {
/*      */       
/* 4789 */       int i = this.outBindAccessors.length;
/*      */       
/* 4791 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 4793 */         if (this.outBindAccessors[b] != null) {
/*      */           
/* 4795 */           (this.outBindAccessors[b]).rowSpaceByte = null;
/* 4796 */           (this.outBindAccessors[b]).rowSpaceChar = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 4801 */     super.releaseBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 4808 */     if (this.outBindAccessors != null) {
/*      */       
/* 4810 */       int i = this.outBindAccessors.length;
/*      */       
/* 4812 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 4814 */         if (this.outBindAccessors[b] != null) {
/*      */           
/* 4816 */           (this.outBindAccessors[b]).rowSpaceByte = this.bindBytes;
/* 4817 */           (this.outBindAccessors[b]).rowSpaceChar = this.bindChars;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/* 4832 */     this.atLeastOneOrdinalParameter = true;
/* 4833 */     setArrayInternal(paramInt, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 4840 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4844 */       this.atLeastOneOrdinalParameter = true;
/* 4845 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 4853 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4857 */       this.atLeastOneOrdinalParameter = true;
/* 4858 */       setBlobInternal(paramInt, paramBlob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 4866 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4870 */       this.atLeastOneOrdinalParameter = true;
/* 4871 */       setBooleanInternal(paramInt, paramBoolean);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/* 4879 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4883 */       this.atLeastOneOrdinalParameter = true;
/* 4884 */       setByteInternal(paramInt, paramByte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 4892 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4896 */       this.atLeastOneOrdinalParameter = true;
/* 4897 */       setBytesInternal(paramInt, paramArrayOfbyte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/* 4905 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4909 */       this.atLeastOneOrdinalParameter = true;
/* 4910 */       setClobInternal(paramInt, paramClob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/* 4918 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4922 */       this.atLeastOneOrdinalParameter = true;
/* 4923 */       setDateInternal(paramInt, paramDate);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 4931 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4935 */       this.atLeastOneOrdinalParameter = true;
/* 4936 */       setDateInternal(paramInt, paramDate, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/* 4944 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4948 */       this.atLeastOneOrdinalParameter = true;
/* 4949 */       setDoubleInternal(paramInt, paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/* 4957 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4961 */       this.atLeastOneOrdinalParameter = true;
/* 4962 */       setFloatInternal(paramInt, paramFloat);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/* 4970 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4974 */       this.atLeastOneOrdinalParameter = true;
/* 4975 */       setIntInternal(paramInt1, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/* 4983 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4987 */       this.atLeastOneOrdinalParameter = true;
/* 4988 */       setLongInternal(paramInt, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 4996 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5000 */       this.atLeastOneOrdinalParameter = true;
/* 5001 */       setNClobInternal(paramInt, paramNClob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(int paramInt, String paramString) throws SQLException {
/* 5009 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5013 */       this.atLeastOneOrdinalParameter = true;
/* 5014 */       setNStringInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/* 5023 */     this.atLeastOneOrdinalParameter = true;
/* 5024 */     setObjectInternal(paramInt, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 5032 */     this.atLeastOneOrdinalParameter = true;
/* 5033 */     setObjectInternal(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/* 5041 */     this.atLeastOneOrdinalParameter = true;
/* 5042 */     setRefInternal(paramInt, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 5049 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5053 */       this.atLeastOneOrdinalParameter = true;
/* 5054 */       setRowIdInternal(paramInt, paramRowId);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/* 5062 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5066 */       this.atLeastOneOrdinalParameter = true;
/* 5067 */       setShortInternal(paramInt, paramShort);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 5075 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5079 */       this.atLeastOneOrdinalParameter = true;
/* 5080 */       setSQLXMLInternal(paramInt, paramSQLXML);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/* 5088 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5092 */       this.atLeastOneOrdinalParameter = true;
/* 5093 */       setStringInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/* 5101 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5105 */       this.atLeastOneOrdinalParameter = true;
/* 5106 */       setTimeInternal(paramInt, paramTime);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 5114 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5118 */       this.atLeastOneOrdinalParameter = true;
/* 5119 */       setTimeInternal(paramInt, paramTime, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 5127 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5131 */       this.atLeastOneOrdinalParameter = true;
/* 5132 */       setTimestampInternal(paramInt, paramTimestamp);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 5140 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5144 */       this.atLeastOneOrdinalParameter = true;
/* 5145 */       setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 5153 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5157 */       this.atLeastOneOrdinalParameter = true;
/* 5158 */       setURLInternal(paramInt, paramURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/* 5167 */     this.atLeastOneOrdinalParameter = true;
/* 5168 */     setARRAYInternal(paramInt, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/* 5175 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5179 */       this.atLeastOneOrdinalParameter = true;
/* 5180 */       setBFILEInternal(paramInt, paramBFILE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/* 5188 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5192 */       this.atLeastOneOrdinalParameter = true;
/* 5193 */       setBfileInternal(paramInt, paramBFILE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/* 5201 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5205 */       this.atLeastOneOrdinalParameter = true;
/* 5206 */       setBinaryFloatInternal(paramInt, paramFloat);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 5214 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5218 */       this.atLeastOneOrdinalParameter = true;
/* 5219 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/* 5227 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5231 */       this.atLeastOneOrdinalParameter = true;
/* 5232 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 5240 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5244 */       this.atLeastOneOrdinalParameter = true;
/* 5245 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 5253 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5257 */       this.atLeastOneOrdinalParameter = true;
/* 5258 */       setBLOBInternal(paramInt, paramBLOB);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 5266 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5270 */       this.atLeastOneOrdinalParameter = true;
/* 5271 */       setCHARInternal(paramInt, paramCHAR);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 5279 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5283 */       this.atLeastOneOrdinalParameter = true;
/* 5284 */       setCLOBInternal(paramInt, paramCLOB);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/* 5292 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5296 */       this.atLeastOneOrdinalParameter = true;
/* 5297 */       setCursorInternal(paramInt, paramResultSet);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 5306 */     this.atLeastOneOrdinalParameter = true;
/* 5307 */     setCustomDatumInternal(paramInt, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 5314 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5318 */       this.atLeastOneOrdinalParameter = true;
/* 5319 */       setDATEInternal(paramInt, paramDATE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/* 5327 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5331 */       this.atLeastOneOrdinalParameter = true;
/* 5332 */       setFixedCHARInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 5340 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5344 */       this.atLeastOneOrdinalParameter = true;
/* 5345 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 5353 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5357 */       this.atLeastOneOrdinalParameter = true;
/* 5358 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 5366 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5370 */       this.atLeastOneOrdinalParameter = true;
/* 5371 */       setNUMBERInternal(paramInt, paramNUMBER);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 5380 */     this.atLeastOneOrdinalParameter = true;
/* 5381 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 5389 */     this.atLeastOneOrdinalParameter = true;
/* 5390 */     setOracleObjectInternal(paramInt, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 5398 */     this.atLeastOneOrdinalParameter = true;
/* 5399 */     setORADataInternal(paramInt, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 5406 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5410 */       this.atLeastOneOrdinalParameter = true;
/* 5411 */       setRAWInternal(paramInt, paramRAW);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/* 5420 */     this.atLeastOneOrdinalParameter = true;
/* 5421 */     setREFInternal(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/* 5429 */     this.atLeastOneOrdinalParameter = true;
/* 5430 */     setRefTypeInternal(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 5437 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5441 */       this.atLeastOneOrdinalParameter = true;
/* 5442 */       setROWIDInternal(paramInt, paramROWID);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 5451 */     this.atLeastOneOrdinalParameter = true;
/* 5452 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 5459 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5463 */       this.atLeastOneOrdinalParameter = true;
/* 5464 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 5472 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5476 */       this.atLeastOneOrdinalParameter = true;
/* 5477 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 5485 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5489 */       this.atLeastOneOrdinalParameter = true;
/* 5490 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 5498 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5502 */       this.atLeastOneOrdinalParameter = true;
/* 5503 */       setBlobInternal(paramInt, paramInputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 5511 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 5514 */       if (paramLong < 0L) {
/*      */         
/* 5516 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 5517 */         sQLException.fillInStackTrace();
/* 5518 */         throw sQLException;
/*      */       } 
/*      */       
/* 5521 */       this.atLeastOneOrdinalParameter = true;
/* 5522 */       setBlobInternal(paramInt, paramInputStream, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 5530 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5534 */       this.atLeastOneOrdinalParameter = true;
/* 5535 */       setClobInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5543 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5547 */       if (paramLong < 0L) {
/*      */         
/* 5549 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 5550 */         sQLException.fillInStackTrace();
/* 5551 */         throw sQLException;
/*      */       } 
/* 5553 */       this.atLeastOneOrdinalParameter = true;
/* 5554 */       setClobInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 5562 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5566 */       this.atLeastOneOrdinalParameter = true;
/* 5567 */       setNClobInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5575 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5579 */       this.atLeastOneOrdinalParameter = true;
/* 5580 */       setNClobInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 5588 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5592 */       this.atLeastOneOrdinalParameter = true;
/* 5593 */       setAsciiStreamInternal(paramInt, paramInputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5601 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5605 */       this.atLeastOneOrdinalParameter = true;
/* 5606 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 5614 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5618 */       this.atLeastOneOrdinalParameter = true;
/* 5619 */       setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 5627 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5631 */       this.atLeastOneOrdinalParameter = true;
/* 5632 */       setBinaryStreamInternal(paramInt, paramInputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5640 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5644 */       this.atLeastOneOrdinalParameter = true;
/* 5645 */       setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 5653 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5657 */       this.atLeastOneOrdinalParameter = true;
/* 5658 */       setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 5666 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5670 */       this.atLeastOneOrdinalParameter = true;
/* 5671 */       setCharacterStreamInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 5679 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5683 */       this.atLeastOneOrdinalParameter = true;
/* 5684 */       setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5692 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5696 */       this.atLeastOneOrdinalParameter = true;
/* 5697 */       setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 5705 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5709 */       this.atLeastOneOrdinalParameter = true;
/* 5710 */       setNCharacterStreamInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5718 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5722 */       this.atLeastOneOrdinalParameter = true;
/* 5723 */       setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5731 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5735 */       this.atLeastOneOrdinalParameter = true;
/* 5736 */       setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/* 5748 */     int i = addNamedPara(paramString);
/* 5749 */     setArrayInternal(i, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 5759 */     int i = addNamedPara(paramString);
/* 5760 */     setBigDecimalInternal(i, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/* 5770 */     int i = addNamedPara(paramString);
/* 5771 */     setBlobInternal(i, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/* 5781 */     int i = addNamedPara(paramString);
/* 5782 */     setBooleanInternal(i, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/* 5792 */     int i = addNamedPara(paramString);
/* 5793 */     setByteInternal(i, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 5803 */     int i = addNamedPara(paramString);
/* 5804 */     setBytesInternal(i, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/* 5814 */     int i = addNamedPara(paramString);
/* 5815 */     setClobInternal(i, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/* 5825 */     int i = addNamedPara(paramString);
/* 5826 */     setDateInternal(i, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 5836 */     int i = addNamedPara(paramString);
/* 5837 */     setDateInternal(i, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/* 5847 */     int i = addNamedPara(paramString);
/* 5848 */     setDoubleInternal(i, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/* 5858 */     int i = addNamedPara(paramString);
/* 5859 */     setFloatInternal(i, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/* 5869 */     int i = addNamedPara(paramString);
/* 5870 */     setIntInternal(i, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/* 5880 */     int i = addNamedPara(paramString);
/* 5881 */     setLongInternal(i, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, NClob paramNClob) throws SQLException {
/* 5891 */     int i = addNamedPara(paramString);
/* 5892 */     setNClobInternal(i, paramNClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(String paramString1, String paramString2) throws SQLException {
/* 5902 */     int i = addNamedPara(paramString1);
/* 5903 */     setNStringInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/* 5913 */     int i = addNamedPara(paramString);
/* 5914 */     setObjectInternal(i, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 5924 */     int i = addNamedPara(paramString);
/* 5925 */     setObjectInternal(i, paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/* 5935 */     int i = addNamedPara(paramString);
/* 5936 */     setRefInternal(i, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(String paramString, RowId paramRowId) throws SQLException {
/* 5946 */     int i = addNamedPara(paramString);
/* 5947 */     setRowIdInternal(i, paramRowId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/* 5957 */     int i = addNamedPara(paramString);
/* 5958 */     setShortInternal(i, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 5968 */     int i = addNamedPara(paramString);
/* 5969 */     setSQLXMLInternal(i, paramSQLXML);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/* 5979 */     int i = addNamedPara(paramString1);
/* 5980 */     setStringInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/* 5990 */     int i = addNamedPara(paramString);
/* 5991 */     setTimeInternal(i, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 6001 */     int i = addNamedPara(paramString);
/* 6002 */     setTimeInternal(i, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 6012 */     int i = addNamedPara(paramString);
/* 6013 */     setTimestampInternal(i, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 6023 */     int i = addNamedPara(paramString);
/* 6024 */     setTimestampInternal(i, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/* 6034 */     int i = addNamedPara(paramString);
/* 6035 */     setURLInternal(i, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/* 6045 */     int i = addNamedPara(paramString);
/* 6046 */     setARRAYInternal(i, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/* 6056 */     int i = addNamedPara(paramString);
/* 6057 */     setBFILEInternal(i, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/* 6067 */     int i = addNamedPara(paramString);
/* 6068 */     setBfileInternal(i, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/* 6078 */     int i = addNamedPara(paramString);
/* 6079 */     setBinaryFloatInternal(i, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 6089 */     int i = addNamedPara(paramString);
/* 6090 */     setBinaryFloatInternal(i, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/* 6100 */     int i = addNamedPara(paramString);
/* 6101 */     setBinaryDoubleInternal(i, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 6111 */     int i = addNamedPara(paramString);
/* 6112 */     setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/* 6122 */     int i = addNamedPara(paramString);
/* 6123 */     setBLOBInternal(i, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/* 6133 */     int i = addNamedPara(paramString);
/* 6134 */     setCHARInternal(i, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/* 6144 */     int i = addNamedPara(paramString);
/* 6145 */     setCLOBInternal(i, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/* 6155 */     int i = addNamedPara(paramString);
/* 6156 */     setCursorInternal(i, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 6166 */     int i = addNamedPara(paramString);
/* 6167 */     setCustomDatumInternal(i, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/* 6177 */     int i = addNamedPara(paramString);
/* 6178 */     setDATEInternal(i, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/* 6188 */     int i = addNamedPara(paramString1);
/* 6189 */     setFixedCHARInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 6199 */     int i = addNamedPara(paramString);
/* 6200 */     setINTERVALDSInternal(i, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 6210 */     int i = addNamedPara(paramString);
/* 6211 */     setINTERVALYMInternal(i, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 6221 */     int i = addNamedPara(paramString);
/* 6222 */     setNUMBERInternal(i, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 6232 */     int i = addNamedPara(paramString);
/* 6233 */     setOPAQUEInternal(i, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/* 6243 */     int i = addNamedPara(paramString);
/* 6244 */     setOracleObjectInternal(i, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/* 6254 */     int i = addNamedPara(paramString);
/* 6255 */     setORADataInternal(i, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/* 6265 */     int i = addNamedPara(paramString);
/* 6266 */     setRAWInternal(i, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/* 6276 */     int i = addNamedPara(paramString);
/* 6277 */     setREFInternal(i, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/* 6287 */     int i = addNamedPara(paramString);
/* 6288 */     setRefTypeInternal(i, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/* 6298 */     int i = addNamedPara(paramString);
/* 6299 */     setROWIDInternal(i, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 6309 */     int i = addNamedPara(paramString);
/* 6310 */     setSTRUCTInternal(i, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 6320 */     int i = addNamedPara(paramString);
/* 6321 */     setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 6331 */     int i = addNamedPara(paramString);
/* 6332 */     setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 6342 */     int i = addNamedPara(paramString);
/* 6343 */     setTIMESTAMPInternal(i, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
/* 6353 */     int i = addNamedPara(paramString);
/* 6354 */     setBlobInternal(i, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6363 */     if (paramLong < 0L) {
/*      */       
/* 6365 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 6366 */       sQLException.fillInStackTrace();
/* 6367 */       throw sQLException;
/*      */     } 
/*      */     
/* 6370 */     int i = addNamedPara(paramString);
/* 6371 */     setBlobInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader) throws SQLException {
/* 6381 */     int i = addNamedPara(paramString);
/* 6382 */     setClobInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6392 */     if (paramLong < 0L) {
/*      */       
/* 6394 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 6395 */       sQLException.fillInStackTrace();
/* 6396 */       throw sQLException;
/*      */     } 
/* 6398 */     int i = addNamedPara(paramString);
/* 6399 */     setClobInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader) throws SQLException {
/* 6409 */     int i = addNamedPara(paramString);
/* 6410 */     setNClobInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6420 */     int i = addNamedPara(paramString);
/* 6421 */     setNClobInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 6431 */     int i = addNamedPara(paramString);
/* 6432 */     setAsciiStreamInternal(i, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6442 */     int i = addNamedPara(paramString);
/* 6443 */     setAsciiStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6453 */     int i = addNamedPara(paramString);
/* 6454 */     setAsciiStreamInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 6464 */     int i = addNamedPara(paramString);
/* 6465 */     setBinaryStreamInternal(i, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6475 */     int i = addNamedPara(paramString);
/* 6476 */     setBinaryStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6486 */     int i = addNamedPara(paramString);
/* 6487 */     setBinaryStreamInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 6497 */     int i = addNamedPara(paramString);
/* 6498 */     setCharacterStreamInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 6508 */     int i = addNamedPara(paramString);
/* 6509 */     setCharacterStreamInternal(i, paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6519 */     int i = addNamedPara(paramString);
/* 6520 */     setCharacterStreamInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 6530 */     int i = addNamedPara(paramString);
/* 6531 */     setNCharacterStreamInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6541 */     int i = addNamedPara(paramString);
/* 6542 */     setNCharacterStreamInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6552 */     int i = addNamedPara(paramString);
/* 6553 */     setUnicodeStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 6564 */     int i = addNamedPara(paramString1);
/* 6565 */     setNullInternal(i, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/* 6576 */     int i = addNamedPara(paramString);
/* 6577 */     setNullInternal(i, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 6586 */     int i = addNamedPara(paramString);
/* 6587 */     setStructDescriptorInternal(i, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 6598 */     int i = addNamedPara(paramString);
/* 6599 */     setObjectInternal(i, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/* 6611 */     synchronized (this.connection) {
/*      */       
/* 6613 */       this.atLeastOneOrdinalParameter = true;
/* 6614 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int addNamedPara(String paramString) throws SQLException {
/* 6632 */     if (this.closed) {
/*      */       
/* 6634 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6635 */       sQLException.fillInStackTrace();
/* 6636 */       throw sQLException;
/*      */     } 
/*      */     
/* 6639 */     String str = paramString.toUpperCase().intern();
/*      */     
/* 6641 */     for (byte b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6643 */       if (str == this.namedParameters[b]) {
/* 6644 */         return b + 1;
/*      */       }
/*      */     } 
/* 6647 */     if (this.parameterCount >= this.namedParameters.length) {
/*      */       
/* 6649 */       String[] arrayOfString = new String[this.namedParameters.length * 2];
/* 6650 */       System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
/* 6651 */       this.namedParameters = arrayOfString;
/*      */     } 
/*      */     
/* 6654 */     this.namedParameters[this.parameterCount++] = str;
/*      */     
/* 6656 */     this.atLeastOneNamedParameter = true;
/* 6657 */     return this.parameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 6667 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6670 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6671 */       sQLException.fillInStackTrace();
/* 6672 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6676 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6679 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6681 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6684 */     b++;
/*      */     
/* 6686 */     Accessor accessor = null;
/* 6687 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6692 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6693 */       sQLException.fillInStackTrace();
/* 6694 */       throw sQLException;
/*      */     } 
/*      */     
/* 6697 */     this.lastIndex = b;
/*      */     
/* 6699 */     if (this.streamList != null) {
/* 6700 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6703 */     return accessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 6711 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6714 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6715 */       sQLException.fillInStackTrace();
/* 6716 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6720 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6723 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6725 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6728 */     b++;
/*      */     
/* 6730 */     Accessor accessor = null;
/* 6731 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6736 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6737 */       sQLException.fillInStackTrace();
/* 6738 */       throw sQLException;
/*      */     } 
/*      */     
/* 6741 */     this.lastIndex = b;
/*      */     
/* 6743 */     if (this.streamList != null) {
/* 6744 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6747 */     return accessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 6755 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6758 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6759 */       sQLException.fillInStackTrace();
/* 6760 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6764 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6767 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6769 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6772 */     b++;
/*      */     
/* 6774 */     Accessor accessor = null;
/* 6775 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6780 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6781 */       sQLException.fillInStackTrace();
/* 6782 */       throw sQLException;
/*      */     } 
/*      */     
/* 6785 */     this.lastIndex = b;
/*      */     
/* 6787 */     if (this.streamList != null) {
/* 6788 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6791 */     return accessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 6804 */     if (this.closed) {
/*      */       
/* 6806 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6807 */       sQLException.fillInStackTrace();
/* 6808 */       throw sQLException;
/*      */     } 
/*      */     
/* 6811 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6814 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6815 */       sQLException.fillInStackTrace();
/* 6816 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6820 */     Accessor accessor = null;
/* 6821 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6827 */       sQLException.fillInStackTrace();
/* 6828 */       throw sQLException;
/*      */     } 
/*      */     
/* 6831 */     this.lastIndex = paramInt;
/*      */     
/* 6833 */     if (this.streamList != null) {
/* 6834 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 6837 */     return (RowId)accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(String paramString) throws SQLException {
/* 6845 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6848 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6849 */       sQLException.fillInStackTrace();
/* 6850 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6854 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6857 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6859 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6862 */     b++;
/*      */     
/* 6864 */     Accessor accessor = null;
/* 6865 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6870 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6871 */       sQLException.fillInStackTrace();
/* 6872 */       throw sQLException;
/*      */     } 
/*      */     
/* 6875 */     this.lastIndex = b;
/*      */     
/* 6877 */     if (this.streamList != null) {
/* 6878 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6881 */     return (RowId)accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 6890 */     if (this.closed) {
/*      */       
/* 6892 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6893 */       sQLException.fillInStackTrace();
/* 6894 */       throw sQLException;
/*      */     } 
/*      */     
/* 6897 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6900 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6901 */       sQLException.fillInStackTrace();
/* 6902 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6906 */     Accessor accessor = null;
/* 6907 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6912 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6913 */       sQLException.fillInStackTrace();
/* 6914 */       throw sQLException;
/*      */     } 
/*      */     
/* 6917 */     this.lastIndex = paramInt;
/*      */     
/* 6919 */     if (this.streamList != null) {
/* 6920 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 6923 */     return accessor.getNClob(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(String paramString) throws SQLException {
/* 6931 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6934 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6935 */       sQLException.fillInStackTrace();
/* 6936 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6940 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6943 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6945 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6948 */     b++;
/*      */     
/* 6950 */     Accessor accessor = null;
/* 6951 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6956 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6957 */       sQLException.fillInStackTrace();
/* 6958 */       throw sQLException;
/*      */     } 
/*      */     
/* 6961 */     this.lastIndex = b;
/*      */     
/* 6963 */     if (this.streamList != null) {
/* 6964 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6967 */     return accessor.getNClob(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 6975 */     if (this.closed) {
/*      */       
/* 6977 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6978 */       sQLException.fillInStackTrace();
/* 6979 */       throw sQLException;
/*      */     } 
/*      */     
/* 6982 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6985 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6986 */       sQLException.fillInStackTrace();
/* 6987 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6991 */     Accessor accessor = null;
/* 6992 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6997 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6998 */       sQLException.fillInStackTrace();
/* 6999 */       throw sQLException;
/*      */     } 
/*      */     
/* 7002 */     this.lastIndex = paramInt;
/*      */     
/* 7004 */     if (this.streamList != null) {
/* 7005 */       closeUsedStreams(paramInt);
/*      */     }
/* 7007 */     return accessor.getSQLXML(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(String paramString) throws SQLException {
/* 7015 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7019 */       sQLException.fillInStackTrace();
/* 7020 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7024 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 7027 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 7029 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 7032 */     b++;
/*      */     
/* 7034 */     Accessor accessor = null;
/* 7035 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7040 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7041 */       sQLException.fillInStackTrace();
/* 7042 */       throw sQLException;
/*      */     } 
/*      */     
/* 7045 */     this.lastIndex = b;
/*      */     
/* 7047 */     if (this.streamList != null) {
/* 7048 */       closeUsedStreams(b);
/*      */     }
/* 7050 */     return accessor.getSQLXML(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 7059 */     if (this.closed) {
/*      */       
/* 7061 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 7062 */       sQLException.fillInStackTrace();
/* 7063 */       throw sQLException;
/*      */     } 
/*      */     
/* 7066 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7069 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7070 */       sQLException.fillInStackTrace();
/* 7071 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7075 */     Accessor accessor = null;
/* 7076 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7081 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 7082 */       sQLException.fillInStackTrace();
/* 7083 */       throw sQLException;
/*      */     } 
/*      */     
/* 7086 */     this.lastIndex = paramInt;
/*      */     
/* 7088 */     if (this.streamList != null) {
/* 7089 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 7092 */     return accessor.getNString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(String paramString) throws SQLException {
/* 7100 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7103 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7104 */       sQLException.fillInStackTrace();
/* 7105 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7109 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 7112 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 7114 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 7117 */     b++;
/*      */     
/* 7119 */     Accessor accessor = null;
/* 7120 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7125 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7126 */       sQLException.fillInStackTrace();
/* 7127 */       throw sQLException;
/*      */     } 
/*      */     
/* 7130 */     this.lastIndex = b;
/*      */     
/* 7132 */     if (this.streamList != null) {
/* 7133 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 7136 */     return accessor.getNString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 7145 */     if (this.closed) {
/*      */       
/* 7147 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 7148 */       sQLException.fillInStackTrace();
/* 7149 */       throw sQLException;
/*      */     } 
/*      */     
/* 7152 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7155 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7156 */       sQLException.fillInStackTrace();
/* 7157 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7161 */     Accessor accessor = null;
/* 7162 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7167 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 7168 */       sQLException.fillInStackTrace();
/* 7169 */       throw sQLException;
/*      */     } 
/*      */     
/* 7172 */     this.lastIndex = paramInt;
/*      */     
/* 7174 */     if (this.streamList != null) {
/* 7175 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 7178 */     return accessor.getNCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(String paramString) throws SQLException {
/* 7186 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7189 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7190 */       sQLException.fillInStackTrace();
/* 7191 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7195 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 7198 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 7200 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 7203 */     b++;
/*      */     
/* 7205 */     Accessor accessor = null;
/* 7206 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7211 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7212 */       sQLException.fillInStackTrace();
/* 7213 */       throw sQLException;
/*      */     } 
/*      */     
/* 7216 */     this.lastIndex = b;
/*      */     
/* 7218 */     if (this.streamList != null) {
/* 7219 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 7222 */     return accessor.getNCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7229 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\OracleCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */