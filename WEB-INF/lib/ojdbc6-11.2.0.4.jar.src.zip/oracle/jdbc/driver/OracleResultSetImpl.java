/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleResultSetImpl
/*      */   extends BaseResultSet
/*      */ {
/*      */   PhysicalConnection connection;
/*      */   OracleStatement statement;
/*      */   boolean explicitly_closed;
/*      */   boolean m_emptyRset;
/*      */   boolean isServerCursorPeeked = false;
/*      */   
/*      */   OracleResultSetImpl(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement) throws SQLException {
/*   70 */     this.connection = paramPhysicalConnection;
/*   71 */     this.statement = paramOracleStatement;
/*   72 */     this.close_statement_on_close = false;
/*   73 */     this.explicitly_closed = false;
/*   74 */     this.m_emptyRset = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/*   84 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*   87 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/*   88 */       sQLException.fillInStackTrace();
/*   89 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  101 */     synchronized (this.connection) {
/*      */       
/*  103 */       internal_close(false);
/*  104 */       this.statement.totalRowsVisited = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  111 */       this.statement.closeCursorOnPlainStatement();
/*      */ 
/*      */       
/*  114 */       if (this.close_statement_on_close) {
/*      */         
/*      */         try {
/*      */           
/*  118 */           this.statement.close();
/*      */         }
/*  120 */         catch (SQLException sQLException) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  125 */       this.explicitly_closed = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  132 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  135 */       if (this.explicitly_closed) {
/*      */         
/*  137 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "wasNull");
/*  138 */         sQLException.fillInStackTrace();
/*  139 */         throw sQLException;
/*      */       } 
/*      */       
/*  142 */       if (this.statement.closed) {
/*      */         
/*  144 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "wasNull");
/*  145 */         sQLException.fillInStackTrace();
/*  146 */         throw sQLException;
/*      */       } 
/*      */       
/*  149 */       return this.statement.wasNullValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  156 */     synchronized (this.connection) {
/*      */       
/*  158 */       if (this.explicitly_closed) {
/*      */         
/*  160 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
/*  161 */         sQLException.fillInStackTrace();
/*  162 */         throw sQLException;
/*      */       } 
/*      */       
/*  165 */       if (this.statement.closed) {
/*      */         
/*  167 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
/*  168 */         sQLException.fillInStackTrace();
/*  169 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  175 */       if (!this.statement.isOpen) {
/*      */         
/*  177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144, "getMetaData");
/*  178 */         sQLException.fillInStackTrace();
/*  179 */         throw sQLException;
/*      */       } 
/*      */       
/*  182 */       return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, this.statement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  190 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/*  194 */       return (this.statement.wrapper == null) ? (Statement)this.statement : (Statement)this.statement.wrapper;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/*  205 */     synchronized (this.connection) {
/*      */       
/*  207 */       return this.statement;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  226 */     synchronized (this.connection) {
/*      */       
/*  228 */       boolean bool = true;
/*      */       
/*  230 */       this.isServerCursorPeeked = true;
/*      */ 
/*      */       
/*  233 */       PhysicalConnection physicalConnection = this.statement.connection;
/*      */       
/*  235 */       if (this.explicitly_closed) {
/*      */         
/*  237 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
/*  238 */         sQLException.fillInStackTrace();
/*  239 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  244 */       if (physicalConnection == null || physicalConnection.lifecycle != 1) {
/*      */         
/*  246 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "next");
/*  247 */         sQLException.fillInStackTrace();
/*  248 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  253 */       if (this.statement.closed) {
/*      */         
/*  255 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "next");
/*  256 */         sQLException.fillInStackTrace();
/*  257 */         throw sQLException;
/*      */       } 
/*      */       
/*  260 */       if (this.statement.sqlKind.isPlsqlOrCall()) {
/*      */         
/*  262 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 166, "next");
/*  263 */         sQLException.fillInStackTrace();
/*  264 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  269 */       if (this.closed) {
/*  270 */         return false;
/*      */       }
/*  272 */       this.statement.currentRow++;
/*  273 */       this.statement.totalRowsVisited++;
/*      */       
/*  275 */       if (this.statement.maxRows != 0 && this.statement.totalRowsVisited > this.statement.maxRows) {
/*      */ 
/*      */         
/*  278 */         internal_close(false);
/*  279 */         this.statement.currentRow--;
/*  280 */         this.statement.totalRowsVisited = 0;
/*      */         
/*  282 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 275);
/*      */         
/*  284 */         return false;
/*      */       } 
/*      */       
/*  287 */       if (this.statement.currentRow >= this.statement.validRows) {
/*  288 */         bool = close_or_fetch_from_next(false);
/*      */       }
/*  290 */       if (bool && physicalConnection.useFetchSizeWithLongColumn) {
/*  291 */         this.statement.reopenStreams();
/*      */       }
/*  293 */       if (!bool) {
/*      */         
/*  295 */         this.statement.currentRow--;
/*  296 */         this.statement.totalRowsVisited = 0;
/*      */       } 
/*      */       
/*  299 */       return bool;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean close_or_fetch_from_next(boolean paramBoolean) throws SQLException {
/*  310 */     if (paramBoolean) {
/*      */       
/*  312 */       internal_close(false);
/*      */       
/*  314 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     if (this.statement.gotLastBatch) {
/*      */       
/*  323 */       internal_close(false);
/*      */       
/*  325 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  332 */     this.statement.check_row_prefetch_changed();
/*      */     
/*  334 */     PhysicalConnection physicalConnection = this.statement.connection;
/*      */     
/*  336 */     if (physicalConnection.protocolId == 3) {
/*  337 */       this.sqlWarning = null;
/*      */     }
/*      */     else {
/*      */       
/*  341 */       if (this.statement.streamList != null)
/*      */       {
/*      */ 
/*      */         
/*  345 */         while (this.statement.nextStream != null) {
/*      */ 
/*      */           
/*      */           try {
/*  349 */             this.statement.nextStream.close();
/*      */           }
/*  351 */           catch (IOException iOException) {
/*      */ 
/*      */             
/*  354 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  355 */             sQLException.fillInStackTrace();
/*  356 */             throw sQLException;
/*      */           } 
/*      */ 
/*      */           
/*  360 */           this.statement.nextStream = this.statement.nextStream.nextStream;
/*      */         } 
/*      */       }
/*      */       
/*  364 */       clearWarnings();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  373 */       physicalConnection.registerHeartbeat();
/*      */       
/*  375 */       physicalConnection.needLine();
/*      */     } 
/*      */ 
/*      */     
/*  379 */     synchronized (physicalConnection) {
/*      */ 
/*      */       
/*      */       try {
/*  383 */         this.statement.cancelLock.enterExecuting();
/*  384 */         this.statement.fetch();
/*      */       } finally {
/*      */         
/*  387 */         this.statement.cancelLock.exitExecuting();
/*      */       } 
/*      */     } 
/*      */     
/*  391 */     if (this.statement.validRows == 0) {
/*      */       
/*  393 */       internal_close(false);
/*      */       
/*  395 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  399 */     this.statement.currentRow = 0;
/*      */     
/*  401 */     this.statement.checkValidRowsStatus();
/*      */     
/*  403 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/*  415 */     if (this.explicitly_closed) {
/*      */       
/*  417 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  418 */       sQLException.fillInStackTrace();
/*  419 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  423 */     if (this.statement.connection.protocolId == 3 && this.statement.serverCursor) {
/*      */       
/*  425 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  426 */       sQLException.fillInStackTrace();
/*  427 */       throw sQLException;
/*      */     } 
/*      */     
/*  430 */     return (!isEmptyResultSet() && this.statement.currentRow == -1 && !this.closed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/*  437 */     if (this.explicitly_closed) {
/*      */       
/*  439 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  440 */       sQLException.fillInStackTrace();
/*  441 */       throw sQLException;
/*      */     } 
/*      */     
/*  444 */     return (!isEmptyResultSet() && this.closed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/*  451 */     if (this.explicitly_closed) {
/*      */       
/*  453 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  454 */       sQLException.fillInStackTrace();
/*  455 */       throw sQLException;
/*      */     } 
/*  457 */     return (getRow() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/*  464 */     if (this.explicitly_closed) {
/*      */       
/*  466 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  467 */       sQLException1.fillInStackTrace();
/*  468 */       throw sQLException1;
/*      */     } 
/*      */     
/*  471 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "isLast");
/*  472 */     sQLException.fillInStackTrace();
/*  473 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/*  481 */     if (this.explicitly_closed) {
/*      */       
/*  483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  484 */       sQLException.fillInStackTrace();
/*  485 */       throw sQLException;
/*      */     } 
/*  487 */     return this.statement.totalRowsVisited;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/*  505 */     synchronized (this.connection) {
/*      */       
/*  507 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  515 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  518 */       if (this.closed) {
/*      */         
/*  520 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  521 */         sQLException.fillInStackTrace();
/*  522 */         throw sQLException;
/*      */       } 
/*      */       
/*  525 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  527 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  528 */         sQLException.fillInStackTrace();
/*  529 */         throw sQLException;
/*      */       } 
/*      */       
/*  532 */       int i = this.statement.currentRow;
/*      */       
/*  534 */       if (i < 0) {
/*      */         
/*  536 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  537 */         sQLException.fillInStackTrace();
/*  538 */         throw sQLException;
/*      */       } 
/*      */       
/*  541 */       this.statement.lastIndex = paramInt;
/*      */       
/*  543 */       if (this.statement.streamList != null)
/*      */       {
/*  545 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  548 */       return this.statement.accessors[paramInt - 1].getBigDecimal(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  556 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  559 */       if (this.closed) {
/*      */         
/*  561 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  562 */         sQLException.fillInStackTrace();
/*  563 */         throw sQLException;
/*      */       } 
/*      */       
/*  566 */       if (paramInt1 <= 0 || paramInt1 > this.statement.numberOfDefinePositions) {
/*      */         
/*  568 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  569 */         sQLException.fillInStackTrace();
/*  570 */         throw sQLException;
/*      */       } 
/*      */       
/*  573 */       int i = this.statement.currentRow;
/*      */       
/*  575 */       if (i < 0) {
/*      */         
/*  577 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  578 */         sQLException.fillInStackTrace();
/*  579 */         throw sQLException;
/*      */       } 
/*      */       
/*  582 */       this.statement.lastIndex = paramInt1;
/*      */       
/*  584 */       if (this.statement.streamList != null)
/*      */       {
/*  586 */         this.statement.closeUsedStreams(paramInt1);
/*      */       }
/*      */       
/*  589 */       return this.statement.accessors[paramInt1 - 1].getBigDecimal(i, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/*  597 */     synchronized (this.connection) {
/*      */       
/*  599 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  607 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  610 */       if (this.closed) {
/*      */         
/*  612 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  613 */         sQLException.fillInStackTrace();
/*  614 */         throw sQLException;
/*      */       } 
/*      */       
/*  617 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  619 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  620 */         sQLException.fillInStackTrace();
/*  621 */         throw sQLException;
/*      */       } 
/*      */       
/*  624 */       int i = this.statement.currentRow;
/*      */       
/*  626 */       if (i < 0) {
/*      */         
/*  628 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  629 */         sQLException.fillInStackTrace();
/*  630 */         throw sQLException;
/*      */       } 
/*      */       
/*  633 */       this.statement.lastIndex = paramInt;
/*      */       
/*  635 */       if (this.statement.streamList != null)
/*      */       {
/*  637 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  640 */       return this.statement.accessors[paramInt - 1].getBoolean(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  648 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  651 */       if (this.closed) {
/*      */         
/*  653 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  654 */         sQLException.fillInStackTrace();
/*  655 */         throw sQLException;
/*      */       } 
/*      */       
/*  658 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  660 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  661 */         sQLException.fillInStackTrace();
/*  662 */         throw sQLException;
/*      */       } 
/*      */       
/*  665 */       int i = this.statement.currentRow;
/*      */       
/*  667 */       if (i < 0) {
/*      */         
/*  669 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  670 */         sQLException.fillInStackTrace();
/*  671 */         throw sQLException;
/*      */       } 
/*      */       
/*  674 */       this.statement.lastIndex = paramInt;
/*      */       
/*  676 */       if (this.statement.streamList != null)
/*      */       {
/*  678 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  681 */       return this.statement.accessors[paramInt - 1].getByte(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  689 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  692 */       if (this.closed) {
/*      */         
/*  694 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  695 */         sQLException.fillInStackTrace();
/*  696 */         throw sQLException;
/*      */       } 
/*      */       
/*  699 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  701 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  702 */         sQLException.fillInStackTrace();
/*  703 */         throw sQLException;
/*      */       } 
/*      */       
/*  706 */       int i = this.statement.currentRow;
/*      */       
/*  708 */       if (i < 0) {
/*      */         
/*  710 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  711 */         sQLException.fillInStackTrace();
/*  712 */         throw sQLException;
/*      */       } 
/*      */       
/*  715 */       this.statement.lastIndex = paramInt;
/*      */       
/*  717 */       if (this.statement.streamList != null)
/*      */       {
/*  719 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  722 */       return this.statement.accessors[paramInt - 1].getBytes(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/*  730 */     synchronized (this.connection) {
/*      */       
/*  732 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  740 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  743 */       if (this.closed) {
/*      */         
/*  745 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  746 */         sQLException.fillInStackTrace();
/*  747 */         throw sQLException;
/*      */       } 
/*      */       
/*  750 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  752 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  753 */         sQLException.fillInStackTrace();
/*  754 */         throw sQLException;
/*      */       } 
/*      */       
/*  757 */       int i = this.statement.currentRow;
/*      */       
/*  759 */       if (i < 0) {
/*      */         
/*  761 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  762 */         sQLException.fillInStackTrace();
/*  763 */         throw sQLException;
/*      */       } 
/*      */       
/*  766 */       this.statement.lastIndex = paramInt;
/*      */       
/*  768 */       if (this.statement.streamList != null)
/*      */       {
/*  770 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  773 */       return this.statement.accessors[paramInt - 1].getDate(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  781 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  784 */       if (this.closed) {
/*      */         
/*  786 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  787 */         sQLException.fillInStackTrace();
/*  788 */         throw sQLException;
/*      */       } 
/*      */       
/*  791 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  793 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  794 */         sQLException.fillInStackTrace();
/*  795 */         throw sQLException;
/*      */       } 
/*      */       
/*  798 */       int i = this.statement.currentRow;
/*      */       
/*  800 */       if (i < 0) {
/*      */         
/*  802 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  803 */         sQLException.fillInStackTrace();
/*  804 */         throw sQLException;
/*      */       } 
/*      */       
/*  807 */       this.statement.lastIndex = paramInt;
/*      */       
/*  809 */       if (this.statement.streamList != null)
/*      */       {
/*  811 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  814 */       return this.statement.accessors[paramInt - 1].getDate(i, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  822 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  825 */       if (this.closed) {
/*      */         
/*  827 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  828 */         sQLException.fillInStackTrace();
/*  829 */         throw sQLException;
/*      */       } 
/*      */       
/*  832 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  834 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  835 */         sQLException.fillInStackTrace();
/*  836 */         throw sQLException;
/*      */       } 
/*      */       
/*  839 */       int i = this.statement.currentRow;
/*      */       
/*  841 */       if (i < 0) {
/*      */         
/*  843 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  844 */         sQLException.fillInStackTrace();
/*  845 */         throw sQLException;
/*      */       } 
/*      */       
/*  848 */       this.statement.lastIndex = paramInt;
/*      */       
/*  850 */       if (this.statement.streamList != null)
/*      */       {
/*  852 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  855 */       return this.statement.accessors[paramInt - 1].getDouble(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  863 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  866 */       if (this.closed) {
/*      */         
/*  868 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  869 */         sQLException.fillInStackTrace();
/*  870 */         throw sQLException;
/*      */       } 
/*      */       
/*  873 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  875 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  876 */         sQLException.fillInStackTrace();
/*  877 */         throw sQLException;
/*      */       } 
/*      */       
/*  880 */       int i = this.statement.currentRow;
/*      */       
/*  882 */       if (i < 0) {
/*      */         
/*  884 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  885 */         sQLException.fillInStackTrace();
/*  886 */         throw sQLException;
/*      */       } 
/*      */       
/*  889 */       this.statement.lastIndex = paramInt;
/*      */       
/*  891 */       if (this.statement.streamList != null)
/*      */       {
/*  893 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  896 */       return this.statement.accessors[paramInt - 1].getFloat(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  909 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  912 */       if (this.closed) {
/*      */         
/*  914 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  915 */         sQLException.fillInStackTrace();
/*  916 */         throw sQLException;
/*      */       } 
/*      */       
/*  919 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  921 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  922 */         sQLException.fillInStackTrace();
/*  923 */         throw sQLException;
/*      */       } 
/*      */       
/*  926 */       int i = this.statement.currentRow;
/*      */       
/*  928 */       if (i < 0) {
/*      */         
/*  930 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  931 */         sQLException.fillInStackTrace();
/*  932 */         throw sQLException;
/*      */       } 
/*      */       
/*  935 */       this.statement.lastIndex = paramInt;
/*      */       
/*  937 */       if (this.statement.streamList != null)
/*      */       {
/*  939 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  942 */       return this.statement.accessors[paramInt - 1].getInt(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  952 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  955 */       if (this.closed) {
/*      */         
/*  957 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  958 */         sQLException.fillInStackTrace();
/*  959 */         throw sQLException;
/*      */       } 
/*      */       
/*  962 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  964 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  965 */         sQLException.fillInStackTrace();
/*  966 */         throw sQLException;
/*      */       } 
/*      */       
/*  969 */       int i = this.statement.currentRow;
/*      */       
/*  971 */       if (i < 0) {
/*      */         
/*  973 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  974 */         sQLException.fillInStackTrace();
/*  975 */         throw sQLException;
/*      */       } 
/*      */       
/*  978 */       this.statement.lastIndex = paramInt;
/*      */       
/*  980 */       if (this.statement.streamList != null)
/*      */       {
/*  982 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  985 */       return this.statement.accessors[paramInt - 1].getLong(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/*  993 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  996 */       if (this.closed) {
/*      */         
/*  998 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  999 */         sQLException.fillInStackTrace();
/* 1000 */         throw sQLException;
/*      */       } 
/*      */       
/* 1003 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1005 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1006 */         sQLException.fillInStackTrace();
/* 1007 */         throw sQLException;
/*      */       } 
/*      */       
/* 1010 */       int i = this.statement.currentRow;
/*      */       
/* 1012 */       if (i < 0) {
/*      */         
/* 1014 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1015 */         sQLException.fillInStackTrace();
/* 1016 */         throw sQLException;
/*      */       } 
/*      */       
/* 1019 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1021 */       if (this.statement.streamList != null)
/*      */       {
/* 1023 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1026 */       return this.statement.accessors[paramInt - 1].getNClob(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 1034 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1037 */       if (this.closed) {
/*      */         
/* 1039 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1040 */         sQLException.fillInStackTrace();
/* 1041 */         throw sQLException;
/*      */       } 
/*      */       
/* 1044 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1046 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1047 */         sQLException.fillInStackTrace();
/* 1048 */         throw sQLException;
/*      */       } 
/*      */       
/* 1051 */       int i = this.statement.currentRow;
/*      */       
/* 1053 */       if (i < 0) {
/*      */         
/* 1055 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1056 */         sQLException.fillInStackTrace();
/* 1057 */         throw sQLException;
/*      */       } 
/*      */       
/* 1060 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1062 */       if (this.statement.streamList != null)
/*      */       {
/* 1064 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1067 */       return this.statement.accessors[paramInt - 1].getNString(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 1075 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1078 */       if (this.closed) {
/*      */         
/* 1080 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1081 */         sQLException.fillInStackTrace();
/* 1082 */         throw sQLException;
/*      */       } 
/*      */       
/* 1085 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1087 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1088 */         sQLException.fillInStackTrace();
/* 1089 */         throw sQLException;
/*      */       } 
/*      */       
/* 1092 */       int i = this.statement.currentRow;
/*      */       
/* 1094 */       if (i < 0) {
/*      */         
/* 1096 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1097 */         sQLException.fillInStackTrace();
/* 1098 */         throw sQLException;
/*      */       } 
/*      */       
/* 1101 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1103 */       if (this.statement.streamList != null)
/*      */       {
/* 1105 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1108 */       return this.statement.accessors[paramInt - 1].getObject(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1116 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1119 */       if (this.closed) {
/*      */         
/* 1121 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1122 */         sQLException.fillInStackTrace();
/* 1123 */         throw sQLException;
/*      */       } 
/*      */       
/* 1126 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1128 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1129 */         sQLException.fillInStackTrace();
/* 1130 */         throw sQLException;
/*      */       } 
/*      */       
/* 1133 */       int i = this.statement.currentRow;
/*      */       
/* 1135 */       if (i < 0) {
/*      */         
/* 1137 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1138 */         sQLException.fillInStackTrace();
/* 1139 */         throw sQLException;
/*      */       } 
/*      */       
/* 1142 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1144 */       if (this.statement.streamList != null)
/*      */       {
/* 1146 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1149 */       return this.statement.accessors[paramInt - 1].getObject(i, paramMap);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1157 */     synchronized (this.connection) {
/*      */       
/* 1159 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 1167 */     synchronized (this.connection) {
/*      */       
/* 1169 */       return (RowId)getROWID(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 1177 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1180 */       if (this.closed) {
/*      */         
/* 1182 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1183 */         sQLException.fillInStackTrace();
/* 1184 */         throw sQLException;
/*      */       } 
/*      */       
/* 1187 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1189 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1190 */         sQLException.fillInStackTrace();
/* 1191 */         throw sQLException;
/*      */       } 
/*      */       
/* 1194 */       int i = this.statement.currentRow;
/*      */       
/* 1196 */       if (i < 0) {
/*      */         
/* 1198 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1199 */         sQLException.fillInStackTrace();
/* 1200 */         throw sQLException;
/*      */       } 
/*      */       
/* 1203 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1205 */       if (this.statement.streamList != null)
/*      */       {
/* 1207 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1210 */       return this.statement.accessors[paramInt - 1].getShort(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 1218 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1221 */       if (this.closed) {
/*      */         
/* 1223 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1224 */         sQLException.fillInStackTrace();
/* 1225 */         throw sQLException;
/*      */       } 
/*      */       
/* 1228 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1230 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1231 */         sQLException.fillInStackTrace();
/* 1232 */         throw sQLException;
/*      */       } 
/*      */       
/* 1235 */       int i = this.statement.currentRow;
/*      */       
/* 1237 */       if (i < 0) {
/*      */         
/* 1239 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1240 */         sQLException.fillInStackTrace();
/* 1241 */         throw sQLException;
/*      */       } 
/*      */       
/* 1244 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1246 */       if (this.statement.streamList != null)
/*      */       {
/* 1248 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1251 */       return this.statement.accessors[paramInt - 1].getSQLXML(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/* 1264 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1267 */       if (this.closed) {
/*      */         
/* 1269 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1270 */         sQLException.fillInStackTrace();
/* 1271 */         throw sQLException;
/*      */       } 
/*      */       
/* 1274 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1276 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1277 */         sQLException.fillInStackTrace();
/* 1278 */         throw sQLException;
/*      */       } 
/*      */       
/* 1281 */       int i = this.statement.currentRow;
/*      */       
/* 1283 */       if (i < 0) {
/*      */         
/* 1285 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1286 */         sQLException.fillInStackTrace();
/* 1287 */         throw sQLException;
/*      */       } 
/*      */       
/* 1290 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1292 */       if (this.statement.streamList != null)
/*      */       {
/* 1294 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1297 */       return this.statement.accessors[paramInt - 1].getString(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 1307 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1310 */       if (this.closed) {
/*      */         
/* 1312 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1313 */         sQLException.fillInStackTrace();
/* 1314 */         throw sQLException;
/*      */       } 
/*      */       
/* 1317 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1319 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1320 */         sQLException.fillInStackTrace();
/* 1321 */         throw sQLException;
/*      */       } 
/*      */       
/* 1324 */       int i = this.statement.currentRow;
/*      */       
/* 1326 */       if (i < 0) {
/*      */         
/* 1328 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1329 */         sQLException.fillInStackTrace();
/* 1330 */         throw sQLException;
/*      */       } 
/*      */       
/* 1333 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1335 */       if (this.statement.streamList != null)
/*      */       {
/* 1337 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1340 */       return this.statement.accessors[paramInt - 1].getTime(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1348 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1351 */       if (this.closed) {
/*      */         
/* 1353 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1354 */         sQLException.fillInStackTrace();
/* 1355 */         throw sQLException;
/*      */       } 
/*      */       
/* 1358 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1360 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1361 */         sQLException.fillInStackTrace();
/* 1362 */         throw sQLException;
/*      */       } 
/*      */       
/* 1365 */       int i = this.statement.currentRow;
/*      */       
/* 1367 */       if (i < 0) {
/*      */         
/* 1369 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1370 */         sQLException.fillInStackTrace();
/* 1371 */         throw sQLException;
/*      */       } 
/*      */       
/* 1374 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1376 */       if (this.statement.streamList != null)
/*      */       {
/* 1378 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1381 */       return this.statement.accessors[paramInt - 1].getTime(i, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 1389 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1392 */       if (this.closed) {
/*      */         
/* 1394 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1395 */         sQLException.fillInStackTrace();
/* 1396 */         throw sQLException;
/*      */       } 
/*      */       
/* 1399 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1401 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1402 */         sQLException.fillInStackTrace();
/* 1403 */         throw sQLException;
/*      */       } 
/*      */       
/* 1406 */       int i = this.statement.currentRow;
/*      */       
/* 1408 */       if (i < 0) {
/*      */         
/* 1410 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1411 */         sQLException.fillInStackTrace();
/* 1412 */         throw sQLException;
/*      */       } 
/*      */       
/* 1415 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1417 */       if (this.statement.streamList != null)
/*      */       {
/* 1419 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1422 */       return this.statement.accessors[paramInt - 1].getTimestamp(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1430 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1433 */       if (this.closed) {
/*      */         
/* 1435 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1436 */         sQLException.fillInStackTrace();
/* 1437 */         throw sQLException;
/*      */       } 
/*      */       
/* 1440 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1442 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1443 */         sQLException.fillInStackTrace();
/* 1444 */         throw sQLException;
/*      */       } 
/*      */       
/* 1447 */       int i = this.statement.currentRow;
/*      */       
/* 1449 */       if (i < 0) {
/*      */         
/* 1451 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1452 */         sQLException.fillInStackTrace();
/* 1453 */         throw sQLException;
/*      */       } 
/*      */       
/* 1456 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1458 */       if (this.statement.streamList != null)
/*      */       {
/* 1460 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1463 */       return this.statement.accessors[paramInt - 1].getTimestamp(i, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1471 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1474 */       if (this.closed) {
/*      */         
/* 1476 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1477 */         sQLException.fillInStackTrace();
/* 1478 */         throw sQLException;
/*      */       } 
/*      */       
/* 1481 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1483 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1484 */         sQLException.fillInStackTrace();
/* 1485 */         throw sQLException;
/*      */       } 
/*      */       
/* 1488 */       int i = this.statement.currentRow;
/*      */       
/* 1490 */       if (i < 0) {
/*      */         
/* 1492 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1493 */         sQLException.fillInStackTrace();
/* 1494 */         throw sQLException;
/*      */       } 
/*      */       
/* 1497 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1499 */       if (this.statement.streamList != null)
/*      */       {
/* 1501 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1504 */       return this.statement.accessors[paramInt - 1].getURL(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 1512 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1515 */       if (this.closed) {
/*      */         
/* 1517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1518 */         sQLException.fillInStackTrace();
/* 1519 */         throw sQLException;
/*      */       } 
/*      */       
/* 1522 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1524 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1525 */         sQLException.fillInStackTrace();
/* 1526 */         throw sQLException;
/*      */       } 
/*      */       
/* 1529 */       int i = this.statement.currentRow;
/*      */       
/* 1531 */       if (i < 0) {
/*      */         
/* 1533 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1534 */         sQLException.fillInStackTrace();
/* 1535 */         throw sQLException;
/*      */       } 
/*      */       
/* 1538 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1540 */       if (this.statement.streamList != null)
/*      */       {
/* 1542 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1545 */       return this.statement.accessors[paramInt - 1].getARRAY(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1553 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1556 */       if (this.closed) {
/*      */         
/* 1558 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1559 */         sQLException.fillInStackTrace();
/* 1560 */         throw sQLException;
/*      */       } 
/*      */       
/* 1563 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1565 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1566 */         sQLException.fillInStackTrace();
/* 1567 */         throw sQLException;
/*      */       } 
/*      */       
/* 1570 */       int i = this.statement.currentRow;
/*      */       
/* 1572 */       if (i < 0) {
/*      */         
/* 1574 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1575 */         sQLException.fillInStackTrace();
/* 1576 */         throw sQLException;
/*      */       } 
/*      */       
/* 1579 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1581 */       if (this.statement.streamList != null)
/*      */       {
/* 1583 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1586 */       return this.statement.accessors[paramInt - 1].getBFILE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1594 */     synchronized (this.connection) {
/*      */       
/* 1596 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1604 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1607 */       if (this.closed) {
/*      */         
/* 1609 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1610 */         sQLException.fillInStackTrace();
/* 1611 */         throw sQLException;
/*      */       } 
/*      */       
/* 1614 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1616 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1617 */         sQLException.fillInStackTrace();
/* 1618 */         throw sQLException;
/*      */       } 
/*      */       
/* 1621 */       int i = this.statement.currentRow;
/*      */       
/* 1623 */       if (i < 0) {
/*      */         
/* 1625 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1626 */         sQLException.fillInStackTrace();
/* 1627 */         throw sQLException;
/*      */       } 
/*      */       
/* 1630 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1632 */       if (this.statement.streamList != null)
/*      */       {
/* 1634 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1637 */       return this.statement.accessors[paramInt - 1].getBLOB(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1645 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1648 */       if (this.closed) {
/*      */         
/* 1650 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1651 */         sQLException.fillInStackTrace();
/* 1652 */         throw sQLException;
/*      */       } 
/*      */       
/* 1655 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1657 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1658 */         sQLException.fillInStackTrace();
/* 1659 */         throw sQLException;
/*      */       } 
/*      */       
/* 1662 */       int i = this.statement.currentRow;
/*      */       
/* 1664 */       if (i < 0) {
/*      */         
/* 1666 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1667 */         sQLException.fillInStackTrace();
/* 1668 */         throw sQLException;
/*      */       } 
/*      */       
/* 1671 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1673 */       if (this.statement.streamList != null)
/*      */       {
/* 1675 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1678 */       return this.statement.accessors[paramInt - 1].getCHAR(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1686 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1689 */       if (this.closed) {
/*      */         
/* 1691 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1692 */         sQLException.fillInStackTrace();
/* 1693 */         throw sQLException;
/*      */       } 
/*      */       
/* 1696 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1698 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1699 */         sQLException.fillInStackTrace();
/* 1700 */         throw sQLException;
/*      */       } 
/*      */       
/* 1703 */       int i = this.statement.currentRow;
/*      */       
/* 1705 */       if (i < 0) {
/*      */         
/* 1707 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1708 */         sQLException.fillInStackTrace();
/* 1709 */         throw sQLException;
/*      */       } 
/*      */       
/* 1712 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1714 */       if (this.statement.streamList != null)
/*      */       {
/* 1716 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1719 */       return this.statement.accessors[paramInt - 1].getCLOB(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 1727 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1730 */       if (this.closed) {
/*      */         
/* 1732 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1733 */         sQLException.fillInStackTrace();
/* 1734 */         throw sQLException;
/*      */       } 
/*      */       
/* 1737 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1739 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1740 */         sQLException.fillInStackTrace();
/* 1741 */         throw sQLException;
/*      */       } 
/*      */       
/* 1744 */       int i = this.statement.currentRow;
/*      */       
/* 1746 */       if (i < 0) {
/*      */         
/* 1748 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1749 */         sQLException.fillInStackTrace();
/* 1750 */         throw sQLException;
/*      */       } 
/*      */       
/* 1753 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1755 */       if (this.statement.streamList != null)
/*      */       {
/* 1757 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1760 */       return this.statement.accessors[paramInt - 1].getCursor(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1768 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1771 */       if (this.closed) {
/*      */         
/* 1773 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1774 */         sQLException.fillInStackTrace();
/* 1775 */         throw sQLException;
/*      */       } 
/*      */       
/* 1778 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1780 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1781 */         sQLException.fillInStackTrace();
/* 1782 */         throw sQLException;
/*      */       } 
/*      */       
/* 1785 */       int i = this.statement.currentRow;
/*      */       
/* 1787 */       if (i < 0) {
/*      */         
/* 1789 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1790 */         sQLException.fillInStackTrace();
/* 1791 */         throw sQLException;
/*      */       } 
/*      */       
/* 1794 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1796 */       if (this.statement.streamList != null)
/*      */       {
/* 1798 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1801 */       return this.statement.accessors[paramInt - 1].getCustomDatum(i, paramCustomDatumFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 1809 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1812 */       if (this.closed) {
/*      */         
/* 1814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1815 */         sQLException.fillInStackTrace();
/* 1816 */         throw sQLException;
/*      */       } 
/*      */       
/* 1819 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1821 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1822 */         sQLException.fillInStackTrace();
/* 1823 */         throw sQLException;
/*      */       } 
/*      */       
/* 1826 */       int i = this.statement.currentRow;
/*      */       
/* 1828 */       if (i < 0) {
/*      */         
/* 1830 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1831 */         sQLException.fillInStackTrace();
/* 1832 */         throw sQLException;
/*      */       } 
/*      */       
/* 1835 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1837 */       if (this.statement.streamList != null)
/*      */       {
/* 1839 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1842 */       return this.statement.accessors[paramInt - 1].getDATE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1850 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1853 */       if (this.closed) {
/*      */         
/* 1855 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1856 */         sQLException.fillInStackTrace();
/* 1857 */         throw sQLException;
/*      */       } 
/*      */       
/* 1860 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1862 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1863 */         sQLException.fillInStackTrace();
/* 1864 */         throw sQLException;
/*      */       } 
/*      */       
/* 1867 */       int i = this.statement.currentRow;
/*      */       
/* 1869 */       if (i < 0) {
/*      */         
/* 1871 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1872 */         sQLException.fillInStackTrace();
/* 1873 */         throw sQLException;
/*      */       } 
/*      */       
/* 1876 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1878 */       if (this.statement.streamList != null)
/*      */       {
/* 1880 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1883 */       return this.statement.accessors[paramInt - 1].getINTERVALDS(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1891 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1894 */       if (this.closed) {
/*      */         
/* 1896 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1897 */         sQLException.fillInStackTrace();
/* 1898 */         throw sQLException;
/*      */       } 
/*      */       
/* 1901 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1903 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1904 */         sQLException.fillInStackTrace();
/* 1905 */         throw sQLException;
/*      */       } 
/*      */       
/* 1908 */       int i = this.statement.currentRow;
/*      */       
/* 1910 */       if (i < 0) {
/*      */         
/* 1912 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1913 */         sQLException.fillInStackTrace();
/* 1914 */         throw sQLException;
/*      */       } 
/*      */       
/* 1917 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1919 */       if (this.statement.streamList != null)
/*      */       {
/* 1921 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1924 */       return this.statement.accessors[paramInt - 1].getINTERVALYM(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1932 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1935 */       if (this.closed) {
/*      */         
/* 1937 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1938 */         sQLException.fillInStackTrace();
/* 1939 */         throw sQLException;
/*      */       } 
/*      */       
/* 1942 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1944 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1945 */         sQLException.fillInStackTrace();
/* 1946 */         throw sQLException;
/*      */       } 
/*      */       
/* 1949 */       int i = this.statement.currentRow;
/*      */       
/* 1951 */       if (i < 0) {
/*      */         
/* 1953 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1954 */         sQLException.fillInStackTrace();
/* 1955 */         throw sQLException;
/*      */       } 
/*      */       
/* 1958 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1960 */       if (this.statement.streamList != null)
/*      */       {
/* 1962 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1965 */       return this.statement.accessors[paramInt - 1].getNUMBER(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1973 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1976 */       if (this.closed) {
/*      */         
/* 1978 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1979 */         sQLException.fillInStackTrace();
/* 1980 */         throw sQLException;
/*      */       } 
/*      */       
/* 1983 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1985 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1986 */         sQLException.fillInStackTrace();
/* 1987 */         throw sQLException;
/*      */       } 
/*      */       
/* 1990 */       int i = this.statement.currentRow;
/*      */       
/* 1992 */       if (i < 0) {
/*      */         
/* 1994 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1995 */         sQLException.fillInStackTrace();
/* 1996 */         throw sQLException;
/*      */       } 
/*      */       
/* 1999 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2001 */       if (this.statement.streamList != null)
/*      */       {
/* 2003 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2006 */       return this.statement.accessors[paramInt - 1].getOPAQUE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/* 2014 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2017 */       if (this.closed) {
/*      */         
/* 2019 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2020 */         sQLException.fillInStackTrace();
/* 2021 */         throw sQLException;
/*      */       } 
/*      */       
/* 2024 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2026 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2027 */         sQLException.fillInStackTrace();
/* 2028 */         throw sQLException;
/*      */       } 
/*      */       
/* 2031 */       int i = this.statement.currentRow;
/*      */       
/* 2033 */       if (i < 0) {
/*      */         
/* 2035 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2036 */         sQLException.fillInStackTrace();
/* 2037 */         throw sQLException;
/*      */       } 
/*      */       
/* 2040 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2042 */       if (this.statement.streamList != null)
/*      */       {
/* 2044 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2047 */       return this.statement.accessors[paramInt - 1].getOracleObject(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 2055 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2058 */       if (this.closed) {
/*      */         
/* 2060 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2061 */         sQLException.fillInStackTrace();
/* 2062 */         throw sQLException;
/*      */       } 
/*      */       
/* 2065 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2067 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2068 */         sQLException.fillInStackTrace();
/* 2069 */         throw sQLException;
/*      */       } 
/*      */       
/* 2072 */       int i = this.statement.currentRow;
/*      */       
/* 2074 */       if (i < 0) {
/*      */         
/* 2076 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2077 */         sQLException.fillInStackTrace();
/* 2078 */         throw sQLException;
/*      */       } 
/*      */       
/* 2081 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2083 */       if (this.statement.streamList != null)
/*      */       {
/* 2085 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2088 */       return this.statement.accessors[paramInt - 1].getORAData(i, paramORADataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 2096 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2099 */       if (this.closed) {
/*      */         
/* 2101 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2102 */         sQLException.fillInStackTrace();
/* 2103 */         throw sQLException;
/*      */       } 
/*      */       
/* 2106 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2108 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2109 */         sQLException.fillInStackTrace();
/* 2110 */         throw sQLException;
/*      */       } 
/*      */       
/* 2113 */       int i = this.statement.currentRow;
/*      */       
/* 2115 */       if (i < 0) {
/*      */         
/* 2117 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2118 */         sQLException.fillInStackTrace();
/* 2119 */         throw sQLException;
/*      */       } 
/*      */       
/* 2122 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2124 */       if (this.statement.streamList != null)
/*      */       {
/* 2126 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2129 */       return this.statement.accessors[paramInt - 1].getObject(i, paramOracleDataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 2137 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2140 */       if (this.closed) {
/*      */         
/* 2142 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2143 */         sQLException.fillInStackTrace();
/* 2144 */         throw sQLException;
/*      */       } 
/*      */       
/* 2147 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2149 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2150 */         sQLException.fillInStackTrace();
/* 2151 */         throw sQLException;
/*      */       } 
/*      */       
/* 2154 */       int i = this.statement.currentRow;
/*      */       
/* 2156 */       if (i < 0) {
/*      */         
/* 2158 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2159 */         sQLException.fillInStackTrace();
/* 2160 */         throw sQLException;
/*      */       } 
/*      */       
/* 2163 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2165 */       if (this.statement.streamList != null)
/*      */       {
/* 2167 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2170 */       return this.statement.accessors[paramInt - 1].getRAW(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 2178 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2181 */       if (this.closed) {
/*      */         
/* 2183 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2184 */         sQLException.fillInStackTrace();
/* 2185 */         throw sQLException;
/*      */       } 
/*      */       
/* 2188 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2190 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2191 */         sQLException.fillInStackTrace();
/* 2192 */         throw sQLException;
/*      */       } 
/*      */       
/* 2195 */       int i = this.statement.currentRow;
/*      */       
/* 2197 */       if (i < 0) {
/*      */         
/* 2199 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2200 */         sQLException.fillInStackTrace();
/* 2201 */         throw sQLException;
/*      */       } 
/*      */       
/* 2204 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2206 */       if (this.statement.streamList != null)
/*      */       {
/* 2208 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2211 */       return this.statement.accessors[paramInt - 1].getREF(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 2219 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2222 */       if (this.closed) {
/*      */         
/* 2224 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2225 */         sQLException.fillInStackTrace();
/* 2226 */         throw sQLException;
/*      */       } 
/*      */       
/* 2229 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2231 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2232 */         sQLException.fillInStackTrace();
/* 2233 */         throw sQLException;
/*      */       } 
/*      */       
/* 2236 */       int i = this.statement.currentRow;
/*      */       
/* 2238 */       if (i < 0) {
/*      */         
/* 2240 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2241 */         sQLException.fillInStackTrace();
/* 2242 */         throw sQLException;
/*      */       } 
/*      */       
/* 2245 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2247 */       if (this.statement.streamList != null)
/*      */       {
/* 2249 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2252 */       return this.statement.accessors[paramInt - 1].getROWID(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 2260 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2263 */       if (this.closed) {
/*      */         
/* 2265 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2266 */         sQLException.fillInStackTrace();
/* 2267 */         throw sQLException;
/*      */       } 
/*      */       
/* 2270 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2272 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2273 */         sQLException.fillInStackTrace();
/* 2274 */         throw sQLException;
/*      */       } 
/*      */       
/* 2277 */       int i = this.statement.currentRow;
/*      */       
/* 2279 */       if (i < 0) {
/*      */         
/* 2281 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2282 */         sQLException.fillInStackTrace();
/* 2283 */         throw sQLException;
/*      */       } 
/*      */       
/* 2286 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2288 */       if (this.statement.streamList != null)
/*      */       {
/* 2290 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2293 */       return this.statement.accessors[paramInt - 1].getSTRUCT(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 2301 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2304 */       if (this.closed) {
/*      */         
/* 2306 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2307 */         sQLException.fillInStackTrace();
/* 2308 */         throw sQLException;
/*      */       } 
/*      */       
/* 2311 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2313 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2314 */         sQLException.fillInStackTrace();
/* 2315 */         throw sQLException;
/*      */       } 
/*      */       
/* 2318 */       int i = this.statement.currentRow;
/*      */       
/* 2320 */       if (i < 0) {
/*      */         
/* 2322 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2323 */         sQLException.fillInStackTrace();
/* 2324 */         throw sQLException;
/*      */       } 
/*      */       
/* 2327 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2329 */       if (this.statement.streamList != null)
/*      */       {
/* 2331 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2334 */       return this.statement.accessors[paramInt - 1].getTIMESTAMPLTZ(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 2342 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2345 */       if (this.closed) {
/*      */         
/* 2347 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2348 */         sQLException.fillInStackTrace();
/* 2349 */         throw sQLException;
/*      */       } 
/*      */       
/* 2352 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2354 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2355 */         sQLException.fillInStackTrace();
/* 2356 */         throw sQLException;
/*      */       } 
/*      */       
/* 2359 */       int i = this.statement.currentRow;
/*      */       
/* 2361 */       if (i < 0) {
/*      */         
/* 2363 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2364 */         sQLException.fillInStackTrace();
/* 2365 */         throw sQLException;
/*      */       } 
/*      */       
/* 2368 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2370 */       if (this.statement.streamList != null)
/*      */       {
/* 2372 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2375 */       return this.statement.accessors[paramInt - 1].getTIMESTAMPTZ(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 2383 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2386 */       if (this.closed) {
/*      */         
/* 2388 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2389 */         sQLException.fillInStackTrace();
/* 2390 */         throw sQLException;
/*      */       } 
/*      */       
/* 2393 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2395 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2396 */         sQLException.fillInStackTrace();
/* 2397 */         throw sQLException;
/*      */       } 
/*      */       
/* 2400 */       int i = this.statement.currentRow;
/*      */       
/* 2402 */       if (i < 0) {
/*      */         
/* 2404 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2405 */         sQLException.fillInStackTrace();
/* 2406 */         throw sQLException;
/*      */       } 
/*      */       
/* 2409 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2411 */       if (this.statement.streamList != null)
/*      */       {
/* 2413 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2416 */       return this.statement.accessors[paramInt - 1].getTIMESTAMP(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 2424 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2427 */       if (this.closed) {
/*      */         
/* 2429 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2430 */         sQLException.fillInStackTrace();
/* 2431 */         throw sQLException;
/*      */       } 
/*      */       
/* 2434 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2436 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2437 */         sQLException.fillInStackTrace();
/* 2438 */         throw sQLException;
/*      */       } 
/*      */       
/* 2441 */       int i = this.statement.currentRow;
/*      */       
/* 2443 */       if (i < 0) {
/*      */         
/* 2445 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2446 */         sQLException.fillInStackTrace();
/* 2447 */         throw sQLException;
/*      */       } 
/*      */       
/* 2450 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2452 */       if (this.statement.streamList != null)
/*      */       {
/* 2454 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2457 */       return this.statement.accessors[paramInt - 1].getAsciiStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 2465 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2468 */       if (this.closed) {
/*      */         
/* 2470 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2471 */         sQLException.fillInStackTrace();
/* 2472 */         throw sQLException;
/*      */       } 
/*      */       
/* 2475 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2477 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2478 */         sQLException.fillInStackTrace();
/* 2479 */         throw sQLException;
/*      */       } 
/*      */       
/* 2482 */       int i = this.statement.currentRow;
/*      */       
/* 2484 */       if (i < 0) {
/*      */         
/* 2486 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2487 */         sQLException.fillInStackTrace();
/* 2488 */         throw sQLException;
/*      */       } 
/*      */       
/* 2491 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2493 */       if (this.statement.streamList != null)
/*      */       {
/* 2495 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2498 */       return this.statement.accessors[paramInt - 1].getBinaryStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 2506 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2509 */       if (this.closed) {
/*      */         
/* 2511 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2512 */         sQLException.fillInStackTrace();
/* 2513 */         throw sQLException;
/*      */       } 
/*      */       
/* 2516 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2518 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2519 */         sQLException.fillInStackTrace();
/* 2520 */         throw sQLException;
/*      */       } 
/*      */       
/* 2523 */       int i = this.statement.currentRow;
/*      */       
/* 2525 */       if (i < 0) {
/*      */         
/* 2527 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2528 */         sQLException.fillInStackTrace();
/* 2529 */         throw sQLException;
/*      */       } 
/*      */       
/* 2532 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2534 */       if (this.statement.streamList != null)
/*      */       {
/* 2536 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2539 */       return this.statement.accessors[paramInt - 1].getCharacterStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 2547 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2550 */       if (this.closed) {
/*      */         
/* 2552 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2553 */         sQLException.fillInStackTrace();
/* 2554 */         throw sQLException;
/*      */       } 
/*      */       
/* 2557 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2559 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2560 */         sQLException.fillInStackTrace();
/* 2561 */         throw sQLException;
/*      */       } 
/*      */       
/* 2564 */       int i = this.statement.currentRow;
/*      */       
/* 2566 */       if (i < 0) {
/*      */         
/* 2568 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2569 */         sQLException.fillInStackTrace();
/* 2570 */         throw sQLException;
/*      */       } 
/*      */       
/* 2573 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2575 */       if (this.statement.streamList != null)
/*      */       {
/* 2577 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2580 */       return this.statement.accessors[paramInt - 1].getNCharacterStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 2588 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2591 */       if (this.closed) {
/*      */         
/* 2593 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2594 */         sQLException.fillInStackTrace();
/* 2595 */         throw sQLException;
/*      */       } 
/*      */       
/* 2598 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2600 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2601 */         sQLException.fillInStackTrace();
/* 2602 */         throw sQLException;
/*      */       } 
/*      */       
/* 2605 */       int i = this.statement.currentRow;
/*      */       
/* 2607 */       if (i < 0) {
/*      */         
/* 2609 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2610 */         sQLException.fillInStackTrace();
/* 2611 */         throw sQLException;
/*      */       } 
/*      */       
/* 2614 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2616 */       if (this.statement.streamList != null)
/*      */       {
/* 2618 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2621 */       return this.statement.accessors[paramInt - 1].getUnicodeStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/* 2633 */     synchronized (this.connection) {
/*      */       
/* 2635 */       if (this.closed) {
/*      */         
/* 2637 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2638 */         sQLException.fillInStackTrace();
/* 2639 */         throw sQLException;
/*      */       } 
/*      */       
/* 2642 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2644 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2645 */         sQLException.fillInStackTrace();
/* 2646 */         throw sQLException;
/*      */       } 
/*      */       
/* 2649 */       int i = this.statement.currentRow;
/*      */       
/* 2651 */       if (i < 0) {
/*      */         
/* 2653 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2654 */         sQLException.fillInStackTrace();
/* 2655 */         throw sQLException;
/*      */       } 
/*      */       
/* 2658 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2660 */       if (this.statement.streamList != null)
/*      */       {
/* 2662 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/* 2664 */       return this.statement.accessors[paramInt - 1].getAuthorizationIndicator(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] privateGetBytes(int paramInt) throws SQLException {
/* 2681 */     synchronized (this.connection) {
/*      */       
/* 2683 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2685 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2686 */         sQLException.fillInStackTrace();
/* 2687 */         throw sQLException;
/*      */       } 
/*      */       
/* 2690 */       if (this.closed) {
/*      */         
/* 2692 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2693 */         sQLException.fillInStackTrace();
/* 2694 */         throw sQLException;
/*      */       } 
/*      */       
/* 2697 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2699 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2700 */         sQLException.fillInStackTrace();
/* 2701 */         throw sQLException;
/*      */       } 
/*      */       
/* 2704 */       int i = this.statement.currentRow;
/*      */       
/* 2706 */       if (i < 0) {
/*      */         
/* 2708 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2709 */         sQLException.fillInStackTrace();
/* 2710 */         throw sQLException;
/*      */       } 
/*      */       
/* 2713 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2715 */       if (this.statement.streamList != null)
/*      */       {
/* 2717 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */ 
/*      */       
/* 2721 */       return this.statement.accessors[paramInt - 1].privateGetBytes(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 2735 */     this.statement.setPrefetchInternal(paramInt, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2743 */     return this.statement.getPrefetchInternal(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internal_close(boolean paramBoolean) throws SQLException {
/* 2754 */     if (this.closed)
/*      */       return; 
/* 2756 */     super.close();
/*      */     
/* 2758 */     if (this.statement.gotLastBatch && this.statement.validRows == 0) {
/* 2759 */       this.m_emptyRset = true;
/*      */     }
/*      */     
/* 2762 */     PhysicalConnection physicalConnection = this.statement.connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2773 */       physicalConnection.registerHeartbeat();
/*      */ 
/*      */       
/* 2776 */       physicalConnection.needLine();
/*      */       
/* 2778 */       synchronized (physicalConnection)
/*      */       {
/*      */         
/* 2781 */         this.statement.closeQuery();
/*      */       }
/*      */     
/* 2784 */     } catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2790 */     this.statement.endOfResultSet(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 2797 */     synchronized (this.connection) {
/*      */       
/* 2799 */       return this.statement.getColumnIndex(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isEmptyResultSet() throws SQLException {
/* 2816 */     if (this.statement != null && !this.statement.closed && this.statement.serverCursor && this.statement.connection.protocolId != 3 && !this.isServerCursorPeeked && !this.closed) {
/*      */ 
/*      */ 
/*      */       
/* 2820 */       close_or_fetch_from_next(false);
/*      */       
/* 2822 */       if (this.statement.validRows > 0) {
/* 2823 */         this.statement.currentRow = -1;
/*      */       } else {
/* 2825 */         this.m_emptyRset = true;
/*      */       } 
/* 2827 */       this.isServerCursorPeeked = true;
/*      */     } 
/*      */     
/* 2830 */     return (this.m_emptyRset || (!this.m_emptyRset && this.statement.gotLastBatch && this.statement.validRows == 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getValidRows() {
/* 2839 */     return this.statement.validRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2854 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2859 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\OracleResultSetImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */