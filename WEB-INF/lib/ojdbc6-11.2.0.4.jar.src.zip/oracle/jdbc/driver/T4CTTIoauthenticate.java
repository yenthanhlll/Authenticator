/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.net.ano.AuthenticationService;
/*      */ import oracle.security.o3logon.O3LoginClientHelper;
/*      */ import oracle.security.o5logon.O5Logon;
/*      */ import oracle.sql.ZONEIDMAP;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4CTTIoauthenticate
/*      */   extends T4CTTIfun
/*      */ {
/*      */   byte[] terminal;
/*      */   byte[] enableTempLobRefCnt;
/*      */   byte[] machine;
/*      */   byte[] sysUserName;
/*      */   byte[] processID;
/*      */   byte[] programName;
/*      */   byte[] encryptedSK;
/*      */   byte[] internalName;
/*      */   byte[] externalName;
/*      */   byte[] alterSession;
/*      */   byte[] aclValue;
/*      */   byte[] clientname;
/*   86 */   byte[] editionName = null;
/*      */   
/*      */   byte[] driverName;
/*      */   
/*      */   String ressourceManagerId;
/*      */   
/*      */   boolean bUseO5Logon;
/*      */   
/*      */   int verifierType;
/*      */   
/*      */   static final int ZTVT_ORCL_7 = 2361;
/*      */   
/*      */   static final int ZTVT_SSH1 = 6949;
/*      */   
/*      */   static final int ZTVT_NTV = 7809;
/*      */   
/*      */   static final int ZTVT_SMD5 = 59694;
/*      */   
/*      */   static final int ZTVT_MD5 = 40674;
/*      */   
/*      */   static final int ZTVT_SH1 = 45394;
/*      */   
/*      */   byte[] salt;
/*      */   
/*      */   byte[] encryptedKB;
/*      */   
/*      */   boolean isSessionTZ = true;
/*      */   
/*      */   static final int SERVER_VERSION_81 = 8100;
/*      */   
/*      */   static final int KPZ_LOGON = 1;
/*      */   
/*      */   static final int KPZ_CPW = 2;
/*      */   
/*      */   static final int KPZ_SRVAUTH = 4;
/*      */   
/*      */   static final int KPZ_ENCRYPTED_PASSWD = 256;
/*      */   
/*      */   static final int KPZ_LOGON_MIGRATE = 16;
/*      */   
/*      */   static final int KPZ_LOGON_SYSDBA = 32;
/*      */   
/*      */   static final int KPZ_LOGON_SYSOPER = 64;
/*      */   
/*      */   static final int KPZ_LOGON_PRELIMAUTH = 128;
/*      */   
/*      */   static final int KPZ_PASSWD_ENCRYPTED = 256;
/*      */   
/*      */   static final int KPZ_LOGON_DBCONC = 512;
/*      */   
/*      */   static final int KPZ_PROXY_AUTH = 1024;
/*      */   
/*      */   static final int KPZ_SESSION_CACHE = 2048;
/*      */   
/*      */   static final int KPZ_PASSWD_IS_VFR = 4096;
/*      */   
/*      */   static final int KPZ_LOGON_SYSASM = 4194304;
/*      */   
/*      */   static final int KPZ_SESSION_QCACHE = 8388608;
/*      */   
/*      */   static final int KPZ_LOGON_SYSBKP = 16777216;
/*      */   
/*      */   static final int KPZ_LOGON_SYSDGD = 33554432;
/*      */   
/*      */   static final int KPZ_LOGON_SYSKMT = 67108864;
/*      */   
/*      */   static final String AUTH_TERMINAL = "AUTH_TERMINAL";
/*      */   
/*      */   static final String AUTH_PROGRAM_NM = "AUTH_PROGRAM_NM";
/*      */   
/*      */   static final String AUTH_MACHINE = "AUTH_MACHINE";
/*      */   
/*      */   static final String AUTH_PID = "AUTH_PID";
/*      */   
/*      */   static final String AUTH_SID = "AUTH_SID";
/*      */   
/*      */   static final String AUTH_SESSKEY = "AUTH_SESSKEY";
/*      */   
/*      */   static final String AUTH_VFR_DATA = "AUTH_VFR_DATA";
/*      */   
/*      */   static final String AUTH_PASSWORD = "AUTH_PASSWORD";
/*      */   
/*      */   static final String AUTH_INTERNALNAME = "AUTH_INTERNALNAME_";
/*      */   static final String AUTH_EXTERNALNAME = "AUTH_EXTERNALNAME_";
/*      */   static final String AUTH_ACL = "AUTH_ACL";
/*      */   static final String AUTH_ALTER_SESSION = "AUTH_ALTER_SESSION";
/*      */   static final String AUTH_INITIAL_CLIENT_ROLE = "INITIAL_CLIENT_ROLE";
/*      */   static final String AUTH_VERSION_SQL = "AUTH_VERSION_SQL";
/*      */   static final String AUTH_VERSION_NO = "AUTH_VERSION_NO";
/*      */   static final String AUTH_XACTION_TRAITS = "AUTH_XACTION_TRAITS";
/*      */   static final String AUTH_VERSION_STATUS = "AUTH_VERSION_STATUS";
/*      */   static final String AUTH_SERIAL_NUM = "AUTH_SERIAL_NUM";
/*      */   static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
/*      */   static final String AUTH_CLIENT_CERTIFICATE = "AUTH_CLIENT_CERTIFICATE";
/*      */   static final String AUTH_PROXY_CLIENT_NAME = "PROXY_CLIENT_NAME";
/*      */   static final String AUTH_CLIENT_DN = "AUTH_CLIENT_DISTINGUISHED_NAME";
/*      */   static final String AUTH_INSTANCENAME = "AUTH_INSTANCENAME";
/*      */   static final String AUTH_DBNAME = "AUTH_DBNAME";
/*      */   static final String AUTH_INSTANCE_NO = "AUTH_INSTANCE_NO";
/*      */   static final String AUTH_SC_SERVER_HOST = "AUTH_SC_SERVER_HOST";
/*      */   static final String AUTH_SC_INSTANCE_NAME = "AUTH_SC_INSTANCE_NAME";
/*      */   static final String AUTH_SC_INSTANCE_ID = "AUTH_SC_INSTANCE_ID";
/*      */   static final String AUTH_SC_INSTANCE_START_TIME = "AUTH_SC_INSTANCE_START_TIME";
/*      */   static final String AUTH_SC_DBUNIQUE_NAME = "AUTH_SC_DBUNIQUE_NAME";
/*      */   static final String AUTH_SC_SERVICE_NAME = "AUTH_SC_SERVICE_NAME";
/*      */   static final String AUTH_SC_SVC_FLAGS = "AUTH_SC_SVC_FLAGS";
/*      */   static final String AUTH_SESSION_CLIENT_CSET = "SESSION_CLIENT_CHARSET";
/*      */   static final String AUTH_SESSION_CLIENT_LTYPE = "SESSION_CLIENT_LIB_TYPE";
/*      */   static final String AUTH_SESSION_CLIENT_DRVNM = "SESSION_CLIENT_DRIVER_NAME";
/*      */   static final String AUTH_SESSION_CLIENT_VSN = "SESSION_CLIENT_VERSION";
/*      */   static final String AUTH_NLS_LXLAN = "AUTH_NLS_LXLAN";
/*      */   static final String AUTH_NLS_LXCTERRITORY = "AUTH_NLS_LXCTERRITORY";
/*      */   static final String AUTH_NLS_LXCCURRENCY = "AUTH_NLS_LXCCURRENCY";
/*      */   static final String AUTH_NLS_LXCISOCURR = "AUTH_NLS_LXCISOCURR";
/*      */   static final String AUTH_NLS_LXCNUMERICS = "AUTH_NLS_LXCNUMERICS";
/*      */   static final String AUTH_NLS_LXCDATEFM = "AUTH_NLS_LXCDATEFM";
/*      */   static final String AUTH_NLS_LXCDATELANG = "AUTH_NLS_LXCDATELANG";
/*      */   static final String AUTH_NLS_LXCSORT = "AUTH_NLS_LXCSORT";
/*      */   static final String AUTH_NLS_LXCCALENDAR = "AUTH_NLS_LXCCALENDAR";
/*      */   static final String AUTH_NLS_LXCUNIONCUR = "AUTH_NLS_LXCUNIONCUR";
/*      */   static final String AUTH_NLS_LXCTIMEFM = "AUTH_NLS_LXCTIMEFM";
/*      */   static final String AUTH_NLS_LXCSTMPFM = "AUTH_NLS_LXCSTMPFM";
/*      */   static final String AUTH_NLS_LXCTTZNFM = "AUTH_NLS_LXCTTZNFM";
/*      */   static final String AUTH_NLS_LXCSTZNFM = "AUTH_NLS_LXCSTZNFM";
/*      */   static final String SESSION_CLIENT_LOBATTR = "SESSION_CLIENT_LOBATTR";
/*      */   static final String DRIVER_NAME_DEFAULT = "jdbcthin";
/*      */   static final int KPU_LIB_UNKN = 0;
/*      */   static final int KPU_LIB_DEF = 1;
/*      */   static final int KPU_LIB_EI = 2;
/*      */   static final int KPU_LIB_XE = 3;
/*      */   static final int KPU_LIB_ICUS = 4;
/*      */   static final int KPU_LIB_OCI = 5;
/*      */   static final int KPU_LIB_THIN = 10;
/*      */   static final String AUTH_ORA_EDITION = "AUTH_ORA_EDITION";
/*      */   static final String AUTH_COPYRIGHT = "AUTH_COPYRIGHT";
/*      */   static final String COPYRIGHT_STR = "\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.";
/*      */   static final String SESSION_TIME_ZONE = "SESSION_TIME_ZONE";
/*      */   static final String SESSION_NLS_LXCCHARSET = "SESSION_NLS_LXCCHARSET";
/*      */   static final String SESSION_NLS_LXCNLSLENSEM = "SESSION_NLS_LXCNLSLENSEM";
/*      */   static final String SESSION_NLS_LXCNCHAREXCP = "SESSION_NLS_LXCNCHAREXCP";
/*      */   static final String SESSION_NLS_LXCNCHARIMP = "SESSION_NLS_LXCNCHARIMP";
/*  227 */   String sessionTimeZone = null;
/*  228 */   byte[] serverCompileTimeCapabilities = null;
/*      */   private T4CKvaldfList keyValList;
/*      */   private byte[] user; private long logonMode; private byte[][] outKeys; private byte[][] outValues; private int[] outFlags; private int outNbPairs; O5Logon o5logonHelper; void marshal() throws IOException { if (this.user != null && this.user.length > 0) { this.meg.marshalPTR(); this.meg.marshalSB4(this.user.length); } else { this.meg.marshalNULLPTR(); this.meg.marshalSB4(0); }  this.meg.marshalUB4(this.logonMode); this.meg.marshalPTR(); this.meg.marshalUB4(this.keyValList.size()); this.meg.marshalPTR(); this.meg.marshalPTR(); if (this.user != null && this.user.length > 0) this.meg.marshalCHR(this.user);  this.meg.marshalKEYVAL(this.keyValList.getKeys(), this.keyValList.getValues(), this.keyValList.getFlags(), this.keyValList.size()); } private void doOAUTH(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong, String paramString, boolean paramBoolean, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4, byte[][] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, SQLException { setFunCode((short)115); this.user = paramArrayOfbyte1; this.logonMode = paramLong | 0x1L; if (paramBoolean) this.logonMode |= 0x400L;  if (paramArrayOfbyte1 != null && paramArrayOfbyte1.length != 0 && paramArrayOfbyte2 != null && paramString != "RADIUS") this.logonMode |= 0x100L;  this.keyValList = new T4CKvaldfList(this.meg.conv); if (paramArrayOfbyte2 != null) this.keyValList.add("AUTH_PASSWORD", paramArrayOfbyte2);  if (paramArrayOfbyte != null) for (byte b = 0; b < paramArrayOfbyte.length; b++) this.keyValList.add("INITIAL_CLIENT_ROLE", paramArrayOfbyte[b]);   if (paramArrayOfbyte3 != null) this.keyValList.add("AUTH_CLIENT_DISTINGUISHED_NAME", paramArrayOfbyte3);  if (paramArrayOfbyte4 != null) this.keyValList.add("AUTH_CLIENT_CERTIFICATE", paramArrayOfbyte4);  this.keyValList.add("AUTH_TERMINAL", this.terminal); if (this.bUseO5Logon && this.encryptedKB != null) this.keyValList.add("AUTH_SESSKEY", this.encryptedKB, (byte)1);  if (this.programName != null) this.keyValList.add("AUTH_PROGRAM_NM", this.programName);  if (this.clientname != null)
/*      */       this.keyValList.add("PROXY_CLIENT_NAME", this.clientname);  this.keyValList.add("AUTH_MACHINE", this.machine); this.keyValList.add("AUTH_PID", this.processID); if (!this.ressourceManagerId.equals("0000")) { byte[] arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_INTERNALNAME_"); arrayOfByte[arrayOfByte.length - 1] = 0; this.keyValList.add(arrayOfByte, this.internalName); arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_EXTERNALNAME_"); arrayOfByte[arrayOfByte.length - 1] = 0; this.keyValList.add(arrayOfByte, this.externalName); }  this.keyValList.add("AUTH_ACL", this.aclValue); this.keyValList.add("AUTH_ALTER_SESSION", this.alterSession, (byte)1); if (this.editionName != null)
/*      */       this.keyValList.add("AUTH_ORA_EDITION", this.editionName);  this.keyValList.add("SESSION_CLIENT_LOBATTR", this.enableTempLobRefCnt); this.keyValList.add("SESSION_CLIENT_DRIVER_NAME", this.driverName); this.keyValList.add("SESSION_CLIENT_VERSION", this.meg.conv.StringToCharBytes(Integer.toString(versionStringToInt(this.connection.getMetaData().getDriverVersion()), 10))); if (paramInt1 != -1)
/*      */       this.keyValList.add("AUTH_SESSION_ID", this.meg.conv.StringToCharBytes(Integer.toString(paramInt1)));  if (paramInt2 != -1)
/*  234 */       this.keyValList.add("AUTH_SERIAL_NUM", this.meg.conv.StringToCharBytes(Integer.toString(paramInt2)));  this.keyValList.add("AUTH_COPYRIGHT", this.meg.conv.StringToCharBytes("\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.")); this.outNbPairs = 0; this.outKeys = (byte[][])null; this.outValues = (byte[][])null; this.outFlags = new int[0]; doRPC(); } T4CTTIoauthenticate(T4CConnection paramT4CConnection, String paramString, byte[] paramArrayOfbyte) throws SQLException { super(paramT4CConnection, (byte)3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  248 */     this.keyValList = null;
/*  249 */     this.user = null;
/*      */ 
/*      */ 
/*      */     
/*  253 */     this.outKeys = (byte[][])null;
/*  254 */     this.outValues = (byte[][])null;
/*  255 */     this.outFlags = new int[0];
/*  256 */     this.outNbPairs = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  582 */     this.o5logonHelper = new O5Logon(); this.ressourceManagerId = paramString; this.serverCompileTimeCapabilities = paramArrayOfbyte; setSessionFields(paramT4CConnection); this.isSessionTZ = true; this.bUseO5Logon = false; }
/*      */   void doOSESSKEY(String paramString, long paramLong) throws IOException, SQLException { setFunCode((short)118); this.user = this.meg.conv.StringToCharBytes(paramString); this.logonMode = paramLong | 0x1L; this.keyValList = new T4CKvaldfList(this.meg.conv); this.keyValList.add("AUTH_TERMINAL", this.terminal); if (this.programName != null)
/*      */       this.keyValList.add("AUTH_PROGRAM_NM", this.programName);  this.keyValList.add("AUTH_MACHINE", this.machine); this.keyValList.add("AUTH_PID", this.processID); this.keyValList.add("AUTH_SID", this.sysUserName); this.outNbPairs = 0; this.outKeys = (byte[][])null; this.outValues = (byte[][])null;
/*      */     this.outFlags = new int[0];
/*  586 */     doRPC(); } void doOAUTH(String paramString1, String paramString2, long paramLong) throws IOException, SQLException { byte[] arrayOfByte1 = null;
/*  587 */     if (paramString1 != null && paramString1.length() > 0) {
/*  588 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(paramString1);
/*      */     }
/*  590 */     byte[] arrayOfByte2 = null;
/*  591 */     byte[] arrayOfByte3 = null;
/*  592 */     byte[] arrayOfByte4 = null;
/*      */     
/*  594 */     String str = this.connection.net.getAuthenticationAdaptorName();
/*      */ 
/*      */ 
/*      */     
/*  598 */     if (paramString1 != null && paramString1.length() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  603 */       if (str != "RADIUS" && this.encryptedSK.length > 16 && !this.bUseO5Logon) {
/*      */ 
/*      */ 
/*      */         
/*  607 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  608 */         sQLException.fillInStackTrace();
/*  609 */         throw sQLException;
/*      */       } 
/*      */       
/*  612 */       if (this.bUseO5Logon && (this.encryptedSK == null || (this.encryptedSK.length != 64 && this.encryptedSK.length != 96))) {
/*      */ 
/*      */         
/*  615 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  616 */         sQLException.fillInStackTrace();
/*  617 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  627 */       String str1 = paramString1.trim();
/*  628 */       String str2 = null;
/*  629 */       if (paramString2 != null)
/*      */       {
/*      */         
/*  632 */         str2 = paramString2.trim();
/*      */       }
/*  634 */       paramString2 = null;
/*      */       
/*  636 */       String str3 = str1;
/*  637 */       String str4 = str2;
/*      */       
/*  639 */       if (str1.startsWith("\"") || str1.endsWith("\"")) {
/*  640 */         str3 = removeQuotes(str1);
/*      */       }
/*  642 */       if (str2 != null && (str2.startsWith("\"") || str2.endsWith("\"")))
/*      */       {
/*  644 */         str4 = removeQuotes(str2);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  650 */       if (str4 != null) {
/*  651 */         arrayOfByte2 = this.meg.conv.StringToCharBytes(str4);
/*      */       }
/*  653 */       if (str != "RADIUS") {
/*      */         
/*  655 */         if (arrayOfByte2 == null) {
/*      */           
/*  657 */           arrayOfByte4 = null;
/*      */         }
/*  659 */         else if (this.bUseO5Logon) {
/*      */           
/*  661 */           this.encryptedKB = new byte[this.encryptedSK.length];
/*  662 */           for (byte b1 = 0; b1 < this.encryptedKB.length; ) { this.encryptedKB[b1] = 1; b1++; }
/*  663 */            int[] arrayOfInt = new int[1];
/*  664 */           byte[] arrayOfByte = new byte[256];
/*  665 */           for (byte b2 = 0; b2 < 'Ā'; ) { arrayOfByte[b2] = 0; b2++; }
/*      */           
/*      */           try {
/*  668 */             this.o5logonHelper.generateOAuthResponse(this.verifierType, this.salt, str3, str4, arrayOfByte2, this.encryptedSK, this.encryptedKB, arrayOfByte, arrayOfInt, this.meg.conv.isServerCSMultiByte, this.serverCompileTimeCapabilities[4]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  681 */           catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  690 */           arrayOfByte4 = new byte[arrayOfInt[0]];
/*  691 */           System.arraycopy(arrayOfByte, 0, arrayOfByte4, 0, arrayOfInt[0]);
/*      */         } else {
/*      */           byte b;
/*      */           
/*  695 */           O3LoginClientHelper o3LoginClientHelper = new O3LoginClientHelper(this.meg.conv.isServerCSMultiByte);
/*      */           
/*  697 */           byte[] arrayOfByte5 = o3LoginClientHelper.getSessionKey(str3, str4, this.encryptedSK);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  703 */           if (arrayOfByte2.length % 8 > 0) {
/*  704 */             b = (byte)(8 - arrayOfByte2.length % 8);
/*      */           } else {
/*  706 */             b = 0;
/*      */           } 
/*  708 */           arrayOfByte3 = new byte[arrayOfByte2.length + b];
/*      */           
/*  710 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  715 */           byte[] arrayOfByte6 = o3LoginClientHelper.getEPasswd(arrayOfByte5, arrayOfByte3);
/*      */ 
/*      */           
/*  718 */           arrayOfByte4 = new byte[2 * arrayOfByte3.length + 1];
/*      */ 
/*      */           
/*  721 */           if (arrayOfByte4.length < 2 * arrayOfByte6.length) {
/*      */             
/*  723 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  724 */             sQLException.fillInStackTrace();
/*  725 */             throw sQLException;
/*      */           } 
/*      */           
/*  728 */           RepConversion.bArray2Nibbles(arrayOfByte6, arrayOfByte4);
/*      */ 
/*      */           
/*  731 */           arrayOfByte4[arrayOfByte4.length - 1] = RepConversion.nibbleToHex(b);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  737 */       else if (arrayOfByte2 != null) {
/*      */         
/*  739 */         if (this.connection.net.getSessionAttributes().getNTAdapter() instanceof oracle.net.nt.TcpsNTAdapter) {
/*      */           
/*  741 */           arrayOfByte4 = arrayOfByte2;
/*      */         } else {
/*      */           byte b1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  749 */           if ((arrayOfByte2.length + 1) % 8 > 0) {
/*  750 */             b1 = (byte)(8 - (arrayOfByte2.length + 1) % 8);
/*      */           } else {
/*  752 */             b1 = 0;
/*      */           } 
/*  754 */           arrayOfByte3 = new byte[arrayOfByte2.length + 1 + b1];
/*      */           
/*  756 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*  757 */           byte[] arrayOfByte = AuthenticationService.obfuscatePasswordForRadius(arrayOfByte3);
/*      */ 
/*      */           
/*  760 */           arrayOfByte4 = new byte[arrayOfByte.length * 2];
/*      */           
/*  762 */           for (byte b2 = 0; b2 < arrayOfByte.length; b2++) {
/*      */             
/*  764 */             byte b3 = (byte)((arrayOfByte[b2] & 0xF0) >> 4);
/*  765 */             byte b4 = (byte)(arrayOfByte[b2] & 0xF);
/*  766 */             arrayOfByte4[b2 * 2] = (byte)((b3 < 10) ? (b3 + 48) : (b3 - 10 + 97));
/*      */             
/*  768 */             arrayOfByte4[b2 * 2 + 1] = (byte)((b4 < 10) ? (b4 + 48) : (b4 - 10 + 97));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  776 */     doOAUTH(arrayOfByte1, arrayOfByte4, paramLong, str, false, (byte[])null, (byte[])null, (byte[][])null, -1, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  787 */     if (str != "RADIUS" && this.bUseO5Logon)
/*      */     
/*  789 */     { String str1 = this.connection.sessionProperties.getProperty("AUTH_SVR_RESPONSE");
/*      */       
/*  791 */       try { if (!this.o5logonHelper.validateServerIdentity(str1))
/*      */         {
/*      */           
/*  794 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  795 */           sQLException.fillInStackTrace();
/*  796 */           throw sQLException;
/*      */         }
/*      */          }
/*  799 */       catch (Exception exception)
/*      */       
/*  801 */       { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  802 */         sQLException.fillInStackTrace();
/*  803 */         throw sQLException; }  }  } void readRPA() throws IOException, SQLException { this.outNbPairs = this.meg.unmarshalUB2(); this.outKeys = new byte[this.outNbPairs][]; this.outValues = new byte[this.outNbPairs][]; this.outFlags = this.meg.unmarshalKEYVAL(this.outKeys, this.outValues, this.outNbPairs); }
/*      */   void processError() throws SQLException { if (getFunCode() == 118) { if (this.oer.getRetCode() != 28035 || this.connection.net.getAuthenticationAdaptorName() != "RADIUS")
/*      */         this.oer.processError();  } else { super.processError(); }  }
/*      */   protected void processRPA() throws SQLException { if (getFunCode() == 115) { Properties properties = new Properties(); for (byte b = 0; b < this.outNbPairs; b++) { String str1 = this.meg.conv.CharBytesToString(this.outKeys[b], (this.outKeys[b]).length).trim(); String str2 = ""; if (this.outValues[b] != null)
/*      */           str2 = this.meg.conv.CharBytesToString(this.outValues[b], (this.outValues[b]).length).trim();  properties.setProperty(str1, str2); }  String str = properties.getProperty("AUTH_VERSION_NO"); if (str != null)
/*      */         try { int i = (new Integer(str)).intValue(); } catch (NumberFormatException numberFormatException) {}  properties.setProperty("SERVER_HOST", properties.getProperty("AUTH_SC_SERVER_HOST", "")); properties.setProperty("INSTANCE_NAME", properties.getProperty("AUTH_SC_INSTANCE_NAME", "")); properties.setProperty("DATABASE_NAME", properties.getProperty("AUTH_SC_DBUNIQUE_NAME", "")); properties.setProperty("SERVICE_NAME", properties.getProperty("AUTH_SC_SERVICE_NAME", "")); properties.setProperty("SESSION_TIME_ZONE", this.sessionTimeZone); this.connection.sessionProperties = properties; } else if (getFunCode() == 118) { if (this.connection.net.getAuthenticationAdaptorName() != "RADIUS") { if (this.outKeys == null || this.outKeys.length < 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }  byte b1 = -1; byte b2 = -1; try { for (byte b = 0; b < this.outKeys.length; b++) { String str = new String(this.outKeys[b], "US-ASCII"); if (str.equals("AUTH_SESSKEY")) { b1 = b; } else if (str.equals("AUTH_VFR_DATA")) { b2 = b; }  if (b2 != -1 && b1 != -1)
/*      */               break;  }  } catch (UnsupportedEncodingException unsupportedEncodingException) {} if (b1 == -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }  this.encryptedSK = this.outValues[b1]; if (b2 != -1) { this.bUseO5Logon = true; this.salt = this.outValues[b2]; this.verifierType = this.outFlags[b2]; }
/*      */          if (!this.bUseO5Logon)
/*      */           if (this.encryptedSK == null || this.encryptedSK.length != 16) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }
/*      */             }
/*      */        }
/*      */      }
/*  815 */   void doOAUTH(int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws IOException, SQLException { byte[] arrayOfByte1 = null;
/*  816 */     byte[] arrayOfByte2 = null;
/*  817 */     String[] arrayOfString = null;
/*  818 */     byte[][] arrayOfByte = (byte[][])null;
/*  819 */     byte[] arrayOfByte3 = null;
/*      */     
/*  821 */     if (paramInt1 == 1) {
/*      */       
/*  823 */       String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  824 */       String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  825 */       if (str2 != null)
/*  826 */         str1 = str1 + "/" + str2; 
/*  827 */       arrayOfByte3 = this.meg.conv.StringToCharBytes(str1);
/*      */     }
/*  829 */     else if (paramInt1 == 2) {
/*      */       
/*  831 */       String str = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*      */ 
/*      */       
/*  834 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(str);
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  840 */         arrayOfByte2 = (byte[])paramProperties.get("PROXY_CERTIFICATE");
/*      */         
/*  842 */         StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */ 
/*      */         
/*  846 */         for (byte b = 0; b < arrayOfByte2.length; b++) {
/*      */           
/*  848 */           String str = Integer.toHexString(0xFF & arrayOfByte2[b]);
/*  849 */           int i = str.length();
/*      */           
/*  851 */           if (i == 0) {
/*  852 */             stringBuffer.append("00");
/*  853 */           } else if (i == 1) {
/*      */             
/*  855 */             stringBuffer.append('0');
/*  856 */             stringBuffer.append(str);
/*      */           } else {
/*      */             
/*  859 */             stringBuffer.append(str);
/*      */           } 
/*      */         } 
/*  862 */         arrayOfByte2 = stringBuffer.toString().getBytes();
/*      */       }
/*  864 */       catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  870 */       arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     }
/*  872 */     catch (Exception exception) {}
/*      */     
/*  874 */     if (arrayOfString != null) {
/*      */       
/*  876 */       arrayOfByte = new byte[arrayOfString.length][];
/*      */       
/*  878 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*  879 */         arrayOfByte[b] = this.meg.conv.StringToCharBytes(arrayOfString[b]);
/*      */       }
/*      */     } 
/*  882 */     doOAUTH(arrayOfByte3, (byte[])null, 0L, (String)null, true, arrayOfByte1, arrayOfByte2, arrayOfByte, paramInt2, paramInt3); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setSessionFields(T4CConnection paramT4CConnection) throws SQLException {
/*  906 */     String str1 = this.connection.thinVsessionTerminal;
/*  907 */     String str2 = this.connection.thinVsessionMachine;
/*  908 */     String str3 = this.connection.thinVsessionOsuser;
/*  909 */     String str4 = this.connection.thinVsessionProgram;
/*  910 */     String str5 = this.connection.thinVsessionProcess;
/*  911 */     String str6 = this.connection.thinVsessionIname;
/*  912 */     String str7 = this.connection.thinVsessionEname;
/*  913 */     String str8 = this.connection.proxyClientName;
/*  914 */     String str9 = this.connection.driverNameAttribute;
/*  915 */     String str10 = this.connection.editionName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  928 */       if (this.connection.enableTempLobRefCnt) {
/*  929 */         this.enableTempLobRefCnt = (new String("1")).getBytes("US-ASCII");
/*      */       } else {
/*      */         
/*  932 */         this.enableTempLobRefCnt = (new String("0")).getBytes("US-ASCII");
/*      */       } 
/*  934 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  940 */     if (str2 == null) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/*  945 */         str2 = InetAddress.getLocalHost().getHostName();
/*      */       }
/*  947 */       catch (Exception exception) {
/*      */         
/*  949 */         str2 = "jdbcclient";
/*      */       } 
/*      */     }
/*      */     
/*  953 */     if (str7 == null) {
/*  954 */       str7 = "jdbc_" + this.ressourceManagerId;
/*      */     }
/*  956 */     if (str9 == null) {
/*  957 */       str9 = "jdbcthin";
/*      */     }
/*      */     
/*  960 */     this.terminal = this.meg.conv.StringToCharBytes(str1);
/*  961 */     this.machine = this.meg.conv.StringToCharBytes(str2);
/*  962 */     this.sysUserName = this.meg.conv.StringToCharBytes(str3);
/*  963 */     this.programName = this.meg.conv.StringToCharBytes(str4);
/*  964 */     this.processID = this.meg.conv.StringToCharBytes(str5);
/*  965 */     this.internalName = this.meg.conv.StringToCharBytes(str6);
/*  966 */     this.externalName = this.meg.conv.StringToCharBytes(str7);
/*  967 */     if (str8 != null)
/*  968 */       this.clientname = this.meg.conv.StringToCharBytes(str8); 
/*  969 */     if (str10 != null)
/*  970 */       this.editionName = this.meg.conv.StringToCharBytes(str10); 
/*  971 */     this.driverName = this.meg.conv.StringToCharBytes(str9);
/*      */     
/*  973 */     TimeZone timeZone = TimeZone.getDefault();
/*      */ 
/*      */     
/*  976 */     String str11 = timeZone.getID();
/*      */     
/*  978 */     if (!ZONEIDMAP.isValidRegion(str11) || !paramT4CConnection.timezoneAsRegion) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  987 */       int i = timeZone.getOffset(System.currentTimeMillis());
/*  988 */       int j = i / 3600000;
/*  989 */       int k = i / 60000 % 60;
/*      */       
/*  991 */       str11 = ((j < 0) ? ("" + j) : ("+" + j)) + ((k < 10) ? (":0" + k) : (":" + k));
/*      */     } 
/*      */ 
/*      */     
/*  995 */     this.sessionTimeZone = str11;
/*  996 */     paramT4CConnection.sessionTimeZone = str11;
/*      */     
/*  998 */     String str12 = CharacterSetMetaData.getNLSLanguage(ClassRef.LOCALE.getDefault());
/*      */     
/* 1000 */     String str13 = CharacterSetMetaData.getNLSTerritory(ClassRef.LOCALE.getDefault());
/*      */ 
/*      */     
/* 1003 */     if (str12 == null || str13 == null) {
/*      */       
/* 1005 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/* 1006 */       sQLException.fillInStackTrace();
/* 1007 */       throw sQLException;
/*      */     } 
/*      */     
/* 1010 */     this.alterSession = this.meg.conv.StringToCharBytes("ALTER SESSION SET " + (this.isSessionTZ ? ("TIME_ZONE='" + this.sessionTimeZone + "'") : "") + " NLS_LANGUAGE='" + str12 + "' NLS_TERRITORY='" + str13 + "' ");
/*      */ 
/*      */ 
/*      */     
/* 1014 */     this.aclValue = this.meg.conv.StringToCharBytes("4400");
/* 1015 */     this.alterSession[this.alterSession.length - 1] = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String removeQuotes(String paramString) {
/* 1029 */     int i = 0, j = paramString.length() - 1;
/*      */     int k;
/* 1031 */     for (k = 0; k < paramString.length(); k++) {
/*      */       
/* 1033 */       if (paramString.charAt(k) != '"') {
/*      */         
/* 1035 */         i = k;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1041 */     for (k = paramString.length() - 1; k >= 0; k--) {
/*      */       
/* 1043 */       if (paramString.charAt(k) != '"') {
/*      */         
/* 1045 */         j = k;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1051 */     return paramString.substring(i, j + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int versionStringToInt(String paramString) throws SQLException {
/* 1080 */     String[] arrayOfString = paramString.split("\\.");
/* 1081 */     int i = Integer.parseInt(arrayOfString[0].replaceAll("\\D", ""));
/* 1082 */     int j = Integer.parseInt(arrayOfString[1].replaceAll("\\D", ""));
/* 1083 */     int k = Integer.parseInt(arrayOfString[2].replaceAll("\\D", ""));
/* 1084 */     int m = Integer.parseInt(arrayOfString[3].replaceAll("\\D", ""));
/* 1085 */     int n = Integer.parseInt(arrayOfString[4].replaceAll("\\D", ""));
/* 1086 */     return i << 24 | j << 20 | k << 12 | m << 8 | n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String versionIntToString(int paramInt) throws SQLException {
/* 1098 */     int i = (paramInt & 0xFF000000) >> 24 & 0xFF;
/* 1099 */     int j = (paramInt & 0xF00000) >> 20 & 0xFF;
/* 1100 */     int k = (paramInt & 0xFF000) >> 12 & 0xFF;
/* 1101 */     int m = (paramInt & 0xF00) >> 8 & 0xFF;
/* 1102 */     int n = paramInt & 0xFF;
/* 1103 */     return "" + i + "." + j + "." + k + "." + m + "." + n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1119 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1124 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CTTIoauthenticate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */