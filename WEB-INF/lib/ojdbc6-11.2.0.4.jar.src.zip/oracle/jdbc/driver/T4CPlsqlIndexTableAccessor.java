/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CPlsqlIndexTableAccessor
/*     */   extends PlsqlIndexTableAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   final int[] meta;
/*     */   final int[] tmp;
/*     */   
/*     */   T4CPlsqlIndexTableAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  43 */     super(paramOracleStatement, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.meta = new int[1];
/*  88 */     this.tmp = new int[1];
/*     */     calculateSizeTmpByteArray();
/*     */     this.mare = paramT4CMAREngine;
/*     */   }
/*     */ 
/*     */   
/*     */   void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/*     */         this.mare.unmarshalSB2();
/*     */       }
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 110 */     if (this.isUseLess) {
/*     */       
/* 112 */       this.lastRowProcessed++;
/*     */       
/* 114 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 123 */       byte[] arrayOfByte1 = new byte[16000];
/*     */       
/* 125 */       this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/* 126 */       processIndicator(this.meta[0]);
/*     */       
/* 128 */       this.lastRowProcessed++;
/*     */       
/* 130 */       return false;
/*     */     } 
/*     */     
/* 133 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 134 */     int j = this.lengthIndex + this.lastRowProcessed;
/* 135 */     byte[] arrayOfByte = this.statement.ibtBindBytes;
/* 136 */     char[] arrayOfChar = this.statement.ibtBindChars;
/* 137 */     short[] arrayOfShort = this.statement.ibtBindIndicators;
/*     */ 
/*     */ 
/*     */     
/* 141 */     if (this.isNullByDescribe) {
/*     */       
/* 143 */       this.rowSpaceIndicator[i] = -1;
/* 144 */       this.rowSpaceIndicator[j] = 0;
/* 145 */       this.lastRowProcessed++;
/*     */       
/* 147 */       if (this.statement.connection.versionNumber < 9200)
/* 148 */         processIndicator(0); 
/* 149 */       return false;
/*     */     } 
/*     */     
/* 152 */     int k = (int)this.mare.unmarshalUB4();
/*     */     
/* 154 */     arrayOfShort[this.ibtMetaIndex + 4] = (short)((k & 0xFFFF0000) >> 16 & 0xFFFF);
/*     */     
/* 156 */     arrayOfShort[this.ibtMetaIndex + 5] = (short)(k & 0xFFFF);
/*     */     
/* 158 */     if (this.elementInternalType == 9 || this.elementInternalType == 96 || this.elementInternalType == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       byte[] arrayOfByte1 = this.statement.tmpByteArray;
/*     */       
/* 167 */       for (byte b = 0; b < k; b++)
/*     */       {
/* 169 */         int m = this.ibtValueIndex + this.elementMaxLen * b;
/*     */         
/* 171 */         this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/*     */         
/* 173 */         this.tmp[0] = this.meta[0];
/*     */         
/* 175 */         int n = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte1, 0, arrayOfChar, m + 1, this.tmp, arrayOfChar.length - m - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         arrayOfChar[m] = (char)(n * 2);
/*     */ 
/*     */ 
/*     */         
/* 184 */         processIndicator(this.meta[0]);
/*     */         
/* 186 */         if (this.meta[0] == 0)
/*     */         {
/*     */ 
/*     */           
/* 190 */           arrayOfShort[this.ibtIndicatorIndex + b] = -1;
/* 191 */           arrayOfShort[this.ibtLengthIndex + b] = 0;
/*     */         }
/*     */         else
/*     */         {
/* 195 */           arrayOfShort[this.ibtLengthIndex + b] = (short)(this.meta[0] * 2);
/*     */ 
/*     */ 
/*     */           
/* 199 */           arrayOfShort[this.ibtIndicatorIndex + b] = 0;
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 207 */       for (byte b = 0; b < k; b++) {
/*     */         
/* 209 */         int m = this.ibtValueIndex + this.elementMaxLen * b;
/*     */         
/* 211 */         this.mare.unmarshalCLR(arrayOfByte, m + 1, this.meta);
/*     */         
/* 213 */         arrayOfByte[m] = (byte)this.meta[0];
/*     */         
/* 215 */         processIndicator(this.meta[0]);
/*     */         
/* 217 */         if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */           
/* 221 */           arrayOfShort[this.ibtIndicatorIndex + b] = -1;
/* 222 */           arrayOfShort[this.ibtLengthIndex + b] = 0;
/*     */         }
/*     */         else {
/*     */           
/* 226 */           arrayOfShort[this.ibtLengthIndex + b] = (short)this.meta[0];
/* 227 */           arrayOfShort[this.ibtIndicatorIndex + b] = 0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 232 */     this.lastRowProcessed++;
/*     */     
/* 234 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void calculateSizeTmpByteArray() {
/* 252 */     if (this.elementInternalType == 9 || this.elementInternalType == 96 || this.elementInternalType == 1) {
/*     */ 
/*     */ 
/*     */       
/* 256 */       int i = this.ibtCharLength * this.statement.connection.conversion.cMaxCharSize / this.maxNumberOfElements;
/*     */ 
/*     */ 
/*     */       
/* 260 */       if (this.statement.sizeTmpByteArray < i) {
/* 261 */         this.statement.sizeTmpByteArray = i;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 276 */     String str = super.getString(paramInt);
/*     */     
/* 278 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 280 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 282 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CPlsqlIndexTableAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */