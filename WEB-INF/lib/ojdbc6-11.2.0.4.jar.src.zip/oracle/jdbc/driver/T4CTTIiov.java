/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIiov
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   T4C8TTIrxh rxh;
/*     */   T4CTTIrxd rxd;
/*  40 */   short bindtype = 0;
/*     */   
/*     */   byte[] iovector;
/*  43 */   int bindcnt = 0;
/*  44 */   int inbinds = 0;
/*  45 */   int outbinds = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final byte BV_IN_V = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final byte BV_OUT_V = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CTTIiov(T4CConnection paramT4CConnection, T4C8TTIrxh paramT4C8TTIrxh, T4CTTIrxd paramT4CTTIrxd) throws SQLException, IOException {
/*  61 */     super(paramT4CConnection, (byte)0);
/*     */     
/*  63 */     this.rxh = paramT4C8TTIrxh;
/*  64 */     this.rxd = paramT4CTTIrxd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init() throws SQLException, IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Accessor[] processRXD(Accessor[] paramArrayOfAccessor, int paramInt1, byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt2, DBConversion paramDBConversion, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfbyte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfbyte4, char[] paramArrayOfchar2, short[] paramArrayOfshort2) throws SQLException, IOException {
/*  99 */     if (paramArrayOfbyte3 != null)
/*     */     {
/* 101 */       for (byte b = 0; b < paramArrayOfbyte3.length; b++) {
/*     */         
/* 103 */         if ((paramArrayOfbyte3[b] & 0x10) != 0 && (paramArrayOfAccessor == null || paramArrayOfAccessor.length <= b || paramArrayOfAccessor[b] == null)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 110 */           int i = paramInt2 + 5 + 10 * b;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 115 */           int j = paramArrayOfshort1[i + 0] & 0xFFFF;
/*     */ 
/*     */           
/* 118 */           int k = j;
/*     */           
/* 120 */           if (j == 9) {
/* 121 */             j = 1;
/*     */           }
/* 123 */           Accessor accessor = paramOracleStatement.allocateAccessor(j, j, b, 0, (short)0, null, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 132 */           accessor.rowSpaceIndicator = null;
/*     */ 
/*     */           
/* 135 */           if (accessor.defineType == 109 || accessor.defineType == 111)
/*     */           {
/* 137 */             accessor.setOffsets(1);
/*     */           }
/* 139 */           if (paramArrayOfAccessor == null)
/*     */           {
/* 141 */             paramArrayOfAccessor = new Accessor[b + 1];
/* 142 */             paramArrayOfAccessor[b] = accessor;
/*     */           }
/* 144 */           else if (paramArrayOfAccessor.length <= b)
/*     */           {
/* 146 */             Accessor[] arrayOfAccessor = new Accessor[b + 1];
/*     */             
/* 148 */             arrayOfAccessor[b] = accessor;
/*     */             
/* 150 */             for (byte b1 = 0; b1 < paramArrayOfAccessor.length; b1++) {
/*     */               
/* 152 */               if (paramArrayOfAccessor[b1] != null) {
/* 153 */                 arrayOfAccessor[b1] = paramArrayOfAccessor[b1];
/*     */               }
/*     */             } 
/* 156 */             paramArrayOfAccessor = arrayOfAccessor;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/*     */             
/* 162 */             paramArrayOfAccessor[b] = accessor;
/*     */           }
/*     */         
/* 165 */         } else if ((paramArrayOfbyte3[b] & 0x10) == 0 && paramArrayOfAccessor != null && b < paramArrayOfAccessor.length && paramArrayOfAccessor[b] != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 171 */           (paramArrayOfAccessor[b]).isUseLess = true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     return paramArrayOfAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshalV10() throws IOException, SQLException {
/* 187 */     this.rxh.unmarshalV10(this.rxd);
/*     */     
/* 189 */     this.bindcnt = this.rxh.numRqsts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     this.iovector = new byte[this.connection.all8.numberOfBindPositions];
/*     */     
/* 201 */     for (byte b = 0; b < this.iovector.length; b++) {
/*     */ 
/*     */ 
/*     */       
/* 205 */       if ((this.bindtype = this.meg.unmarshalUB1()) == 0) {
/*     */ 
/*     */ 
/*     */         
/* 209 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 210 */         sQLException.fillInStackTrace();
/* 211 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 217 */       if ((this.bindtype & 0x20) > 0) {
/*     */         
/* 219 */         this.iovector[b] = (byte)(this.iovector[b] | 0x20);
/* 220 */         this.inbinds++;
/*     */       } 
/*     */       
/* 223 */       if ((this.bindtype & 0x10) > 0) {
/*     */         
/* 225 */         this.iovector[b] = (byte)(this.iovector[b] | 0x10);
/* 226 */         this.outbinds++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getIOVector() {
/* 244 */     return this.iovector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isIOVectorEmpty() {
/* 255 */     return (this.iovector.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 260 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CTTIiov.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */