/*       */ package oracle.jdbc.driver;
/*       */ import java.lang.reflect.Field;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.InetAddress;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.sql.Array;
/*       */ import java.sql.Blob;
/*       */ import java.sql.CallableStatement;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.DatabaseMetaData;
/*       */ import java.sql.Date;
/*       */ import java.sql.DriverManager;
/*       */ import java.sql.NClob;
/*       */ import java.sql.PreparedStatement;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLWarning;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Savepoint;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Struct;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Calendar;
/*       */ import java.util.EnumSet;
/*       */ import java.util.Enumeration;
/*       */ import java.util.Hashtable;
/*       */ import java.util.Map;
/*       */ import java.util.Properties;
/*       */ import java.util.TimeZone;
/*       */ import java.util.Vector;
/*       */ import java.util.regex.Pattern;
/*       */ import oracle.jdbc.OracleCallableStatement;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OraclePreparedStatement;
/*       */ import oracle.jdbc.OracleSQLPermission;
/*       */ import oracle.jdbc.OracleSavepoint;
/*       */ import oracle.jdbc.OracleStatement;
/*       */ import oracle.jdbc.aq.AQDequeueOptions;
/*       */ import oracle.jdbc.aq.AQEnqueueOptions;
/*       */ import oracle.jdbc.aq.AQMessage;
/*       */ import oracle.jdbc.aq.AQNotificationRegistration;
/*       */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*       */ import oracle.jdbc.internal.KeywordValueLong;
/*       */ import oracle.jdbc.internal.OracleConnection;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.internal.XSEventListener;
/*       */ import oracle.jdbc.internal.XSNamespace;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*       */ import oracle.jdbc.pool.OraclePooledConnection;
/*       */ import oracle.net.nt.CustomSSLSocketFactory;
/*       */ import oracle.security.pki.OracleSecretStore;
/*       */ import oracle.security.pki.OracleWallet;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.BfileDBAccess;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NCLOB;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.SQLName;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ import oracle.sql.TIMEZONETAB;
/*       */ import oracle.sql.TypeDescriptor;
/*       */ 
/*       */ abstract class PhysicalConnection extends OracleConnection {
/*       */   public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
/*       */   public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
/*       */   public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
/*       */   public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
/*       */   public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
/*    89 */   static final CRC64 CHECKSUM = new CRC64();
/*       */   public static final char slash_character = '/';
/*       */   public static final char at_sign_character = '@';
/*       */   public static final char left_square_bracket_character = '[';
/*       */   public static final char right_square_bracket_character = ']';
/*    94 */   static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*    99 */   long outScn = 0L;
/*       */   
/*   101 */   char[][] charOutput = new char[1][];
/*   102 */   byte[][] byteOutput = new byte[1][];
/*   103 */   short[][] shortOutput = new short[1][];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   109 */   Properties sessionProperties = null;
/*       */   
/*       */   boolean retainV9BindBehavior;
/*       */   
/*       */   String userName;
/*       */   
/*       */   String database;
/*       */   
/*       */   boolean autocommit;
/*       */   
/*       */   String protocol;
/*       */   
/*       */   int streamChunkSize;
/*       */   
/*       */   boolean setFloatAndDoubleUseBinary;
/*       */   String thinVsessionTerminal;
/*       */   String thinVsessionMachine;
/*       */   String thinVsessionOsuser;
/*       */   String thinVsessionProgram;
/*       */   String thinVsessionProcess;
/*       */   String thinVsessionIname;
/*       */   String thinVsessionEname;
/*       */   String thinNetProfile;
/*       */   String thinNetAuthenticationServices;
/*       */   String thinNetAuthenticationKrb5Mutual;
/*       */   String thinNetAuthenticationKrb5CcName;
/*       */   String thinNetEncryptionLevel;
/*       */   String thinNetEncryptionTypes;
/*       */   String thinNetChecksumLevel;
/*       */   String thinNetChecksumTypes;
/*       */   String thinNetCryptoSeed;
/*       */   boolean thinTcpNoDelay;
/*       */   String thinReadTimeout;
/*       */   String thinNetConnectTimeout;
/*       */   boolean thinNetDisableOutOfBandBreak;
/*       */   boolean thinNetUseZeroCopyIO;
/*       */   boolean thinNetEnableSDP;
/*       */   boolean use1900AsYearForTime;
/*       */   boolean timestamptzInGmt;
/*       */   boolean timezoneAsRegion;
/*       */   String thinSslServerDnMatch;
/*       */   String thinSslVersion;
/*       */   String thinSslCipherSuites;
/*       */   String thinJavaxNetSslKeystore;
/*       */   String thinJavaxNetSslKeystoretype;
/*       */   String thinJavaxNetSslKeystorepassword;
/*       */   String thinJavaxNetSslTruststore;
/*       */   String thinJavaxNetSslTruststoretype;
/*       */   String thinJavaxNetSslTruststorepassword;
/*       */   String thinSslKeymanagerfactoryAlgorithm;
/*       */   String thinSslTrustmanagerfactoryAlgorithm;
/*       */   String thinNetOldsyntax;
/*       */   String thinNamingContextInitial;
/*       */   String thinNamingProviderUrl;
/*       */   String thinNamingSecurityAuthentication;
/*       */   String thinNamingSecurityPrincipal;
/*       */   String thinNamingSecurityCredentials;
/*       */   String walletLocation;
/*       */   String walletPassword;
/*       */   String proxyClientName;
/*       */   boolean useNio;
/*       */   String ociDriverCharset;
/*       */   String editionName;
/*       */   String logonCap;
/*       */   String internalLogon;
/*       */   boolean createDescriptorUseCurrentSchemaForSchemaName;
/*       */   long ociSvcCtxHandle;
/*       */   long ociEnvHandle;
/*       */   long ociErrHandle;
/*       */   boolean prelimAuth;
/*       */   boolean nlsLangBackdoor;
/*       */   String setNewPassword;
/*       */   boolean spawnNewThreadToCancel;
/*       */   int defaultExecuteBatch;
/*       */   int defaultRowPrefetch;
/*       */   int defaultLobPrefetchSize;
/*       */   boolean enableDataInLocator;
/*       */   boolean enableReadDataInLocator;
/*       */   boolean overrideEnableReadDataInLocator;
/*       */   boolean reportRemarks;
/*       */   boolean includeSynonyms;
/*       */   boolean restrictGettables;
/*       */   boolean accumulateBatchResult;
/*       */   boolean useFetchSizeWithLongColumn;
/*       */   boolean processEscapes;
/*       */   boolean fixedString;
/*       */   boolean defaultnchar;
/*       */   boolean permitTimestampDateMismatch;
/*       */   String resourceManagerId;
/*       */   boolean disableDefinecolumntype;
/*       */   boolean convertNcharLiterals;
/*       */   boolean j2ee13Compliant;
/*       */   boolean mapDateToTimestamp;
/*       */   boolean useThreadLocalBufferCache;
/*       */   String driverNameAttribute;
/*       */   int maxCachedBufferSize;
/*       */   int implicitStatementCacheSize;
/*       */   boolean lobStreamPosStandardCompliant;
/*       */   boolean isStrictAsciiConversion;
/*       */   boolean isQuickAsciiConversion;
/*       */   boolean thinForceDnsLoadBalancing;
/*       */   boolean enableJavaNetFastPath;
/*       */   boolean enableTempLobRefCnt;
/*       */   boolean plsqlVarcharParameter4KOnly;
/*       */   boolean keepAlive;
/*       */   public boolean calculateChecksum;
/*       */   String url;
/*       */   String savedUser;
/*       */   int commitOption;
/*   218 */   int ociConnectionPoolMinLimit = 0;
/*   219 */   int ociConnectionPoolMaxLimit = 0;
/*   220 */   int ociConnectionPoolIncrement = 0;
/*   221 */   int ociConnectionPoolTimeout = 0;
/*       */   boolean ociConnectionPoolNoWait = false;
/*       */   boolean ociConnectionPoolTransactionDistributed = false;
/*   224 */   String ociConnectionPoolLogonMode = null;
/*       */   boolean ociConnectionPoolIsPooling = false;
/*   226 */   Object ociConnectionPoolObject = null;
/*   227 */   Object ociConnectionPoolConnID = null;
/*   228 */   String ociConnectionPoolProxyType = null;
/*   229 */   Integer ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
/*   230 */   Object ociConnectionPoolProxyRoles = null;
/*   231 */   String ociConnectionPoolProxyUserName = null;
/*   232 */   String ociConnectionPoolProxyPassword = null;
/*   233 */   String ociConnectionPoolProxyDistinguishedName = null;
/*   234 */   Object ociConnectionPoolProxyCertificate = null;
/*       */   
/*   236 */   static NTFManager ntfManager = new NTFManager();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   247 */   public int protocolId = -3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout timeout;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   DBConversion conversion;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean xaWantsError;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean usingXA;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   272 */   int txnMode = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] fdo;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Boolean bigEndian;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statements;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int lifecycle;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int OPEN = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSING = 2;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSED = 4;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int ABORTED = 8;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BLOCKED = 16;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clientIdSet = false;
/*       */ 
/*       */ 
/*       */   
/*   322 */   String clientId = null;
/*       */ 
/*       */ 
/*       */   
/*       */   int txnLevel;
/*       */ 
/*       */ 
/*       */   
/*       */   Map map;
/*       */ 
/*       */ 
/*       */   
/*       */   Map javaObjectMap;
/*       */ 
/*       */ 
/*       */   
/*   338 */   final Hashtable[] descriptorCacheStack = new Hashtable[2];
/*       */   
/*   340 */   int dci = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statementHoldingLine;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   352 */   OracleDatabaseMetaData databaseMetaData = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   LogicalConnection logicalConnectionAttached;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isProxy = false;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   367 */   OracleSql sqlObj = null;
/*       */ 
/*       */   
/*   370 */   SQLWarning sqlWarning = null;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean readOnly = false;
/*       */ 
/*       */ 
/*       */   
/*   378 */   LRUStatementCache statementCache = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */   
/*   387 */   OracleCloseCallback closeCallback = null;
/*   388 */   Object privateData = null;
/*       */ 
/*       */   
/*   391 */   Statement savepointStatement = null;
/*       */ 
/*       */   
/*       */   boolean isUsable = true;
/*       */   
/*   396 */   TimeZone defaultTimeZone = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   421 */   final int[] endToEndMaxLength = new int[4];
/*       */   
/*       */   boolean endToEndAnyChanged = false;
/*   424 */   final boolean[] endToEndHasChanged = new boolean[4];
/*   425 */   short endToEndECIDSequenceNumber = Short.MIN_VALUE;
/*       */ 
/*       */   
/*       */   static final int DMS_NONE = 0;
/*       */ 
/*       */   
/*       */   static final int DMS_10G = 1;
/*       */   
/*       */   static final int DMS_11 = 2;
/*       */   
/*   435 */   String[] endToEndValues = null;
/*   436 */   final int whichDMS = 0;
/*       */ 
/*       */ 
/*       */   
/*   440 */   OracleConnection wrapper = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int minVcsBindSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxIbtVarcharElementLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   493 */   String instanceName = null;
/*       */   OracleDriverExtension driverExtension;
/*       */   static final String uninitializedMarker = "";
/*   496 */   String databaseProductVersion = "";
/*   497 */   short versionNumber = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int namedTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int refTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CharacterSet setCHARCharSetObj;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CharacterSet setCHARNCharSetObj;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected final Object cancelInProgressLockForThin;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean plsqlCompilerWarnings = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String propertyVariableName(String paramString) {
/*   687 */     char[] arrayOfChar = new char[paramString.length()];
/*   688 */     paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*   689 */     String str = "";
/*   690 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/*       */       
/*   692 */       if (Character.isUpperCase(arrayOfChar[b]))
/*   693 */         str = str + "_"; 
/*   694 */       str = str + Character.toUpperCase(arrayOfChar[b]);
/*       */     } 
/*   696 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void initializeUserDefaults(Properties paramProperties) {
/*   711 */     for (String str : OracleDriver.DEFAULT_CONNECTION_PROPERTIES.stringPropertyNames()) {
/*   712 */       if (!paramProperties.containsKey(str)) {
/*   713 */         paramProperties.setProperty(str, OracleDriver.DEFAULT_CONNECTION_PROPERTIES.getProperty(str));
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readConnectionProperties(String paramString, Properties paramProperties) throws SQLException {
/*   742 */     initializeUserDefaults(paramProperties);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   747 */     String str1 = null;
/*       */ 
/*       */     
/*   750 */     str1 = null;
/*   751 */     if (paramProperties != null)
/*       */     {
/*   753 */       str1 = paramProperties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
/*       */     }
/*   755 */     if (str1 == null)
/*   756 */       str1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", (String)null); 
/*   757 */     if (str1 == null) {
/*   758 */       str1 = "false";
/*       */     }
/*       */     
/*   761 */     this.retainV9BindBehavior = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   764 */     str1 = null;
/*   765 */     if (paramProperties != null) {
/*       */       
/*   767 */       str1 = paramProperties.getProperty("user");
/*   768 */       if (str1 == null)
/*   769 */         str1 = paramProperties.getProperty("oracle.jdbc.user"); 
/*       */     } 
/*   771 */     if (str1 == null)
/*   772 */       str1 = getSystemProperty("oracle.jdbc.user", (String)null); 
/*   773 */     if (str1 == null) {
/*   774 */       str1 = null;
/*       */     }
/*       */     
/*   777 */     this.userName = str1;
/*       */ 
/*       */     
/*   780 */     str1 = null;
/*   781 */     if (paramProperties != null) {
/*       */       
/*   783 */       str1 = paramProperties.getProperty("database");
/*   784 */       if (str1 == null)
/*   785 */         str1 = paramProperties.getProperty("oracle.jdbc.database"); 
/*       */     } 
/*   787 */     if (str1 == null)
/*   788 */       str1 = getSystemProperty("oracle.jdbc.database", (String)null); 
/*   789 */     if (str1 == null) {
/*   790 */       str1 = null;
/*       */     }
/*       */     
/*   793 */     this.database = str1;
/*       */ 
/*       */     
/*   796 */     str1 = null;
/*   797 */     if (paramProperties != null) {
/*       */       
/*   799 */       str1 = paramProperties.getProperty("autoCommit");
/*   800 */       if (str1 == null)
/*   801 */         str1 = paramProperties.getProperty("oracle.jdbc.autoCommit"); 
/*       */     } 
/*   803 */     if (str1 == null)
/*   804 */       str1 = getSystemProperty("oracle.jdbc.autoCommit", (String)null); 
/*   805 */     if (str1 == null) {
/*   806 */       str1 = "true";
/*       */     }
/*       */     
/*   809 */     this.autocommit = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   812 */     str1 = null;
/*   813 */     if (paramProperties != null) {
/*       */       
/*   815 */       str1 = paramProperties.getProperty("protocol");
/*   816 */       if (str1 == null)
/*   817 */         str1 = paramProperties.getProperty("oracle.jdbc.protocol"); 
/*       */     } 
/*   819 */     if (str1 == null)
/*   820 */       str1 = getSystemProperty("oracle.jdbc.protocol", (String)null); 
/*   821 */     if (str1 == null) {
/*   822 */       str1 = null;
/*       */     }
/*       */     
/*   825 */     this.protocol = str1;
/*       */ 
/*       */     
/*   828 */     str1 = null;
/*   829 */     if (paramProperties != null)
/*       */     {
/*   831 */       str1 = paramProperties.getProperty("oracle.jdbc.StreamChunkSize");
/*       */     }
/*   833 */     if (str1 == null)
/*   834 */       str1 = getSystemProperty("oracle.jdbc.StreamChunkSize", (String)null); 
/*   835 */     if (str1 == null) {
/*   836 */       str1 = "16384";
/*       */     }
/*       */     try {
/*   839 */       this.streamChunkSize = Integer.parseInt(str1);
/*   840 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*   844 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
/*   845 */       sQLException.fillInStackTrace();
/*   846 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   852 */     str1 = null;
/*   853 */     if (paramProperties != null) {
/*       */       
/*   855 */       str1 = paramProperties.getProperty("SetFloatAndDoubleUseBinary");
/*   856 */       if (str1 == null)
/*   857 */         str1 = paramProperties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary"); 
/*       */     } 
/*   859 */     if (str1 == null)
/*   860 */       str1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", (String)null); 
/*   861 */     if (str1 == null) {
/*   862 */       str1 = "false";
/*       */     }
/*       */     
/*   865 */     this.setFloatAndDoubleUseBinary = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   868 */     str1 = null;
/*   869 */     if (paramProperties != null) {
/*       */       
/*   871 */       str1 = paramProperties.getProperty("v$session.terminal");
/*   872 */       if (str1 == null)
/*   873 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.terminal"); 
/*       */     } 
/*   875 */     if (str1 == null)
/*   876 */       str1 = getSystemProperty("oracle.jdbc.v$session.terminal", (String)null); 
/*   877 */     if (str1 == null) {
/*   878 */       str1 = "unknown";
/*       */     }
/*       */     
/*   881 */     this.thinVsessionTerminal = str1;
/*       */ 
/*       */     
/*   884 */     str1 = null;
/*   885 */     if (paramProperties != null) {
/*       */       
/*   887 */       str1 = paramProperties.getProperty("v$session.machine");
/*   888 */       if (str1 == null)
/*   889 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.machine"); 
/*       */     } 
/*   891 */     if (str1 == null)
/*   892 */       str1 = getSystemProperty("oracle.jdbc.v$session.machine", (String)null); 
/*   893 */     if (str1 == null) {
/*   894 */       str1 = null;
/*       */     }
/*       */     
/*   897 */     this.thinVsessionMachine = str1;
/*       */ 
/*       */     
/*   900 */     str1 = null;
/*   901 */     if (paramProperties != null) {
/*       */       
/*   903 */       str1 = paramProperties.getProperty("v$session.osuser");
/*   904 */       if (str1 == null)
/*   905 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.osuser"); 
/*       */     } 
/*   907 */     if (str1 == null)
/*   908 */       str1 = getSystemProperty("oracle.jdbc.v$session.osuser", (String)null); 
/*   909 */     if (str1 == null) {
/*   910 */       str1 = null;
/*       */     }
/*       */     
/*   913 */     this.thinVsessionOsuser = str1;
/*       */ 
/*       */     
/*   916 */     str1 = null;
/*   917 */     if (paramProperties != null) {
/*       */       
/*   919 */       str1 = paramProperties.getProperty("v$session.program");
/*   920 */       if (str1 == null)
/*   921 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.program"); 
/*       */     } 
/*   923 */     if (str1 == null)
/*   924 */       str1 = getSystemProperty("oracle.jdbc.v$session.program", (String)null); 
/*   925 */     if (str1 == null) {
/*   926 */       str1 = "JDBC Thin Client";
/*       */     }
/*       */     
/*   929 */     this.thinVsessionProgram = str1;
/*       */ 
/*       */     
/*   932 */     str1 = null;
/*   933 */     if (paramProperties != null) {
/*       */       
/*   935 */       str1 = paramProperties.getProperty("v$session.process");
/*   936 */       if (str1 == null)
/*   937 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.process"); 
/*       */     } 
/*   939 */     if (str1 == null)
/*   940 */       str1 = getSystemProperty("oracle.jdbc.v$session.process", (String)null); 
/*   941 */     if (str1 == null) {
/*   942 */       str1 = "1234";
/*       */     }
/*       */     
/*   945 */     this.thinVsessionProcess = str1;
/*       */ 
/*       */     
/*   948 */     str1 = null;
/*   949 */     if (paramProperties != null) {
/*       */       
/*   951 */       str1 = paramProperties.getProperty("v$session.iname");
/*   952 */       if (str1 == null)
/*   953 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.iname"); 
/*       */     } 
/*   955 */     if (str1 == null)
/*   956 */       str1 = getSystemProperty("oracle.jdbc.v$session.iname", (String)null); 
/*   957 */     if (str1 == null) {
/*   958 */       str1 = "jdbc_ttc_impl";
/*       */     }
/*       */     
/*   961 */     this.thinVsessionIname = str1;
/*       */ 
/*       */     
/*   964 */     str1 = null;
/*   965 */     if (paramProperties != null) {
/*       */       
/*   967 */       str1 = paramProperties.getProperty("v$session.ename");
/*   968 */       if (str1 == null)
/*   969 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.ename"); 
/*       */     } 
/*   971 */     if (str1 == null)
/*   972 */       str1 = getSystemProperty("oracle.jdbc.v$session.ename", (String)null); 
/*   973 */     if (str1 == null) {
/*   974 */       str1 = null;
/*       */     }
/*       */     
/*   977 */     this.thinVsessionEname = str1;
/*       */ 
/*       */     
/*   980 */     str1 = null;
/*   981 */     if (paramProperties != null)
/*       */     {
/*   983 */       str1 = paramProperties.getProperty("oracle.net.profile");
/*       */     }
/*   985 */     if (str1 == null)
/*   986 */       str1 = getSystemProperty("oracle.net.profile", (String)null); 
/*   987 */     if (str1 == null) {
/*   988 */       str1 = null;
/*       */     }
/*       */     
/*   991 */     this.thinNetProfile = str1;
/*       */ 
/*       */     
/*   994 */     str1 = null;
/*   995 */     if (paramProperties != null)
/*       */     {
/*   997 */       str1 = paramProperties.getProperty("oracle.net.authentication_services");
/*       */     }
/*   999 */     if (str1 == null)
/*  1000 */       str1 = getSystemProperty("oracle.net.authentication_services", (String)null); 
/*  1001 */     if (str1 == null) {
/*  1002 */       str1 = null;
/*       */     }
/*       */     
/*  1005 */     this.thinNetAuthenticationServices = str1;
/*       */ 
/*       */     
/*  1008 */     str1 = null;
/*  1009 */     if (paramProperties != null)
/*       */     {
/*  1011 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_mutual_authentication");
/*       */     }
/*  1013 */     if (str1 == null)
/*  1014 */       str1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", (String)null); 
/*  1015 */     if (str1 == null) {
/*  1016 */       str1 = null;
/*       */     }
/*       */     
/*  1019 */     this.thinNetAuthenticationKrb5Mutual = str1;
/*       */ 
/*       */     
/*  1022 */     str1 = null;
/*  1023 */     if (paramProperties != null)
/*       */     {
/*  1025 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_cc_name");
/*       */     }
/*  1027 */     if (str1 == null)
/*  1028 */       str1 = getSystemProperty("oracle.net.kerberos5_cc_name", (String)null); 
/*  1029 */     if (str1 == null) {
/*  1030 */       str1 = null;
/*       */     }
/*       */     
/*  1033 */     this.thinNetAuthenticationKrb5CcName = str1;
/*       */ 
/*       */     
/*  1036 */     str1 = null;
/*  1037 */     if (paramProperties != null)
/*       */     {
/*  1039 */       str1 = paramProperties.getProperty("oracle.net.encryption_client");
/*       */     }
/*  1041 */     if (str1 == null)
/*  1042 */       str1 = getSystemProperty("oracle.net.encryption_client", (String)null); 
/*  1043 */     if (str1 == null) {
/*  1044 */       str1 = null;
/*       */     }
/*       */     
/*  1047 */     this.thinNetEncryptionLevel = str1;
/*       */ 
/*       */     
/*  1050 */     str1 = null;
/*  1051 */     if (paramProperties != null)
/*       */     {
/*  1053 */       str1 = paramProperties.getProperty("oracle.net.encryption_types_client");
/*       */     }
/*  1055 */     if (str1 == null)
/*  1056 */       str1 = getSystemProperty("oracle.net.encryption_types_client", (String)null); 
/*  1057 */     if (str1 == null) {
/*  1058 */       str1 = null;
/*       */     }
/*       */     
/*  1061 */     this.thinNetEncryptionTypes = str1;
/*       */ 
/*       */     
/*  1064 */     str1 = null;
/*  1065 */     if (paramProperties != null)
/*       */     {
/*  1067 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_client");
/*       */     }
/*  1069 */     if (str1 == null)
/*  1070 */       str1 = getSystemProperty("oracle.net.crypto_checksum_client", (String)null); 
/*  1071 */     if (str1 == null) {
/*  1072 */       str1 = null;
/*       */     }
/*       */     
/*  1075 */     this.thinNetChecksumLevel = str1;
/*       */ 
/*       */     
/*  1078 */     str1 = null;
/*  1079 */     if (paramProperties != null)
/*       */     {
/*  1081 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_types_client");
/*       */     }
/*  1083 */     if (str1 == null)
/*  1084 */       str1 = getSystemProperty("oracle.net.crypto_checksum_types_client", (String)null); 
/*  1085 */     if (str1 == null) {
/*  1086 */       str1 = null;
/*       */     }
/*       */     
/*  1089 */     this.thinNetChecksumTypes = str1;
/*       */ 
/*       */     
/*  1092 */     str1 = null;
/*  1093 */     if (paramProperties != null)
/*       */     {
/*  1095 */       str1 = paramProperties.getProperty("oracle.net.crypto_seed");
/*       */     }
/*  1097 */     if (str1 == null)
/*  1098 */       str1 = getSystemProperty("oracle.net.crypto_seed", (String)null); 
/*  1099 */     if (str1 == null) {
/*  1100 */       str1 = null;
/*       */     }
/*       */     
/*  1103 */     this.thinNetCryptoSeed = str1;
/*       */ 
/*       */     
/*  1106 */     str1 = null;
/*  1107 */     if (paramProperties != null)
/*       */     {
/*  1109 */       str1 = paramProperties.getProperty("oracle.jdbc.TcpNoDelay");
/*       */     }
/*  1111 */     if (str1 == null)
/*  1112 */       str1 = getSystemProperty("oracle.jdbc.TcpNoDelay", (String)null); 
/*  1113 */     if (str1 == null) {
/*  1114 */       str1 = "false";
/*       */     }
/*       */     
/*  1117 */     this.thinTcpNoDelay = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1120 */     str1 = null;
/*  1121 */     if (paramProperties != null)
/*       */     {
/*  1123 */       str1 = paramProperties.getProperty("oracle.jdbc.ReadTimeout");
/*       */     }
/*  1125 */     if (str1 == null)
/*  1126 */       str1 = getSystemProperty("oracle.jdbc.ReadTimeout", (String)null); 
/*  1127 */     if (str1 == null) {
/*  1128 */       str1 = null;
/*       */     }
/*       */     
/*  1131 */     this.thinReadTimeout = str1;
/*       */ 
/*       */     
/*  1134 */     str1 = null;
/*  1135 */     if (paramProperties != null)
/*       */     {
/*  1137 */       str1 = paramProperties.getProperty("oracle.net.CONNECT_TIMEOUT");
/*       */     }
/*  1139 */     if (str1 == null)
/*  1140 */       str1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", (String)null); 
/*  1141 */     if (str1 == null) {
/*  1142 */       str1 = null;
/*       */     }
/*       */     
/*  1145 */     this.thinNetConnectTimeout = str1;
/*       */ 
/*       */     
/*  1148 */     str1 = null;
/*  1149 */     if (paramProperties != null)
/*       */     {
/*  1151 */       str1 = paramProperties.getProperty("oracle.net.disableOob");
/*       */     }
/*  1153 */     if (str1 == null)
/*  1154 */       str1 = getSystemProperty("oracle.net.disableOob", (String)null); 
/*  1155 */     if (str1 == null) {
/*  1156 */       str1 = "false";
/*       */     }
/*       */     
/*  1159 */     this.thinNetDisableOutOfBandBreak = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1162 */     str1 = null;
/*  1163 */     if (paramProperties != null)
/*       */     {
/*  1165 */       str1 = paramProperties.getProperty("oracle.net.useZeroCopyIO");
/*       */     }
/*  1167 */     if (str1 == null)
/*  1168 */       str1 = getSystemProperty("oracle.net.useZeroCopyIO", (String)null); 
/*  1169 */     if (str1 == null) {
/*  1170 */       str1 = "true";
/*       */     }
/*       */     
/*  1173 */     this.thinNetUseZeroCopyIO = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1176 */     str1 = null;
/*  1177 */     if (paramProperties != null)
/*       */     {
/*  1179 */       str1 = paramProperties.getProperty("oracle.net.SDP");
/*       */     }
/*  1181 */     if (str1 == null)
/*  1182 */       str1 = getSystemProperty("oracle.net.SDP", (String)null); 
/*  1183 */     if (str1 == null) {
/*  1184 */       str1 = "false";
/*       */     }
/*       */     
/*  1187 */     this.thinNetEnableSDP = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1190 */     str1 = null;
/*  1191 */     if (paramProperties != null)
/*       */     {
/*  1193 */       str1 = paramProperties.getProperty("oracle.jdbc.use1900AsYearForTime");
/*       */     }
/*  1195 */     if (str1 == null)
/*  1196 */       str1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", (String)null); 
/*  1197 */     if (str1 == null) {
/*  1198 */       str1 = "false";
/*       */     }
/*       */     
/*  1201 */     this.use1900AsYearForTime = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1204 */     str1 = null;
/*  1205 */     if (paramProperties != null)
/*       */     {
/*  1207 */       str1 = paramProperties.getProperty("oracle.jdbc.timestampTzInGmt");
/*       */     }
/*  1209 */     if (str1 == null)
/*  1210 */       str1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", (String)null); 
/*  1211 */     if (str1 == null) {
/*  1212 */       str1 = "true";
/*       */     }
/*       */     
/*  1215 */     this.timestamptzInGmt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1218 */     str1 = null;
/*  1219 */     if (paramProperties != null)
/*       */     {
/*  1221 */       str1 = paramProperties.getProperty("oracle.jdbc.timezoneAsRegion");
/*       */     }
/*  1223 */     if (str1 == null)
/*  1224 */       str1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", (String)null); 
/*  1225 */     if (str1 == null) {
/*  1226 */       str1 = "true";
/*       */     }
/*       */     
/*  1229 */     this.timezoneAsRegion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1232 */     str1 = null;
/*  1233 */     if (paramProperties != null)
/*       */     {
/*  1235 */       str1 = paramProperties.getProperty("oracle.net.ssl_server_dn_match");
/*       */     }
/*  1237 */     if (str1 == null)
/*  1238 */       str1 = getSystemProperty("oracle.net.ssl_server_dn_match", (String)null); 
/*  1239 */     if (str1 == null) {
/*  1240 */       str1 = null;
/*       */     }
/*       */     
/*  1243 */     this.thinSslServerDnMatch = str1;
/*       */ 
/*       */     
/*  1246 */     str1 = null;
/*  1247 */     if (paramProperties != null)
/*       */     {
/*  1249 */       str1 = paramProperties.getProperty("oracle.net.ssl_version");
/*       */     }
/*  1251 */     if (str1 == null)
/*  1252 */       str1 = getSystemProperty("oracle.net.ssl_version", (String)null); 
/*  1253 */     if (str1 == null) {
/*  1254 */       str1 = null;
/*       */     }
/*       */     
/*  1257 */     this.thinSslVersion = str1;
/*       */ 
/*       */     
/*  1260 */     str1 = null;
/*  1261 */     if (paramProperties != null)
/*       */     {
/*  1263 */       str1 = paramProperties.getProperty("oracle.net.ssl_cipher_suites");
/*       */     }
/*  1265 */     if (str1 == null)
/*  1266 */       str1 = getSystemProperty("oracle.net.ssl_cipher_suites", (String)null); 
/*  1267 */     if (str1 == null) {
/*  1268 */       str1 = null;
/*       */     }
/*       */     
/*  1271 */     this.thinSslCipherSuites = str1;
/*       */ 
/*       */     
/*  1274 */     str1 = null;
/*  1275 */     if (paramProperties != null)
/*       */     {
/*  1277 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStore");
/*       */     }
/*  1279 */     if (str1 == null)
/*  1280 */       str1 = getSystemProperty("javax.net.ssl.keyStore", (String)null); 
/*  1281 */     if (str1 == null) {
/*  1282 */       str1 = null;
/*       */     }
/*       */     
/*  1285 */     this.thinJavaxNetSslKeystore = str1;
/*       */ 
/*       */     
/*  1288 */     str1 = null;
/*  1289 */     if (paramProperties != null)
/*       */     {
/*  1291 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStoreType");
/*       */     }
/*  1293 */     if (str1 == null)
/*  1294 */       str1 = getSystemProperty("javax.net.ssl.keyStoreType", (String)null); 
/*  1295 */     if (str1 == null) {
/*  1296 */       str1 = null;
/*       */     }
/*       */     
/*  1299 */     this.thinJavaxNetSslKeystoretype = str1;
/*       */ 
/*       */     
/*  1302 */     str1 = null;
/*  1303 */     if (paramProperties != null)
/*       */     {
/*  1305 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStorePassword");
/*       */     }
/*  1307 */     if (str1 == null)
/*  1308 */       str1 = getSystemProperty("javax.net.ssl.keyStorePassword", (String)null); 
/*  1309 */     if (str1 == null) {
/*  1310 */       str1 = null;
/*       */     }
/*       */     
/*  1313 */     this.thinJavaxNetSslKeystorepassword = str1;
/*       */ 
/*       */     
/*  1316 */     str1 = null;
/*  1317 */     if (paramProperties != null)
/*       */     {
/*  1319 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStore");
/*       */     }
/*  1321 */     if (str1 == null)
/*  1322 */       str1 = getSystemProperty("javax.net.ssl.trustStore", (String)null); 
/*  1323 */     if (str1 == null) {
/*  1324 */       str1 = null;
/*       */     }
/*       */     
/*  1327 */     this.thinJavaxNetSslTruststore = str1;
/*       */ 
/*       */     
/*  1330 */     str1 = null;
/*  1331 */     if (paramProperties != null)
/*       */     {
/*  1333 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStoreType");
/*       */     }
/*  1335 */     if (str1 == null)
/*  1336 */       str1 = getSystemProperty("javax.net.ssl.trustStoreType", (String)null); 
/*  1337 */     if (str1 == null) {
/*  1338 */       str1 = null;
/*       */     }
/*       */     
/*  1341 */     this.thinJavaxNetSslTruststoretype = str1;
/*       */ 
/*       */     
/*  1344 */     str1 = null;
/*  1345 */     if (paramProperties != null)
/*       */     {
/*  1347 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStorePassword");
/*       */     }
/*  1349 */     if (str1 == null)
/*  1350 */       str1 = getSystemProperty("javax.net.ssl.trustStorePassword", (String)null); 
/*  1351 */     if (str1 == null) {
/*  1352 */       str1 = null;
/*       */     }
/*       */     
/*  1355 */     this.thinJavaxNetSslTruststorepassword = str1;
/*       */ 
/*       */     
/*  1358 */     str1 = null;
/*  1359 */     if (paramProperties != null) {
/*       */       
/*  1361 */       str1 = paramProperties.getProperty("ssl.keyManagerFactory.algorithm");
/*  1362 */       if (str1 == null)
/*  1363 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm"); 
/*       */     } 
/*  1365 */     if (str1 == null)
/*  1366 */       str1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", (String)null); 
/*  1367 */     if (str1 == null) {
/*  1368 */       str1 = null;
/*       */     }
/*       */     
/*  1371 */     this.thinSslKeymanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1374 */     str1 = null;
/*  1375 */     if (paramProperties != null) {
/*       */       
/*  1377 */       str1 = paramProperties.getProperty("ssl.trustManagerFactory.algorithm");
/*  1378 */       if (str1 == null)
/*  1379 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm"); 
/*       */     } 
/*  1381 */     if (str1 == null)
/*  1382 */       str1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", (String)null); 
/*  1383 */     if (str1 == null) {
/*  1384 */       str1 = null;
/*       */     }
/*       */     
/*  1387 */     this.thinSslTrustmanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1390 */     str1 = null;
/*  1391 */     if (paramProperties != null)
/*       */     {
/*  1393 */       str1 = paramProperties.getProperty("oracle.net.oldSyntax");
/*       */     }
/*  1395 */     if (str1 == null)
/*  1396 */       str1 = getSystemProperty("oracle.net.oldSyntax", (String)null); 
/*  1397 */     if (str1 == null) {
/*  1398 */       str1 = null;
/*       */     }
/*       */     
/*  1401 */     this.thinNetOldsyntax = str1;
/*       */ 
/*       */     
/*  1404 */     str1 = null;
/*  1405 */     if (paramProperties != null)
/*       */     {
/*  1407 */       str1 = paramProperties.getProperty("java.naming.factory.initial");
/*       */     }
/*  1409 */     if (str1 == null) {
/*  1410 */       str1 = null;
/*       */     }
/*       */     
/*  1413 */     this.thinNamingContextInitial = str1;
/*       */ 
/*       */     
/*  1416 */     str1 = null;
/*  1417 */     if (paramProperties != null)
/*       */     {
/*  1419 */       str1 = paramProperties.getProperty("java.naming.provider.url");
/*       */     }
/*  1421 */     if (str1 == null) {
/*  1422 */       str1 = null;
/*       */     }
/*       */     
/*  1425 */     this.thinNamingProviderUrl = str1;
/*       */ 
/*       */     
/*  1428 */     str1 = null;
/*  1429 */     if (paramProperties != null)
/*       */     {
/*  1431 */       str1 = paramProperties.getProperty("java.naming.security.authentication");
/*       */     }
/*  1433 */     if (str1 == null) {
/*  1434 */       str1 = null;
/*       */     }
/*       */     
/*  1437 */     this.thinNamingSecurityAuthentication = str1;
/*       */ 
/*       */     
/*  1440 */     str1 = null;
/*  1441 */     if (paramProperties != null)
/*       */     {
/*  1443 */       str1 = paramProperties.getProperty("java.naming.security.principal");
/*       */     }
/*  1445 */     if (str1 == null) {
/*  1446 */       str1 = null;
/*       */     }
/*       */     
/*  1449 */     this.thinNamingSecurityPrincipal = str1;
/*       */ 
/*       */     
/*  1452 */     str1 = null;
/*  1453 */     if (paramProperties != null)
/*       */     {
/*  1455 */       str1 = paramProperties.getProperty("java.naming.security.credentials");
/*       */     }
/*  1457 */     if (str1 == null) {
/*  1458 */       str1 = null;
/*       */     }
/*       */     
/*  1461 */     this.thinNamingSecurityCredentials = str1;
/*       */ 
/*       */     
/*  1464 */     str1 = null;
/*  1465 */     if (paramProperties != null)
/*       */     {
/*  1467 */       str1 = paramProperties.getProperty("oracle.net.wallet_location");
/*       */     }
/*  1469 */     if (str1 == null)
/*  1470 */       str1 = getSystemProperty("oracle.net.wallet_location", (String)null); 
/*  1471 */     if (str1 == null) {
/*  1472 */       str1 = null;
/*       */     }
/*       */     
/*  1475 */     this.walletLocation = str1;
/*       */ 
/*       */     
/*  1478 */     str1 = null;
/*  1479 */     if (paramProperties != null)
/*       */     {
/*  1481 */       str1 = paramProperties.getProperty("oracle.net.wallet_password");
/*       */     }
/*  1483 */     if (str1 == null)
/*  1484 */       str1 = getSystemProperty("oracle.net.wallet_password", (String)null); 
/*  1485 */     if (str1 == null) {
/*  1486 */       str1 = null;
/*       */     }
/*       */     
/*  1489 */     this.walletPassword = str1;
/*       */ 
/*       */     
/*  1492 */     str1 = null;
/*  1493 */     if (paramProperties != null)
/*       */     {
/*  1495 */       str1 = paramProperties.getProperty("oracle.jdbc.proxyClientName");
/*       */     }
/*  1497 */     if (str1 == null)
/*  1498 */       str1 = getSystemProperty("oracle.jdbc.proxyClientName", (String)null); 
/*  1499 */     if (str1 == null) {
/*  1500 */       str1 = null;
/*       */     }
/*       */     
/*  1503 */     this.proxyClientName = str1;
/*       */ 
/*       */     
/*  1506 */     str1 = null;
/*  1507 */     if (paramProperties != null)
/*       */     {
/*  1509 */       str1 = paramProperties.getProperty("oracle.jdbc.useNio");
/*       */     }
/*  1511 */     if (str1 == null)
/*  1512 */       str1 = getSystemProperty("oracle.jdbc.useNio", (String)null); 
/*  1513 */     if (str1 == null) {
/*  1514 */       str1 = "false";
/*       */     }
/*       */     
/*  1517 */     this.useNio = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1520 */     str1 = null;
/*  1521 */     if (paramProperties != null) {
/*       */       
/*  1523 */       str1 = paramProperties.getProperty("JDBCDriverCharSetId");
/*  1524 */       if (str1 == null)
/*  1525 */         str1 = paramProperties.getProperty("oracle.jdbc.JDBCDriverCharSetId"); 
/*       */     } 
/*  1527 */     if (str1 == null)
/*  1528 */       str1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", (String)null); 
/*  1529 */     if (str1 == null) {
/*  1530 */       str1 = null;
/*       */     }
/*       */     
/*  1533 */     this.ociDriverCharset = str1;
/*       */ 
/*       */     
/*  1536 */     str1 = null;
/*  1537 */     if (paramProperties != null)
/*       */     {
/*  1539 */       str1 = paramProperties.getProperty("oracle.jdbc.editionName");
/*       */     }
/*  1541 */     if (str1 == null)
/*  1542 */       str1 = getSystemProperty("oracle.jdbc.editionName", (String)null); 
/*  1543 */     if (str1 == null) {
/*  1544 */       str1 = null;
/*       */     }
/*       */     
/*  1547 */     this.editionName = str1;
/*       */ 
/*       */     
/*  1550 */     str1 = null;
/*  1551 */     if (paramProperties != null)
/*       */     {
/*  1553 */       str1 = paramProperties.getProperty("oracle.jdbc.thinLogonCapability");
/*       */     }
/*  1555 */     if (str1 == null)
/*  1556 */       str1 = getSystemProperty("oracle.jdbc.thinLogonCapability", (String)null); 
/*  1557 */     if (str1 == null) {
/*  1558 */       str1 = "o5";
/*       */     }
/*       */     
/*  1561 */     this.logonCap = str1;
/*       */ 
/*       */     
/*  1564 */     str1 = null;
/*  1565 */     if (paramProperties != null) {
/*       */       
/*  1567 */       str1 = paramProperties.getProperty("internal_logon");
/*  1568 */       if (str1 == null)
/*  1569 */         str1 = paramProperties.getProperty("oracle.jdbc.internal_logon"); 
/*       */     } 
/*  1571 */     if (str1 == null)
/*  1572 */       str1 = getSystemProperty("oracle.jdbc.internal_logon", (String)null); 
/*  1573 */     if (str1 == null) {
/*  1574 */       str1 = null;
/*       */     }
/*       */     
/*  1577 */     this.internalLogon = str1;
/*       */ 
/*       */     
/*  1580 */     str1 = null;
/*  1581 */     if (paramProperties != null)
/*       */     {
/*  1583 */       str1 = paramProperties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
/*       */     }
/*  1585 */     if (str1 == null)
/*  1586 */       str1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", (String)null); 
/*  1587 */     if (str1 == null) {
/*  1588 */       str1 = "false";
/*       */     }
/*       */     
/*  1591 */     this.createDescriptorUseCurrentSchemaForSchemaName = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1594 */     str1 = null;
/*  1595 */     if (paramProperties != null) {
/*       */       
/*  1597 */       str1 = paramProperties.getProperty("OCISvcCtxHandle");
/*  1598 */       if (str1 == null)
/*  1599 */         str1 = paramProperties.getProperty("oracle.jdbc.OCISvcCtxHandle"); 
/*       */     } 
/*  1601 */     if (str1 == null)
/*  1602 */       str1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", (String)null); 
/*  1603 */     if (str1 == null) {
/*  1604 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1607 */       this.ociSvcCtxHandle = Long.parseLong(str1);
/*  1608 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1612 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
/*  1613 */       sQLException.fillInStackTrace();
/*  1614 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1620 */     str1 = null;
/*  1621 */     if (paramProperties != null) {
/*       */       
/*  1623 */       str1 = paramProperties.getProperty("OCIEnvHandle");
/*  1624 */       if (str1 == null)
/*  1625 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIEnvHandle"); 
/*       */     } 
/*  1627 */     if (str1 == null)
/*  1628 */       str1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", (String)null); 
/*  1629 */     if (str1 == null) {
/*  1630 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1633 */       this.ociEnvHandle = Long.parseLong(str1);
/*  1634 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1638 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
/*  1639 */       sQLException.fillInStackTrace();
/*  1640 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1646 */     str1 = null;
/*  1647 */     if (paramProperties != null) {
/*       */       
/*  1649 */       str1 = paramProperties.getProperty("OCIErrHandle");
/*  1650 */       if (str1 == null)
/*  1651 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIErrHandle"); 
/*       */     } 
/*  1653 */     if (str1 == null)
/*  1654 */       str1 = getSystemProperty("oracle.jdbc.OCIErrHandle", (String)null); 
/*  1655 */     if (str1 == null) {
/*  1656 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1659 */       this.ociErrHandle = Long.parseLong(str1);
/*  1660 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1664 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
/*  1665 */       sQLException.fillInStackTrace();
/*  1666 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1672 */     str1 = null;
/*  1673 */     if (paramProperties != null) {
/*       */       
/*  1675 */       str1 = paramProperties.getProperty("prelim_auth");
/*  1676 */       if (str1 == null)
/*  1677 */         str1 = paramProperties.getProperty("oracle.jdbc.prelim_auth"); 
/*       */     } 
/*  1679 */     if (str1 == null)
/*  1680 */       str1 = getSystemProperty("oracle.jdbc.prelim_auth", (String)null); 
/*  1681 */     if (str1 == null) {
/*  1682 */       str1 = "false";
/*       */     }
/*       */     
/*  1685 */     this.prelimAuth = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1688 */     str1 = null;
/*  1689 */     if (paramProperties != null)
/*       */     {
/*  1691 */       str1 = paramProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
/*       */     }
/*  1693 */     if (str1 == null)
/*  1694 */       str1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", (String)null); 
/*  1695 */     if (str1 == null) {
/*  1696 */       str1 = "false";
/*       */     }
/*       */     
/*  1699 */     this.nlsLangBackdoor = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1702 */     str1 = null;
/*  1703 */     if (paramProperties != null) {
/*       */       
/*  1705 */       str1 = paramProperties.getProperty("OCINewPassword");
/*  1706 */       if (str1 == null)
/*  1707 */         str1 = paramProperties.getProperty("oracle.jdbc.OCINewPassword"); 
/*       */     } 
/*  1709 */     if (str1 == null)
/*  1710 */       str1 = getSystemProperty("oracle.jdbc.OCINewPassword", (String)null); 
/*  1711 */     if (str1 == null) {
/*  1712 */       str1 = null;
/*       */     }
/*       */     
/*  1715 */     this.setNewPassword = str1;
/*       */ 
/*       */     
/*  1718 */     str1 = null;
/*  1719 */     if (paramProperties != null)
/*       */     {
/*  1721 */       str1 = paramProperties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
/*       */     }
/*  1723 */     if (str1 == null)
/*  1724 */       str1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", (String)null); 
/*  1725 */     if (str1 == null) {
/*  1726 */       str1 = "false";
/*       */     }
/*       */     
/*  1729 */     this.spawnNewThreadToCancel = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1732 */     str1 = null;
/*  1733 */     if (paramProperties != null) {
/*       */       
/*  1735 */       str1 = paramProperties.getProperty("defaultExecuteBatch");
/*  1736 */       if (str1 == null)
/*  1737 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultExecuteBatch"); 
/*       */     } 
/*  1739 */     if (str1 == null)
/*  1740 */       str1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", (String)null); 
/*  1741 */     if (str1 == null) {
/*  1742 */       str1 = "1";
/*       */     }
/*       */     try {
/*  1745 */       this.defaultExecuteBatch = Integer.parseInt(str1);
/*  1746 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1750 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
/*  1751 */       sQLException.fillInStackTrace();
/*  1752 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1758 */     str1 = null;
/*  1759 */     if (paramProperties != null) {
/*       */       
/*  1761 */       str1 = paramProperties.getProperty("defaultRowPrefetch");
/*  1762 */       if (str1 == null)
/*  1763 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultRowPrefetch"); 
/*       */     } 
/*  1765 */     if (str1 == null)
/*  1766 */       str1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", (String)null); 
/*  1767 */     if (str1 == null) {
/*  1768 */       str1 = "10";
/*       */     }
/*       */     try {
/*  1771 */       this.defaultRowPrefetch = Integer.parseInt(str1);
/*  1772 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1776 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
/*  1777 */       sQLException.fillInStackTrace();
/*  1778 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1784 */     str1 = null;
/*  1785 */     if (paramProperties != null)
/*       */     {
/*  1787 */       str1 = paramProperties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
/*       */     }
/*  1789 */     if (str1 == null)
/*  1790 */       str1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", (String)null); 
/*  1791 */     if (str1 == null) {
/*  1792 */       str1 = "4000";
/*       */     }
/*       */     try {
/*  1795 */       this.defaultLobPrefetchSize = Integer.parseInt(str1);
/*  1796 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1800 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
/*  1801 */       sQLException.fillInStackTrace();
/*  1802 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1808 */     str1 = null;
/*  1809 */     if (paramProperties != null)
/*       */     {
/*  1811 */       str1 = paramProperties.getProperty("oracle.jdbc.enableDataInLocator");
/*       */     }
/*  1813 */     if (str1 == null)
/*  1814 */       str1 = getSystemProperty("oracle.jdbc.enableDataInLocator", (String)null); 
/*  1815 */     if (str1 == null) {
/*  1816 */       str1 = "true";
/*       */     }
/*       */     
/*  1819 */     this.enableDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1822 */     str1 = null;
/*  1823 */     if (paramProperties != null)
/*       */     {
/*  1825 */       str1 = paramProperties.getProperty("oracle.jdbc.enableReadDataInLocator");
/*       */     }
/*  1827 */     if (str1 == null)
/*  1828 */       str1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", (String)null); 
/*  1829 */     if (str1 == null) {
/*  1830 */       str1 = "true";
/*       */     }
/*       */     
/*  1833 */     this.enableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1836 */     str1 = null;
/*  1837 */     if (paramProperties != null)
/*       */     {
/*  1839 */       str1 = paramProperties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
/*       */     }
/*  1841 */     if (str1 == null)
/*  1842 */       str1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", (String)null); 
/*  1843 */     if (str1 == null) {
/*  1844 */       str1 = "false";
/*       */     }
/*       */     
/*  1847 */     this.overrideEnableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1850 */     str1 = null;
/*  1851 */     if (paramProperties != null) {
/*       */       
/*  1853 */       str1 = paramProperties.getProperty("remarksReporting");
/*  1854 */       if (str1 == null)
/*  1855 */         str1 = paramProperties.getProperty("oracle.jdbc.remarksReporting"); 
/*       */     } 
/*  1857 */     if (str1 == null)
/*  1858 */       str1 = getSystemProperty("oracle.jdbc.remarksReporting", (String)null); 
/*  1859 */     if (str1 == null) {
/*  1860 */       str1 = "false";
/*       */     }
/*       */     
/*  1863 */     this.reportRemarks = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1866 */     str1 = null;
/*  1867 */     if (paramProperties != null) {
/*       */       
/*  1869 */       str1 = paramProperties.getProperty("includeSynonyms");
/*  1870 */       if (str1 == null)
/*  1871 */         str1 = paramProperties.getProperty("oracle.jdbc.includeSynonyms"); 
/*       */     } 
/*  1873 */     if (str1 == null)
/*  1874 */       str1 = getSystemProperty("oracle.jdbc.includeSynonyms", (String)null); 
/*  1875 */     if (str1 == null) {
/*  1876 */       str1 = "false";
/*       */     }
/*       */     
/*  1879 */     this.includeSynonyms = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1882 */     str1 = null;
/*  1883 */     if (paramProperties != null) {
/*       */       
/*  1885 */       str1 = paramProperties.getProperty("restrictGetTables");
/*  1886 */       if (str1 == null)
/*  1887 */         str1 = paramProperties.getProperty("oracle.jdbc.restrictGetTables"); 
/*       */     } 
/*  1889 */     if (str1 == null)
/*  1890 */       str1 = getSystemProperty("oracle.jdbc.restrictGetTables", (String)null); 
/*  1891 */     if (str1 == null) {
/*  1892 */       str1 = "false";
/*       */     }
/*       */     
/*  1895 */     this.restrictGettables = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1898 */     str1 = null;
/*  1899 */     if (paramProperties != null) {
/*       */       
/*  1901 */       str1 = paramProperties.getProperty("AccumulateBatchResult");
/*  1902 */       if (str1 == null)
/*  1903 */         str1 = paramProperties.getProperty("oracle.jdbc.AccumulateBatchResult"); 
/*       */     } 
/*  1905 */     if (str1 == null)
/*  1906 */       str1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", (String)null); 
/*  1907 */     if (str1 == null) {
/*  1908 */       str1 = "true";
/*       */     }
/*       */     
/*  1911 */     this.accumulateBatchResult = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1914 */     str1 = null;
/*  1915 */     if (paramProperties != null) {
/*       */       
/*  1917 */       str1 = paramProperties.getProperty("useFetchSizeWithLongColumn");
/*  1918 */       if (str1 == null)
/*  1919 */         str1 = paramProperties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn"); 
/*       */     } 
/*  1921 */     if (str1 == null)
/*  1922 */       str1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", (String)null); 
/*  1923 */     if (str1 == null) {
/*  1924 */       str1 = "false";
/*       */     }
/*       */     
/*  1927 */     this.useFetchSizeWithLongColumn = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1930 */     str1 = null;
/*  1931 */     if (paramProperties != null) {
/*       */       
/*  1933 */       str1 = paramProperties.getProperty("processEscapes");
/*  1934 */       if (str1 == null)
/*  1935 */         str1 = paramProperties.getProperty("oracle.jdbc.processEscapes"); 
/*       */     } 
/*  1937 */     if (str1 == null)
/*  1938 */       str1 = getSystemProperty("oracle.jdbc.processEscapes", (String)null); 
/*  1939 */     if (str1 == null) {
/*  1940 */       str1 = "true";
/*       */     }
/*       */     
/*  1943 */     this.processEscapes = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1946 */     str1 = null;
/*  1947 */     if (paramProperties != null) {
/*       */       
/*  1949 */       str1 = paramProperties.getProperty("fixedString");
/*  1950 */       if (str1 == null)
/*  1951 */         str1 = paramProperties.getProperty("oracle.jdbc.fixedString"); 
/*       */     } 
/*  1953 */     if (str1 == null)
/*  1954 */       str1 = getSystemProperty("oracle.jdbc.fixedString", (String)null); 
/*  1955 */     if (str1 == null) {
/*  1956 */       str1 = "false";
/*       */     }
/*       */     
/*  1959 */     this.fixedString = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1962 */     str1 = null;
/*  1963 */     if (paramProperties != null) {
/*       */       
/*  1965 */       str1 = paramProperties.getProperty("defaultNChar");
/*  1966 */       if (str1 == null)
/*  1967 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultNChar"); 
/*       */     } 
/*  1969 */     if (str1 == null)
/*  1970 */       str1 = getSystemProperty("oracle.jdbc.defaultNChar", (String)null); 
/*  1971 */     if (str1 == null) {
/*  1972 */       str1 = "false";
/*       */     }
/*       */     
/*  1975 */     this.defaultnchar = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1978 */     str1 = null;
/*  1979 */     if (paramProperties != null)
/*       */     {
/*  1981 */       str1 = paramProperties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
/*       */     }
/*  1983 */     if (str1 == null)
/*  1984 */       str1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", (String)null); 
/*  1985 */     if (str1 == null) {
/*  1986 */       str1 = "false";
/*       */     }
/*       */     
/*  1989 */     this.permitTimestampDateMismatch = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1992 */     str1 = null;
/*  1993 */     if (paramProperties != null) {
/*       */       
/*  1995 */       str1 = paramProperties.getProperty("RessourceManagerId");
/*  1996 */       if (str1 == null)
/*  1997 */         str1 = paramProperties.getProperty("oracle.jdbc.RessourceManagerId"); 
/*       */     } 
/*  1999 */     if (str1 == null)
/*  2000 */       str1 = getSystemProperty("oracle.jdbc.RessourceManagerId", (String)null); 
/*  2001 */     if (str1 == null) {
/*  2002 */       str1 = "0000";
/*       */     }
/*       */     
/*  2005 */     this.resourceManagerId = str1;
/*       */ 
/*       */     
/*  2008 */     str1 = null;
/*  2009 */     if (paramProperties != null) {
/*       */       
/*  2011 */       str1 = paramProperties.getProperty("disableDefineColumnType");
/*  2012 */       if (str1 == null)
/*  2013 */         str1 = paramProperties.getProperty("oracle.jdbc.disableDefineColumnType"); 
/*       */     } 
/*  2015 */     if (str1 == null)
/*  2016 */       str1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", (String)null); 
/*  2017 */     if (str1 == null) {
/*  2018 */       str1 = "false";
/*       */     }
/*       */     
/*  2021 */     this.disableDefinecolumntype = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2024 */     str1 = null;
/*  2025 */     if (paramProperties != null)
/*       */     {
/*  2027 */       str1 = paramProperties.getProperty("oracle.jdbc.convertNcharLiterals");
/*       */     }
/*  2029 */     if (str1 == null)
/*  2030 */       str1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", (String)null); 
/*  2031 */     if (str1 == null) {
/*  2032 */       str1 = "false";
/*       */     }
/*       */     
/*  2035 */     this.convertNcharLiterals = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2038 */     str1 = null;
/*  2039 */     if (paramProperties != null)
/*       */     {
/*  2041 */       str1 = paramProperties.getProperty("oracle.jdbc.J2EE13Compliant");
/*       */     }
/*  2043 */     if (str1 == null)
/*  2044 */       str1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", (String)null); 
/*  2045 */     if (str1 == null) {
/*  2046 */       str1 = "false";
/*       */     }
/*       */     
/*  2049 */     this.j2ee13Compliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2052 */     str1 = null;
/*  2053 */     if (paramProperties != null)
/*       */     {
/*  2055 */       str1 = paramProperties.getProperty("oracle.jdbc.mapDateToTimestamp");
/*       */     }
/*  2057 */     if (str1 == null)
/*  2058 */       str1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", (String)null); 
/*  2059 */     if (str1 == null) {
/*  2060 */       str1 = "true";
/*       */     }
/*       */     
/*  2063 */     this.mapDateToTimestamp = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2066 */     str1 = null;
/*  2067 */     if (paramProperties != null)
/*       */     {
/*  2069 */       str1 = paramProperties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
/*       */     }
/*  2071 */     if (str1 == null)
/*  2072 */       str1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", (String)null); 
/*  2073 */     if (str1 == null) {
/*  2074 */       str1 = "false";
/*       */     }
/*       */     
/*  2077 */     this.useThreadLocalBufferCache = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2080 */     str1 = null;
/*  2081 */     if (paramProperties != null)
/*       */     {
/*  2083 */       str1 = paramProperties.getProperty("oracle.jdbc.driverNameAttribute");
/*       */     }
/*  2085 */     if (str1 == null)
/*  2086 */       str1 = getSystemProperty("oracle.jdbc.driverNameAttribute", (String)null); 
/*  2087 */     if (str1 == null) {
/*  2088 */       str1 = null;
/*       */     }
/*       */     
/*  2091 */     this.driverNameAttribute = str1;
/*       */ 
/*       */     
/*  2094 */     str1 = null;
/*  2095 */     if (paramProperties != null)
/*       */     {
/*  2097 */       str1 = paramProperties.getProperty("oracle.jdbc.maxCachedBufferSize");
/*       */     }
/*  2099 */     if (str1 == null)
/*  2100 */       str1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", (String)null); 
/*  2101 */     if (str1 == null) {
/*  2102 */       str1 = "30";
/*       */     }
/*       */     try {
/*  2105 */       this.maxCachedBufferSize = Integer.parseInt(str1);
/*  2106 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2110 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
/*  2111 */       sQLException.fillInStackTrace();
/*  2112 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2118 */     str1 = null;
/*  2119 */     if (paramProperties != null)
/*       */     {
/*  2121 */       str1 = paramProperties.getProperty("oracle.jdbc.implicitStatementCacheSize");
/*       */     }
/*  2123 */     if (str1 == null)
/*  2124 */       str1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", (String)null); 
/*  2125 */     if (str1 == null) {
/*  2126 */       str1 = "0";
/*       */     }
/*       */     try {
/*  2129 */       this.implicitStatementCacheSize = Integer.parseInt(str1);
/*  2130 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2134 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
/*  2135 */       sQLException.fillInStackTrace();
/*  2136 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2142 */     str1 = null;
/*  2143 */     if (paramProperties != null)
/*       */     {
/*  2145 */       str1 = paramProperties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
/*       */     }
/*  2147 */     if (str1 == null)
/*  2148 */       str1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", (String)null); 
/*  2149 */     if (str1 == null) {
/*  2150 */       str1 = "false";
/*       */     }
/*       */     
/*  2153 */     this.lobStreamPosStandardCompliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2156 */     str1 = null;
/*  2157 */     if (paramProperties != null)
/*       */     {
/*  2159 */       str1 = paramProperties.getProperty("oracle.jdbc.strictASCIIConversion");
/*       */     }
/*  2161 */     if (str1 == null)
/*  2162 */       str1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", (String)null); 
/*  2163 */     if (str1 == null) {
/*  2164 */       str1 = "false";
/*       */     }
/*       */     
/*  2167 */     this.isStrictAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2170 */     str1 = null;
/*  2171 */     if (paramProperties != null)
/*       */     {
/*  2173 */       str1 = paramProperties.getProperty("oracle.jdbc.quickASCIIConversion");
/*       */     }
/*  2175 */     if (str1 == null)
/*  2176 */       str1 = getSystemProperty("oracle.jdbc.quickASCIIConversion", (String)null); 
/*  2177 */     if (str1 == null) {
/*  2178 */       str1 = "false";
/*       */     }
/*       */     
/*  2181 */     this.isQuickAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2184 */     str1 = null;
/*  2185 */     if (paramProperties != null)
/*       */     {
/*  2187 */       str1 = paramProperties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
/*       */     }
/*  2189 */     if (str1 == null)
/*  2190 */       str1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", (String)null); 
/*  2191 */     if (str1 == null) {
/*  2192 */       str1 = "false";
/*       */     }
/*       */     
/*  2195 */     this.thinForceDnsLoadBalancing = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2198 */     str1 = null;
/*  2199 */     if (paramProperties != null)
/*       */     {
/*  2201 */       str1 = paramProperties.getProperty("oracle.jdbc.enableJavaNetFastPath");
/*       */     }
/*  2203 */     if (str1 == null)
/*  2204 */       str1 = getSystemProperty("oracle.jdbc.enableJavaNetFastPath", (String)null); 
/*  2205 */     if (str1 == null) {
/*  2206 */       str1 = "false";
/*       */     }
/*       */     
/*  2209 */     this.enableJavaNetFastPath = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2212 */     str1 = null;
/*  2213 */     if (paramProperties != null)
/*       */     {
/*  2215 */       str1 = paramProperties.getProperty("oracle.jdbc.enableTempLobRefCnt");
/*       */     }
/*  2217 */     if (str1 == null)
/*  2218 */       str1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", (String)null); 
/*  2219 */     if (str1 == null) {
/*  2220 */       str1 = "true";
/*       */     }
/*       */     
/*  2223 */     this.enableTempLobRefCnt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2226 */     str1 = null;
/*  2227 */     if (paramProperties != null)
/*       */     {
/*  2229 */       str1 = paramProperties.getProperty("oracle.jdbc.plsqlVarcharParameter4KOnly");
/*       */     }
/*  2231 */     if (str1 == null)
/*  2232 */       str1 = getSystemProperty("oracle.jdbc.plsqlVarcharParameter4KOnly", (String)null); 
/*  2233 */     if (str1 == null) {
/*  2234 */       str1 = "false";
/*       */     }
/*       */     
/*  2237 */     this.plsqlVarcharParameter4KOnly = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2240 */     str1 = null;
/*  2241 */     if (paramProperties != null)
/*       */     {
/*  2243 */       str1 = paramProperties.getProperty("oracle.net.keepAlive");
/*       */     }
/*  2245 */     if (str1 == null)
/*  2246 */       str1 = getSystemProperty("oracle.net.keepAlive", (String)null); 
/*  2247 */     if (str1 == null) {
/*  2248 */       str1 = "false";
/*       */     }
/*       */     
/*  2251 */     this.keepAlive = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */ 
/*       */     
/*  2255 */     str1 = null;
/*  2256 */     if (paramProperties != null)
/*  2257 */       str1 = paramProperties.getProperty("oracle.jdbc.commitOption"); 
/*  2258 */     if (str1 == null)
/*  2259 */       str1 = getSystemProperty("oracle.jdbc.commitOption", (String)null); 
/*  2260 */     if (str1 != null) {
/*       */       
/*  2262 */       this.commitOption = 0;
/*  2263 */       String[] arrayOfString = str1.split(",");
/*  2264 */       if (arrayOfString != null && arrayOfString.length > 0)
/*       */       {
/*  2266 */         for (String str : arrayOfString) {
/*  2267 */           if (str.trim() != "") {
/*  2268 */             this.commitOption |= OracleConnection.CommitOption.valueOf(str.trim()).getCode();
/*       */           }
/*       */         } 
/*       */       }
/*       */     } 
/*  2273 */     str1 = null;
/*  2274 */     if (paramProperties != null)
/*       */     {
/*  2276 */       str1 = paramProperties.getProperty("oracle.jdbc.calculateChecksum");
/*       */     }
/*  2278 */     if (str1 == null)
/*  2279 */       str1 = getSystemProperty("oracle.jdbc.calculateChecksum", (String)null); 
/*  2280 */     if (str1 == null) {
/*  2281 */       str1 = "false";
/*       */     }
/*       */     
/*  2284 */     this.calculateChecksum = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2289 */     this.includeSynonyms = parseConnectionProperty_boolean(paramProperties, "synonyms", (byte)3, this.includeSynonyms);
/*       */ 
/*       */     
/*  2292 */     this.reportRemarks = parseConnectionProperty_boolean(paramProperties, "remarks", (byte)3, this.reportRemarks);
/*       */ 
/*       */     
/*  2295 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "prefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2298 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2301 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "batch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2304 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "executeBatch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2307 */     this.proxyClientName = parseConnectionProperty_String(paramProperties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2313 */     if (this.defaultRowPrefetch <= 0) {
/*  2314 */       this.defaultRowPrefetch = Integer.parseInt("10");
/*       */     }
/*  2316 */     if (this.defaultExecuteBatch <= 0) {
/*  2317 */       this.defaultExecuteBatch = Integer.parseInt("1");
/*       */     }
/*  2319 */     if (this.defaultLobPrefetchSize < -1) {
/*       */       
/*  2321 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/*  2322 */       sQLException.fillInStackTrace();
/*  2323 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2330 */     if (this.streamChunkSize > 0) {
/*  2331 */       this.streamChunkSize = Math.max(4096, this.streamChunkSize);
/*       */     } else {
/*  2333 */       this.streamChunkSize = Integer.parseInt("16384");
/*       */     } 
/*       */ 
/*       */     
/*  2337 */     if (this.thinVsessionOsuser == null) {
/*       */       
/*  2339 */       this.thinVsessionOsuser = getSystemProperty("user.name", (String)null);
/*  2340 */       if (this.thinVsessionOsuser == null) {
/*  2341 */         this.thinVsessionOsuser = "jdbcuser";
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2348 */     if (this.thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT) {
/*       */       
/*  2350 */       int i = DriverManager.getLoginTimeout();
/*  2351 */       if (i != 0) {
/*  2352 */         this.thinNetConnectTimeout = "" + (i * 1000);
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2360 */     this.url = paramString;
/*  2361 */     Hashtable hashtable = parseUrl(this.url, this.walletLocation, this.walletPassword);
/*       */     
/*  2363 */     if (this.userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
/*  2364 */       this.userName = (String)hashtable.get("user"); 
/*  2365 */     String[] arrayOfString1 = new String[1];
/*  2366 */     String[] arrayOfString2 = new String[1];
/*  2367 */     this.userName = parseLoginOption(this.userName, paramProperties, arrayOfString1, arrayOfString2);
/*  2368 */     if (arrayOfString1[0] != null)
/*  2369 */       this.internalLogon = arrayOfString1[0]; 
/*  2370 */     if (arrayOfString2[0] != null) {
/*  2371 */       this.proxyClientName = arrayOfString2[0];
/*       */     }
/*  2373 */     String str2 = paramProperties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
/*       */     
/*  2375 */     if (str2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
/*  2376 */       str2 = (String)hashtable.get("password"); 
/*  2377 */     initializePassword(str2);
/*       */     
/*  2379 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2380 */       this.database = paramProperties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
/*       */     }
/*  2382 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2383 */       this.database = (String)hashtable.get("database");
/*       */     }
/*  2385 */     this.protocol = (String)hashtable.get("protocol");
/*       */ 
/*       */     
/*  2388 */     if (this.protocol == null) {
/*       */ 
/*       */       
/*  2391 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
/*  2392 */       sQLException.fillInStackTrace();
/*  2393 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2398 */     if (this.protocol.equals("oci8") || this.protocol.equals("oci")) {
/*  2399 */       this.database = translateConnStr(this.database);
/*       */     }
/*       */     
/*  2402 */     if (paramProperties.getProperty("is_connection_pooling") == "true")
/*       */     {
/*       */       
/*  2405 */       if (this.database == null) {
/*  2406 */         this.database = "";
/*       */       }
/*       */     }
/*  2409 */     if (this.userName != null && !this.userName.startsWith("\"")) {
/*       */ 
/*       */       
/*  2412 */       char[] arrayOfChar = this.userName.toCharArray();
/*  2413 */       for (byte b = 0; b < arrayOfChar.length; b++)
/*  2414 */         arrayOfChar[b] = Character.toUpperCase(arrayOfChar[b]); 
/*  2415 */       this.userName = String.copyValueOf(arrayOfChar);
/*       */     } 
/*       */ 
/*       */     
/*  2419 */     this.xaWantsError = false;
/*  2420 */     this.usingXA = false;
/*       */     
/*  2422 */     readOCIConnectionPoolProperties(paramProperties);
/*  2423 */     validateConnectionProperties();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readOCIConnectionPoolProperties(Properties paramProperties) throws SQLException {
/*  2432 */     this.ociConnectionPoolMinLimit = parseConnectionProperty_int(paramProperties, "connpool_min_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2435 */     this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(paramProperties, "connpool_max_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2438 */     this.ociConnectionPoolIncrement = parseConnectionProperty_int(paramProperties, "connpool_increment", (byte)1, 0);
/*       */ 
/*       */     
/*  2441 */     this.ociConnectionPoolTimeout = parseConnectionProperty_int(paramProperties, "connpool_timeout", (byte)1, 0);
/*       */ 
/*       */     
/*  2444 */     this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(paramProperties, "connpool_nowait", (byte)1, false);
/*       */ 
/*       */     
/*  2447 */     this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(paramProperties, "transactions_distributed", (byte)1, false);
/*       */ 
/*       */     
/*  2450 */     this.ociConnectionPoolLogonMode = parseConnectionProperty_String(paramProperties, "connection_pool", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2453 */     this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(paramProperties, "is_connection_pooling", (byte)1, false);
/*       */ 
/*       */     
/*  2456 */     this.ociConnectionPoolObject = parseConnectionProperty_Object(paramProperties, "connpool_object", (Object)null);
/*       */     
/*  2458 */     this.ociConnectionPoolConnID = parseConnectionProperty_Object(paramProperties, "connection_id", (Object)null);
/*       */     
/*  2460 */     this.ociConnectionPoolProxyType = parseConnectionProperty_String(paramProperties, "proxytype", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2463 */     this.ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(paramProperties, "proxy_num_roles", Integer.valueOf(0));
/*       */     
/*  2465 */     this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(paramProperties, "proxy_roles", (Object)null);
/*       */     
/*  2467 */     this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(paramProperties, "proxy_user_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2470 */     this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(paramProperties, "proxy_password", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2473 */     this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(paramProperties, "proxy_distinguished_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2476 */     this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(paramProperties, "proxy_certificate", (Object)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  2483 */   private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void validateConnectionProperties() throws SQLException {
/*  2493 */     if (this.driverNameAttribute != null && !driverNameAttributePattern.matcher(this.driverNameAttribute).matches()) {
/*       */ 
/*       */       
/*  2496 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
/*  2497 */       sQLException.fillInStackTrace();
/*  2498 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Object parseConnectionProperty_Object(Properties paramProperties, String paramString, Object paramObject) throws SQLException {
/*  2515 */     Object object = paramObject;
/*  2516 */     if (paramProperties != null) {
/*       */       
/*  2518 */       Object object1 = paramProperties.get(paramString);
/*  2519 */       if (object1 != null)
/*  2520 */         object = object1; 
/*       */     } 
/*  2522 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String parseConnectionProperty_String(Properties paramProperties, String paramString1, byte paramByte, String paramString2) throws SQLException {
/*  2551 */     String str = null;
/*  2552 */     if ((paramByte == 1 || paramByte == 3) && paramProperties != null) {
/*       */ 
/*       */       
/*  2555 */       str = paramProperties.getProperty(paramString1);
/*  2556 */       if (str == null && !paramString1.startsWith("oracle.") && !paramString1.startsWith("java.") && !paramString1.startsWith("javax."))
/*  2557 */         str = paramProperties.getProperty("oracle.jdbc." + paramString1); 
/*       */     } 
/*  2559 */     if (str == null && (paramByte == 2 || paramByte == 3))
/*       */     {
/*       */       
/*  2562 */       if (paramString1.startsWith("oracle.") || paramString1.startsWith("java.") || paramString1.startsWith("javax.")) {
/*  2563 */         str = getSystemProperty(paramString1, (String)null);
/*       */       } else {
/*  2565 */         str = getSystemProperty("oracle.jdbc." + paramString1, (String)null);
/*       */       }  } 
/*  2567 */     if (str == null)
/*  2568 */       str = paramString2; 
/*  2569 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int parseConnectionProperty_int(Properties paramProperties, String paramString, byte paramByte, int paramInt) throws SQLException {
/*  2580 */     int i = paramInt;
/*  2581 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2586 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2590 */         i = Integer.parseInt(str);
/*       */       }
/*  2592 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2596 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2597 */         sQLException.fillInStackTrace();
/*  2598 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2603 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final long parseConnectionProperty_long(Properties paramProperties, String paramString, byte paramByte, long paramLong) throws SQLException {
/*  2614 */     long l = paramLong;
/*  2615 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2620 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2624 */         l = Long.parseLong(str);
/*       */       }
/*  2626 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2630 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2631 */         sQLException.fillInStackTrace();
/*  2632 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2637 */     return l;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final boolean parseConnectionProperty_boolean(Properties paramProperties, String paramString, byte paramByte, boolean paramBoolean) throws SQLException {
/*  2648 */     boolean bool = paramBoolean;
/*  2649 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2654 */     if (str != null)
/*       */     {
/*  2656 */       if (str.equalsIgnoreCase("false")) {
/*  2657 */         bool = false;
/*  2658 */       } else if (str.equalsIgnoreCase("true")) {
/*  2659 */         bool = true;
/*       */       }  } 
/*  2661 */     return bool;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String parseLoginOption(String paramString, Properties paramProperties, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*  2681 */     int j = 0;
/*  2682 */     String str1 = null;
/*  2683 */     String str2 = null;
/*       */ 
/*       */     
/*  2686 */     if (paramString == null) {
/*  2687 */       return null;
/*       */     }
/*  2689 */     int k = paramString.length();
/*       */     
/*  2691 */     if (k == 0) {
/*  2692 */       return null;
/*       */     }
/*       */     
/*  2695 */     int i = paramString.indexOf('[');
/*  2696 */     if (i > 0) {
/*  2697 */       j = paramString.indexOf(']');
/*  2698 */       str2 = paramString.substring(i + 1, j);
/*  2699 */       str2 = str2.trim();
/*       */       
/*  2701 */       if (str2.length() > 0) {
/*  2702 */         paramArrayOfString2[0] = str2;
/*       */       }
/*       */       
/*  2705 */       paramString = paramString.substring(0, i) + paramString.substring(j + 1, k);
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2710 */     String str3 = paramString.toLowerCase();
/*       */ 
/*       */     
/*  2713 */     i = str3.lastIndexOf(" as ");
/*       */     
/*  2715 */     if (i == -1 || i < str3.lastIndexOf("\"")) {
/*  2716 */       return paramString;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  2721 */     str1 = paramString.substring(0, i);
/*       */     
/*  2723 */     i += 4;
/*       */ 
/*       */     
/*  2726 */     while (i < k && str3.charAt(i) == ' ') {
/*  2727 */       i++;
/*       */     }
/*  2729 */     if (i == k) {
/*  2730 */       return paramString;
/*       */     }
/*  2732 */     String str4 = str3.substring(i).trim();
/*       */     
/*  2734 */     if (str4.length() > 0) {
/*  2735 */       paramArrayOfString1[0] = str4;
/*       */     }
/*  2737 */     return str1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Hashtable parseUrl(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  2758 */     Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(5);
/*  2759 */     int i = paramString1.indexOf(':', paramString1.indexOf(':') + 1) + 1;
/*  2760 */     int j = paramString1.length();
/*       */ 
/*       */     
/*  2763 */     if (i == j) {
/*  2764 */       return hashtable;
/*       */     }
/*  2766 */     int k = paramString1.indexOf(':', i);
/*       */ 
/*       */     
/*  2769 */     if (k == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2775 */       return hashtable;
/*       */     }
/*       */ 
/*       */     
/*  2779 */     hashtable.put("protocol", paramString1.substring(i, k));
/*       */     
/*  2781 */     int m = k + 1;
/*  2782 */     int n = paramString1.indexOf('/', m);
/*       */     
/*  2784 */     int i1 = paramString1.indexOf('@', m);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2789 */     if (i1 > m && m > i && n == -1) {
/*       */ 
/*       */       
/*  2792 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 67);
/*  2793 */       sQLException.fillInStackTrace();
/*  2794 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2798 */     if (i1 == -1) {
/*  2799 */       i1 = j;
/*       */     }
/*  2801 */     if (n == -1) {
/*  2802 */       n = i1;
/*       */     }
/*  2804 */     if (n < i1 && n != m && i1 != m) {
/*       */       
/*  2806 */       hashtable.put("user", paramString1.substring(m, n));
/*  2807 */       hashtable.put("password", paramString1.substring(n + 1, i1));
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2813 */     if (n <= i1 && (n == m || i1 == m))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2820 */       if (i1 < j) {
/*       */         
/*  2822 */         String str = paramString1.substring(i1 + 1);
/*  2823 */         String[] arrayOfString = getSecretStoreCredentials(str, paramString2, paramString3);
/*  2824 */         if (arrayOfString[0] != null || arrayOfString[1] != null) {
/*       */           
/*  2826 */           hashtable.put("user", arrayOfString[0]);
/*  2827 */           hashtable.put("password", arrayOfString[1]);
/*       */         } 
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2833 */     if (i1 < j) {
/*  2834 */       hashtable.put("database", paramString1.substring(i1 + 1));
/*       */     }
/*  2836 */     return hashtable;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final synchronized String[] getSecretStoreCredentials(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  2998 */     String[] arrayOfString = new String[2];
/*  2999 */     arrayOfString[0] = null;
/*  3000 */     arrayOfString[1] = null;
/*       */     
/*  3002 */     if (paramString2 != null) {
/*       */       
/*       */       try {
/*       */         
/*  3006 */         if (paramString2.startsWith("(")) {
/*  3007 */           paramString2 = "file:" + CustomSSLSocketFactory.processWalletLocation(paramString2);
/*       */         }
/*  3009 */         OracleWallet oracleWallet = new OracleWallet();
/*  3010 */         if (oracleWallet.exists(paramString2)) {
/*       */ 
/*       */ 
/*       */           
/*  3014 */           char[] arrayOfChar = null;
/*  3015 */           if (paramString3 != null) {
/*  3016 */             arrayOfChar = paramString3.toCharArray();
/*       */           }
/*       */ 
/*       */           
/*  3020 */           oracleWallet.open(paramString2, arrayOfChar);
/*  3021 */           OracleSecretStore oracleSecretStore = oracleWallet.getSecretStore();
/*       */ 
/*       */ 
/*       */           
/*  3025 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_username")) {
/*  3026 */             arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.default_username"));
/*       */           }
/*  3028 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_password")) {
/*  3029 */             arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.default_password"));
/*       */           }
/*       */           
/*  3032 */           Enumeration<String> enumeration = oracleWallet.getSecretStore().internalAliases();
/*       */           
/*  3034 */           String str = null;
/*  3035 */           while (enumeration.hasMoreElements()) {
/*       */             
/*  3037 */             str = enumeration.nextElement();
/*  3038 */             if (str.startsWith("oracle.security.client.connect_string"))
/*       */             {
/*  3040 */               if (paramString1.equalsIgnoreCase(new String(oracleSecretStore.getSecret(str)))) {
/*       */ 
/*       */                 
/*  3043 */                 String str1 = str.substring("oracle.security.client.connect_string".length());
/*  3044 */                 arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.username" + str1));
/*       */                 
/*  3046 */                 arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.password" + str1));
/*       */ 
/*       */                 
/*       */                 break;
/*       */               } 
/*       */             }
/*       */           } 
/*       */         } 
/*  3054 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/*       */ 
/*       */         
/*  3057 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 167, noClassDefFoundError);
/*  3058 */         sQLException.fillInStackTrace();
/*  3059 */         throw sQLException;
/*       */       
/*       */       }
/*  3062 */       catch (Exception exception) {
/*       */         
/*  3064 */         if (exception instanceof RuntimeException) throw (RuntimeException)exception;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3074 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 168, exception);
/*  3075 */         sQLException.fillInStackTrace();
/*  3076 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  3081 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private String translateConnStr(String paramString) throws SQLException {
/*  3100 */     int i = 0;
/*  3101 */     int j = 0;
/*       */     
/*  3103 */     if (paramString == null || paramString.equals("")) {
/*  3104 */       return paramString;
/*       */     }
/*       */     
/*  3107 */     if (paramString.indexOf(')') != -1) {
/*  3108 */       return paramString;
/*       */     }
/*  3110 */     boolean bool = false;
/*  3111 */     if (paramString.indexOf('[') != -1) {
/*       */ 
/*       */       
/*  3114 */       i = paramString.indexOf(']');
/*  3115 */       if (i == -1) {
/*       */         
/*  3117 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3118 */         sQLException.fillInStackTrace();
/*  3119 */         throw sQLException;
/*       */       } 
/*  3121 */       bool = true;
/*       */     } 
/*       */     
/*  3124 */     i = paramString.indexOf(':', i);
/*  3125 */     if (i == -1)
/*  3126 */       return paramString; 
/*  3127 */     j = paramString.indexOf(':', i + 1);
/*  3128 */     if (j == -1) {
/*  3129 */       return paramString;
/*       */     }
/*       */     
/*  3132 */     if (paramString.indexOf(':', j + 1) != -1) {
/*       */ 
/*       */       
/*  3135 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3136 */       sQLException.fillInStackTrace();
/*  3137 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3141 */     String str1 = null;
/*  3142 */     if (bool) {
/*  3143 */       str1 = paramString.substring(1, i - 1);
/*       */     } else {
/*  3145 */       str1 = paramString.substring(0, i);
/*       */     } 
/*  3147 */     String str2 = paramString.substring(i + 1, j);
/*  3148 */     String str3 = paramString.substring(j + 1, paramString.length());
/*       */     
/*  3150 */     return "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + str2 + "))(CONNECT_DATA=(SID=" + str3 + ")))";
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static String getSystemPropertyPollInterval() {
/*  3163 */     return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyFastConnectionFailover(String paramString) {
/*  3172 */     return getSystemProperty("oracle.jdbc.FastConnectionFailover", paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyJserverVersion() {
/*  3180 */     return getSystemProperty("oracle.jserver.version", (String)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String getSystemProperty(String paramString1, String paramString2) {
/*  3187 */     if (paramString1 != null) {
/*       */       
/*  3189 */       final String fstr = paramString1;
/*  3190 */       final String fdefaultValue = paramString2;
/*  3191 */       final String[] rets = { paramString2 };
/*  3192 */       AccessController.doPrivileged(new PrivilegedAction()
/*       */           {
/*       */             public Object run()
/*       */             {
/*  3196 */               rets[0] = System.getProperty(fstr, fdefaultValue);
/*  3197 */               return null;
/*       */             }
/*       */           });
/*  3200 */       return arrayOfString[0];
/*       */     } 
/*       */     
/*  3203 */     return paramString2;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getProperties() {
/*  3214 */     Properties properties = new Properties();
/*       */     
/*       */     try {
/*  3217 */       Class clazz1 = null;
/*  3218 */       Class clazz2 = null;
/*       */       
/*       */       try {
/*  3221 */         clazz1 = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*  3222 */         clazz2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
/*       */       }
/*  3224 */       catch (ClassNotFoundException classNotFoundException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3231 */       Field[] arrayOfField = clazz2.getDeclaredFields();
/*  3232 */       for (byte b = 0; b < arrayOfField.length; b++) {
/*       */         
/*  3234 */         int i = arrayOfField[b].getModifiers();
/*  3235 */         if (!Modifier.isStatic(i)) {
/*       */ 
/*       */           
/*  3238 */           String str1 = arrayOfField[b].getName();
/*       */ 
/*       */           
/*  3241 */           String str2 = "CONNECTION_PROPERTY_" + propertyVariableName(str1);
/*       */ 
/*       */ 
/*       */           
/*  3245 */           Field field = null;
/*       */ 
/*       */           
/*       */           try {
/*  3249 */             field = clazz1.getField(str2);
/*       */           }
/*  3251 */           catch (NoSuchFieldException noSuchFieldException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  3257 */           if (!str2.matches(".*PASSWORD.*")) {
/*       */ 
/*       */             
/*  3260 */             String str3 = (String)field.get(null);
/*  3261 */             String str4 = arrayOfField[b].getType().getName();
/*  3262 */             if (str4.equals("boolean"))
/*       */             
/*  3264 */             { boolean bool = arrayOfField[b].getBoolean(this);
/*  3265 */               if (bool) {
/*  3266 */                 properties.setProperty(str3, "true");
/*       */               } else {
/*  3268 */                 properties.setProperty(str3, "false");
/*       */               }  }
/*  3270 */             else if (str4.equals("int"))
/*       */             
/*  3272 */             { int j = arrayOfField[b].getInt(this);
/*  3273 */               properties.setProperty(str3, Integer.toString(j)); }
/*       */             
/*  3275 */             else if (str4.equals("long"))
/*       */             
/*  3277 */             { long l = arrayOfField[b].getLong(this);
/*  3278 */               properties.setProperty(str3, Long.toString(l)); }
/*       */             
/*  3280 */             else if (str4.equals("java.lang.String"))
/*       */             
/*  3282 */             { String str = (String)arrayOfField[b].get(this);
/*  3283 */               if (str != null)
/*  3284 */                 properties.setProperty(str3, str);  } 
/*       */           } 
/*       */         } 
/*       */       } 
/*  3288 */     } catch (IllegalAccessException illegalAccessException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3293 */     return properties;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Connection _getPC() {
/*  3314 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleConnection getPhysicalConnection() {
/*  3330 */     return this;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isLogicalConnection() {
/*  3343 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initialize(Hashtable paramHashtable, Map paramMap1, Map paramMap2) throws SQLException {
/*  3356 */     this.clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3362 */     if (paramHashtable != null) {
/*  3363 */       this.descriptorCacheStack[this.dci] = paramHashtable;
/*       */     } else {
/*  3365 */       this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */     } 
/*  3367 */     this.map = paramMap1;
/*       */     
/*  3369 */     if (paramMap2 != null) {
/*  3370 */       this.javaObjectMap = paramMap2;
/*       */     } else {
/*  3372 */       this.javaObjectMap = new Hashtable<Object, Object>(10);
/*       */     } 
/*  3374 */     this.lifecycle = 1;
/*  3375 */     this.txnLevel = 2;
/*       */ 
/*       */     
/*  3378 */     this.clientIdSet = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initializeSetCHARCharSetObjs() {
/*  3386 */     this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
/*  3387 */     this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout getTimeout() throws SQLException {
/*  3401 */     if (this.timeout == null)
/*       */     {
/*  3403 */       this.timeout = OracleTimeout.newTimeout(this.url);
/*       */     }
/*       */     
/*  3406 */     return this.timeout;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement() throws SQLException {
/*  3425 */     return createStatement(-1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement(int paramInt1, int paramInt2) throws SQLException {
/*  3447 */     if (this.lifecycle != 1) {
/*       */       
/*  3449 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3450 */       sQLException.fillInStackTrace();
/*  3451 */       throw sQLException;
/*       */     } 
/*       */     
/*  3454 */     OracleStatement oracleStatement = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3460 */     oracleStatement = this.driverExtension.allocateStatement(this, paramInt1, paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3467 */     return (Statement)new OracleStatementWrapper((OracleStatement)oracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString) throws SQLException {
/*  3488 */     return prepareStatement(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatementWithKey(String paramString) throws SQLException {
/*       */     OraclePreparedStatementWrapper oraclePreparedStatementWrapper;
/*  3509 */     if (this.lifecycle != 1) {
/*       */       
/*  3511 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3512 */       sQLException.fillInStackTrace();
/*  3513 */       throw sQLException;
/*       */     } 
/*       */     
/*  3516 */     if (paramString == null) {
/*  3517 */       return null;
/*       */     }
/*  3519 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3521 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3522 */       sQLException.fillInStackTrace();
/*  3523 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3530 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */     
/*  3532 */     oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3543 */     if (oraclePreparedStatement != null) {
/*  3544 */       oraclePreparedStatementWrapper = new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */     }
/*  3546 */     return (PreparedStatement)oraclePreparedStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3577 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3579 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3580 */       sQLException.fillInStackTrace();
/*  3581 */       throw sQLException;
/*       */     } 
/*       */     
/*  3584 */     if (this.lifecycle != 1) {
/*       */       
/*  3586 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3587 */       sQLException.fillInStackTrace();
/*  3588 */       throw sQLException;
/*       */     } 
/*       */     
/*  3591 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */ 
/*       */     
/*  3594 */     if (this.statementCache != null) {
/*  3595 */       oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchImplicitCache(paramString, 1, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3601 */     if (oraclePreparedStatement == null) {
/*  3602 */       oraclePreparedStatement = this.driverExtension.allocatePreparedStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3614 */     return (PreparedStatement)new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString) throws SQLException {
/*  3633 */     return prepareCall(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3662 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3664 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3665 */       sQLException.fillInStackTrace();
/*  3666 */       throw sQLException;
/*       */     } 
/*       */     
/*  3669 */     if (this.lifecycle != 1) {
/*       */       
/*  3671 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3672 */       sQLException.fillInStackTrace();
/*  3673 */       throw sQLException;
/*       */     } 
/*       */     
/*  3676 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  3678 */     if (this.statementCache != null) {
/*  3679 */       oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchImplicitCache(paramString, 2, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3685 */     if (oracleCallableStatement == null) {
/*  3686 */       oracleCallableStatement = this.driverExtension.allocateCallableStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3697 */     return (CallableStatement)new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCallWithKey(String paramString) throws SQLException {
/*       */     OracleCallableStatementWrapper oracleCallableStatementWrapper;
/*  3717 */     if (this.lifecycle != 1) {
/*       */       
/*  3719 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3720 */       sQLException.fillInStackTrace();
/*  3721 */       throw sQLException;
/*       */     } 
/*       */     
/*  3724 */     if (paramString == null) {
/*  3725 */       return null;
/*       */     }
/*  3727 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3729 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3730 */       sQLException.fillInStackTrace();
/*  3731 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3738 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  3740 */     oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3750 */     if (oracleCallableStatement != null) {
/*  3751 */       oracleCallableStatementWrapper = new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */     }
/*  3753 */     return (CallableStatement)oracleCallableStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String nativeSQL(String paramString) throws SQLException {
/*  3765 */     if (this.sqlObj == null)
/*       */     {
/*  3767 */       this.sqlObj = new OracleSql(this.conversion);
/*       */     }
/*       */     
/*  3770 */     this.sqlObj.initialize(paramString);
/*       */     
/*  3772 */     return this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoCommit(boolean paramBoolean) throws SQLException {
/*  3784 */     if (paramBoolean) {
/*  3785 */       disallowGlobalTxnMode(116);
/*       */     }
/*  3787 */     if (this.lifecycle != 1) {
/*       */       
/*  3789 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3790 */       sQLException.fillInStackTrace();
/*  3791 */       throw sQLException;
/*       */     } 
/*       */     
/*  3794 */     needLine();
/*  3795 */     doSetAutoCommit(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoCommit() throws SQLException {
/*  3803 */     return this.autocommit;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cancel() throws SQLException {
/*  3822 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3824 */     if (this.lifecycle != 1 && this.lifecycle != 16) {
/*       */       
/*  3826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3827 */       sQLException.fillInStackTrace();
/*  3828 */       throw sQLException;
/*       */     } 
/*       */     
/*  3831 */     boolean bool = false;
/*       */     
/*  3833 */     while (oracleStatement != null) {
/*       */ 
/*       */       
/*       */       try {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3841 */         if (oracleStatement.doCancel()) {
/*  3842 */           bool = true;
/*       */         }
/*  3844 */       } catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */       
/*  3848 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */     
/*  3852 */     if (!bool) {
/*  3853 */       cancelOperationOnServer(false);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit(EnumSet<OracleConnection.CommitOption> paramEnumSet) throws SQLException {
/*  3860 */     int i = 0;
/*  3861 */     if (paramEnumSet != null) {
/*       */       
/*  3863 */       if ((paramEnumSet.contains(OracleConnection.CommitOption.WRITEBATCH) && paramEnumSet.contains(OracleConnection.CommitOption.WRITEIMMED)) || (paramEnumSet.contains(OracleConnection.CommitOption.WAIT) && paramEnumSet.contains(OracleConnection.CommitOption.NOWAIT))) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3869 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3870 */         sQLException.fillInStackTrace();
/*  3871 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  3875 */       for (OracleConnection.CommitOption commitOption : paramEnumSet)
/*  3876 */         i |= commitOption.getCode(); 
/*       */     } 
/*  3878 */     commit(i);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void commit(int paramInt) throws SQLException {
/*  3889 */     disallowGlobalTxnMode(114);
/*       */     
/*  3891 */     if (this.lifecycle != 1) {
/*       */       
/*  3893 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3894 */       sQLException.fillInStackTrace();
/*  3895 */       throw sQLException;
/*       */     } 
/*       */     
/*  3898 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3900 */     while (oracleStatement != null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3905 */       if (!oracleStatement.closed) {
/*  3906 */         oracleStatement.sendBatch();
/*       */       }
/*  3908 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*  3910 */     if (((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) || ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0)) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3916 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3917 */       sQLException.fillInStackTrace();
/*  3918 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3925 */     registerHeartbeat();
/*       */     
/*  3927 */     needLine();
/*  3928 */     doCommit(paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit() throws SQLException {
/*  3934 */     commit(this.commitOption);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback() throws SQLException {
/*  3943 */     disallowGlobalTxnMode(115);
/*       */     
/*  3945 */     if (this.lifecycle != 1) {
/*       */       
/*  3947 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3948 */       sQLException.fillInStackTrace();
/*  3949 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3953 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3955 */     while (oracleStatement != null) {
/*       */       
/*  3957 */       if (oracleStatement.isOracleBatchStyle()) {
/*  3958 */         oracleStatement.clearBatch();
/*       */       }
/*  3960 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3967 */     registerHeartbeat();
/*       */     
/*  3969 */     needLine();
/*  3970 */     doRollback();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close() throws SQLException {
/*  3984 */     if (this.lifecycle == 2 || this.lifecycle == 4) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  3990 */     needLineUnchecked();
/*       */ 
/*       */     
/*       */     try {
/*  3994 */       if (this.closeCallback != null) {
/*  3995 */         this.closeCallback.beforeClose(this, this.privateData);
/*       */       }
/*  3997 */       closeStatementCache();
/*  3998 */       closeStatements(false);
/*       */       
/*  4000 */       if (this.lifecycle == 1) this.lifecycle = 2;
/*       */ 
/*       */       
/*  4003 */       if (this.isProxy)
/*       */       {
/*  4005 */         close(1);
/*       */       }
/*       */       
/*  4008 */       if (this.timeZoneTab != null) {
/*  4009 */         this.timeZoneTab.freeInstance();
/*       */       }
/*  4011 */       logoff();
/*  4012 */       cleanup();
/*       */       
/*  4014 */       if (this.timeout != null) {
/*  4015 */         this.timeout.close();
/*       */       }
/*  4017 */       if (this.closeCallback != null) {
/*  4018 */         this.closeCallback.afterClose(this.privateData);
/*       */       }
/*       */     } finally {
/*       */       
/*  4022 */       this.lifecycle = 4;
/*  4023 */       this.isUsable = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDataIntegrityAlgorithmName() throws SQLException {
/*  4034 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4035 */     sQLException.fillInStackTrace();
/*  4036 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getEncryptionAlgorithmName() throws SQLException {
/*  4043 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4044 */     sQLException.fillInStackTrace();
/*  4045 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getAuthenticationAdaptorName() throws SQLException {
/*  4052 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4053 */     sQLException.fillInStackTrace();
/*  4054 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void closeInternal(boolean paramBoolean) throws SQLException {
/*  4064 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4065 */     sQLException.fillInStackTrace();
/*  4066 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cleanupAndClose(boolean paramBoolean) throws SQLException {
/*  4077 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4078 */     sQLException.fillInStackTrace();
/*  4079 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanupAndClose() throws SQLException {
/*  4090 */     if (this.lifecycle != 1) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4096 */     this.lifecycle = 16;
/*       */ 
/*       */     
/*  4099 */     cancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeLogicalConnection() throws SQLException {
/*  4106 */     if (this.lifecycle == 1 || this.lifecycle == 16 || this.lifecycle == 2) {
/*       */ 
/*       */ 
/*       */       
/*  4110 */       this.savepointStatement = null;
/*  4111 */       closeStatements(true);
/*       */       
/*  4113 */       if (this.clientIdSet) {
/*  4114 */         clearClientIdentifier(this.clientId);
/*       */       }
/*  4116 */       this.logicalConnectionAttached = null;
/*  4117 */       this.lifecycle = 1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(Properties paramProperties) throws SQLException {
/*  4137 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4138 */     sQLException.fillInStackTrace();
/*  4139 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(int paramInt) throws SQLException {
/*  4155 */     if ((paramInt & 0x1000) != 0) {
/*       */       
/*  4157 */       close();
/*       */       
/*       */       return;
/*       */     } 
/*       */     
/*  4162 */     if ((paramInt & 0x1) != 0 && this.isProxy) {
/*       */       
/*  4164 */       purgeStatementCache();
/*  4165 */       closeStatements(false);
/*  4166 */       this.descriptorCacheStack[this.dci--] = null;
/*       */       
/*  4168 */       closeProxySession();
/*       */       
/*  4170 */       this.isProxy = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  4177 */   private static final OracleSQLPermission CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort"); static final String DATABASE_NAME = "DATABASE_NAME"; static final String SERVER_HOST = "SERVER_HOST"; static final String INSTANCE_NAME = "INSTANCE_NAME"; static final String SERVICE_NAME = "SERVICE_NAME"; Hashtable clientData; private BufferCacheStore connectionBufferCacheStore; private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore; private int pingResult; String sessionTimeZone; String databaseTimeZone; Calendar dbTzCalendar; static final String RAW_STR = "RAW"; static final String SYS_RAW_STR = "SYS.RAW"; static final String SYS_ANYDATA_STR = "SYS.ANYDATA"; static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
/*       */   int timeZoneVersionNumber;
/*       */   TIMEZONETAB timeZoneTab;
/*       */   
/*       */   public void abort() throws SQLException {
/*  4182 */     SecurityManager securityManager = System.getSecurityManager();
/*  4183 */     if (securityManager != null) {
/*  4184 */       securityManager.checkPermission((Permission)CALL_ABORT_PERMISSION);
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4189 */     if (this.lifecycle == 4 || this.lifecycle == 8) {
/*       */       return;
/*       */     }
/*       */     
/*  4193 */     this.lifecycle = 8;
/*       */ 
/*       */     
/*  4196 */     doAbort();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void closeProxySession() throws SQLException {
/*  4209 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4210 */     sQLException.fillInStackTrace();
/*  4211 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getServerSessionInfo() throws SQLException {
/*  4228 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4229 */     sQLException.fillInStackTrace();
/*  4230 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void applyConnectionAttributes(Properties paramProperties) throws SQLException {
/*  4243 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4244 */     sQLException.fillInStackTrace();
/*  4245 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getConnectionAttributes() throws SQLException {
/*  4258 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4259 */     sQLException.fillInStackTrace();
/*  4260 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
/*  4273 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4274 */     sQLException.fillInStackTrace();
/*  4275 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException {
/*  4289 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4290 */     sQLException.fillInStackTrace();
/*  4291 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt) throws SQLException {
/*  4304 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4305 */     sQLException.fillInStackTrace();
/*  4306 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
/*  4319 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4320 */     sQLException.fillInStackTrace();
/*  4321 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getConnectionCacheCallbackPrivObj() throws SQLException {
/*  4333 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4334 */     sQLException.fillInStackTrace();
/*  4335 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionCacheCallbackFlag() throws SQLException {
/*  4347 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4348 */     sQLException.fillInStackTrace();
/*  4349 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setConnectionReleasePriority(int paramInt) throws SQLException {
/*  4362 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4363 */     sQLException.fillInStackTrace();
/*  4364 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionReleasePriority() throws SQLException {
/*  4376 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4377 */     sQLException.fillInStackTrace();
/*  4378 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isClosed() throws SQLException {
/*  4391 */     return (this.lifecycle != 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isProxySession() {
/*  4398 */     return this.isProxy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void openProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  4407 */     boolean bool = true;
/*       */     
/*  4409 */     if (this.isProxy) {
/*       */       
/*  4411 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
/*  4412 */       sQLException.fillInStackTrace();
/*  4413 */       throw sQLException;
/*       */     } 
/*       */     
/*  4416 */     String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  4417 */     String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  4418 */     String str3 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*       */     
/*  4420 */     Object object = paramProperties.get("PROXY_CERTIFICATE");
/*       */     
/*  4422 */     if (paramInt == 1) {
/*       */       
/*  4424 */       if (str1 == null && str2 == null)
/*       */       {
/*  4426 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4427 */         sQLException.fillInStackTrace();
/*  4428 */         throw sQLException;
/*       */       }
/*       */     
/*  4431 */     } else if (paramInt == 2) {
/*       */       
/*  4433 */       if (str3 == null)
/*       */       {
/*  4435 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4436 */         sQLException.fillInStackTrace();
/*  4437 */         throw sQLException;
/*       */       }
/*       */     
/*  4440 */     } else if (paramInt == 3) {
/*       */       
/*  4442 */       if (object == null) {
/*       */         
/*  4444 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4445 */         sQLException.fillInStackTrace();
/*  4446 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*       */       try {
/*  4451 */         byte[] arrayOfByte = (byte[])object;
/*       */       }
/*  4453 */       catch (ClassCastException classCastException) {
/*       */ 
/*       */         
/*  4456 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4457 */         sQLException.fillInStackTrace();
/*  4458 */         throw sQLException;
/*       */       }
/*       */     
/*       */     }
/*       */     else {
/*       */       
/*  4464 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4465 */       sQLException.fillInStackTrace();
/*  4466 */       throw sQLException;
/*       */     } 
/*       */     
/*  4469 */     purgeStatementCache();
/*  4470 */     closeStatements(false);
/*       */ 
/*       */ 
/*       */     
/*       */     try {
/*  4475 */       doProxySession(paramInt, paramProperties);
/*  4476 */       this.dci++;
/*       */       
/*  4478 */       bool = false;
/*       */     
/*       */     }
/*       */     finally {
/*       */       
/*  4483 */       if (bool == true) {
/*  4484 */         closeProxySession();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  4495 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4496 */     sQLException.fillInStackTrace();
/*  4497 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanup() {
/*  4507 */     this.fdo = null;
/*  4508 */     this.conversion = null;
/*  4509 */     this.statements = null;
/*  4510 */     this.descriptorCacheStack[this.dci] = null;
/*  4511 */     this.map = null;
/*  4512 */     this.javaObjectMap = null;
/*  4513 */     this.statementHoldingLine = null;
/*  4514 */     this.sqlObj = null;
/*  4515 */     this.isProxy = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized DatabaseMetaData getMetaData() throws SQLException {
/*  4532 */     if (this.lifecycle != 1) {
/*       */       
/*  4534 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4535 */       sQLException.fillInStackTrace();
/*  4536 */       throw sQLException;
/*       */     } 
/*       */     
/*  4539 */     if (this.databaseMetaData == null) {
/*  4540 */       this.databaseMetaData = new OracleDatabaseMetaData(this);
/*       */     }
/*  4542 */     return (DatabaseMetaData)this.databaseMetaData;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setReadOnly(boolean paramBoolean) throws SQLException {
/*  4559 */     this.readOnly = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isReadOnly() throws SQLException {
/*  4575 */     return this.readOnly;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCatalog(String paramString) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCatalog() throws SQLException {
/*  4597 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTransactionIsolation(int paramInt) throws SQLException {
/*  4607 */     if (this.txnLevel == paramInt) {
/*       */       return;
/*       */     }
/*  4610 */     Statement statement = createStatement();
/*       */     
/*       */     try {
/*       */       SQLException sQLException;
/*  4614 */       switch (paramInt) {
/*       */ 
/*       */ 
/*       */         
/*       */         case 2:
/*  4619 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
/*       */           
/*  4621 */           this.txnLevel = 2;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         case 8:
/*  4628 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
/*       */           
/*  4630 */           this.txnLevel = 8;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         default:
/*  4637 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
/*  4638 */           sQLException.fillInStackTrace();
/*  4639 */           throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     } finally {
/*  4647 */       statement.close();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTransactionIsolation() throws SQLException {
/*  4656 */     return this.txnLevel;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoClose(boolean paramBoolean) throws SQLException {
/*  4669 */     if (!paramBoolean) {
/*       */       
/*  4671 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
/*  4672 */       sQLException.fillInStackTrace();
/*  4673 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoClose() throws SQLException {
/*  4685 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public SQLWarning getWarnings() throws SQLException {
/*  4695 */     return this.sqlWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearWarnings() throws SQLException {
/*  4702 */     this.sqlWarning = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setWarnings(SQLWarning paramSQLWarning) {
/*  4709 */     this.sqlWarning = paramSQLWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultRowPrefetch(int paramInt) throws SQLException {
/*  4753 */     if (paramInt <= 0) {
/*       */       
/*  4755 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/*  4756 */       sQLException.fillInStackTrace();
/*  4757 */       throw sQLException;
/*       */     } 
/*       */     
/*  4760 */     this.defaultRowPrefetch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getDefaultRowPrefetch() {
/*  4787 */     return this.defaultRowPrefetch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getTimestamptzInGmt() {
/*  4794 */     return this.timestamptzInGmt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getUse1900AsYearForTime() {
/*  4801 */     return this.use1900AsYearForTime;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setDefaultExecuteBatch(int paramInt) throws SQLException {
/*  4843 */     if (paramInt <= 0) {
/*       */       
/*  4845 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  4846 */       sQLException.fillInStackTrace();
/*  4847 */       throw sQLException;
/*       */     } 
/*       */     
/*  4850 */     this.defaultExecuteBatch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getDefaultExecuteBatch() {
/*  4878 */     return this.defaultExecuteBatch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setRemarksReporting(boolean paramBoolean) {
/*  4901 */     this.reportRemarks = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getRemarksReporting() {
/*  4914 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIncludeSynonyms(boolean paramBoolean) {
/*  4935 */     this.includeSynonyms = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String[] getEndToEndMetrics() throws SQLException {
/*       */     String[] arrayOfString;
/*  4949 */     if (this.endToEndValues == null) {
/*       */       
/*  4951 */       arrayOfString = null;
/*       */     }
/*       */     else {
/*       */       
/*  4955 */       arrayOfString = new String[this.endToEndValues.length];
/*       */       
/*  4957 */       System.arraycopy(this.endToEndValues, 0, arrayOfString, 0, this.endToEndValues.length);
/*       */     } 
/*  4959 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getEndToEndECIDSequenceNumber() throws SQLException {
/*  4977 */     return this.endToEndECIDSequenceNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setEndToEndMetrics(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  4992 */     String[] arrayOfString = new String[paramArrayOfString.length];
/*       */     
/*  4994 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
/*  4995 */     setEndToEndMetricsInternal(arrayOfString, paramShort);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setEndToEndMetricsInternal(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  5010 */     if (paramArrayOfString != this.endToEndValues) {
/*       */       
/*  5012 */       if (paramArrayOfString.length != 4) {
/*       */ 
/*       */ 
/*       */         
/*  5016 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
/*  5017 */         sQLException.fillInStackTrace();
/*  5018 */         throw sQLException;
/*       */       } 
/*       */       
/*       */       byte b;
/*  5022 */       for (b = 0; b < 4; b++) {
/*       */         
/*  5024 */         String str = paramArrayOfString[b];
/*       */         
/*  5026 */         if (str != null && str.length() > this.endToEndMaxLength[b]) {
/*       */ 
/*       */           
/*  5029 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, str);
/*  5030 */           sQLException.fillInStackTrace();
/*  5031 */           throw sQLException;
/*       */         } 
/*       */       } 
/*       */ 
/*       */       
/*  5036 */       if (this.endToEndValues != null) {
/*       */         
/*  5038 */         for (b = 0; b < 4; b++) {
/*       */           
/*  5040 */           String str = paramArrayOfString[b];
/*       */           
/*  5042 */           if ((str == null && this.endToEndValues[b] != null) || (str != null && !str.equals(this.endToEndValues[b]))) {
/*       */ 
/*       */             
/*  5045 */             this.endToEndHasChanged[b] = true;
/*  5046 */             this.endToEndAnyChanged = true;
/*       */           } 
/*       */         } 
/*       */ 
/*       */         
/*  5051 */         this.endToEndHasChanged[0] = this.endToEndHasChanged[0] | this.endToEndHasChanged[3];
/*       */       
/*       */       }
/*       */       else {
/*       */         
/*  5056 */         for (b = 0; b < 4; b++)
/*       */         {
/*  5058 */           this.endToEndHasChanged[b] = true;
/*       */         }
/*       */         
/*  5061 */         this.endToEndAnyChanged = true;
/*       */       } 
/*       */ 
/*       */       
/*  5065 */       this.endToEndValues = paramArrayOfString;
/*       */     } 
/*       */     
/*  5068 */     this.endToEndECIDSequenceNumber = paramShort;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetSystemContext() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext11() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getIncludeSynonyms() {
/*  5127 */     return this.includeSynonyms;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRestrictGetTables(boolean paramBoolean) {
/*  5168 */     this.restrictGettables = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getRestrictGetTables() {
/*  5184 */     return this.restrictGettables;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultFixedString(boolean paramBoolean) {
/*  5213 */     this.fixedString = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultNChar(boolean paramBoolean) {
/*  5222 */     this.defaultnchar = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getDefaultFixedString() {
/*  5250 */     return this.fixedString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getNlsRatio() {
/*  5263 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getC2SNlsRatio() {
/*  5270 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void addStatement(OracleStatement paramOracleStatement) {
/*  5279 */     if (paramOracleStatement.next != null) {
/*  5280 */       throw new Error("add_statement called twice on " + paramOracleStatement);
/*       */     }
/*  5282 */     paramOracleStatement.next = this.statements;
/*       */     
/*  5284 */     if (this.statements != null) {
/*  5285 */       this.statements.prev = paramOracleStatement;
/*       */     }
/*  5287 */     this.statements = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void removeStatement(OracleStatement paramOracleStatement) {
/*  5306 */     OracleStatement oracleStatement1 = paramOracleStatement.prev;
/*  5307 */     OracleStatement oracleStatement2 = paramOracleStatement.next;
/*       */     
/*  5309 */     if (oracleStatement1 == null) {
/*       */       
/*  5311 */       if (this.statements != paramOracleStatement) {
/*       */         return;
/*       */       }
/*  5314 */       this.statements = oracleStatement2;
/*       */     } else {
/*       */       
/*  5317 */       oracleStatement1.next = oracleStatement2;
/*       */     } 
/*  5319 */     if (oracleStatement2 != null) {
/*  5320 */       oracleStatement2.prev = oracleStatement1;
/*       */     }
/*  5322 */     paramOracleStatement.next = null;
/*  5323 */     paramOracleStatement.prev = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeStatements(boolean paramBoolean) throws SQLException {
/*  5345 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  5347 */     while (oracleStatement != null) {
/*       */       
/*  5349 */       OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */       
/*  5351 */       if (oracleStatement.serverCursor) {
/*       */         
/*  5353 */         oracleStatement.close();
/*  5354 */         removeStatement(oracleStatement);
/*       */       } 
/*       */       
/*  5357 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */ 
/*       */     
/*  5361 */     oracleStatement = this.statements;
/*       */     
/*  5363 */     while (oracleStatement != null) {
/*       */       
/*  5365 */       OracleStatement oracleStatement1 = oracleStatement.next;
/*       */       
/*  5367 */       if (paramBoolean) {
/*  5368 */         oracleStatement.close();
/*       */       } else {
/*  5370 */         oracleStatement.hardClose();
/*  5371 */       }  removeStatement(oracleStatement);
/*       */       
/*  5373 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void purgeStatementCache() throws SQLException {
/*  5384 */     if (isStatementCacheInitialized()) {
/*       */       
/*  5386 */       this.statementCache.purgeImplicitCache();
/*  5387 */       this.statementCache.purgeExplicitCache();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void closeStatementCache() throws SQLException {
/*  5397 */     if (isStatementCacheInitialized()) {
/*       */ 
/*       */ 
/*       */       
/*  5401 */       this.statementCache.close();
/*       */       
/*  5403 */       this.statementCache = null;
/*  5404 */       this.clearStatementMetaData = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void needLine() throws SQLException {
/*  5413 */     if (this.lifecycle != 1) {
/*       */       
/*  5415 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5416 */       sQLException.fillInStackTrace();
/*  5417 */       throw sQLException;
/*       */     } 
/*       */     
/*  5420 */     needLineUnchecked();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void needLineUnchecked() throws SQLException {
/*  5430 */     if (this.statementHoldingLine != null)
/*       */     {
/*  5432 */       this.statementHoldingLine.freeLine();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  5440 */     holdLine((OracleStatement)paramOracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  5449 */     this.statementHoldingLine = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void releaseLine() {
/*  5457 */     releaseLineForCancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void releaseLineForCancel() {
/*  5466 */     this.statementHoldingLine = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(String paramString, int paramInt) throws SQLException {
/*  5474 */     if (this.lifecycle != 1) {
/*       */       
/*  5476 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5477 */       sQLException1.fillInStackTrace();
/*  5478 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  5482 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5483 */     sQLException.fillInStackTrace();
/*  5484 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(OracleConnection.DatabaseStartupMode paramDatabaseStartupMode) throws SQLException {
/*  5492 */     if (this.lifecycle != 1) {
/*       */       
/*  5494 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5495 */       sQLException.fillInStackTrace();
/*  5496 */       throw sQLException;
/*       */     } 
/*  5498 */     if (paramDatabaseStartupMode == null) {
/*       */       
/*  5500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5501 */       sQLException.fillInStackTrace();
/*  5502 */       throw sQLException;
/*       */     } 
/*       */     
/*  5505 */     needLine();
/*  5506 */     doStartup(paramDatabaseStartupMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doStartup(int paramInt) throws SQLException {
/*  5515 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5516 */     sQLException.fillInStackTrace();
/*  5517 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void shutdown(OracleConnection.DatabaseShutdownMode paramDatabaseShutdownMode) throws SQLException {
/*  5526 */     if (this.lifecycle != 1) {
/*       */       
/*  5528 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5529 */       sQLException.fillInStackTrace();
/*  5530 */       throw sQLException;
/*       */     } 
/*  5532 */     if (paramDatabaseShutdownMode == null) {
/*       */       
/*  5534 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5535 */       sQLException.fillInStackTrace();
/*  5536 */       throw sQLException;
/*       */     } 
/*       */     
/*  5539 */     needLine();
/*  5540 */     doShutdown(paramDatabaseShutdownMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doShutdown(int paramInt) throws SQLException {
/*  5549 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5550 */     sQLException.fillInStackTrace();
/*  5551 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void archive(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  5562 */     if (this.lifecycle != 1) {
/*       */       
/*  5564 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5565 */       sQLException1.fillInStackTrace();
/*  5566 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  5570 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5571 */     sQLException.fillInStackTrace();
/*  5572 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString1, String paramString2) throws SQLException {
/*  5586 */     if (paramString1 == null || paramString2 == null) {
/*       */       
/*  5588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5589 */       sQLException.fillInStackTrace();
/*  5590 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*       */     try {
/*  5595 */       registerSQLType(paramString1, Class.forName(paramString2));
/*       */     }
/*  5597 */     catch (ClassNotFoundException classNotFoundException) {
/*       */ 
/*       */       
/*  5600 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Class not found: " + paramString2);
/*  5601 */       sQLException.fillInStackTrace();
/*  5602 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString, Class<?> paramClass) throws SQLException {
/*  5613 */     if (paramString == null || paramClass == null) {
/*       */       
/*  5615 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5616 */       sQLException.fillInStackTrace();
/*  5617 */       throw sQLException;
/*       */     } 
/*       */     
/*  5620 */     if (this.map == null) this.map = new Hashtable<Object, Object>(10);
/*       */     
/*  5622 */     this.map.put(paramString, paramClass);
/*  5623 */     this.map.put(paramClass.getName(), paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getSQLType(Object paramObject) throws SQLException {
/*  5631 */     if (paramObject != null && this.map != null) {
/*       */       
/*  5633 */       String str = paramObject.getClass().getName();
/*       */       
/*  5635 */       return (String)this.map.get(str);
/*       */     } 
/*       */     
/*  5638 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getJavaObject(String paramString) throws SQLException {
/*  5646 */     Object object = null;
/*       */ 
/*       */     
/*       */     try {
/*  5650 */       if (paramString != null && this.map != null)
/*       */       {
/*  5652 */         Class<Object> clazz = (Class)this.map.get(paramString);
/*       */         
/*  5654 */         object = clazz.newInstance();
/*       */       }
/*       */     
/*  5657 */     } catch (IllegalAccessException illegalAccessException) {
/*       */       
/*  5659 */       illegalAccessException.printStackTrace();
/*       */     }
/*  5661 */     catch (InstantiationException instantiationException) {
/*       */       
/*  5663 */       instantiationException.printStackTrace();
/*       */     } 
/*       */     
/*  5666 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(String paramString, Object paramObject) throws SQLException {
/*  5679 */     if (paramString != null && paramObject != null) {
/*       */       
/*  5681 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5682 */         this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */       }
/*  5684 */       ((TypeDescriptor)paramObject).fixupConnection(this);
/*  5685 */       this.descriptorCacheStack[this.dci].put(paramString, paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  5689 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5690 */       sQLException.fillInStackTrace();
/*  5691 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(String paramString) {
/*  5703 */     Object object = null;
/*       */     
/*  5705 */     if (paramString != null) {
/*  5706 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5707 */         object = this.descriptorCacheStack[this.dci].get(paramString); 
/*  5708 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5709 */         object = this.descriptorCacheStack[0].get(paramString);
/*       */       }
/*       */     } 
/*  5712 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDecriptor(String paramString) {
/*  5724 */     removeDescriptor(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDescriptor(String paramString) {
/*  5738 */     if (paramString != null && this.descriptorCacheStack[this.dci] != null)
/*  5739 */       this.descriptorCacheStack[this.dci].remove(paramString); 
/*  5740 */     if (paramString != null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5741 */       this.descriptorCacheStack[0].remove(paramString);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeAllDescriptor() {
/*  5752 */     for (byte b = 0; b <= this.dci; b++) {
/*  5753 */       if (this.descriptorCacheStack[b] != null) {
/*  5754 */         this.descriptorCacheStack[b].clear();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int numberOfDescriptorCacheEntries() {
/*  5771 */     int i = 0;
/*  5772 */     for (byte b = 0; b <= this.dci; b++) {
/*  5773 */       if (this.descriptorCacheStack[b] != null)
/*  5774 */         i += this.descriptorCacheStack[b].size(); 
/*       */     } 
/*  5776 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Enumeration descriptorCacheKeys() {
/*  5789 */     if (this.dci == 0) {
/*  5790 */       if (this.descriptorCacheStack[this.dci] != null) {
/*  5791 */         return this.descriptorCacheStack[this.dci].keys();
/*       */       }
/*  5793 */       return null;
/*       */     } 
/*  5795 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] != null)
/*  5796 */       return this.descriptorCacheStack[1].keys(); 
/*  5797 */     if (this.descriptorCacheStack[1] == null && this.descriptorCacheStack[0] != null)
/*  5798 */       return this.descriptorCacheStack[0].keys(); 
/*  5799 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] == null) {
/*  5800 */       return null;
/*       */     }
/*  5802 */     Vector vector = new Vector(this.descriptorCacheStack[1].keySet());
/*  5803 */     vector.addAll(this.descriptorCacheStack[0].keySet());
/*  5804 */     return vector.elements();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
/*  5818 */     if (paramArrayOfbyte != null && paramObject != null) {
/*       */       
/*  5820 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5821 */         this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */       }
/*  5823 */       this.descriptorCacheStack[this.dci].put(new ByteArrayKey(paramArrayOfbyte), paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  5827 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5828 */       sQLException.fillInStackTrace();
/*  5829 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(byte[] paramArrayOfbyte) {
/*  5841 */     Object object = null;
/*       */     
/*  5843 */     if (paramArrayOfbyte != null) {
/*  5844 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  5845 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5846 */         object = this.descriptorCacheStack[this.dci].get(byteArrayKey); 
/*  5847 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5848 */         object = this.descriptorCacheStack[0].get(byteArrayKey);
/*       */       }
/*       */     } 
/*  5851 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDecriptor(byte[] paramArrayOfbyte) {
/*  5863 */     if (paramArrayOfbyte != null) {
/*  5864 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  5865 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5866 */         this.descriptorCacheStack[this.dci].remove(byteArrayKey); 
/*  5867 */       if (this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5868 */         this.descriptorCacheStack[0].remove(byteArrayKey);
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getJdbcCsId() throws SQLException {
/*  5891 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5894 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5895 */       sQLException.fillInStackTrace();
/*  5896 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5900 */     return this.conversion.getClientCharSet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getDbCsId() throws SQLException {
/*  5915 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5918 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5919 */       sQLException.fillInStackTrace();
/*  5920 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5924 */     return this.conversion.getServerCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getNCsId() throws SQLException {
/*  5931 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5934 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5935 */       sQLException.fillInStackTrace();
/*  5936 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5940 */     return this.conversion.getNCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrCsId() throws SQLException {
/*  5956 */     return getDbCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrNCsId() throws SQLException {
/*  5963 */     return getNCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getTypeMap() {
/*  5973 */     if (this.map == null) this.map = new Hashtable<Object, Object>(10); 
/*  5974 */     return this.map;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTypeMap(Map paramMap) {
/*  5981 */     this.map = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setUsingXAFlag(boolean paramBoolean) {
/*  5989 */     this.usingXA = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getUsingXAFlag() {
/*  5996 */     return this.usingXA;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setXAErrorFlag(boolean paramBoolean) {
/*  6004 */     this.xaWantsError = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getXAErrorFlag() {
/*  6011 */     return this.xaWantsError;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String getPropertyFromDatabase(String paramString) throws SQLException {
/*  6019 */     String str = null;
/*  6020 */     Statement statement = null;
/*  6021 */     ResultSet resultSet = null;
/*       */     
/*       */     try {
/*  6024 */       statement = createStatement();
/*  6025 */       statement.setFetchSize(1);
/*  6026 */       resultSet = statement.executeQuery(paramString);
/*  6027 */       if (resultSet.next()) {
/*  6028 */         str = resultSet.getString(1);
/*       */       }
/*       */     } finally {
/*       */       
/*  6032 */       if (resultSet != null)
/*  6033 */         resultSet.close(); 
/*  6034 */       if (statement != null)
/*  6035 */         statement.close(); 
/*       */     } 
/*  6037 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getUserName() throws SQLException {
/*  6045 */     if (this.userName == null) {
/*  6046 */       this.userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
/*       */     }
/*  6048 */     return this.userName;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCurrentSchema() throws SQLException {
/*  6063 */     return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDefaultSchemaNameForNamedTypes() throws SQLException {
/*  6081 */     String str = null;
/*       */     
/*  6083 */     if (this.createDescriptorUseCurrentSchemaForSchemaName) {
/*  6084 */       str = getCurrentSchema();
/*       */     } else {
/*  6086 */       str = getUserName();
/*       */     } 
/*  6088 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStartTime(long paramLong) throws SQLException {
/*  6106 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6107 */     sQLException.fillInStackTrace();
/*  6108 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized long getStartTime() throws SQLException {
/*  6124 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6125 */     sQLException.fillInStackTrace();
/*  6126 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void registerHeartbeat() throws SQLException {
/*  6139 */     if (this.logicalConnectionAttached != null) {
/*  6140 */       this.logicalConnectionAttached.registerHeartbeat();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHeartbeatNoChangeCount() throws SQLException {
/*  6152 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6153 */     sQLException.fillInStackTrace();
/*  6154 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized byte[] getFDO(boolean paramBoolean) throws SQLException {
/*  6166 */     if (this.fdo == null && paramBoolean) {
/*       */       
/*  6168 */       CallableStatement callableStatement = null;
/*       */ 
/*       */       
/*       */       try {
/*  6172 */         callableStatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
/*       */ 
/*       */         
/*  6175 */         callableStatement.registerOutParameter(1, 2);
/*  6176 */         callableStatement.registerOutParameter(2, -4);
/*  6177 */         callableStatement.execute();
/*       */         
/*  6179 */         this.fdo = callableStatement.getBytes(2);
/*       */       }
/*       */       finally {
/*       */         
/*  6183 */         if (callableStatement != null) {
/*  6184 */           callableStatement.close();
/*       */         }
/*  6186 */         callableStatement = null;
/*       */       } 
/*       */     } 
/*       */     
/*  6190 */     return this.fdo;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setFDO(byte[] paramArrayOfbyte) throws SQLException {
/*  6201 */     this.fdo = paramArrayOfbyte;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getBigEndian() throws SQLException {
/*  6212 */     if (this.bigEndian == null) {
/*       */       
/*  6214 */       int[] arrayOfInt = Util.toJavaUnsignedBytes(getFDO(true));
/*       */ 
/*       */ 
/*       */       
/*  6218 */       int i = arrayOfInt[6 + arrayOfInt[5] + arrayOfInt[6] + 5];
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6223 */       int j = (byte)(i & 0x10);
/*       */       
/*  6225 */       if (j < 0) {
/*  6226 */         j = j + 256;
/*       */       }
/*  6228 */       if (j > 0) {
/*  6229 */         this.bigEndian = Boolean.TRUE;
/*       */       } else {
/*  6231 */         this.bigEndian = Boolean.FALSE;
/*       */       } 
/*       */     } 
/*  6234 */     return this.bigEndian.booleanValue();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setHoldability(int paramInt) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHoldability() throws SQLException {
/*  6287 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint() throws SQLException {
/*  6296 */     return (Savepoint)oracleSetSavepoint();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint(String paramString) throws SQLException {
/*  6306 */     return (Savepoint)oracleSetSavepoint(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback(Savepoint paramSavepoint) throws SQLException {
/*  6317 */     disallowGlobalTxnMode(122);
/*       */ 
/*       */     
/*  6320 */     if (this.autocommit) {
/*       */       
/*  6322 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6323 */       sQLException.fillInStackTrace();
/*  6324 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6329 */     if (this.savepointStatement == null)
/*       */     {
/*  6331 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6334 */     String str = null;
/*       */ 
/*       */     
/*       */     try {
/*  6338 */       str = paramSavepoint.getSavepointName();
/*       */     }
/*  6340 */     catch (SQLException sQLException) {
/*       */       
/*  6342 */       str = "ORACLE_SVPT_" + paramSavepoint.getSavepointId();
/*       */     } 
/*       */     
/*  6345 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void releaseSavepoint(Savepoint paramSavepoint) throws SQLException {
/*  6355 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6356 */     sQLException.fillInStackTrace();
/*  6357 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6403 */     return createStatement(paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6454 */     return prepareStatement(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6502 */     return prepareCall(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLException {
/*  6552 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString);
/*  6553 */     if (paramInt == 2 || !autoKeyInfo.isInsertSqlStmt())
/*       */     {
/*  6555 */       return prepareStatement(paramString);
/*       */     }
/*  6557 */     if (paramInt != 1) {
/*       */       
/*  6559 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6560 */       sQLException.fillInStackTrace();
/*  6561 */       throw sQLException;
/*       */     } 
/*       */     
/*  6564 */     String str = autoKeyInfo.getNewSql();
/*  6565 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6566 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6568 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6569 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6570 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6571 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLException {
/*  6620 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint);
/*       */     
/*  6622 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  6624 */     if (paramArrayOfint == null || paramArrayOfint.length == 0) {
/*       */       
/*  6626 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6627 */       sQLException.fillInStackTrace();
/*  6628 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6633 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  6635 */     String str = autoKeyInfo.getNewSql();
/*  6636 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6637 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6639 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6640 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6641 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6642 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLException {
/*  6692 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*  6693 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  6695 */     if (paramArrayOfString == null || paramArrayOfString.length == 0) {
/*       */       
/*  6697 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6698 */       sQLException.fillInStackTrace();
/*  6699 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6703 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  6705 */     String str = autoKeyInfo.getNewSql();
/*  6706 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6707 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6709 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6710 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6711 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6712 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint() throws SQLException {
/*  6738 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  6741 */     if (this.autocommit) {
/*       */       
/*  6743 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6744 */       sQLException.fillInStackTrace();
/*  6745 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6750 */     if (this.savepointStatement == null)
/*       */     {
/*  6752 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6755 */     OracleSavepoint oracleSavepoint = new OracleSavepoint();
/*       */     
/*  6757 */     String str = "SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
/*       */     
/*  6759 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  6762 */     return oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint(String paramString) throws SQLException {
/*  6789 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  6792 */     if (this.autocommit) {
/*       */       
/*  6794 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6795 */       sQLException.fillInStackTrace();
/*  6796 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6801 */     if (this.savepointStatement == null)
/*       */     {
/*  6803 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6806 */     OracleSavepoint oracleSavepoint = new OracleSavepoint(paramString);
/*       */     
/*  6808 */     String str = "SAVEPOINT " + oracleSavepoint.getSavepointName();
/*       */     
/*  6810 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  6813 */     return oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleRollback(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  6841 */     disallowGlobalTxnMode(115);
/*       */ 
/*       */     
/*  6844 */     if (this.autocommit) {
/*       */       
/*  6846 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6847 */       sQLException.fillInStackTrace();
/*  6848 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6853 */     if (this.savepointStatement == null)
/*       */     {
/*  6855 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6858 */     String str = null;
/*       */ 
/*       */     
/*       */     try {
/*  6862 */       str = paramOracleSavepoint.getSavepointName();
/*       */     }
/*  6864 */     catch (SQLException sQLException) {
/*       */       
/*  6866 */       str = "ORACLE_SVPT_" + paramOracleSavepoint.getSavepointId();
/*       */     } 
/*       */     
/*  6869 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleReleaseSavepoint(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  6897 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6898 */     sQLException.fillInStackTrace();
/*  6899 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void disallowGlobalTxnMode(int paramInt) throws SQLException {
/*  6920 */     if (this.txnMode == 1) {
/*       */       
/*  6922 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/*  6923 */       sQLException.fillInStackTrace();
/*  6924 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTxnMode(int paramInt) {
/*  6938 */     this.txnMode = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTxnMode() {
/*  6945 */     return this.txnMode;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getClientData(Object paramObject) {
/*  6974 */     if (this.clientData == null)
/*       */     {
/*  6976 */       return null;
/*       */     }
/*       */     
/*  6979 */     return this.clientData.get(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object setClientData(Object paramObject1, Object paramObject2) {
/*  7006 */     if (this.clientData == null)
/*       */     {
/*  7008 */       this.clientData = new Hashtable<Object, Object>();
/*       */     }
/*       */     
/*  7011 */     return this.clientData.put(paramObject1, paramObject2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object removeClientData(Object paramObject) {
/*  7032 */     if (this.clientData == null)
/*       */     {
/*  7034 */       return null;
/*       */     }
/*       */     
/*  7037 */     return this.clientData.remove(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BlobDBAccess createBlobDBAccess() throws SQLException {
/*  7045 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7046 */     sQLException.fillInStackTrace();
/*  7047 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ClobDBAccess createClobDBAccess() throws SQLException {
/*  7056 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7057 */     sQLException.fillInStackTrace();
/*  7058 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BfileDBAccess createBfileDBAccess() throws SQLException {
/*  7067 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7068 */     sQLException.fillInStackTrace();
/*  7069 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void printState() {
/*       */     try {
/*  7095 */       short s1 = getJdbcCsId();
/*       */ 
/*       */       
/*  7098 */       short s2 = getDbCsId();
/*       */ 
/*       */       
/*  7101 */       short s3 = getStructAttrCsId();
/*       */     
/*       */     }
/*  7104 */     catch (SQLException sQLException) {
/*       */       
/*  7106 */       sQLException.printStackTrace();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getProtocolType() {
/*  7118 */     return this.protocol;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getURL() {
/*  7129 */     return this.url;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
/*  7143 */     setStatementCacheSize(paramInt);
/*  7144 */     setImplicitCachingEnabled(true);
/*  7145 */     setExplicitCachingEnabled(true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
/*  7160 */     setStatementCacheSize(paramInt);
/*  7161 */     setImplicitCachingEnabled(true);
/*       */ 
/*       */     
/*  7164 */     setExplicitCachingEnabled(true);
/*       */     
/*  7166 */     this.clearStatementMetaData = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStmtCacheSize() {
/*  7180 */     int i = 0;
/*       */ 
/*       */     
/*       */     try {
/*  7184 */       i = getStatementCacheSize();
/*       */     }
/*  7186 */     catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7192 */     if (i == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7197 */       i = 0;
/*       */     }
/*       */     
/*  7200 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStatementCacheSize(int paramInt) throws SQLException {
/*  7221 */     if (this.statementCache == null) {
/*       */       
/*  7223 */       this.statementCache = new LRUStatementCache(paramInt);
/*       */ 
/*       */     
/*       */     }
/*       */     else {
/*       */ 
/*       */       
/*  7230 */       this.statementCache.resize(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStatementCacheSize() throws SQLException {
/*  7249 */     if (this.statementCache == null) {
/*  7250 */       return -1;
/*       */     }
/*  7252 */     return this.statementCache.getCacheSize();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  7275 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7280 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7287 */     this.statementCache.setImplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getImplicitCachingEnabled() throws SQLException {
/*  7306 */     if (this.statementCache == null) {
/*  7307 */       return false;
/*       */     }
/*  7309 */     return this.statementCache.getImplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  7332 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7337 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7344 */     this.statementCache.setExplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getExplicitCachingEnabled() throws SQLException {
/*  7363 */     if (this.statementCache == null) {
/*  7364 */       return false;
/*       */     }
/*  7366 */     return this.statementCache.getExplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeImplicitCache() throws SQLException {
/*  7385 */     if (this.statementCache != null) {
/*  7386 */       this.statementCache.purgeImplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeExplicitCache() throws SQLException {
/*  7405 */     if (this.statementCache != null) {
/*  7406 */       this.statementCache.purgeExplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement getStatementWithKey(String paramString) throws SQLException {
/*  7428 */     if (this.statementCache != null) {
/*       */       
/*  7430 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  7433 */       if (oracleStatement == null || oracleStatement.statementType == 1) {
/*  7434 */         return (PreparedStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  7438 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7439 */       sQLException.fillInStackTrace();
/*  7440 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7445 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement getCallWithKey(String paramString) throws SQLException {
/*  7467 */     if (this.statementCache != null) {
/*       */       
/*  7469 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  7472 */       if (oracleStatement == null || oracleStatement.statementType == 2) {
/*  7473 */         return (CallableStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  7477 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7478 */       sQLException.fillInStackTrace();
/*  7479 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7484 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void cacheImplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  7500 */     if (this.statementCache == null) {
/*       */       
/*  7502 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7503 */       sQLException.fillInStackTrace();
/*  7504 */       throw sQLException;
/*       */     } 
/*       */     
/*  7507 */     this.statementCache.addToImplicitCache(paramOraclePreparedStatement, paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void cacheExplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
/*  7524 */     if (this.statementCache == null) {
/*       */       
/*  7526 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7527 */       sQLException.fillInStackTrace();
/*  7528 */       throw sQLException;
/*       */     } 
/*       */     
/*  7531 */     this.statementCache.addToExplicitCache(paramOraclePreparedStatement, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isStatementCacheInitialized() {
/*  7546 */     if (this.statementCache == null)
/*  7547 */       return false; 
/*  7548 */     if (this.statementCache.getCacheSize() == 0) {
/*  7549 */       return false;
/*       */     }
/*  7551 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final class BufferCacheStore
/*       */   {
/*  7587 */     static int MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
/*       */     final BufferCache<byte[]> byteBufferCache;
/*       */     final BufferCache<char[]> charBufferCache;
/*       */     
/*       */     BufferCacheStore() {
/*  7592 */       this(MAX_CACHED_BUFFER_SIZE);
/*       */     }
/*       */     
/*       */     BufferCacheStore(int param1Int) {
/*  7596 */       this.byteBufferCache = (BufferCache)new BufferCache<byte>(param1Int);
/*  7597 */       this.charBufferCache = (BufferCache)new BufferCache<char>(param1Int);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private BufferCacheStore getBufferCacheStore() {
/*  7608 */     if (this.useThreadLocalBufferCache) {
/*  7609 */       if (threadLocalBufferCacheStore == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7622 */         BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
/*  7623 */         threadLocalBufferCacheStore = new ThreadLocal<BufferCacheStore>()
/*       */           {
/*       */             protected PhysicalConnection.BufferCacheStore initialValue()
/*       */             {
/*  7627 */               return new PhysicalConnection.BufferCacheStore();
/*       */             }
/*       */           };
/*       */       } 
/*  7631 */       return threadLocalBufferCacheStore.get();
/*       */     } 
/*       */     
/*  7634 */     if (this.connectionBufferCacheStore == null)
/*       */     {
/*  7636 */       this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
/*       */     }
/*  7638 */     return this.connectionBufferCacheStore;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(byte[] paramArrayOfbyte) {
/*  7649 */     if (paramArrayOfbyte != null) {
/*  7650 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7651 */       bufferCacheStore.byteBufferCache.put(paramArrayOfbyte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(char[] paramArrayOfchar) {
/*  7663 */     if (paramArrayOfchar != null) {
/*  7664 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7665 */       bufferCacheStore.charBufferCache.put(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/*       */   public void cacheBufferSync(char[] paramArrayOfchar) {
/*  7671 */     synchronized (this) {
/*  7672 */       cacheBuffer(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] getByteBuffer(int paramInt) {
/*  7684 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7685 */     return bufferCacheStore.byteBufferCache.get(byte.class, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   char[] getCharBuffer(int paramInt) {
/*  7697 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7698 */     return bufferCacheStore.charBufferCache.get(char.class, paramInt);
/*       */   }
/*       */ 
/*       */   
/*       */   public char[] getCharBufferSync(int paramInt) {
/*  7703 */     synchronized (this) {
/*  7704 */       return getCharBuffer(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics() {
/*  7715 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7716 */     return bufferCacheStore.byteBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics() {
/*  7727 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7728 */     return bufferCacheStore.charBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/*  7751 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7752 */     sQLException.fillInStackTrace();
/*  7753 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDatabaseProductVersion() throws SQLException {
/*  7766 */     if (this.databaseProductVersion == "") {
/*       */       
/*  7768 */       needLine();
/*       */       
/*  7770 */       this.databaseProductVersion = doGetDatabaseProductVersion();
/*       */     } 
/*       */     
/*  7773 */     return this.databaseProductVersion;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getReportRemarks() {
/*  7780 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getVersionNumber() throws SQLException {
/*  7787 */     if (this.versionNumber == -1)
/*       */     {
/*  7789 */       synchronized (this) {
/*       */         
/*  7791 */         if (this.versionNumber == -1) {
/*       */           
/*  7793 */           needLine();
/*       */           
/*  7795 */           this.versionNumber = doGetVersionNumber();
/*       */         } 
/*       */       } 
/*       */     }
/*       */     
/*  7800 */     return this.versionNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
/*  7808 */     this.closeCallback = paramOracleCloseCallback;
/*  7809 */     this.privateData = paramObject;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCreateStatementAsRefCursor(boolean paramBoolean) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getCreateStatementAsRefCursor() {
/*  7857 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase() throws SQLException {
/*  7868 */     if (this.lifecycle != 1)
/*  7869 */       return -1; 
/*  7870 */     return doPingDatabase();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase(int paramInt) throws SQLException {
/*  7883 */     if (this.lifecycle != 1)
/*  7884 */       return -1; 
/*  7885 */     if (paramInt == 0) {
/*  7886 */       return pingDatabase();
/*       */     }
/*       */     
/*       */     try {
/*  7890 */       this.pingResult = -2;
/*  7891 */       Thread thread = new Thread(new Runnable() {
/*       */             public void run() {
/*       */               try {
/*  7894 */                 PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
/*       */               }
/*  7896 */               catch (Throwable throwable) {}
/*       */             }
/*       */           });
/*  7899 */       thread.start();
/*  7900 */       thread.join((paramInt * 1000));
/*  7901 */       return this.pingResult;
/*       */     }
/*  7903 */     catch (InterruptedException interruptedException) {
/*  7904 */       return -3;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doPingDatabase() throws SQLException {
/*  7913 */     Statement statement = null;
/*       */ 
/*       */     
/*       */     try {
/*  7917 */       statement = createStatement();
/*       */       
/*  7919 */       ((OracleStatement)statement).defineColumnType(1, 12, 1);
/*  7920 */       statement.executeQuery("SELECT 'x' FROM DUAL");
/*       */     }
/*  7922 */     catch (SQLException sQLException) {
/*       */       
/*  7924 */       return -1;
/*       */     }
/*       */     finally {
/*       */       
/*  7928 */       if (statement != null) {
/*  7929 */         statement.close();
/*       */       }
/*       */     } 
/*  7932 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getJavaObjectTypeMap() {
/*  7948 */     return this.javaObjectMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setJavaObjectTypeMap(Map paramMap) {
/*  7958 */     this.javaObjectMap = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearClientIdentifier(String paramString) throws SQLException {
/*  7973 */     if (paramString != null && paramString.length() != 0) {
/*       */ 
/*       */ 
/*       */       
/*  7977 */       String[] arrayOfString = getEndToEndMetrics();
/*       */       
/*  7979 */       if (arrayOfString != null && paramString.equals(arrayOfString[1])) {
/*       */ 
/*       */         
/*  7982 */         arrayOfString[1] = null;
/*       */         
/*  7984 */         setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClientIdentifier(String paramString) throws SQLException {
/*  8006 */     String[] arrayOfString = getEndToEndMetrics();
/*       */     
/*  8008 */     if (arrayOfString == null)
/*       */     {
/*  8010 */       arrayOfString = new String[4];
/*       */     }
/*       */ 
/*       */     
/*  8014 */     arrayOfString[1] = paramString;
/*       */     
/*  8016 */     setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected PhysicalConnection()
/*       */   {
/*  8028 */     this.sessionTimeZone = null;
/*  8029 */     this.databaseTimeZone = null;
/*  8030 */     this.dbTzCalendar = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11072 */     this.timeZoneVersionNumber = -1;
/* 11073 */     this.timeZoneTab = null; this.cancelInProgressLockForThin = new Object(); } public void setSessionTimeZone(String paramString) throws SQLException { Statement statement = null; Object object = null; try { statement = createStatement(); statement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + paramString + "'"); if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  } catch (SQLException sQLException) { throw sQLException; } finally { if (statement != null) statement.close();  }  this.sessionTimeZone = paramString; } public String getDatabaseTimeZone() throws SQLException { if (this.databaseTimeZone == null) this.databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");  return this.databaseTimeZone; } public String getSessionTimeZone() { return this.sessionTimeZone; } private static String to2DigitString(int paramInt) { String str; if (paramInt < 10) { str = "0" + paramInt; } else { str = "" + paramInt; }  return str; } public String tzToOffset(String paramString) { if (paramString == null) return paramString;  char c = paramString.charAt(0); if (c != '-' && c != '+') { TimeZone timeZone = TimeZone.getTimeZone(paramString); int i = timeZone.getOffset(System.currentTimeMillis()); if (i != 0) { int j = i / 60000; int k = j / 60; j -= k * 60; if (i > 0) { paramString = "+" + to2DigitString(k) + ":" + to2DigitString(j); } else { paramString = "-" + to2DigitString(-k) + ":" + to2DigitString(-j); }  } else { paramString = "+00:00"; }  }  return paramString; } public String getSessionTimeZoneOffset() throws SQLException { String str = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL"); if (str != null) str = tzToOffset(str.trim());  return str; } private void setDbTzCalendar(String paramString) { char c = paramString.charAt(0); if (c == '-' || c == '+') paramString = "GMT" + paramString;  TimeZone timeZone = TimeZone.getTimeZone(paramString); this.dbTzCalendar = new GregorianCalendar(timeZone); } public Calendar getDbTzCalendar() throws SQLException { if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  return this.dbTzCalendar; } public void setAccumulateBatchResult(boolean paramBoolean) { this.accumulateBatchResult = paramBoolean; } public boolean isAccumulateBatchResult() { return this.accumulateBatchResult; } public void setJ2EE13Compliant(boolean paramBoolean) { this.j2ee13Compliant = paramBoolean; } public boolean getJ2EE13Compliant() { return this.j2ee13Compliant; } public Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException { return Class.forName(paramString1); } public Class safelyGetClassForName(String paramString) throws ClassNotFoundException { return Class.forName(paramString); } public int getHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public int getOCIEnvHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public static OracleConnection unwrapCompletely(OracleConnection paramOracleConnection) { OracleConnection oracleConnection1 = paramOracleConnection; OracleConnection oracleConnection2 = oracleConnection1; while (true) { if (oracleConnection2 == null) return (OracleConnection)oracleConnection1;  oracleConnection1 = oracleConnection2; oracleConnection2 = oracleConnection1.unwrap(); }  } public void setWrapper(OracleConnection paramOracleConnection) { this.wrapper = paramOracleConnection; } public OracleConnection unwrap() { return null; } public OracleConnection getWrapper() { if (this.wrapper != null) return this.wrapper;  return (OracleConnection)this; } static OracleConnection _physicalConnectionWithin(Connection paramConnection) { OracleConnection oracleConnection = null; if (paramConnection != null) oracleConnection = unwrapCompletely((OracleConnection)paramConnection);  return oracleConnection; } public OracleConnection physicalConnectionWithin() { return this; } public long getTdoCState(String paramString1, String paramString2) throws SQLException { return 0L; } public void getOracleTypeADT(OracleTypeADT paramOracleTypeADT) throws SQLException {} public Datum toDatum(CustomDatum paramCustomDatum) throws SQLException { return paramCustomDatum.toDatum(this); } public short getNCharSet() { return this.conversion.getNCharSetId(); } public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramArrayOfDatum, paramLong, paramInt, paramMap); } public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramARRAY, paramLong, paramInt, paramMap); } public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayLocatorResultSet(this, paramArrayDescriptor, paramArrayOfbyte, paramLong, paramInt, paramMap); } public ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException { return (ResultSetMetaData)new StructMetaData(paramStructDescriptor); } public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; arrayOfInt[0] = paramInt; return this.conversion.CHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; return this.conversion.NCHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public boolean IsNCharFixedWith() { return this.conversion.IsNCharFixedWith(); } public short getDriverCharSet() { return this.conversion.getClientCharSet(); } public int getMaxCharSize() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58); sQLException.fillInStackTrace(); throw sQLException; } public int getMaxCharbyteSize() { return this.conversion.getMaxCharbyteSize(); } public int getMaxNCharbyteSize() { return this.conversion.getMaxNCharbyteSize(); } public boolean isCharSetMultibyte(short paramShort) { return DBConversion.isCharSetMultibyte(paramShort); } PhysicalConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { this.sessionTimeZone = null; this.databaseTimeZone = null; this.dbTzCalendar = null; this.timeZoneVersionNumber = -1; this.timeZoneTab = null; this.cancelInProgressLockForThin = new Object(); readConnectionProperties(paramString, paramProperties); this.driverExtension = paramOracleDriverExtension; initialize((Hashtable)null, (Map)null, (Map)null); this.logicalConnectionAttached = null; try { needLine(); logon(); setAutoCommit(this.autocommit); if (getVersionNumber() >= 11202) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 64; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 64; } else if (getVersionNumber() >= 11000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 10000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 9200) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 2000; this.maxVcsCharsSql = 4000; this.maxVcsNCharsSql = 4000; this.maxVcsBytesPlsql = 4000; this.maxIbtVarcharElementLength = 4000; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; }  if (getVersionNumber() >= 10000) this.retainV9BindBehavior = false;  initializeSetCHARCharSetObjs(); if (this.implicitStatementCacheSize > 0) { setStatementCacheSize(this.implicitStatementCacheSize); setImplicitCachingEnabled(true); }  } catch (SQLException sQLException) { this.lifecycle = 2; try { logoff(); } catch (SQLException sQLException1) {} this.lifecycle = 4; throw sQLException; }  this.txnMode = 0; }
/*       */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
/*       */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToNCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
/*       */   final void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection, String paramString) throws SQLException { Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(); hashtable.put("obj_type_map", this.javaObjectMap); Properties properties = new Properties(); properties.put("user", this.userName); properties.put("password", paramString); properties.put("connection_url", this.url); properties.put("connect_auto_commit", "" + this.autocommit); properties.put("trans_isolation", "" + this.txnLevel); if (getStatementCacheSize() != -1) { properties.put("stmt_cache_size", "" + getStatementCacheSize()); properties.put("implicit_cache_enabled", "" + getImplicitCachingEnabled()); properties.put("explict_cache_enabled", "" + getExplicitCachingEnabled()); }  properties.put("defaultExecuteBatch", "" + this.defaultExecuteBatch); properties.put("defaultRowPrefetch", "" + this.defaultRowPrefetch); properties.put("remarksReporting", "" + this.reportRemarks); properties.put("AccumulateBatchResult", "" + this.accumulateBatchResult); properties.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant); properties.put("processEscapes", "" + this.processEscapes); properties.put("restrictGetTables", "" + this.restrictGettables); properties.put("includeSynonyms", "" + this.includeSynonyms); properties.put("fixedString", "" + this.fixedString); hashtable.put("connection_properties", properties); paramOraclePooledConnection.setProperties(hashtable); }
/* 11077 */   public Properties getDBAccessProperties() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Properties getOCIHandles() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void logoff() throws SQLException {} int getDefaultStreamChunkSize() { return this.streamChunkSize; } public OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException { if (this.logicalConnectionAttached != null || paramOraclePooledConnection.getPhysicalHandle() != this) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143); sQLException.fillInStackTrace(); throw sQLException; }  LogicalConnection logicalConnection = new LogicalConnection(paramOraclePooledConnection, this, paramBoolean); this.logicalConnectionAttached = logicalConnection; return (Connection)logicalConnection; } public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {} public CLOB createClob(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte, true); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException { if (paramShort == 2) return (CLOB)new NCLOB((OracleConnection)this, paramArrayOfbyte);  return new CLOB((OracleConnection)this, paramArrayOfbyte, paramShort); } public BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte); } public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte, true); } public BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException { return new BFILE((OracleConnection)this, paramArrayOfbyte); } public ARRAY createARRAY(String paramString, Object paramObject) throws SQLException { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this); return new ARRAY(arrayDescriptor, (Connection)this, paramObject); } public Array createOracleArray(String paramString, Object paramObject) throws SQLException { return (Array)createARRAY(paramString, paramObject); } public BINARY_DOUBLE createBINARY_DOUBLE(double paramDouble) throws SQLException { return new BINARY_DOUBLE(paramDouble); } public BINARY_FLOAT createBINARY_FLOAT(float paramFloat) throws SQLException { return new BINARY_FLOAT(paramFloat); } public DATE createDATE(Date paramDate) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(Date paramDate, Calendar paramCalendar) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime, Calendar paramCalendar) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(String paramString) throws SQLException { return new DATE(paramString); } public INTERVALDS createINTERVALDS(String paramString) throws SQLException { return new INTERVALDS(paramString); } public INTERVALYM createINTERVALYM(String paramString) throws SQLException { return new INTERVALYM(paramString); } public NUMBER createNUMBER(boolean paramBoolean) throws SQLException { return new NUMBER(paramBoolean); } public NUMBER createNUMBER(byte paramByte) throws SQLException { return new NUMBER(paramByte); } public NUMBER createNUMBER(short paramShort) throws SQLException { return new NUMBER(paramShort); } public NUMBER createNUMBER(int paramInt) throws SQLException { return new NUMBER(paramInt); } public NUMBER createNUMBER(long paramLong) throws SQLException { return new NUMBER(paramLong); } public NUMBER createNUMBER(float paramFloat) throws SQLException { return new NUMBER(paramFloat); } public NUMBER createNUMBER(double paramDouble) throws SQLException { return new NUMBER(paramDouble); } public NUMBER createNUMBER(BigDecimal paramBigDecimal) throws SQLException { return new NUMBER(paramBigDecimal); } public NUMBER createNUMBER(BigInteger paramBigInteger) throws SQLException { return new NUMBER(paramBigInteger); } public int getTimezoneVersionNumber() throws SQLException { return this.timeZoneVersionNumber; } public NUMBER createNUMBER(String paramString, int paramInt) throws SQLException { return new NUMBER(paramString, paramInt); } public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException { try { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this); return (Struct)new STRUCT(structDescriptor, (Connection)this, paramArrayOfObject); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 17049) removeAllDescriptor();  throw sQLException; }  } public TIMESTAMP createTIMESTAMP(Date paramDate) throws SQLException { return new TIMESTAMP(paramDate); } public TIMESTAMP createTIMESTAMP(DATE paramDATE) throws SQLException { return new TIMESTAMP(paramDATE); } public TIMESTAMP createTIMESTAMP(Time paramTime) throws SQLException { return new TIMESTAMP(paramTime); } public TIMESTAMP createTIMESTAMP(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMP(paramTimestamp); } public TIMESTAMP createTIMESTAMP(String paramString) throws SQLException { return new TIMESTAMP(paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(DATE paramDATE) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDATE); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDate); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTime); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTimestamp); } public TIMESTAMPLTZ createTIMESTAMPLTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramString); } public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE paramDATE, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDATE); } public Blob createBlob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Blob)createTemporaryBlob((Connection)this, true, 10); } public Clob createClob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Clob)createTemporaryClob((Connection)this, true, 10, (short)1); } public NClob createNClob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (NClob)createTemporaryClob((Connection)this, true, 10, (short)2); } public SQLXML createSQLXML() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (SQLXML)new XMLType((Connection)this, (String)null); } public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException { PhysicalConnection physicalConnection1 = this; PhysicalConnection physicalConnection2 = (PhysicalConnection)paramOracleConnection.getPhysicalConnection(); return (physicalConnection1 == physicalConnection2 || physicalConnection1.url.equals(physicalConnection2.url) || (physicalConnection2.protocol != null && physicalConnection2.protocol.equals("kprb"))); } boolean useLittleEndianSetCHARBinder() throws SQLException { return false; } public void setPlsqlWarnings(String paramString) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString != null && (paramString = paramString.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(paramString)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str1 = "ALTER SESSION SET PLSQL_WARNINGS=" + paramString; String str2 = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'"; Statement statement = null; try { statement = createStatement(-1, -1); statement.execute(str1); if (paramString.equals("'DISABLE:ALL'")) { this.plsqlCompilerWarnings = false; } else { statement.execute(str2); this.plsqlCompilerWarnings = true; }  } finally { if (statement != null) statement.close();  }  }
/*       */   void internalClose() throws SQLException { this.lifecycle = 4; OracleStatement oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.nextChild; if (oracleStatement.serverCursor) { oracleStatement.internalClose(); removeStatement(oracleStatement); }  oracleStatement = oracleStatement1; }  oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.next; oracleStatement.internalClose(); oracleStatement = oracleStatement1; }  this.statements = null; }
/*       */   public XAResource getXAResource() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { if (paramString1 == null || paramString2 == null || paramString3 == null) throw new NullPointerException();  if (paramString1.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString1.compareToIgnoreCase("CLIENTCONTEXT") != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 174); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString2.length() > 30) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString3.length() > 4000) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172); sQLException.fillInStackTrace(); throw sQLException; }  doSetApplicationContext(paramString1, paramString2, paramString3); }
/*       */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void clearAllApplicationContext(String paramString) throws SQLException { if (paramString == null) throw new NullPointerException();  if (paramString.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  doClearAllApplicationContext(paramString); }
/*       */   void doClearAllApplicationContext(String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/* 11087 */   public TIMEZONETAB getTIMEZONETAB() throws SQLException { if (this.timeZoneTab == null) {
/* 11088 */       this.timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());
/*       */     }
/* 11090 */     return this.timeZoneTab; } public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void enqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessage paramAQMessage) throws SQLException { AQMessageI aQMessageI = (AQMessageI)paramAQMessage; byte[][] arrayOfByte = new byte[1][]; doEnqueue(paramString, paramAQEnqueueOptions, aQMessageI.getMessagePropertiesI(), aQMessageI.getPayloadTOID(), aQMessageI.getPayload(), arrayOfByte, aQMessageI.isRAWPayload()); if (arrayOfByte[0] != null) aQMessageI.setMessageId(arrayOfByte[0]);  } public AQMessage dequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfbyte) throws SQLException { byte[][] arrayOfByte1 = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = new AQMessagePropertiesI(); byte[][] arrayOfByte2 = new byte[1][]; boolean bool = false; bool = doDequeue(paramString, paramAQDequeueOptions, aQMessagePropertiesI, paramArrayOfbyte, arrayOfByte2, arrayOfByte1, AQMessageI.compareToid(paramArrayOfbyte, TypeDescriptor.RAWTOID)); AQMessageI aQMessageI = null; if (bool) { aQMessageI = new AQMessageI(aQMessagePropertiesI, (Connection)this); aQMessageI.setPayload(arrayOfByte2[0], paramArrayOfbyte); aQMessageI.setMessageId(arrayOfByte1[0]); }  return aQMessageI; } public AQMessage dequeue(String paramString1, AQDequeueOptions paramAQDequeueOptions, String paramString2) throws SQLException { byte[] arrayOfByte = null; TypeDescriptor typeDescriptor = null; if ("RAW".equals(paramString2) || "SYS.RAW".equals(paramString2)) { arrayOfByte = TypeDescriptor.RAWTOID; } else if ("SYS.ANYDATA".equals(paramString2)) { arrayOfByte = TypeDescriptor.ANYDATATOID; } else if ("SYS.XMLTYPE".equals(paramString2)) { arrayOfByte = TypeDescriptor.XMLTYPETOID; } else { typeDescriptor = TypeDescriptor.getTypeDescriptor(paramString2, (OracleConnection)this); arrayOfByte = ((OracleTypeADT)typeDescriptor.getPickler()).getTOID(); }  AQMessageI aQMessageI = (AQMessageI)dequeue(paramString1, paramAQDequeueOptions, arrayOfByte); if (aQMessageI != null) { aQMessageI.setTypeName(paramString2); aQMessageI.setTypeDescriptor(typeDescriptor); }  return aQMessageI; } synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public boolean isV8Compatible() throws SQLException { return this.mapDateToTimestamp; } public boolean getMapDateToTimestamp() { return this.mapDateToTimestamp; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public AQNotificationRegistration[] registerAQNotification(String[] paramArrayOfString, Properties[] paramArrayOfProperties, Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); NTFAQRegistration[] arrayOfNTFAQRegistration = doRegisterAQNotification(paramArrayOfString, str, i, paramArrayOfProperties); return (AQNotificationRegistration[])arrayOfNTFAQRegistration; } NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterAQNotification(AQNotificationRegistration paramAQNotificationRegistration) throws SQLException { NTFAQRegistration nTFAQRegistration = (NTFAQRegistration)paramAQNotificationRegistration; doUnregisterAQNotification(nTFAQRegistration); } void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } private String readNTFlocalhost(Properties paramProperties) throws SQLException { String str = null; try { str = paramProperties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress()); } catch (UnknownHostException unknownHostException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240); sQLException.fillInStackTrace(); throw sQLException; } catch (SecurityException securityException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241); sQLException.fillInStackTrace(); throw sQLException; }  return str; } private int readNTFtcpport(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_LOCAL_TCP_PORT", "0")); if (i < 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  return i; } int readNTFtimeout(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_TIMEOUT", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243); sQLException.fillInStackTrace(); throw sQLException; }  return i; } public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); int j = readNTFtimeout(paramProperties); int k = 0; try { k = Integer.parseInt(paramProperties.getProperty("DCN_NOTIFY_CHANGELAG", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244); sQLException.fillInStackTrace(); throw sQLException; }  NTFDCNRegistration nTFDCNRegistration = doRegisterDatabaseChangeNotification(str, i, paramProperties, j, k); ntfManager.addRegistration(nTFDCNRegistration); return nTFDCNRegistration; } NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public DatabaseChangeRegistration getDatabaseChangeRegistration(int paramInt) throws SQLException { return new NTFDCNRegistration(this.instanceName, paramInt, this.userName, this.versionNumber); } public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { NTFDCNRegistration nTFDCNRegistration = (NTFDCNRegistration)paramDatabaseChangeRegistration; if (nTFDCNRegistration.getDatabaseName().compareToIgnoreCase(this.instanceName) != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245); sQLException.fillInStackTrace(); throw sQLException; }  doUnregisterDatabaseChangeNotification(nTFDCNRegistration); } void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterDatabaseChangeNotification(int paramInt) throws SQLException { String str = null; try { str = InetAddress.getLocalHost().getHostAddress(); } catch (Exception exception) {} unregisterDatabaseChangeNotification(paramInt, str, 47632); } public void unregisterDatabaseChangeNotification(int paramInt1, String paramString, int paramInt2) throws SQLException { String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt2 + "))?PR=0"; unregisterDatabaseChangeNotification(paramInt1, str); } public void unregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { doUnregisterDatabaseChangeNotification(paramLong, paramString); }
/*       */   void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; Statement statement = null; try { statement = createStatement(); ResultSet resultSet = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())"); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (statement != null) statement.close();  }  return arrayOfTypeDescriptor; }
/*       */   public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String[] paramArrayOfString) throws SQLException { String str = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))"; TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; try { preparedStatement = prepareStatement(str); int i = paramArrayOfString.length; StringBuffer stringBuffer = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer.append(paramArrayOfString[b]); if (b < i - 1) stringBuffer.append(',');  }  preparedStatement.setString(1, stringBuffer.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
/*       */   public TypeDescriptor[] getTypeDescriptorsFromList(String[][] paramArrayOfString) throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; int i = paramArrayOfString.length; StringBuffer stringBuffer1 = new StringBuffer(i * 8); StringBuffer stringBuffer2 = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer1.append(paramArrayOfString[b][0]); stringBuffer2.append(paramArrayOfString[b][1]); if (b < i - 1) { stringBuffer1.append(','); stringBuffer2.append(','); }  }  try { String str = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))"; preparedStatement = prepareStatement(str); preparedStatement.setString(1, stringBuffer1.toString()); preparedStatement.setString(2, stringBuffer2.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
/*       */   TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet paramResultSet) throws SQLException { ArrayList<StructDescriptor> arrayList = new ArrayList(); while (paramResultSet.next()) { String str1 = paramResultSet.getString(1); String str2 = paramResultSet.getString(2); byte[] arrayOfByte1 = paramResultSet.getBytes(3); String str3 = paramResultSet.getString(4); int i = paramResultSet.getInt(5); byte[] arrayOfByte2 = paramResultSet.getBytes(6); SQLName sQLName = new SQLName(str1, str2, (OracleConnection)this); if (str3.equals("OBJECT")) { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, structDescriptor); putDescriptor(structDescriptor.getName(), structDescriptor); arrayList.add(structDescriptor); continue; }  if (str3.equals("COLLECTION")) { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, arrayDescriptor); putDescriptor(arrayDescriptor.getName(), arrayDescriptor); arrayList.add(arrayDescriptor); }  }  TypeDescriptor[] arrayOfTypeDescriptor = new TypeDescriptor[arrayList.size()]; for (byte b = 0; b < arrayList.size(); b++) { TypeDescriptor typeDescriptor = (TypeDescriptor)arrayList.get(b); arrayOfTypeDescriptor[b] = typeDescriptor; }  return arrayOfTypeDescriptor; }
/*       */   public synchronized boolean isUsable() { return this.isUsable; }
/*       */   public void setUsable(boolean paramBoolean) { this.isUsable = paramBoolean; }
/*       */   void queryFCFProperties(Properties paramProperties) throws SQLException { Statement statement = null; ResultSet resultSet = null; String str = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual"; try { statement = createStatement(); statement.setFetchSize(1); resultSet = statement.executeQuery(str); while (resultSet.next()) { String str1 = null; str1 = resultSet.getString(1); if (str1 != null) paramProperties.put("INSTANCE_NAME", str1.trim());  str1 = resultSet.getString(2); if (str1 != null) paramProperties.put("SERVER_HOST", str1.trim());  str1 = resultSet.getString(3); if (str1 != null) paramProperties.put("SERVICE_NAME", str1.trim());  str1 = resultSet.getString(4); if (str1 != null) paramProperties.put("DATABASE_NAME", str1.trim());  }  } finally { if (resultSet != null) resultSet.close();  if (statement != null) statement.close();  }  }
/*       */   public void setDefaultTimeZone(TimeZone paramTimeZone) throws SQLException { this.defaultTimeZone = paramTimeZone; }
/*       */   public TimeZone getDefaultTimeZone() throws SQLException { return this.defaultTimeZone; }
/* 11104 */   public boolean isDataInLocatorEnabled() throws SQLException { return ((getVersionNumber() >= 10200)) & ((getVersionNumber() < 11000)) & this.enableReadDataInLocator | this.overrideEnableReadDataInLocator; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isLobStreamPosStandardCompliant() throws SQLException {
/* 11113 */     return this.lobStreamPosStandardCompliant;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public long getCurrentSCN() throws SQLException {
/* 11120 */     return doGetCurrentSCN();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   long doGetCurrentSCN() throws SQLException {
/* 11126 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11127 */     sQLException.fillInStackTrace();
/* 11128 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/* 11135 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11136 */     sQLException.fillInStackTrace();
/* 11137 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public EnumSet<OracleConnection.TransactionState> getTransactionState() throws SQLException {
/* 11143 */     return doGetTransactionState();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 11149 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11150 */     sQLException.fillInStackTrace();
/* 11151 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isConnectionSocketKeepAlive() throws SocketException, SQLException {
/* 11158 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11159 */     sQLException.fillInStackTrace();
/* 11160 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/* 11165 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final boolean TRACE = false;
/*       */   
/*       */   abstract void initializePassword(String paramString) throws SQLException;
/*       */   
/*       */   abstract void doAbort() throws SQLException;
/*       */   
/*       */   public abstract void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
/*       */   
/*       */   abstract void logon() throws SQLException;
/*       */   
/*       */   abstract void open(OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   abstract void cancelOperationOnServer(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doSetAutoCommit(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doCommit(int paramInt) throws SQLException;
/*       */   
/*       */   abstract void doRollback() throws SQLException;
/*       */   
/*       */   abstract String doGetDatabaseProductVersion() throws SQLException;
/*       */   
/*       */   abstract short doGetVersionNumber() throws SQLException;
/*       */   
/*       */   abstract OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   public abstract BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException;
/*       */   
/*       */   public abstract CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException;
/*       */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\PhysicalConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */