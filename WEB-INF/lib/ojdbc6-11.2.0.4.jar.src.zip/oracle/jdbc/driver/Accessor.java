/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.OracleResultSetMetaData;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class Accessor
/*      */ {
/*      */   static final int FIXED_CHAR = 999;
/*      */   static final int CHAR = 96;
/*      */   static final int VARCHAR = 1;
/*      */   static final int VCS = 9;
/*      */   static final int LONG = 8;
/*      */   static final int NUMBER = 2;
/*      */   static final int VARNUM = 6;
/*      */   static final int BINARY_FLOAT = 100;
/*      */   static final int BINARY_DOUBLE = 101;
/*      */   static final int RAW = 23;
/*      */   static final int VBI = 15;
/*      */   static final int LONG_RAW = 24;
/*      */   static final int ROWID = 104;
/*      */   static final int RESULT_SET = 102;
/*      */   static final int RSET = 116;
/*      */   static final int DATE = 12;
/*      */   static final int BLOB = 113;
/*      */   static final int CLOB = 112;
/*      */   static final int BFILE = 114;
/*      */   static final int NAMED_TYPE = 109;
/*      */   static final int REF_TYPE = 111;
/*      */   static final int TIMESTAMP = 180;
/*      */   static final int TIMESTAMPTZ = 181;
/*      */   static final int TIMESTAMPLTZ = 231;
/*      */   static final int INTERVALYM = 182;
/*      */   static final int INTERVALDS = 183;
/*      */   static final int UROWID = 208;
/*      */   static final int PLSQL_INDEX_TABLE = 998;
/*      */   static final int T2S_OVERLONG_RAW = 997;
/*      */   static final int SET_CHAR_BYTES = 996;
/*      */   static final int NULL_TYPE = 995;
/*      */   static final int DML_RETURN_PARAM = 994;
/*      */   static final int ONLY_FORM_USABLE = 0;
/*      */   static final int NOT_USABLE = 1;
/*      */   static final int NO_NEED_TO_PREPARE = 2;
/*      */   static final int NEED_TO_PREPARE = 3;
/*      */   OracleStatement statement;
/*      */   boolean outBind;
/*      */   int internalType;
/*      */   int internalTypeMaxLength;
/*      */   boolean isStream = false;
/*      */   boolean isColumnNumberAware = false;
/*  143 */   short formOfUse = 2;
/*      */   
/*      */   OracleType internalOtype;
/*      */   
/*      */   int externalType;
/*      */   
/*      */   String internalTypeName;
/*      */   
/*      */   String columnName;
/*      */   
/*      */   int describeType;
/*      */   
/*      */   int describeMaxLength;
/*      */   
/*      */   boolean nullable;
/*      */   
/*      */   int precision;
/*      */   
/*      */   int scale;
/*      */   
/*      */   int flags;
/*      */   
/*      */   int contflag;
/*      */   
/*      */   int total_elems;
/*      */   
/*      */   OracleType describeOtype;
/*      */   String describeTypeName;
/*  171 */   int definedColumnType = 0;
/*  172 */   int definedColumnSize = 0;
/*  173 */   int oacmxl = 0;
/*      */ 
/*      */   
/*  176 */   short udskpos = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  186 */   int lobPrefetchSizeForThisColumn = -1;
/*      */ 
/*      */   
/*  189 */   long[] prefetchedLobSize = null;
/*      */   
/*  191 */   int[] prefetchedLobChunkSize = null;
/*      */ 
/*      */   
/*  194 */   byte[] prefetchedClobFormOfUse = null;
/*      */ 
/*      */ 
/*      */   
/*  198 */   byte[][] prefetchedLobData = (byte[][])null;
/*  199 */   char[][] prefetchedLobCharData = (char[][])null;
/*      */ 
/*      */   
/*  202 */   int[] prefetchedLobDataL = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleResultSetMetaData.SecurityAttribute securityAttribute;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  213 */   byte[] rowSpaceByte = null;
/*  214 */   char[] rowSpaceChar = null;
/*  215 */   short[] rowSpaceIndicator = null;
/*      */   
/*      */   static final byte DATA_UNAUTHORIZED = 1;
/*      */   
/*  219 */   byte[] rowSpaceMetaData = null;
/*      */   
/*  221 */   int columnIndex = 0;
/*  222 */   int lengthIndex = 0;
/*  223 */   int indicatorIndex = 0;
/*  224 */   int metaDataIndex = 0;
/*  225 */   int columnIndexLastRow = 0;
/*  226 */   int lengthIndexLastRow = 0;
/*  227 */   int indicatorIndexLastRow = 0;
/*  228 */   int metaDataIndexLastRow = 0;
/*  229 */   int byteLength = 0;
/*  230 */   int charLength = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defineType;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDMLReturnedParam = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setOffsets(int paramInt) {
/*  247 */     this.columnIndex = this.statement.defineByteSubRange;
/*  248 */     this.statement.defineByteSubRange = this.columnIndex + paramInt * this.byteLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, boolean paramBoolean) throws SQLException {
/*  256 */     this.statement = paramOracleStatement;
/*  257 */     this.outBind = paramBoolean;
/*  258 */     this.internalType = paramInt1;
/*  259 */     this.defineType = paramInt2;
/*  260 */     this.formOfUse = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initForDescribe(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  272 */     this.describeType = paramInt1;
/*  273 */     this.describeMaxLength = paramInt2;
/*  274 */     this.nullable = paramBoolean;
/*  275 */     this.precision = paramInt4;
/*  276 */     this.scale = paramInt5;
/*  277 */     this.flags = paramInt3;
/*  278 */     this.contflag = paramInt6;
/*  279 */     this.total_elems = paramInt7;
/*  280 */     this.formOfUse = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initForDescribe(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, String paramString) throws SQLException {
/*  289 */     this.describeTypeName = paramString;
/*  290 */     this.describeOtype = null;
/*      */     
/*  292 */     initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleInputStream initForNewRow() throws SQLException {
/*  305 */     unimpl("initForNewRow");
/*  306 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int useForDataAccessIfPossible(int paramInt1, int paramInt2, int paramInt3, String paramString) throws SQLException {
/*  321 */     byte b = 3;
/*  322 */     int i = 0;
/*  323 */     int j = 0;
/*      */     
/*  325 */     if (this.internalType != 0)
/*      */     {
/*  327 */       if (this.internalType != paramInt1) {
/*  328 */         b = 0;
/*  329 */       } else if (this.rowSpaceIndicator != null) {
/*      */         
/*  331 */         i = this.byteLength;
/*  332 */         j = this.charLength;
/*      */       } 
/*      */     }
/*      */     
/*  336 */     if (b == 3) {
/*      */       
/*  338 */       initForDataAccess(paramInt2, paramInt3, paramString);
/*      */       
/*  340 */       if (!this.outBind && i >= this.byteLength && j >= this.charLength)
/*      */       {
/*  342 */         b = 2;
/*      */       }
/*      */     } 
/*  345 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useForDescribeIfPossible(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, String paramString) throws SQLException {
/*  357 */     if (this.externalType == 0 && paramInt1 != this.describeType) {
/*  358 */       return false;
/*      */     }
/*  360 */     initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, paramString);
/*      */ 
/*      */     
/*  363 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFormOfUse(short paramShort) {
/*  372 */     this.formOfUse = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateColumnNumber(int paramInt) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  389 */     return super.toString() + ", statement=" + this.statement + ", outBind=" + this.outBind + ", internalType=" + this.internalType + ", internalTypeMaxLength=" + this.internalTypeMaxLength + ", isStream=" + this.isStream + ", formOfUse=" + this.formOfUse + ", internalOtype=" + this.internalOtype + ", externalType=" + this.externalType + ", internalTypeName=" + this.internalTypeName + ", columnName=" + this.columnName + ", describeType=" + this.describeType + ", describeMaxLength=" + this.describeMaxLength + ", nullable=" + this.nullable + ", precision=" + this.precision + ", scale=" + this.scale + ", flags=" + this.flags + ", contflag=" + this.contflag + ", total_elems=" + this.total_elems + ", describeOtype=" + this.describeOtype + ", describeTypeName=" + this.describeTypeName + ", rowSpaceByte=" + this.rowSpaceByte + ", rowSpaceChar=" + this.rowSpaceChar + ", rowSpaceIndicator=" + this.rowSpaceIndicator + ", columnIndex=" + this.columnIndex + ", lengthIndex=" + this.lengthIndex + ", indicatorIndex=" + this.indicatorIndex + ", byteLength=" + this.byteLength + ", charLength=" + this.charLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unimpl(String paramString) throws SQLException {
/*  412 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, paramString + " not implemented for " + getClass());
/*      */     
/*  414 */     sQLException.fillInStackTrace();
/*  415 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getBoolean(int paramInt) throws SQLException {
/*  427 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  430 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  431 */       sQLException.fillInStackTrace();
/*  432 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  436 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  437 */       return false;
/*      */     }
/*  439 */     unimpl("getBoolean");
/*      */     
/*  441 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte getByte(int paramInt) throws SQLException {
/*  449 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  452 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  453 */       sQLException.fillInStackTrace();
/*  454 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  458 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  459 */       return 0;
/*      */     }
/*  461 */     unimpl("getByte");
/*      */     
/*  463 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  469 */     if (this.rowSpaceMetaData == null) {
/*      */ 
/*      */ 
/*      */       
/*  473 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  474 */       sQLException.fillInStackTrace();
/*  475 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  479 */     byte b = this.rowSpaceMetaData[this.metaDataIndex + 1 * paramInt];
/*      */ 
/*      */     
/*  482 */     if ((b & 0x1) != 0)
/*  483 */       return OracleResultSet.AuthorizationIndicator.UNAUTHORIZED; 
/*  484 */     if (this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED || this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.NONE)
/*      */     {
/*  486 */       return OracleResultSet.AuthorizationIndicator.NONE;
/*      */     }
/*  488 */     return OracleResultSet.AuthorizationIndicator.UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getShort(int paramInt) throws SQLException {
/*  497 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  501 */       sQLException.fillInStackTrace();
/*  502 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  506 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  507 */       return 0;
/*      */     }
/*  509 */     unimpl("getShort");
/*      */     
/*  511 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInt(int paramInt) throws SQLException {
/*  519 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  522 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  523 */       sQLException.fillInStackTrace();
/*  524 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  528 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  529 */       return 0;
/*      */     }
/*  531 */     unimpl("getInt");
/*      */     
/*  533 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getLong(int paramInt) throws SQLException {
/*  541 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  544 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  545 */       sQLException.fillInStackTrace();
/*  546 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  550 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  551 */       return 0L;
/*      */     }
/*  553 */     unimpl("getLong");
/*      */     
/*  555 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float getFloat(int paramInt) throws SQLException {
/*  563 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  566 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  567 */       sQLException.fillInStackTrace();
/*  568 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  572 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  573 */       return 0.0F;
/*      */     }
/*  575 */     unimpl("getFloat");
/*      */ 
/*      */     
/*  578 */     return 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getDouble(int paramInt) throws SQLException {
/*  587 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  590 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  591 */       sQLException.fillInStackTrace();
/*  592 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  596 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  597 */       return 0.0D;
/*      */     }
/*  599 */     unimpl("getDouble");
/*      */     
/*  601 */     return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  609 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  613 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  614 */       sQLException.fillInStackTrace();
/*  615 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  620 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  621 */       return null;
/*      */     }
/*  623 */     unimpl("getBigDecimal");
/*      */ 
/*      */     
/*  626 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  635 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  639 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  640 */       sQLException.fillInStackTrace();
/*  641 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  646 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt1] == -1) {
/*  647 */       return null;
/*      */     }
/*  649 */     unimpl("getBigDecimal");
/*      */ 
/*      */     
/*  652 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/*  670 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt) throws SQLException {
/*  678 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  682 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  683 */       sQLException.fillInStackTrace();
/*  684 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  689 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  690 */       return null;
/*      */     }
/*  692 */     unimpl("getDate");
/*      */ 
/*      */     
/*  695 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  704 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  708 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  709 */       sQLException.fillInStackTrace();
/*  710 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  715 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  716 */       return null;
/*      */     }
/*  718 */     unimpl("getDate");
/*      */ 
/*      */     
/*  721 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt) throws SQLException {
/*  730 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  734 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  735 */       sQLException.fillInStackTrace();
/*  736 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  741 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  742 */       return null;
/*      */     }
/*  744 */     unimpl("getTime");
/*      */ 
/*      */     
/*  747 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  756 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  760 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  761 */       sQLException.fillInStackTrace();
/*  762 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  767 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  768 */       return null;
/*      */     }
/*  770 */     unimpl("getTime");
/*      */ 
/*      */     
/*  773 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt) throws SQLException {
/*  782 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  786 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  787 */       sQLException.fillInStackTrace();
/*  788 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  793 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  794 */       return null;
/*      */     }
/*  796 */     unimpl("getTimestamp");
/*      */ 
/*      */     
/*  799 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/*  808 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  812 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  813 */       sQLException.fillInStackTrace();
/*  814 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  819 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  820 */       return null;
/*      */     }
/*  822 */     unimpl("getTimestamp");
/*      */ 
/*      */     
/*  825 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] privateGetBytes(int paramInt) throws SQLException {
/*  840 */     return getBytes(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBytes(int paramInt) throws SQLException {
/*  852 */     byte[] arrayOfByte = null;
/*      */     
/*  854 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  858 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  859 */       sQLException.fillInStackTrace();
/*  860 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  865 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  867 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*  868 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */       
/*  870 */       arrayOfByte = new byte[s];
/*  871 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*      */     } 
/*      */     
/*  874 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getAsciiStream(int paramInt) throws SQLException {
/*  882 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  886 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  887 */       sQLException.fillInStackTrace();
/*  888 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  893 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  894 */       return null;
/*      */     }
/*  896 */     unimpl("getAsciiStream");
/*      */ 
/*      */     
/*  899 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  908 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  912 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  913 */       sQLException.fillInStackTrace();
/*  914 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  919 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  920 */       return null;
/*      */     }
/*  922 */     unimpl("getUnicodeStream");
/*      */ 
/*      */     
/*  925 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getBinaryStream(int paramInt) throws SQLException {
/*  934 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  938 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  939 */       sQLException.fillInStackTrace();
/*  940 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  945 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  946 */       return null;
/*      */     }
/*  948 */     unimpl("getBinaryStream");
/*      */ 
/*      */     
/*  951 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*  960 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  964 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  965 */       sQLException.fillInStackTrace();
/*  966 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  971 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  972 */       return null;
/*      */     }
/*  974 */     unimpl("getObject");
/*      */ 
/*      */     
/*  977 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSet getCursor(int paramInt) throws SQLException {
/*  987 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  988 */     sQLException.fillInStackTrace();
/*  989 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum getOracleObject(int paramInt) throws SQLException {
/*  998 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1002 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1003 */       sQLException.fillInStackTrace();
/* 1004 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1009 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1010 */       return null;
/*      */     }
/* 1012 */     unimpl("getOracleObject");
/*      */ 
/*      */     
/* 1015 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ROWID getROWID(int paramInt) throws SQLException {
/* 1024 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1028 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1029 */       sQLException1.fillInStackTrace();
/* 1030 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1035 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1036 */       return null;
/*      */     }
/*      */     
/* 1039 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1040 */     sQLException.fillInStackTrace();
/* 1041 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1050 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1054 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1055 */       sQLException.fillInStackTrace();
/* 1056 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1061 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1062 */       return null;
/*      */     }
/* 1064 */     unimpl("getNUMBER");
/*      */ 
/*      */     
/* 1067 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DATE getDATE(int paramInt) throws SQLException {
/* 1076 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1080 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1081 */       sQLException.fillInStackTrace();
/* 1082 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1087 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1088 */       return null;
/*      */     }
/* 1090 */     unimpl("getDATE");
/*      */ 
/*      */     
/* 1093 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY getARRAY(int paramInt) throws SQLException {
/* 1102 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1106 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1107 */       sQLException.fillInStackTrace();
/* 1108 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1113 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1114 */       return null;
/*      */     }
/* 1116 */     unimpl("getARRAY");
/*      */ 
/*      */     
/* 1119 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1128 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1132 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1133 */       sQLException.fillInStackTrace();
/* 1134 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1139 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1140 */       return null;
/*      */     }
/* 1142 */     unimpl("getSTRUCT");
/*      */ 
/*      */     
/* 1145 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1154 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1159 */       sQLException.fillInStackTrace();
/* 1160 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1165 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1166 */       return null;
/*      */     }
/* 1168 */     unimpl("getOPAQUE");
/*      */ 
/*      */     
/* 1171 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   REF getREF(int paramInt) throws SQLException {
/* 1180 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1185 */       sQLException.fillInStackTrace();
/* 1186 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1191 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1192 */       return null;
/*      */     }
/* 1194 */     unimpl("getREF");
/*      */ 
/*      */     
/* 1197 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CHAR getCHAR(int paramInt) throws SQLException {
/* 1206 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1210 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1211 */       sQLException.fillInStackTrace();
/* 1212 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1217 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1218 */       return null;
/*      */     }
/* 1220 */     unimpl("getCHAR");
/*      */ 
/*      */     
/* 1223 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RAW getRAW(int paramInt) throws SQLException {
/* 1232 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1236 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1237 */       sQLException.fillInStackTrace();
/* 1238 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1243 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1244 */       return null;
/*      */     }
/* 1246 */     unimpl("getRAW");
/*      */ 
/*      */     
/* 1249 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BLOB getBLOB(int paramInt) throws SQLException {
/* 1258 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1262 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1263 */       sQLException.fillInStackTrace();
/* 1264 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1269 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1270 */       return null;
/*      */     }
/* 1272 */     unimpl("getBLOB");
/*      */ 
/*      */     
/* 1275 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CLOB getCLOB(int paramInt) throws SQLException {
/* 1284 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1288 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1289 */       sQLException.fillInStackTrace();
/* 1290 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1295 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1296 */       return null;
/*      */     }
/* 1298 */     unimpl("getCLOB");
/*      */ 
/*      */     
/* 1301 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BFILE getBFILE(int paramInt) throws SQLException {
/* 1310 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1314 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1315 */       sQLException.fillInStackTrace();
/* 1316 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1321 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1322 */       return null;
/*      */     }
/* 1324 */     unimpl("getBFILE");
/*      */ 
/*      */     
/* 1327 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1337 */     Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1342 */     return paramCustomDatumFactory.create(datum, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1350 */     Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1355 */     return paramORADataFactory.create(datum, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1362 */     Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1367 */     Object object = datum.toJdbc();
/* 1368 */     return paramOracleDataFactory.create(object, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1376 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1380 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1381 */       sQLException.fillInStackTrace();
/* 1382 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1387 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1388 */       return null;
/*      */     }
/* 1390 */     unimpl("getObject");
/*      */ 
/*      */     
/* 1393 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 1402 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1406 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1407 */       sQLException.fillInStackTrace();
/* 1408 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1413 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1414 */       return null;
/*      */     }
/* 1416 */     unimpl("getCharacterStream");
/*      */ 
/*      */     
/* 1419 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1428 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1432 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1433 */       sQLException.fillInStackTrace();
/* 1434 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1439 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1440 */       return null;
/*      */     }
/* 1442 */     unimpl("getINTERVALYM");
/*      */ 
/*      */     
/* 1445 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1454 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1458 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1459 */       sQLException.fillInStackTrace();
/* 1460 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1465 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1466 */       return null;
/*      */     }
/* 1468 */     unimpl("getINTERVALDS");
/*      */ 
/*      */     
/* 1471 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1480 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1484 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1485 */       sQLException.fillInStackTrace();
/* 1486 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1491 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1492 */       return null;
/*      */     }
/* 1494 */     unimpl("getTIMESTAMP");
/*      */ 
/*      */     
/* 1497 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1506 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1511 */       sQLException.fillInStackTrace();
/* 1512 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1517 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1518 */       return null;
/*      */     }
/* 1520 */     unimpl("getTIMESTAMPTZ");
/*      */ 
/*      */     
/* 1523 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1532 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1536 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1537 */       sQLException.fillInStackTrace();
/* 1538 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1543 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1544 */       return null;
/*      */     }
/* 1546 */     unimpl("getTIMESTAMPLTZ");
/*      */ 
/*      */     
/* 1549 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   URL getURL(int paramInt) throws SQLException {
/* 1558 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1562 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1563 */       sQLException.fillInStackTrace();
/* 1564 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1569 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1570 */       return null;
/*      */     }
/* 1572 */     unimpl("getURL");
/*      */ 
/*      */     
/* 1575 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 1584 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1589 */       sQLException.fillInStackTrace();
/* 1590 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1595 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1596 */       return null;
/*      */     }
/* 1598 */     unimpl("getOraclePlsqlIndexTable");
/*      */ 
/*      */     
/* 1601 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NClob getNClob(int paramInt) throws SQLException {
/* 1612 */     if (this.formOfUse != 2) {
/*      */       
/* 1614 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.valueOf(this.columnIndex));
/* 1615 */       sQLException.fillInStackTrace();
/* 1616 */       throw sQLException;
/*      */     } 
/*      */     
/* 1619 */     return (NClob)getCLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getNString(int paramInt) throws SQLException {
/* 1626 */     return getString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLXML getSQLXML(int paramInt) throws SQLException {
/* 1633 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/* 1636 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1637 */       sQLException.fillInStackTrace();
/* 1638 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1642 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1643 */       return null;
/*      */     }
/* 1645 */     unimpl("getSQLXML");
/*      */     
/* 1647 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1655 */     return getCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNull(int paramInt) throws SQLException {
/* 1664 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1668 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1669 */       sQLException.fillInStackTrace();
/* 1670 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1675 */     return (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setNull(int paramInt, boolean paramBoolean) throws SQLException {
/* 1683 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1687 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1688 */       sQLException.fillInStackTrace();
/* 1689 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1694 */     this.rowSpaceIndicator[this.indicatorIndex + paramInt] = (short)(paramBoolean ? -1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetchNextColumns() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void calculateSizeTmpByteArray() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 1726 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
/* 1727 */     sQLException.fillInStackTrace();
/* 1728 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copyRow() throws SQLException, IOException {
/* 1739 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
/* 1740 */     sQLException.fillInStackTrace();
/* 1741 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readStream(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 1750 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
/* 1751 */     sQLException.fillInStackTrace();
/* 1752 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initMetadata() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setDisplaySize(int paramInt) throws SQLException {
/* 1769 */     this.describeMaxLength = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1774 */   int lastRowProcessed = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isUseLess = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1788 */   int physicalColumnIndex = -2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNullByDescribe = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1820 */     return this.statement.getConnectionDuringExceptionHandling();
/*      */   }
/*      */ 
/*      */   
/* 1824 */   static final byte[] NULL_DATA_BYTES = new byte[] { 2, 3, 5, 7, 11, 13, 17, 19 };
/*      */ 
/*      */ 
/*      */   
/*      */   long updateChecksum(long paramLong, int paramInt) throws SQLException {
/* 1829 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*      */       
/* 1831 */       paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1837 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 1838 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */       
/* 1840 */       paramLong = CRC64.updateChecksum(paramLong, this.rowSpaceByte, i, s);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1846 */     return paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1851 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\Accessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */