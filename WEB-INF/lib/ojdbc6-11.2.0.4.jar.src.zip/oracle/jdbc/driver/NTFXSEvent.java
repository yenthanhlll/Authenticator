/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValueLong;
/*     */ import oracle.jdbc.internal.XSEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFXSEvent
/*     */   extends XSEvent
/*     */ {
/*     */   private final byte[] sid_kpuzxsss;
/*     */   private final KeywordValueLongI[] sess_kpuzxsss;
/*     */   private final int flg_kpuzxsss;
/*     */   
/*     */   NTFXSEvent(T4CConnection paramT4CConnection) throws SQLException, IOException {
/*  49 */     super(paramT4CConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     T4CMAREngine t4CMAREngine = paramT4CConnection.getMarshalEngine();
/*     */     
/*  65 */     this.sid_kpuzxsss = t4CMAREngine.unmarshalDALC();
/*  66 */     int i = (int)t4CMAREngine.unmarshalUB4();
/*  67 */     byte b = (byte)t4CMAREngine.unmarshalUB1();
/*  68 */     this.sess_kpuzxsss = new KeywordValueLongI[i];
/*  69 */     for (byte b1 = 0; b1 < i; b1++)
/*     */     {
/*  71 */       this.sess_kpuzxsss[b1] = KeywordValueLongI.unmarshal(t4CMAREngine);
/*     */     }
/*  73 */     this.flg_kpuzxsss = (int)t4CMAREngine.unmarshalUB4();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getSessionId() {
/*  79 */     return this.sid_kpuzxsss;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeywordValueLong[] getDetails() {
/*  86 */     return (KeywordValueLong[])this.sess_kpuzxsss;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/*  93 */     return this.flg_kpuzxsss;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 100 */     StringBuffer stringBuffer = new StringBuffer();
/* 101 */     stringBuffer.append("sid_kpuzxsss  : " + NTFAQEvent.byteBufferToHexString(this.sid_kpuzxsss, 50) + "\n");
/* 102 */     stringBuffer.append("sess_kpuzxsss : \n");
/* 103 */     stringBuffer.append("  size : " + this.sess_kpuzxsss.length + "\n");
/* 104 */     for (byte b = 0; b < this.sess_kpuzxsss.length; b++) {
/*     */       
/* 106 */       stringBuffer.append("  sess_kpuzxsss #" + b + " : \n");
/* 107 */       if (this.sess_kpuzxsss[b] == null) {
/* 108 */         stringBuffer.append("null\n");
/*     */       } else {
/* 110 */         stringBuffer.append(this.sess_kpuzxsss[b].toString());
/*     */       } 
/* 112 */     }  stringBuffer.append("flg_kpuzxsss  : " + this.flg_kpuzxsss + "\n");
/* 113 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 118 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\NTFXSEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */