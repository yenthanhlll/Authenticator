/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleClobInputStream
/*     */   extends OracleBufferedStream
/*     */ {
/*     */   protected long lobOffset;
/*     */   protected CLOB clob;
/*     */   protected long markedByte;
/*     */   protected boolean endOfStream;
/*     */   protected char[] charBuf;
/*     */   
/*     */   public OracleClobInputStream(CLOB paramCLOB) throws SQLException {
/*  37 */     this(paramCLOB, ((PhysicalConnection)paramCLOB.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobInputStream(CLOB paramCLOB, int paramInt) throws SQLException {
/*  52 */     this(paramCLOB, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/*  66 */     super(paramInt);
/*     */ 
/*     */     
/*  69 */     if (paramCLOB == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  71 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  74 */     this.lobOffset = paramLong;
/*  75 */     this.clob = paramCLOB;
/*  76 */     this.markedByte = -1L;
/*  77 */     this.endOfStream = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes(int paramInt) throws IOException {
/*  90 */     ensureOpen();
/*     */     
/*  92 */     if (this.pos >= this.count) {
/*     */       
/*  94 */       if (!this.endOfStream) {
/*     */         
/*     */         try {
/*     */           
/*  98 */           if (paramInt > this.currentBufferSize) {
/*     */             
/* 100 */             this.currentBufferSize = Math.max(paramInt, this.initialBufferSize);
/* 101 */             PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
/*     */             
/* 103 */             synchronized (physicalConnection) {
/* 104 */               this.resizableBuffer = physicalConnection.getByteBuffer(this.currentBufferSize);
/* 105 */               this.charBuf = physicalConnection.getCharBuffer(this.currentBufferSize);
/*     */             } 
/*     */           } 
/* 108 */           this.count = this.clob.getChars(this.lobOffset, this.currentBufferSize, this.charBuf);
/*     */ 
/*     */           
/* 111 */           for (byte b = 0; b < this.count; b++) {
/* 112 */             this.resizableBuffer[b] = (byte)this.charBuf[b];
/*     */           }
/* 114 */           if (this.count < this.currentBufferSize) {
/* 115 */             this.endOfStream = true;
/*     */           }
/* 117 */           if (this.count > 0)
/*     */           {
/* 119 */             this.pos = 0;
/* 120 */             this.lobOffset += this.count;
/*     */             
/* 122 */             return true;
/*     */           }
/*     */         
/* 125 */         } catch (SQLException sQLException) {
/*     */ 
/*     */           
/* 128 */           IOException iOException = DatabaseError.createIOException(sQLException);
/* 129 */           iOException.fillInStackTrace();
/* 130 */           throw iOException;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 135 */       return false;
/*     */     } 
/*     */     
/* 138 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void ensureOpen() throws IOException {
/*     */     try {
/* 153 */       if (this.closed)
/*     */       {
/* 155 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 156 */         sQLException.fillInStackTrace();
/* 157 */         throw sQLException;
/*     */       }
/*     */     
/* 160 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 163 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 164 */       iOException.fillInStackTrace();
/* 165 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 181 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int paramInt) {
/* 199 */     if (paramInt < 0) {
/* 200 */       throw new IllegalArgumentException(DatabaseError.findMessage(196, null));
/*     */     }
/* 202 */     this.markedByte = this.lobOffset - this.count + this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markInternal(int paramInt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 218 */     ensureOpen();
/*     */     
/* 220 */     if (this.markedByte < 0L) {
/* 221 */       throw new IOException(DatabaseError.findMessage(195, null));
/*     */     }
/* 223 */     this.lobOffset = this.markedByte;
/* 224 */     this.pos = this.count;
/* 225 */     this.endOfStream = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long paramLong) throws IOException {
/* 244 */     ensureOpen();
/*     */     
/* 246 */     long l = 0L;
/*     */     
/* 248 */     if ((this.count - this.pos) >= paramLong) {
/*     */       
/* 250 */       this.pos = (int)(this.pos + paramLong);
/* 251 */       l += paramLong;
/*     */     }
/*     */     else {
/*     */       
/* 255 */       l += (this.count - this.pos);
/* 256 */       this.pos = this.count;
/*     */ 
/*     */       
/*     */       try {
/* 260 */         long l1 = 0L;
/*     */         
/* 262 */         l1 = this.clob.length() - this.lobOffset + 1L;
/*     */         
/* 264 */         if (l1 >= paramLong - l)
/*     */         {
/* 266 */           this.lobOffset += paramLong - l;
/* 267 */           l += paramLong - l;
/*     */         }
/*     */         else
/*     */         {
/* 271 */           this.lobOffset += l1;
/* 272 */           l += l1;
/*     */         }
/*     */       
/* 275 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 278 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 279 */         iOException.fillInStackTrace();
/* 280 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 285 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 293 */     if (this.closed) {
/*     */       return;
/*     */     }
/*     */     try {
/* 297 */       super.close();
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 302 */         PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
/*     */         
/* 304 */         synchronized (physicalConnection) {
/*     */           
/* 306 */           if (this.charBuf != null) {
/*     */             
/* 308 */             physicalConnection.cacheBuffer(this.charBuf);
/* 309 */             this.charBuf = null;
/*     */           } 
/* 311 */           if (this.resizableBuffer != null) {
/*     */             
/* 313 */             physicalConnection.cacheBuffer(this.resizableBuffer);
/* 314 */             this.resizableBuffer = null;
/*     */           } 
/* 316 */           this.currentBufferSize = 0;
/*     */         } 
/* 318 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 321 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 322 */         iOException.fillInStackTrace();
/* 323 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 346 */       return this.clob.getInternalConnection();
/*     */     }
/* 348 */     catch (Exception exception) {
/*     */       
/* 350 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 357 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\OracleClobInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */