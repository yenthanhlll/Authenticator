/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.BindException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFManager
/*     */ {
/*  54 */   private Hashtable<Integer, NTFListener> nsListeners = new Hashtable<Integer, NTFListener>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private Hashtable<Integer, NTFRegistration> ntfRegistrations = new Hashtable<Integer, NTFRegistration>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private byte[] listOfJdbcRegId = new byte[20];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean listenOnPortT4C(int[] paramArrayOfint, boolean paramBoolean) throws SQLException {
/* 104 */     int i = paramArrayOfint[0];
/* 105 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 109 */     while (this.nsListeners.get(Integer.valueOf(i)) == null) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 117 */         ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
/* 118 */         serverSocketChannel.configureBlocking(false);
/*     */         
/* 120 */         ServerSocket serverSocket = serverSocketChannel.socket();
/*     */         
/* 122 */         InetSocketAddress inetSocketAddress = new InetSocketAddress(i);
/*     */ 
/*     */         
/*     */         try {
/* 126 */           serverSocket.bind(inetSocketAddress);
/*     */           
/* 128 */           bool = true;
/* 129 */           NTFListener nTFListener = new NTFListener(this, serverSocketChannel, i);
/* 130 */           this.nsListeners.put(Integer.valueOf(i), nTFListener);
/* 131 */           nTFListener.start();
/*     */           
/*     */           break;
/* 134 */         } catch (BindException bindException) {
/*     */           
/* 136 */           if (!paramBoolean) {
/*     */             
/* 138 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
/* 139 */             sQLException.fillInStackTrace();
/* 140 */             throw sQLException;
/*     */           } 
/*     */           
/* 143 */           i++;
/*     */         }
/* 145 */         catch (IOException iOException) {
/*     */           
/* 147 */           if (!paramBoolean) {
/*     */             
/* 149 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
/* 150 */             sQLException.fillInStackTrace();
/* 151 */             throw sQLException;
/*     */           } 
/*     */           
/* 154 */           i++;
/*     */         }
/*     */       
/* 157 */       } catch (IOException iOException) {
/*     */ 
/*     */         
/* 160 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 161 */         sQLException.fillInStackTrace();
/* 162 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     paramArrayOfint[0] = i;
/* 167 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized int getNextJdbcRegId() {
/* 178 */     byte b = 1;
/* 179 */     for (; b < this.listOfJdbcRegId.length; b++) {
/*     */       
/* 181 */       if (this.listOfJdbcRegId[b] == 0)
/*     */         break; 
/*     */     } 
/* 184 */     if (b == this.listOfJdbcRegId.length - 1) {
/*     */       
/* 186 */       byte[] arrayOfByte = new byte[this.listOfJdbcRegId.length * 2];
/* 187 */       System.arraycopy(this.listOfJdbcRegId, 0, arrayOfByte, 0, this.listOfJdbcRegId.length);
/* 188 */       this.listOfJdbcRegId = arrayOfByte;
/*     */     } 
/* 190 */     this.listOfJdbcRegId[b] = 2;
/* 191 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void addRegistration(NTFRegistration paramNTFRegistration) {
/* 201 */     Integer integer = Integer.valueOf(paramNTFRegistration.getJdbcRegId());
/* 202 */     Hashtable<Integer, NTFRegistration> hashtable = (Hashtable)this.ntfRegistrations.clone();
/* 203 */     hashtable.put(integer, paramNTFRegistration);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     this.ntfRegistrations = hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean removeRegistration(NTFRegistration paramNTFRegistration) {
/* 222 */     Integer integer = Integer.valueOf(paramNTFRegistration.getJdbcRegId());
/* 223 */     Hashtable<Integer, NTFRegistration> hashtable = (Hashtable)this.ntfRegistrations.clone();
/* 224 */     Object object = hashtable.remove(integer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     this.ntfRegistrations = hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     boolean bool = false;
/*     */     
/* 238 */     if (object != null)
/* 239 */       bool = true; 
/* 240 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void freeJdbcRegId(int paramInt) {
/* 248 */     if (this.listOfJdbcRegId != null && this.listOfJdbcRegId.length > paramInt) {
/* 249 */       this.listOfJdbcRegId[paramInt] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void cleanListenersT4C(int paramInt) {
/* 268 */     Enumeration<Integer> enumeration = this.ntfRegistrations.keys();
/* 269 */     boolean bool = false;
/* 270 */     while (!bool && enumeration.hasMoreElements()) {
/*     */       
/* 272 */       Object object = enumeration.nextElement();
/* 273 */       NTFRegistration nTFRegistration = this.ntfRegistrations.get(object);
/* 274 */       if (nTFRegistration.getClientTCPPort() == paramInt)
/* 275 */         bool = true; 
/*     */     } 
/* 277 */     if (!bool) {
/*     */       
/* 279 */       NTFListener nTFListener = this.nsListeners.get(Integer.valueOf(paramInt));
/* 280 */       if (nTFListener != null) {
/*     */         
/* 282 */         nTFListener.closeThisListener();
/* 283 */         nTFListener.interrupt();
/* 284 */         this.nsListeners.remove(Integer.valueOf(paramInt));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTFRegistration getRegistration(int paramInt) {
/* 300 */     Integer integer = Integer.valueOf(paramInt);
/*     */     
/* 302 */     Hashtable<Integer, NTFRegistration> hashtable = this.ntfRegistrations;
/* 303 */     return hashtable.get(integer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 319 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 324 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\NTFManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */