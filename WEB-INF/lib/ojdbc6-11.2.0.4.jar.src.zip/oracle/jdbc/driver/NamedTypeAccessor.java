/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.OracleDataFactory;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.JAVA_STRUCT;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamedTypeAccessor
/*     */   extends TypeAccessor
/*     */ {
/*     */   private static final Class xmlType;
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean) throws SQLException {
/*  40 */     init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
/*  41 */     initForDataAccess(paramInt, 0, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString) throws SQLException {
/*  51 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*  52 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*  54 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType) throws SQLException {
/*  64 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*     */     
/*  66 */     this.describeOtype = paramOracleType;
/*     */     
/*  68 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */ 
/*     */     
/*  71 */     this.internalOtype = paramOracleType;
/*     */     
/*  73 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleType otypeFromName(String paramString) throws SQLException {
/*  80 */     if (!this.outBind) {
/*  81 */       return (OracleType)TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)this.statement.connection).getPickler();
/*     */     }
/*  83 */     if (this.externalType == 2003) {
/*  84 */       return (OracleType)ArrayDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeCOLLECTION();
/*     */     }
/*  86 */     if (this.externalType == 2007 || this.externalType == 2009)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       return (OracleType)OpaqueDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getPickler();
/*     */     }
/*     */     
/*  96 */     return (OracleType)StructDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeADT();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 105 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*     */     
/* 107 */     this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 123 */     return getObject(paramInt, this.statement.connection.getTypeMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 139 */     return paramOracleDataFactory.create(getObject(paramInt, this.statement.connection.getTypeMap()), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 149 */     Class<?> clazz = null;
/*     */     try {
/* 151 */       clazz = Class.forName("oracle.xdb.XMLType");
/*     */     }
/* 153 */     catch (Throwable throwable) {}
/* 154 */     xmlType = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 166 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 169 */       sQLException.fillInStackTrace();
/* 170 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       Datum datum;
/*     */ 
/*     */       
/* 180 */       if (this.externalType == 0) {
/*     */         
/* 182 */         Datum datum1 = getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */         
/* 186 */         if (datum1 == null) {
/* 187 */           return null;
/*     */         }
/* 189 */         if (datum1 instanceof STRUCT) {
/* 190 */           return ((STRUCT)datum1).toJdbc(paramMap);
/*     */         }
/* 192 */         if (datum1 instanceof OPAQUE) {
/* 193 */           return ((OPAQUE)datum1).toJdbc(paramMap);
/*     */         }
/*     */ 
/*     */         
/* 197 */         return datum1.toJdbc();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 202 */       switch (this.externalType) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2008:
/* 208 */           paramMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2000:
/*     */         case 2002:
/*     */         case 2003:
/*     */         case 2007:
/* 217 */           datum = getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */           
/* 221 */           if (datum == null) {
/* 222 */             return null;
/*     */           }
/* 224 */           if (datum instanceof STRUCT) {
/* 225 */             return ((STRUCT)datum).toJdbc(paramMap);
/*     */           }
/* 227 */           return datum.toJdbc();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2009:
/* 233 */           datum = getOracleObject(paramInt);
/* 234 */           if (datum == null) {
/* 235 */             return null;
/*     */           }
/*     */           try {
/* 238 */             return datum;
/*     */           }
/* 240 */           catch (ClassCastException classCastException) {
/*     */ 
/*     */             
/* 243 */             SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 244 */             sQLException1.fillInStackTrace();
/* 245 */             throw sQLException1;
/*     */           } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 252 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 253 */       sQLException.fillInStackTrace();
/* 254 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/*     */     STRUCT sTRUCT;
/*     */     OPAQUE oPAQUE;
/* 277 */     ARRAY aRRAY = null;
/*     */ 
/*     */     
/* 280 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 282 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 283 */       sQLException1.fillInStackTrace();
/* 284 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 291 */     byte[] arrayOfByte = pickledBytes(paramInt);
/*     */     
/* 293 */     if (arrayOfByte == null || arrayOfByte.length == 0)
/*     */     {
/* 295 */       return null;
/*     */     }
/*     */     
/* 298 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 299 */     OracleTypeADT oracleTypeADT = (OracleTypeADT)this.internalOtype;
/* 300 */     TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(oracleTypeADT.getFullName(), (OracleConnection)physicalConnection, arrayOfByte, 0L);
/*     */ 
/*     */     
/* 303 */     switch (typeDescriptor.getTypeCode()) {
/*     */ 
/*     */       
/*     */       case 2003:
/* 307 */         aRRAY = new ARRAY((ArrayDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 348 */         return (Datum)aRRAY;case 2002: return (Datum)new STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);case 2009: oPAQUE = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection)); return (Datum)oPAQUE;case 2007: oPAQUE = new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection); return (Datum)oPAQUE;
/*     */       case 2008:
/*     */         return (Datum)new JAVA_STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ARRAY getARRAY(int paramInt) throws SQLException {
/* 364 */     return (ARRAY)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 380 */     return (STRUCT)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 396 */     return (OPAQUE)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isNull(int paramInt) throws SQLException {
/* 403 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 407 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 408 */       sQLException.fillInStackTrace();
/* 409 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 414 */     byte[] arrayOfByte = pickledBytes(paramInt);
/* 415 */     return (arrayOfByte == null || arrayOfByte.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLXML getSQLXML(int paramInt) throws SQLException {
/*     */     try {
/* 431 */       OPAQUE oPAQUE = (OPAQUE)getOracleObject(paramInt);
/* 432 */       if (oPAQUE == null) return null; 
/* 433 */       return (SQLXML)oPAQUE;
/*     */     }
/* 435 */     catch (ClassCastException classCastException) {
/*     */       
/* 437 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 438 */       sQLException.fillInStackTrace();
/* 439 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 448 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\NamedTypeAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */