package oracle.jdbc.driver;

public interface DiagnosabilityMXBean {
  boolean stateManageable();
  
  boolean statisticsProvider();
  
  boolean getLoggingEnabled();
  
  void setLoggingEnabled(boolean paramBoolean);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\DiagnosabilityMXBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */