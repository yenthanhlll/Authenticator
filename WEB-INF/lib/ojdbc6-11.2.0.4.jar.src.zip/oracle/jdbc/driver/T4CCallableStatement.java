/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CCallableStatement
/*      */   extends OracleCallableStatement
/*      */ {
/*      */   T4CCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   29 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*   31 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*   32 */     this.nbPostPonedColumns = new int[1];
/*   33 */     this.nbPostPonedColumns[0] = 0;
/*   34 */     this.indexOfPostPonedColumn = new int[1][3];
/*      */     
/*   36 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   37 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   38 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   39 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   45 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   65 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   66 */       this.oacdefSent = null;
/*      */     }
/*   68 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.doOall8");
/*      */     
/*   70 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   74 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   75 */       sQLException.fillInStackTrace();
/*   76 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   80 */     if (paramBoolean3) {
/*   81 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   83 */     int i = this.numberOfDefinePositions;
/*      */     
/*   85 */     if (this.sqlKind.isDML()) {
/*   86 */       i = 0;
/*      */     }
/*      */     
/*   89 */     if (this.accessors != null)
/*   90 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   91 */         if (this.accessors[b] != null)
/*   92 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   93 */       }   if (this.outBindAccessors != null)
/*   94 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   95 */         if (this.outBindAccessors[b] != null)
/*   96 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*   97 */       }   if (this.returnParamAccessors != null) {
/*   98 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*   99 */         if (this.returnParamAccessors[b] != null) {
/*  100 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  107 */     if (this.bindIndicators != null) {
/*      */       
/*  109 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  112 */       int k = 0;
/*      */       
/*  114 */       if (this.ibtBindChars != null) {
/*  115 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  117 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  119 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  123 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  127 */         if (n != 0) {
/*      */ 
/*      */           
/*  130 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  134 */           if (i1 == 2) {
/*      */             
/*  136 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  141 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  147 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  149 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  151 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  153 */         this.tmpBindsByteArray = null;
/*  154 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  166 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  171 */     int[] arrayOfInt1 = this.definedColumnType;
/*  172 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  173 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  179 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  184 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  185 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  186 */       arrayOfInt1[0] = -8;
/*  187 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  188 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  189 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  190 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  196 */     allocateTmpByteArray();
/*      */     
/*  198 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  200 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  205 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  217 */       int j = t4C8Oall.getCursorId();
/*  218 */       if (j != 0) {
/*  219 */         this.cursorId = j;
/*      */       }
/*  221 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  223 */     catch (SQLException sQLException) {
/*      */       
/*  225 */       int j = t4C8Oall.getCursorId();
/*  226 */       if (j != 0) {
/*  227 */         this.cursorId = j;
/*      */       }
/*  229 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  232 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  237 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  247 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  250 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  252 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  256 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  268 */     super.releaseBuffers();
/*  269 */     this.tmpByteArray = null;
/*  270 */     this.tmpBindsByteArray = null;
/*      */     
/*  272 */     this.t4Connection.all8.bindChars = null;
/*  273 */     this.t4Connection.all8.bindBytes = null;
/*  274 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  281 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  294 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  305 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  313 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  315 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     if (paramInt1 < 1) {
/*      */       
/*  323 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  324 */       sQLException.fillInStackTrace();
/*  325 */       throw sQLException;
/*      */     } 
/*  327 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  331 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  337 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  343 */     else if (paramInt3 < 0) {
/*      */       
/*  345 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  346 */       sQLException.fillInStackTrace();
/*  347 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  351 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  353 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  354 */       sQLException.fillInStackTrace();
/*  355 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  362 */     int i = paramInt1 - 1;
/*      */     
/*  364 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  366 */       if (this.definedColumnType == null) {
/*      */         
/*  368 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  380 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  382 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  385 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  391 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  393 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  395 */       if (this.definedColumnSize == null) {
/*  396 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  399 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  401 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  404 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  408 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  410 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  412 */       if (this.definedColumnFormOfUse == null) {
/*  413 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  416 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  418 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  421 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  425 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  427 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  429 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  434 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  438 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  444 */           this.needToPrepareDefineBuffer = true;
/*  445 */           this.columnsDefinedByUser = true;
/*      */           
/*  447 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  448 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  457 */     synchronized (this.connection) {
/*      */       
/*  459 */       super.clearDefines();
/*  460 */       this.definedColumnType = null;
/*  461 */       this.definedColumnSize = null;
/*  462 */       this.definedColumnFormOfUse = null;
/*  463 */       this.t4Connection.all8.definesAccessors = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  481 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  510 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  519 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  520 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  521 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  523 */       int m = bool ? this.accessors.length : 1;
/*  524 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  525 */         m += bool ? -1 : 1) {
/*      */         
/*  527 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  528 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  529 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  530 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  537 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  538 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  539 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  546 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  553 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  563 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  583 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  585 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  589 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  595 */         if (!paramBoolean) {
/*      */           
/*  597 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  605 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  611 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  617 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  623 */         if (!paramBoolean) {
/*      */           
/*  625 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  633 */         if (paramBoolean && paramString != null) {
/*      */           
/*  635 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  636 */           sQLException1.fillInStackTrace();
/*  637 */           throw sQLException1;
/*      */         } 
/*      */         
/*  640 */         if (paramBoolean) {
/*  641 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  644 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  650 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  656 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  662 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  668 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  672 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  675 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  682 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  688 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  694 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  700 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  706 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  712 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  715 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  720 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  723 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  730 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  736 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  742 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  748 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  754 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  770 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  771 */         sQLException.fillInStackTrace();
/*  772 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  776 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  803 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  806 */       this.connection.open(this);
/*  807 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  813 */       this.t4Connection.needLine();
/*  814 */       this.t4Connection.sendPiggyBackedMessages();
/*  815 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  816 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  818 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  820 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  821 */         this.accessors[b].initMetadata();
/*      */       }
/*  823 */     } catch (IOException iOException) {
/*      */       
/*  825 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  828 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  829 */       sQLException.fillInStackTrace();
/*  830 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  834 */     this.describedWithNames = true;
/*  835 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  870 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  873 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  879 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  883 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  886 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  889 */       throw sQLException;
/*      */     }
/*  891 */     catch (IOException iOException) {
/*      */       
/*  893 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  895 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  896 */       sQLException.fillInStackTrace();
/*  897 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  902 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  903 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  906 */     this.needToParse = false;
/*      */ 
/*      */     
/*  909 */     if (this.connection.calculateChecksum) {
/*  910 */       if (this.validRows > 0) {
/*  911 */         calculateCheckSum();
/*  912 */       } else if (this.rowsProcessed > 0) {
/*  913 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  915 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  925 */     if (this.definedColumnType == null) {
/*  926 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  928 */     this.aFetchWasDoneDuringDescribe = false;
/*  929 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  931 */       this.aFetchWasDoneDuringDescribe = true;
/*  932 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  936 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  937 */       this.accessors[b].initMetadata();
/*      */     }
/*  939 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  981 */         boolean bool = false;
/*  982 */         if (this.columnsDefinedByUser) {
/*  983 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1003 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1011 */           boolean bool1 = false;
/* 1012 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1013 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1015 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1020 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1021 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1027 */               bool1 = true;
/* 1028 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1029 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1033 */           if (bool1) {
/*      */             
/* 1035 */             this.definedColumnType = arrayOfInt1;
/* 1036 */             this.definedColumnSize = arrayOfInt2;
/* 1037 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1043 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1045 */         this.needToParse = false;
/* 1046 */         if (bool) {
/* 1047 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1051 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1054 */     } catch (SQLException sQLException) {
/*      */       
/* 1056 */       throw sQLException;
/*      */     }
/* 1058 */     catch (IOException iOException) {
/*      */       
/* 1060 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1061 */       calculateCheckSum();
/*      */       
/* 1063 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1064 */       sQLException.fillInStackTrace();
/* 1065 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1092 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1096 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1100 */           this.nextStream.close();
/*      */         }
/* 1102 */         catch (IOException iOException) {
/*      */           
/* 1104 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1106 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1107 */           sQLException.fillInStackTrace();
/* 1108 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1112 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1118 */       doOall8(false, false, true, false, false);
/*      */       
/* 1120 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1122 */     catch (IOException iOException) {
/*      */       
/* 1124 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1126 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1127 */       sQLException.fillInStackTrace();
/* 1128 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1134 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1149 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1151 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1153 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1156 */     } catch (IOException iOException) {
/*      */       
/* 1158 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1160 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1161 */       sQLException.fillInStackTrace();
/* 1162 */       throw sQLException;
/*      */     
/*      */     }
/* 1165 */     catch (SQLException sQLException) {
/*      */       
/* 1167 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1170 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1175 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1199 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.do_close");
/*      */     
/* 1201 */     if (this.cursorId != 0) {
/* 1202 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1205 */     this.tmpByteArray = null;
/* 1206 */     this.tmpBindsByteArray = null;
/* 1207 */     this.definedColumnType = null;
/* 1208 */     this.definedColumnSize = null;
/* 1209 */     this.definedColumnFormOfUse = null;
/* 1210 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1230 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.closeQuery");
/*      */     
/* 1232 */     if (this.streamList != null)
/*      */     {
/* 1234 */       while (this.nextStream != null) {
/*      */         try {
/* 1236 */           this.nextStream.close();
/*      */         }
/* 1238 */         catch (IOException iOException) {
/* 1239 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1241 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1242 */           sQLException.fillInStackTrace();
/* 1243 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1247 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1260 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1263 */       this.currentRowCharLens[paramInt] = 1;
/* 1264 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1267 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
/* 1281 */     return new T4CPlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1291 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */