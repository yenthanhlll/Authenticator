/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFAQEvent
/*     */   extends AQNotificationEvent
/*     */ {
/*     */   private String registrationString;
/*     */   private int namespace;
/*     */   private byte[] payload;
/*  50 */   private String queueName = null;
/*  51 */   private byte[] messageId = null;
/*  52 */   private String consumerName = null;
/*     */   private NTFConnection conn;
/*     */   private AQMessagePropertiesI msgProp;
/*  55 */   private AQNotificationEvent.EventType eventType = AQNotificationEvent.EventType.REGULAR;
/*  56 */   private AQNotificationEvent.AdditionalEventType additionalEventType = AQNotificationEvent.AdditionalEventType.NONE;
/*     */   
/*     */   private ByteBuffer dataBuffer;
/*     */   
/*     */   private boolean isReady = false;
/*     */   
/*     */   private short databaseVersion;
/*     */   
/*     */   NTFAQEvent(NTFConnection paramNTFConnection, short paramShort) throws IOException, InterruptedException {
/*  65 */     super(paramNTFConnection);
/*     */     
/*  67 */     this.conn = paramNTFConnection;
/*  68 */     int i = this.conn.readInt();
/*  69 */     byte[] arrayOfByte = new byte[i];
/*  70 */     this.conn.readBuffer(arrayOfByte, 0, i);
/*  71 */     this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
/*  72 */     this.databaseVersion = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initEvent() throws SQLException {
/*  79 */     byte b1 = this.dataBuffer.get();
/*  80 */     int i = this.dataBuffer.getInt();
/*  81 */     byte[] arrayOfByte1 = new byte[i];
/*  82 */     this.dataBuffer.get(arrayOfByte1, 0, i);
/*  83 */     this.registrationString = this.conn.charset.toString(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */     
/*  87 */     byte b2 = this.dataBuffer.get();
/*  88 */     int j = this.dataBuffer.getInt();
/*  89 */     byte[] arrayOfByte2 = new byte[j];
/*  90 */     this.dataBuffer.get(arrayOfByte2, 0, j);
/*  91 */     this.namespace = arrayOfByte2[0];
/*     */ 
/*     */     
/*  94 */     byte b3 = this.dataBuffer.get();
/*  95 */     int k = this.dataBuffer.getInt();
/*  96 */     if (k > 0) {
/*     */       
/*  98 */       this.payload = new byte[k];
/*  99 */       this.dataBuffer.get(this.payload, 0, k);
/*     */     } else {
/*     */       
/* 102 */       this.payload = null;
/*     */     } 
/* 104 */     if (this.dataBuffer.hasRemaining()) {
/*     */       
/* 106 */       int m = 0;
/* 107 */       if (this.databaseVersion >= 10200) {
/*     */ 
/*     */         
/* 110 */         byte b = this.dataBuffer.get();
/* 111 */         int i23 = this.dataBuffer.getInt();
/* 112 */         m = this.dataBuffer.getInt();
/*     */       } 
/*     */ 
/*     */       
/* 116 */       byte b4 = this.dataBuffer.get();
/* 117 */       int n = this.dataBuffer.getInt();
/* 118 */       byte[] arrayOfByte3 = new byte[n];
/* 119 */       this.dataBuffer.get(arrayOfByte3, 0, n);
/* 120 */       this.queueName = this.conn.charset.toString(arrayOfByte3, 0, n);
/*     */ 
/*     */ 
/*     */       
/* 124 */       byte b5 = this.dataBuffer.get();
/* 125 */       int i1 = this.dataBuffer.getInt();
/* 126 */       this.messageId = new byte[i1];
/* 127 */       this.dataBuffer.get(this.messageId, 0, i1);
/*     */ 
/*     */       
/* 130 */       byte b6 = this.dataBuffer.get();
/* 131 */       int i2 = this.dataBuffer.getInt();
/* 132 */       byte[] arrayOfByte4 = new byte[i2];
/* 133 */       this.dataBuffer.get(arrayOfByte4, 0, i2);
/* 134 */       this.consumerName = this.conn.charset.toString(arrayOfByte4, 0, i2);
/*     */ 
/*     */ 
/*     */       
/* 138 */       byte b7 = this.dataBuffer.get();
/* 139 */       int i3 = this.dataBuffer.getInt();
/* 140 */       byte[] arrayOfByte5 = new byte[i3];
/* 141 */       this.dataBuffer.get(arrayOfByte5, 0, i3);
/*     */ 
/*     */       
/* 144 */       byte b8 = this.dataBuffer.get();
/* 145 */       int i4 = this.dataBuffer.getInt();
/* 146 */       int i5 = this.dataBuffer.getInt();
/* 147 */       if (arrayOfByte5[0] == 1)
/* 148 */         i5 = -i5; 
/* 149 */       int i6 = i5;
/*     */ 
/*     */       
/* 152 */       byte b9 = this.dataBuffer.get();
/* 153 */       int i7 = this.dataBuffer.getInt();
/* 154 */       int i8 = this.dataBuffer.getInt();
/*     */ 
/*     */       
/* 157 */       byte b10 = this.dataBuffer.get();
/* 158 */       int i9 = this.dataBuffer.getInt();
/* 159 */       byte[] arrayOfByte6 = new byte[i9];
/* 160 */       this.dataBuffer.get(arrayOfByte6, 0, i9);
/*     */ 
/*     */       
/* 163 */       byte b11 = this.dataBuffer.get();
/* 164 */       int i10 = this.dataBuffer.getInt();
/* 165 */       int i11 = this.dataBuffer.getInt();
/* 166 */       if (arrayOfByte6[0] == 1)
/* 167 */         i11 = -i11; 
/* 168 */       int i12 = i11;
/*     */ 
/*     */       
/* 171 */       byte b12 = this.dataBuffer.get();
/* 172 */       int i13 = this.dataBuffer.getInt();
/* 173 */       int i14 = this.dataBuffer.getInt();
/*     */ 
/*     */       
/* 176 */       byte b13 = this.dataBuffer.get();
/* 177 */       int i15 = this.dataBuffer.getInt();
/* 178 */       byte[] arrayOfByte7 = new byte[i15];
/* 179 */       this.dataBuffer.get(arrayOfByte7, 0, i15);
/* 180 */       TIMESTAMP tIMESTAMP = new TIMESTAMP(arrayOfByte7);
/*     */ 
/*     */       
/* 183 */       byte b14 = this.dataBuffer.get();
/* 184 */       int i16 = this.dataBuffer.getInt();
/* 185 */       byte[] arrayOfByte8 = new byte[i16];
/* 186 */       this.dataBuffer.get(arrayOfByte8, 0, i16);
/* 187 */       byte b15 = arrayOfByte8[0];
/*     */ 
/*     */       
/* 190 */       byte b16 = this.dataBuffer.get();
/* 191 */       int i17 = this.dataBuffer.getInt();
/* 192 */       byte[] arrayOfByte9 = new byte[i17];
/* 193 */       this.dataBuffer.get(arrayOfByte9, 0, i17);
/* 194 */       String str1 = this.conn.charset.toString(arrayOfByte9, 0, i17);
/*     */ 
/*     */ 
/*     */       
/* 198 */       byte b17 = this.dataBuffer.get();
/* 199 */       int i18 = this.dataBuffer.getInt();
/* 200 */       byte[] arrayOfByte10 = new byte[i18];
/* 201 */       this.dataBuffer.get(arrayOfByte10, 0, i18);
/* 202 */       String str2 = this.conn.charset.toString(arrayOfByte10, 0, i18);
/*     */ 
/*     */ 
/*     */       
/* 206 */       byte b18 = this.dataBuffer.get();
/* 207 */       int i19 = this.dataBuffer.getInt();
/* 208 */       byte[] arrayOfByte11 = null;
/* 209 */       if (i19 > 0) {
/*     */         
/* 211 */         arrayOfByte11 = new byte[i19];
/* 212 */         this.dataBuffer.get(arrayOfByte11, 0, i19);
/*     */       } 
/*     */ 
/*     */       
/* 216 */       byte b19 = this.dataBuffer.get();
/* 217 */       int i20 = this.dataBuffer.getInt();
/* 218 */       byte[] arrayOfByte12 = new byte[i20];
/* 219 */       this.dataBuffer.get(arrayOfByte12, 0, i20);
/* 220 */       String str3 = this.conn.charset.toString(arrayOfByte12, 0, i20);
/*     */ 
/*     */ 
/*     */       
/* 224 */       byte b20 = this.dataBuffer.get();
/* 225 */       int i21 = this.dataBuffer.getInt();
/* 226 */       byte[] arrayOfByte13 = new byte[i21];
/* 227 */       this.dataBuffer.get(arrayOfByte13, 0, i21);
/* 228 */       String str4 = this.conn.charset.toString(arrayOfByte13, 0, i21);
/*     */ 
/*     */ 
/*     */       
/* 232 */       byte b21 = this.dataBuffer.get();
/* 233 */       int i22 = this.dataBuffer.getInt();
/* 234 */       byte b22 = this.dataBuffer.get();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       this.msgProp = new AQMessagePropertiesI();
/* 240 */       this.msgProp.setAttempts(i14);
/* 241 */       this.msgProp.setCorrelation(str2);
/* 242 */       this.msgProp.setDelay(i8);
/* 243 */       this.msgProp.setEnqueueTime(tIMESTAMP.timestampValue());
/* 244 */       this.msgProp.setMessageState(AQMessageProperties.MessageState.getMessageState(b15));
/* 245 */       if (this.databaseVersion >= 10200)
/* 246 */         this.msgProp.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(m)); 
/* 247 */       this.msgProp.setPreviousQueueMessageId(arrayOfByte11);
/* 248 */       AQAgentI aQAgentI = new AQAgentI();
/* 249 */       aQAgentI.setAddress(str4);
/* 250 */       aQAgentI.setName(str3);
/* 251 */       aQAgentI.setProtocol(b22);
/* 252 */       this.msgProp.setSender(aQAgentI);
/*     */       
/* 254 */       this.msgProp.setPriority(i6);
/* 255 */       this.msgProp.setExpiration(i12);
/* 256 */       this.msgProp.setExceptionQueue(str1);
/*     */     } 
/* 258 */     this.isReady = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties getMessageProperties() throws SQLException {
/* 265 */     if (!this.isReady)
/* 266 */       initEvent(); 
/* 267 */     return this.msgProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegistration() throws SQLException {
/* 274 */     if (!this.isReady)
/* 275 */       initEvent(); 
/* 276 */     return this.registrationString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQNotificationEvent.EventType getEventType() {
/* 283 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQNotificationEvent.AdditionalEventType getAdditionalEventType() {
/* 290 */     return this.additionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEventType(AQNotificationEvent.EventType paramEventType) throws IOException {
/* 297 */     this.eventType = paramEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAdditionalEventType(AQNotificationEvent.AdditionalEventType paramAdditionalEventType) {
/* 304 */     this.additionalEventType = paramAdditionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayload() throws SQLException {
/* 311 */     if (!this.isReady)
/* 312 */       initEvent(); 
/* 313 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueueName() throws SQLException {
/* 320 */     if (!this.isReady)
/* 321 */       initEvent(); 
/* 322 */     return this.queueName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() throws SQLException {
/* 329 */     if (!this.isReady)
/* 330 */       initEvent(); 
/* 331 */     return this.messageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConsumerName() throws SQLException {
/* 338 */     if (!this.isReady)
/* 339 */       initEvent(); 
/* 340 */     return this.consumerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionInformation() {
/* 347 */     return this.conn.connectionDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 355 */     if (!this.isReady) {
/*     */       
/*     */       try {
/*     */         
/* 359 */         initEvent();
/*     */       }
/* 361 */       catch (SQLException sQLException) {
/*     */         
/* 363 */         return sQLException.getMessage();
/*     */       } 
/*     */     }
/* 366 */     StringBuffer stringBuffer = new StringBuffer();
/* 367 */     stringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
/* 368 */     stringBuffer.append("Event type              : " + this.eventType + "\n");
/* 369 */     if (this.additionalEventType != AQNotificationEvent.AdditionalEventType.NONE)
/* 370 */       stringBuffer.append("Additional event type   : " + this.additionalEventType + "\n"); 
/* 371 */     stringBuffer.append("Namespace               : " + this.namespace + "\n");
/* 372 */     stringBuffer.append("Registration            : " + this.registrationString + "\n");
/* 373 */     stringBuffer.append("Queue name              : " + this.queueName + "\n");
/* 374 */     stringBuffer.append("Consumer name           : " + this.consumerName + "\n");
/* 375 */     if (this.payload != null) {
/*     */       
/* 377 */       stringBuffer.append("Payload length          : " + this.payload.length + "\n");
/* 378 */       stringBuffer.append("Payload (first 50 bytes): " + byteBufferToHexString(this.payload, 50) + "\n");
/*     */     } else {
/*     */       
/* 381 */       stringBuffer.append("Payload                 : null\n");
/* 382 */     }  stringBuffer.append("Message ID              : " + byteBufferToHexString(this.messageId, 50) + "\n");
/* 383 */     if (this.msgProp != null)
/* 384 */       stringBuffer.append(this.msgProp.toString()); 
/* 385 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final String byteBufferToHexString(byte[] paramArrayOfbyte, int paramInt) {
/* 391 */     if (paramArrayOfbyte == null) {
/* 392 */       return null;
/*     */     }
/* 394 */     byte b = 0;
/* 395 */     boolean bool = true;
/* 396 */     StringBuffer stringBuffer = new StringBuffer();
/* 397 */     while (b < paramArrayOfbyte.length && b < paramInt) {
/*     */       
/* 399 */       if (!bool) {
/* 400 */         stringBuffer.append(' ');
/*     */       } else {
/* 402 */         bool = false;
/* 403 */       }  String str = Integer.toHexString(paramArrayOfbyte[b] & 0xFF);
/* 404 */       if (str.length() == 1)
/* 405 */         str = "0" + str; 
/* 406 */       stringBuffer.append(str);
/* 407 */       b++;
/*     */     } 
/* 409 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 415 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\NTFAQEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */