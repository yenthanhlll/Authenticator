/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*      */   T4CPreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   30 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */ 
/*      */     
/*   33 */     this.nbPostPonedColumns = new int[1];
/*   34 */     this.nbPostPonedColumns[0] = 0;
/*   35 */     this.indexOfPostPonedColumn = new int[1][3];
/*   36 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */     
/*   38 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   39 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   40 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   41 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   48 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   68 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   69 */       this.oacdefSent = null;
/*      */     }
/*   71 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
/*      */     
/*   73 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   77 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   78 */       sQLException.fillInStackTrace();
/*   79 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   83 */     if (paramBoolean3) {
/*   84 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   86 */     int i = this.numberOfDefinePositions;
/*      */     
/*   88 */     if (this.sqlKind.isDML()) {
/*   89 */       i = 0;
/*      */     }
/*      */     
/*   92 */     if (this.accessors != null)
/*   93 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   94 */         if (this.accessors[b] != null)
/*   95 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   96 */       }   if (this.outBindAccessors != null)
/*   97 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   98 */         if (this.outBindAccessors[b] != null)
/*   99 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*  100 */       }   if (this.returnParamAccessors != null) {
/*  101 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*  102 */         if (this.returnParamAccessors[b] != null) {
/*  103 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  110 */     if (this.bindIndicators != null) {
/*      */       
/*  112 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  115 */       int k = 0;
/*      */       
/*  117 */       if (this.ibtBindChars != null) {
/*  118 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  120 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  122 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  126 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  130 */         if (n != 0) {
/*      */ 
/*      */           
/*  133 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  137 */           if (i1 == 2) {
/*      */             
/*  139 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  144 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  150 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  152 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  154 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  156 */         this.tmpBindsByteArray = null;
/*  157 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  169 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  174 */     int[] arrayOfInt1 = this.definedColumnType;
/*  175 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  176 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  182 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  187 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  188 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  189 */       arrayOfInt1[0] = -8;
/*  190 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  191 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  192 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  193 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  199 */     allocateTmpByteArray();
/*      */     
/*  201 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  203 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  208 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  220 */       int j = t4C8Oall.getCursorId();
/*  221 */       if (j != 0) {
/*  222 */         this.cursorId = j;
/*      */       }
/*  224 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  226 */     catch (SQLException sQLException) {
/*      */       
/*  228 */       int j = t4C8Oall.getCursorId();
/*  229 */       if (j != 0) {
/*  230 */         this.cursorId = j;
/*      */       }
/*  232 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  235 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  240 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  250 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  253 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  255 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  259 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  271 */     super.releaseBuffers();
/*  272 */     this.tmpByteArray = null;
/*  273 */     this.tmpBindsByteArray = null;
/*      */     
/*  275 */     this.t4Connection.all8.bindChars = null;
/*  276 */     this.t4Connection.all8.bindBytes = null;
/*  277 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  284 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  297 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  308 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  316 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  318 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  324 */     if (paramInt1 < 1) {
/*      */       
/*  326 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  327 */       sQLException.fillInStackTrace();
/*  328 */       throw sQLException;
/*      */     } 
/*  330 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  334 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  340 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  346 */     else if (paramInt3 < 0) {
/*      */       
/*  348 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  349 */       sQLException.fillInStackTrace();
/*  350 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  354 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  356 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  357 */       sQLException.fillInStackTrace();
/*  358 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  365 */     int i = paramInt1 - 1;
/*      */     
/*  367 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  369 */       if (this.definedColumnType == null) {
/*      */         
/*  371 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  383 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  385 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  388 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  394 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  396 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  398 */       if (this.definedColumnSize == null) {
/*  399 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  402 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  404 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  407 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  411 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  413 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  415 */       if (this.definedColumnFormOfUse == null) {
/*  416 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  419 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  421 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  424 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  428 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  430 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  432 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  437 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  441 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  447 */           this.needToPrepareDefineBuffer = true;
/*  448 */           this.columnsDefinedByUser = true;
/*      */           
/*  450 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  451 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  460 */     synchronized (this.connection) {
/*      */       
/*  462 */       super.clearDefines();
/*  463 */       this.definedColumnType = null;
/*  464 */       this.definedColumnSize = null;
/*  465 */       this.definedColumnFormOfUse = null;
/*  466 */       this.t4Connection.all8.definesAccessors = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  484 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  513 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  522 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  523 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  524 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  526 */       int m = bool ? this.accessors.length : 1;
/*  527 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  528 */         m += bool ? -1 : 1) {
/*      */         
/*  530 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  531 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  532 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  533 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  540 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  541 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  542 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  549 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  556 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  566 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  586 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  588 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  592 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  598 */         if (!paramBoolean) {
/*      */           
/*  600 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  608 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  614 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  620 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  626 */         if (!paramBoolean) {
/*      */           
/*  628 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  636 */         if (paramBoolean && paramString != null) {
/*      */           
/*  638 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  639 */           sQLException1.fillInStackTrace();
/*  640 */           throw sQLException1;
/*      */         } 
/*      */         
/*  643 */         if (paramBoolean) {
/*  644 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  647 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  653 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  659 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  665 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  671 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  675 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  678 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  685 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  691 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  697 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  703 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  709 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  715 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  718 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  723 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  726 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  733 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  739 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  745 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  751 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  757 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  773 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  774 */         sQLException.fillInStackTrace();
/*  775 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  779 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  806 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  809 */       this.connection.open(this);
/*  810 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  816 */       this.t4Connection.needLine();
/*  817 */       this.t4Connection.sendPiggyBackedMessages();
/*  818 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  819 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  821 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  823 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  824 */         this.accessors[b].initMetadata();
/*      */       }
/*  826 */     } catch (IOException iOException) {
/*      */       
/*  828 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  831 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  832 */       sQLException.fillInStackTrace();
/*  833 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  837 */     this.describedWithNames = true;
/*  838 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  873 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  876 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  882 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  886 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  889 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  892 */       throw sQLException;
/*      */     }
/*  894 */     catch (IOException iOException) {
/*      */       
/*  896 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  898 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  899 */       sQLException.fillInStackTrace();
/*  900 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  905 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  906 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  909 */     this.needToParse = false;
/*      */ 
/*      */     
/*  912 */     if (this.connection.calculateChecksum) {
/*  913 */       if (this.validRows > 0) {
/*  914 */         calculateCheckSum();
/*  915 */       } else if (this.rowsProcessed > 0) {
/*  916 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  918 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  928 */     if (this.definedColumnType == null) {
/*  929 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  931 */     this.aFetchWasDoneDuringDescribe = false;
/*  932 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  934 */       this.aFetchWasDoneDuringDescribe = true;
/*  935 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  939 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  940 */       this.accessors[b].initMetadata();
/*      */     }
/*  942 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  984 */         boolean bool = false;
/*  985 */         if (this.columnsDefinedByUser) {
/*  986 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1006 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1014 */           boolean bool1 = false;
/* 1015 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1016 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1018 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1023 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1024 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1030 */               bool1 = true;
/* 1031 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1032 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1036 */           if (bool1) {
/*      */             
/* 1038 */             this.definedColumnType = arrayOfInt1;
/* 1039 */             this.definedColumnSize = arrayOfInt2;
/* 1040 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1046 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1048 */         this.needToParse = false;
/* 1049 */         if (bool) {
/* 1050 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1054 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1057 */     } catch (SQLException sQLException) {
/*      */       
/* 1059 */       throw sQLException;
/*      */     }
/* 1061 */     catch (IOException iOException) {
/*      */       
/* 1063 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1064 */       calculateCheckSum();
/*      */       
/* 1066 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1067 */       sQLException.fillInStackTrace();
/* 1068 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1095 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1099 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1103 */           this.nextStream.close();
/*      */         }
/* 1105 */         catch (IOException iOException) {
/*      */           
/* 1107 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1109 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1110 */           sQLException.fillInStackTrace();
/* 1111 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1115 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1121 */       doOall8(false, false, true, false, false);
/*      */       
/* 1123 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1125 */     catch (IOException iOException) {
/*      */       
/* 1127 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1129 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1130 */       sQLException.fillInStackTrace();
/* 1131 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1137 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1152 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1154 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1156 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1159 */     } catch (IOException iOException) {
/*      */       
/* 1161 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1163 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1164 */       sQLException.fillInStackTrace();
/* 1165 */       throw sQLException;
/*      */     
/*      */     }
/* 1168 */     catch (SQLException sQLException) {
/*      */       
/* 1170 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1173 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1178 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1202 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
/*      */     
/* 1204 */     if (this.cursorId != 0) {
/* 1205 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1208 */     this.tmpByteArray = null;
/* 1209 */     this.tmpBindsByteArray = null;
/* 1210 */     this.definedColumnType = null;
/* 1211 */     this.definedColumnSize = null;
/* 1212 */     this.definedColumnFormOfUse = null;
/* 1213 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1233 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
/*      */     
/* 1235 */     if (this.streamList != null)
/*      */     {
/* 1237 */       while (this.nextStream != null) {
/*      */         try {
/* 1239 */           this.nextStream.close();
/*      */         }
/* 1241 */         catch (IOException iOException) {
/* 1242 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1244 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1245 */           sQLException.fillInStackTrace();
/* 1246 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1250 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1263 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1266 */       this.currentRowCharLens[paramInt] = 1;
/* 1267 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1270 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 1279 */     super.doLocalInitialization();
/*      */     
/* 1281 */     this.t4Connection.all8.bindChars = this.bindChars;
/* 1282 */     this.t4Connection.all8.bindBytes = this.bindBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1288 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CPreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */