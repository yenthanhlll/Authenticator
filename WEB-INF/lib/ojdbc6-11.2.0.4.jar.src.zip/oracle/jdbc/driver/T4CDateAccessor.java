/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.text.DateFormatSymbols;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CDateAccessor
/*     */   extends DateAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   final int[] meta;
/*     */   
/*     */   T4CDateAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  46 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CDateAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1) {
/*     */       this.underlyingLongRaw = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 125 */     if (this.isUseLess) {
/*     */       
/* 127 */       this.lastRowProcessed++;
/*     */       
/* 129 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 138 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 140 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 141 */       processIndicator(this.meta[0]);
/*     */       
/* 143 */       this.lastRowProcessed++;
/*     */       
/* 145 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 150 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (this.isNullByDescribe) {
/*     */       
/* 156 */       this.rowSpaceIndicator[i] = -1;
/* 157 */       this.rowSpaceIndicator[j] = 0;
/* 158 */       this.lastRowProcessed++;
/*     */       
/* 160 */       if (this.statement.connection.versionNumber < 9200) {
/* 161 */         processIndicator(0);
/*     */       }
/* 163 */       return false;
/*     */     } 
/*     */     
/* 166 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 170 */     this.mare.unmarshalCLR(this.rowSpaceByte, k, this.meta, this.byteLength);
/*     */     
/* 172 */     processIndicator(this.meta[0]);
/*     */     
/* 174 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 178 */       this.rowSpaceIndicator[i] = -1;
/* 179 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 183 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/* 184 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 187 */     this.lastRowProcessed++;
/*     */     
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/*     */     int i;
/* 199 */     if (this.lastRowProcessed == 0) {
/* 200 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 202 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 205 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 206 */     int k = this.columnIndex + i * this.byteLength;
/* 207 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 208 */     int n = this.indicatorIndex + i;
/* 209 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 210 */     int i2 = this.lengthIndex + i;
/* 211 */     short s = this.rowSpaceIndicator[i2];
/* 212 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 214 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 218 */     this.rowSpaceIndicator[i1] = (short)s;
/* 219 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 222 */     if (!this.isNullByDescribe)
/*     */     {
/* 224 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 229 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 232 */     this.lastRowProcessed++; } void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   } void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 244 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 246 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 248 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 249 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 250 */     int n = this.lengthIndex + paramInt2 - 1;
/* 251 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 252 */     short s = paramArrayOfshort[i1];
/*     */     
/* 254 */     this.rowSpaceIndicator[n] = (short)s;
/* 255 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 258 */     if (s != 0)
/*     */     {
/* 260 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString) throws SQLException {
/* 288 */     if (this.definedColumnType == 0 || this.definedColumnType == 91)
/*     */     {
/*     */       
/* 291 */       return super.toText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     String str = (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM");
/* 300 */     return nlsFormatToText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String nlsFormatToText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString1, String paramString2) throws SQLException {
/* 326 */     char[] arrayOfChar = (paramString2 + "      ").toCharArray();
/* 327 */     int i = paramString2.length();
/*     */     
/* 329 */     StringBuffer stringBuffer = new StringBuffer(i + 25);
/* 330 */     String[] arrayOfString1 = null;
/* 331 */     String[] arrayOfString2 = null;
/* 332 */     TimeZone timeZone = null;
/*     */ 
/*     */     
/* 335 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 337 */       switch (arrayOfChar[b]) {
/*     */         
/*     */         case 'R':
/*     */         case 'r':
/* 341 */           if (arrayOfChar[b + 1] == 'R' || arrayOfChar[b + 1] == 'r') {
/*     */             
/* 343 */             if ((arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') && (arrayOfChar[b + 3] == 'R' || arrayOfChar[b + 3] == 'r')) {
/*     */ 
/*     */               
/* 346 */               if (paramInt1 < 1000) {
/* 347 */                 stringBuffer.append("0" + paramInt1);
/* 348 */               } else if (paramInt1 < 100) {
/* 349 */                 stringBuffer.append("00" + paramInt1);
/* 350 */               } else if (paramInt1 < 10) {
/* 351 */                 stringBuffer.append("000" + paramInt1);
/*     */               } else {
/* 353 */                 stringBuffer.append(paramInt1);
/*     */               } 
/* 355 */               b += 3;
/*     */               
/*     */               break;
/*     */             } 
/* 359 */             if (paramInt1 >= 100) {
/* 360 */               paramInt1 %= 100;
/*     */             }
/* 362 */             if (paramInt1 < 10) {
/* 363 */               stringBuffer.append("0" + paramInt1);
/*     */             } else {
/* 365 */               stringBuffer.append(paramInt1);
/*     */             } 
/* 367 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'Y':
/*     */         case 'y':
/* 374 */           if (arrayOfChar[b + 1] == 'Y' || arrayOfChar[b + 1] == 'y') {
/*     */             
/* 376 */             if ((arrayOfChar[b + 2] == 'Y' || arrayOfChar[b + 2] == 'y') && (arrayOfChar[b + 3] == 'Y' || arrayOfChar[b + 3] == 'y')) {
/*     */ 
/*     */               
/* 379 */               if (paramInt1 < 1000) {
/* 380 */                 stringBuffer.append("0" + paramInt1);
/* 381 */               } else if (paramInt1 < 100) {
/* 382 */                 stringBuffer.append("00" + paramInt1);
/* 383 */               } else if (paramInt1 < 10) {
/* 384 */                 stringBuffer.append("000" + paramInt1);
/*     */               } else {
/* 386 */                 stringBuffer.append(paramInt1);
/*     */               } 
/* 388 */               b += 3;
/*     */               
/*     */               break;
/*     */             } 
/* 392 */             if (paramInt1 >= 100) {
/* 393 */               paramInt1 %= 100;
/*     */             }
/* 395 */             if (paramInt1 < 10) {
/* 396 */               stringBuffer.append("0" + paramInt1);
/*     */             } else {
/* 398 */               stringBuffer.append(paramInt1);
/*     */             } 
/* 400 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'D':
/*     */         case 'd':
/* 407 */           if (arrayOfChar[b + 1] == 'D' || arrayOfChar[b + 1] == 'd') {
/*     */             
/* 409 */             stringBuffer.append(((paramInt3 < 10) ? "0" : "") + paramInt3);
/* 410 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'M':
/*     */         case 'm':
/* 416 */           if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
/*     */             
/* 418 */             stringBuffer.append(((paramInt2 < 10) ? "0" : "") + paramInt2);
/* 419 */             b++; break;
/*     */           } 
/* 421 */           if (arrayOfChar[b + 1] == 'I' || arrayOfChar[b + 1] == 'i') {
/*     */             
/* 423 */             stringBuffer.append(((paramInt5 < 10) ? "0" : "") + paramInt5);
/* 424 */             b++; break;
/*     */           } 
/* 426 */           if ((arrayOfChar[b + 1] == 'O' || arrayOfChar[b + 1] == 'o') && (arrayOfChar[b + 2] == 'N' || arrayOfChar[b + 2] == 'n')) {
/*     */ 
/*     */             
/* 429 */             if ((arrayOfChar[b + 3] == 'T' || arrayOfChar[b + 3] == 't') && (arrayOfChar[b + 4] == 'H' || arrayOfChar[b + 4] == 'h')) {
/*     */ 
/*     */ 
/*     */               
/* 433 */               if (arrayOfString2 == null) {
/* 434 */                 arrayOfString2 = (new DateFormatSymbols()).getMonths();
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 441 */               if (arrayOfChar[b] == 'm') {
/*     */ 
/*     */                 
/* 444 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1].toLowerCase());
/*     */               }
/* 446 */               else if (arrayOfChar[b + 1] == 'O') {
/*     */ 
/*     */                 
/* 449 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1].toUpperCase());
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 454 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1]);
/*     */               } 
/* 456 */               b += 4;
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 461 */             if (arrayOfString1 == null) {
/* 462 */               arrayOfString1 = (new DateFormatSymbols()).getShortMonths();
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 469 */             if (arrayOfChar[b] == 'm') {
/*     */ 
/*     */               
/* 472 */               stringBuffer.append(arrayOfString1[paramInt2 - 1].toLowerCase());
/*     */             }
/* 474 */             else if (arrayOfChar[b + 1] == 'O') {
/*     */ 
/*     */               
/* 477 */               stringBuffer.append(arrayOfString1[paramInt2 - 1].toUpperCase());
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 482 */               stringBuffer.append(arrayOfString1[paramInt2 - 1]);
/*     */             } 
/* 484 */             b += 2;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'H':
/*     */         case 'h':
/* 491 */           if (arrayOfChar[b + 1] == 'H' || arrayOfChar[b + 1] == 'h') {
/*     */             
/* 493 */             if (arrayOfChar[b + 2] == '2' || arrayOfChar[b + 3] == '4') {
/*     */               
/* 495 */               stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
/* 496 */               b += 3;
/*     */               break;
/*     */             } 
/* 499 */             if (paramInt4 > 12)
/* 500 */               paramInt4 -= 12; 
/* 501 */             stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
/* 502 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'S':
/*     */         case 's':
/* 509 */           if (arrayOfChar[b + 1] == 'S' || arrayOfChar[b + 1] == 's') {
/*     */             
/* 511 */             stringBuffer.append(((paramInt6 < 10) ? "0" : "") + paramInt6);
/* 512 */             b++;
/* 513 */             if ((arrayOfChar[b + 1] == 'X' || arrayOfChar[b + 1] == 'x') && (arrayOfChar[b + 2] == 'F' || arrayOfChar[b + 2] == 'f') && (arrayOfChar[b + 3] == 'F' || arrayOfChar[b + 3] == 'f')) {
/*     */ 
/*     */ 
/*     */               
/* 517 */               stringBuffer.append(".");
/* 518 */               b++;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'F':
/*     */         case 'f':
/* 526 */           if (arrayOfChar[b + 1] == 'F' || arrayOfChar[b + 1] == 'f') {
/*     */             
/* 528 */             if (paramInt7 >= 0) {
/*     */               
/* 530 */               stringBuffer.append(paramInt7);
/*     */             }
/*     */             else {
/*     */               
/* 534 */               stringBuffer.append(0);
/*     */             } 
/* 536 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'T':
/*     */         case 't':
/* 542 */           if (arrayOfChar[b + 1] == 'Z' || arrayOfChar[b + 1] == 'z') {
/*     */             
/* 544 */             if (arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') {
/*     */               
/* 546 */               if (paramString1.length() > 3 && paramString1.startsWith("GMT")) {
/*     */                 
/* 548 */                 stringBuffer.append(paramString1.substring(3));
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 553 */                 stringBuffer.append(paramString1.toUpperCase());
/*     */               } 
/* 555 */               b += 2; break;
/* 556 */             }  if (arrayOfChar[b + 2] == 'H' || arrayOfChar[b + 2] == 'h') {
/*     */               
/* 558 */               if (timeZone == null)
/* 559 */                 timeZone = TimeZone.getTimeZone(paramString1); 
/* 560 */               long l = (timeZone.getRawOffset() / 3600000);
/* 561 */               stringBuffer.append(l);
/* 562 */               b += 2; break;
/* 563 */             }  if (arrayOfChar[b + 2] == 'M' || arrayOfChar[b + 2] == 'm') {
/*     */               
/* 565 */               if (timeZone == null)
/* 566 */                 timeZone = TimeZone.getTimeZone(paramString1); 
/* 567 */               long l = (Math.abs(timeZone.getRawOffset()) % 3600000 / 60000);
/* 568 */               stringBuffer.append(((l < 10L) ? "0" : "") + l);
/* 569 */               b += 2;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'A':
/*     */         case 'P':
/*     */         case 'a':
/*     */         case 'p':
/* 578 */           if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
/*     */             
/* 580 */             stringBuffer.append(paramBoolean ? "AM" : "PM");
/* 581 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         default:
/* 586 */           stringBuffer.append(arrayOfChar[b]);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 592 */     return stringBuffer.substring(0, stringBuffer.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 607 */     String str = null;
/*     */     
/* 609 */     if (this.definedColumnType == 0) {
/*     */       
/* 611 */       str = super.getString(paramInt);
/*     */     }
/*     */     else {
/*     */       
/* 615 */       if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 619 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 620 */         sQLException.fillInStackTrace();
/* 621 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 626 */       if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */         
/* 628 */         int i = this.columnIndex + this.byteLength * paramInt;
/* 629 */         int j = oracleYear(i);
/* 630 */         int k = 0;
/* 631 */         str = toText(j, this.rowSpaceByte[2 + i], this.rowSpaceByte[3 + i], k = this.rowSpaceByte[4 + i] - 1, this.rowSpaceByte[5 + i] - 1, this.rowSpaceByte[6 + i] - 1, -1, (k < 12), (String)null);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 643 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 645 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 647 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 653 */     if (this.definedColumnType == 0) {
/* 654 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 657 */     Object object = null;
/*     */     
/* 659 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 661 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 662 */       sQLException.fillInStackTrace();
/* 663 */       throw sQLException;
/*     */     } 
/*     */     
/* 666 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 668 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -15:
/*     */         case -9:
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 682 */           return getString(paramInt);
/*     */         
/*     */         case 91:
/* 685 */           return getDate(paramInt);
/*     */         
/*     */         case 92:
/* 688 */           return getTime(paramInt);
/*     */         
/*     */         case 93:
/* 691 */           return getTimestamp(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 698 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 702 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 703 */       sQLException.fillInStackTrace();
/* 704 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 710 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 715 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CDateAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */