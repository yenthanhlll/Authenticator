package oracle.jdbc.driver;

public interface Message {
  String msg(String paramString, Object paramObject);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */