/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ class ScrollableResultSet extends BaseResultSet {
/*      */   PhysicalConnection connection;
/*      */   OracleResultSetImpl resultSet;
/*      */   ScrollRsetStatement scrollStmt;
/*      */   ResultSetMetaData metadata;
/*      */   private int rsetType;
/*      */   private int rsetConcurency;
/*      */   private int beginColumnIndex;
/*      */   private int columnCount;
/*      */   private int wasNull;
/*      */   OracleResultSetCache rsetCache;
/*      */   int currentRow;
/*      */   private int numRowsCached;
/*      */   private boolean allRowsCached;
/*      */   private int lastRefetchSz;
/*      */   private Vector refetchRowids;
/*      */   private OraclePreparedStatement refetchStmt;
/*      */   private int usrFetchDirection;
/*      */   private static final ClassRef XMLTYPE_CLASS;
/*      */   
/*      */   ScrollableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2) throws SQLException {
/*   77 */     this.connection = ((OracleStatement)paramScrollRsetStatement).connection;
/*   78 */     this.resultSet = paramOracleResultSetImpl;
/*   79 */     this.metadata = null;
/*   80 */     this.scrollStmt = paramScrollRsetStatement;
/*   81 */     this.rsetType = paramInt1;
/*   82 */     this.rsetConcurency = paramInt2;
/*   83 */     this.beginColumnIndex = needIdentifier(paramInt1, paramInt2) ? 1 : 0;
/*   84 */     this.columnCount = 0;
/*   85 */     this.wasNull = -1;
/*   86 */     this.rsetCache = paramScrollRsetStatement.getResultSetCache();
/*      */     
/*   88 */     if (this.rsetCache == null) {
/*      */       
/*   90 */       this.rsetCache = new OracleResultSetCacheImpl();
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*   96 */         this.rsetCache.clear();
/*      */       }
/*   98 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  101 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  102 */         sQLException.fillInStackTrace();
/*  103 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  108 */     this.currentRow = 0;
/*  109 */     this.numRowsCached = 0;
/*  110 */     this.allRowsCached = false;
/*  111 */     this.lastRefetchSz = 0;
/*  112 */     this.refetchRowids = null;
/*  113 */     this.refetchStmt = null;
/*  114 */     this.usrFetchDirection = 1000;
/*  115 */     getInternalMetadata();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  128 */     synchronized (this.connection) {
/*      */       
/*  130 */       if (this.closed)
/*  131 */         return;  super.close();
/*  132 */       if (this.resultSet != null)
/*  133 */         this.resultSet.close(); 
/*  134 */       if (this.refetchStmt != null)
/*  135 */         this.refetchStmt.close(); 
/*  136 */       if (this.scrollStmt != null)
/*  137 */         this.scrollStmt.notifyCloseRset(); 
/*  138 */       if (this.refetchRowids != null) {
/*  139 */         this.refetchRowids.removeAllElements();
/*      */       }
/*  141 */       this.resultSet = null;
/*  142 */       this.scrollStmt = null;
/*  143 */       this.refetchStmt = null;
/*  144 */       this.refetchRowids = null;
/*  145 */       this.metadata = null;
/*      */ 
/*      */       
/*      */       try {
/*  149 */         if (this.rsetCache != null)
/*      */         {
/*  151 */           this.rsetCache.clear();
/*  152 */           this.rsetCache.close();
/*      */         }
/*      */       
/*  155 */       } catch (IOException iOException) {
/*      */ 
/*      */         
/*  158 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  159 */         sQLException.fillInStackTrace();
/*  160 */         throw sQLException;
/*      */       }
/*      */       finally {
/*      */         
/*  164 */         this.rsetCache = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  172 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  175 */       if (this.wasNull == -1) {
/*      */         
/*  177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/*  178 */         sQLException.fillInStackTrace();
/*  179 */         throw sQLException;
/*      */       } 
/*      */       
/*  182 */       return (this.wasNull == 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  190 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  193 */       return (Statement)this.scrollStmt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetBeginColumnIndex() {
/*  203 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  206 */       this.beginColumnIndex = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSet getResultSet() {
/*  216 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  219 */       return (ResultSet)this.resultSet;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int removeRowInCache(int paramInt) throws SQLException {
/*  226 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  229 */       if (!isEmptyResultSet() && isValidRow(paramInt)) {
/*      */         
/*  231 */         removeCachedRowAt(paramInt);
/*      */         
/*  233 */         this.numRowsCached--;
/*      */         
/*  235 */         if (paramInt >= this.currentRow) {
/*  236 */           this.currentRow--;
/*      */         }
/*  238 */         return 1;
/*      */       } 
/*      */       
/*  241 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int refreshRowsInCache(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  252 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  255 */       OracleResultSetImpl oracleResultSetImpl = null;
/*  256 */       int i = 0;
/*      */ 
/*      */       
/*  259 */       i = get_refetch_size(paramInt1, paramInt2, paramInt3);
/*      */ 
/*      */       
/*      */       try {
/*  263 */         if (i > 0)
/*      */         {
/*      */ 
/*      */           
/*  267 */           if (i != this.lastRefetchSz) {
/*      */             
/*  269 */             if (this.refetchStmt != null) {
/*  270 */               this.refetchStmt.close();
/*      */             }
/*  272 */             this.refetchStmt = prepare_refetch_statement(i);
/*  273 */             this.refetchStmt.setQueryTimeout(((OracleStatement)this.scrollStmt).getQueryTimeout());
/*  274 */             this.lastRefetchSz = i;
/*      */           } 
/*      */ 
/*      */           
/*  278 */           prepare_refetch_binds(this.refetchStmt, i);
/*      */ 
/*      */           
/*  281 */           oracleResultSetImpl = (OracleResultSetImpl)this.refetchStmt.executeQuery();
/*      */ 
/*      */           
/*  284 */           save_refetch_results(oracleResultSetImpl, paramInt1, i, paramInt3);
/*      */         }
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/*  290 */         if (oracleResultSetImpl != null) {
/*  291 */           oracleResultSetImpl.close();
/*      */         }
/*      */       } 
/*  294 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  305 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  308 */       if (this.closed) {
/*      */         
/*  310 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  311 */         sQLException.fillInStackTrace();
/*  312 */         throw sQLException;
/*      */       } 
/*      */       
/*  315 */       if (isEmptyResultSet())
/*      */       {
/*  317 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  321 */       if (this.currentRow < 1) {
/*      */         
/*  323 */         this.currentRow = 1;
/*      */       }
/*      */       else {
/*      */         
/*  327 */         this.currentRow++;
/*      */       } 
/*      */       
/*  330 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/*  338 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  341 */       if (this.closed) {
/*      */         
/*  343 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  344 */         sQLException.fillInStackTrace();
/*  345 */         throw sQLException;
/*      */       } 
/*  347 */       return (!isEmptyResultSet() && this.currentRow < 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/*  354 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  357 */       if (this.closed) {
/*      */         
/*  359 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  360 */         sQLException.fillInStackTrace();
/*  361 */         throw sQLException;
/*      */       } 
/*  363 */       return (!isEmptyResultSet() && this.currentRow > 0 && !isValidRow(this.currentRow));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/*  370 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  373 */       if (this.closed) {
/*      */         
/*  375 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  376 */         sQLException.fillInStackTrace();
/*  377 */         throw sQLException;
/*      */       } 
/*  379 */       return (this.currentRow == 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/*  386 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  389 */       if (this.closed) {
/*      */         
/*  391 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  392 */         sQLException.fillInStackTrace();
/*  393 */         throw sQLException;
/*      */       } 
/*  395 */       return (!isEmptyResultSet() && isValidRow(this.currentRow) && !isValidRow(this.currentRow + 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*  403 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  406 */       if (this.closed) {
/*      */         
/*  408 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  409 */         sQLException.fillInStackTrace();
/*  410 */         throw sQLException;
/*      */       } 
/*  412 */       if (!isEmptyResultSet()) {
/*  413 */         this.currentRow = 0;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*  420 */     synchronized (this.connection) {
/*  421 */       if (this.closed) {
/*      */         
/*  423 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  424 */         sQLException.fillInStackTrace();
/*  425 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  429 */       if (!isEmptyResultSet()) {
/*  430 */         this.currentRow = getLastRow() + 1;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/*  437 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  440 */       if (this.closed) {
/*      */         
/*  442 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  443 */         sQLException.fillInStackTrace();
/*  444 */         throw sQLException;
/*      */       } 
/*  446 */       if (isEmptyResultSet())
/*      */       {
/*  448 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  452 */       this.currentRow = 1;
/*      */       
/*  454 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/*  462 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  465 */       if (this.closed) {
/*      */         
/*  467 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  468 */         sQLException.fillInStackTrace();
/*  469 */         throw sQLException;
/*      */       } 
/*  471 */       if (isEmptyResultSet())
/*      */       {
/*  473 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  477 */       this.currentRow = getLastRow();
/*      */       
/*  479 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/*  487 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  490 */       if (this.closed) {
/*      */         
/*  492 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  493 */         sQLException.fillInStackTrace();
/*  494 */         throw sQLException;
/*      */       } 
/*  496 */       if (isValidRow(this.currentRow)) {
/*  497 */         return this.currentRow;
/*      */       }
/*  499 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLException {
/*  506 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  509 */       if (this.closed) {
/*      */         
/*  511 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  512 */         sQLException.fillInStackTrace();
/*  513 */         throw sQLException;
/*      */       } 
/*  515 */       if (paramInt == 0) {
/*      */         
/*  517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "absolute(" + paramInt + ")");
/*  518 */         sQLException.fillInStackTrace();
/*  519 */         throw sQLException;
/*      */       } 
/*      */       
/*  522 */       if (isEmptyResultSet())
/*      */       {
/*  524 */         return false;
/*      */       }
/*  526 */       if (paramInt > 0) {
/*      */         
/*  528 */         this.currentRow = paramInt;
/*      */       }
/*  530 */       else if (paramInt < 0) {
/*      */         
/*  532 */         this.currentRow = getLastRow() + 1 + paramInt;
/*      */       } 
/*      */       
/*  535 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLException {
/*  542 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  545 */       if (this.closed) {
/*      */         
/*  547 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  548 */         sQLException1.fillInStackTrace();
/*  549 */         throw sQLException1;
/*      */       } 
/*  551 */       if (isEmptyResultSet())
/*      */       {
/*  553 */         return false;
/*      */       }
/*  555 */       if (isValidRow(this.currentRow)) {
/*      */         
/*  557 */         this.currentRow += paramInt;
/*      */         
/*  559 */         return isValidRow(this.currentRow);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  564 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "relative");
/*  565 */       sQLException.fillInStackTrace();
/*  566 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/*  575 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  578 */       if (this.closed) {
/*      */         
/*  580 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  581 */         sQLException.fillInStackTrace();
/*  582 */         throw sQLException;
/*      */       } 
/*  584 */       if (isEmptyResultSet())
/*      */       {
/*  586 */         return false;
/*      */       }
/*  588 */       if (isAfterLast()) {
/*      */         
/*  590 */         this.currentRow = getLastRow();
/*      */       }
/*      */       else {
/*      */         
/*  594 */         this.currentRow--;
/*      */       } 
/*      */       
/*  597 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  608 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  611 */       if (this.closed) {
/*      */         
/*  613 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  614 */         sQLException.fillInStackTrace();
/*  615 */         throw sQLException;
/*      */       } 
/*      */       
/*  618 */       this.wasNull = -1;
/*      */       
/*  620 */       if (!isValidRow(this.currentRow)) {
/*      */         
/*  622 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  623 */         sQLException.fillInStackTrace();
/*  624 */         throw sQLException;
/*      */       } 
/*      */       
/*  627 */       if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */         
/*  629 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  630 */         sQLException.fillInStackTrace();
/*  631 */         throw sQLException;
/*      */       } 
/*      */       
/*  634 */       Datum datum = getCachedDatumValueAt(this.currentRow, paramInt + this.beginColumnIndex);
/*      */ 
/*      */       
/*  637 */       this.wasNull = (datum == null) ? 1 : 0;
/*      */       
/*  639 */       return datum;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  646 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  649 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  651 */       if (datum != null) {
/*      */         CLOB cLOB;
/*  653 */         switch (getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 2005:
/*      */           case 2011:
/*  663 */             cLOB = (CLOB)datum;
/*  664 */             return cLOB.getSubString(1L, (int)cLOB.length());
/*      */ 
/*      */ 
/*      */           
/*      */           case 91:
/*  669 */             if (this.connection.mapDateToTimestamp) {
/*  670 */               return datum.toJdbc().toString();
/*      */             }
/*  672 */             return datum.dateValue().toString();
/*      */ 
/*      */ 
/*      */           
/*      */           case 93:
/*  677 */             if (datum instanceof DATE) {
/*      */               
/*  679 */               if (this.connection.mapDateToTimestamp) {
/*  680 */                 return datum.toJdbc().toString();
/*      */               }
/*  682 */               return datum.dateValue().toString();
/*      */             } 
/*      */ 
/*      */             
/*  686 */             if (this.connection.j2ee13Compliant)
/*      */             {
/*      */               
/*  689 */               return datum.toJdbc().toString();
/*      */             }
/*      */ 
/*      */             
/*  693 */             return datum.stringValue((Connection)this.connection);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  700 */         return datum.stringValue((Connection)this.connection);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  705 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  712 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  715 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  717 */       if (datum != null)
/*      */       {
/*  719 */         return datum.booleanValue();
/*      */       }
/*      */       
/*  722 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  729 */     synchronized (this.connection) {
/*      */       
/*  731 */       if (!isValidRow(this.currentRow)) {
/*      */         
/*  733 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  734 */         sQLException.fillInStackTrace();
/*  735 */         throw sQLException;
/*      */       } 
/*      */       
/*  738 */       if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */         
/*  740 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  741 */         sQLException.fillInStackTrace();
/*  742 */         throw sQLException;
/*      */       } 
/*      */       
/*  745 */       CachedRowElement cachedRowElement = null;
/*  746 */       OracleResultSet.AuthorizationIndicator authorizationIndicator = null;
/*      */ 
/*      */       
/*      */       try {
/*  750 */         cachedRowElement = (CachedRowElement)this.rsetCache.get(this.currentRow, paramInt);
/*      */       }
/*  752 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  755 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  756 */         sQLException.fillInStackTrace();
/*  757 */         throw sQLException;
/*      */       } 
/*      */       
/*  760 */       if (cachedRowElement != null) {
/*  761 */         authorizationIndicator = cachedRowElement.getIndicator();
/*      */       }
/*  763 */       return authorizationIndicator;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  770 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  773 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  775 */       if (datum != null) {
/*  776 */         return datum.byteValue();
/*      */       }
/*  778 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  785 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  788 */       long l = getLong(paramInt);
/*      */       
/*  790 */       if (l > 65537L || l < -65538L) {
/*      */         
/*  792 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  793 */         sQLException.fillInStackTrace();
/*  794 */         throw sQLException;
/*      */       } 
/*      */       
/*  797 */       return (short)(int)l;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  804 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  807 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  809 */       if (datum != null)
/*      */       {
/*  811 */         return datum.intValue();
/*      */       }
/*      */       
/*  814 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  821 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  824 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  826 */       if (datum != null)
/*      */       {
/*  828 */         return datum.longValue();
/*      */       }
/*      */       
/*  831 */       return 0L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  838 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  841 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  843 */       if (datum != null)
/*      */       {
/*  845 */         return datum.floatValue();
/*      */       }
/*      */       
/*  848 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  855 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  858 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  860 */       if (datum != null)
/*      */       {
/*  862 */         return datum.doubleValue();
/*      */       }
/*      */       
/*  865 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  873 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  876 */       Datum datum = getOracleObject(paramInt1);
/*      */       
/*  878 */       if (datum != null)
/*      */       {
/*  880 */         return datum.bigDecimalValue();
/*      */       }
/*      */       
/*  883 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  890 */     synchronized (this.connection) {
/*      */       
/*  892 */       byte[] arrayOfByte = null;
/*  893 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  895 */       if (datum != null)
/*      */       {
/*  897 */         if (datum instanceof RAW) {
/*  898 */           arrayOfByte = ((RAW)datum).shareBytes();
/*  899 */         } else if (datum instanceof BLOB) {
/*      */           
/*  901 */           BLOB bLOB = (BLOB)datum;
/*  902 */           long l = bLOB.length();
/*  903 */           if (l > 2147483647L) {
/*      */ 
/*      */             
/*  906 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/*  907 */             sQLException.fillInStackTrace();
/*  908 */             throw sQLException;
/*      */           } 
/*      */           
/*  911 */           arrayOfByte = bLOB.getBytes(1L, (int)l);
/*  912 */           if (bLOB.isTemporary()) this.resultSet.statement.addToTempLobsToFree(bLOB);
/*      */         
/*      */         } else {
/*      */           
/*  916 */           arrayOfByte = datum.getBytes();
/*      */         } 
/*      */       }
/*  919 */       return arrayOfByte;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  926 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  929 */       Datum datum = getOracleObject(paramInt);
/*  930 */       Date date = null;
/*      */       
/*  932 */       if (datum != null)
/*      */       
/*  934 */       { ResultSetMetaData resultSetMetaData = getInternalMetadata();
/*  935 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { 
/*      */           
/*      */           case -101:
/*  940 */             date = ((TIMESTAMPTZ)datum).dateValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  953 */             return date;case -102: date = ((TIMESTAMPLTZ)datum).dateValue((Connection)this.connection); return date; }  date = datum.dateValue(); }  return date;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  960 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  963 */       Datum datum = getOracleObject(paramInt);
/*  964 */       Time time = null;
/*      */       
/*  966 */       if (datum != null)
/*      */       
/*  968 */       { ResultSetMetaData resultSetMetaData = getInternalMetadata();
/*  969 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/*  972 */             time = ((TIMESTAMPTZ)datum).timeValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  986 */             return time;case -102: time = ((TIMESTAMPLTZ)datum).timeValue((Connection)this.connection, this.connection.getDbTzCalendar()); return time; }  time = datum.timeValue(); }  return time;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  994 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  997 */       Datum datum = getOracleObject(paramInt);
/*  998 */       Timestamp timestamp = null;
/*      */       
/* 1000 */       if (datum != null)
/*      */       
/* 1002 */       { ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1003 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1006 */             timestamp = ((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1020 */             return timestamp;case -102: timestamp = ((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, this.connection.getDbTzCalendar()); return timestamp; }  timestamp = datum.timestampValue(); }  return timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1028 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1031 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1033 */       if (datum != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1038 */         int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/*      */ 
/*      */         
/* 1041 */         if (datum instanceof CHAR && (i == -15 || i == -9)) {
/*      */ 
/*      */           
/* 1044 */           DBConversion dBConversion = this.connection.conversion;
/* 1045 */           byte[] arrayOfByte = datum.shareBytes();
/*      */           
/* 1047 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 12);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1052 */         return datum.asciiStreamValue();
/*      */       } 
/*      */       
/* 1055 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1063 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1066 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1068 */       if (datum != null) {
/*      */         
/* 1070 */         DBConversion dBConversion = this.connection.conversion;
/* 1071 */         byte[] arrayOfByte = datum.shareBytes();
/*      */         
/* 1073 */         if (datum instanceof RAW)
/*      */         {
/* 1075 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */         }
/*      */         
/* 1078 */         if (datum instanceof CHAR)
/*      */         {
/* 1080 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1085 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/* 1086 */         sQLException.fillInStackTrace();
/* 1087 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1091 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1099 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1102 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1104 */       if (datum != null)
/*      */       {
/* 1106 */         return datum.binaryStreamValue();
/*      */       }
/*      */       
/* 1109 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 1119 */     return getObject(paramInt, this.connection.getTypeMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1127 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1130 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1132 */       if (datum != null)
/*      */       {
/* 1134 */         return datum.characterStreamValue();
/*      */       }
/*      */       
/* 1137 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1147 */     return getBigDecimal(paramInt, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/* 1156 */     ClassRef classRef = null;
/*      */     try {
/* 1158 */       classRef = ClassRef.newInstance("oracle.xdb.XMLType");
/*      */     }
/* 1160 */     catch (ClassNotFoundException classNotFoundException) {}
/* 1161 */     XMLTYPE_CLASS = classRef;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1169 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1172 */       Object object = null;
/* 1173 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1175 */       if (datum != null)
/*      */       
/* 1177 */       { int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/*      */         
/* 1179 */         switch (i)
/*      */         
/*      */         { case 2002:
/* 1182 */             object = ((STRUCT)datum).toJdbc(paramMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1228 */             return object;case 91: if (this.connection.mapDateToTimestamp) { object = datum.toJdbc(); } else { object = datum.dateValue(); }  return object;case 93: if (datum instanceof DATE) { if (this.connection.mapDateToTimestamp) { object = datum.toJdbc(); } else { object = datum.dateValue(); }  } else if (this.connection.j2ee13Compliant) { object = datum.toJdbc(); } else { object = datum; }  return object;case -102: case -101: object = datum; return object;case 2007: object = ((OPAQUE)datum).toJdbc(paramMap); return object; }  object = datum.toJdbc(); }  return object;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1236 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1239 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1247 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1250 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1258 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1261 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1270 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1273 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1282 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1285 */       Datum datum = getOracleObject(paramInt);
/* 1286 */       Date date = null;
/*      */       
/* 1288 */       if (datum != null)
/*      */       { Calendar calendar;
/* 1290 */         ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1291 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1294 */             date = new Date(((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection).getTime());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1311 */             return date;case -102: calendar = this.connection.getDbTzCalendar(); date = new Date(((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar).getTime()); return date; }  date = new Date(datum.timestampValue(paramCalendar).getTime()); }  return date;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1320 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1323 */       Datum datum = getOracleObject(paramInt);
/* 1324 */       Time time = null;
/*      */       
/* 1326 */       if (datum != null)
/*      */       { Calendar calendar;
/* 1328 */         ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1329 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1332 */             time = new Time(((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection).getTime());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1346 */             return time;case -102: calendar = this.connection.getDbTzCalendar(); time = new Time(((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar).getTime()); return time; }  time = new Time(datum.timestampValue(paramCalendar).getTime()); }  return time;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1355 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1358 */       Datum datum = getOracleObject(paramInt);
/* 1359 */       Timestamp timestamp = null;
/*      */       
/* 1361 */       if (datum != null)
/*      */       { Calendar calendar;
/* 1363 */         ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1364 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1367 */             timestamp = ((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1381 */             return timestamp;case -102: calendar = this.connection.getDbTzCalendar(); timestamp = ((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar); return timestamp; }  timestamp = datum.timestampValue(paramCalendar); }  return timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1389 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1392 */       URL uRL = null;
/*      */       
/* 1394 */       int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/* 1395 */       int j = SQLUtil.getInternalType(i);
/*      */ 
/*      */       
/* 1398 */       if (j == 96 || j == 1 || j == 8) {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/* 1403 */           String str = getString(paramInt);
/* 1404 */           if (str == null) { uRL = null; }
/* 1405 */           else { uRL = new URL(str); }
/*      */         
/* 1407 */         } catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */           
/* 1410 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 1411 */           sQLException.fillInStackTrace();
/* 1412 */           throw sQLException;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1419 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Conversion to java.net.URL not supported.");
/* 1420 */         sQLException.fillInStackTrace();
/* 1421 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1425 */       return uRL;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 1433 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1437 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/* 1438 */       sQLException.fillInStackTrace();
/* 1439 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 1449 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1452 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1454 */       if (datum != null) {
/*      */         
/* 1456 */         if (datum instanceof ROWID) {
/* 1457 */           return (ROWID)datum;
/*      */         }
/*      */         
/* 1460 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/* 1461 */         sQLException.fillInStackTrace();
/* 1462 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1466 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1474 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1477 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1479 */       if (datum != null) {
/*      */         
/* 1481 */         if (datum instanceof NUMBER) {
/* 1482 */           return (NUMBER)datum;
/*      */         }
/*      */         
/* 1485 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/* 1486 */         sQLException.fillInStackTrace();
/* 1487 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1491 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 1499 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1502 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1504 */       if (datum != null) {
/*      */         
/* 1506 */         if (datum instanceof DATE)
/* 1507 */           return (DATE)datum; 
/* 1508 */         if (datum instanceof TIMESTAMP)
/* 1509 */           return TIMESTAMP.toDATE(datum.getBytes()); 
/* 1510 */         if (datum instanceof TIMESTAMPLTZ)
/* 1511 */           return TIMESTAMPLTZ.toDATE((Connection)this.connection, datum.getBytes()); 
/* 1512 */         if (datum instanceof TIMESTAMPTZ) {
/* 1513 */           return TIMESTAMPTZ.toDATE((Connection)this.connection, datum.getBytes());
/*      */         }
/*      */         
/* 1516 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/* 1517 */         sQLException.fillInStackTrace();
/* 1518 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1522 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1530 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1533 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1535 */       if (datum != null) {
/*      */         
/* 1537 */         if (datum instanceof TIMESTAMP)
/* 1538 */           return (TIMESTAMP)datum; 
/* 1539 */         if (datum instanceof TIMESTAMPLTZ)
/* 1540 */           return TIMESTAMPLTZ.toTIMESTAMP((Connection)this.connection, datum.getBytes()); 
/* 1541 */         if (datum instanceof TIMESTAMPTZ)
/* 1542 */           return TIMESTAMPTZ.toTIMESTAMP((Connection)this.connection, datum.getBytes()); 
/* 1543 */         if (datum instanceof DATE) {
/* 1544 */           return new TIMESTAMP((DATE)datum);
/*      */         }
/*      */         
/* 1547 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/* 1548 */         sQLException.fillInStackTrace();
/* 1549 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1553 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1561 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1564 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1566 */       if (datum != null) {
/*      */         
/* 1568 */         if (datum instanceof TIMESTAMPTZ)
/* 1569 */           return (TIMESTAMPTZ)datum; 
/* 1570 */         if (datum instanceof TIMESTAMPLTZ) {
/* 1571 */           return TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.connection, datum.getBytes());
/*      */         }
/*      */         
/* 1574 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/* 1575 */         sQLException.fillInStackTrace();
/* 1576 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1580 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1588 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1591 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1593 */       if (datum != null) {
/*      */         
/* 1595 */         if (datum instanceof TIMESTAMPLTZ) {
/* 1596 */           return (TIMESTAMPLTZ)datum;
/*      */         }
/*      */         
/* 1599 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/* 1600 */         sQLException.fillInStackTrace();
/* 1601 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1605 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1613 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1616 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1618 */       if (datum != null) {
/*      */         
/* 1620 */         if (datum instanceof INTERVALDS) {
/* 1621 */           return (INTERVALDS)datum;
/*      */         }
/*      */         
/* 1624 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
/* 1625 */         sQLException.fillInStackTrace();
/* 1626 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1630 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1638 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1641 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1643 */       if (datum != null) {
/*      */         
/* 1645 */         if (datum instanceof INTERVALYM) {
/* 1646 */           return (INTERVALYM)datum;
/*      */         }
/*      */         
/* 1649 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
/* 1650 */         sQLException.fillInStackTrace();
/* 1651 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1655 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 1663 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1666 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1668 */       if (datum != null) {
/*      */         
/* 1670 */         if (datum instanceof ARRAY) {
/* 1671 */           return (ARRAY)datum;
/*      */         }
/*      */         
/* 1674 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/* 1675 */         sQLException.fillInStackTrace();
/* 1676 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1680 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1688 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1691 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1693 */       if (datum != null) {
/*      */         
/* 1695 */         if (datum instanceof STRUCT) {
/* 1696 */           return (STRUCT)datum;
/*      */         }
/*      */         
/* 1699 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/* 1700 */         sQLException.fillInStackTrace();
/* 1701 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1705 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1713 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1716 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1718 */       if (datum != null) {
/*      */         
/* 1720 */         if (datum instanceof OPAQUE) {
/* 1721 */           return (OPAQUE)datum;
/*      */         }
/*      */         
/* 1724 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/* 1725 */         sQLException.fillInStackTrace();
/* 1726 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1730 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 1738 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1741 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1743 */       if (datum != null) {
/*      */         
/* 1745 */         if (datum instanceof REF) {
/* 1746 */           return (REF)datum;
/*      */         }
/*      */         
/* 1749 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/* 1750 */         sQLException.fillInStackTrace();
/* 1751 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1755 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1763 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1766 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1768 */       if (datum != null) {
/*      */         
/* 1770 */         if (datum instanceof CHAR) {
/* 1771 */           return (CHAR)datum;
/*      */         }
/*      */         
/* 1774 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/* 1775 */         sQLException.fillInStackTrace();
/* 1776 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1780 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1788 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1791 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1793 */       if (datum != null) {
/*      */         
/* 1795 */         if (datum instanceof RAW) {
/* 1796 */           return (RAW)datum;
/*      */         }
/*      */         
/* 1799 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/* 1800 */         sQLException.fillInStackTrace();
/* 1801 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1805 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1813 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1816 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1818 */       if (datum != null) {
/*      */         
/* 1820 */         if (datum instanceof BLOB) {
/* 1821 */           return (BLOB)datum;
/*      */         }
/*      */         
/* 1824 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/* 1825 */         sQLException.fillInStackTrace();
/* 1826 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1830 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1838 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1841 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1843 */       if (datum != null) {
/*      */         
/* 1845 */         if (datum instanceof CLOB) {
/* 1846 */           return (CLOB)datum;
/*      */         }
/*      */         
/* 1849 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 1850 */         sQLException.fillInStackTrace();
/* 1851 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1855 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NCLOB getNCLOB(int paramInt) throws SQLException {
/* 1866 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1869 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1871 */       if (datum != null) {
/*      */         
/* 1873 */         if (datum instanceof NCLOB) {
/* 1874 */           return (NCLOB)datum;
/*      */         }
/*      */         
/* 1877 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 1878 */         sQLException.fillInStackTrace();
/* 1879 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1883 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1892 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1895 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1897 */       if (datum != null) {
/*      */         
/* 1899 */         if (datum instanceof BFILE) {
/* 1900 */           return (BFILE)datum;
/*      */         }
/*      */         
/* 1903 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/* 1904 */         sQLException.fillInStackTrace();
/* 1905 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1909 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1918 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1921 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1930 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1933 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1938 */       return paramCustomDatumFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1947 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1950 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1955 */       return paramORADataFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1963 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1969 */       return paramOracleDataFactory.create(getObject(paramInt), 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 1983 */     NCLOB nCLOB = getNCLOB(paramInt);
/*      */     
/* 1985 */     if (nCLOB == null) return null;
/*      */     
/* 1987 */     if (!(nCLOB instanceof NClob)) {
/*      */       
/* 1989 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 1990 */       sQLException.fillInStackTrace();
/* 1991 */       throw sQLException;
/*      */     } 
/*      */     
/* 1994 */     return (NClob)nCLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 2001 */     return getString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 2008 */     return getCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 2015 */     return (RowId)getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 2022 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 2024 */     if (datum != null) {
/*      */       
/* 2026 */       if (datum instanceof SQLXML) {
/* 2027 */         return (SQLXML)datum;
/*      */       }
/*      */       
/* 2030 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSQLXML");
/* 2031 */       sQLException.fillInStackTrace();
/* 2032 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2036 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 2048 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2051 */       return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, (OracleStatement)this.scrollStmt, this.beginColumnIndex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 2060 */     synchronized (this.connection) {
/*      */       
/* 2062 */       if (this.closed) {
/*      */         
/* 2064 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 2065 */         sQLException.fillInStackTrace();
/* 2066 */         throw sQLException;
/*      */       } 
/* 2068 */       return this.resultSet.findColumn(paramString) - this.beginColumnIndex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 2079 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2082 */       if (paramInt == 1000) {
/*      */         
/* 2084 */         this.usrFetchDirection = paramInt;
/*      */       }
/* 2086 */       else if (paramInt == 1001 || paramInt == 1002) {
/*      */ 
/*      */         
/* 2089 */         this.usrFetchDirection = paramInt;
/*      */         
/* 2091 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2098 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 2099 */         sQLException.fillInStackTrace();
/* 2100 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 2112 */     return 1000;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 2118 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2121 */       this.resultSet.setFetchSize(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2128 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2131 */       return this.resultSet.getFetchSize();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/* 2140 */     return this.rsetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/* 2148 */     return this.rsetConcurency;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 2163 */     if (!needIdentifier(this.rsetType, this.rsetConcurency)) {
/*      */       
/* 2165 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "refreshRow");
/* 2166 */       sQLException.fillInStackTrace();
/* 2167 */       throw sQLException;
/*      */     } 
/*      */     
/* 2170 */     if (isValidRow(this.currentRow)) {
/*      */       
/* 2172 */       int i = getFetchDirection();
/*      */ 
/*      */       
/*      */       try {
/* 2176 */         refreshRowsInCache(this.currentRow, getFetchSize(), i);
/*      */       }
/* 2178 */       catch (SQLException sQLException1) {
/*      */ 
/*      */         
/* 2181 */         SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), sQLException1, 90, "Unsupported syntax for refreshRow()");
/* 2182 */         sQLException2.fillInStackTrace();
/* 2183 */         throw sQLException2;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2189 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "refreshRow");
/* 2190 */       sQLException.fillInStackTrace();
/* 2191 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isEmptyResultSet() throws SQLException {
/* 2207 */     if (this.numRowsCached != 0)
/*      */     {
/* 2209 */       return false;
/*      */     }
/* 2211 */     if (this.numRowsCached == 0 && this.allRowsCached)
/*      */     {
/* 2213 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 2217 */     return !isValidRow(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isValidRow(int paramInt) throws SQLException {
/* 2230 */     if (paramInt > 0 && paramInt <= this.numRowsCached)
/*      */     {
/* 2232 */       return true;
/*      */     }
/* 2234 */     if (paramInt <= 0)
/*      */     {
/* 2236 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2240 */     return cacheRowAt(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cacheCurrentRow(OracleResultSetImpl paramOracleResultSetImpl, int paramInt) throws SQLException {
/* 2251 */     for (byte b = 0; b < getColumnCount(); b++) {
/*      */ 
/*      */       
/* 2254 */       byte[] arrayOfByte = paramOracleResultSetImpl.privateGetBytes(b + 1);
/* 2255 */       OracleResultSet.AuthorizationIndicator authorizationIndicator = paramOracleResultSetImpl.getAuthorizationIndicator(b + 1);
/*      */       
/* 2257 */       CachedRowElement cachedRowElement = new CachedRowElement(paramInt, b + 1, authorizationIndicator, arrayOfByte);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2262 */       int i = (paramOracleResultSetImpl.statement.accessors[b]).internalType;
/*      */       
/* 2264 */       if (i == 112) {
/*      */         
/* 2266 */         CLOB cLOB = paramOracleResultSetImpl.getCLOB(b + 1);
/* 2267 */         cachedRowElement.setData((Datum)cLOB);
/*      */       }
/* 2269 */       else if (i == 113) {
/*      */         
/* 2271 */         BLOB bLOB = paramOracleResultSetImpl.getBLOB(b + 1);
/* 2272 */         cachedRowElement.setData((Datum)bLOB);
/*      */       } 
/*      */       
/* 2275 */       putCachedValueAt(paramInt, b + 1, cachedRowElement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean cacheRowAt(int paramInt) throws SQLException {
/* 2291 */     while (this.numRowsCached < paramInt && this.resultSet.next()) {
/* 2292 */       cacheCurrentRow(this.resultSet, ++this.numRowsCached);
/*      */     }
/* 2294 */     if (this.numRowsCached < paramInt) {
/*      */       
/* 2296 */       this.allRowsCached = true;
/*      */       
/* 2298 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 2302 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int cacheAllRows() throws SQLException {
/* 2314 */     while (this.resultSet.next()) {
/* 2315 */       cacheCurrentRow(this.resultSet, ++this.numRowsCached);
/*      */     }
/* 2317 */     this.allRowsCached = true;
/*      */     
/* 2319 */     return this.numRowsCached;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnCount() throws SQLException {
/* 2330 */     if (this.columnCount == 0) {
/*      */ 
/*      */ 
/*      */       
/* 2334 */       int i = this.resultSet.statement.numberOfDefinePositions;
/*      */       
/* 2336 */       if (this.resultSet.statement.accessors != null && i > 0) {
/* 2337 */         this.columnCount = i;
/*      */       } else {
/* 2339 */         this.columnCount = getInternalMetadata().getColumnCount();
/*      */       } 
/*      */     } 
/* 2342 */     return this.columnCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetMetaData getInternalMetadata() throws SQLException {
/* 2353 */     if (this.metadata == null) {
/* 2354 */       this.metadata = this.resultSet.getMetaData();
/*      */     }
/* 2356 */     return this.metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getLastRow() throws SQLException {
/* 2367 */     if (!this.allRowsCached) {
/* 2368 */       cacheAllRows();
/*      */     }
/* 2370 */     return this.numRowsCached;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_refetch_size(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2383 */     byte b1 = (paramInt3 == 1001) ? -1 : 1;
/*      */ 
/*      */     
/* 2386 */     byte b2 = 0;
/*      */     
/* 2388 */     if (this.refetchRowids == null) {
/* 2389 */       this.refetchRowids = new Vector(10);
/*      */     } else {
/* 2391 */       this.refetchRowids.removeAllElements();
/*      */     } 
/*      */     
/* 2394 */     while (b2 < paramInt2 && isValidRow(paramInt1 + b2 * b1)) {
/*      */       
/* 2396 */       this.refetchRowids.addElement(getCachedDatumValueAt(paramInt1 + b2 * b1, 1));
/*      */ 
/*      */       
/* 2399 */       b2++;
/*      */     } 
/*      */     
/* 2402 */     return b2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OraclePreparedStatement prepare_refetch_statement(int paramInt) throws SQLException {
/* 2419 */     if (paramInt < 1) {
/*      */       
/* 2421 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2422 */       sQLException.fillInStackTrace();
/* 2423 */       throw sQLException;
/*      */     } 
/*      */     
/* 2426 */     PreparedStatement preparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getRefetchSqlForScrollableResultSet(this, paramInt));
/*      */ 
/*      */     
/* 2429 */     return (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepare_refetch_binds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
/* 2443 */     int i = this.scrollStmt.copyBinds((Statement)paramOraclePreparedStatement, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2463 */     for (byte b = 0; b < paramInt; b++)
/*      */     {
/* 2465 */       paramOraclePreparedStatement.setROWID(i + b + 1, this.refetchRowids.elementAt(b));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void save_refetch_results(OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2480 */     byte b = (paramInt3 == 1001) ? -1 : 1;
/*      */     
/* 2482 */     while (paramOracleResultSetImpl.next()) {
/*      */       
/* 2484 */       ROWID rOWID = paramOracleResultSetImpl.getROWID(1);
/*      */       
/* 2486 */       boolean bool = false;
/* 2487 */       int i = paramInt1;
/*      */       
/* 2489 */       while (!bool && i < paramInt1 + paramInt2 * b) {
/*      */         
/* 2491 */         if (((ROWID)getCachedDatumValueAt(i, 1)).stringValue((Connection)this.connection).equals(rOWID.stringValue((Connection)this.connection))) {
/*      */           
/* 2493 */           bool = true; continue;
/*      */         } 
/* 2495 */         i += b;
/*      */       } 
/*      */       
/* 2498 */       if (bool) {
/* 2499 */         cacheCurrentRow(paramOracleResultSetImpl, i);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Datum getCachedDatumValueAt(int paramInt1, int paramInt2) throws SQLException {
/* 2508 */     CachedRowElement cachedRowElement = null;
/*      */ 
/*      */     
/*      */     try {
/* 2512 */       cachedRowElement = (CachedRowElement)this.rsetCache.get(paramInt1, paramInt2);
/*      */     }
/* 2514 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2517 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2518 */       sQLException.fillInStackTrace();
/* 2519 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2523 */     Datum datum = null;
/*      */     
/* 2525 */     if (cachedRowElement != null) {
/*      */       
/* 2527 */       datum = cachedRowElement.getDataAsDatum();
/* 2528 */       byte[] arrayOfByte = cachedRowElement.getData();
/*      */       
/* 2530 */       if (datum == null && arrayOfByte != null && arrayOfByte.length > 0) {
/*      */ 
/*      */         
/* 2533 */         int i = getInternalMetadata().getColumnType(paramInt2);
/* 2534 */         int j = getInternalMetadata().getColumnDisplaySize(paramInt2);
/*      */         
/* 2536 */         int k = (((OracleResultSetMetaData)getInternalMetadata()).getDescription()[paramInt2 - 1]).internalType;
/*      */ 
/*      */ 
/*      */         
/* 2540 */         int m = this.scrollStmt.getMaxFieldSize();
/*      */         
/* 2542 */         if (m > 0 && m < j) {
/* 2543 */           j = m;
/*      */         }
/* 2545 */         String str = null;
/*      */         
/* 2547 */         if (i == 2006 || i == 2002 || i == 2008 || i == 2007 || i == 2003 || i == 2009)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2554 */           str = getInternalMetadata().getColumnTypeName(paramInt2);
/*      */         }
/*      */         
/* 2557 */         short s = (this.resultSet.statement.accessors[paramInt2 - 1]).formOfUse;
/*      */         
/* 2559 */         if (s == 2 && (k == 96 || k == 1 || k == 8 || k == 112)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2568 */           datum = SQLUtil.makeNDatum(this.connection, arrayOfByte, k, str, s, j);
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 2574 */           datum = SQLUtil.makeDatum(this.connection, arrayOfByte, k, str, j);
/*      */         } 
/*      */ 
/*      */         
/* 2578 */         cachedRowElement.setData(datum);
/*      */       } 
/*      */     } 
/*      */     
/* 2582 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void putCachedValueAt(int paramInt1, int paramInt2, CachedRowElement paramCachedRowElement) throws SQLException {
/*      */     try {
/* 2593 */       this.rsetCache.put(paramInt1, paramInt2, paramCachedRowElement);
/*      */     }
/* 2595 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2598 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2599 */       sQLException.fillInStackTrace();
/* 2600 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeCachedRowAt(int paramInt) throws SQLException {
/*      */     try {
/* 2612 */       this.rsetCache.remove(paramInt);
/*      */     }
/* 2614 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2617 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2618 */       sQLException.fillInStackTrace();
/* 2619 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean needIdentifier(int paramInt1, int paramInt2) {
/* 2632 */     if ((paramInt1 == 1003 && paramInt2 == 1007) || (paramInt1 == 1004 && paramInt2 == 1007))
/*      */     {
/*      */       
/* 2635 */       return false;
/*      */     }
/* 2637 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean needCache(int paramInt1, int paramInt2) {
/* 2646 */     if (paramInt1 == 1003 || (paramInt1 == 1004 && paramInt2 == 1007))
/*      */     {
/*      */       
/* 2649 */       return false;
/*      */     }
/* 2651 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean supportRefreshRow(int paramInt1, int paramInt2) {
/* 2660 */     if (paramInt1 == 1003 || (paramInt1 == 1004 && paramInt2 == 1007))
/*      */     {
/*      */       
/* 2663 */       return false;
/*      */     }
/* 2665 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getFirstUserColumnIndex() {
/* 2684 */     return this.beginColumnIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 2690 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2693 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 2694 */       sQLException.fillInStackTrace();
/* 2695 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2712 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/* 2723 */     return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2728 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\ScrollableResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */