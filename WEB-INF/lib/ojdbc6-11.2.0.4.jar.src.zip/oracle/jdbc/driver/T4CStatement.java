/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CStatement
/*      */   extends OracleStatement
/*      */ {
/*   24 */   static final byte[][][] parameterDatum = (byte[][][])null;
/*   25 */   static final OracleTypeADT[][] parameterOtype = (OracleTypeADT[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   35 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   55 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   56 */       this.oacdefSent = null;
/*      */     }
/*   58 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.doOall8");
/*      */     
/*   60 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   64 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   65 */       sQLException.fillInStackTrace();
/*   66 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   70 */     if (paramBoolean3) {
/*   71 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   73 */     int i = this.numberOfDefinePositions;
/*      */     
/*   75 */     if (this.sqlKind.isDML()) {
/*   76 */       i = 0;
/*      */     }
/*      */     
/*   79 */     if (this.accessors != null)
/*   80 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   81 */         if (this.accessors[b] != null)
/*   82 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   83 */       }   if (this.outBindAccessors != null)
/*   84 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   85 */         if (this.outBindAccessors[b] != null)
/*   86 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*   87 */       }   if (this.returnParamAccessors != null) {
/*   88 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*   89 */         if (this.returnParamAccessors[b] != null) {
/*   90 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*   97 */     if (this.bindIndicators != null) {
/*      */       
/*   99 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  102 */       int k = 0;
/*      */       
/*  104 */       if (this.ibtBindChars != null) {
/*  105 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  107 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  109 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  113 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  117 */         if (n != 0) {
/*      */ 
/*      */           
/*  120 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  124 */           if (i1 == 2) {
/*      */             
/*  126 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  131 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  137 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  139 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  141 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  143 */         this.tmpBindsByteArray = null;
/*  144 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  156 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  161 */     int[] arrayOfInt1 = this.definedColumnType;
/*  162 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  163 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  169 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  174 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  175 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  176 */       arrayOfInt1[0] = -8;
/*  177 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  178 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  179 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  180 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  186 */     allocateTmpByteArray();
/*      */     
/*  188 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  190 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  195 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, parameterDatum, parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  207 */       int j = t4C8Oall.getCursorId();
/*  208 */       if (j != 0) {
/*  209 */         this.cursorId = j;
/*      */       }
/*  211 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  213 */     catch (SQLException sQLException) {
/*      */       
/*  215 */       int j = t4C8Oall.getCursorId();
/*  216 */       if (j != 0) {
/*  217 */         this.cursorId = j;
/*      */       }
/*  219 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  222 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  227 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  237 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  240 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  242 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  246 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  258 */     super.releaseBuffers();
/*  259 */     this.tmpByteArray = null;
/*  260 */     this.tmpBindsByteArray = null;
/*      */     
/*  262 */     this.t4Connection.all8.bindChars = null;
/*  263 */     this.t4Connection.all8.bindBytes = null;
/*  264 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  271 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  284 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  295 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  303 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  305 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  311 */     if (paramInt1 < 1) {
/*      */       
/*  313 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  314 */       sQLException.fillInStackTrace();
/*  315 */       throw sQLException;
/*      */     } 
/*  317 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  321 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  327 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  333 */     else if (paramInt3 < 0) {
/*      */       
/*  335 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  336 */       sQLException.fillInStackTrace();
/*  337 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  341 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  343 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  344 */       sQLException.fillInStackTrace();
/*  345 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  352 */     int i = paramInt1 - 1;
/*      */     
/*  354 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  356 */       if (this.definedColumnType == null) {
/*      */         
/*  358 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  370 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  372 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  375 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  381 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  383 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  385 */       if (this.definedColumnSize == null) {
/*  386 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  389 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  391 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  394 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  398 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  400 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  402 */       if (this.definedColumnFormOfUse == null) {
/*  403 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  406 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  408 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  411 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  415 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  417 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  419 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  424 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  428 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  434 */           this.needToPrepareDefineBuffer = true;
/*  435 */           this.columnsDefinedByUser = true;
/*      */           
/*  437 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  438 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  447 */     synchronized (this.connection) {
/*      */       
/*  449 */       super.clearDefines();
/*  450 */       this.definedColumnType = null;
/*  451 */       this.definedColumnSize = null;
/*  452 */       this.definedColumnFormOfUse = null;
/*  453 */       this.t4Connection.all8.definesAccessors = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  471 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  500 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  509 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  510 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  511 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  513 */       int m = bool ? this.accessors.length : 1;
/*  514 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  515 */         m += bool ? -1 : 1) {
/*      */         
/*  517 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  518 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  519 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  520 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  527 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  528 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  529 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  536 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  543 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  553 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  573 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  575 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  579 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  585 */         if (!paramBoolean) {
/*      */           
/*  587 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  595 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  601 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  607 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  613 */         if (!paramBoolean) {
/*      */           
/*  615 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  623 */         if (paramBoolean && paramString != null) {
/*      */           
/*  625 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  626 */           sQLException1.fillInStackTrace();
/*  627 */           throw sQLException1;
/*      */         } 
/*      */         
/*  630 */         if (paramBoolean) {
/*  631 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  634 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  640 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  646 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  652 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  658 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  662 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  665 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  672 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  678 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  684 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  690 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  696 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  702 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  705 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  710 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  713 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  720 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  726 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  732 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  738 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  744 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  760 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  761 */         sQLException.fillInStackTrace();
/*  762 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  766 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  793 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/*  797 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/*  798 */       sQLException.fillInStackTrace();
/*  799 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  806 */       this.t4Connection.needLine();
/*  807 */       this.t4Connection.sendPiggyBackedMessages();
/*  808 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  809 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  811 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  813 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  814 */         this.accessors[b].initMetadata();
/*      */       }
/*  816 */     } catch (IOException iOException) {
/*      */       
/*  818 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  821 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  822 */       sQLException.fillInStackTrace();
/*  823 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  827 */     this.describedWithNames = true;
/*  828 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  863 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  866 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  872 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  876 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  879 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  882 */       throw sQLException;
/*      */     }
/*  884 */     catch (IOException iOException) {
/*      */       
/*  886 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  888 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  889 */       sQLException.fillInStackTrace();
/*  890 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  895 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  896 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  899 */     this.needToParse = false;
/*      */ 
/*      */     
/*  902 */     if (this.connection.calculateChecksum) {
/*  903 */       if (this.validRows > 0) {
/*  904 */         calculateCheckSum();
/*  905 */       } else if (this.rowsProcessed > 0) {
/*  906 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  908 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  918 */     if (this.definedColumnType == null) {
/*  919 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  921 */     this.aFetchWasDoneDuringDescribe = false;
/*  922 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  924 */       this.aFetchWasDoneDuringDescribe = true;
/*  925 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  929 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  930 */       this.accessors[b].initMetadata();
/*      */     }
/*  932 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  974 */         boolean bool = false;
/*  975 */         if (this.columnsDefinedByUser) {
/*  976 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  996 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1004 */           boolean bool1 = false;
/* 1005 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1006 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1008 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1013 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1014 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1020 */               bool1 = true;
/* 1021 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1022 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1026 */           if (bool1) {
/*      */             
/* 1028 */             this.definedColumnType = arrayOfInt1;
/* 1029 */             this.definedColumnSize = arrayOfInt2;
/* 1030 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1036 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1038 */         this.needToParse = false;
/* 1039 */         if (bool) {
/* 1040 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1044 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1047 */     } catch (SQLException sQLException) {
/*      */       
/* 1049 */       throw sQLException;
/*      */     }
/* 1051 */     catch (IOException iOException) {
/*      */       
/* 1053 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1054 */       calculateCheckSum();
/*      */       
/* 1056 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1057 */       sQLException.fillInStackTrace();
/* 1058 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1085 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1089 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1093 */           this.nextStream.close();
/*      */         }
/* 1095 */         catch (IOException iOException) {
/*      */           
/* 1097 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1099 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1100 */           sQLException.fillInStackTrace();
/* 1101 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1105 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1111 */       doOall8(false, false, true, false, false);
/*      */       
/* 1113 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1115 */     catch (IOException iOException) {
/*      */       
/* 1117 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1119 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1120 */       sQLException.fillInStackTrace();
/* 1121 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1142 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1144 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1146 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1149 */     } catch (IOException iOException) {
/*      */       
/* 1151 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1153 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1154 */       sQLException.fillInStackTrace();
/* 1155 */       throw sQLException;
/*      */     
/*      */     }
/* 1158 */     catch (SQLException sQLException) {
/*      */       
/* 1160 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1163 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1168 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1192 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.do_close");
/*      */     
/* 1194 */     if (this.cursorId != 0) {
/* 1195 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1198 */     this.tmpByteArray = null;
/* 1199 */     this.tmpBindsByteArray = null;
/* 1200 */     this.definedColumnType = null;
/* 1201 */     this.definedColumnSize = null;
/* 1202 */     this.definedColumnFormOfUse = null;
/* 1203 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1223 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.closeQuery");
/*      */     
/* 1225 */     if (this.streamList != null)
/*      */     {
/* 1227 */       while (this.nextStream != null) {
/*      */         try {
/* 1229 */           this.nextStream.close();
/*      */         }
/* 1231 */         catch (IOException iOException) {
/* 1232 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1234 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1235 */           sQLException.fillInStackTrace();
/* 1236 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1240 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
/* 1255 */     super(paramPhysicalConnection, 1, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/* 1257 */     this.nbPostPonedColumns = new int[1];
/* 1258 */     this.nbPostPonedColumns[0] = 0;
/* 1259 */     this.indexOfPostPonedColumn = new int[1][3];
/* 1260 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeCursorOnPlainStatement() throws SQLException {
/* 1275 */     if (this.cursorId != 0 && this.t4Connection.isLoggedOn()) {
/* 1276 */       this.t4Connection.closeCursor(this.cursorId);
/* 1277 */       setCursorId(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1283 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */