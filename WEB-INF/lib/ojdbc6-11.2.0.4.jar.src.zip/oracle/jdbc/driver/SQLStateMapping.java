/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLDataException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.SQLIntegrityConstraintViolationException;
/*     */ import java.sql.SQLInvalidAuthorizationSpecException;
/*     */ import java.sql.SQLNonTransientConnectionException;
/*     */ import java.sql.SQLNonTransientException;
/*     */ import java.sql.SQLRecoverableException;
/*     */ import java.sql.SQLSyntaxErrorException;
/*     */ import java.sql.SQLTimeoutException;
/*     */ import java.sql.SQLTransactionRollbackException;
/*     */ import java.sql.SQLTransientConnectionException;
/*     */ import java.sql.SQLTransientException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLStateMapping
/*     */ {
/*     */   public static final int SQLEXCEPTION = 0;
/*     */   public static final int SQLNONTRANSIENTEXCEPTION = 1;
/*     */   public static final int SQLTRANSIENTEXCEPTION = 2;
/*     */   public static final int SQLDATAEXCEPTION = 3;
/*     */   public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
/*     */   public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
/*     */   public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
/*     */   public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
/*     */   public static final int SQLSYNTAXERROREXCEPTION = 8;
/*     */   public static final int SQLTIMEOUTEXCEPTION = 9;
/*     */   public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
/*     */   public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
/*     */   public static final int SQLCLIENTINFOEXCEPTION = 12;
/*     */   public static final int SQLRECOVERABLEEXCEPTION = 13;
/*     */   int low;
/*     */   int high;
/*     */   public String sqlState;
/*     */   public int exception;
/*     */   static final String mappingResource = "errorMap.xml";
/*     */   static SQLStateMapping[] all;
/*     */   private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
/*     */   
/*     */   public SQLStateMapping(int paramInt1, int paramInt2, String paramString, int paramInt3) {
/*  54 */     this.low = paramInt1;
/*  55 */     this.sqlState = paramString;
/*  56 */     this.exception = paramInt3;
/*  57 */     this.high = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(int paramInt) {
/*  63 */     return (this.low <= paramInt && paramInt <= this.high);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLException newSQLException(String paramString, int paramInt) {
/*  69 */     switch (this.exception) {
/*     */       case 0:
/*  71 */         return new SQLException(paramString, this.sqlState, paramInt);
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*  76 */         return new SQLNonTransientException(paramString, this.sqlState, paramInt);
/*     */       case 2:
/*  78 */         return new SQLTransientException(paramString, this.sqlState, paramInt);
/*     */       case 3:
/*  80 */         return new SQLDataException(paramString, this.sqlState, paramInt);
/*     */       case 4:
/*  82 */         return new SQLFeatureNotSupportedException(paramString, this.sqlState, paramInt);
/*     */       case 5:
/*  84 */         return new SQLIntegrityConstraintViolationException(paramString, this.sqlState, paramInt);
/*     */       case 6:
/*  86 */         return new SQLInvalidAuthorizationSpecException(paramString, this.sqlState, paramInt);
/*     */       case 7:
/*  88 */         return new SQLNonTransientConnectionException(paramString, this.sqlState, paramInt);
/*     */       case 8:
/*  90 */         return new SQLSyntaxErrorException(paramString, this.sqlState, paramInt);
/*     */       case 9:
/*  92 */         return new SQLTimeoutException(paramString, this.sqlState, paramInt);
/*     */       case 10:
/*  94 */         return new SQLTransactionRollbackException(paramString, this.sqlState, paramInt);
/*     */       case 11:
/*  96 */         return new SQLTransientConnectionException(paramString, this.sqlState, paramInt);
/*     */       case 12:
/*  98 */         return new SQLClientInfoException(paramString, this.sqlState, paramInt, null);
/*     */       case 13:
/* 100 */         return new SQLRecoverableException(paramString, this.sqlState, paramInt);
/*     */     } 
/* 102 */     return new SQLException(paramString, this.sqlState, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean lessThan(SQLStateMapping paramSQLStateMapping) {
/* 108 */     if (this.low < paramSQLStateMapping.low) {
/* 109 */       return (this.high < paramSQLStateMapping.high);
/*     */     }
/*     */     
/* 112 */     return (this.high <= paramSQLStateMapping.high);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     return super.toString() + "(" + this.low + ", " + this.high + ", " + this.sqlState + ", " + this.exception + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/* 124 */     SQLStateMapping[] arrayOfSQLStateMapping = doGetMappings();
/* 125 */     System.out.println("a\t" + arrayOfSQLStateMapping);
/* 126 */     for (byte b = 0; b < arrayOfSQLStateMapping.length; b++) {
/* 127 */       System.out.println("low:\t" + (arrayOfSQLStateMapping[b]).low + "\thigh:\t" + (arrayOfSQLStateMapping[b]).high + "\tsqlState:\t" + (arrayOfSQLStateMapping[b]).sqlState + "\tsqlException:\t" + (arrayOfSQLStateMapping[b]).exception);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SQLStateMapping[] getMappings() {
/* 137 */     if (all == null) {
/*     */       try {
/* 139 */         all = doGetMappings();
/*     */       }
/* 141 */       catch (Throwable throwable) {
/*     */         
/* 143 */         all = new SQLStateMapping[0];
/*     */       } 
/*     */     }
/* 146 */     return all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SQLStateMapping[] doGetMappings() throws IOException {
/* 154 */     InputStream inputStream = SQLStateMapping.class.getResourceAsStream("errorMap.xml");
/* 155 */     ArrayList arrayList = new ArrayList(128);
/* 156 */     load(inputStream, arrayList);
/* 157 */     return (SQLStateMapping[])arrayList.toArray((Object[])new SQLStateMapping[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void load(InputStream paramInputStream, List paramList) throws IOException {
/* 179 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/* 180 */     Tokenizer tokenizer = new Tokenizer(bufferedReader);
/* 181 */     int i = -1;
/* 182 */     int j = -1;
/* 183 */     String str1 = null;
/* 184 */     int k = -1;
/* 185 */     String str2 = null;
/* 186 */     byte b = 0;
/*     */     String str3;
/* 188 */     while ((str3 = tokenizer.next()) != null) {
/* 189 */       switch (b) {
/*     */         case false:
/* 191 */           if (str3.equals("<")) b = 1; 
/*     */           continue;
/*     */         case true:
/* 194 */           if (str3.equals("!")) { b = 2; continue; }
/* 195 */            if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 6; continue; }
/* 196 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */ 
/*     */         
/*     */         case true:
/* 200 */           if (str3.equals("-")) { b = 3; continue; }
/* 201 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 205 */           if (str3.equals("-")) b = 4; 
/*     */           continue;
/*     */         case true:
/* 208 */           if (str3.equals("-")) { b = 5; continue; }
/* 209 */            b = 3;
/*     */           continue;
/*     */         case true:
/* 212 */           if (str3.equals(">")) { b = 1; continue; }
/* 213 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 217 */           if (str3.equals(">")) { b = 7; continue; }
/* 218 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 222 */           if (str3.equals("<")) { b = 8; continue; }
/* 223 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"<\".");
/*     */ 
/*     */         
/*     */         case true:
/* 227 */           if (str3.equals("!")) { b = 9; continue; }
/* 228 */            if (str3.equals("error")) { b = 14; continue; }
/* 229 */            if (str3.equals("/")) { b = 16; continue; }
/* 230 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".");
/*     */ 
/*     */         
/*     */         case true:
/* 234 */           if (str3.equals("-")) { b = 10; continue; }
/* 235 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 239 */           if (str3.equals("-")) { b = 11; continue; }
/* 240 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 244 */           if (str3.equals("-")) b = 12; 
/*     */           continue;
/*     */         case true:
/* 247 */           if (str3.equals("-")) { b = 13; continue; }
/* 248 */            b = 11;
/*     */           continue;
/*     */         case true:
/* 251 */           if (str3.equals(">")) { b = 7; continue; }
/* 252 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 256 */           if (str3.equals("/")) { b = 15; continue; }
/* 257 */            if (str3.equals("oraErrorFrom")) { b = 19; continue; }
/* 258 */            if (str3.equals("oraErrorTo")) { b = 21; continue; }
/* 259 */            if (str3.equals("sqlState")) { b = 23; continue; }
/* 260 */            if (str3.equals("sqlException")) { b = 25; continue; }
/* 261 */            if (str3.equals("comment")) { b = 27; continue; }
/* 262 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of " + "\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", " + "\"sqlException\", \"comment\", \"/\".");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 268 */           if (str3.equals(">")) {
/*     */             try {
/* 270 */               createOne(paramList, i, j, str1, k, str2);
/*     */             }
/* 272 */             catch (IOException iOException) {
/* 273 */               throw new IOException("Invalid error element at line " + tokenizer.lineno + " of errorMap.xml. " + iOException.getMessage());
/*     */             } 
/*     */             
/* 276 */             i = -1;
/* 277 */             j = -1;
/* 278 */             str1 = null;
/* 279 */             k = -1;
/* 280 */             str2 = null;
/* 281 */             b = 7; continue;
/*     */           } 
/* 283 */           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 287 */           if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 17; continue; }
/* 288 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */ 
/*     */         
/*     */         case true:
/* 292 */           if (str3.equals(">")) { b = 18; continue; }
/* 293 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         
/*     */         case true:
/*     */           continue;
/*     */         
/*     */         case true:
/* 299 */           if (str3.equals("=")) { b = 20; continue; }
/* 300 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 305 */             i = Integer.parseInt(str3);
/*     */           }
/* 307 */           catch (NumberFormatException numberFormatException) {
/* 308 */             throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */           } 
/*     */           
/* 311 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 314 */           if (str3.equals("=")) { b = 22; continue; }
/* 315 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 320 */             j = Integer.parseInt(str3);
/*     */           }
/* 322 */           catch (NumberFormatException numberFormatException) {
/* 323 */             throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */           } 
/*     */           
/* 326 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 329 */           if (str3.equals("=")) { b = 24; continue; }
/* 330 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/* 334 */           str1 = str3;
/* 335 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 338 */           if (str3.equals("=")) { b = 26; continue; }
/* 339 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 344 */             k = valueOf(str3);
/*     */           }
/* 346 */           catch (Exception exception) {
/* 347 */             throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected SQLException" + " subclass name.");
/*     */           } 
/*     */ 
/*     */           
/* 351 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 354 */           if (str3.equals("=")) { b = 28; continue; }
/* 355 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/* 359 */           str2 = str3;
/* 360 */           b = 14;
/*     */           continue;
/*     */       } 
/* 363 */       throw new IOException("Unknown parser state " + b + " at line " + tokenizer.lineno + " of errorMap.xml.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Tokenizer
/*     */   {
/* 381 */     int lineno = 1;
/*     */     Reader r;
/*     */     int c;
/*     */     
/*     */     Tokenizer(Reader param1Reader) throws IOException {
/* 386 */       this.r = param1Reader;
/* 387 */       this.c = param1Reader.read();
/*     */     }
/*     */     
/*     */     String next() throws IOException {
/* 391 */       StringBuffer stringBuffer = new StringBuffer(16);
/* 392 */       boolean bool = true;
/*     */       
/* 394 */       while (this.c != -1) {
/* 395 */         if (this.c == 10) this.lineno++; 
/* 396 */         if (this.c <= 32 && bool) {
/* 397 */           this.c = this.r.read();
/*     */           continue;
/*     */         } 
/* 400 */         if (this.c <= 32 && !bool) {
/* 401 */           this.c = this.r.read();
/*     */           break;
/*     */         } 
/* 404 */         if (this.c == 34) {
/* 405 */           for (; (this.c = this.r.read()) != 34; stringBuffer.append((char)this.c));
/* 406 */           this.c = this.r.read();
/*     */           break;
/*     */         } 
/* 409 */         if ((48 <= this.c && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95) {
/*     */           
/*     */           do
/*     */           {
/*     */             
/* 414 */             stringBuffer.append((char)this.c);
/*     */ 
/*     */           
/*     */           }
/* 418 */           while ((48 <= (this.c = this.r.read()) && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95);
/*     */           break;
/*     */         } 
/* 421 */         stringBuffer.append((char)this.c);
/* 422 */         this.c = this.r.read();
/*     */         break;
/*     */       } 
/* 425 */       if (stringBuffer.length() > 0) return stringBuffer.toString(); 
/* 426 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void createOne(List paramList, int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2) throws IOException {
/* 432 */     if (paramInt1 == -1) throw new IOException("oraErrorFrom is a required attribute"); 
/* 433 */     if (paramInt2 == -1) paramInt2 = paramInt1; 
/* 434 */     if (paramString1 == null || paramString1.length() == 0) throw new IOException("sqlState is a required attribute"); 
/* 435 */     if (paramInt3 == -1) throw new IOException("sqlException is a required attribute"); 
/* 436 */     if (paramString2 == null || paramString2.length() < 8) throw new IOException("a lengthy comment in required"); 
/* 437 */     SQLStateMapping sQLStateMapping = new SQLStateMapping(paramInt1, paramInt2, paramString1, paramInt3);
/* 438 */     add(paramList, sQLStateMapping);
/*     */   }
/*     */   
/*     */   static void add(List<SQLStateMapping> paramList, SQLStateMapping paramSQLStateMapping) {
/* 442 */     int i = paramList.size();
/* 443 */     for (; i > 0 && 
/* 444 */       !((SQLStateMapping)paramList.get(i - 1)).lessThan(paramSQLStateMapping); i--);
/*     */ 
/*     */ 
/*     */     
/* 448 */     paramList.add(i, paramSQLStateMapping);
/*     */   }
/*     */ 
/*     */   
/*     */   static int valueOf(String paramString) throws Exception {
/* 453 */     if (paramString.equalsIgnoreCase("SQLEXCEPTION")) return 0; 
/* 454 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION")) return 1; 
/* 455 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTEXCEPTION")) return 2; 
/* 456 */     if (paramString.equalsIgnoreCase("SQLDATAEXCEPTION")) return 3; 
/* 457 */     if (paramString.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION")) return 4; 
/* 458 */     if (paramString.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION")) return 5; 
/* 459 */     if (paramString.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION")) return 6; 
/* 460 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION")) return 7; 
/* 461 */     if (paramString.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION")) return 8; 
/* 462 */     if (paramString.equalsIgnoreCase("SQLTIMEOUTEXCEPTION")) return 9; 
/* 463 */     if (paramString.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION")) return 10; 
/* 464 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION")) return 11; 
/* 465 */     if (paramString.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION")) return 12; 
/* 466 */     if (paramString.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION")) return 13; 
/* 467 */     throw new Exception("unexpected exception name: " + paramString);
/*     */   }
/*     */ 
/*     */   
/* 471 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\SQLStateMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */