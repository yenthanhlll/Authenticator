/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.BufferedInputStream;
/*       */ import java.io.BufferedReader;
/*       */ import java.io.ByteArrayInputStream;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.io.StringReader;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.URL;
/*       */ import java.security.AccessController;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.sql.Array;
/*       */ import java.sql.BatchUpdateException;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.Date;
/*       */ import java.sql.NClob;
/*       */ import java.sql.ParameterMetaData;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.RowId;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Locale;
/*       */ import java.util.TimeZone;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OracleData;
/*       */ import oracle.jdbc.OracleParameterMetaData;
/*       */ import oracle.jdbc.internal.OraclePreparedStatement;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*       */ import oracle.jdbc.oracore.OracleTypeNUMBER;
/*       */ import oracle.jdbc.proxy.OracleProxy;
/*       */ import oracle.jdbc.proxy.ProxyFactory;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.OpaqueDescriptor;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ abstract class OraclePreparedStatement
/*       */   extends OracleStatement
/*       */   implements OraclePreparedStatement, ScrollRsetStatement
/*       */ {
/*       */   int numberOfBindRowsAllocated;
/*   112 */   static Binder theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
/*       */   
/*   114 */   static Binder theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
/*       */   
/*   116 */   Binder theVarnumNullBinder = theStaticVarnumNullBinder;
/*       */   
/*   118 */   static Binder theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
/*       */   
/*   120 */   Binder theBooleanBinder = theStaticBooleanBinder;
/*       */   
/*   122 */   static Binder theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
/*       */   
/*   124 */   Binder theByteBinder = theStaticByteBinder;
/*       */   
/*   126 */   static Binder theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
/*       */   
/*   128 */   Binder theShortBinder = theStaticShortBinder;
/*       */   
/*   130 */   static Binder theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
/*       */   
/*   132 */   Binder theIntBinder = theStaticIntBinder;
/*       */   
/*   134 */   static Binder theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
/*       */   
/*   136 */   Binder theLongBinder = theStaticLongBinder;
/*       */   
/*   138 */   static Binder theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
/*       */   
/*   140 */   Binder theFloatBinder = null;
/*       */   
/*   142 */   static Binder theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
/*       */   
/*   144 */   Binder theDoubleBinder = null;
/*       */   
/*   146 */   static Binder theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
/*       */   
/*   148 */   Binder theBigDecimalBinder = theStaticBigDecimalBinder;
/*       */   
/*   150 */   static Binder theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
/*       */   
/*   152 */   static Binder theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
/*       */   
/*   154 */   Binder theVarcharNullBinder = theStaticVarcharNullBinder;
/*       */   
/*   156 */   static Binder theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
/*       */   
/*   158 */   Binder theStringBinder = theStaticStringBinder;
/*       */   
/*   160 */   static Binder theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
/*       */   
/*   162 */   static Binder theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
/*       */   
/*   164 */   static Binder theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
/*       */   
/*   166 */   static Binder theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
/*       */   
/*       */   Binder theSetCHARBinder;
/*   169 */   Binder theSetCHARNullBinder = theStaticSetCHARNullBinder;
/*       */   
/*   171 */   static Binder theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
/*       */   
/*   173 */   static Binder theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
/*       */   
/*   175 */   static Binder theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
/*       */   
/*   177 */   Binder theFixedCHARBinder = theStaticFixedCHARBinder;
/*   178 */   Binder theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
/*       */   
/*   180 */   static Binder theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
/*       */   
/*   182 */   static Binder theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
/*       */   
/*   184 */   static Binder theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
/*       */   
/*   186 */   Binder theDateBinder = theStaticDateBinder;
/*   187 */   Binder theDateNullBinder = theStaticDateNullBinder;
/*       */   
/*   189 */   static Binder theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
/*       */   
/*   191 */   static Binder theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
/*       */   
/*   193 */   Binder theTimeBinder = theStaticTimeBinder;
/*       */   
/*   195 */   static Binder theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
/*       */   
/*   197 */   static Binder theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
/*       */   
/*   199 */   static Binder theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
/*       */   
/*   201 */   Binder theTimestampBinder = theStaticTimestampBinder;
/*   202 */   Binder theTimestampNullBinder = theStaticTimestampNullBinder;
/*       */   
/*   204 */   static Binder theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
/*       */   
/*   206 */   Binder theOracleNumberBinder = theStaticOracleNumberBinder;
/*       */   
/*   208 */   static Binder theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
/*       */   
/*   210 */   Binder theOracleDateBinder = theStaticOracleDateBinder;
/*       */   
/*   212 */   static Binder theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
/*       */   
/*   214 */   Binder theOracleTimestampBinder = theStaticOracleTimestampBinder;
/*       */   
/*   216 */   static Binder theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
/*       */   
/*   218 */   static Binder theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
/*       */   
/*   220 */   static Binder theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
/*       */   
/*   222 */   Binder theTSTZBinder = theStaticTSTZBinder;
/*   223 */   Binder theTSTZNullBinder = theStaticTSTZNullBinder;
/*       */   
/*   225 */   static Binder theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
/*       */   
/*   227 */   static Binder theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
/*       */   
/*   229 */   static Binder theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
/*       */   
/*   231 */   Binder theTSLTZBinder = theStaticTSLTZBinder;
/*   232 */   Binder theTSLTZNullBinder = theStaticTSLTZNullBinder;
/*       */   
/*   234 */   static Binder theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
/*       */   
/*   236 */   static Binder theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
/*       */   
/*   238 */   static Binder theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
/*       */   
/*   240 */   static Binder theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
/*       */   
/*   242 */   static Binder theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
/*       */   
/*       */   Binder theRowidBinder;
/*   245 */   Binder theRowidNullBinder = theStaticRowidNullBinder;
/*       */   
/*       */   Binder theURowidBinder;
/*   248 */   Binder theURowidNullBinder = theStaticURowidNullBinder;
/*       */   
/*   250 */   static Binder theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
/*       */   
/*   252 */   static Binder theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
/*       */   
/*   254 */   static Binder theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
/*       */   
/*   256 */   Binder theIntervalDSBinder = theStaticIntervalDSBinder;
/*   257 */   Binder theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
/*       */   
/*   259 */   static Binder theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
/*       */   
/*   261 */   static Binder theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
/*       */   
/*   263 */   static Binder theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
/*       */   
/*   265 */   Binder theIntervalYMBinder = theStaticIntervalYMBinder;
/*   266 */   Binder theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
/*       */   
/*   268 */   static Binder theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
/*       */   
/*   270 */   static Binder theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
/*       */   
/*   272 */   static Binder theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
/*       */   
/*   274 */   Binder theBfileBinder = theStaticBfileBinder;
/*   275 */   Binder theBfileNullBinder = theStaticBfileNullBinder;
/*       */   
/*   277 */   static Binder theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
/*       */   
/*   279 */   static Binder theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
/*       */   
/*   281 */   static Binder theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
/*       */   
/*   283 */   Binder theBlobBinder = theStaticBlobBinder;
/*   284 */   Binder theBlobNullBinder = theStaticBlobNullBinder;
/*       */   
/*   286 */   static Binder theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
/*       */   
/*   288 */   static Binder theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
/*       */   
/*   290 */   static Binder theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
/*       */   
/*   292 */   Binder theClobBinder = theStaticClobBinder;
/*   293 */   Binder theClobNullBinder = theStaticClobNullBinder;
/*       */   
/*   295 */   static Binder theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
/*       */   
/*   297 */   static Binder theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
/*       */   
/*   299 */   static Binder theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
/*       */   
/*   301 */   Binder theRawBinder = theStaticRawBinder;
/*   302 */   Binder theRawNullBinder = theStaticRawNullBinder;
/*       */   
/*   304 */   static Binder theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
/*       */   
/*   306 */   static Binder theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
/*       */   
/*   308 */   Binder thePlsqlRawBinder = theStaticPlsqlRawBinder;
/*       */   
/*   310 */   static Binder theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
/*       */   
/*   312 */   static Binder theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
/*       */   
/*   314 */   static Binder theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
/*       */   
/*   316 */   Binder theBinaryFloatBinder = theStaticBinaryFloatBinder;
/*   317 */   Binder theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
/*       */   
/*   319 */   static Binder theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
/*       */   
/*   321 */   static Binder theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
/*       */   
/*   323 */   static Binder theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
/*       */   
/*   325 */   Binder theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
/*   326 */   Binder theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
/*       */   
/*   328 */   static Binder theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
/*       */   
/*   330 */   static Binder theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
/*       */   
/*   332 */   static Binder theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
/*       */   
/*   334 */   Binder theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
/*   335 */   Binder theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
/*       */   
/*   337 */   static Binder theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
/*       */   
/*   339 */   static Binder theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
/*       */   
/*   341 */   static Binder theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   343 */   Binder theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
/*   344 */   Binder theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   346 */   static Binder theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
/*       */   
/*   348 */   Binder theLongStreamBinder = theStaticLongStreamBinder;
/*       */   
/*   350 */   static Binder theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
/*       */   
/*   352 */   Binder theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
/*   353 */   static Binder theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
/*       */ 
/*       */   
/*   356 */   static Binder theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
/*       */   
/*   358 */   Binder theLongRawStreamBinder = theStaticLongRawStreamBinder;
/*       */   
/*   360 */   static Binder theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
/*       */   
/*   362 */   Binder theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
/*   363 */   static Binder theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
/*       */ 
/*       */   
/*   366 */   static Binder theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
/*       */   
/*   368 */   static Binder theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
/*       */   
/*   370 */   static Binder theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
/*       */   
/*   372 */   Binder theNamedTypeBinder = theStaticNamedTypeBinder;
/*   373 */   Binder theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
/*       */   
/*   375 */   static Binder theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
/*       */   
/*   377 */   static Binder theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
/*       */   
/*   379 */   static Binder theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
/*       */   
/*   381 */   Binder theRefTypeBinder = theStaticRefTypeBinder;
/*   382 */   Binder theRefTypeNullBinder = theStaticRefTypeNullBinder;
/*       */   
/*   384 */   static Binder theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
/*       */   
/*   386 */   static Binder theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
/*       */   
/*   388 */   static Binder theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
/*       */   
/*   390 */   Binder thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
/*   391 */   Binder thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
/*       */   
/*   393 */   static Binder theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
/*       */   
/*   395 */   Binder theOutBinder = theStaticOutBinder;
/*       */   
/*   397 */   static Binder theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
/*       */   
/*   399 */   Binder theReturnParamBinder = theStaticReturnParamBinder;
/*       */   
/*   401 */   static Binder theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
/*       */   
/*   403 */   static Binder theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
/*       */   
/*   405 */   static Binder theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
/*       */   
/*   407 */   static Binder theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   414 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*   415 */   private static final Calendar UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
/*       */   
/*   417 */   protected Calendar cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
/*       */   
/*       */   public static final int TypeBinder_BYTELEN = 24;
/*       */   
/*   421 */   char[] digits = new char[20];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[][] binders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[][] parameterInt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   long[][] parameterLong;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   float[][] parameterFloat;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   double[][] parameterDouble;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BigDecimal[][] parameterBigDecimal;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String[][] parameterString;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Date[][] parameterDate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Time[][] parameterTime;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Timestamp[][] parameterTimestamp;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][][] parameterDatum;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[][] parameterOtype;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CLOB[] lastBoundClobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BLOB[] lastBoundBlobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PlsqlIbtBindInfo[][] parameterPlsqlIbt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] currentRowBinders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentRowCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentRowBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentRowFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentRowNeedToPrepareBinds = true;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentBatchFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentBatchNeedToPrepareBinds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatches;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatchesTail;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   class PushedBatch
/*       */   {
/*       */     int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean lastBoundNeeded;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean need_to_parse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean current_batch_need_to_prepare_binds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int first_row_in_batch;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int number_of_rows_to_be_bound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     PushedBatch next;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   879 */   int cachedBindByteSize = 0;
/*   880 */   int cachedBindCharSize = 0;
/*   881 */   int cachedBindIndicatorSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindByteLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindCharLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindIndicatorLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_TYPE_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_SIZE = 10;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int SETLOB_NO_LENGTH = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int bindBufferCapacity;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int numberOfBoundRows;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int indicatorsOffset;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int valueLengthsOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedAllBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedCharBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] lastBinders;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] lastBoundBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundByteOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   char[] lastBoundChars;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundCharOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteLens;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundInds;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundLens;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean lastBoundNeeded = false;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][] lastBoundTypeBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[] lastBoundTypeOtypes;
/*       */ 
/*       */ 
/*       */   
/*       */   InputStream[] lastBoundStream;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int STREAM_MAX_BYTES_SQL = 2147483647;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*  1102 */   private int maxCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1108 */   private int maxNCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1116 */   private int charMaxCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1124 */   private int charMaxNCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1131 */   private int maxVcsCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1138 */   private int maxVcsNCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1144 */   int maxIbtVarcharElementLength = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1152 */   private int maxStreamCharsSql = 0; protected boolean isServerCharSetFixedWidth = false; private boolean isServerNCharSetFixedWidth = false; int minVcsBindSize; int prematureBatchCount; boolean checkBindTypes = true; boolean scrollRsetTypeSolved; private static final double MIN_NUMBER = 1.0E-130D; private static final double MAX_NUMBER = 1.0E126D; int SetBigStringTryClob; static final int BSTYLE_UNKNOWN = 0; static final int BSTYLE_ORACLE = 1; static final int BSTYLE_JDBC = 2; int m_batchStyle; void allocBinds(int paramInt) throws SQLException { boolean bool = (paramInt > this.numberOfBindRowsAllocated) ? true : false; initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = paramInt * this.numberOfBindPositions; int k = i + 2 * j; if (k > this.totalBindIndicatorLength) { short[] arrayOfShort = this.bindIndicators; int i2 = this.bindIndicatorOffset; this.bindIndicatorOffset = 0; this.bindIndicators = new short[k]; this.totalBindIndicatorLength = k; if (arrayOfShort != null && bool) System.arraycopy(arrayOfShort, i2, this.bindIndicators, this.bindIndicatorOffset, i);  }  this.bindIndicatorSubRange += this.bindIndicatorOffset; this.bindIndicators[this.bindIndicatorSubRange + 0] = (short)this.numberOfBindPositions; this.indicatorsOffset = this.bindIndicatorOffset + i; this.valueLengthsOffset = this.indicatorsOffset + j; int m = this.indicatorsOffset; int n = this.valueLengthsOffset; int i1 = this.bindIndicatorSubRange + 5; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[i1 + 5] = (short)(m >> 16); this.bindIndicators[i1 + 6] = (short)(m & 0xFFFF); this.bindIndicators[i1 + 7] = (short)(n >> 16); this.bindIndicators[i1 + 8] = (short)(n & 0xFFFF); m += paramInt; n += paramInt; i1 += 10; }  }
/*       */   void initializeBinds() throws SQLException { this.numberOfBindPositions = this.sqlObject.getParameterCount(); this.numReturnParams = this.sqlObject.getReturnParameterCount(); if (this.numberOfBindPositions == 0) { this.currentRowNeedToPrepareBinds = false; return; }  this.numberOfBindRowsAllocated = this.batch; this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; this.currentRowBinders = this.binders[0]; this.currentRowCharLens = new int[this.numberOfBindPositions]; this.currentBatchCharLens = new int[this.numberOfBindPositions]; this.currentRowFormOfUse = new short[this.numberOfBindPositions]; this.currentBatchFormOfUse = new short[this.numberOfBindPositions]; this.lastBoundClobs = new CLOB[this.numberOfBindPositions]; this.lastBoundBlobs = new BLOB[this.numberOfBindPositions]; byte b1 = 1; if (this.connection.defaultnchar) b1 = 2;  for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { this.currentRowFormOfUse[b2] = b1; this.currentBatchFormOfUse[b2] = b1; }  this.lastBinders = new Binder[this.numberOfBindPositions]; this.lastBoundCharLens = new int[this.numberOfBindPositions]; this.lastBoundByteOffsets = new int[this.numberOfBindPositions]; this.lastBoundCharOffsets = new int[this.numberOfBindPositions]; this.lastBoundByteLens = new int[this.numberOfBindPositions]; this.lastBoundInds = new short[this.numberOfBindPositions]; this.lastBoundLens = new short[this.numberOfBindPositions]; this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][]; this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions]; allocBinds(this.numberOfBindRowsAllocated); }
/*       */   void growBinds(int paramInt) throws SQLException { Binder[][] arrayOfBinder = this.binders; this.binders = new Binder[paramInt][]; if (arrayOfBinder != null) System.arraycopy(arrayOfBinder, 0, this.binders, 0, this.numberOfBindRowsAllocated);  int i; for (i = this.numberOfBindRowsAllocated; i < paramInt; i++) this.binders[i] = new Binder[this.numberOfBindPositions];  allocBinds(paramInt); if (this.parameterInt != null) { int[][] arrayOfInt = this.parameterInt; this.parameterInt = new int[paramInt][]; System.arraycopy(arrayOfInt, 0, this.parameterInt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterInt[i] = new int[this.numberOfBindPositions];  }  if (this.parameterLong != null) { long[][] arrayOfLong = this.parameterLong; this.parameterLong = new long[paramInt][]; System.arraycopy(arrayOfLong, 0, this.parameterLong, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterLong[i] = new long[this.numberOfBindPositions];  }  if (this.parameterFloat != null) { float[][] arrayOfFloat = this.parameterFloat; this.parameterFloat = new float[paramInt][]; System.arraycopy(arrayOfFloat, 0, this.parameterFloat, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterFloat[i] = new float[this.numberOfBindPositions];  }  if (this.parameterDouble != null) { double[][] arrayOfDouble = this.parameterDouble; this.parameterDouble = new double[paramInt][]; System.arraycopy(arrayOfDouble, 0, this.parameterDouble, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDouble[i] = new double[this.numberOfBindPositions];  }  if (this.parameterBigDecimal != null) { BigDecimal[][] arrayOfBigDecimal = this.parameterBigDecimal; this.parameterBigDecimal = new BigDecimal[paramInt][]; System.arraycopy(arrayOfBigDecimal, 0, this.parameterBigDecimal, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterBigDecimal[i] = new BigDecimal[this.numberOfBindPositions];  }  if (this.parameterString != null) { String[][] arrayOfString = this.parameterString; this.parameterString = new String[paramInt][]; System.arraycopy(arrayOfString, 0, this.parameterString, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterString[i] = new String[this.numberOfBindPositions];  }  if (this.parameterDate != null) { Date[][] arrayOfDate = this.parameterDate; this.parameterDate = new Date[paramInt][]; System.arraycopy(arrayOfDate, 0, this.parameterDate, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDate[i] = new Date[this.numberOfBindPositions];  }  if (this.parameterTime != null) { Time[][] arrayOfTime = this.parameterTime; this.parameterTime = new Time[paramInt][]; System.arraycopy(arrayOfTime, 0, this.parameterTime, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterTime[i] = new Time[this.numberOfBindPositions];  }  if (this.parameterTimestamp != null) { Timestamp[][] arrayOfTimestamp = this.parameterTimestamp; this.parameterTimestamp = new Timestamp[paramInt][]; System.arraycopy(arrayOfTimestamp, 0, this.parameterTimestamp, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterTimestamp[i] = new Timestamp[this.numberOfBindPositions];  }  if (this.parameterDatum != null) { byte[][][] arrayOfByte = this.parameterDatum; this.parameterDatum = new byte[paramInt][][]; System.arraycopy(arrayOfByte, 0, this.parameterDatum, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDatum[i] = new byte[this.numberOfBindPositions][];  }  if (this.parameterOtype != null) { OracleTypeADT[][] arrayOfOracleTypeADT = this.parameterOtype; this.parameterOtype = new OracleTypeADT[paramInt][]; System.arraycopy(arrayOfOracleTypeADT, 0, this.parameterOtype, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterOtype[i] = new OracleTypeADT[this.numberOfBindPositions];  }  if (this.parameterStream != null) { InputStream[][] arrayOfInputStream = this.parameterStream; this.parameterStream = new InputStream[paramInt][]; System.arraycopy(arrayOfInputStream, 0, this.parameterStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterStream[i] = new InputStream[this.numberOfBindPositions];  }  if (this.userStream != null) { Object[][] arrayOfObject = this.userStream; this.userStream = new Object[paramInt][]; System.arraycopy(arrayOfObject, 0, this.userStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.userStream[i] = new Object[this.numberOfBindPositions];  }  if (this.parameterPlsqlIbt != null) { PlsqlIbtBindInfo[][] arrayOfPlsqlIbtBindInfo = this.parameterPlsqlIbt; this.parameterPlsqlIbt = new PlsqlIbtBindInfo[paramInt][]; System.arraycopy(arrayOfPlsqlIbtBindInfo, 0, this.parameterPlsqlIbt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterPlsqlIbt[i] = new PlsqlIbtBindInfo[this.numberOfBindPositions];  }  this.numberOfBindRowsAllocated = paramInt; this.currentRowNeedToPrepareBinds = true; }
/*       */   void processCompletedBindRow(int paramInt, boolean paramBoolean) throws SQLException { // Byte code:
/*       */     //   0: aload_0
/*       */     //   1: getfield numberOfBindPositions : I
/*       */     //   4: ifne -> 8
/*       */     //   7: return
/*       */     //   8: iconst_0
/*       */     //   9: istore #4
/*       */     //   11: iconst_0
/*       */     //   12: istore #5
/*       */     //   14: iconst_0
/*       */     //   15: istore #6
/*       */     //   17: aload_0
/*       */     //   18: getfield currentRank : I
/*       */     //   21: aload_0
/*       */     //   22: getfield firstRowInBatch : I
/*       */     //   25: if_icmpne -> 32
/*       */     //   28: iconst_1
/*       */     //   29: goto -> 33
/*       */     //   32: iconst_0
/*       */     //   33: istore #7
/*       */     //   35: aload_0
/*       */     //   36: getfield currentRank : I
/*       */     //   39: ifne -> 62
/*       */     //   42: aload_0
/*       */     //   43: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   46: iconst_0
/*       */     //   47: aaload
/*       */     //   48: ifnonnull -> 55
/*       */     //   51: aconst_null
/*       */     //   52: goto -> 73
/*       */     //   55: aload_0
/*       */     //   56: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   59: goto -> 73
/*       */     //   62: aload_0
/*       */     //   63: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   66: aload_0
/*       */     //   67: getfield currentRank : I
/*       */     //   70: iconst_1
/*       */     //   71: isub
/*       */     //   72: aaload
/*       */     //   73: astore #8
/*       */     //   75: aload_0
/*       */     //   76: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   79: ifnonnull -> 591
/*       */     //   82: aload_0
/*       */     //   83: getfield isAutoGeneratedKey : Z
/*       */     //   86: ifeq -> 100
/*       */     //   89: aload_0
/*       */     //   90: getfield clearParameters : Z
/*       */     //   93: ifeq -> 100
/*       */     //   96: iconst_1
/*       */     //   97: goto -> 101
/*       */     //   100: iconst_0
/*       */     //   101: istore #9
/*       */     //   103: aload #8
/*       */     //   105: ifnonnull -> 174
/*       */     //   108: iconst_0
/*       */     //   109: istore_3
/*       */     //   110: iload_3
/*       */     //   111: aload_0
/*       */     //   112: getfield numberOfBindPositions : I
/*       */     //   115: if_icmpge -> 565
/*       */     //   118: aload_0
/*       */     //   119: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   122: iload_3
/*       */     //   123: aaload
/*       */     //   124: ifnonnull -> 168
/*       */     //   127: iload #9
/*       */     //   129: ifeq -> 142
/*       */     //   132: aload_0
/*       */     //   133: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   136: iconst_0
/*       */     //   137: istore #9
/*       */     //   139: goto -> 168
/*       */     //   142: aload_0
/*       */     //   143: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   146: bipush #41
/*       */     //   148: iload_3
/*       */     //   149: iconst_1
/*       */     //   150: iadd
/*       */     //   151: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   154: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   157: astore #10
/*       */     //   159: aload #10
/*       */     //   161: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   164: pop
/*       */     //   165: aload #10
/*       */     //   167: athrow
/*       */     //   168: iinc #3, 1
/*       */     //   171: goto -> 110
/*       */     //   174: aload_0
/*       */     //   175: getfield checkBindTypes : Z
/*       */     //   178: ifeq -> 462
/*       */     //   181: aload_0
/*       */     //   182: getfield currentRank : I
/*       */     //   185: ifne -> 195
/*       */     //   188: aload_0
/*       */     //   189: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   192: goto -> 217
/*       */     //   195: aload_0
/*       */     //   196: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   199: ifnonnull -> 206
/*       */     //   202: aconst_null
/*       */     //   203: goto -> 217
/*       */     //   206: aload_0
/*       */     //   207: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   210: aload_0
/*       */     //   211: getfield currentRank : I
/*       */     //   214: iconst_1
/*       */     //   215: isub
/*       */     //   216: aaload
/*       */     //   217: astore #10
/*       */     //   219: iconst_0
/*       */     //   220: istore_3
/*       */     //   221: iload_3
/*       */     //   222: aload_0
/*       */     //   223: getfield numberOfBindPositions : I
/*       */     //   226: if_icmpge -> 459
/*       */     //   229: aload_0
/*       */     //   230: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   233: iload_3
/*       */     //   234: aaload
/*       */     //   235: ifnonnull -> 250
/*       */     //   238: iload #9
/*       */     //   240: ifeq -> 250
/*       */     //   243: aload_0
/*       */     //   244: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   247: iconst_0
/*       */     //   248: istore #9
/*       */     //   250: aload_0
/*       */     //   251: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   254: iload_3
/*       */     //   255: aaload
/*       */     //   256: astore #11
/*       */     //   258: aload #11
/*       */     //   260: ifnonnull -> 340
/*       */     //   263: aload_0
/*       */     //   264: getfield clearParameters : Z
/*       */     //   267: ifeq -> 296
/*       */     //   270: aload_0
/*       */     //   271: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   274: bipush #41
/*       */     //   276: iload_3
/*       */     //   277: iconst_1
/*       */     //   278: iadd
/*       */     //   279: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   282: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   285: astore #12
/*       */     //   287: aload #12
/*       */     //   289: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   292: pop
/*       */     //   293: aload #12
/*       */     //   295: athrow
/*       */     //   296: aload_0
/*       */     //   297: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   300: iload_3
/*       */     //   301: aload #8
/*       */     //   303: iload_3
/*       */     //   304: aaload
/*       */     //   305: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   308: aastore
/*       */     //   309: aload_0
/*       */     //   310: getfield currentRank : I
/*       */     //   313: ifne -> 327
/*       */     //   316: aload_0
/*       */     //   317: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   320: iload_3
/*       */     //   321: aaload
/*       */     //   322: aload_0
/*       */     //   323: iload_3
/*       */     //   324: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   327: aload_0
/*       */     //   328: getfield currentRowCharLens : [I
/*       */     //   331: iload_3
/*       */     //   332: iconst_m1
/*       */     //   333: iastore
/*       */     //   334: iconst_1
/*       */     //   335: istore #5
/*       */     //   337: goto -> 435
/*       */     //   340: aload #11
/*       */     //   342: getfield type : S
/*       */     //   345: istore #12
/*       */     //   347: iload #12
/*       */     //   349: aload #8
/*       */     //   351: iload_3
/*       */     //   352: aaload
/*       */     //   353: getfield type : S
/*       */     //   356: if_icmpne -> 432
/*       */     //   359: iload #12
/*       */     //   361: bipush #109
/*       */     //   363: if_icmpeq -> 373
/*       */     //   366: iload #12
/*       */     //   368: bipush #111
/*       */     //   370: if_icmpne -> 394
/*       */     //   373: aload_0
/*       */     //   374: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   377: aload_0
/*       */     //   378: getfield currentRank : I
/*       */     //   381: aaload
/*       */     //   382: iload_3
/*       */     //   383: aaload
/*       */     //   384: aload #10
/*       */     //   386: iload_3
/*       */     //   387: aaload
/*       */     //   388: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   391: ifeq -> 432
/*       */     //   394: iload #12
/*       */     //   396: bipush #9
/*       */     //   398: if_icmpne -> 435
/*       */     //   401: aload #11
/*       */     //   403: getfield bytelen : I
/*       */     //   406: ifne -> 413
/*       */     //   409: iconst_1
/*       */     //   410: goto -> 414
/*       */     //   413: iconst_0
/*       */     //   414: aload #8
/*       */     //   416: iload_3
/*       */     //   417: aaload
/*       */     //   418: getfield bytelen : I
/*       */     //   421: ifne -> 428
/*       */     //   424: iconst_1
/*       */     //   425: goto -> 429
/*       */     //   428: iconst_0
/*       */     //   429: if_icmpeq -> 435
/*       */     //   432: iconst_1
/*       */     //   433: istore #4
/*       */     //   435: aload_0
/*       */     //   436: getfield currentBatchFormOfUse : [S
/*       */     //   439: iload_3
/*       */     //   440: saload
/*       */     //   441: aload_0
/*       */     //   442: getfield currentRowFormOfUse : [S
/*       */     //   445: iload_3
/*       */     //   446: saload
/*       */     //   447: if_icmpeq -> 453
/*       */     //   450: iconst_1
/*       */     //   451: istore #4
/*       */     //   453: iinc #3, 1
/*       */     //   456: goto -> 221
/*       */     //   459: goto -> 565
/*       */     //   462: iconst_0
/*       */     //   463: istore_3
/*       */     //   464: iload_3
/*       */     //   465: aload_0
/*       */     //   466: getfield numberOfBindPositions : I
/*       */     //   469: if_icmpge -> 565
/*       */     //   472: aload_0
/*       */     //   473: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   476: iload_3
/*       */     //   477: aaload
/*       */     //   478: astore #10
/*       */     //   480: aload #10
/*       */     //   482: ifnonnull -> 559
/*       */     //   485: aload_0
/*       */     //   486: getfield clearParameters : Z
/*       */     //   489: ifeq -> 518
/*       */     //   492: aload_0
/*       */     //   493: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   496: bipush #41
/*       */     //   498: iload_3
/*       */     //   499: iconst_1
/*       */     //   500: iadd
/*       */     //   501: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   504: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   507: astore #11
/*       */     //   509: aload #11
/*       */     //   511: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   514: pop
/*       */     //   515: aload #11
/*       */     //   517: athrow
/*       */     //   518: aload_0
/*       */     //   519: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   522: iload_3
/*       */     //   523: aload #8
/*       */     //   525: iload_3
/*       */     //   526: aaload
/*       */     //   527: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   530: aastore
/*       */     //   531: aload_0
/*       */     //   532: getfield currentRank : I
/*       */     //   535: ifne -> 549
/*       */     //   538: aload_0
/*       */     //   539: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   542: iload_3
/*       */     //   543: aaload
/*       */     //   544: aload_0
/*       */     //   545: iload_3
/*       */     //   546: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   549: aload_0
/*       */     //   550: getfield currentRowCharLens : [I
/*       */     //   553: iload_3
/*       */     //   554: iconst_m1
/*       */     //   555: iastore
/*       */     //   556: iconst_1
/*       */     //   557: istore #5
/*       */     //   559: iinc #3, 1
/*       */     //   562: goto -> 464
/*       */     //   565: iload #5
/*       */     //   567: ifeq -> 588
/*       */     //   570: iload #7
/*       */     //   572: ifne -> 583
/*       */     //   575: aload_0
/*       */     //   576: getfield m_batchStyle : I
/*       */     //   579: iconst_2
/*       */     //   580: if_icmpne -> 588
/*       */     //   583: aload_0
/*       */     //   584: iconst_1
/*       */     //   585: putfield lastBoundNeeded : Z
/*       */     //   588: goto -> 1259
/*       */     //   591: aload #8
/*       */     //   593: ifnonnull -> 729
/*       */     //   596: iconst_0
/*       */     //   597: istore_3
/*       */     //   598: iload_3
/*       */     //   599: aload_0
/*       */     //   600: getfield numberOfBindPositions : I
/*       */     //   603: if_icmpge -> 1244
/*       */     //   606: aload_0
/*       */     //   607: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   610: iload_3
/*       */     //   611: aaload
/*       */     //   612: astore #9
/*       */     //   614: aload_0
/*       */     //   615: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   618: iload_3
/*       */     //   619: aaload
/*       */     //   620: astore #10
/*       */     //   622: aload #9
/*       */     //   624: ifnonnull -> 671
/*       */     //   627: aload #10
/*       */     //   629: ifnonnull -> 658
/*       */     //   632: aload_0
/*       */     //   633: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   636: bipush #41
/*       */     //   638: iload_3
/*       */     //   639: iconst_1
/*       */     //   640: iadd
/*       */     //   641: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   644: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   647: astore #11
/*       */     //   649: aload #11
/*       */     //   651: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   654: pop
/*       */     //   655: aload #11
/*       */     //   657: athrow
/*       */     //   658: aload_0
/*       */     //   659: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   662: iload_3
/*       */     //   663: aload_0
/*       */     //   664: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   667: aastore
/*       */     //   668: goto -> 723
/*       */     //   671: aload #10
/*       */     //   673: ifnull -> 723
/*       */     //   676: aload #10
/*       */     //   678: getfield defineType : I
/*       */     //   681: aload #9
/*       */     //   683: getfield type : S
/*       */     //   686: if_icmpeq -> 723
/*       */     //   689: aload_0
/*       */     //   690: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   693: getfield permitTimestampDateMismatch : Z
/*       */     //   696: ifeq -> 720
/*       */     //   699: aload #9
/*       */     //   701: getfield type : S
/*       */     //   704: sipush #180
/*       */     //   707: if_icmpne -> 720
/*       */     //   710: aload #10
/*       */     //   712: getfield defineType : I
/*       */     //   715: bipush #12
/*       */     //   717: if_icmpeq -> 723
/*       */     //   720: iconst_1
/*       */     //   721: istore #6
/*       */     //   723: iinc #3, 1
/*       */     //   726: goto -> 598
/*       */     //   729: aload_0
/*       */     //   730: getfield checkBindTypes : Z
/*       */     //   733: ifeq -> 1117
/*       */     //   736: aload_0
/*       */     //   737: getfield currentRank : I
/*       */     //   740: ifne -> 750
/*       */     //   743: aload_0
/*       */     //   744: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   747: goto -> 772
/*       */     //   750: aload_0
/*       */     //   751: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   754: ifnonnull -> 761
/*       */     //   757: aconst_null
/*       */     //   758: goto -> 772
/*       */     //   761: aload_0
/*       */     //   762: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   765: aload_0
/*       */     //   766: getfield currentRank : I
/*       */     //   769: iconst_1
/*       */     //   770: isub
/*       */     //   771: aaload
/*       */     //   772: astore #9
/*       */     //   774: iconst_0
/*       */     //   775: istore_3
/*       */     //   776: iload_3
/*       */     //   777: aload_0
/*       */     //   778: getfield numberOfBindPositions : I
/*       */     //   781: if_icmpge -> 1114
/*       */     //   784: aload_0
/*       */     //   785: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   788: iload_3
/*       */     //   789: aaload
/*       */     //   790: astore #10
/*       */     //   792: aload_0
/*       */     //   793: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   796: iload_3
/*       */     //   797: aaload
/*       */     //   798: astore #11
/*       */     //   800: aload #10
/*       */     //   802: ifnonnull -> 885
/*       */     //   805: aload_0
/*       */     //   806: getfield clearParameters : Z
/*       */     //   809: ifeq -> 849
/*       */     //   812: aload #8
/*       */     //   814: iload_3
/*       */     //   815: aaload
/*       */     //   816: aload_0
/*       */     //   817: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   820: if_acmpeq -> 849
/*       */     //   823: aload_0
/*       */     //   824: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   827: bipush #41
/*       */     //   829: iload_3
/*       */     //   830: iconst_1
/*       */     //   831: iadd
/*       */     //   832: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   835: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   838: astore #12
/*       */     //   840: aload #12
/*       */     //   842: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   845: pop
/*       */     //   846: aload #12
/*       */     //   848: athrow
/*       */     //   849: aload #8
/*       */     //   851: iload_3
/*       */     //   852: aaload
/*       */     //   853: astore #10
/*       */     //   855: aload_0
/*       */     //   856: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   859: iload_3
/*       */     //   860: aload #10
/*       */     //   862: aastore
/*       */     //   863: aload_0
/*       */     //   864: getfield currentRowCharLens : [I
/*       */     //   867: iload_3
/*       */     //   868: iconst_m1
/*       */     //   869: iastore
/*       */     //   870: aload #10
/*       */     //   872: aload_0
/*       */     //   873: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   876: if_acmpeq -> 980
/*       */     //   879: iconst_1
/*       */     //   880: istore #5
/*       */     //   882: goto -> 980
/*       */     //   885: aload #10
/*       */     //   887: getfield type : S
/*       */     //   890: istore #12
/*       */     //   892: iload #12
/*       */     //   894: aload #8
/*       */     //   896: iload_3
/*       */     //   897: aaload
/*       */     //   898: getfield type : S
/*       */     //   901: if_icmpne -> 977
/*       */     //   904: iload #12
/*       */     //   906: bipush #109
/*       */     //   908: if_icmpeq -> 918
/*       */     //   911: iload #12
/*       */     //   913: bipush #111
/*       */     //   915: if_icmpne -> 939
/*       */     //   918: aload_0
/*       */     //   919: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   922: aload_0
/*       */     //   923: getfield currentRank : I
/*       */     //   926: aaload
/*       */     //   927: iload_3
/*       */     //   928: aaload
/*       */     //   929: aload #9
/*       */     //   931: iload_3
/*       */     //   932: aaload
/*       */     //   933: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   936: ifeq -> 977
/*       */     //   939: iload #12
/*       */     //   941: bipush #9
/*       */     //   943: if_icmpne -> 980
/*       */     //   946: aload #10
/*       */     //   948: getfield bytelen : I
/*       */     //   951: ifne -> 958
/*       */     //   954: iconst_1
/*       */     //   955: goto -> 959
/*       */     //   958: iconst_0
/*       */     //   959: aload #8
/*       */     //   961: iload_3
/*       */     //   962: aaload
/*       */     //   963: getfield bytelen : I
/*       */     //   966: ifne -> 973
/*       */     //   969: iconst_1
/*       */     //   970: goto -> 974
/*       */     //   973: iconst_0
/*       */     //   974: if_icmpeq -> 980
/*       */     //   977: iconst_1
/*       */     //   978: istore #4
/*       */     //   980: aload_0
/*       */     //   981: getfield currentBatchFormOfUse : [S
/*       */     //   984: iload_3
/*       */     //   985: saload
/*       */     //   986: aload_0
/*       */     //   987: getfield currentRowFormOfUse : [S
/*       */     //   990: iload_3
/*       */     //   991: saload
/*       */     //   992: if_icmpeq -> 998
/*       */     //   995: iconst_1
/*       */     //   996: istore #4
/*       */     //   998: aload_0
/*       */     //   999: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1002: iload_3
/*       */     //   1003: aaload
/*       */     //   1004: astore #12
/*       */     //   1006: aload #11
/*       */     //   1008: ifnonnull -> 1026
/*       */     //   1011: aload #12
/*       */     //   1013: astore #11
/*       */     //   1015: aload_0
/*       */     //   1016: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1019: iload_3
/*       */     //   1020: aload #11
/*       */     //   1022: aastore
/*       */     //   1023: goto -> 1047
/*       */     //   1026: aload #12
/*       */     //   1028: ifnull -> 1047
/*       */     //   1031: aload #11
/*       */     //   1033: getfield defineType : I
/*       */     //   1036: aload #12
/*       */     //   1038: getfield defineType : I
/*       */     //   1041: if_icmpeq -> 1047
/*       */     //   1044: iconst_1
/*       */     //   1045: istore #4
/*       */     //   1047: aload #11
/*       */     //   1049: ifnull -> 1108
/*       */     //   1052: aload #10
/*       */     //   1054: aload_0
/*       */     //   1055: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1058: if_acmpeq -> 1108
/*       */     //   1061: aload #11
/*       */     //   1063: getfield defineType : I
/*       */     //   1066: aload #10
/*       */     //   1068: getfield type : S
/*       */     //   1071: if_icmpeq -> 1108
/*       */     //   1074: aload_0
/*       */     //   1075: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   1078: getfield permitTimestampDateMismatch : Z
/*       */     //   1081: ifeq -> 1105
/*       */     //   1084: aload #10
/*       */     //   1086: getfield type : S
/*       */     //   1089: sipush #180
/*       */     //   1092: if_icmpne -> 1105
/*       */     //   1095: aload #11
/*       */     //   1097: getfield defineType : I
/*       */     //   1100: bipush #12
/*       */     //   1102: if_icmpeq -> 1108
/*       */     //   1105: iconst_1
/*       */     //   1106: istore #6
/*       */     //   1108: iinc #3, 1
/*       */     //   1111: goto -> 776
/*       */     //   1114: goto -> 1244
/*       */     //   1117: iconst_0
/*       */     //   1118: istore_3
/*       */     //   1119: iload_3
/*       */     //   1120: aload_0
/*       */     //   1121: getfield numberOfBindPositions : I
/*       */     //   1124: if_icmpge -> 1244
/*       */     //   1127: aload_0
/*       */     //   1128: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1131: iload_3
/*       */     //   1132: aaload
/*       */     //   1133: astore #9
/*       */     //   1135: aload #9
/*       */     //   1137: ifnonnull -> 1217
/*       */     //   1140: aload_0
/*       */     //   1141: getfield clearParameters : Z
/*       */     //   1144: ifeq -> 1184
/*       */     //   1147: aload #8
/*       */     //   1149: iload_3
/*       */     //   1150: aaload
/*       */     //   1151: aload_0
/*       */     //   1152: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1155: if_acmpeq -> 1184
/*       */     //   1158: aload_0
/*       */     //   1159: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1162: bipush #41
/*       */     //   1164: iload_3
/*       */     //   1165: iconst_1
/*       */     //   1166: iadd
/*       */     //   1167: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   1170: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   1173: astore #10
/*       */     //   1175: aload #10
/*       */     //   1177: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1180: pop
/*       */     //   1181: aload #10
/*       */     //   1183: athrow
/*       */     //   1184: aload #8
/*       */     //   1186: iload_3
/*       */     //   1187: aaload
/*       */     //   1188: astore #9
/*       */     //   1190: aload_0
/*       */     //   1191: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1194: iload_3
/*       */     //   1195: aload #9
/*       */     //   1197: aastore
/*       */     //   1198: aload_0
/*       */     //   1199: getfield currentRowCharLens : [I
/*       */     //   1202: iload_3
/*       */     //   1203: iconst_m1
/*       */     //   1204: iastore
/*       */     //   1205: aload #9
/*       */     //   1207: aload_0
/*       */     //   1208: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1211: if_acmpeq -> 1217
/*       */     //   1214: iconst_1
/*       */     //   1215: istore #5
/*       */     //   1217: aload_0
/*       */     //   1218: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1221: iload_3
/*       */     //   1222: aaload
/*       */     //   1223: ifnonnull -> 1238
/*       */     //   1226: aload_0
/*       */     //   1227: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1230: iload_3
/*       */     //   1231: aload_0
/*       */     //   1232: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1235: iload_3
/*       */     //   1236: aaload
/*       */     //   1237: aastore
/*       */     //   1238: iinc #3, 1
/*       */     //   1241: goto -> 1119
/*       */     //   1244: iload #5
/*       */     //   1246: ifeq -> 1259
/*       */     //   1249: iload #7
/*       */     //   1251: ifeq -> 1259
/*       */     //   1254: aload_0
/*       */     //   1255: iconst_1
/*       */     //   1256: putfield lastBoundNeeded : Z
/*       */     //   1259: iload #4
/*       */     //   1261: ifeq -> 1360
/*       */     //   1264: iload #7
/*       */     //   1266: ifne -> 1342
/*       */     //   1269: aload_0
/*       */     //   1270: getfield m_batchStyle : I
/*       */     //   1273: iconst_2
/*       */     //   1274: if_icmpne -> 1285
/*       */     //   1277: aload_0
/*       */     //   1278: iconst_0
/*       */     //   1279: invokevirtual pushBatch : (Z)V
/*       */     //   1282: goto -> 1342
/*       */     //   1285: aload_0
/*       */     //   1286: getfield validRows : I
/*       */     //   1289: istore #9
/*       */     //   1291: aload_0
/*       */     //   1292: aload_0
/*       */     //   1293: invokevirtual sendBatch : ()I
/*       */     //   1296: putfield prematureBatchCount : I
/*       */     //   1299: aload_0
/*       */     //   1300: iload #9
/*       */     //   1302: putfield validRows : I
/*       */     //   1305: iconst_0
/*       */     //   1306: istore_3
/*       */     //   1307: iload_3
/*       */     //   1308: aload_0
/*       */     //   1309: getfield numberOfBindPositions : I
/*       */     //   1312: if_icmpge -> 1332
/*       */     //   1315: aload_0
/*       */     //   1316: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1319: iload_3
/*       */     //   1320: aaload
/*       */     //   1321: aload_0
/*       */     //   1322: iload_3
/*       */     //   1323: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   1326: iinc #3, 1
/*       */     //   1329: goto -> 1307
/*       */     //   1332: iload #5
/*       */     //   1334: ifeq -> 1342
/*       */     //   1337: aload_0
/*       */     //   1338: iconst_1
/*       */     //   1339: putfield lastBoundNeeded : Z
/*       */     //   1342: aload_0
/*       */     //   1343: iconst_1
/*       */     //   1344: putfield needToParse : Z
/*       */     //   1347: aload_0
/*       */     //   1348: iconst_1
/*       */     //   1349: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1352: aload_0
/*       */     //   1353: iconst_1
/*       */     //   1354: putfield needToPrepareDefineBuffer : Z
/*       */     //   1357: goto -> 1379
/*       */     //   1360: iload_2
/*       */     //   1361: ifeq -> 1379
/*       */     //   1364: aload_0
/*       */     //   1365: iconst_0
/*       */     //   1366: invokevirtual pushBatch : (Z)V
/*       */     //   1369: aload_0
/*       */     //   1370: iconst_0
/*       */     //   1371: putfield needToParse : Z
/*       */     //   1374: aload_0
/*       */     //   1375: iconst_0
/*       */     //   1376: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1379: iload #6
/*       */     //   1381: ifeq -> 1404
/*       */     //   1384: aload_0
/*       */     //   1385: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1388: bipush #12
/*       */     //   1390: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;I)Ljava/sql/SQLException;
/*       */     //   1393: astore #9
/*       */     //   1395: aload #9
/*       */     //   1397: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1400: pop
/*       */     //   1401: aload #9
/*       */     //   1403: athrow
/*       */     //   1404: iconst_0
/*       */     //   1405: istore_3
/*       */     //   1406: iload_3
/*       */     //   1407: aload_0
/*       */     //   1408: getfield numberOfBindPositions : I
/*       */     //   1411: if_icmpge -> 1491
/*       */     //   1414: aload_0
/*       */     //   1415: getfield currentRowCharLens : [I
/*       */     //   1418: iload_3
/*       */     //   1419: iaload
/*       */     //   1420: istore #9
/*       */     //   1422: iload #9
/*       */     //   1424: iconst_m1
/*       */     //   1425: if_icmpne -> 1447
/*       */     //   1428: aload_0
/*       */     //   1429: getfield currentRank : I
/*       */     //   1432: aload_0
/*       */     //   1433: getfield firstRowInBatch : I
/*       */     //   1436: if_icmpne -> 1447
/*       */     //   1439: aload_0
/*       */     //   1440: getfield lastBoundCharLens : [I
/*       */     //   1443: iload_3
/*       */     //   1444: iaload
/*       */     //   1445: istore #9
/*       */     //   1447: aload_0
/*       */     //   1448: getfield currentBatchCharLens : [I
/*       */     //   1451: iload_3
/*       */     //   1452: iaload
/*       */     //   1453: iload #9
/*       */     //   1455: if_icmpge -> 1466
/*       */     //   1458: aload_0
/*       */     //   1459: getfield currentBatchCharLens : [I
/*       */     //   1462: iload_3
/*       */     //   1463: iload #9
/*       */     //   1465: iastore
/*       */     //   1466: aload_0
/*       */     //   1467: getfield currentRowCharLens : [I
/*       */     //   1470: iload_3
/*       */     //   1471: iconst_0
/*       */     //   1472: iastore
/*       */     //   1473: aload_0
/*       */     //   1474: getfield currentBatchFormOfUse : [S
/*       */     //   1477: iload_3
/*       */     //   1478: aload_0
/*       */     //   1479: getfield currentRowFormOfUse : [S
/*       */     //   1482: iload_3
/*       */     //   1483: saload
/*       */     //   1484: sastore
/*       */     //   1485: iinc #3, 1
/*       */     //   1488: goto -> 1406
/*       */     //   1491: aload_0
/*       */     //   1492: getfield currentRowNeedToPrepareBinds : Z
/*       */     //   1495: ifeq -> 1503
/*       */     //   1498: aload_0
/*       */     //   1499: iconst_1
/*       */     //   1500: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1503: aload_0
/*       */     //   1504: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1507: ifnull -> 1568
/*       */     //   1510: aload_0
/*       */     //   1511: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1514: astore #9
/*       */     //   1516: aload_0
/*       */     //   1517: aload_0
/*       */     //   1518: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1521: putfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1524: aload #9
/*       */     //   1526: ifnonnull -> 1541
/*       */     //   1529: aload_0
/*       */     //   1530: getfield numberOfBindPositions : I
/*       */     //   1533: anewarray oracle/jdbc/driver/Accessor
/*       */     //   1536: astore #9
/*       */     //   1538: goto -> 1562
/*       */     //   1541: iconst_0
/*       */     //   1542: istore_3
/*       */     //   1543: iload_3
/*       */     //   1544: aload_0
/*       */     //   1545: getfield numberOfBindPositions : I
/*       */     //   1548: if_icmpge -> 1562
/*       */     //   1551: aload #9
/*       */     //   1553: iload_3
/*       */     //   1554: aconst_null
/*       */     //   1555: aastore
/*       */     //   1556: iinc #3, 1
/*       */     //   1559: goto -> 1543
/*       */     //   1562: aload_0
/*       */     //   1563: aload #9
/*       */     //   1565: putfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1568: aload_0
/*       */     //   1569: getfield currentRank : I
/*       */     //   1572: iconst_1
/*       */     //   1573: iadd
/*       */     //   1574: istore #9
/*       */     //   1576: iload #9
/*       */     //   1578: iload_1
/*       */     //   1579: if_icmpge -> 1652
/*       */     //   1582: iload #9
/*       */     //   1584: aload_0
/*       */     //   1585: getfield numberOfBindRowsAllocated : I
/*       */     //   1588: if_icmplt -> 1638
/*       */     //   1591: aload_0
/*       */     //   1592: getfield numberOfBindRowsAllocated : I
/*       */     //   1595: iconst_1
/*       */     //   1596: ishl
/*       */     //   1597: istore #10
/*       */     //   1599: iload #10
/*       */     //   1601: iload #9
/*       */     //   1603: if_icmpgt -> 1612
/*       */     //   1606: iload #9
/*       */     //   1608: iconst_1
/*       */     //   1609: iadd
/*       */     //   1610: istore #10
/*       */     //   1612: aload_0
/*       */     //   1613: iload #10
/*       */     //   1615: invokevirtual growBinds : (I)V
/*       */     //   1618: aload_0
/*       */     //   1619: iconst_1
/*       */     //   1620: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1623: aload_0
/*       */     //   1624: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1627: ifnull -> 1638
/*       */     //   1630: aload_0
/*       */     //   1631: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1634: iconst_1
/*       */     //   1635: putfield current_batch_need_to_prepare_binds : Z
/*       */     //   1638: aload_0
/*       */     //   1639: aload_0
/*       */     //   1640: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1643: iload #9
/*       */     //   1645: aaload
/*       */     //   1646: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1649: goto -> 1668
/*       */     //   1652: aload_0
/*       */     //   1653: iconst_0
/*       */     //   1654: iload_1
/*       */     //   1655: invokevirtual setupBindBuffers : (II)V
/*       */     //   1658: aload_0
/*       */     //   1659: aload_0
/*       */     //   1660: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1663: iconst_0
/*       */     //   1664: aaload
/*       */     //   1665: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1668: aload_0
/*       */     //   1669: iconst_0
/*       */     //   1670: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1673: aload_0
/*       */     //   1674: iconst_0
/*       */     //   1675: putfield clearParameters : Z
/*       */     //   1678: return
/*       */     // Line number table:
/*       */     //   Java source line number -> byte code offset
/*       */     //   #1805	-> 0
/*       */     //   #1808	-> 7
/*       */     //   #1811	-> 8
/*       */     //   #1812	-> 11
/*       */     //   #1813	-> 14
/*       */     //   #1814	-> 17
/*       */     //   #1821	-> 35
/*       */     //   #1825	-> 75
/*       */     //   #1827	-> 82
/*       */     //   #1830	-> 103
/*       */     //   #1834	-> 108
/*       */     //   #1835	-> 118
/*       */     //   #1837	-> 127
/*       */     //   #1839	-> 132
/*       */     //   #1840	-> 136
/*       */     //   #1843	-> 142
/*       */     //   #1844	-> 159
/*       */     //   #1845	-> 165
/*       */     //   #1834	-> 168
/*       */     //   #1849	-> 174
/*       */     //   #1854	-> 181
/*       */     //   #1858	-> 219
/*       */     //   #1860	-> 229
/*       */     //   #1862	-> 243
/*       */     //   #1863	-> 247
/*       */     //   #1865	-> 250
/*       */     //   #1867	-> 258
/*       */     //   #1872	-> 263
/*       */     //   #1874	-> 270
/*       */     //   #1875	-> 287
/*       */     //   #1876	-> 293
/*       */     //   #1885	-> 296
/*       */     //   #1888	-> 309
/*       */     //   #1889	-> 316
/*       */     //   #1896	-> 327
/*       */     //   #1902	-> 334
/*       */     //   #1906	-> 340
/*       */     //   #1908	-> 347
/*       */     //   #1917	-> 432
/*       */     //   #1920	-> 435
/*       */     //   #1924	-> 450
/*       */     //   #1858	-> 453
/*       */     //   #1927	-> 459
/*       */     //   #1933	-> 462
/*       */     //   #1935	-> 472
/*       */     //   #1937	-> 480
/*       */     //   #1942	-> 485
/*       */     //   #1944	-> 492
/*       */     //   #1945	-> 509
/*       */     //   #1946	-> 515
/*       */     //   #1955	-> 518
/*       */     //   #1958	-> 531
/*       */     //   #1959	-> 538
/*       */     //   #1965	-> 549
/*       */     //   #1971	-> 556
/*       */     //   #1933	-> 559
/*       */     //   #1976	-> 565
/*       */     //   #1978	-> 583
/*       */     //   #1979	-> 588
/*       */     //   #1984	-> 591
/*       */     //   #1990	-> 596
/*       */     //   #1992	-> 606
/*       */     //   #1993	-> 614
/*       */     //   #1995	-> 622
/*       */     //   #2000	-> 627
/*       */     //   #2005	-> 632
/*       */     //   #2006	-> 649
/*       */     //   #2007	-> 655
/*       */     //   #2013	-> 658
/*       */     //   #2015	-> 671
/*       */     //   #2023	-> 689
/*       */     //   #2027	-> 720
/*       */     //   #1990	-> 723
/*       */     //   #2032	-> 729
/*       */     //   #2039	-> 736
/*       */     //   #2043	-> 774
/*       */     //   #2045	-> 784
/*       */     //   #2046	-> 792
/*       */     //   #2048	-> 800
/*       */     //   #2054	-> 805
/*       */     //   #2057	-> 823
/*       */     //   #2058	-> 840
/*       */     //   #2059	-> 846
/*       */     //   #2070	-> 849
/*       */     //   #2071	-> 855
/*       */     //   #2072	-> 863
/*       */     //   #2074	-> 870
/*       */     //   #2080	-> 879
/*       */     //   #2084	-> 885
/*       */     //   #2086	-> 892
/*       */     //   #2095	-> 977
/*       */     //   #2098	-> 980
/*       */     //   #2102	-> 995
/*       */     //   #2104	-> 998
/*       */     //   #2106	-> 1006
/*       */     //   #2112	-> 1011
/*       */     //   #2113	-> 1015
/*       */     //   #2115	-> 1026
/*       */     //   #2120	-> 1044
/*       */     //   #2122	-> 1047
/*       */     //   #2131	-> 1074
/*       */     //   #2135	-> 1105
/*       */     //   #2043	-> 1108
/*       */     //   #2139	-> 1114
/*       */     //   #2146	-> 1117
/*       */     //   #2148	-> 1127
/*       */     //   #2150	-> 1135
/*       */     //   #2156	-> 1140
/*       */     //   #2158	-> 1158
/*       */     //   #2159	-> 1175
/*       */     //   #2160	-> 1181
/*       */     //   #2170	-> 1184
/*       */     //   #2171	-> 1190
/*       */     //   #2172	-> 1198
/*       */     //   #2174	-> 1205
/*       */     //   #2180	-> 1214
/*       */     //   #2183	-> 1217
/*       */     //   #2188	-> 1226
/*       */     //   #2146	-> 1238
/*       */     //   #2200	-> 1244
/*       */     //   #2201	-> 1254
/*       */     //   #2204	-> 1259
/*       */     //   #2208	-> 1264
/*       */     //   #2214	-> 1269
/*       */     //   #2221	-> 1277
/*       */     //   #2230	-> 1285
/*       */     //   #2232	-> 1291
/*       */     //   #2233	-> 1299
/*       */     //   #2238	-> 1305
/*       */     //   #2239	-> 1315
/*       */     //   #2238	-> 1326
/*       */     //   #2243	-> 1332
/*       */     //   #2244	-> 1337
/*       */     //   #2250	-> 1342
/*       */     //   #2254	-> 1347
/*       */     //   #2257	-> 1352
/*       */     //   #2259	-> 1360
/*       */     //   #2265	-> 1364
/*       */     //   #2269	-> 1369
/*       */     //   #2277	-> 1374
/*       */     //   #2280	-> 1379
/*       */     //   #2287	-> 1384
/*       */     //   #2288	-> 1395
/*       */     //   #2289	-> 1401
/*       */     //   #2301	-> 1404
/*       */     //   #2303	-> 1414
/*       */     //   #2305	-> 1422
/*       */     //   #2306	-> 1439
/*       */     //   #2308	-> 1447
/*       */     //   #2309	-> 1458
/*       */     //   #2311	-> 1466
/*       */     //   #2312	-> 1473
/*       */     //   #2301	-> 1485
/*       */     //   #2317	-> 1491
/*       */     //   #2318	-> 1498
/*       */     //   #2327	-> 1503
/*       */     //   #2329	-> 1510
/*       */     //   #2331	-> 1516
/*       */     //   #2333	-> 1524
/*       */     //   #2334	-> 1529
/*       */     //   #2336	-> 1541
/*       */     //   #2337	-> 1551
/*       */     //   #2336	-> 1556
/*       */     //   #2339	-> 1562
/*       */     //   #2342	-> 1568
/*       */     //   #2344	-> 1576
/*       */     //   #2349	-> 1582
/*       */     //   #2355	-> 1591
/*       */     //   #2357	-> 1599
/*       */     //   #2358	-> 1606
/*       */     //   #2360	-> 1612
/*       */     //   #2362	-> 1618
/*       */     //   #2364	-> 1623
/*       */     //   #2365	-> 1630
/*       */     //   #2369	-> 1638
/*       */     //   #2378	-> 1652
/*       */     //   #2385	-> 1658
/*       */     //   #2390	-> 1668
/*       */     //   #2392	-> 1673
/*       */     //   #2394	-> 1678 }
/*       */   void processPlsqlIndexTabBinds(int paramInt) throws SQLException { byte b1 = 0; int i = 0; int j = 0; int k = 0; Binder[] arrayOfBinder = this.binders[paramInt]; PlsqlIbtBindInfo[] arrayOfPlsqlIbtBindInfo = (this.parameterPlsqlIbt == null) ? null : this.parameterPlsqlIbt[paramInt]; int m; for (m = 0; m < this.numberOfBindPositions; m++) { Binder binder = arrayOfBinder[m]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[m]; PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : (PlsqlIndexTableAccessor)accessor; if (binder.type == 998) { PlsqlIbtBindInfo plsqlIbtBindInfo = arrayOfPlsqlIbtBindInfo[m]; if (plsqlIndexTableAccessor != null) { if (plsqlIbtBindInfo.element_internal_type != plsqlIndexTableAccessor.elementInternalType) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12); sQLException.fillInStackTrace(); throw sQLException; }  if (plsqlIbtBindInfo.maxLen < plsqlIndexTableAccessor.maxNumberOfElements) plsqlIbtBindInfo.maxLen = plsqlIndexTableAccessor.maxNumberOfElements;  if (plsqlIbtBindInfo.elemMaxLen < plsqlIndexTableAccessor.elementMaxLen) plsqlIbtBindInfo.elemMaxLen = plsqlIndexTableAccessor.elementMaxLen;  if (plsqlIbtBindInfo.ibtByteLength > 0) { plsqlIbtBindInfo.ibtByteLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen; } else { plsqlIbtBindInfo.ibtCharLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen; }  }  b1++; j += plsqlIbtBindInfo.ibtByteLength; k += plsqlIbtBindInfo.ibtCharLength; i += plsqlIbtBindInfo.maxLen; } else if (plsqlIndexTableAccessor != null) { b1++; j += plsqlIndexTableAccessor.ibtByteLength; k += plsqlIndexTableAccessor.ibtCharLength; i += plsqlIndexTableAccessor.maxNumberOfElements; }  }  if (b1 == 0) return;  this.ibtBindIndicatorSize = 6 + b1 * 8 + i * 2; this.ibtBindIndicators = new short[this.ibtBindIndicatorSize]; this.ibtBindIndicatorOffset = 0; if (j > 0) this.ibtBindBytes = new byte[j];  this.ibtBindByteOffset = 0; if (k > 0)
/*       */       this.ibtBindChars = new char[k];  this.ibtBindCharOffset = 0; m = this.ibtBindByteOffset; int n = this.ibtBindCharOffset; int i1 = this.ibtBindIndicatorOffset; int i2 = i1 + 6 + b1 * 8; this.ibtBindIndicators[i1++] = (short)(b1 >> 16); this.ibtBindIndicators[i1++] = (short)(b1 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(j >> 16); this.ibtBindIndicators[i1++] = (short)(j & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(k >> 16); this.ibtBindIndicators[i1++] = (short)(k & 0xFFFF); for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Binder binder = arrayOfBinder[b2]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[b2]; PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : (PlsqlIndexTableAccessor)accessor; if (binder.type == 998) { int i3; PlsqlIbtBindInfo plsqlIbtBindInfo = arrayOfPlsqlIbtBindInfo[b2]; int i4 = plsqlIbtBindInfo.maxLen; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo.element_internal_type; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo.elemMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo.curLen >> 16); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo.curLen & 0xFFFF); if (plsqlIbtBindInfo.ibtByteLength > 0) { i3 = m; m += plsqlIbtBindInfo.ibtByteLength; } else { i3 = n; n += plsqlIbtBindInfo.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIbtBindInfo.ibtValueIndex = i3; plsqlIbtBindInfo.ibtIndicatorIndex = i2; plsqlIbtBindInfo.ibtLengthIndex = i2 + i4; if (plsqlIndexTableAccessor != null) { plsqlIndexTableAccessor.ibtIndicatorIndex = plsqlIbtBindInfo.ibtIndicatorIndex; plsqlIndexTableAccessor.ibtLengthIndex = plsqlIbtBindInfo.ibtLengthIndex; plsqlIndexTableAccessor.ibtMetaIndex = i1 - 8; plsqlIndexTableAccessor.ibtValueIndex = i3; }  i2 += 2 * i4; } else if (plsqlIndexTableAccessor != null) { int i3, i4 = plsqlIndexTableAccessor.maxNumberOfElements; this.ibtBindIndicators[i1++] = (short)plsqlIndexTableAccessor.elementInternalType; this.ibtBindIndicators[i1++] = (short)plsqlIndexTableAccessor.elementMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = 0; this.ibtBindIndicators[i1++] = 0; if (plsqlIndexTableAccessor.ibtByteLength > 0) { i3 = m; m += plsqlIndexTableAccessor.ibtByteLength; } else { i3 = n; n += plsqlIndexTableAccessor.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIndexTableAccessor.ibtValueIndex = i3; plsqlIndexTableAccessor.ibtIndicatorIndex = i2; plsqlIndexTableAccessor.ibtLengthIndex = i2 + i4; plsqlIndexTableAccessor.ibtMetaIndex = i1 - 8; i2 += 2 * i4; }  }  }
/*       */   void initializeBindSubRanges(int paramInt1, int paramInt2) { this.bindByteSubRange = 0; this.bindCharSubRange = 0; }
/*       */   int calculateIndicatorSubRangeSize() { return 0; }
/*  1160 */   private int maxStreamNCharsSql = 0; short getInoutIndicator(int paramInt) { return 0; } void initializeIndicatorSubRange() { this.bindIndicatorSubRange = calculateIndicatorSubRangeSize(); } void prepareBindPreambles(int paramInt1, int paramInt2) {} void setupBindBuffers(int paramInt1, int paramInt2) throws SQLException { try { if (this.numberOfBindPositions == 0) { if (paramInt2 != 0) { if (this.bindIndicators == null)
/*       */             allocBinds(paramInt2);  this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); }  return; }  this.preparedAllBinds = this.currentBatchNeedToPrepareBinds; this.preparedCharBinds = false; this.currentBatchNeedToPrepareBinds = false; this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); int i = this.bindBufferCapacity; if (this.numberOfBoundRows > this.bindBufferCapacity) { i = this.numberOfBoundRows; this.preparedAllBinds = true; }  if (this.currentBatchBindAccessors != null) { if (this.outBindAccessors == null)
/*       */           this.outBindAccessors = new Accessor[this.numberOfBindPositions];  for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { Accessor accessor = this.currentBatchBindAccessors[b1]; this.outBindAccessors[b1] = accessor; if (accessor != null) { int i8 = accessor.charLength; if (i8 == 0 || this.currentBatchCharLens[b1] < i8)
/*       */               this.currentBatchCharLens[b1] = i8;  }  }  }  int j = 0; int k = 0; int m = this.bindIndicatorSubRange + 5; int n = m; if (this.preparedAllBinds) { this.preparedCharBinds = true; Binder[] arrayOfBinder1 = this.binders[paramInt1]; for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s; char c; Binder binder = arrayOfBinder1[b1]; int i8 = this.currentBatchCharLens[b1]; if (binder == this.theOutBinder) { Accessor accessor = this.currentBatchBindAccessors[b1]; c = accessor.byteLength; s = (short)accessor.defineType; } else { c = binder.bytelen; s = binder.type; }  if (binder == this.theRawNullBinder && this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK)
/*       */             c = '翿';  k += c; j += i8; this.bindIndicators[n + 0] = s; this.bindIndicators[n + 1] = (short)c; this.bindIndicators[n + 2] = (short)i8; this.bindIndicators[n + 9] = this.currentBatchFormOfUse[b1]; n += 10; }  } else if (this.preparedCharBinds) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = this.currentBatchCharLens[b1]; j += i8; this.bindIndicators[n + 2] = (short)i8; n += 10; }  } else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = n + 2; int i9 = this.currentBatchCharLens[b1]; short s = this.bindIndicators[i8]; int i10 = (this.bindIndicators[n + 5] << 16) + (this.bindIndicators[n + 6] & 0xFFFF); boolean bool1 = (this.bindIndicators[i10] == -1) ? true : false; if (bool1 && i9 > 1)
/*       */             this.preparedCharBinds = true;  if (s >= i9 && !this.preparedCharBinds) { this.currentBatchCharLens[b1] = s; j += s; } else { this.bindIndicators[i8] = (short)i9; j += i9; this.preparedCharBinds = true; }  n += 10; }
/*       */          }
/*       */        if (this.preparedCharBinds)
/*       */         initializeBindSubRanges(this.numberOfBoundRows, i);  if (this.preparedAllBinds) { int i8 = this.bindByteSubRange + k * i; if (this.lastBoundNeeded || i8 > this.totalBindByteLength) { this.bindByteOffset = 0; this.bindBytes = this.connection.getByteBuffer(i8); this.totalBindByteLength = i8; }
/*       */          this.bindBufferCapacity = i; this.bindIndicators[this.bindIndicatorSubRange + 1] = (short)((this.bindBufferCapacity & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 2] = (short)(this.bindBufferCapacity & 0xFFFF); }
/*       */        if (this.preparedCharBinds) { int i8 = this.bindCharSubRange + j * this.bindBufferCapacity; if (this.lastBoundNeeded || i8 > this.totalBindCharLength) { this.bindCharOffset = 0; this.bindChars = this.connection.getCharBuffer(i8); this.totalBindCharLength = i8; }
/*       */          this.bindByteSubRange += this.bindByteOffset; this.bindCharSubRange += this.bindCharOffset; }
/*       */        int i1 = this.bindByteSubRange; int i2 = this.bindCharSubRange; int i3 = this.indicatorsOffset; int i4 = this.valueLengthsOffset; n = m; if (this.preparedCharBinds) { if (this.currentBatchBindAccessors == null) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b1]; int i9 = (i8 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i9 >> 16); this.bindIndicators[n + 4] = (short)(i9 & 0xFFFF); i1 += s * this.bindBufferCapacity; i2 += i8 * this.bindBufferCapacity; n += 10; }
/*       */            }
/*       */         else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b1]; int i9 = (i8 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i9 >> 16); this.bindIndicators[n + 4] = (short)(i9 & 0xFFFF); Accessor accessor = this.currentBatchBindAccessors[b1]; if (accessor != null) { if (i8 > 0) { accessor.columnIndex = i2; accessor.charLength = i8; }
/*       */               else { accessor.columnIndex = i1; accessor.byteLength = s; }
/*       */                accessor.lengthIndex = i4; accessor.indicatorIndex = i3; accessor.rowSpaceByte = this.bindBytes; accessor.rowSpaceChar = this.bindChars; accessor.rowSpaceIndicator = this.bindIndicators; if (accessor.defineType == 109 || accessor.defineType == 111)
/*       */                 accessor.setOffsets(this.bindBufferCapacity);  }
/*       */              i1 += s * this.bindBufferCapacity; i2 += i8 * this.bindBufferCapacity; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */            }
/*       */          i1 = this.bindByteSubRange; i2 = this.bindCharSubRange; i3 = this.indicatorsOffset; i4 = this.valueLengthsOffset; n = m; }
/*       */        int i5 = this.bindBufferCapacity - this.numberOfBoundRows; int i6 = this.numberOfBoundRows - 1; int i7 = i6 + paramInt1; Binder[] arrayOfBinder = this.binders[i7]; if (this.parameterOtype != null) { System.arraycopy(this.parameterDatum[i7], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions); System.arraycopy(this.parameterOtype[i7], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions); }
/*       */        if (this.hasIbtBind)
/*       */         processPlsqlIndexTabBinds(paramInt1);  if (this.numReturnParams > 0 && (this.returnParamAccessors == null || this.returnParamAccessors.length < this.numReturnParams)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }
/*       */        if (this.returnParamAccessors != null)
/*       */         processDmlReturningBind();  boolean bool = (!this.sqlKind.isPlsqlOrCall() || this.currentRowBindAccessors == null) ? true : false; for (byte b = 0; b < this.numberOfBindPositions; b++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b]; this.lastBinders[b] = arrayOfBinder[b]; this.lastBoundByteLens[b] = s; for (byte b1 = 0; b1 < this.numberOfBoundRows; b1++) { int i9 = paramInt1 + b1; this.binders[i9][b].bind(this, b, b1, i9, this.bindBytes, this.bindChars, this.bindIndicators, s, i8, i1, i2, i4 + b1, i3 + b1, bool); this.binders[i9][b] = null; if (this.userStream != null)
/*       */             this.userStream[b1][b] = null;  i1 += s; i2 += i8; }
/*       */          this.lastBoundByteOffsets[b] = i1 - s; this.lastBoundCharOffsets[b] = i2 - i8; this.lastBoundInds[b] = this.bindIndicators[i3 + i6]; this.lastBoundLens[b] = this.bindIndicators[i4 + i6]; this.lastBoundCharLens[b] = 0; i1 += i5 * s; i2 += i5 * i8; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */        this.lastBoundBytes = this.bindBytes; this.lastBoundByteOffset = this.bindByteOffset; this.lastBoundChars = this.bindChars; this.lastBoundCharOffset = this.bindCharOffset; if (this.parameterStream != null)
/*       */         this.lastBoundStream = this.parameterStream[paramInt1 + this.numberOfBoundRows - 1];  int[] arrayOfInt = this.currentBatchCharLens; this.currentBatchCharLens = this.lastBoundCharLens; this.lastBoundCharLens = arrayOfInt; this.lastBoundNeeded = false; prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity); }
/*       */     catch (NullPointerException nullPointerException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      }
/*       */   void releaseBuffers() { this.cachedBindCharSize = (this.bindChars != null) ? this.bindChars.length : 0; if (this.bindChars != this.lastBoundChars)
/*       */       this.connection.cacheBuffer(this.lastBoundChars);  this.lastBoundChars = null; this.connection.cacheBuffer(this.bindChars); this.bindChars = null; this.cachedBindByteSize = (this.bindBytes != null) ? this.bindBytes.length : 0; if (this.bindBytes != this.lastBoundBytes)
/*       */       this.connection.cacheBuffer(this.lastBoundBytes);  this.lastBoundBytes = null; this.connection.cacheBuffer(this.bindBytes); this.bindBytes = null; super.releaseBuffers(); }
/*       */   public void enterImplicitCache() throws SQLException { alwaysOnClose(); if (!this.connection.isClosed())
/*       */       cleanAllTempLobs();  if (this.connection.clearStatementMetaData) { this.lastBoundBytes = null; this.lastBoundChars = null; }
/*       */      clearParameters(); this.cacheState = 2; this.creationState = 1; this.currentResultSet = null; this.lastIndex = 0; this.queryTimeout = 0; this.autoRollback = 2; this.rowPrefetchChanged = false; this.currentRank = 0; this.currentRow = -1; this.validRows = 0; this.maxRows = 0; this.totalRowsVisited = 0; this.maxFieldSize = 0; this.gotLastBatch = false; this.clearParameters = true; this.scrollRset = null; this.defaultFetchDirection = 1000; this.defaultTimeZone = null; this.defaultCalendar = null; this.checkSum = 0L; this.checkSumComputationFailure = false; if (this.sqlKind.isOTHER()) { this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; }
/*       */      releaseBuffers(); this.definedColumnType = null; this.definedColumnSize = null; this.definedColumnFormOfUse = null; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceByte = null; (this.accessors[b]).rowSpaceChar = null; (this.accessors[b]).rowSpaceIndicator = null; if (this.columnsDefinedByUser)
/*       */             (this.accessors[b]).externalType = 0;  }
/*       */          }
/*       */        }
/*       */      this.fixedString = this.connection.getDefaultFixedString(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchInLastFetch = -1; if (this.connection.clearStatementMetaData) { this.sqlStringChanged = true; this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (this.userRsetType == 0) { this.userRsetType = 1; this.realRsetType = 1; }
/*       */        this.currentRowNeedToPrepareBinds = true; }
/*       */      }
/*       */   public void enterExplicitCache() throws SQLException { this.cacheState = 2; this.creationState = 2; this.defaultTimeZone = null; alwaysOnClose(); }
/*       */   public void exitImplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; if (this.rowPrefetch != this.connection.getDefaultRowPrefetch())
/*       */       if (this.streamList == null) { this.rowPrefetch = this.connection.getDefaultRowPrefetch(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchChanged = true; }
/*       */         if (this.batch != this.connection.getDefaultExecuteBatch())
/*       */       resetBatch();  this.processEscapes = this.connection.processEscapes; if (this.cachedDefineIndicatorSize != 0) { this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize); this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize); this.defineIndicators = new short[this.cachedDefineIndicatorSize]; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceByte = this.defineBytes; (this.accessors[b]).rowSpaceChar = this.defineChars; (this.accessors[b]).rowSpaceIndicator = this.defineIndicators; }
/*       */            }
/*       */          doInitializationAfterDefineBufferRestore(); }
/*       */        }
/*       */      if (this.cachedBindCharSize != 0 || this.cachedBindByteSize != 0) { if (this.cachedBindByteSize > 0)
/*       */         this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);  if (this.cachedBindCharSize > 0)
/*       */         this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);  doLocalInitialization(); }
/*       */      }
/*       */   void doLocalInitialization() {}
/*       */   void doInitializationAfterDefineBufferRestore() {}
/*       */   public void exitExplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; }
/*       */   public void exitImplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void exitExplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void closeWithKey(String paramString) throws SQLException { synchronized (this.connection) { closeOrCache(paramString); }
/*       */      }
/*       */   int executeInternal() throws SQLException { this.noMoreUpdateCounts = false; this.checkSum = 0L; this.checkSumComputationFailure = false; ensureOpen(); if (this.currentRank > 0 && this.m_batchStyle == 2) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      boolean bool1 = (this.userRsetType == 1) ? true : false; prepareForNewResults(true, false); processCompletedBindRow(this.sqlKind.isSELECT() ? 1 : this.batch, false); if (!bool1 && !this.scrollRsetTypeSolved)
/*       */       return doScrollPstmtExecuteUpdate() + this.prematureBatchCount;  doExecuteWithTimeout(); boolean bool2 = (this.prematureBatchCount != 0 && this.validRows > 0) ? true : false; if (!bool1) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType); if (!this.connection.accumulateBatchResult)
/*       */         bool2 = false;  }
/*       */      if (bool2) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }
/*       */      if (this.sqlKind.isOTHER())
/*       */       this.needToParse = true;  return this.validRows; }
/*       */   public ResultSet executeQuery() throws SQLException { synchronized (this.connection) { this.executionType = 1; executeInternal(); if (this.userRsetType == 1) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); return (ResultSet)this.currentResultSet; }
/*       */        if (this.scrollRset == null) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.scrollRset = this.currentResultSet; }
/*       */        return (ResultSet)this.scrollRset; }
/*       */      }
/*       */   public int executeUpdate() throws SQLException { synchronized (this.connection) { this.executionType = 2; return executeInternal(); }
/*       */      }
/*       */   public boolean execute() throws SQLException { synchronized (this.connection) { this.executionType = 3; executeInternal(); return this.sqlKind.isSELECT(); }
/*       */      }
/*       */   void slideDownCurrentRow(int paramInt) { if (this.binders != null) { this.binders[paramInt] = this.binders[0]; this.binders[0] = this.currentRowBinders; }
/*       */      if (this.parameterInt != null) { int[] arrayOfInt = this.parameterInt[0]; this.parameterInt[0] = this.parameterInt[paramInt]; this.parameterInt[paramInt] = arrayOfInt; }
/*       */      if (this.parameterLong != null) { long[] arrayOfLong = this.parameterLong[0]; this.parameterLong[0] = this.parameterLong[paramInt]; this.parameterLong[paramInt] = arrayOfLong; }
/*       */      if (this.parameterFloat != null) { float[] arrayOfFloat = this.parameterFloat[0]; this.parameterFloat[0] = this.parameterFloat[paramInt]; this.parameterFloat[paramInt] = arrayOfFloat; }
/*       */      if (this.parameterDouble != null) { double[] arrayOfDouble = this.parameterDouble[0]; this.parameterDouble[0] = this.parameterDouble[paramInt]; this.parameterDouble[paramInt] = arrayOfDouble; }
/*       */      if (this.parameterBigDecimal != null) { BigDecimal[] arrayOfBigDecimal = this.parameterBigDecimal[0]; this.parameterBigDecimal[0] = this.parameterBigDecimal[paramInt]; this.parameterBigDecimal[paramInt] = arrayOfBigDecimal; }
/*       */      if (this.parameterString != null) { String[] arrayOfString = this.parameterString[0]; this.parameterString[0] = this.parameterString[paramInt]; this.parameterString[paramInt] = arrayOfString; }
/*       */      if (this.parameterDate != null) { Date[] arrayOfDate = this.parameterDate[0]; this.parameterDate[0] = this.parameterDate[paramInt]; this.parameterDate[paramInt] = arrayOfDate; }
/*       */      if (this.parameterTime != null) { Time[] arrayOfTime = this.parameterTime[0]; this.parameterTime[0] = this.parameterTime[paramInt]; this.parameterTime[paramInt] = arrayOfTime; }
/*       */      if (this.parameterTimestamp != null) { Timestamp[] arrayOfTimestamp = this.parameterTimestamp[0]; this.parameterTimestamp[0] = this.parameterTimestamp[paramInt]; this.parameterTimestamp[paramInt] = arrayOfTimestamp; }
/*       */      if (this.parameterDatum != null) { byte[][] arrayOfByte = this.parameterDatum[0]; this.parameterDatum[0] = this.parameterDatum[paramInt]; this.parameterDatum[paramInt] = arrayOfByte; }
/*       */      if (this.parameterOtype != null) { OracleTypeADT[] arrayOfOracleTypeADT = this.parameterOtype[0]; this.parameterOtype[0] = this.parameterOtype[paramInt]; this.parameterOtype[paramInt] = arrayOfOracleTypeADT; }
/*       */      if (this.parameterStream != null) { InputStream[] arrayOfInputStream = this.parameterStream[0]; this.parameterStream[0] = this.parameterStream[paramInt]; this.parameterStream[paramInt] = arrayOfInputStream; }
/*       */      if (this.userStream != null) { Object[] arrayOfObject = this.userStream[0]; this.userStream[0] = this.userStream[paramInt]; this.userStream[paramInt] = arrayOfObject; }
/*       */      }
/*  1256 */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException { this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */ 
/*       */     
/*  1259 */     this.cacheState = 1; }
/*       */   void resetBatch() { this.batch = this.connection.getDefaultExecuteBatch(); }
/*       */   public int sendBatch() throws SQLException { if (isJdbcBatchStyle()) return 0;  synchronized (this.connection) { if (!this.connection.isUsable() || this.bsendBatchInProgress) { clearBatch(); this.bsendBatchInProgress = false; return 0; }  try { ensureOpen(); if (this.currentRank <= 0) return this.connection.accumulateBatchResult ? 0 : this.validRows;  int i = this.batch; this.bsendBatchInProgress = true; try { int j = this.currentRank; if (this.batch != this.currentRank) this.batch = this.currentRank;  setupBindBuffers(0, this.currentRank); this.currentRank--; doExecuteWithTimeout(); slideDownCurrentRow(j); } finally { if (this.batch != i) this.batch = i;  }  if (this.connection.accumulateBatchResult) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }  return this.validRows; } finally { this.currentRank = 0; this.bsendBatchInProgress = false; }  }  }
/*       */   public void setExecuteBatch(int paramInt) throws SQLException { synchronized (this.connection) { setOracleBatchStyle(); set_execute_batch(paramInt); }  }
/*       */   void set_execute_batch(int paramInt) throws SQLException { synchronized (this.connection) { if (paramInt <= 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt == this.batch) return;  if (this.currentRank > 0) { int j = this.validRows; this.prematureBatchCount = sendBatch(); this.validRows = j; }  int i = this.batch; this.batch = paramInt; if (this.numberOfBindRowsAllocated < this.batch) growBinds(this.batch);  }  }
/*       */   public final int getExecuteBatch() { return this.batch; }
/*       */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { SQLException sQLException; if (paramInt3 < 0) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt1 < 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  switch (paramInt2) { case -7: case -6: case -5: case 2: case 3: case 4: case 5: case 6: case 7: case 8: paramInt2 = 6; break;case 1: paramInt2 = 96; break;case 12: paramInt2 = 1; break;case 91: case 92: paramInt2 = 12; break;case -103: paramInt2 = 182; break;case -104: paramInt2 = 183; break;case -100: case 93: paramInt2 = 180; break;case -101: paramInt2 = 181; break;case -102: paramInt2 = 231; break;case -3: case -2: paramInt2 = 23; break;case 100: paramInt2 = 100; break;case 101: paramInt2 = 101; break;case -8: paramInt2 = 104; break;case 2004: paramInt2 = 113; break;case 2005: paramInt2 = 112; break;case -13: paramInt2 = 114; break;case -10: paramInt2 = 102; break;case 0: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }  }  }
/*       */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { int i = this.connection.getNlsRatio(); if (paramInt2 == 1 || paramInt2 == 12) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3 * i); } else { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }  }
/*       */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }
/*       */   public ResultSetMetaData getMetaData() throws SQLException { if (this.sqlObject.getSqlKind().isSELECT()) return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, this);  return null; }
/*       */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException { setNullInternal(paramInt1, paramInt2, paramString); }
/*       */   void setNullInternal(int paramInt1, int paramInt2, String paramString) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2007 || paramInt2 == 2009 || paramInt2 == 2006) { synchronized (this.connection) { setNullCritical(i, paramInt2, paramString); this.currentRowCharLens[i] = 0; }  } else { setNullInternal(paramInt1, paramInt2); return; }  }
/*  1271 */   void setNullInternal(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2, String paramString) throws SQLException { OracleTypeCOLLECTION oracleTypeCOLLECTION; OracleTypeADT oracleTypeADT1; StructDescriptor structDescriptor; ArrayDescriptor arrayDescriptor; OpaqueDescriptor opaqueDescriptor; OracleTypeADT oracleTypeADT2 = null; Binder binder = this.theNamedTypeNullBinder; switch (paramInt2) { case 2006: binder = this.theRefTypeNullBinder;case 2002: case 2008: structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT2 = structDescriptor.getOracleTypeADT(); break;case 2003: arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); break;case 2007: case 2009: opaqueDescriptor = OpaqueDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT1 = (OracleTypeADT)opaqueDescriptor.getPickler(); break; }  this.currentRowBinders[paramInt1] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt1] = null; if (oracleTypeADT1 != null) oracleTypeADT1.getTOID();  if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt1] = oracleTypeADT1; } public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException { String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNullInternal(b + 1, paramInt, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  } public void setNull(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2) throws SQLException { SQLException sQLException; int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  Binder binder = null; int j = getInternalType(paramInt2); switch (j) { case 6: binder = this.theVarnumNullBinder; break;case 1: case 8: case 96: case 995: binder = this.theVarcharNullBinder; this.currentRowCharLens[i] = 1; break;case 999: binder = this.theFixedCHARNullBinder; break;case 12: binder = this.theDateNullBinder; break;case 180: binder = this.theTimestampNullBinder; break;case 181: binder = this.theTSTZNullBinder; break;case 231: binder = this.theTSLTZNullBinder; break;case 104: binder = getRowidNullBinder(i); break;case 183: binder = this.theIntervalDSNullBinder; break;case 182: binder = this.theIntervalYMNullBinder; break;case 23: case 24: binder = this.theRawNullBinder; break;case 100: binder = this.theBinaryFloatNullBinder; break;case 101: binder = this.theBinaryDoubleNullBinder; break;case 113: binder = this.theBlobNullBinder; break;case 112: binder = this.theClobNullBinder; break;case 114: binder = this.theBfileNullBinder; break;case 109: case 111: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = binder; } Binder getRowidNullBinder(int paramInt) { return this.theRowidNullBinder; } public void setNullAtName(String paramString, int paramInt) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNull(b + 1, paramInt); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException { synchronized (this.connection) { setBooleanInternal(paramInt, paramBoolean); }  } void setBooleanInternal(int paramInt, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theBooleanBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramBoolean ? 1 : 0; } public void setByte(int paramInt, byte paramByte) throws SQLException { synchronized (this.connection) { setByteInternal(paramInt, paramByte); }  } void setByteInternal(int paramInt, byte paramByte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theByteBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramByte; } public void setShort(int paramInt, short paramShort) throws SQLException { synchronized (this.connection) { setShortInternal(paramInt, paramShort); }  } void setShortInternal(int paramInt, short paramShort) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theShortBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramShort; } public void setInt(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setIntInternal(paramInt1, paramInt2); }  } void setIntInternal(int paramInt1, int paramInt2) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theIntBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramInt2; } public void setLong(int paramInt, long paramLong) throws SQLException { synchronized (this.connection) { setLongInternal(paramInt, paramLong); }  } void setLongInternal(int paramInt, long paramLong) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theLongBinder; if (this.parameterLong == null) this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterLong[this.currentRank][i] = paramLong; } public void setFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setFloatInternal(paramInt, paramFloat); }  } void setFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.connection.setFloatAndDoubleUseBinary) if (Float.isNaN(paramFloat)) throw new IllegalArgumentException("NaN");   if (this.theFloatBinder == null) { this.theFloatBinder = theStaticFloatBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theFloatBinder = theStaticBinaryFloatBinder;  }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theFloatBinder; if (this.theFloatBinder == theStaticFloatBinder) { if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramFloat; } else { if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; }  } public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramFloat); }  } void setBinaryFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theBinaryFloatBinder; if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; } public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramBINARY_FLOAT); }  } void setBinaryFloatInternal(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_FLOAT == null) { this.currentRowBinders[i] = this.theBINARY_FLOATNullBinder; } else { this.currentRowBinders[i] = this.theBINARY_FLOATBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_FLOAT.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramDouble); }  } void setBinaryDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theBinaryDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.currentRowCharLens[i] = 0; this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE); }  } void setBinaryDoubleInternal(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_DOUBLE == null) { this.currentRowBinders[i] = this.theBINARY_DOUBLENullBinder; } else { this.currentRowBinders[i] = this.theBINARY_DOUBLEBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_DOUBLE.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setDoubleInternal(paramInt, paramDouble); }  } void setDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.connection.setFloatAndDoubleUseBinary) { if (Double.isNaN(paramDouble)) throw new IllegalArgumentException("NaN");  double d = Math.abs(paramDouble); if (d != 0.0D && d < 1.0E-130D) throw new IllegalArgumentException("Underflow");  if (d >= 1.0E126D) throw new IllegalArgumentException("Overflow");  }  if (this.theDoubleBinder == null) { this.theDoubleBinder = theStaticDoubleBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theDoubleBinder = theStaticBinaryDoubleBinder;  }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { synchronized (this.connection) { setBigDecimalInternal(paramInt, paramBigDecimal); }  } void setBigDecimalInternal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBigDecimal == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theBigDecimalBinder; if (this.parameterBigDecimal == null) this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterBigDecimal[this.currentRank][i] = paramBigDecimal; }  this.currentRowCharLens[i] = 0; } public void setString(int paramInt, String paramString) throws SQLException { setStringInternal(paramInt, paramString); } void setStringInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramString != null) ? paramString.length() : 0; if (!b) { setNull(paramInt, 12); } else if (this.currentRowFormOfUse[paramInt - 1] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, false); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else if (b <= this.maxStreamCharsSql) { basicBindCharacterStream(paramInt, new StringReader(paramString), b, true); } else { setStringForClobCritical(paramInt, paramString); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsNCharsPlsql && this.isServerNCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsNCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, true); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void basicBindNullString(int paramInt) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theVarcharNullBinder; if (this.sqlKind.isPlsqlOrCall()) { this.currentRowCharLens[i] = this.minVcsBindSize; } else { this.currentRowCharLens[i] = 1; }  }  } void basicBindString(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theStringBinder; int j = paramString.length(); if (this.sqlKind.isPlsqlOrCall()) { int k = this.connection.minVcsBindSize; int m = j + 1; this.currentRowCharLens[i] = (m < k) ? k : m; } else { this.currentRowCharLens[i] = j + 1; }  if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  } public void setStringForClob(int paramInt, String paramString) throws SQLException { if (paramString == null) { setNull(paramInt, 1); return; }  int i = paramString.length(); if (i == 0) { setNull(paramInt, 1); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxVcsCharsPlsql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } else if (i <= this.maxVcsCharsSql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void setStringForClobCritical(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); cLOB.setString(1L, paramString); addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setReaderContentsForClobCritical(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramReader = isReaderEmpty(paramReader)) == null) { if (paramBoolean) throw new IOException(paramLong + " char of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); char[] arrayOfChar = new char[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramReader.read(arrayOfChar); } else { j = paramReader.read(arrayOfChar, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " char of CLOB data cannot be read");  break; }  oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setAsciiStreamContentsForClobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; char[] arrayOfChar = new char[i]; int j = 0; long l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of CLOB data cannot be read");  break; }  DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar); oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException { String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStringForClob(b + 1, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  } OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { super(paramPhysicalConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  5359 */     this.SetBigStringTryClob = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10074 */     this.m_batchStyle = 0; this.cacheState = 1; if (paramInt1 > 1) setOracleBatchStyle();  this.theSetCHARBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder; this.theURowidBinder = this.theRowidBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder; this.statementType = 1; this.currentRow = -1; this.needToParse = true; this.processEscapes = paramPhysicalConnection.processEscapes; this.sqlObject.initialize(paramString); this.sqlKind = this.sqlObject.getSqlKind(); this.clearParameters = true; this.scrollRsetTypeSolved = false; this.prematureBatchCount = 0; initializeBinds(); this.minVcsBindSize = paramPhysicalConnection.minVcsBindSize; this.maxRawBytesSql = paramPhysicalConnection.maxRawBytesSql; this.maxRawBytesPlsql = paramPhysicalConnection.maxRawBytesPlsql; this.maxVcsCharsSql = paramPhysicalConnection.maxVcsCharsSql; this.maxVcsNCharsSql = paramPhysicalConnection.maxVcsNCharsSql; this.maxVcsBytesPlsql = paramPhysicalConnection.maxVcsBytesPlsql; this.maxIbtVarcharElementLength = paramPhysicalConnection.maxIbtVarcharElementLength; this.maxCharSize = this.connection.conversion.sMaxCharSize; this.maxNCharSize = this.connection.conversion.maxNCharSize; this.maxVcsCharsPlsql = this.maxVcsBytesPlsql / this.maxCharSize; this.maxVcsNCharsPlsql = this.maxVcsBytesPlsql / this.maxNCharSize; this.maxStreamCharsSql = Integer.MAX_VALUE / this.maxCharSize; this.maxStreamNCharsSql = this.maxRawBytesSql / this.maxNCharSize; this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth; this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth; }
/*       */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { setFixedCHARInternal(paramInt, paramString); }  }
/*       */   void setFixedCHARInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  int j = 0; if (paramString != null) j = paramString.length();  if (j > 32766) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString == null) { this.currentRowBinders[i] = this.theFixedCHARNullBinder; this.currentRowCharLens[i] = 1; } else { this.currentRowBinders[i] = this.theFixedCHARBinder; this.currentRowCharLens[i] = j + 1; if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  }
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException { synchronized (this.connection) { setCursorInternal(paramInt, paramResultSet); }  }
/*       */   void setCursorInternal(int paramInt, ResultSet paramResultSet) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException { synchronized (this.connection) { setROWIDInternal(paramInt, paramROWID); }  }
/*       */   void setROWIDInternal(int paramInt, ROWID paramROWID) throws SQLException { if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (paramROWID == null) { setNull(paramInt, 12); } else { setStringInternal(paramInt, paramROWID.stringValue()); }  return; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramROWID == null || paramROWID.shareBytes() == null) { this.currentRowBinders[i] = this.theRowidNullBinder; } else { this.currentRowBinders[i] = T4CRowidAccessor.isUROWID(paramROWID.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramROWID.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   public void setArray(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   void setArrayInternal(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException { setARRAYInternal(paramInt, paramARRAY); }
/*       */   void setARRAYInternal(int paramInt, ARRAY paramARRAY) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramARRAY == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setArrayCritical(i, paramARRAY); this.currentRowCharLens[i] = 0; }  }
/* 10085 */   void setArrayCritical(int paramInt, ARRAY paramARRAY) throws SQLException { ArrayDescriptor arrayDescriptor = paramARRAY.getDescriptor(); if (arrayDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramARRAY.toBytes(); OracleTypeCOLLECTION oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); oracleTypeCOLLECTION.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = (OracleTypeADT)oracleTypeCOLLECTION; } public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException { setOPAQUEInternal(paramInt, paramOPAQUE); } void setOPAQUEInternal(int paramInt, OPAQUE paramOPAQUE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramOPAQUE == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setOPAQUECritical(i, paramOPAQUE); this.currentRowCharLens[i] = 0; }  } void setOPAQUECritical(int paramInt, OPAQUE paramOPAQUE) throws SQLException { OpaqueDescriptor opaqueDescriptor = paramOPAQUE.getDescriptor(); if (opaqueDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramOPAQUE.toBytes(); OracleTypeADT oracleTypeADT = (OracleTypeADT)opaqueDescriptor.getPickler(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLException { if (paramSQLXML == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setOPAQUEInternal(paramInt, (OPAQUE)paramSQLXML); } public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { setStructDescriptorInternal(paramInt, paramStructDescriptor); } void setStructDescriptorInternal(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramStructDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setStructDescriptorCritical(i, paramStructDescriptor); this.currentRowCharLens[i] = 0; }  } void setStructDescriptorCritical(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  OracleTypeADT oracleTypeADT = paramStructDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStructDescriptorInternal(b + 1, paramStructDescriptor); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } void setPreBindsCompelete() throws SQLException {} public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException { setSTRUCTInternal(paramInt, paramSTRUCT); } void setSTRUCTInternal(int paramInt, STRUCT paramSTRUCT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramSTRUCT == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setSTRUCTCritical(i, paramSTRUCT); this.currentRowCharLens[i] = 0; }  } void setSTRUCTCritical(int paramInt, STRUCT paramSTRUCT) throws SQLException { StructDescriptor structDescriptor = paramSTRUCT.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramSTRUCT.toBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setRAW(int paramInt, RAW paramRAW) throws SQLException { setRAWInternal(paramInt, paramRAW); } void setRAWInternal(int paramInt, RAW paramRAW) throws SQLException { boolean bool = false; synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramRAW == null) { this.currentRowBinders[i] = this.theRawNullBinder; } else { bool = true; }  }  if (bool) setBytesInternal(paramInt, paramRAW.getBytes());  } final void setOracleBatchStyle() throws SQLException { if (this.m_batchStyle == 2) {
/*       */ 
/*       */       
/* 10088 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
/* 10089 */       sQLException.fillInStackTrace();
/* 10090 */       throw sQLException;
/*       */     } 
/*       */     
/* 10093 */     if (this.m_batchStyle == 0);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10098 */     this.m_batchStyle = 1; } public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException { synchronized (this.connection) { setCHARInternal(paramInt, paramCHAR); }  } void setCHARInternal(int paramInt, CHAR paramCHAR) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramCHAR == null || paramCHAR.getLength() == 0L) { this.currentRowBinders[i] = this.theSetCHARNullBinder; this.currentRowCharLens[i] = 1; } else { byte[] arrayOfByte; short s = (short)paramCHAR.oracleId(); this.currentRowBinders[i] = this.theSetCHARBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  CharacterSet characterSet = (this.currentRowFormOfUse[i] == 2) ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj; if (characterSet != null && characterSet.getOracleId() != s) { byte[] arrayOfByte1 = paramCHAR.shareBytes(); arrayOfByte = characterSet.convert(paramCHAR.getCharacterSet(), arrayOfByte1, 0, arrayOfByte1.length); } else { arrayOfByte = paramCHAR.getBytes(); }  this.parameterDatum[this.currentRank][i] = arrayOfByte; this.currentRowCharLens[i] = (arrayOfByte.length + 1 >> 1) + 1; }  if (this.sqlKind.isPlsqlOrCall()) if (this.currentRowCharLens[i] < this.minVcsBindSize) this.currentRowCharLens[i] = this.minVcsBindSize;   } public void setDATE(int paramInt, DATE paramDATE) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, paramDATE); }  } void setDATEInternal(int paramInt, DATE paramDATE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramDATE == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theOracleDateBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramDATE.getBytes(); }  } public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException { synchronized (this.connection) { setNUMBERInternal(paramInt, paramNUMBER); }  } void setNUMBERInternal(int paramInt, NUMBER paramNUMBER) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramNUMBER == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theOracleNumberBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramNUMBER.getBytes(); }  } public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, paramBLOB); }  } void setBLOBInternal(int paramInt, BLOB paramBLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramBLOB == null) { this.currentRowBinders[i] = this.theBlobNullBinder; } else { this.currentRowBinders[i] = this.theBlobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBLOB.getBytes(); }  } public void setBlob(int paramInt, Blob paramBlob) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, (BLOB)paramBlob); }  } void setBlobInternal(int paramInt, Blob paramBlob) throws SQLException { setBLOBInternal(paramInt, (BLOB)paramBlob); } public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, paramCLOB); }  } void setCLOBInternal(int paramInt, CLOB paramCLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramCLOB == null) { this.currentRowBinders[i] = this.theClobNullBinder; } else { this.currentRowBinders[i] = this.theClobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramCLOB.getBytes(); }  } public void setClob(int paramInt, Clob paramClob) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, (CLOB)paramClob); }  } void setClobInternal(int paramInt, Clob paramClob) throws SQLException { setCLOBInternal(paramInt, (CLOB)paramClob); } public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBFILEInternal(int paramInt, BFILE paramBFILE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramBFILE == null) { this.currentRowBinders[i] = this.theBfileNullBinder; } else { this.currentRowBinders[i] = this.theBfileBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBFILE.getBytes(); }  } public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBfileInternal(int paramInt, BFILE paramBFILE) throws SQLException { setBFILEInternal(paramInt, paramBFILE); } public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { setBytesInternal(paramInt, paramArrayOfbyte); } void setBytesInternal(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramArrayOfbyte != null) ? paramArrayOfbyte.length : 0; if (!b) { setNullInternal(paramInt, -2); } else if (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (b > this.maxRawBytesSql) { bindBytesAsStream(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } void bindBytesAsStream(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramArrayOfbyte.length; byte[] arrayOfByte = new byte[i]; System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, i); set_execute_batch(1); basicBindBinaryStream(paramInt, new ByteArrayInputStream(arrayOfByte), i, true); } void basicBindBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; Binder binder = this.sqlKind.isPlsqlOrCall() ? this.thePlsqlRawBinder : this.theRawBinder; this.currentRowBinders[i] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramArrayOfbyte; this.currentRowCharLens[i] = 0; }  } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { basicBindBinaryStream(paramInt1, paramInputStream, paramInt2, false); } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongRawStreamForBytesBinder; } else { this.currentRowBinders[i] = this.theLongRawStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramInputStream, 6, paramInt2) : this.connection.conversion.ConvertStream(paramInputStream, 6, paramInt2); this.currentRowCharLens[i] = 0; }  } public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException { if (paramArrayOfbyte == null) { setNull(paramInt, -2); return; }  int i = paramArrayOfbyte.length; if (i == 0) { setNull(paramInt, -2); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxRawBytesPlsql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } else if (i <= this.maxRawBytesSql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } void setBytesForBlobCritical(int paramInt, byte[] paramArrayOfbyte) throws SQLException { BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); bLOB.putBytes(1L, paramArrayOfbyte); addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); } void setBinaryStreamContentsForBlobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of BLOB data cannot be read");  setBLOBInternal(paramInt, (BLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); OracleBlobOutputStream oracleBlobOutputStream = (OracleBlobOutputStream)bLOB.setBinaryStream(1L); int i = bLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of BLOB data cannot be read");  break; }  oracleBlobOutputStream.write(arrayOfByte, 0, j); l -= j; }  oracleBlobOutputStream.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); }  } public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setBytesForBlob(b + 1, paramArrayOfbyte); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { synchronized (this.connection) { setInternalBytesInternal(paramInt1, paramArrayOfbyte, paramInt2); }  } void setInternalBytesInternal(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setDate(int paramInt, Date paramDate) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); }  } void setDateInternal(int paramInt, Date paramDate) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); } public void setTime(int paramInt, Time paramTime) throws SQLException { synchronized (this.connection) { setTimeInternal(paramInt, paramTime); }  } void setTimeInternal(int paramInt, Time paramTime) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTime == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theTimeBinder; if (this.parameterTime == null) this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTime[this.currentRank][i] = paramTime; }  this.currentRowCharLens[i] = 0; } public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException { synchronized (this.connection) { setTimestampInternal(paramInt, paramTimestamp); }  } void setTimestampInternal(int paramInt, Timestamp paramTimestamp) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTimestamp == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theTimestampBinder; if (this.parameterTimestamp == null) this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTimestamp[this.currentRank][i] = paramTimestamp; }  this.currentRowCharLens[i] = 0; } public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { synchronized (this.connection) { setINTERVALYMInternal(paramInt, paramINTERVALYM); }  } void setINTERVALYMInternal(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALYM == null) { this.currentRowBinders[i] = this.theIntervalYMNullBinder; } else { this.currentRowBinders[i] = this.theIntervalYMBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALYM.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { synchronized (this.connection) { setINTERVALDSInternal(paramInt, paramINTERVALDS); }  } void setINTERVALDSInternal(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALDS == null) { this.currentRowBinders[i] = this.theIntervalDSNullBinder; } else { this.currentRowBinders[i] = this.theIntervalDSBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALDS.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { synchronized (this.connection) { setTIMESTAMPInternal(paramInt, paramTIMESTAMP); }  } void setTIMESTAMPInternal(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMP == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theOracleTimestampBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMP.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ); }  } void setTIMESTAMPTZInternal(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPTZ == null) { this.currentRowBinders[i] = this.theTSTZNullBinder; } else { this.currentRowBinders[i] = this.theTSTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPTZ.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ); }  }
/*       */   void setTIMESTAMPLTZInternal(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { if (this.connection.getSessionTimeZone() == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPLTZ == null) { this.currentRowBinders[i] = this.theTSLTZNullBinder; } else { this.currentRowBinders[i] = this.theTSLTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPLTZ.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   private Reader isReaderEmpty(Reader paramReader) throws IOException { if (!paramReader.markSupported()) paramReader = new BufferedReader(paramReader, 5);  paramReader.mark(100); int i; if ((i = paramReader.read()) == -1) return null;  paramReader.reset(); return paramReader; }
/*       */   private InputStream isInputStreamEmpty(InputStream paramInputStream) throws IOException { if (!paramInputStream.markSupported()) paramInputStream = new BufferedInputStream(paramInputStream, 5);  paramInputStream.mark(100); int i; if ((i = paramInputStream.read()) == -1) return null;  paramInputStream.reset(); return paramInputStream; }
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2); }  }
/*       */   void setAsciiStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2, true); }
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != 1 && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsCharsPlsql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsCharsSql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else if (paramLong > 2147483647L) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { basicBindAsciiStream(paramInt, paramInputStream, (int)paramLong); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsNCharsPlsql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsNCharsSql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  }  }
/* 10105 */   boolean isOracleBatchStyle() { return (this.m_batchStyle == 1); } void basicBindAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { if (this.userRsetType != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt1 - 1; this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 5, paramInt2); this.currentRowCharLens[i] = 0; }  } void setAsciiStreamContentsForStringInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[paramInt2]; DBConversion.asciiBytesToJavaChars(arrayOfByte, i, arrayOfChar); basicBindString(paramInt1, new String(arrayOfChar)); } public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2); } void setBinaryStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2, true); } void checkUserStreamForDuplicates(Object paramObject, int paramInt) throws SQLException { if (paramObject == null) return;  if (this.userStream != null) { for (Object[] arrayOfObject : this.userStream) { for (Object object : arrayOfObject) { if (object == paramObject) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(paramInt + 1)); sQLException.fillInStackTrace(); throw sQLException; }  }  }  } else { this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; }  this.userStream[this.currentRank][paramInt] = paramObject; } void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setRAWInternal(paramInt, (RAW)null); } else { if (this.userRsetType != 1 && (paramLong > this.maxRawBytesSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxRawBytesPlsql) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  } else if (paramLong > 2147483647L) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (paramLong > this.maxRawBytesSql) { basicBindBinaryStream(paramInt, paramInputStream, (int)paramLong); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  }  }  } void setBinaryStreamContentsForByteArrayInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { byte[] arrayOfByte1 = new byte[i]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i); arrayOfByte = arrayOfByte1; }  setBytesInternal(paramInt1, arrayOfByte); } public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2); } void setUnicodeStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setStringInternal(paramInt1, (String)null); } else { if (this.userRsetType != 1 && paramInt2 > this.maxVcsCharsSql) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (this.sqlKind.isPlsqlOrCall() || paramInt2 <= this.maxVcsCharsSql) { byte[] arrayOfByte = new byte[paramInt2]; int j = 0; int k = paramInt2; try { int m; while (k > 0 && (m = paramInputStream.read(arrayOfByte, j, k)) != -1) { j += m; k -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[j >> 1]; DBConversion.ucs2BytesToJavaChars(arrayOfByte, j, arrayOfChar); setStringInternal(paramInt1, new String(arrayOfChar)); } else { this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 4, paramInt2); this.currentRowCharLens[i] = 0; }  }  }  } public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt, this.connection.toDatum(paramCustomDatum)); }  } void setCustomDatumInternal(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { Datum datum = this.connection.toDatum(paramCustomDatum); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); }  } public void setORAData(int paramInt, ORAData paramORAData) throws SQLException { setORADataInternal(paramInt, paramORAData); } void setORADataInternal(int paramInt, ORAData paramORAData) throws SQLException { synchronized (this.connection) { Datum datum = paramORAData.toDatum((Connection)this.connection); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  } void setOracleDataInternal(int paramInt, OracleData paramOracleData) throws SQLException { synchronized (this.connection) { Object object = paramOracleData.toJDBCObject((Connection)this.connection); if (object instanceof OracleProxy) { final OracleProxy proxiedJDBCObject = (OracleProxy)object; object = AccessController.doPrivileged(new PrivilegedAction() { public Object run() { return ProxyFactory.extractDelegate(proxiedJDBCObject); } }
/*       */           ); }  int i = sqlTypeForObject(object); setObjectCritical(paramInt, object, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { if (paramObject == null && paramInt2 != 2002 && paramInt2 != 2008 && paramInt2 != 2003 && paramInt2 != 2007 && paramInt2 != 2006 && paramInt2 != 2009) { setNullInternal(paramInt1, paramInt2); } else if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2009) { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); this.currentRowCharLens[paramInt1 - 1] = 0; } else { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectCritical(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { switch (paramInt2) { case -15: setFormOfUse(paramInt1, (short)2);case 1: if (paramObject instanceof CHAR) { setCHARInternal(paramInt1, (CHAR)paramObject); } else if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -9: setFormOfUse(paramInt1, (short)2);case 12: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 999: setFixedCHARInternal(paramInt1, (String)paramObject); return;case -16: setFormOfUse(paramInt1, (short)2);case -1: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 2: if (paramObject instanceof NUMBER) { setNUMBERInternal(paramInt1, (NUMBER)paramObject); } else if (paramObject instanceof Integer) { setIntInternal(paramInt1, ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setLongInternal(paramInt1, ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setFloatInternal(paramInt1, ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setDoubleInternal(paramInt1, ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof BigInteger) { setBigDecimalInternal(paramInt1, new BigDecimal((BigInteger)paramObject)); } else if (paramObject instanceof String) { setNUMBERInternal(paramInt1, new NUMBER((String)paramObject, paramInt3)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else if (paramObject instanceof Short) { setShortInternal(paramInt1, ((Short)paramObject).shortValue()); } else if (paramObject instanceof Byte) { setByteInternal(paramInt1, ((Byte)paramObject).byteValue()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 3: if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof Number) { setBigDecimalInternal(paramInt1, new BigDecimal(((Number)paramObject).doubleValue())); } else if (paramObject instanceof NUMBER) { setBigDecimalInternal(paramInt1, ((NUMBER)paramObject).bigDecimalValue()); } else if (paramObject instanceof String) { setBigDecimalInternal(paramInt1, new BigDecimal((String)paramObject)); } else if (paramObject instanceof Boolean) { setBigDecimalInternal(paramInt1, new BigDecimal(((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -7: if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof String) { setByteInternal(paramInt1, (byte)(("true".equalsIgnoreCase((String)paramObject) || "1".equals(paramObject)) ? 1 : 0)); } else if (paramObject instanceof Number) { setIntInternal(paramInt1, (((Number)paramObject).byteValue() != 0) ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -6: if (paramObject instanceof Number) { setByteInternal(paramInt1, ((Number)paramObject).byteValue()); } else if (paramObject instanceof String) { setByteInternal(paramInt1, Byte.parseByte((String)paramObject)); } else if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 5: if (paramObject instanceof Number) { setShortInternal(paramInt1, ((Number)paramObject).shortValue()); } else if (paramObject instanceof String) { setShortInternal(paramInt1, Short.parseShort((String)paramObject)); } else if (paramObject instanceof Boolean) { setShortInternal(paramInt1, (short)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 4: if (paramObject instanceof Number) { setIntInternal(paramInt1, ((Number)paramObject).intValue()); } else if (paramObject instanceof String) { setIntInternal(paramInt1, Integer.parseInt((String)paramObject)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -5: if (paramObject instanceof Number) { setLongInternal(paramInt1, ((Number)paramObject).longValue()); } else if (paramObject instanceof String) { setLongInternal(paramInt1, Long.parseLong((String)paramObject)); } else if (paramObject instanceof Boolean) { setLongInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1L : 0L); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 7: if (paramObject instanceof Number) { setFloatInternal(paramInt1, ((Number)paramObject).floatValue()); } else if (paramObject instanceof String) { setFloatInternal(paramInt1, Float.valueOf((String)paramObject).floatValue()); } else if (paramObject instanceof Boolean) { setFloatInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0F : 0.0F); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 6: case 8: if (paramObject instanceof Number) { setDoubleInternal(paramInt1, ((Number)paramObject).doubleValue()); } else if (paramObject instanceof String) { setDoubleInternal(paramInt1, Double.valueOf((String)paramObject).doubleValue()); } else if (paramObject instanceof Boolean) { setDoubleInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -2: if (paramObject instanceof RAW) { setRAWInternal(paramInt1, (RAW)paramObject); } else { setBytesInternal(paramInt1, (byte[])paramObject); }  return;case -3: setBytesInternal(paramInt1, (byte[])paramObject); return;case -4: setBytesInternal(paramInt1, (byte[])paramObject); return;case 91: if (paramObject instanceof DATE) { setDATEInternal(paramInt1, (DATE)paramObject); } else if (paramObject instanceof Date) { setDATEInternal(paramInt1, new DATE(paramObject, getDefaultCalendar())); } else if (paramObject instanceof Timestamp) { setDATEInternal(paramInt1, new DATE((Timestamp)paramObject)); } else if (paramObject instanceof String) { setDateInternal(paramInt1, Date.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 92: if (paramObject instanceof Time) { setTimeInternal(paramInt1, (Time)paramObject); } else if (paramObject instanceof Timestamp) { setTimeInternal(paramInt1, new Time(((Timestamp)paramObject).getTime())); } else if (paramObject instanceof Date) { setTimeInternal(paramInt1, new Time(((Date)paramObject).getTime())); } else if (paramObject instanceof String) { setTimeInternal(paramInt1, Time.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 93: if (paramObject instanceof TIMESTAMP) { setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); } else if (paramObject instanceof Timestamp) { setTimestampInternal(paramInt1, (Timestamp)paramObject); } else if (paramObject instanceof Date) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP((Date)paramObject)); } else if (paramObject instanceof DATE) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP(((DATE)paramObject).timestampValue())); } else if (paramObject instanceof String) { setTimestampInternal(paramInt1, Timestamp.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -100: setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); return;case -101: setTIMESTAMPTZInternal(paramInt1, (TIMESTAMPTZ)paramObject); return;case -102: setTIMESTAMPLTZInternal(paramInt1, (TIMESTAMPLTZ)paramObject); return;case -103: setINTERVALYMInternal(paramInt1, (INTERVALYM)paramObject); return;case -104: setINTERVALDSInternal(paramInt1, (INTERVALDS)paramObject); return;case -8: setROWIDInternal(paramInt1, (ROWID)paramObject); return;case 100: setBinaryFloatInternal(paramInt1, (BINARY_FLOAT)paramObject); return;case 101: setBinaryDoubleInternal(paramInt1, (BINARY_DOUBLE)paramObject); return;case 2004: setBLOBInternal(paramInt1, (BLOB)paramObject); return;case 2005: case 2011: setCLOBInternal(paramInt1, (CLOB)paramObject); if (((CLOB)paramObject).isNCLOB()) setFormOfUse(paramInt1, (short)2);  return;case -13: setBFILEInternal(paramInt1, (BFILE)paramObject); return;case 2002: case 2008: setSTRUCTInternal(paramInt1, STRUCT.toSTRUCT(paramObject, (OracleConnection)this.connection)); return;case 2003: setARRAYInternal(paramInt1, ARRAY.toARRAY(paramObject, (OracleConnection)this.connection)); return;case 2007: setOPAQUEInternal(paramInt1, (OPAQUE)paramObject); return;case 2006: setREFInternal(paramInt1, (REF)paramObject); return;case 2009: setSQLXMLInternal(paramInt1, (SQLXML)paramObject); return; }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setObjectInternal(b + 1, paramObject); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   public void setRefType(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   void setRefTypeInternal(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   public void setRef(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   void setRefInternal(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   public void setREF(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/* 10118 */   final void setJdbcBatchStyle() throws SQLException { if (this.m_batchStyle == 1) {
/*       */ 
/*       */       
/* 10121 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
/* 10122 */       sQLException.fillInStackTrace();
/* 10123 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10127 */     this.m_batchStyle = 2; } void setREFInternal(int paramInt, REF paramREF) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramREF == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setREFCritical(i, paramREF); this.currentRowCharLens[i] = 0; } void setREFCritical(int paramInt, REF paramREF) throws SQLException { StructDescriptor structDescriptor = paramREF.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theRefTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramREF.getBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setObject(int paramInt, Object paramObject) throws SQLException { setObjectInternal(paramInt, paramObject); } void setObjectInternal(int paramInt, Object paramObject) throws SQLException { if (paramObject instanceof ORAData) { setORADataInternal(paramInt, (ORAData)paramObject); } else if (paramObject instanceof CustomDatum) { setCustomDatumInternal(paramInt, (CustomDatum)paramObject); } else if (paramObject instanceof OracleData) { setOracleDataInternal(paramInt, (OracleData)paramObject); } else { int i = sqlTypeForObject(paramObject); setObjectInternal(paramInt, paramObject, i, 0); }  } public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } void setOracleObjectInternal(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { synchronized (this.connection) { setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5); }  } void setPlsqlIndexTableInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { Datum[] arrayOfDatum; String[] arrayOfString2; SQLException sQLException; int k, i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramObject == null) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271); sQLException1.fillInStackTrace(); throw sQLException1; }  int j = getInternalType(paramInt4); String[] arrayOfString1 = null; switch (j) { case 1: case 96: arrayOfString2 = null; k = 0; if (paramObject instanceof CHAR[]) { CHAR[] arrayOfCHAR = (CHAR[])paramObject; k = arrayOfCHAR.length; arrayOfString2 = new String[k]; for (byte b = 0; b < k; b++) { CHAR cHAR = arrayOfCHAR[b]; if (cHAR != null) arrayOfString2[b] = cHAR.getString();  }  } else if (paramObject instanceof String[]) { arrayOfString2 = (String[])paramObject; k = arrayOfString2.length; } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt5 == 0 && arrayOfString2 != null) for (byte b = 0; b < k; b++) { String str = arrayOfString2[b]; if (str != null && paramInt5 < str.length()) paramInt5 = str.length();  }   arrayOfString1 = arrayOfString2; break;case 2: case 6: arrayOfDatum = OracleTypeNUMBER.toNUMBERArray(paramObject, this.connection, 1L, paramInt3); if (paramInt5 == 0 && arrayOfDatum != null) paramInt5 = 22;  this.currentRowCharLens[i] = 0; break;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException.fillInStackTrace(); throw sQLException; }  if (arrayOfDatum.length == 0 && paramInt2 == 0) { sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.thePlsqlIbtBinder; if (this.parameterPlsqlIbt == null) this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterPlsqlIbt[this.currentRank][i] = new PlsqlIbtBindInfo((Object[])arrayOfDatum, paramInt2, paramInt3, j, paramInt5); this.hasIbtBind = true; } public void setPlsqlIndexTableAtName(String paramString, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { synchronized (this.connection) { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setPlsqlIndexTableInternal(b + 1, paramObject, paramInt1, paramInt2, paramInt3, paramInt4); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }  } void endOfResultSet(boolean paramBoolean) throws SQLException { if (!paramBoolean) prepareForNewResults(false, false);  this.rowPrefetchInLastFetch = -1; } int sqlTypeForObject(Object paramObject) { if (paramObject == null) return 0;  if (!(paramObject instanceof Datum)) { if (paramObject instanceof String) return this.fixedString ? 999 : 12;  if (paramObject instanceof BigDecimal) return 2;  if (paramObject instanceof BigInteger) return 2;  if (paramObject instanceof Boolean) return -7;  if (paramObject instanceof Integer) return 4;  if (paramObject instanceof Long) return -5;  if (paramObject instanceof Float) return 7;  if (paramObject instanceof Double) return 8;  if (paramObject instanceof byte[]) return -3;  if (paramObject instanceof Short) return 5;  if (paramObject instanceof Byte) return -6;  if (paramObject instanceof Date) return 91;  if (paramObject instanceof Time) return 92;  if (paramObject instanceof Timestamp) return 93;  if (paramObject instanceof java.sql.SQLData) return 2002;  if (paramObject instanceof oracle.jdbc.internal.ObjectData) return 2002;  } else { if (paramObject instanceof BINARY_FLOAT) return 100;  if (paramObject instanceof BINARY_DOUBLE) return 101;  if (paramObject instanceof BLOB) return 2004;  if (paramObject instanceof CLOB) return 2005;  if (paramObject instanceof BFILE) return -13;  if (paramObject instanceof ROWID) return -8;  if (paramObject instanceof NUMBER) return 2;  if (paramObject instanceof DATE) return 91;  if (paramObject instanceof TIMESTAMP) return 93;  if (paramObject instanceof TIMESTAMPTZ) return -101;  if (paramObject instanceof TIMESTAMPLTZ) return -102;  if (paramObject instanceof REF) return 2006;  if (paramObject instanceof CHAR) return 1;  if (paramObject instanceof RAW) return -2;  if (paramObject instanceof ARRAY) return 2003;  if (paramObject instanceof STRUCT) return 2002;  if (paramObject instanceof OPAQUE) return 2007;  if (paramObject instanceof INTERVALYM) return -103;  if (paramObject instanceof INTERVALDS) return -104;  if (paramObject instanceof SQLXML) return 2009;  }  return 1111; }
/*       */   public void clearParameters() throws SQLException { synchronized (this.connection) { this.clearParameters = true; for (byte b = 0; b < this.numberOfBindPositions; b++) this.currentRowBinders[b] = null;  }  }
/*       */   void printByteArray(byte[] paramArrayOfbyte) { if (paramArrayOfbyte != null) { int i = paramArrayOfbyte.length; for (byte b = 0; b < i; b++) { int j = paramArrayOfbyte[b] & 0xFF; if (j < 16); }  }  }
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2); }
/*       */   void setCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2, true); }
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramReader, i); if (paramReader == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != 1 && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsCharsPlsql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, false); }  } else if (paramLong <= this.maxVcsCharsSql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else if (paramLong > 2147483647L) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else { basicBindCharacterStream(paramInt, paramReader, (int)paramLong, false); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsNCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsNCharsPlsql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, true); }  } else if (paramLong <= this.maxVcsNCharsSql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); }  }  }
/*       */   void basicBindCharacterStream(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongStreamForStringBinder; } else { this.currentRowBinders[i] = this.theLongStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]) : this.connection.conversion.ConvertStream(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]); this.currentRowCharLens[i] = 0; }  }
/*       */   void setReaderContentsForStringOrClobInVariableWidthCase(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int m; while (j > 0 && (m = paramReader.read(arrayOfChar, i, j)) != -1) { i += m; j -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  int k = this.connection.conversion.encodedByteLength(arrayOfChar, paramBoolean); if (k < this.maxVcsBytesPlsql && !this.connection.retainV9BindBehavior) { setStringInternal(paramInt1, new String(arrayOfChar)); } else { setStringForClobCritical(paramInt1, new String(arrayOfChar)); }  }
/*       */   void setReaderContentsForStringInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramReader.read(arrayOfChar, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  setStringInternal(paramInt1, new String(arrayOfChar)); }
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   void setDateInternal(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   void setTimeInternal(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTimestampInternal(paramInt, paramTimestamp, paramCalendar); }
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTIMESTAMPInternal(paramInt, (paramTimestamp == null) ? null : new TIMESTAMP(paramTimestamp, paramCalendar)); }
/*       */   public void setCheckBindTypes(boolean paramBoolean) { this.checkBindTypes = paramBoolean; }
/* 10143 */   final void checkIfJdbcBatchExists() throws SQLException { if (doesJdbcBatchExist()) {
/*       */ 
/*       */       
/* 10146 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/* 10147 */       sQLException.fillInStackTrace();
/* 10148 */       throw sQLException;
/*       */     }  }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean doesJdbcBatchExist() {
/* 10157 */     if (this.currentRank > 0 && this.m_batchStyle == 2) {
/* 10158 */       return true;
/*       */     }
/* 10160 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isJdbcBatchStyle() {
/* 10167 */     return (this.m_batchStyle == 2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch() throws SQLException {
/* 10188 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10203 */       setJdbcBatchStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10213 */       processCompletedBindRow(this.currentRank + 2, (this.currentRank > 0 && this.sqlKind.isPlsqlOrCall()));
/*       */ 
/*       */ 
/*       */       
/* 10217 */       this.currentRank++;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch(String paramString) throws SQLException {
/* 10227 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10230 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10231 */       sQLException.fillInStackTrace();
/* 10232 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearBatch() throws SQLException {
/* 10251 */     synchronized (this.connection) {
/*       */       
/* 10253 */       for (int i = this.currentRank - 1; i >= 0; i--) {
/* 10254 */         for (byte b = 0; b < this.numberOfBindPositions; b++)
/* 10255 */           this.binders[i][b] = null; 
/*       */       } 
/* 10257 */       this.currentRank = 0;
/*       */       
/* 10259 */       if (this.binders != null) {
/* 10260 */         this.currentRowBinders = this.binders[0];
/*       */       }
/* 10262 */       this.pushedBatches = null;
/* 10263 */       this.pushedBatchesTail = null;
/* 10264 */       this.firstRowInBatch = 0;
/*       */       
/* 10266 */       this.clearParameters = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void executeForRowsWithTimeout(boolean paramBoolean) throws SQLException {
/* 10279 */     if (this.queryTimeout > 0) {
/*       */ 
/*       */       
/*       */       try {
/* 10283 */         this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/* 10284 */         this.cancelLock.enterExecuting();
/* 10285 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10289 */         this.connection.getTimeout().cancelTimeout();
/* 10290 */         this.cancelLock.exitExecuting();
/*       */       } 
/*       */     } else {
/*       */ 
/*       */       
/*       */       try {
/*       */         
/* 10297 */         this.cancelLock.enterExecuting();
/* 10298 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10302 */         this.cancelLock.exitExecuting();
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int[] executeBatch() throws SQLException {
/* 10329 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10332 */       int[] arrayOfInt = new int[this.currentRank];
/* 10333 */       this.checkSum = 0L;
/* 10334 */       this.checkSumComputationFailure = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10340 */       byte b = 0;
/*       */       
/* 10342 */       cleanOldTempLobs();
/* 10343 */       setJdbcBatchStyle();
/*       */       
/* 10345 */       if (this.currentRank > 0) {
/*       */ 
/*       */ 
/*       */         
/* 10349 */         ensureOpen();
/*       */ 
/*       */         
/* 10352 */         prepareForNewResults(true, true);
/*       */         
/* 10354 */         if (this.sqlKind.isSELECT()) {
/*       */ 
/*       */           
/* 10357 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, 0, (int[])null);
/* 10358 */           batchUpdateException.fillInStackTrace();
/* 10359 */           throw batchUpdateException;
/*       */         } 
/*       */ 
/*       */ 
/*       */         
/* 10364 */         this.noMoreUpdateCounts = false;
/*       */         
/* 10366 */         int i = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         try {
/* 10378 */           this.connection.registerHeartbeat();
/*       */           
/* 10380 */           this.connection.needLine();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10386 */           if (!this.isOpen) {
/*       */             
/* 10388 */             this.connection.open(this);
/*       */             
/* 10390 */             this.isOpen = true;
/*       */           } 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10396 */           int j = this.currentRank;
/*       */           
/* 10398 */           if (this.pushedBatches == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 10403 */             setupBindBuffers(0, this.currentRank);
/* 10404 */             executeForRowsWithTimeout(false);
/*       */ 
/*       */           
/*       */           }
/*       */           else {
/*       */ 
/*       */ 
/*       */             
/* 10412 */             if (this.currentRank > this.firstRowInBatch)
/*       */             {
/*       */ 
/*       */               
/* 10416 */               pushBatch(true);
/*       */             }
/* 10418 */             boolean bool = this.needToParse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             do {
/* 10426 */               PushedBatch pushedBatch = this.pushedBatches;
/*       */               
/* 10428 */               this.currentBatchCharLens = pushedBatch.currentBatchCharLens;
/* 10429 */               this.lastBoundCharLens = pushedBatch.lastBoundCharLens;
/* 10430 */               this.lastBoundNeeded = pushedBatch.lastBoundNeeded;
/* 10431 */               this.currentBatchBindAccessors = pushedBatch.currentBatchBindAccessors;
/* 10432 */               this.needToParse = pushedBatch.need_to_parse;
/* 10433 */               this.currentBatchNeedToPrepareBinds = pushedBatch.current_batch_need_to_prepare_binds;
/*       */               
/* 10435 */               this.firstRowInBatch = pushedBatch.first_row_in_batch;
/*       */               
/* 10437 */               setupBindBuffers(pushedBatch.first_row_in_batch, pushedBatch.number_of_rows_to_be_bound);
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10442 */               this.currentRank = pushedBatch.number_of_rows_to_be_bound;
/*       */               
/* 10444 */               executeForRowsWithTimeout(false);
/*       */               
/* 10446 */               i += this.validRows;
/* 10447 */               if (this.sqlKind.isPlsqlOrCall())
/*       */               {
/* 10449 */                 arrayOfInt[b++] = this.validRows;
/*       */               }
/*       */               
/* 10452 */               this.pushedBatches = pushedBatch.next;
/*       */             
/*       */             }
/* 10455 */             while (this.pushedBatches != null);
/*       */ 
/*       */             
/* 10458 */             this.pushedBatchesTail = null;
/* 10459 */             this.firstRowInBatch = 0;
/*       */             
/* 10461 */             this.needToParse = bool;
/*       */           } 
/*       */ 
/*       */ 
/*       */           
/* 10466 */           slideDownCurrentRow(j);
/*       */ 
/*       */         
/*       */         }
/* 10470 */         catch (SQLException sQLException) {
/*       */ 
/*       */ 
/*       */           
/* 10474 */           int j = this.currentRank;
/* 10475 */           clearBatch();
/* 10476 */           this.needToParse = true;
/*       */           
/* 10478 */           if (!this.sqlKind.isPlsqlOrCall())
/*       */           {
/*       */ 
/*       */ 
/*       */             
/* 10483 */             if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch != j) {
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10488 */               arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 10489 */               for (b = 0; b < this.numberOfExecutedElementsInBatch; b++) {
/* 10490 */                 arrayOfInt[b] = -2;
/*       */               }
/*       */             } else {
/* 10493 */               for (b = 0; b < arrayOfInt.length; b++)
/* 10494 */                 arrayOfInt[b] = -3; 
/*       */             }  } 
/* 10496 */           resetCurrentRowBinders();
/*       */ 
/*       */           
/* 10499 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, this.sqlKind.isPlsqlOrCall() ? b : arrayOfInt.length, arrayOfInt);
/* 10500 */           batchUpdateException.fillInStackTrace();
/* 10501 */           throw batchUpdateException;
/*       */         
/*       */         }
/*       */         finally {
/*       */           
/* 10506 */           if (this.sqlKind.isPlsqlOrCall() || i > this.validRows) {
/* 10507 */             this.validRows = i;
/*       */           }
/* 10509 */           checkValidRowsStatus();
/*       */           
/* 10511 */           this.currentRank = 0;
/*       */         } 
/*       */         
/* 10514 */         if (this.validRows < 0) {
/*       */           
/* 10516 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 10517 */             arrayOfInt[b] = -3;
/*       */           }
/*       */           
/* 10520 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, 0, arrayOfInt);
/* 10521 */           batchUpdateException.fillInStackTrace();
/* 10522 */           throw batchUpdateException;
/*       */         } 
/*       */         
/* 10525 */         if (!this.sqlKind.isPlsqlOrCall())
/*       */         {
/* 10527 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 10528 */             arrayOfInt[b] = -2;
/*       */           }
/*       */         }
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10536 */       this.connection.registerHeartbeat();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10542 */       return arrayOfInt;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void pushBatch(boolean paramBoolean) {
/* 10550 */     PushedBatch pushedBatch = new PushedBatch();
/*       */     
/* 10552 */     pushedBatch.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10554 */     System.arraycopy(this.currentBatchCharLens, 0, pushedBatch.currentBatchCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 10557 */     pushedBatch.lastBoundCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10559 */     System.arraycopy(this.lastBoundCharLens, 0, pushedBatch.lastBoundCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 10562 */     if (this.currentBatchBindAccessors != null) {
/*       */       
/* 10564 */       pushedBatch.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       
/* 10566 */       System.arraycopy(this.currentBatchBindAccessors, 0, pushedBatch.currentBatchBindAccessors, 0, this.numberOfBindPositions);
/*       */     } 
/*       */ 
/*       */     
/* 10570 */     pushedBatch.lastBoundNeeded = this.lastBoundNeeded;
/* 10571 */     pushedBatch.need_to_parse = this.needToParse;
/* 10572 */     pushedBatch.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
/* 10573 */     pushedBatch.first_row_in_batch = this.firstRowInBatch;
/* 10574 */     pushedBatch.number_of_rows_to_be_bound = this.currentRank - this.firstRowInBatch;
/*       */     
/* 10576 */     if (this.pushedBatches == null) {
/* 10577 */       this.pushedBatches = pushedBatch;
/*       */     } else {
/* 10579 */       this.pushedBatchesTail.next = pushedBatch;
/*       */     } 
/* 10581 */     this.pushedBatchesTail = pushedBatch;
/*       */     
/* 10583 */     if (!paramBoolean) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10589 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/* 10591 */       this.currentBatchCharLens = this.lastBoundCharLens;
/* 10592 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/* 10594 */       this.lastBoundNeeded = false;
/*       */       
/* 10596 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/* 10597 */         this.currentBatchCharLens[b] = 0;
/*       */       }
/* 10599 */       this.firstRowInBatch = this.currentRank;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doScrollPstmtExecuteUpdate() throws SQLException {
/* 10613 */     doScrollExecuteCommon();
/*       */     
/* 10615 */     if (this.sqlKind.isSELECT()) {
/* 10616 */       this.scrollRsetTypeSolved = true;
/*       */     }
/* 10618 */     return this.validRows;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int copyBinds(Statement paramStatement, int paramInt) throws SQLException {
/* 10633 */     if (this.numberOfBindPositions > 0) {
/*       */       
/* 10635 */       OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)paramStatement;
/*       */       
/* 10637 */       int i = this.bindIndicatorSubRange + 5;
/*       */       
/* 10639 */       int j = this.bindByteSubRange;
/* 10640 */       int k = this.bindCharSubRange;
/* 10641 */       int m = this.indicatorsOffset;
/* 10642 */       int n = this.valueLengthsOffset;
/*       */       
/* 10644 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*       */         
/* 10646 */         short s1 = this.bindIndicators[i + 0];
/*       */         
/* 10648 */         short s2 = this.bindIndicators[i + 1];
/*       */         
/* 10650 */         short s3 = this.bindIndicators[i + 2];
/*       */ 
/*       */         
/* 10653 */         int i1 = b + paramInt;
/*       */ 
/*       */ 
/*       */         
/* 10657 */         if (oraclePreparedStatement.parameterDatum == null) {
/* 10658 */           oraclePreparedStatement.parameterDatum = new byte[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions][];
/*       */         }
/*       */         
/* 10661 */         if (oraclePreparedStatement.parameterOtype == null) {
/* 10662 */           oraclePreparedStatement.parameterOtype = new OracleTypeADT[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions];
/*       */         }
/*       */         
/* 10665 */         if (this.bindIndicators[m] == -1) {
/*       */           
/* 10667 */           oraclePreparedStatement.currentRowBinders[i1] = copiedNullBinder(s1, s2);
/*       */           
/* 10669 */           if (s3 > 0) {
/* 10670 */             oraclePreparedStatement.currentRowCharLens[i1] = 1;
/*       */           }
/* 10672 */         } else if (s1 == 109 || s1 == 111) {
/*       */           
/* 10674 */           oraclePreparedStatement.currentRowBinders[i1] = (s1 == 109) ? this.theNamedTypeBinder : this.theRefTypeBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10679 */           byte[] arrayOfByte1 = this.parameterDatum[0][b];
/* 10680 */           int i2 = arrayOfByte1.length;
/* 10681 */           byte[] arrayOfByte2 = new byte[i2];
/*       */           
/* 10683 */           oraclePreparedStatement.parameterDatum[0][i1] = arrayOfByte2;
/*       */           
/* 10685 */           System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i2);
/*       */           
/* 10687 */           oraclePreparedStatement.parameterOtype[0][i1] = this.parameterOtype[0][b];
/*       */         }
/* 10689 */         else if (s2 > 0) {
/*       */           
/* 10691 */           oraclePreparedStatement.currentRowBinders[i1] = copiedByteBinder(s1, this.bindBytes, j, s2, this.bindIndicators[n]);
/*       */         
/*       */         }
/* 10694 */         else if (s3 > 0) {
/*       */           
/* 10696 */           oraclePreparedStatement.currentRowBinders[i1] = copiedCharBinder(s1, this.bindChars, k, s3, this.bindIndicators[n], getInoutIndicator(b));
/*       */           
/* 10698 */           oraclePreparedStatement.currentRowCharLens[i1] = s3;
/*       */         }
/*       */         else {
/*       */           
/* 10702 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + s1);
/* 10703 */           sQLException.fillInStackTrace();
/* 10704 */           throw sQLException;
/*       */         } 
/*       */         
/* 10707 */         j += this.bindBufferCapacity * s2;
/* 10708 */         k += this.bindBufferCapacity * s3;
/* 10709 */         m += this.numberOfBindRowsAllocated;
/* 10710 */         n += this.numberOfBindRowsAllocated;
/* 10711 */         i += 10;
/*       */       } 
/*       */     } 
/*       */     
/* 10715 */     return this.numberOfBindPositions;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedNullBinder(short paramShort, int paramInt) throws SQLException {
/* 10722 */     return new CopiedNullBinder(paramShort, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedByteBinder(short paramShort1, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort2) throws SQLException {
/* 10730 */     byte[] arrayOfByte = new byte[paramInt2];
/*       */     
/* 10732 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*       */     
/* 10734 */     return new CopiedByteBinder(paramShort1, paramInt2, arrayOfByte, paramShort2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedCharBinder(short paramShort1, char[] paramArrayOfchar, int paramInt1, int paramInt2, short paramShort2, short paramShort3) throws SQLException {
/* 10742 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/* 10744 */     System.arraycopy(paramArrayOfchar, paramInt1, arrayOfChar, 0, paramInt2);
/*       */     
/* 10746 */     return new CopiedCharBinder(paramShort1, arrayOfChar, paramShort2, paramShort3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void hardClose() throws SQLException {
/* 10754 */     super.hardClose();
/*       */     
/* 10756 */     this.connection.cacheBuffer(this.bindBytes);
/* 10757 */     this.bindBytes = null;
/* 10758 */     this.connection.cacheBuffer(this.bindChars);
/* 10759 */     this.bindChars = null;
/* 10760 */     this.bindIndicators = null;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10765 */     if (!this.connection.isClosed())
/*       */     {
/* 10767 */       cleanAllTempLobs();
/*       */     }
/*       */     
/* 10770 */     this.lastBoundBytes = null;
/* 10771 */     this.lastBoundChars = null;
/*       */     
/* 10773 */     clearParameters();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void alwaysOnClose() throws SQLException {
/* 10785 */     if (this.currentRank > 0)
/*       */     {
/* 10787 */       if (this.m_batchStyle == 2) {
/* 10788 */         clearBatch();
/*       */       
/*       */       }
/*       */       else {
/*       */ 
/*       */         
/* 10794 */         int i = this.validRows;
/*       */         
/* 10796 */         this.prematureBatchCount = sendBatch();
/* 10797 */         this.validRows = i;
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10812 */     if (this.sqlKind.isSELECT()) {
/* 10813 */       OracleStatement oracleStatement = this.children;
/*       */       
/* 10815 */       while (oracleStatement != null) {
/* 10816 */         OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */ 
/*       */         
/* 10819 */         if (oracleStatement.serverCursor) {
/* 10820 */           oracleStatement.cursorId = 0;
/*       */         }
/* 10822 */         oracleStatement = oracleStatement1;
/*       */       } 
/*       */     } 
/*       */     
/* 10826 */     super.alwaysOnClose();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDisableStmtCaching(boolean paramBoolean) {
/* 10839 */     synchronized (this.connection) {
/*       */       
/* 10841 */       if (paramBoolean == true) {
/* 10842 */         this.cacheState = 3;
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFormOfUse(int paramInt, short paramShort) {
/* 10852 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10855 */       int i = paramInt - 1;
/*       */       
/* 10857 */       if (this.currentRowFormOfUse[i] != paramShort) {
/*       */         
/* 10859 */         this.currentRowFormOfUse[i] = paramShort;
/*       */ 
/*       */ 
/*       */         
/* 10863 */         if (this.currentRowBindAccessors != null) {
/*       */           
/* 10865 */           Accessor accessor = this.currentRowBindAccessors[i];
/*       */           
/* 10867 */           if (accessor != null) {
/* 10868 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */         
/* 10872 */         if (this.returnParamAccessors != null) {
/*       */           
/* 10874 */           Accessor accessor = this.returnParamAccessors[i];
/*       */           
/* 10876 */           if (accessor != null) {
/* 10877 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 10904 */     setURLInternal(paramInt, paramURL);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setURLInternal(int paramInt, URL paramURL) throws SQLException {
/* 10911 */     setStringInternal(paramInt, paramURL.toString());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 10918 */     return (ParameterMetaData)new OracleParameterMetaData(this.sqlObject.getParameterCount());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 10941 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10942 */     sQLException.fillInStackTrace();
/* 10943 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 10953 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10955 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10956 */       sQLException.fillInStackTrace();
/* 10957 */       throw sQLException;
/*       */     } 
/*       */     
/* 10960 */     if (this.numReturnParams <= 0) {
/*       */       
/* 10962 */       this.numReturnParams = this.sqlObject.getReturnParameterCount();
/* 10963 */       if (this.numReturnParams <= 0) {
/*       */         
/* 10965 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10966 */         sQLException.fillInStackTrace();
/* 10967 */         throw sQLException;
/*       */       } 
/*       */     } 
/*       */     
/* 10971 */     int i = paramInt1 - 1;
/* 10972 */     if (i < this.numberOfBindPositions - this.numReturnParams || paramInt1 > this.numberOfBindPositions) {
/*       */ 
/*       */       
/* 10975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10976 */       sQLException.fillInStackTrace();
/* 10977 */       throw sQLException;
/*       */     } 
/*       */     
/* 10980 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10982 */     short s = 0;
/* 10983 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 10984 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10986 */     registerReturnParameterInternal(i, j, paramInt2, -1, s, null);
/*       */ 
/*       */     
/* 10989 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 11000 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 11002 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 11003 */       sQLException.fillInStackTrace();
/* 11004 */       throw sQLException;
/*       */     } 
/*       */     
/* 11007 */     int i = paramInt1 - 1;
/* 11008 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 11010 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11011 */       sQLException.fillInStackTrace();
/* 11012 */       throw sQLException;
/*       */     } 
/*       */     
/* 11015 */     if (paramInt2 != 1 && paramInt2 != 12 && paramInt2 != -1 && paramInt2 != -2 && paramInt2 != -3 && paramInt2 != -4 && paramInt2 != 12) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 11024 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 11025 */       sQLException.fillInStackTrace();
/* 11026 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11030 */     if (paramInt3 <= 0) {
/*       */ 
/*       */       
/* 11033 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 11034 */       sQLException.fillInStackTrace();
/* 11035 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11039 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 11041 */     short s = 0;
/* 11042 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 11043 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 11045 */     registerReturnParameterInternal(i, j, paramInt2, paramInt3, s, null);
/*       */ 
/*       */     
/* 11048 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 11059 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 11061 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 11062 */       sQLException.fillInStackTrace();
/* 11063 */       throw sQLException;
/*       */     } 
/*       */     
/* 11066 */     int i = paramInt1 - 1;
/* 11067 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 11069 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11070 */       sQLException.fillInStackTrace();
/* 11071 */       throw sQLException;
/*       */     } 
/*       */     
/* 11074 */     int j = getInternalTypeForDmlReturning(paramInt2);
/* 11075 */     if (j != 111 && j != 109) {
/*       */ 
/*       */ 
/*       */       
/* 11079 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 11080 */       sQLException.fillInStackTrace();
/* 11081 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11085 */     registerReturnParameterInternal(i, j, paramInt2, -1, (short)0, paramString);
/*       */ 
/*       */     
/* 11088 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ResultSet getReturnResultSet() throws SQLException {
/* 11096 */     if (this.closed) {
/*       */       
/* 11098 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 11099 */       sQLException.fillInStackTrace();
/* 11100 */       throw sQLException;
/*       */     } 
/*       */     
/* 11103 */     if (this.returnParamAccessors == null || this.numReturnParams == 0) {
/*       */       
/* 11105 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 11106 */       sQLException.fillInStackTrace();
/* 11107 */       throw sQLException;
/*       */     } 
/*       */     
/* 11110 */     if (this.returnResultSet == null || this.numReturnParams == 0 || !this.isOpen)
/*       */     {
/*       */ 
/*       */       
/* 11114 */       this.returnResultSet = new OracleReturnResultSet(this);
/*       */     }
/*       */     
/* 11117 */     return (ResultSet)this.returnResultSet;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getInternalTypeForDmlReturning(int paramInt) throws SQLException {
/* 11131 */     char c = Character.MIN_VALUE;
/*       */     
/* 11133 */     switch (paramInt) {
/*       */       
/*       */       case -7:
/*       */       case -6:
/*       */       case -5:
/*       */       case 2:
/*       */       case 3:
/*       */       case 4:
/*       */       case 5:
/*       */       case 6:
/*       */       case 7:
/*       */       case 8:
/* 11145 */         c = '\006';
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 11267 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case -15: case 1: c = '`'; return c;case -9: case 12: c = '\001'; return c;case -16: case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: case 2011: c = 'p'; return c;case -13: c = 'r'; return c;case 2002: case 2003: case 2007: case 2008: case 2009: c = 'm'; return c;case 2006: c = 'o'; return c;case 70: c = '\001'; return c;
/*       */     } 
/*       */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*       */     sQLException.fillInStackTrace();
/*       */     throw sQLException;
/*       */   }
/*       */   
/*       */   void registerReturnParamsForAutoKey() throws SQLException {
/* 11275 */     int[] arrayOfInt1 = this.autoKeyInfo.returnTypes;
/* 11276 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 11277 */     int[] arrayOfInt2 = this.autoKeyInfo.columnIndexes;
/*       */     
/* 11279 */     int i = arrayOfInt1.length;
/*       */ 
/*       */     
/* 11282 */     int j = this.numberOfBindPositions - i;
/*       */ 
/*       */     
/* 11285 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 11287 */       int k = j + b;
/* 11288 */       this.currentRowBinders[k] = this.theReturnParamBinder;
/*       */       
/* 11290 */       byte b1 = this.connection.defaultnchar ? 2 : 1;
/*       */ 
/*       */       
/* 11293 */       if (arrayOfShort != null && arrayOfInt2 != null)
/*       */       {
/* 11295 */         if (arrayOfShort[arrayOfInt2[b] - 1] == 2) {
/*       */ 
/*       */           
/* 11298 */           b1 = 2;
/* 11299 */           setFormOfUse(k + 1, b1);
/*       */         } 
/*       */       }
/*       */       
/* 11303 */       checkTypeForAutoKey(arrayOfInt1[b]);
/*       */       
/* 11305 */       String str = null;
/* 11306 */       if (arrayOfInt1[b] == 111) {
/* 11307 */         str = this.autoKeyInfo.tableTypeNames[arrayOfInt2[b] - 1];
/*       */       }
/* 11309 */       registerReturnParameterInternal(k, arrayOfInt1[b], arrayOfInt1[b], -1, b1, str);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanOldTempLobs() {
/* 11319 */     if (this.m_batchStyle != 1 || this.currentRank == this.batch - 1)
/*       */     {
/* 11321 */       super.cleanOldTempLobs();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   void resetOnExceptionDuringExecute() {
/* 11328 */     super.resetOnExceptionDuringExecute();
/* 11329 */     this.currentRank = 0;
/* 11330 */     this.currentBatchNeedToPrepareBinds = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetCurrentRowBinders() {
/* 11339 */     Binder[] arrayOfBinder = this.currentRowBinders;
/* 11340 */     if (this.binders != null && this.currentRowBinders != null && arrayOfBinder != this.binders[0]) {
/*       */ 
/*       */ 
/*       */       
/* 11344 */       this.currentRowBinders = this.binders[0];
/* 11345 */       this.binders[this.numberOfBoundRows] = arrayOfBinder;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11364 */     setAsciiStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11379 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11393 */     setBinaryStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11408 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11421 */     setBlobInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11435 */     if (paramLong < 0L) {
/*       */       
/* 11437 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 11438 */       sQLException.fillInStackTrace();
/* 11439 */       throw sQLException;
/*       */     } 
/* 11441 */     setBlobInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 11455 */     setCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11470 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11484 */     if (paramLong < 0L) {
/*       */       
/* 11486 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 11487 */       sQLException.fillInStackTrace();
/* 11488 */       throw sQLException;
/*       */     } 
/* 11490 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 11504 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 11519 */     setRowIdInternal(paramInt, paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 11535 */     setNCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11551 */     setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 11566 */     setNClobInternal(paramInt, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11582 */     setNClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 11597 */     setNClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 11604 */     setSQLXMLInternal(paramInt, paramSQLXML);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNString(int paramInt, String paramString) throws SQLException {
/* 11619 */     setNStringInternal(paramInt, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11627 */     setAsciiStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11635 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11643 */     setBinaryStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11651 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11660 */     int i = paramInt - 1;
/*       */     
/* 11662 */     if (i < 0 || paramInt > this.numberOfBindPositions) {
/*       */       
/* 11664 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11665 */       sQLException.fillInStackTrace();
/* 11666 */       throw sQLException;
/*       */     } 
/*       */     
/* 11669 */     if (paramInputStream == null) {
/* 11670 */       setNullInternal(paramInt, 2004);
/*       */     } else {
/* 11672 */       setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, !(paramLong == -1L));
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11681 */     setBlobInternal(paramInt, paramInputStream, -1L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11689 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11697 */     setCharacterStreamInternal(paramInt, paramReader, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setClobInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11705 */     setClobInternal(paramInt, paramReader, -1L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setClobInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11713 */     int i = paramInt - 1;
/*       */     
/* 11715 */     if (i < 0 || paramInt > this.numberOfBindPositions) {
/*       */       
/* 11717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11718 */       sQLException.fillInStackTrace();
/* 11719 */       throw sQLException;
/*       */     } 
/*       */     
/* 11722 */     if (paramReader == null) {
/* 11723 */       setNullInternal(paramInt, 2005);
/*       */     } else {
/* 11725 */       setReaderContentsForClobCritical(paramInt, paramReader, paramLong, !(paramLong == -1L));
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11733 */     setFormOfUse(paramInt, (short)2);
/* 11734 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11742 */     setFormOfUse(paramInt, (short)2);
/* 11743 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, NClob paramNClob) throws SQLException {
/* 11751 */     setFormOfUse(paramInt, (short)2);
/* 11752 */     setClobInternal(paramInt, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11760 */     setFormOfUse(paramInt, (short)2);
/* 11761 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11769 */     setFormOfUse(paramInt, (short)2);
/* 11770 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNStringInternal(int paramInt, String paramString) throws SQLException {
/* 11778 */     setFormOfUse(paramInt, (short)2);
/* 11779 */     setStringInternal(paramInt, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setRowIdInternal(int paramInt, RowId paramRowId) throws SQLException {
/* 11787 */     setROWIDInternal(paramInt, (ROWID)paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/* 11814 */     String str = paramString.intern();
/* 11815 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11816 */     boolean bool = false;
/* 11817 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11819 */     for (byte b = 0; b < i; b++) {
/* 11820 */       if (arrayOfString[b] == str) {
/*       */         
/* 11822 */         setArray(b + 1, paramArray);
/*       */         
/* 11824 */         bool = true;
/*       */       } 
/*       */     } 
/* 11827 */     if (!bool) {
/*       */       
/* 11829 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11830 */       sQLException.fillInStackTrace();
/* 11831 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 11851 */     String str = paramString.intern();
/* 11852 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11853 */     boolean bool = false;
/* 11854 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11856 */     for (byte b = 0; b < i; b++) {
/* 11857 */       if (arrayOfString[b] == str) {
/*       */         
/* 11859 */         setBigDecimal(b + 1, paramBigDecimal);
/*       */         
/* 11861 */         bool = true;
/*       */       } 
/*       */     } 
/* 11864 */     if (!bool) {
/*       */       
/* 11866 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11867 */       sQLException.fillInStackTrace();
/* 11868 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/* 11888 */     String str = paramString.intern();
/* 11889 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11890 */     boolean bool = false;
/* 11891 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11893 */     for (byte b = 0; b < i; b++) {
/* 11894 */       if (arrayOfString[b] == str) {
/*       */         
/* 11896 */         setBlob(b + 1, paramBlob);
/*       */         
/* 11898 */         bool = true;
/*       */       } 
/*       */     } 
/* 11901 */     if (!bool) {
/*       */       
/* 11903 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11904 */       sQLException.fillInStackTrace();
/* 11905 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/* 11925 */     String str = paramString.intern();
/* 11926 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11927 */     boolean bool = false;
/* 11928 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11930 */     for (byte b = 0; b < i; b++) {
/* 11931 */       if (arrayOfString[b] == str) {
/*       */         
/* 11933 */         setBoolean(b + 1, paramBoolean);
/*       */         
/* 11935 */         bool = true;
/*       */       } 
/*       */     } 
/* 11938 */     if (!bool) {
/*       */       
/* 11940 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11941 */       sQLException.fillInStackTrace();
/* 11942 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/* 11962 */     String str = paramString.intern();
/* 11963 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11964 */     boolean bool = false;
/* 11965 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11967 */     for (byte b = 0; b < i; b++) {
/* 11968 */       if (arrayOfString[b] == str) {
/*       */         
/* 11970 */         setByte(b + 1, paramByte);
/*       */         
/* 11972 */         bool = true;
/*       */       } 
/*       */     } 
/* 11975 */     if (!bool) {
/*       */       
/* 11977 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11978 */       sQLException.fillInStackTrace();
/* 11979 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 11999 */     String str = paramString.intern();
/* 12000 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12001 */     boolean bool = false;
/* 12002 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12004 */     for (byte b = 0; b < i; b++) {
/* 12005 */       if (arrayOfString[b] == str) {
/*       */         
/* 12007 */         setBytes(b + 1, paramArrayOfbyte);
/*       */         
/* 12009 */         bool = true;
/*       */       } 
/*       */     } 
/* 12012 */     if (!bool) {
/*       */       
/* 12014 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12015 */       sQLException.fillInStackTrace();
/* 12016 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/* 12036 */     String str = paramString.intern();
/* 12037 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12038 */     boolean bool = false;
/* 12039 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12041 */     for (byte b = 0; b < i; b++) {
/* 12042 */       if (arrayOfString[b] == str) {
/*       */         
/* 12044 */         setClob(b + 1, paramClob);
/*       */         
/* 12046 */         bool = true;
/*       */       } 
/*       */     } 
/* 12049 */     if (!bool) {
/*       */       
/* 12051 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12052 */       sQLException.fillInStackTrace();
/* 12053 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/* 12073 */     String str = paramString.intern();
/* 12074 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12075 */     boolean bool = false;
/* 12076 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12078 */     for (byte b = 0; b < i; b++) {
/* 12079 */       if (arrayOfString[b] == str) {
/*       */         
/* 12081 */         setDate(b + 1, paramDate);
/*       */         
/* 12083 */         bool = true;
/*       */       } 
/*       */     } 
/* 12086 */     if (!bool) {
/*       */       
/* 12088 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12089 */       sQLException.fillInStackTrace();
/* 12090 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 12110 */     String str = paramString.intern();
/* 12111 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12112 */     boolean bool = false;
/* 12113 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12115 */     for (byte b = 0; b < i; b++) {
/* 12116 */       if (arrayOfString[b] == str) {
/*       */         
/* 12118 */         setDate(b + 1, paramDate, paramCalendar);
/*       */         
/* 12120 */         bool = true;
/*       */       } 
/*       */     } 
/* 12123 */     if (!bool) {
/*       */       
/* 12125 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12126 */       sQLException.fillInStackTrace();
/* 12127 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 12147 */     String str = paramString.intern();
/* 12148 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12149 */     boolean bool = false;
/* 12150 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12152 */     for (byte b = 0; b < i; b++) {
/* 12153 */       if (arrayOfString[b] == str) {
/*       */         
/* 12155 */         setDouble(b + 1, paramDouble);
/*       */         
/* 12157 */         bool = true;
/*       */       } 
/*       */     } 
/* 12160 */     if (!bool) {
/*       */       
/* 12162 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12163 */       sQLException.fillInStackTrace();
/* 12164 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 12184 */     String str = paramString.intern();
/* 12185 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12186 */     boolean bool = false;
/* 12187 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12189 */     for (byte b = 0; b < i; b++) {
/* 12190 */       if (arrayOfString[b] == str) {
/*       */         
/* 12192 */         setFloat(b + 1, paramFloat);
/*       */         
/* 12194 */         bool = true;
/*       */       } 
/*       */     } 
/* 12197 */     if (!bool) {
/*       */       
/* 12199 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12200 */       sQLException.fillInStackTrace();
/* 12201 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/* 12221 */     String str = paramString.intern();
/* 12222 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12223 */     boolean bool = false;
/* 12224 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12226 */     for (byte b = 0; b < i; b++) {
/* 12227 */       if (arrayOfString[b] == str) {
/*       */         
/* 12229 */         setInt(b + 1, paramInt);
/*       */         
/* 12231 */         bool = true;
/*       */       } 
/*       */     } 
/* 12234 */     if (!bool) {
/*       */       
/* 12236 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12237 */       sQLException.fillInStackTrace();
/* 12238 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/* 12258 */     String str = paramString.intern();
/* 12259 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12260 */     boolean bool = false;
/* 12261 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12263 */     for (byte b = 0; b < i; b++) {
/* 12264 */       if (arrayOfString[b] == str) {
/*       */         
/* 12266 */         setLong(b + 1, paramLong);
/*       */         
/* 12268 */         bool = true;
/*       */       } 
/*       */     } 
/* 12271 */     if (!bool) {
/*       */       
/* 12273 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12274 */       sQLException.fillInStackTrace();
/* 12275 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, NClob paramNClob) throws SQLException {
/* 12295 */     String str = paramString.intern();
/* 12296 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12297 */     boolean bool = false;
/* 12298 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12300 */     for (byte b = 0; b < i; b++) {
/* 12301 */       if (arrayOfString[b] == str) {
/*       */         
/* 12303 */         setNClob(b + 1, paramNClob);
/*       */         
/* 12305 */         bool = true;
/*       */       } 
/*       */     } 
/* 12308 */     if (!bool) {
/*       */       
/* 12310 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12311 */       sQLException.fillInStackTrace();
/* 12312 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNStringAtName(String paramString1, String paramString2) throws SQLException {
/* 12332 */     String str = paramString1.intern();
/* 12333 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12334 */     boolean bool = false;
/* 12335 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12337 */     for (byte b = 0; b < i; b++) {
/* 12338 */       if (arrayOfString[b] == str) {
/*       */         
/* 12340 */         setNString(b + 1, paramString2);
/*       */         
/* 12342 */         bool = true;
/*       */       } 
/*       */     } 
/* 12345 */     if (!bool) {
/*       */       
/* 12347 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12348 */       sQLException.fillInStackTrace();
/* 12349 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/* 12369 */     String str = paramString.intern();
/* 12370 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12371 */     boolean bool = false;
/* 12372 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12374 */     for (byte b = 0; b < i; b++) {
/* 12375 */       if (arrayOfString[b] == str) {
/*       */         
/* 12377 */         setObject(b + 1, paramObject);
/*       */         
/* 12379 */         bool = true;
/*       */       } 
/*       */     } 
/* 12382 */     if (!bool) {
/*       */       
/* 12384 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12385 */       sQLException.fillInStackTrace();
/* 12386 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 12406 */     String str = paramString.intern();
/* 12407 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12408 */     boolean bool = false;
/* 12409 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12411 */     for (byte b = 0; b < i; b++) {
/* 12412 */       if (arrayOfString[b] == str) {
/*       */         
/* 12414 */         setObject(b + 1, paramObject, paramInt);
/*       */         
/* 12416 */         bool = true;
/*       */       } 
/*       */     } 
/* 12419 */     if (!bool) {
/*       */       
/* 12421 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12422 */       sQLException.fillInStackTrace();
/* 12423 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/* 12443 */     String str = paramString.intern();
/* 12444 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12445 */     boolean bool = false;
/* 12446 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12448 */     for (byte b = 0; b < i; b++) {
/* 12449 */       if (arrayOfString[b] == str) {
/*       */         
/* 12451 */         setRef(b + 1, paramRef);
/*       */         
/* 12453 */         bool = true;
/*       */       } 
/*       */     } 
/* 12456 */     if (!bool) {
/*       */       
/* 12458 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12459 */       sQLException.fillInStackTrace();
/* 12460 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowIdAtName(String paramString, RowId paramRowId) throws SQLException {
/* 12480 */     String str = paramString.intern();
/* 12481 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12482 */     boolean bool = false;
/* 12483 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12485 */     for (byte b = 0; b < i; b++) {
/* 12486 */       if (arrayOfString[b] == str) {
/*       */         
/* 12488 */         setRowId(b + 1, paramRowId);
/*       */         
/* 12490 */         bool = true;
/*       */       } 
/*       */     } 
/* 12493 */     if (!bool) {
/*       */       
/* 12495 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12496 */       sQLException.fillInStackTrace();
/* 12497 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/* 12517 */     String str = paramString.intern();
/* 12518 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12519 */     boolean bool = false;
/* 12520 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12522 */     for (byte b = 0; b < i; b++) {
/* 12523 */       if (arrayOfString[b] == str) {
/*       */         
/* 12525 */         setShort(b + 1, paramShort);
/*       */         
/* 12527 */         bool = true;
/*       */       } 
/*       */     } 
/* 12530 */     if (!bool) {
/*       */       
/* 12532 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12533 */       sQLException.fillInStackTrace();
/* 12534 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXMLAtName(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 12554 */     String str = paramString.intern();
/* 12555 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12556 */     boolean bool = false;
/* 12557 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12559 */     for (byte b = 0; b < i; b++) {
/* 12560 */       if (arrayOfString[b] == str) {
/*       */         
/* 12562 */         setSQLXML(b + 1, paramSQLXML);
/*       */         
/* 12564 */         bool = true;
/*       */       } 
/*       */     } 
/* 12567 */     if (!bool) {
/*       */       
/* 12569 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12570 */       sQLException.fillInStackTrace();
/* 12571 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/* 12591 */     String str = paramString1.intern();
/* 12592 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12593 */     boolean bool = false;
/* 12594 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12596 */     for (byte b = 0; b < i; b++) {
/* 12597 */       if (arrayOfString[b] == str) {
/*       */         
/* 12599 */         setString(b + 1, paramString2);
/*       */         
/* 12601 */         bool = true;
/*       */       } 
/*       */     } 
/* 12604 */     if (!bool) {
/*       */       
/* 12606 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12607 */       sQLException.fillInStackTrace();
/* 12608 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/* 12628 */     String str = paramString.intern();
/* 12629 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12630 */     boolean bool = false;
/* 12631 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12633 */     for (byte b = 0; b < i; b++) {
/* 12634 */       if (arrayOfString[b] == str) {
/*       */         
/* 12636 */         setTime(b + 1, paramTime);
/*       */         
/* 12638 */         bool = true;
/*       */       } 
/*       */     } 
/* 12641 */     if (!bool) {
/*       */       
/* 12643 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12644 */       sQLException.fillInStackTrace();
/* 12645 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 12665 */     String str = paramString.intern();
/* 12666 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12667 */     boolean bool = false;
/* 12668 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12670 */     for (byte b = 0; b < i; b++) {
/* 12671 */       if (arrayOfString[b] == str) {
/*       */         
/* 12673 */         setTime(b + 1, paramTime, paramCalendar);
/*       */         
/* 12675 */         bool = true;
/*       */       } 
/*       */     } 
/* 12678 */     if (!bool) {
/*       */       
/* 12680 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12681 */       sQLException.fillInStackTrace();
/* 12682 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 12702 */     String str = paramString.intern();
/* 12703 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12704 */     boolean bool = false;
/* 12705 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12707 */     for (byte b = 0; b < i; b++) {
/* 12708 */       if (arrayOfString[b] == str) {
/*       */         
/* 12710 */         setTimestamp(b + 1, paramTimestamp);
/*       */         
/* 12712 */         bool = true;
/*       */       } 
/*       */     } 
/* 12715 */     if (!bool) {
/*       */       
/* 12717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12718 */       sQLException.fillInStackTrace();
/* 12719 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 12739 */     String str = paramString.intern();
/* 12740 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12741 */     boolean bool = false;
/* 12742 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12744 */     for (byte b = 0; b < i; b++) {
/* 12745 */       if (arrayOfString[b] == str) {
/*       */         
/* 12747 */         setTimestamp(b + 1, paramTimestamp, paramCalendar);
/*       */         
/* 12749 */         bool = true;
/*       */       } 
/*       */     } 
/* 12752 */     if (!bool) {
/*       */       
/* 12754 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12755 */       sQLException.fillInStackTrace();
/* 12756 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/* 12776 */     String str = paramString.intern();
/* 12777 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12778 */     boolean bool = false;
/* 12779 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12781 */     for (byte b = 0; b < i; b++) {
/* 12782 */       if (arrayOfString[b] == str) {
/*       */         
/* 12784 */         setURL(b + 1, paramURL);
/*       */         
/* 12786 */         bool = true;
/*       */       } 
/*       */     } 
/* 12789 */     if (!bool) {
/*       */       
/* 12791 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12792 */       sQLException.fillInStackTrace();
/* 12793 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/* 12813 */     String str = paramString.intern();
/* 12814 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12815 */     boolean bool = false;
/* 12816 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12818 */     for (byte b = 0; b < i; b++) {
/* 12819 */       if (arrayOfString[b] == str) {
/*       */         
/* 12821 */         setARRAY(b + 1, paramARRAY);
/*       */         
/* 12823 */         bool = true;
/*       */       } 
/*       */     } 
/* 12826 */     if (!bool) {
/*       */       
/* 12828 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12829 */       sQLException.fillInStackTrace();
/* 12830 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 12850 */     String str = paramString.intern();
/* 12851 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12852 */     boolean bool = false;
/* 12853 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12855 */     for (byte b = 0; b < i; b++) {
/* 12856 */       if (arrayOfString[b] == str) {
/*       */         
/* 12858 */         setBFILE(b + 1, paramBFILE);
/*       */         
/* 12860 */         bool = true;
/*       */       } 
/*       */     } 
/* 12863 */     if (!bool) {
/*       */       
/* 12865 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12866 */       sQLException.fillInStackTrace();
/* 12867 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 12887 */     String str = paramString.intern();
/* 12888 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12889 */     boolean bool = false;
/* 12890 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12892 */     for (byte b = 0; b < i; b++) {
/* 12893 */       if (arrayOfString[b] == str) {
/*       */         
/* 12895 */         setBfile(b + 1, paramBFILE);
/*       */         
/* 12897 */         bool = true;
/*       */       } 
/*       */     } 
/* 12900 */     if (!bool) {
/*       */       
/* 12902 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12903 */       sQLException.fillInStackTrace();
/* 12904 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 12924 */     String str = paramString.intern();
/* 12925 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12926 */     boolean bool = false;
/* 12927 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12929 */     for (byte b = 0; b < i; b++) {
/* 12930 */       if (arrayOfString[b] == str) {
/*       */         
/* 12932 */         setBinaryFloat(b + 1, paramFloat);
/*       */         
/* 12934 */         bool = true;
/*       */       } 
/*       */     } 
/* 12937 */     if (!bool) {
/*       */       
/* 12939 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12940 */       sQLException.fillInStackTrace();
/* 12941 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 12961 */     String str = paramString.intern();
/* 12962 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12963 */     boolean bool = false;
/* 12964 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12966 */     for (byte b = 0; b < i; b++) {
/* 12967 */       if (arrayOfString[b] == str) {
/*       */         
/* 12969 */         setBinaryFloat(b + 1, paramBINARY_FLOAT);
/*       */         
/* 12971 */         bool = true;
/*       */       } 
/*       */     } 
/* 12974 */     if (!bool) {
/*       */       
/* 12976 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12977 */       sQLException.fillInStackTrace();
/* 12978 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 12998 */     String str = paramString.intern();
/* 12999 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13000 */     boolean bool = false;
/* 13001 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13003 */     for (byte b = 0; b < i; b++) {
/* 13004 */       if (arrayOfString[b] == str) {
/*       */         
/* 13006 */         setBinaryDouble(b + 1, paramDouble);
/*       */         
/* 13008 */         bool = true;
/*       */       } 
/*       */     } 
/* 13011 */     if (!bool) {
/*       */       
/* 13013 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13014 */       sQLException.fillInStackTrace();
/* 13015 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 13035 */     String str = paramString.intern();
/* 13036 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13037 */     boolean bool = false;
/* 13038 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13040 */     for (byte b = 0; b < i; b++) {
/* 13041 */       if (arrayOfString[b] == str) {
/*       */         
/* 13043 */         setBinaryDouble(b + 1, paramBINARY_DOUBLE);
/*       */         
/* 13045 */         bool = true;
/*       */       } 
/*       */     } 
/* 13048 */     if (!bool) {
/*       */       
/* 13050 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13051 */       sQLException.fillInStackTrace();
/* 13052 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/* 13072 */     String str = paramString.intern();
/* 13073 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13074 */     boolean bool = false;
/* 13075 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13077 */     for (byte b = 0; b < i; b++) {
/* 13078 */       if (arrayOfString[b] == str) {
/*       */         
/* 13080 */         setBLOB(b + 1, paramBLOB);
/*       */         
/* 13082 */         bool = true;
/*       */       } 
/*       */     } 
/* 13085 */     if (!bool) {
/*       */       
/* 13087 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13088 */       sQLException.fillInStackTrace();
/* 13089 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/* 13109 */     String str = paramString.intern();
/* 13110 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13111 */     boolean bool = false;
/* 13112 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13114 */     for (byte b = 0; b < i; b++) {
/* 13115 */       if (arrayOfString[b] == str) {
/*       */         
/* 13117 */         setCHAR(b + 1, paramCHAR);
/*       */         
/* 13119 */         bool = true;
/*       */       } 
/*       */     } 
/* 13122 */     if (!bool) {
/*       */       
/* 13124 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13125 */       sQLException.fillInStackTrace();
/* 13126 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/* 13146 */     String str = paramString.intern();
/* 13147 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13148 */     boolean bool = false;
/* 13149 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13151 */     for (byte b = 0; b < i; b++) {
/* 13152 */       if (arrayOfString[b] == str) {
/*       */         
/* 13154 */         setCLOB(b + 1, paramCLOB);
/*       */         
/* 13156 */         bool = true;
/*       */       } 
/*       */     } 
/* 13159 */     if (!bool) {
/*       */       
/* 13161 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13162 */       sQLException.fillInStackTrace();
/* 13163 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/* 13183 */     String str = paramString.intern();
/* 13184 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13185 */     boolean bool = false;
/* 13186 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13188 */     for (byte b = 0; b < i; b++) {
/* 13189 */       if (arrayOfString[b] == str) {
/*       */         
/* 13191 */         setCursor(b + 1, paramResultSet);
/*       */         
/* 13193 */         bool = true;
/*       */       } 
/*       */     } 
/* 13196 */     if (!bool) {
/*       */       
/* 13198 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13199 */       sQLException.fillInStackTrace();
/* 13200 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 13220 */     String str = paramString.intern();
/* 13221 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13222 */     boolean bool = false;
/* 13223 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13225 */     for (byte b = 0; b < i; b++) {
/* 13226 */       if (arrayOfString[b] == str) {
/*       */         
/* 13228 */         setCustomDatum(b + 1, paramCustomDatum);
/*       */         
/* 13230 */         bool = true;
/*       */       } 
/*       */     } 
/* 13233 */     if (!bool) {
/*       */       
/* 13235 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13236 */       sQLException.fillInStackTrace();
/* 13237 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/* 13257 */     String str = paramString.intern();
/* 13258 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13259 */     boolean bool = false;
/* 13260 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13262 */     for (byte b = 0; b < i; b++) {
/* 13263 */       if (arrayOfString[b] == str) {
/*       */         
/* 13265 */         setDATE(b + 1, paramDATE);
/*       */         
/* 13267 */         bool = true;
/*       */       } 
/*       */     } 
/* 13270 */     if (!bool) {
/*       */       
/* 13272 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13273 */       sQLException.fillInStackTrace();
/* 13274 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/* 13294 */     String str = paramString1.intern();
/* 13295 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13296 */     boolean bool = false;
/* 13297 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13299 */     for (byte b = 0; b < i; b++) {
/* 13300 */       if (arrayOfString[b] == str) {
/*       */         
/* 13302 */         setFixedCHAR(b + 1, paramString2);
/*       */         
/* 13304 */         bool = true;
/*       */       } 
/*       */     } 
/* 13307 */     if (!bool) {
/*       */       
/* 13309 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 13310 */       sQLException.fillInStackTrace();
/* 13311 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 13331 */     String str = paramString.intern();
/* 13332 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13333 */     boolean bool = false;
/* 13334 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13336 */     for (byte b = 0; b < i; b++) {
/* 13337 */       if (arrayOfString[b] == str) {
/*       */         
/* 13339 */         setINTERVALDS(b + 1, paramINTERVALDS);
/*       */         
/* 13341 */         bool = true;
/*       */       } 
/*       */     } 
/* 13344 */     if (!bool) {
/*       */       
/* 13346 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13347 */       sQLException.fillInStackTrace();
/* 13348 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 13368 */     String str = paramString.intern();
/* 13369 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13370 */     boolean bool = false;
/* 13371 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13373 */     for (byte b = 0; b < i; b++) {
/* 13374 */       if (arrayOfString[b] == str) {
/*       */         
/* 13376 */         setINTERVALYM(b + 1, paramINTERVALYM);
/*       */         
/* 13378 */         bool = true;
/*       */       } 
/*       */     } 
/* 13381 */     if (!bool) {
/*       */       
/* 13383 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13384 */       sQLException.fillInStackTrace();
/* 13385 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 13405 */     String str = paramString.intern();
/* 13406 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13407 */     boolean bool = false;
/* 13408 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13410 */     for (byte b = 0; b < i; b++) {
/* 13411 */       if (arrayOfString[b] == str) {
/*       */         
/* 13413 */         setNUMBER(b + 1, paramNUMBER);
/*       */         
/* 13415 */         bool = true;
/*       */       } 
/*       */     } 
/* 13418 */     if (!bool) {
/*       */       
/* 13420 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13421 */       sQLException.fillInStackTrace();
/* 13422 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 13442 */     String str = paramString.intern();
/* 13443 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13444 */     boolean bool = false;
/* 13445 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13447 */     for (byte b = 0; b < i; b++) {
/* 13448 */       if (arrayOfString[b] == str) {
/*       */         
/* 13450 */         setOPAQUE(b + 1, paramOPAQUE);
/*       */         
/* 13452 */         bool = true;
/*       */       } 
/*       */     } 
/* 13455 */     if (!bool) {
/*       */       
/* 13457 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13458 */       sQLException.fillInStackTrace();
/* 13459 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/* 13479 */     String str = paramString.intern();
/* 13480 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13481 */     boolean bool = false;
/* 13482 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13484 */     for (byte b = 0; b < i; b++) {
/* 13485 */       if (arrayOfString[b] == str) {
/*       */         
/* 13487 */         setOracleObject(b + 1, paramDatum);
/*       */         
/* 13489 */         bool = true;
/*       */       } 
/*       */     } 
/* 13492 */     if (!bool) {
/*       */       
/* 13494 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13495 */       sQLException.fillInStackTrace();
/* 13496 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/* 13516 */     String str = paramString.intern();
/* 13517 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13518 */     boolean bool = false;
/* 13519 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13521 */     for (byte b = 0; b < i; b++) {
/* 13522 */       if (arrayOfString[b] == str) {
/*       */         
/* 13524 */         setORAData(b + 1, paramORAData);
/*       */         
/* 13526 */         bool = true;
/*       */       } 
/*       */     } 
/* 13529 */     if (!bool) {
/*       */       
/* 13531 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13532 */       sQLException.fillInStackTrace();
/* 13533 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/* 13553 */     String str = paramString.intern();
/* 13554 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13555 */     boolean bool = false;
/* 13556 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13558 */     for (byte b = 0; b < i; b++) {
/* 13559 */       if (arrayOfString[b] == str) {
/*       */         
/* 13561 */         setRAW(b + 1, paramRAW);
/*       */         
/* 13563 */         bool = true;
/*       */       } 
/*       */     } 
/* 13566 */     if (!bool) {
/*       */       
/* 13568 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13569 */       sQLException.fillInStackTrace();
/* 13570 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/* 13590 */     String str = paramString.intern();
/* 13591 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13592 */     boolean bool = false;
/* 13593 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13595 */     for (byte b = 0; b < i; b++) {
/* 13596 */       if (arrayOfString[b] == str) {
/*       */         
/* 13598 */         setREF(b + 1, paramREF);
/*       */         
/* 13600 */         bool = true;
/*       */       } 
/*       */     } 
/* 13603 */     if (!bool) {
/*       */       
/* 13605 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13606 */       sQLException.fillInStackTrace();
/* 13607 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/* 13627 */     String str = paramString.intern();
/* 13628 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13629 */     boolean bool = false;
/* 13630 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13632 */     for (byte b = 0; b < i; b++) {
/* 13633 */       if (arrayOfString[b] == str) {
/*       */         
/* 13635 */         setRefType(b + 1, paramREF);
/*       */         
/* 13637 */         bool = true;
/*       */       } 
/*       */     } 
/* 13640 */     if (!bool) {
/*       */       
/* 13642 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13643 */       sQLException.fillInStackTrace();
/* 13644 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/* 13664 */     String str = paramString.intern();
/* 13665 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13666 */     boolean bool = false;
/* 13667 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13669 */     for (byte b = 0; b < i; b++) {
/* 13670 */       if (arrayOfString[b] == str) {
/*       */         
/* 13672 */         setROWID(b + 1, paramROWID);
/*       */         
/* 13674 */         bool = true;
/*       */       } 
/*       */     } 
/* 13677 */     if (!bool) {
/*       */       
/* 13679 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13680 */       sQLException.fillInStackTrace();
/* 13681 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 13701 */     String str = paramString.intern();
/* 13702 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13703 */     boolean bool = false;
/* 13704 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13706 */     for (byte b = 0; b < i; b++) {
/* 13707 */       if (arrayOfString[b] == str) {
/*       */         
/* 13709 */         setSTRUCT(b + 1, paramSTRUCT);
/*       */         
/* 13711 */         bool = true;
/*       */       } 
/*       */     } 
/* 13714 */     if (!bool) {
/*       */       
/* 13716 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13717 */       sQLException.fillInStackTrace();
/* 13718 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 13738 */     String str = paramString.intern();
/* 13739 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13740 */     boolean bool = false;
/* 13741 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13743 */     for (byte b = 0; b < i; b++) {
/* 13744 */       if (arrayOfString[b] == str) {
/*       */         
/* 13746 */         setTIMESTAMPLTZ(b + 1, paramTIMESTAMPLTZ);
/*       */         
/* 13748 */         bool = true;
/*       */       } 
/*       */     } 
/* 13751 */     if (!bool) {
/*       */       
/* 13753 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13754 */       sQLException.fillInStackTrace();
/* 13755 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 13775 */     String str = paramString.intern();
/* 13776 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13777 */     boolean bool = false;
/* 13778 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13780 */     for (byte b = 0; b < i; b++) {
/* 13781 */       if (arrayOfString[b] == str) {
/*       */         
/* 13783 */         setTIMESTAMPTZ(b + 1, paramTIMESTAMPTZ);
/*       */         
/* 13785 */         bool = true;
/*       */       } 
/*       */     } 
/* 13788 */     if (!bool) {
/*       */       
/* 13790 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13791 */       sQLException.fillInStackTrace();
/* 13792 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 13812 */     String str = paramString.intern();
/* 13813 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13814 */     boolean bool = false;
/* 13815 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13817 */     for (byte b = 0; b < i; b++) {
/* 13818 */       if (arrayOfString[b] == str) {
/*       */         
/* 13820 */         setTIMESTAMP(b + 1, paramTIMESTAMP);
/*       */         
/* 13822 */         bool = true;
/*       */       } 
/*       */     } 
/* 13825 */     if (!bool) {
/*       */       
/* 13827 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13828 */       sQLException.fillInStackTrace();
/* 13829 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 13851 */     String str = paramString.intern();
/* 13852 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13853 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13854 */     boolean bool = true;
/*       */     
/* 13856 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13858 */       if (arrayOfString[b] == str)
/*       */       {
/* 13860 */         if (bool) {
/*       */           
/* 13862 */           setBlob(b + 1, paramInputStream);
/*       */           
/* 13864 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13869 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13870 */           sQLException.fillInStackTrace();
/* 13871 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13876 */     if (bool) {
/*       */       
/* 13878 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13879 */       sQLException.fillInStackTrace();
/* 13880 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 13900 */     String str = paramString.intern();
/* 13901 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13902 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13903 */     boolean bool = true;
/*       */     
/* 13905 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13907 */       if (arrayOfString[b] == str)
/*       */       {
/* 13909 */         if (bool) {
/*       */           
/* 13911 */           setBlob(b + 1, paramInputStream, paramLong);
/*       */           
/* 13913 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13918 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13919 */           sQLException.fillInStackTrace();
/* 13920 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13925 */     if (bool) {
/*       */       
/* 13927 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13928 */       sQLException.fillInStackTrace();
/* 13929 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 13949 */     String str = paramString.intern();
/* 13950 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13951 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13952 */     boolean bool = true;
/*       */     
/* 13954 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13956 */       if (arrayOfString[b] == str)
/*       */       {
/* 13958 */         if (bool) {
/*       */           
/* 13960 */           setClob(b + 1, paramReader);
/*       */           
/* 13962 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13967 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13968 */           sQLException.fillInStackTrace();
/* 13969 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13974 */     if (bool) {
/*       */       
/* 13976 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13977 */       sQLException.fillInStackTrace();
/* 13978 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 13998 */     String str = paramString.intern();
/* 13999 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14000 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14001 */     boolean bool = true;
/*       */     
/* 14003 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14005 */       if (arrayOfString[b] == str)
/*       */       {
/* 14007 */         if (bool) {
/*       */           
/* 14009 */           setClob(b + 1, paramReader, paramLong);
/*       */           
/* 14011 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14016 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14017 */           sQLException.fillInStackTrace();
/* 14018 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14023 */     if (bool) {
/*       */       
/* 14025 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14026 */       sQLException.fillInStackTrace();
/* 14027 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 14047 */     String str = paramString.intern();
/* 14048 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14049 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14050 */     boolean bool = true;
/*       */     
/* 14052 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14054 */       if (arrayOfString[b] == str)
/*       */       {
/* 14056 */         if (bool) {
/*       */           
/* 14058 */           setNClob(b + 1, paramReader);
/*       */           
/* 14060 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14065 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14066 */           sQLException.fillInStackTrace();
/* 14067 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14072 */     if (bool) {
/*       */       
/* 14074 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14075 */       sQLException.fillInStackTrace();
/* 14076 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 14096 */     String str = paramString.intern();
/* 14097 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14098 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14099 */     boolean bool = true;
/*       */     
/* 14101 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14103 */       if (arrayOfString[b] == str)
/*       */       {
/* 14105 */         if (bool) {
/*       */           
/* 14107 */           setNClob(b + 1, paramReader, paramLong);
/*       */           
/* 14109 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14114 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14115 */           sQLException.fillInStackTrace();
/* 14116 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14121 */     if (bool) {
/*       */       
/* 14123 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14124 */       sQLException.fillInStackTrace();
/* 14125 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 14145 */     String str = paramString.intern();
/* 14146 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14147 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14148 */     boolean bool = true;
/*       */     
/* 14150 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14152 */       if (arrayOfString[b] == str)
/*       */       {
/* 14154 */         if (bool) {
/*       */           
/* 14156 */           setAsciiStream(b + 1, paramInputStream);
/*       */           
/* 14158 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14163 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14164 */           sQLException.fillInStackTrace();
/* 14165 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14170 */     if (bool) {
/*       */       
/* 14172 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14173 */       sQLException.fillInStackTrace();
/* 14174 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 14194 */     String str = paramString.intern();
/* 14195 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14196 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14197 */     boolean bool = true;
/*       */     
/* 14199 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14201 */       if (arrayOfString[b] == str)
/*       */       {
/* 14203 */         if (bool) {
/*       */           
/* 14205 */           setAsciiStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 14207 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14212 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14213 */           sQLException.fillInStackTrace();
/* 14214 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14219 */     if (bool) {
/*       */       
/* 14221 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14222 */       sQLException.fillInStackTrace();
/* 14223 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 14243 */     String str = paramString.intern();
/* 14244 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14245 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14246 */     boolean bool = true;
/*       */     
/* 14248 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14250 */       if (arrayOfString[b] == str)
/*       */       {
/* 14252 */         if (bool) {
/*       */           
/* 14254 */           setAsciiStream(b + 1, paramInputStream, paramLong);
/*       */           
/* 14256 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14261 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14262 */           sQLException.fillInStackTrace();
/* 14263 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14268 */     if (bool) {
/*       */       
/* 14270 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14271 */       sQLException.fillInStackTrace();
/* 14272 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 14292 */     String str = paramString.intern();
/* 14293 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14294 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14295 */     boolean bool = true;
/*       */     
/* 14297 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14299 */       if (arrayOfString[b] == str)
/*       */       {
/* 14301 */         if (bool) {
/*       */           
/* 14303 */           setBinaryStream(b + 1, paramInputStream);
/*       */           
/* 14305 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14310 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14311 */           sQLException.fillInStackTrace();
/* 14312 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14317 */     if (bool) {
/*       */       
/* 14319 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14320 */       sQLException.fillInStackTrace();
/* 14321 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 14341 */     String str = paramString.intern();
/* 14342 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14343 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14344 */     boolean bool = true;
/*       */     
/* 14346 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14348 */       if (arrayOfString[b] == str)
/*       */       {
/* 14350 */         if (bool) {
/*       */           
/* 14352 */           setBinaryStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 14354 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14359 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14360 */           sQLException.fillInStackTrace();
/* 14361 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14366 */     if (bool) {
/*       */       
/* 14368 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14369 */       sQLException.fillInStackTrace();
/* 14370 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 14390 */     String str = paramString.intern();
/* 14391 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14392 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14393 */     boolean bool = true;
/*       */     
/* 14395 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14397 */       if (arrayOfString[b] == str)
/*       */       {
/* 14399 */         if (bool) {
/*       */           
/* 14401 */           setBinaryStream(b + 1, paramInputStream, paramLong);
/*       */           
/* 14403 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14408 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14409 */           sQLException.fillInStackTrace();
/* 14410 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14415 */     if (bool) {
/*       */       
/* 14417 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14418 */       sQLException.fillInStackTrace();
/* 14419 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 14439 */     String str = paramString.intern();
/* 14440 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14441 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14442 */     boolean bool = true;
/*       */     
/* 14444 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14446 */       if (arrayOfString[b] == str)
/*       */       {
/* 14448 */         if (bool) {
/*       */           
/* 14450 */           setCharacterStream(b + 1, paramReader);
/*       */           
/* 14452 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14457 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14458 */           sQLException.fillInStackTrace();
/* 14459 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14464 */     if (bool) {
/*       */       
/* 14466 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14467 */       sQLException.fillInStackTrace();
/* 14468 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 14488 */     String str = paramString.intern();
/* 14489 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14490 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14491 */     boolean bool = true;
/*       */     
/* 14493 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14495 */       if (arrayOfString[b] == str)
/*       */       {
/* 14497 */         if (bool) {
/*       */           
/* 14499 */           setCharacterStream(b + 1, paramReader, paramInt);
/*       */           
/* 14501 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14506 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14507 */           sQLException.fillInStackTrace();
/* 14508 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14513 */     if (bool) {
/*       */       
/* 14515 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14516 */       sQLException.fillInStackTrace();
/* 14517 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 14537 */     String str = paramString.intern();
/* 14538 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14539 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14540 */     boolean bool = true;
/*       */     
/* 14542 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14544 */       if (arrayOfString[b] == str)
/*       */       {
/* 14546 */         if (bool) {
/*       */           
/* 14548 */           setCharacterStream(b + 1, paramReader, paramLong);
/*       */           
/* 14550 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14555 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14556 */           sQLException.fillInStackTrace();
/* 14557 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14562 */     if (bool) {
/*       */       
/* 14564 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14565 */       sQLException.fillInStackTrace();
/* 14566 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 14586 */     String str = paramString.intern();
/* 14587 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14588 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14589 */     boolean bool = true;
/*       */     
/* 14591 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14593 */       if (arrayOfString[b] == str)
/*       */       {
/* 14595 */         if (bool) {
/*       */           
/* 14597 */           setNCharacterStream(b + 1, paramReader);
/*       */           
/* 14599 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14604 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14605 */           sQLException.fillInStackTrace();
/* 14606 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14611 */     if (bool) {
/*       */       
/* 14613 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14614 */       sQLException.fillInStackTrace();
/* 14615 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 14635 */     String str = paramString.intern();
/* 14636 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14637 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14638 */     boolean bool = true;
/*       */     
/* 14640 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14642 */       if (arrayOfString[b] == str)
/*       */       {
/* 14644 */         if (bool) {
/*       */           
/* 14646 */           setNCharacterStream(b + 1, paramReader, paramLong);
/*       */           
/* 14648 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14653 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14654 */           sQLException.fillInStackTrace();
/* 14655 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14660 */     if (bool) {
/*       */       
/* 14662 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14663 */       sQLException.fillInStackTrace();
/* 14664 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 14684 */     String str = paramString.intern();
/* 14685 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14686 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14687 */     boolean bool = true;
/*       */     
/* 14689 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14691 */       if (arrayOfString[b] == str)
/*       */       {
/* 14693 */         if (bool) {
/*       */           
/* 14695 */           setUnicodeStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 14697 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14702 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14703 */           sQLException.fillInStackTrace();
/* 14704 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14709 */     if (bool) {
/*       */       
/* 14711 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14712 */       sQLException.fillInStackTrace();
/* 14713 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 14722 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final boolean TRACE = false;
/*       */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\OraclePreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */