/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.net.SocketException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.zip.CRC32;
/*      */ import oracle.jdbc.NotificationRegistration;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQEnqueueOptions;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NSProtocol;
/*      */ import oracle.net.ns.NetException;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*      */   static final short MIN_TTCVER_SUPPORTED = 4;
/*      */   static final short V8_TTCVER_SUPPORTED = 5;
/*      */   static final short MAX_TTCVER_SUPPORTED = 6;
/*      */   static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
/*      */   static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
/*      */   static final int STREAM_CHUNK_SIZE = 255;
/*      */   static final int REFCURSOR_SIZE = 5;
/*   94 */   long LOGON_MODE = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useZeroCopyIO;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLobPrefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String password;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Communication net;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int eocs;
/*      */ 
/*      */ 
/*      */   
/*  128 */   private NTFEventListener[] xsListeners = new NTFEventListener[0];
/*      */   
/*      */   boolean readAsNonStream;
/*      */   
/*      */   T4CTTIoer oer;
/*      */   
/*      */   T4CMAREngine mare;
/*      */   
/*      */   T4C8TTIpro pro;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4CTTIsto sto;
/*      */   
/*      */   T4CTTIspfp spfp;
/*      */   
/*      */   T4CTTIoauthenticate auth;
/*      */   
/*      */   T4C8Odscrarr describe;
/*      */   
/*      */   T4C8Oall all8;
/*      */   
/*      */   T4C8Oclose close8;
/*      */   T4C7Ocommoncall commoncall;
/*      */   T4Caqe aqe;
/*      */   T4Caqdq aqdq;
/*      */   T4C8TTIBfile bfileMsg;
/*      */   T4C8TTIBlob blobMsg;
/*      */   T4C8TTIClob clobMsg;
/*      */   T4CTTIoses oses;
/*      */   T4CTTIoping oping;
/*      */   T4CTTIokpn okpn;
/*  160 */   byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */   T4CTTIOtxen otxen;
/*      */   
/*      */   T4CTTIOtxse otxse;
/*      */   
/*      */   T4CTTIk2rpc k2rpc;
/*      */   
/*      */   T4CTTIoscid oscid;
/*      */   
/*      */   T4CTTIokeyval okeyval;
/*      */   
/*      */   T4CTTIoxsscs oxsscs;
/*      */   
/*      */   T4CTTIoxssro oxssro;
/*      */   
/*      */   T4CTTIoxsspo oxsspo;
/*      */   
/*      */   T4CTTIxsnsop xsnsop;
/*      */   
/*      */   int[] cursorToClose;
/*      */   
/*      */   int cursorToCloseOffset;
/*      */   
/*      */   int lastCursorToCloseOffset;
/*      */   
/*      */   int[] queryToClose;
/*      */   
/*      */   int queryToCloseOffset;
/*      */   
/*      */   int[] lusFunctionId2;
/*      */   
/*      */   byte[][] lusSessionId2;
/*      */   
/*      */   KeywordValueLong[][] lusInKeyVal2;
/*      */   
/*      */   int[] lusInFlags2;
/*      */   
/*      */   int lusOffset2;
/*      */   
/*      */   int sessionId;
/*      */   
/*      */   int serialNumber;
/*      */   
/*      */   byte negotiatedTTCversion;
/*      */   
/*      */   byte[] serverRuntimeCapabilities;
/*      */   
/*      */   byte[] serverCompileTimeCapabilities;
/*      */   
/*      */   Hashtable namespaces;
/*      */   
/*      */   byte[] internalName;
/*      */   
/*      */   byte[] externalName;
/*      */   static final int FREE = -1;
/*      */   static final int SEND = 1;
/*      */   static final int RECEIVE = 2;
/*  218 */   int pipeState = -1;
/*      */   boolean sentCancel = false;
/*      */   String currentSchema;
/*      */   boolean cancelInProgressFlag = false;
/*      */   boolean statementCancel = true;
/*      */   private final CRC32 checksumEngine;
/*      */   private final Hashtable<Long, Integer> tempLobRefCount;
/*      */   static final int MAX_SIZE_VSESSION_OSUSER = 30;
/*      */   static final int MAX_SIZE_VSESSION_PROCESS = 24;
/*      */   static final int MAX_SIZE_VSESSION_MACHINE = 64;
/*      */   static final int MAX_SIZE_VSESSION_TERMINAL = 30; static final int MAX_SIZE_VSESSION_PROGRAM = 48; final void initializePassword(String paramString) throws SQLException { this.password = paramString; } void logon() throws SQLException { SQLException sQLException = null; try { if (this.isLoggedOn) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 428); sQLException1.fillInStackTrace(); throw sQLException1; }  if (this.database == null)
/*      */         this.database = "localhost:1521:orcl";  connect(this.database); this.all8 = new T4C8Oall(this); this.okpn = new T4CTTIokpn(this); this.close8 = new T4C8Oclose(this); this.sto = new T4CTTIsto(this); this.spfp = new T4CTTIspfp(this); this.commoncall = new T4C7Ocommoncall(this); this.describe = new T4C8Odscrarr(this); this.bfileMsg = new T4C8TTIBfile(this); this.blobMsg = new T4C8TTIBlob(this); this.clobMsg = new T4C8TTIClob(this); this.otxen = new T4CTTIOtxen(this); this.otxse = new T4CTTIOtxse(this); this.oping = new T4CTTIoping(this); this.k2rpc = new T4CTTIk2rpc(this); this.oses = new T4CTTIoses(this); this.okeyval = new T4CTTIokeyval(this); this.oxssro = new T4CTTIoxssro(this); this.oxsspo = new T4CTTIoxsspo(this); this.oxsscs = new T4CTTIoxsscs(this); this.xsnsop = new T4CTTIxsnsop(this); this.aqe = new T4Caqe(this); this.aqdq = new T4Caqdq(this); this.oscid = new T4CTTIoscid(this); this.LOGON_MODE = 0L; if (this.internalLogon != null)
/*      */         if (this.internalLogon.equalsIgnoreCase("sysoper")) { this.LOGON_MODE = 64L; } else if (this.internalLogon.equalsIgnoreCase("sysdba")) { this.LOGON_MODE = 32L; } else if (this.internalLogon.equalsIgnoreCase("sysasm")) { this.LOGON_MODE = 4194304L; } else if (this.internalLogon.equalsIgnoreCase("sysbackup")) { this.LOGON_MODE = 16777216L; } else if (this.internalLogon.equalsIgnoreCase("sysdg")) { this.LOGON_MODE = 33554432L; } else if (this.internalLogon.equalsIgnoreCase("syskm")) { this.LOGON_MODE = 67108864L; }   if (this.prelimAuth)
/*      */         this.LOGON_MODE |= 0x80L;  this.auth = new T4CTTIoauthenticate(this, this.resourceManagerId, this.serverCompileTimeCapabilities); if (this.userName != null && this.userName.length() != 0)
/*      */         try { this.auth.doOSESSKEY(this.userName, this.LOGON_MODE); } catch (SQLException sQLException1) { if (sQLException1.getErrorCode() == 1017) { sQLException = sQLException1; this.userName = null; } else { throw sQLException1; }  }   this.auth.doOAUTH(this.userName, this.password, this.LOGON_MODE); this.sessionId = getSessionId(); this.serialNumber = getSerialNumber(); this.internalName = this.auth.internalName; this.externalName = this.auth.externalName; this.instanceName = this.sessionProperties.getProperty("AUTH_INSTANCENAME"); if (!this.prelimAuth) { T4C7Oversion t4C7Oversion = new T4C7Oversion(this); t4C7Oversion.doOVERSION(); byte[] arrayOfByte = t4C7Oversion.getVersion(); try { this.databaseProductVersion = new String(arrayOfByte, "UTF8"); } catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException1.fillInStackTrace(); throw sQLException1; }  this.versionNumber = t4C7Oversion.getVersionNumber(); } else { this.versionNumber = 0; }  this.isLoggedOn = true; if (getVersionNumber() < 11000)
/*      */         this.enableTempLobRefCnt = false;  } catch (NetException netException) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException1.fillInStackTrace(); throw sQLException1; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException1.fillInStackTrace(); throw sQLException1; } catch (SQLException sQLException1) { if (sQLException != null)
/*      */         sQLException1.initCause(sQLException);  try { this.net.disconnect(); } catch (Exception exception) {} this.isLoggedOn = false; throw sQLException1; }  } void handleIOException(IOException paramIOException) throws SQLException { try { this.pipeState = -1; this.net.disconnect(); this.net = null; } catch (Exception exception) {} this.isLoggedOn = false; this.lifecycle = 4; } synchronized void logoff() throws SQLException { try { assertLoggedOn("T4CConnection.logoff"); if (this.lifecycle == 8)
/*      */         return;  sendPiggyBackedMessages(); this.commoncall.doOLOGOFF(); this.net.disconnect(); this.net = null; } catch (IOException iOException) { handleIOException(iOException); if (this.lifecycle != 8) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } finally { try { if (this.net != null)
/*      */           this.net.disconnect();  } catch (Exception exception) {} this.isLoggedOn = false; }  } T4CMAREngine getMarshalEngine() { return this.mare; } synchronized void doCommit(int paramInt) throws SQLException { assertLoggedOn("T4CConnection.do_commit"); try { sendPiggyBackedMessages(); if (paramInt == 0) { this.commoncall.doOCOMMIT(); } else { int i = 0; if ((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0) { i = i | 0x2 | 0x1; } else if ((paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) { i |= 0x2; }  if ((paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0) { i = i | 0x8 | 0x4; } else if ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0) { i |= 0x8; }  this.otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, i); int j = this.otxen.getOutStateFromServer(); if (j == 2 || j != 4); }  } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } synchronized void doRollback() throws SQLException { try { assertLoggedOn("T4CConnection.do_rollback"); sendPiggyBackedMessages(); this.commoncall.doOROLLBACK(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } synchronized void doSetAutoCommit(boolean paramBoolean) throws SQLException { this.autocommit = paramBoolean; } public synchronized void open(OracleStatement paramOracleStatement) throws SQLException { assertLoggedOn("T4CConnection.open"); paramOracleStatement.setCursorId(0); } synchronized String doGetDatabaseProductVersion() throws SQLException { assertLoggedOn("T4CConnection.do_getDatabaseProductVersion"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); }
/*      */     catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }
/*      */      String str = null; byte[] arrayOfByte = t4C7Oversion.getVersion(); try { str = new String(arrayOfByte, "UTF8"); }
/*      */     catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException.fillInStackTrace(); throw sQLException; }
/*  240 */      return str; } byte currentTTCSeqNumber = 0;
/*      */   synchronized short doGetVersionNumber() throws SQLException { assertLoggedOn("T4CConnection.do_getVersionNumber"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return t4C7Oversion.getVersionNumber(); }
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException { T4CStatement t4CStatement = new T4CStatement(this, -1, -1); try { int i = this.mare.unmarshalRefCursor(paramArrayOfbyte); t4CStatement.setCursorId(i); t4CStatement.isOpen = true; t4CStatement.sqlObject = paramOracleStatement.sqlObject; t4CStatement.serverCursor = true; paramOracleStatement.addChild(t4CStatement); t4CStatement.prepareForNewResults(true, false); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  t4CStatement.sqlStringChanged = false; t4CStatement.needToParse = false; return t4CStatement; }
/*      */   void cancelOperationOnServer(boolean paramBoolean) throws SQLException { synchronized (this.cancelInProgressLockForThin) { if (!this.cancelInProgressFlag) { try { switch (this.pipeState) { case -1: return;case 1: this.net.sendBreak(); break;case 2: this.net.sendInterrupt(); break; }  this.sentCancel = true; } catch (NetException netException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException.fillInStackTrace(); throw sQLException; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  this.cancelInProgressFlag = true; this.statementCancel = paramBoolean; }  }  }
/*      */   void connect(String paramString) throws IOException, SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433); sQLException.fillInStackTrace(); throw sQLException; }  Properties properties = new Properties(); if (this.thinNetProfile != null) properties.setProperty("oracle.net.profile", this.thinNetProfile);  if (this.thinNetAuthenticationServices != null) properties.setProperty("oracle.net.authentication_services", this.thinNetAuthenticationServices);  if (this.thinNetAuthenticationKrb5Mutual != null) properties.setProperty("oracle.net.kerberos5_mutual_authentication", this.thinNetAuthenticationKrb5Mutual);  if (this.thinNetAuthenticationKrb5CcName != null) properties.setProperty("oracle.net.kerberos5_cc_name", this.thinNetAuthenticationKrb5CcName);  if (this.thinNetEncryptionLevel != null) properties.setProperty("oracle.net.encryption_client", this.thinNetEncryptionLevel);  if (this.thinNetEncryptionTypes != null) properties.setProperty("oracle.net.encryption_types_client", this.thinNetEncryptionTypes);  if (this.thinNetChecksumLevel != null) properties.setProperty("oracle.net.crypto_checksum_client", this.thinNetChecksumLevel);  if (this.thinNetChecksumTypes != null) properties.setProperty("oracle.net.crypto_checksum_types_client", this.thinNetChecksumTypes);  if (this.thinNetCryptoSeed != null) properties.setProperty("oracle.net.crypto_seed", this.thinNetCryptoSeed);  if (this.thinTcpNoDelay) properties.setProperty("TCP.NODELAY", "YES");  if (this.thinReadTimeout != null) properties.setProperty("oracle.net.READ_TIMEOUT", this.thinReadTimeout);  if (this.thinNetConnectTimeout != null) properties.setProperty("oracle.net.CONNECT_TIMEOUT", this.thinNetConnectTimeout);  if (this.thinSslServerDnMatch != null) properties.setProperty("oracle.net.ssl_server_dn_match", this.thinSslServerDnMatch);  if (this.walletLocation != null) properties.setProperty("oracle.net.wallet_location", this.walletLocation);  if (this.walletPassword != null) properties.setProperty("oracle.net.wallet_password", this.walletPassword);  if (this.thinSslVersion != null) properties.setProperty("oracle.net.ssl_version", this.thinSslVersion);  if (this.thinSslCipherSuites != null) properties.setProperty("oracle.net.ssl_cipher_suites", this.thinSslCipherSuites);  if (this.thinJavaxNetSslKeystore != null) properties.setProperty("javax.net.ssl.keyStore", this.thinJavaxNetSslKeystore);  if (this.thinJavaxNetSslKeystoretype != null) properties.setProperty("javax.net.ssl.keyStoreType", this.thinJavaxNetSslKeystoretype);  if (this.thinJavaxNetSslKeystorepassword != null) properties.setProperty("javax.net.ssl.keyStorePassword", this.thinJavaxNetSslKeystorepassword);  if (this.thinJavaxNetSslTruststore != null) properties.setProperty("javax.net.ssl.trustStore", this.thinJavaxNetSslTruststore);  if (this.thinJavaxNetSslTruststoretype != null) properties.setProperty("javax.net.ssl.trustStoreType", this.thinJavaxNetSslTruststoretype);  if (this.thinJavaxNetSslTruststorepassword != null) properties.setProperty("javax.net.ssl.trustStorePassword", this.thinJavaxNetSslTruststorepassword);  if (this.thinSslKeymanagerfactoryAlgorithm != null) properties.setProperty("ssl.keyManagerFactory.algorithm", this.thinSslKeymanagerfactoryAlgorithm);  if (this.thinSslTrustmanagerfactoryAlgorithm != null) properties.setProperty("ssl.trustManagerFactory.algorithm", this.thinSslTrustmanagerfactoryAlgorithm);  if (this.thinNetOldsyntax != null)
/*      */       properties.setProperty("oracle.net.oldSyntax", this.thinNetOldsyntax);  if (this.thinNamingContextInitial != null)
/*      */       properties.setProperty("java.naming.factory.initial", this.thinNamingContextInitial);  if (this.thinNamingProviderUrl != null)
/*      */       properties.setProperty("java.naming.provider.url", this.thinNamingProviderUrl);  if (this.thinNamingSecurityAuthentication != null)
/*      */       properties.setProperty("java.naming.security.authentication", this.thinNamingSecurityAuthentication);  if (this.thinNamingSecurityPrincipal != null)
/*      */       properties.setProperty("java.naming.security.principal", this.thinNamingSecurityPrincipal);  if (this.thinNamingSecurityCredentials != null)
/*      */       properties.setProperty("java.naming.security.credentials", this.thinNamingSecurityCredentials);  if (this.thinNetDisableOutOfBandBreak)
/*      */       properties.setProperty("DISABLE_OOB", "" + this.thinNetDisableOutOfBandBreak);  if (this.thinNetEnableSDP)
/*      */       properties.setProperty("oracle.net.SDP", "" + this.thinNetEnableSDP);  properties.setProperty("USE_ZERO_COPY_IO", "" + this.thinNetUseZeroCopyIO); properties.setProperty("FORCE_DNS_LOAD_BALANCING", "" + this.thinForceDnsLoadBalancing); properties.setProperty("ENABLE_JAVANET_FASTPATH", "" + this.enableJavaNetFastPath); properties.setProperty("oracle.jdbc.v$session.osuser", this.thinVsessionOsuser); properties.setProperty("oracle.jdbc.v$session.program", this.thinVsessionProgram); properties.setProperty("T4CConnection.hashCode", Integer.toHexString(hashCode()).toUpperCase()); properties.setProperty("oracle.net.keepAlive", Boolean.toString(this.keepAlive)); this.net = (Communication)new NSProtocol(); this.net.connect(paramString, properties); this.mare = new T4CMAREngine(this.net, this.enableJavaNetFastPath); this.oer = new T4CTTIoer(this); this.mare.setConnectionDuringExceptionHandling(this); this.pro = new T4C8TTIpro(this); this.pro.marshal(); this.serverCompileTimeCapabilities = this.pro.receive(); this.serverRuntimeCapabilities = this.pro.getServerRuntimeCapabilities(); short s1 = this.pro.getOracleVersion(); short s2 = this.pro.getCharacterSet(); short s3 = DBConversion.findDriverCharSet(s2, s1); this.conversion = new DBConversion(s2, s3, this.pro.getncharCHARSET(), this.isStrictAsciiConversion, this.isQuickAsciiConversion); this.mare.types.setServerConversion(!(s3 == s2)); if (DBConversion.isCharSetMultibyte(s3)) { if (DBConversion.isCharSetMultibyte(this.pro.getCharacterSet())) { this.mare.types.setFlags((byte)1); } else { this.mare.types.setFlags((byte)2); }  } else { this.mare.types.setFlags(this.pro.getFlags()); }  this.mare.conv = this.conversion; T4C8TTIdty t4C8TTIdty = new T4C8TTIdty(this, this.serverCompileTimeCapabilities, this.serverRuntimeCapabilities, (this.logonCap != null && this.logonCap.trim().equals("o3")), this.thinNetUseZeroCopyIO); t4C8TTIdty.doRPC(); this.negotiatedTTCversion = this.serverCompileTimeCapabilities[7]; if (t4C8TTIdty.jdbcThinCompileTimeCapabilities[7] < this.serverCompileTimeCapabilities[7])
/*      */       this.negotiatedTTCversion = t4C8TTIdty.jdbcThinCompileTimeCapabilities[7];  if (this.serverRuntimeCapabilities != null && this.serverRuntimeCapabilities.length > 6 && (this.serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0 && this.thinNetUseZeroCopyIO && (this.net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0 && getDataIntegrityAlgorithmName().equals("") && getEncryptionAlgorithmName().equals("")) { this.useZeroCopyIO = true; } else { this.useZeroCopyIO = false; }  if (this.serverCompileTimeCapabilities.length > 23 && (this.serverCompileTimeCapabilities[23] & 0x40) != 0 && (t4C8TTIdty.jdbcThinCompileTimeCapabilities[23] & 0x40) != 0) { this.useLobPrefetch = true; } else { this.useLobPrefetch = false; }  }
/*  254 */   boolean isZeroCopyIOEnabled() { return this.useZeroCopyIO; } T4CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2679 */     this.checksumEngine = new CRC32();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2696 */     this.tempLobRefCount = new Hashtable<Long, Integer>(); this.cursorToClose = new int[4]; this.cursorToCloseOffset = 0; this.queryToClose = new int[10]; this.queryToCloseOffset = 0; this.lusFunctionId2 = new int[10]; this.lusSessionId2 = new byte[10][]; this.lusInKeyVal2 = new KeywordValueLong[10][]; this.lusInFlags2 = new int[10]; this.lusOffset2 = 0; this.minVcsBindSize = 0; this.streamChunkSize = 255; this.namespaces = new Hashtable<Object, Object>(5); this.currentSchema = null; } final T4CTTIoer getT4CTTIoer() { return this.oer; } final byte getTTCVersion() { return this.negotiatedTTCversion; } void doStartup(int paramInt) throws SQLException { try { byte b = 0; if (paramInt == OracleConnection.DatabaseStartupMode.FORCE.getMode()) { b = 16; } else if (paramInt == OracleConnection.DatabaseStartupMode.RESTRICT.getMode()) { b = 1; }  this.spfp.doOSPFPPUT(); this.sto.doOV6STRT(b); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void doShutdown(int paramInt) throws SQLException { try { char c = '\004'; if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL.getMode()) { c = ''; } else if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode()) { c = 'Ā'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.IMMEDIATE.getMode()) { c = '\002'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.FINAL.getMode()) { c = '\b'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.ABORT.getMode()) { c = '@'; }  sendPiggyBackedMessages(); this.sto.doOV6STOP(c); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void sendPiggyBackedMessages() throws SQLException, IOException { sendPiggyBackedClose(); if (this.endToEndAnyChanged && getTTCVersion() >= 3) { this.oscid.doOSCID(this.endToEndHasChanged, this.endToEndValues, this.endToEndECIDSequenceNumber); for (byte b = 0; b < 4; b++) { if (this.endToEndHasChanged[b]) this.endToEndHasChanged[b] = false;  }  }  this.endToEndAnyChanged = false; if (!this.namespaces.isEmpty()) { if (getTTCVersion() >= 4) { Object[] arrayOfObject = this.namespaces.values().toArray(); for (byte b = 0; b < arrayOfObject.length; b++) this.okeyval.doOKEYVAL((Namespace)arrayOfObject[b]);  }  this.namespaces.clear(); }  if (this.lusOffset2 > 0) { for (byte b = 0; b < this.lusOffset2; b++) this.oxsspo.doOXSSPO(this.lusFunctionId2[b], this.lusSessionId2[b], this.lusInKeyVal2[b], this.lusInFlags2[b]);  this.lusOffset2 = 0; }  } private void sendPiggyBackedClose() throws SQLException, IOException { if (this.queryToCloseOffset > 0) { this.close8.doOCANA(this.queryToClose, this.queryToCloseOffset); this.queryToCloseOffset = 0; }  if (this.cursorToCloseOffset > 0) { this.close8.doOCCA(this.cursorToClose, this.cursorToCloseOffset); this.lastCursorToCloseOffset = this.cursorToCloseOffset; this.cursorToCloseOffset = 0; }  } void redoCursorClose() { if (this.cursorToCloseOffset == 0 && this.lastCursorToCloseOffset != 0) { this.cursorToCloseOffset = this.lastCursorToCloseOffset; this.lastCursorToCloseOffset = 0; }  } synchronized void closeCursor(int paramInt) throws SQLException { if (this.cursorToCloseOffset == this.cursorToClose.length) { int[] arrayOfInt = new int[this.cursorToClose.length * 2]; System.arraycopy(this.cursorToClose, 0, arrayOfInt, 0, this.cursorToClose.length); this.cursorToClose = arrayOfInt; }  this.cursorToClose[this.cursorToCloseOffset++] = paramInt; } void doProxySession(int paramInt, Properties paramProperties) throws SQLException { try { sendPiggyBackedMessages(); this.auth.doOAUTH(paramInt, paramProperties, this.sessionId, this.serialNumber); int i = getSessionId(); int j = getSerialNumber(); this.oses.doO80SES(i, j, 1); this.savedUser = this.userName; if (paramInt == 1) { this.userName = paramProperties.getProperty("PROXY_USER_NAME"); } else { this.userName = null; }  this.isProxy = true; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void closeProxySession() throws SQLException { try { sendPiggyBackedMessages(); this.commoncall.doOLOGOFF(); this.oses.doO80SES(this.sessionId, this.serialNumber, 1); this.userName = this.savedUser; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   void updateSessionProperties(KeywordValue[] paramArrayOfKeywordValue) throws SQLException { for (byte b = 0; b < paramArrayOfKeywordValue.length; b++) { int i = paramArrayOfKeywordValue[b].getKeyword(); byte[] arrayOfByte = paramArrayOfKeywordValue[b].getBinaryValue(); if (i < T4C8Oall.NLS_KEYS.length) { String str = T4C8Oall.NLS_KEYS[i]; if (str != null) if (arrayOfByte != null) { this.sessionProperties.setProperty(str, this.mare.conv.CharBytesToString(arrayOfByte, arrayOfByte.length)); } else if (paramArrayOfKeywordValue[b].getTextValue() != null) { this.sessionProperties.setProperty(str, paramArrayOfKeywordValue[b].getTextValue().trim()); }   } else if (i == 163) { if (arrayOfByte != null) { int j = arrayOfByte[4]; int k = arrayOfByte[5]; if ((arrayOfByte[4] & 0xFF) > 120) { int m = (arrayOfByte[4] & 0xFF) - 181; int n = (arrayOfByte[5] & 0xFF) - 60; } else { j = (arrayOfByte[4] & 0xFF) - 60; k = (arrayOfByte[5] & 0xFF) - 60; }  String str = ((j > 0) ? "+" : "") + j + ((k <= 9) ? ":0" : ":") + k; this.sessionProperties.setProperty("SESSION_TIME_ZONE", str); }  } else if (i != 165) { if (i != 166) if (i != 167) if (i == 168) { String str = paramArrayOfKeywordValue[b].getTextValue(); if (str != null) this.currentSchema = str.trim();  } else if (i != 169) { if (i != 170) if (i == 171);  }    }  }  }
/*      */   public String getCurrentSchema() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  if (this.currentSchema == null || getVersionNumber() < 11100) this.currentSchema = super.getCurrentSchema();  return this.currentSchema; }
/*      */   public Properties getServerSessionInfo() throws SQLException { if (getVersionNumber() >= 10000 && getVersionNumber() < 10200) queryFCFProperties(this.sessionProperties);  return this.sessionProperties; }
/*      */   public String getSessionTimeZoneOffset() throws SQLException { String str = getServerSessionInfo().getProperty("SESSION_TIME_ZONE"); if (str == null) { str = super.getSessionTimeZoneOffset(); } else { str = tzToOffset(str); }  return str; }
/* 2701 */   private final synchronized Long getLocatorHash(byte[] paramArrayOfbyte) { this.checksumEngine.reset();
/*      */     
/* 2703 */     this.checksumEngine.update(paramArrayOfbyte, 10, 10);
/* 2704 */     long l = this.checksumEngine.getValue();
/* 2705 */     return Long.valueOf(l); } int getSessionId() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SESSION_ID"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; } int getSerialNumber() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SERIAL_NUM"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { byte b = 0; if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 6) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[5]; } else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 4) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[3]; }  return b; } public synchronized BlobDBAccess createBlobDBAccess() throws SQLException { return this; }
/*      */   public synchronized ClobDBAccess createClobDBAccess() throws SQLException { return this; }
/*      */   public synchronized BfileDBAccess createBfileDBAccess() throws SQLException { return this; }
/*      */   public synchronized long length(BFILE paramBFILE) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBFILE.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.bfileMsg.getLength(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; }
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException { assertNotNull(paramBFILE1.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBFILE.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); long l = 0L; if (paramInt != 0) try { l = this.bfileMsg.read(paramBFILE.shareBytes(), paramLong, paramInt, paramArrayOfbyte, 0); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; }
/*      */   public String getName(BFILE paramBFILE) throws SQLException { assertLoggedOn("getName"); assertNotNull(paramBFILE.shareBytes(), "getName"); return LobPlsqlUtil.fileGetName(paramBFILE); }
/*      */   public String getDirAlias(BFILE paramBFILE) throws SQLException { assertLoggedOn("getDirAlias"); assertNotNull(paramBFILE.shareBytes(), "getDirAlias"); return LobPlsqlUtil.fileGetDirAlias(paramBFILE); }
/*      */   public synchronized void openFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), 11); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; }
/*      */   public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException { assertLoggedOn("fileExists"); assertNotNull(paramBFILE.shareBytes(), "fileExists"); needLine(); boolean bool = false; try { bool = this.bfileMsg.doesExist(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; }
/* 2717 */   public final synchronized int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) { int i = 0;
/* 2718 */     if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length == 40 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2724 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 2725 */       Integer integer = this.tempLobRefCount.get(long_);
/* 2726 */       if (integer != null) {
/*      */         
/* 2728 */         i = integer.intValue() - 1;
/* 2729 */         if (i == 0) {
/* 2730 */           this.tempLobRefCount.remove(long_);
/*      */         } else {
/* 2732 */           this.tempLobRefCount.put(long_, Integer.valueOf(i));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2743 */     return i; } public synchronized void closeFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("closeFile"); assertNotNull(paramBFILE.shareBytes(), "closeFile"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException { assertLoggedOn("open"); assertNotNull(paramBFILE.shareBytes(), "open"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized void close(BFILE paramBFILE) throws SQLException { assertLoggedOn("close"); assertNotNull(paramBFILE.shareBytes(), "close"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("isOpen"); assertNotNull(paramBFILE.shareBytes(), "isOpen"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException { if (paramLong == 0L) return new OracleBlobInputStream(paramBFILE, paramInt);  return new OracleBlobInputStream(paramBFILE, paramInt, paramLong); } public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "newConversionInputStream"); return new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt); } public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "newConversionReader"); return new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt); } public synchronized long length(BLOB paramBLOB) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBLOB.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.blobMsg.getLength(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; } public long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; } public long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB1.shareBytes(), "position"); assertNotNull(paramBLOB2.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBLOB.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  long l1 = 0L; long l2 = -1L; if (paramBLOB.isActivePrefetch()) { byte[] arrayOfByte = paramBLOB.getPrefetchedData(); int i = paramBLOB.getPrefetchedDataSize(); l2 = paramBLOB.length(); int j = 0; if (arrayOfByte != null) j = Math.min(i, arrayOfByte.length);  if (j > 0 && paramLong <= j) { int k = Math.min(j - (int)paramLong + 1, paramInt); System.arraycopy(arrayOfByte, (int)paramLong - 1, paramArrayOfbyte, 0, k); l1 += k; }  }  if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) { needLine(); try { l1 += this.blobMsg.read(paramBLOB.shareBytes(), paramLong + l1, paramInt - l1, paramArrayOfbyte, (int)l1); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }  return (int)l1; }
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException { assertLoggedOn("putBytes"); assertNotNull(paramBLOB.shareBytes(), "putBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramArrayOfbyte == null || paramInt2 <= 0) return 0;  needLine(); long l = 0L; if (paramInt2 != 0) try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); l = this.blobMsg.write(paramBLOB.shareBytes(), paramLong, paramArrayOfbyte, paramInt1, paramInt2); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; }
/*      */   public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException { assertLoggedOn("getChunkSize"); assertNotNull(paramBLOB.shareBytes(), "getChunkSize"); needLine(); long l = 0L; try { l = this.blobMsg.getChunkSize(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return (int)l; }
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException { assertLoggedOn("trim"); assertNotNull(paramBLOB.shareBytes(), "trim"); if (paramLong < 0L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); this.blobMsg.trim(paramBLOB.shareBytes(), paramLong); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException { assertLoggedOn("createTemporaryBlob"); needLine(); BLOB bLOB = null; try { bLOB = (BLOB)this.blobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bLOB; }
/* 2749 */   public final synchronized void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) { if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length == 40 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2755 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 2756 */       Integer integer = this.tempLobRefCount.get(long_);
/*      */       
/* 2758 */       if (integer != null) {
/*      */         
/* 2760 */         int i = integer.intValue();
/*      */         
/* 2762 */         this.tempLobRefCount.put(long_, Integer.valueOf(i + 1));
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2767 */         this.tempLobRefCount.put(long_, Integer.valueOf(1));
/*      */       } 
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/* 2784 */     assertLoggedOn("freeTemporary");
/* 2785 */     assertNotNull(paramBLOB.shareBytes(), "freeTemporary");
/*      */     
/* 2787 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2791 */       this.blobMsg.freeTemporaryLob(paramBLOB.shareBytes());
/*      */     }
/* 2793 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2796 */       handleIOException(iOException);
/*      */       
/* 2798 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2799 */       sQLException.fillInStackTrace();
/* 2800 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 2819 */     assertNotNull(paramBLOB.shareBytes(), "isTemporary");
/*      */ 
/*      */ 
/*      */     
/* 2823 */     boolean bool = false;
/* 2824 */     byte[] arrayOfByte = paramBLOB.shareBytes();
/*      */     
/* 2826 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 2827 */       bool = true;
/*      */     }
/* 2829 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2842 */     assertLoggedOn("open");
/* 2843 */     assertNotNull(paramBLOB.shareBytes(), "open");
/*      */     
/* 2845 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2849 */       this.blobMsg.open(paramBLOB.shareBytes(), paramInt);
/*      */     }
/* 2851 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2854 */       handleIOException(iOException);
/*      */       
/* 2856 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2857 */       sQLException.fillInStackTrace();
/* 2858 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 2873 */     assertLoggedOn("close");
/* 2874 */     assertNotNull(paramBLOB.shareBytes(), "close");
/*      */     
/* 2876 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2880 */       this.blobMsg.close(paramBLOB.shareBytes());
/*      */     }
/* 2882 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2885 */       handleIOException(iOException);
/*      */       
/* 2887 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2888 */       sQLException.fillInStackTrace();
/* 2889 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 2905 */     assertLoggedOn("isOpen");
/* 2906 */     assertNotNull(paramBLOB.shareBytes(), "isOpen");
/*      */     
/* 2908 */     needLine();
/*      */     
/* 2910 */     boolean bool = false;
/*      */ 
/*      */     
/*      */     try {
/* 2914 */       bool = this.blobMsg.isOpen(paramBLOB.shareBytes());
/*      */     }
/* 2916 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2919 */       handleIOException(iOException);
/*      */       
/* 2921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2922 */       sQLException.fillInStackTrace();
/* 2923 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2928 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 2947 */     if (paramLong == 0L)
/*      */     {
/* 2949 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2953 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 2976 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2996 */     if (paramLong == 0L) {
/*      */       
/* 2998 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3001 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3002 */         sQLException.fillInStackTrace();
/* 3003 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3008 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3013 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3032 */     assertNotNull(paramBLOB.shareBytes(), "newConversionInputStream");
/*      */     
/* 3034 */     return new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3055 */     assertNotNull(paramBLOB.shareBytes(), "newConversionReader");
/*      */     
/* 3057 */     return new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 3085 */     assertLoggedOn("length");
/* 3086 */     assertNotNull(paramCLOB.shareBytes(), "length");
/*      */     
/* 3088 */     needLine();
/*      */     
/* 3090 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3094 */       l = this.clobMsg.getLength(paramCLOB.shareBytes());
/*      */     }
/* 3096 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3099 */       handleIOException(iOException);
/*      */       
/* 3101 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3102 */       sQLException.fillInStackTrace();
/* 3103 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3108 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 3125 */     if (paramString == null) {
/*      */       
/* 3127 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3128 */       sQLException.fillInStackTrace();
/* 3129 */       throw sQLException;
/*      */     } 
/*      */     
/* 3132 */     assertLoggedOn("position");
/* 3133 */     assertNotNull(paramCLOB.shareBytes(), "position");
/*      */ 
/*      */     
/* 3136 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3139 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3140 */       sQLException.fillInStackTrace();
/* 3141 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3146 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 3148 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 3150 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 3152 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3154 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 3170 */     if (paramCLOB2 == null) {
/*      */       
/* 3172 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3173 */       sQLException.fillInStackTrace();
/* 3174 */       throw sQLException;
/*      */     } 
/*      */     
/* 3177 */     assertLoggedOn("position");
/* 3178 */     assertNotNull(paramCLOB1.shareBytes(), "position");
/* 3179 */     assertNotNull(paramCLOB2.shareBytes(), "position");
/*      */     
/* 3181 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3185 */       sQLException.fillInStackTrace();
/* 3186 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3190 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 3192 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3194 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 3211 */     assertLoggedOn("getChars");
/* 3212 */     assertNotNull(paramCLOB.shareBytes(), "getChars");
/*      */     
/* 3214 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3217 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getChars()");
/* 3218 */       sQLException.fillInStackTrace();
/* 3219 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3225 */     if (this.pipeState != -1) {
/*      */ 
/*      */       
/* 3228 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getChars()");
/* 3229 */       sQLException.fillInStackTrace();
/* 3230 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3235 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 3236 */       return 0;
/*      */     }
/*      */     
/* 3239 */     long l1 = 0L;
/*      */ 
/*      */     
/* 3242 */     long l2 = -1L;
/*      */ 
/*      */     
/* 3245 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 3247 */       l2 = paramCLOB.length();
/* 3248 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 3249 */       int i = paramCLOB.getPrefetchedDataSize();
/*      */       
/* 3251 */       int j = 0;
/* 3252 */       if (arrayOfChar != null) {
/* 3253 */         j = Math.min(i, arrayOfChar.length);
/*      */       }
/* 3255 */       if (j > 0 && paramLong <= j) {
/*      */ 
/*      */ 
/*      */         
/* 3259 */         int k = Math.min(j - (int)paramLong + 1, paramInt);
/*      */ 
/*      */ 
/*      */         
/* 3263 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, k);
/* 3264 */         l1 += k;
/*      */       } 
/*      */     } 
/*      */     
/* 3268 */     if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) {
/*      */ 
/*      */       
/* 3271 */       needLine();
/*      */       
/*      */       try {
/* 3274 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3276 */         l1 += this.clobMsg.read(paramCLOB.shareBytes(), paramLong + l1, paramInt - l1, bool, paramArrayOfchar, (int)l1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 3283 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3286 */         handleIOException(iOException);
/*      */         
/* 3288 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3289 */         sQLException.fillInStackTrace();
/* 3290 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3297 */     return (int)l1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 3317 */     assertLoggedOn("putChars");
/* 3318 */     assertNotNull(paramCLOB.shareBytes(), "putChars");
/*      */     
/* 3320 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3323 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putChars()");
/* 3324 */       sQLException.fillInStackTrace();
/* 3325 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3329 */     if (paramArrayOfchar == null || paramInt2 <= 0) {
/* 3330 */       return 0;
/*      */     }
/* 3332 */     needLine();
/*      */     
/* 3334 */     long l = 0L;
/*      */     
/* 3336 */     if (paramInt2 != 0) {
/*      */       
/*      */       try {
/*      */         
/* 3340 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3342 */         paramCLOB.setActivePrefetch(false);
/* 3343 */         paramCLOB.clearCachedData();
/* 3344 */         l = this.clobMsg.write(paramCLOB.shareBytes(), paramLong, bool, paramArrayOfchar, paramInt1, paramInt2);
/*      */       
/*      */       }
/* 3347 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3350 */         handleIOException(iOException);
/*      */         
/* 3352 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3353 */         sQLException.fillInStackTrace();
/* 3354 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3360 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 3372 */     assertLoggedOn("getChunkSize");
/* 3373 */     assertNotNull(paramCLOB.shareBytes(), "getChunkSize");
/*      */     
/* 3375 */     needLine();
/*      */     
/* 3377 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3381 */       l = this.clobMsg.getChunkSize(paramCLOB.shareBytes());
/*      */     }
/* 3383 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3386 */       handleIOException(iOException);
/*      */       
/* 3388 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3389 */       sQLException.fillInStackTrace();
/* 3390 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3395 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 3409 */     assertLoggedOn("trim");
/* 3410 */     assertNotNull(paramCLOB.shareBytes(), "trim");
/*      */ 
/*      */     
/* 3413 */     if (paramLong < 0L) {
/*      */ 
/*      */       
/* 3416 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
/* 3417 */       sQLException.fillInStackTrace();
/* 3418 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3423 */     needLine();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3428 */       paramCLOB.setActivePrefetch(false);
/* 3429 */       paramCLOB.clearCachedData();
/* 3430 */       this.clobMsg.trim(paramCLOB.shareBytes(), paramLong);
/*      */     }
/* 3432 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3435 */       handleIOException(iOException);
/*      */       
/* 3437 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3438 */       sQLException.fillInStackTrace();
/* 3439 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 3462 */     assertLoggedOn("createTemporaryClob");
/*      */ 
/*      */     
/* 3465 */     if (paramShort != 2 && paramShort != 1) {
/*      */ 
/*      */ 
/*      */       
/* 3469 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 3470 */       sQLException.fillInStackTrace();
/* 3471 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3475 */     needLine();
/*      */     
/* 3477 */     CLOB cLOB = null;
/*      */ 
/*      */     
/*      */     try {
/* 3481 */       cLOB = (CLOB)this.clobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt, paramShort);
/*      */     
/*      */     }
/* 3484 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3487 */       handleIOException(iOException);
/*      */       
/* 3489 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3490 */       sQLException.fillInStackTrace();
/* 3491 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3496 */     return cLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/* 3511 */     assertLoggedOn("freeTemporary");
/* 3512 */     assertNotNull(paramCLOB.shareBytes(), "freeTemporary");
/*      */     
/* 3514 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3518 */       this.clobMsg.freeTemporaryLob(paramCLOB.shareBytes());
/*      */     }
/* 3520 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3523 */       handleIOException(iOException);
/*      */       
/* 3525 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3526 */       sQLException.fillInStackTrace();
/* 3527 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 3548 */     boolean bool = false;
/* 3549 */     byte[] arrayOfByte = paramCLOB.shareBytes();
/*      */     
/* 3551 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 3552 */       bool = true;
/*      */     }
/* 3554 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 3567 */     assertLoggedOn("open");
/* 3568 */     assertNotNull(paramCLOB.shareBytes(), "open");
/*      */     
/* 3570 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3574 */       this.clobMsg.open(paramCLOB.shareBytes(), paramInt);
/*      */     }
/* 3576 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3579 */       handleIOException(iOException);
/*      */       
/* 3581 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3582 */       sQLException.fillInStackTrace();
/* 3583 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 3598 */     assertLoggedOn("close");
/* 3599 */     assertNotNull(paramCLOB.shareBytes(), "close");
/*      */     
/* 3601 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3605 */       this.clobMsg.close(paramCLOB.shareBytes());
/*      */     }
/* 3607 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3610 */       handleIOException(iOException);
/*      */       
/* 3612 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3613 */       sQLException.fillInStackTrace();
/* 3614 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 3630 */     assertLoggedOn("isOpen");
/* 3631 */     assertNotNull(paramCLOB.shareBytes(), "isOpen");
/*      */     
/* 3633 */     boolean bool = false;
/*      */     
/* 3635 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3639 */       bool = this.clobMsg.isOpen(paramCLOB.shareBytes());
/*      */     }
/* 3641 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3644 */       handleIOException(iOException);
/*      */       
/* 3646 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3647 */       sQLException.fillInStackTrace();
/* 3648 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3653 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3672 */     if (paramLong == 0L)
/*      */     {
/* 3674 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3678 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3699 */     if (paramLong == 0L) {
/*      */       
/* 3701 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3704 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3705 */         sQLException.fillInStackTrace();
/* 3706 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3711 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3716 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3736 */     if (paramLong == 0L)
/*      */     {
/* 3738 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3742 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3763 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3782 */     if (paramLong == 0L) {
/*      */       
/* 3784 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3787 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3788 */         sQLException.fillInStackTrace();
/* 3789 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3794 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3799 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertLoggedOn(String paramString) throws SQLException {
/* 3825 */     if (!this.isLoggedOn) {
/*      */ 
/*      */       
/* 3828 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 430);
/* 3829 */       sQLException.fillInStackTrace();
/* 3830 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn() {
/* 3844 */     return this.isLoggedOn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertNotNull(byte[] paramArrayOfbyte, String paramString) throws NullPointerException {
/* 3860 */     if (paramArrayOfbyte == null)
/*      */     {
/* 3862 */       throw new NullPointerException("bytes are null");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalClose() throws SQLException {
/* 3871 */     super.internalClose();
/*      */     
/* 3873 */     this.isLoggedOn = false;
/*      */     
/*      */     try {
/* 3876 */       if (this.net != null) {
/* 3877 */         this.net.disconnect();
/*      */       }
/* 3879 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*      */     try {
/* 3891 */       this.net.abort();
/*      */     }
/* 3893 */     catch (NetException netException) {
/*      */ 
/*      */ 
/*      */       
/* 3897 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 3898 */       sQLException.fillInStackTrace();
/* 3899 */       throw sQLException;
/*      */ 
/*      */     
/*      */     }
/* 3903 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3906 */       handleIOException(iOException);
/*      */       
/* 3908 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3909 */       sQLException.fillInStackTrace();
/* 3910 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 3921 */     T4CStatement t4CStatement = new T4CStatement(this, -1, -1);
/* 3922 */     t4CStatement.open();
/*      */     
/* 3924 */     String str1 = paramAutoKeyInfo.getTableName();
/* 3925 */     String str2 = "SELECT * FROM " + str1;
/*      */     
/* 3927 */     t4CStatement.sqlObject.initialize(str2);
/*      */     
/* 3929 */     Accessor[] arrayOfAccessor = null;
/*      */ 
/*      */     
/*      */     try {
/* 3933 */       this.describe.doODNY(t4CStatement, 0, arrayOfAccessor, t4CStatement.sqlObject.getSqlBytes(false, false));
/* 3934 */       arrayOfAccessor = this.describe.getAccessors();
/*      */     }
/* 3936 */     catch (IOException iOException) {
/*      */       
/* 3938 */       handleIOException(iOException);
/*      */       
/* 3940 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3941 */       sQLException.fillInStackTrace();
/* 3942 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3946 */     int i = this.describe.numuds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3957 */     paramAutoKeyInfo.allocateSpaceForDescribedData(i);
/*      */     
/* 3959 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 3961 */       Accessor accessor = arrayOfAccessor[b];
/* 3962 */       String str3 = accessor.columnName;
/* 3963 */       int j = accessor.describeType;
/* 3964 */       int k = accessor.describeMaxLength;
/* 3965 */       boolean bool = accessor.nullable;
/* 3966 */       short s = accessor.formOfUse;
/* 3967 */       int m = accessor.precision;
/* 3968 */       int n = accessor.scale;
/* 3969 */       String str4 = accessor.describeTypeName;
/*      */       
/* 3971 */       paramAutoKeyInfo.fillDescribedData(b, str3, j, k, bool, s, m, n, str4);
/*      */     } 
/*      */ 
/*      */     
/* 3975 */     t4CStatement.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 3986 */     Namespace namespace = (Namespace)this.namespaces.get(paramString1);
/* 3987 */     if (namespace == null) {
/*      */       
/* 3989 */       namespace = new Namespace(paramString1);
/* 3990 */       this.namespaces.put(paramString1, namespace);
/*      */     } 
/* 3992 */     namespace.setAttribute(paramString2, paramString3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 4001 */     Namespace namespace = new Namespace(paramString);
/* 4002 */     namespace.clear();
/* 4003 */     this.namespaces.put(paramString, namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 4011 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void getPasswordInternal(T4CXAResource paramT4CXAResource) throws SQLException {
/* 4019 */     paramT4CXAResource.setPasswordInternal(this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 4037 */       needLine();
/* 4038 */       sendPiggyBackedMessages();
/* 4039 */       this.aqe.doOAQEQ(paramString, paramAQEnqueueOptions, paramAQMessagePropertiesI, paramArrayOfbyte2, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4046 */       if (paramAQEnqueueOptions.getRetrieveMessageId()) {
/* 4047 */         paramArrayOfbyte[0] = this.aqe.getMessageId();
/*      */       }
/* 4049 */     } catch (IOException iOException) {
/*      */       
/* 4051 */       handleIOException(iOException);
/*      */       
/* 4053 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4054 */       sQLException.fillInStackTrace();
/* 4055 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException {
/* 4072 */     boolean bool = false;
/*      */     
/*      */     try {
/* 4075 */       needLine();
/* 4076 */       sendPiggyBackedMessages();
/* 4077 */       this.aqdq.doOAQDQ(paramString, paramAQDequeueOptions, paramArrayOfbyte, paramBoolean, paramAQMessagePropertiesI);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4083 */       paramArrayOfbyte1[0] = this.aqdq.getPayload();
/* 4084 */       paramArrayOfbyte2[0] = this.aqdq.getDequeuedMessageId();
/* 4085 */       bool = this.aqdq.hasAMessageBeenDequeued();
/*      */     }
/* 4087 */     catch (IOException iOException) {
/*      */       
/* 4089 */       handleIOException(iOException);
/*      */       
/* 4091 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4092 */       sQLException.fillInStackTrace();
/* 4093 */       throw sQLException;
/*      */     } 
/*      */     
/* 4096 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/* 4103 */     if (this.versionNumber >= 10102) {
/*      */ 
/*      */       
/*      */       try {
/* 4107 */         needLine();
/* 4108 */         sendPiggyBackedMessages();
/* 4109 */         this.oping.doOPING();
/*      */       }
/* 4111 */       catch (IOException iOException) {
/*      */         
/* 4113 */         return -1;
/*      */       }
/* 4115 */       catch (SQLException sQLException) {
/*      */         
/* 4117 */         return -1;
/*      */       } 
/* 4119 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/* 4123 */     return super.doPingDatabase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException {
/* 4136 */     int i = paramArrayOfString.length;
/* 4137 */     int[] arrayOfInt1 = new int[i];
/* 4138 */     byte[][] arrayOfByte = new byte[i][];
/* 4139 */     int[] arrayOfInt2 = new int[i];
/* 4140 */     int[] arrayOfInt3 = new int[i];
/* 4141 */     int[] arrayOfInt4 = new int[i];
/* 4142 */     int[] arrayOfInt5 = new int[i];
/* 4143 */     int[] arrayOfInt6 = new int[i];
/* 4144 */     int[] arrayOfInt7 = new int[i];
/* 4145 */     long[] arrayOfLong = new long[i];
/* 4146 */     byte[] arrayOfByte1 = new byte[i];
/* 4147 */     int[] arrayOfInt8 = new int[i];
/* 4148 */     byte[] arrayOfByte2 = new byte[i];
/* 4149 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[i];
/* 4150 */     int[] arrayOfInt9 = new int[i];
/*      */     
/* 4152 */     boolean bool = false;
/* 4153 */     if (paramInt == 0) {
/*      */ 
/*      */       
/* 4156 */       bool = true;
/* 4157 */       paramInt = 47632;
/*      */     } 
/*      */     
/* 4160 */     for (byte b1 = 0; b1 < i; b1++) {
/*      */       
/* 4162 */       arrayOfInt1[b1] = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4163 */       arrayOfByte[b1] = new byte[4];
/* 4164 */       arrayOfByte[b1][0] = (byte)((arrayOfInt1[b1] & 0xFF000000) >> 24);
/* 4165 */       arrayOfByte[b1][1] = (byte)((arrayOfInt1[b1] & 0xFF0000) >> 16);
/* 4166 */       arrayOfByte[b1][2] = (byte)((arrayOfInt1[b1] & 0xFF00) >> 8);
/* 4167 */       arrayOfByte[b1][3] = (byte)(arrayOfInt1[b1] & 0xFF);
/* 4168 */       arrayOfInt2[b1] = 1;
/* 4169 */       arrayOfInt3[b1] = 23;
/*      */ 
/*      */       
/* 4172 */       if (paramArrayOfProperties.length > b1 && paramArrayOfProperties[b1] != null) {
/*      */         
/* 4174 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4176 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x1; } 
/* 4177 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4179 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x10; } 
/* 4180 */         if (paramArrayOfProperties[b1].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4182 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x2; } 
/* 4183 */         arrayOfInt5[b1] = readNTFtimeout(paramArrayOfProperties[b1]);
/*      */       } 
/*      */     } 
/*      */     
/* 4187 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9, paramArrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4194 */     int[] arrayOfInt10 = new int[1];
/* 4195 */     arrayOfInt10[0] = paramInt;
/*      */ 
/*      */ 
/*      */     
/* 4199 */     boolean bool1 = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt10, bool);
/* 4200 */     paramInt = arrayOfInt10[0];
/*      */     
/* 4202 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt + "))?PR=0";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 4209 */         boolean bool2 = bool1 ? true : false;
/* 4210 */         sendPiggyBackedMessages();
/* 4211 */         this.okpn.doOKPN(1, bool2, this.userName, str, i, arrayOfInt2, paramArrayOfString, arrayOfByte, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfLong, arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 4233 */       catch (IOException iOException) {
/*      */         
/* 4235 */         handleIOException(iOException);
/*      */         
/* 4237 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4238 */         sQLException.fillInStackTrace();
/* 4239 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 4243 */     catch (SQLException sQLException) {
/*      */       
/* 4245 */       if (bool1) {
/* 4246 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt);
/*      */       }
/* 4248 */       throw sQLException;
/*      */     } 
/* 4250 */     NTFAQRegistration[] arrayOfNTFAQRegistration = new NTFAQRegistration[i];
/*      */     byte b2;
/* 4252 */     for (b2 = 0; b2 < i; b2++) {
/* 4253 */       arrayOfNTFAQRegistration[b2] = new NTFAQRegistration(arrayOfInt1[b2], true, this.instanceName, this.userName, paramString, paramInt, paramArrayOfProperties[b2], paramArrayOfString[b2], this.versionNumber);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4263 */     for (b2 = 0; b2 < arrayOfNTFAQRegistration.length; b2++)
/* 4264 */       PhysicalConnection.ntfManager.addRegistration(arrayOfNTFAQRegistration[b2]); 
/* 4265 */     return arrayOfNTFAQRegistration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setNtfGroupingOptions(byte[] paramArrayOfbyte1, int[] paramArrayOfint1, byte[] paramArrayOfbyte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfint2, Properties[] paramArrayOfProperties) throws SQLException {
/* 4284 */     for (byte b = 0; b < paramArrayOfProperties.length; b++) {
/*      */       
/* 4286 */       String str1 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
/* 4287 */       String str2 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_VALUE");
/* 4288 */       String str3 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_TYPE");
/* 4289 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/* 4290 */       if (paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME") != null)
/* 4291 */         tIMESTAMPTZ = (TIMESTAMPTZ)paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME"); 
/* 4292 */       String str4 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
/*      */ 
/*      */       
/* 4295 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") != 0 && str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0) {
/*      */ 
/*      */ 
/*      */         
/* 4299 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4300 */         sQLException.fillInStackTrace();
/* 4301 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4306 */       if (str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0 && getTTCVersion() < 5) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4311 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4312 */         sQLException.fillInStackTrace();
/* 4313 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4319 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") == 0) {
/*      */         
/* 4321 */         paramArrayOfbyte1[b] = 1;
/*      */         
/* 4323 */         paramArrayOfint1[b] = 600;
/* 4324 */         if (str2 != null) {
/* 4325 */           paramArrayOfint1[b] = Integer.parseInt(str2);
/*      */         }
/* 4327 */         paramArrayOfbyte2[b] = 1;
/* 4328 */         if (str3 != null)
/*      */         {
/* 4330 */           if (str3.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0) {
/* 4331 */             paramArrayOfbyte2[b] = 1;
/* 4332 */           } else if (str3.compareTo("NTF_GROUPING_TYPE_LAST") == 0) {
/* 4333 */             paramArrayOfbyte2[b] = 2;
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 4339 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4340 */             sQLException.fillInStackTrace();
/* 4341 */             throw sQLException;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 4346 */         paramArrayOfTIMESTAMPTZ[b] = tIMESTAMPTZ;
/* 4347 */         if (str4.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0) {
/* 4348 */           paramArrayOfint2[b] = 0;
/*      */         } else {
/* 4350 */           paramArrayOfint2[b] = Integer.parseInt(str4);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException {
/* 4362 */     String str1 = paramNTFAQRegistration.getClientHost();
/* 4363 */     int i = paramNTFAQRegistration.getClientTCPPort();
/* 4364 */     if (str1 == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4375 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFAQRegistration);
/* 4376 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFAQRegistration.getJdbcRegId());
/* 4377 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFAQRegistration.getClientTCPPort());
/* 4378 */     paramNTFAQRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4380 */     String str2 = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + i + "))?PR=0";
/*      */ 
/*      */     
/* 4383 */     int[] arrayOfInt1 = { 1 };
/* 4384 */     String[] arrayOfString = new String[1];
/* 4385 */     arrayOfString[0] = paramNTFAQRegistration.getQueueName();
/* 4386 */     int[] arrayOfInt2 = { 0 };
/* 4387 */     int[] arrayOfInt3 = { 0 };
/* 4388 */     int[] arrayOfInt4 = { 0 };
/* 4389 */     int[] arrayOfInt5 = { 0 };
/* 4390 */     int[] arrayOfInt6 = { 0 };
/* 4391 */     long[] arrayOfLong = { 0L };
/* 4392 */     byte[] arrayOfByte1 = { 0 };
/* 4393 */     int[] arrayOfInt7 = { 0 };
/* 4394 */     byte[] arrayOfByte2 = { 0 };
/* 4395 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4396 */     int[] arrayOfInt8 = { 0 };
/* 4397 */     byte[][] arrayOfByte = new byte[1][];
/* 4398 */     int j = paramNTFAQRegistration.getJdbcRegId();
/* 4399 */     arrayOfByte[0] = new byte[4];
/* 4400 */     arrayOfByte[0][0] = (byte)((j & 0xFF000000) >> 24);
/* 4401 */     arrayOfByte[0][1] = (byte)((j & 0xFF0000) >> 16);
/* 4402 */     arrayOfByte[0][2] = (byte)((j & 0xFF00) >> 8);
/* 4403 */     arrayOfByte[0][3] = (byte)(j & 0xFF);
/*      */     
/*      */     try {
/* 4406 */       sendPiggyBackedMessages();
/* 4407 */       this.okpn.doOKPN(2, 0, this.userName, str2, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4429 */     catch (IOException iOException) {
/*      */       
/* 4431 */       handleIOException(iOException);
/*      */       
/* 4433 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4434 */       sQLException.fillInStackTrace();
/* 4435 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException {
/* 4451 */     int i = 0;
/* 4452 */     int j = 0;
/* 4453 */     boolean bool1 = false;
/* 4454 */     boolean bool2 = false;
/* 4455 */     boolean bool3 = false;
/* 4456 */     Object object = null;
/* 4457 */     boolean bool4 = false;
/* 4458 */     boolean bool5 = false;
/* 4459 */     if (paramInt1 == 0) {
/*      */ 
/*      */       
/* 4462 */       bool5 = true;
/* 4463 */       paramInt1 = 47632;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4468 */     if (paramProperties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4470 */       j |= 0x1; } 
/* 4471 */     if (paramProperties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4473 */       j |= 0x10;
/*      */     }
/*      */ 
/*      */     
/* 4477 */     if (paramProperties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4479 */       i |= 0x10;
/*      */     }
/*      */     
/* 4482 */     if (paramProperties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4484 */       i |= 0x20;
/*      */     }
/*      */     
/* 4487 */     if (paramProperties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4489 */       i |= 0x40;
/*      */     }
/* 4491 */     boolean bool6 = false;
/* 4492 */     boolean bool7 = false;
/* 4493 */     boolean bool8 = false;
/* 4494 */     if (paramProperties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4496 */       bool6 = true; } 
/* 4497 */     if (paramProperties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4499 */       bool7 = true; } 
/* 4500 */     if (paramProperties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4502 */       bool8 = true;
/*      */     }
/* 4504 */     if (bool6 || bool7 || bool8) {
/*      */       
/* 4506 */       i |= 0xF;
/*      */ 
/*      */ 
/*      */       
/* 4510 */       if (bool6)
/* 4511 */         i -= 2; 
/* 4512 */       if (bool7)
/* 4513 */         i -= 4; 
/* 4514 */       if (bool8) {
/* 4515 */         i -= 8;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4521 */     byte[] arrayOfByte1 = new byte[1];
/* 4522 */     int[] arrayOfInt1 = new int[1];
/* 4523 */     byte[] arrayOfByte2 = new byte[1];
/* 4524 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[1];
/* 4525 */     int[] arrayOfInt2 = new int[1];
/* 4526 */     Properties[] arrayOfProperties = { paramProperties };
/* 4527 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2, arrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4543 */     int[] arrayOfInt3 = new int[1];
/* 4544 */     arrayOfInt3[0] = paramInt1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4549 */     boolean bool = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt3, bool5);
/* 4550 */     paramInt1 = arrayOfInt3[0];
/*      */     
/* 4552 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt1 + "))?PR=0";
/*      */ 
/*      */ 
/*      */     
/* 4556 */     int[] arrayOfInt4 = { 2 };
/* 4557 */     String[] arrayOfString = new String[1];
/* 4558 */     int[] arrayOfInt5 = { 23 };
/*      */ 
/*      */     
/* 4561 */     int[] arrayOfInt6 = { j };
/* 4562 */     int[] arrayOfInt7 = { paramInt2 };
/* 4563 */     int[] arrayOfInt8 = { i };
/* 4564 */     int[] arrayOfInt9 = { paramInt3 };
/* 4565 */     long[] arrayOfLong = { 0L };
/* 4566 */     int k = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4567 */     byte[][] arrayOfByte = new byte[1][];
/* 4568 */     arrayOfByte[0] = new byte[4];
/* 4569 */     arrayOfByte[0][0] = (byte)((k & 0xFF000000) >> 24);
/* 4570 */     arrayOfByte[0][1] = (byte)((k & 0xFF0000) >> 16);
/* 4571 */     arrayOfByte[0][2] = (byte)((k & 0xFF00) >> 8);
/* 4572 */     arrayOfByte[0][3] = (byte)(k & 0xFF);
/* 4573 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 4578 */         boolean bool9 = bool ? true : false;
/* 4579 */         sendPiggyBackedMessages();
/* 4580 */         this.okpn.doOKPN(1, bool9, this.userName, str, 1, arrayOfInt4, arrayOfString, arrayOfByte, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfInt8, arrayOfInt9, arrayOfLong, arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4601 */         l = this.okpn.getRegistrationId();
/*      */       }
/* 4603 */       catch (IOException iOException) {
/*      */         
/* 4605 */         handleIOException(iOException);
/*      */         
/* 4607 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4608 */         sQLException.fillInStackTrace();
/* 4609 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 4613 */     catch (SQLException sQLException) {
/*      */       
/* 4615 */       if (bool) {
/* 4616 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt1);
/*      */       }
/* 4618 */       throw sQLException;
/*      */     } 
/* 4620 */     return new NTFDCNRegistration(k, true, this.instanceName, l, this.userName, paramString, paramInt1, paramProperties, this.versionNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException {
/* 4644 */     int[] arrayOfInt1 = { 2 };
/* 4645 */     String[] arrayOfString = new String[1];
/* 4646 */     int[] arrayOfInt2 = { 0 };
/* 4647 */     int[] arrayOfInt3 = { 0 };
/* 4648 */     int[] arrayOfInt4 = { 0 };
/* 4649 */     int[] arrayOfInt5 = { 0 };
/* 4650 */     int[] arrayOfInt6 = { 0 };
/* 4651 */     byte[] arrayOfByte1 = { 0 };
/* 4652 */     int[] arrayOfInt7 = { 0 };
/* 4653 */     byte[] arrayOfByte2 = { 0 };
/* 4654 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4655 */     int[] arrayOfInt8 = { 0 };
/* 4656 */     long[] arrayOfLong = { paramLong };
/* 4657 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/*      */     try {
/* 4660 */       sendPiggyBackedMessages();
/* 4661 */       this.okpn.doOKPN(2, 0, null, paramString, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4683 */     catch (IOException iOException) {
/*      */       
/* 4685 */       handleIOException(iOException);
/*      */       
/* 4687 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4688 */       sQLException.fillInStackTrace();
/* 4689 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException {
/* 4702 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFDCNRegistration);
/* 4703 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFDCNRegistration.getJdbcRegId());
/* 4704 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFDCNRegistration.getClientTCPPort());
/* 4705 */     paramNTFDCNRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4707 */     doUnregisterDatabaseChangeNotification(paramNTFDCNRegistration.getRegId(), "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramNTFDCNRegistration.getClientHost() + ")(PORT=" + paramNTFDCNRegistration.getClientTCPPort() + "))?PR=0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataIntegrityAlgorithmName() throws SQLException {
/* 4717 */     return this.net.getDataIntegrityName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncryptionAlgorithmName() throws SQLException {
/* 4724 */     return this.net.getEncryptionName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthenticationAdaptorName() throws SQLException {
/* 4731 */     return this.net.getAuthenticationAdaptorName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void validateConnectionProperties() throws SQLException {
/* 4746 */     super.validateConnectionProperties();
/*      */     
/* 4748 */     String str = ".*[\\00\\(\\)].*";
/* 4749 */     if (this.thinVsessionOsuser != null && (this.thinVsessionOsuser.matches(str) || this.thinVsessionOsuser.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 4753 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.osuser' and value is '" + this.thinVsessionOsuser + "'");
/* 4754 */       sQLException.fillInStackTrace();
/* 4755 */       throw sQLException;
/*      */     } 
/*      */     
/* 4758 */     if (this.thinVsessionTerminal != null && (this.thinVsessionTerminal.matches(str) || this.thinVsessionTerminal.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 4762 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.terminal' and value is '" + this.thinVsessionTerminal + "'");
/* 4763 */       sQLException.fillInStackTrace();
/* 4764 */       throw sQLException;
/*      */     } 
/*      */     
/* 4767 */     if (this.thinVsessionMachine != null && (this.thinVsessionMachine.matches(str) || this.thinVsessionMachine.length() > 64)) {
/*      */ 
/*      */ 
/*      */       
/* 4771 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.machine' and value is '" + this.thinVsessionMachine + "'");
/* 4772 */       sQLException.fillInStackTrace();
/* 4773 */       throw sQLException;
/*      */     } 
/*      */     
/* 4776 */     if (this.thinVsessionProgram != null && (this.thinVsessionProgram.matches(str) || this.thinVsessionProgram.length() > 48)) {
/*      */ 
/*      */ 
/*      */       
/* 4780 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.program' and value is '" + this.thinVsessionProgram + "'");
/* 4781 */       sQLException.fillInStackTrace();
/* 4782 */       throw sQLException;
/*      */     } 
/*      */     
/* 4785 */     if (this.thinVsessionProcess != null && (this.thinVsessionProcess.matches(str) || this.thinVsessionProcess.length() > 24)) {
/*      */ 
/*      */ 
/*      */       
/* 4789 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.process' and value is '" + this.thinVsessionProcess + "'");
/* 4790 */       sQLException.fillInStackTrace();
/* 4791 */       throw sQLException;
/*      */     } 
/*      */     
/* 4794 */     if (this.thinVsessionIname != null && this.thinVsessionIname.matches(str)) {
/*      */       
/* 4796 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.iname' and value is '" + this.thinVsessionIname + "'");
/* 4797 */       sQLException.fillInStackTrace();
/* 4798 */       throw sQLException;
/*      */     } 
/*      */     
/* 4801 */     if (this.thinVsessionEname != null && this.thinVsessionEname.matches(str)) {
/*      */       
/* 4803 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.ename' and value is '" + this.thinVsessionEname + "'");
/* 4804 */       sQLException.fillInStackTrace();
/* 4805 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 4811 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean TRACE = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 4825 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 4827 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4828 */       sQLException.fillInStackTrace();
/* 4829 */       throw sQLException;
/*      */     } 
/*      */     
/* 4832 */     byte[] arrayOfByte = null;
/*      */     
/*      */     try {
/* 4835 */       sendPiggyBackedMessages();
/* 4836 */       this.oxsscs.doOXSSCS(paramString, paramArrayOfKeywordValueLong, paramInt);
/* 4837 */       arrayOfByte = this.oxsscs.getSessionId();
/* 4838 */       paramArrayOfKeywordValueLong1[0] = this.oxsscs.getOutKV();
/* 4839 */       paramArrayOfint[0] = this.oxsscs.getOutFlags();
/*      */     }
/* 4841 */     catch (IOException iOException) {
/*      */       
/* 4843 */       handleIOException(iOException);
/*      */       
/* 4845 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4846 */       sQLException.fillInStackTrace();
/* 4847 */       throw sQLException;
/*      */     } 
/*      */     
/* 4850 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, boolean paramBoolean) throws SQLException {
/* 4866 */     XSNamespace[] arrayOfXSNamespace = null;
/*      */     
/*      */     try {
/* 4869 */       if (paramBoolean)
/* 4870 */         sendPiggyBackedMessages(); 
/* 4871 */       this.xsnsop.doOXSNS(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramBoolean);
/* 4872 */       if (paramBoolean) {
/* 4873 */         arrayOfXSNamespace = this.xsnsop.getNamespaces();
/*      */       }
/* 4875 */     } catch (IOException iOException) {
/*      */       
/* 4877 */       handleIOException(iOException);
/*      */       
/* 4879 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4880 */       sQLException.fillInStackTrace();
/* 4881 */       throw sQLException;
/*      */     } 
/*      */     
/* 4884 */     if (paramArrayOfXSNamespace1 != null && paramArrayOfXSNamespace1.length > 0) {
/* 4885 */       paramArrayOfXSNamespace1[0] = arrayOfXSNamespace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException {
/* 4899 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramArrayOfXSNamespace1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException {
/* 4911 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, (XSNamespace[][])null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 4923 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 4925 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4926 */       sQLException.fillInStackTrace();
/* 4927 */       throw sQLException;
/*      */     } 
/*      */     
/*      */     try {
/* 4931 */       sendPiggyBackedMessages();
/* 4932 */       this.oxssro.doOXSSRO(paramInt1, paramArrayOfbyte, paramArrayOfKeywordValueLong, paramInt2);
/* 4933 */       paramArrayOfKeywordValueLong1[0] = this.oxssro.getOutKV();
/* 4934 */       paramArrayOfint[0] = this.oxssro.getOutFlags();
/*      */     }
/* 4936 */     catch (IOException iOException) {
/*      */       
/* 4938 */       handleIOException(iOException);
/*      */       
/* 4940 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4941 */       sQLException.fillInStackTrace();
/* 4942 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException {
/* 4955 */     if (this.lusOffset2 == this.lusFunctionId2.length) {
/*      */       
/* 4957 */       int i = this.lusFunctionId2.length;
/* 4958 */       int[] arrayOfInt1 = new int[i * 2];
/* 4959 */       System.arraycopy(this.lusFunctionId2, 0, arrayOfInt1, 0, i);
/* 4960 */       byte[][] arrayOfByte = new byte[i * 2][];
/* 4961 */       System.arraycopy(this.lusSessionId2, 0, arrayOfByte, 0, i);
/* 4962 */       KeywordValueLong[][] arrayOfKeywordValueLong = new KeywordValueLong[i * 2][];
/* 4963 */       System.arraycopy(this.lusInKeyVal2, 0, arrayOfKeywordValueLong, 0, i);
/* 4964 */       int[] arrayOfInt2 = new int[i * 2];
/* 4965 */       System.arraycopy(this.lusInFlags2, 0, arrayOfInt2, 0, i);
/* 4966 */       this.lusFunctionId2 = arrayOfInt1;
/* 4967 */       this.lusSessionId2 = arrayOfByte;
/* 4968 */       this.lusInKeyVal2 = arrayOfKeywordValueLong;
/* 4969 */       this.lusInFlags2 = arrayOfInt2;
/*      */     } 
/* 4971 */     this.lusFunctionId2[this.lusOffset2] = paramInt1;
/* 4972 */     this.lusSessionId2[this.lusOffset2] = paramArrayOfbyte;
/* 4973 */     this.lusInKeyVal2[this.lusOffset2] = paramArrayOfKeywordValueLong;
/* 4974 */     this.lusInFlags2[this.lusOffset2] = paramInt2;
/* 4975 */     this.lusOffset2++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException {
/* 4986 */     if (this.lifecycle != 1) {
/*      */       
/* 4988 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4989 */       sQLException.fillInStackTrace();
/* 4990 */       throw sQLException;
/*      */     } 
/*      */     
/* 4993 */     NTFEventListener nTFEventListener = new NTFEventListener(paramXSEventListener);
/* 4994 */     nTFEventListener.setExecutor(paramExecutor);
/* 4995 */     synchronized (this.xsListeners) {
/*      */       
/* 4997 */       int i = this.xsListeners.length;
/* 4998 */       for (byte b = 0; b < i; b++) {
/* 4999 */         if (this.xsListeners[b].getXSEventListener() == paramXSEventListener) {
/*      */ 
/*      */ 
/*      */           
/* 5003 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 5004 */           sQLException.fillInStackTrace();
/* 5005 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */       
/* 5009 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 5010 */       System.arraycopy(this.xsListeners, 0, arrayOfNTFEventListener, 0, i);
/*      */       
/* 5012 */       arrayOfNTFEventListener[i] = nTFEventListener;
/*      */       
/* 5014 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 5025 */     addXSEventListener(paramXSEventListener, (Executor)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 5033 */     synchronized (this.xsListeners) {
/*      */ 
/*      */       
/* 5036 */       byte b1 = 0;
/* 5037 */       int i = this.xsListeners.length;
/*      */       
/* 5039 */       for (b1 = 0; b1 < i && 
/* 5040 */         this.xsListeners[b1].getXSEventListener() != paramXSEventListener; b1++);
/*      */       
/* 5042 */       if (b1 == i) {
/*      */ 
/*      */ 
/*      */         
/* 5046 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 5047 */         sQLException.fillInStackTrace();
/* 5048 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 5052 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
/* 5053 */       byte b2 = 0;
/* 5054 */       for (b1 = 0; b1 < i; b1++) {
/* 5055 */         if (this.xsListeners[b1].getXSEventListener() != paramXSEventListener) {
/* 5056 */           arrayOfNTFEventListener[b2++] = this.xsListeners[b1];
/*      */         }
/*      */       } 
/* 5059 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notify(final NTFXSEvent event) {
/* 5072 */     NTFEventListener[] arrayOfNTFEventListener = this.xsListeners;
/*      */ 
/*      */ 
/*      */     
/* 5076 */     int i = arrayOfNTFEventListener.length;
/* 5077 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 5079 */       Executor executor = arrayOfNTFEventListener[b].getExecutor();
/* 5080 */       if (executor != null) {
/*      */         
/* 5082 */         final XSEventListener l = arrayOfNTFEventListener[b].getXSEventListener();
/*      */         
/* 5084 */         executor.execute(new Runnable() {
/*      */               public void run() {
/* 5086 */                 l.onXSEvent(event);
/*      */               }
/*      */             });
/*      */       }
/*      */       else {
/*      */         
/* 5092 */         arrayOfNTFEventListener[b].getXSEventListener().onXSEvent(event);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean hasServerCompileTimeCapability(int paramInt1, int paramInt2) {
/* 5115 */     boolean bool = false;
/* 5116 */     if (this.serverCompileTimeCapabilities != null && this.serverCompileTimeCapabilities.length > paramInt1 && (this.serverCompileTimeCapabilities[paramInt1] & paramInt2) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 5121 */       bool = true;
/*      */     }
/* 5123 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long doGetCurrentSCN() throws SQLException {
/* 5131 */     return this.outScn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 5138 */     EnumSet<OracleConnection.TransactionState> enumSet = EnumSet.noneOf(OracleConnection.TransactionState.class);
/* 5139 */     if ((this.eocs & 0x1) != 0)
/*      */     {
/* 5141 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_READONLY);
/*      */     }
/* 5143 */     if ((this.eocs & 0x2) != 0)
/*      */     {
/* 5145 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_STARTED);
/*      */     }
/* 5147 */     if ((this.eocs & 0x4) != 0)
/*      */     {
/* 5149 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_ENDED);
/*      */     }
/* 5151 */     if ((this.eocs & 0x400) != 0)
/*      */     {
/* 5153 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_INTENTION);
/*      */     }
/* 5155 */     return enumSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConnectionSocketKeepAlive() throws SocketException {
/* 5162 */     return this.net.isConnectionSocketKeepAlive();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   byte getNextSeqNumber() {
/* 5168 */     if (this.currentTTCSeqNumber == Byte.MAX_VALUE) {
/*      */       
/* 5170 */       this.currentTTCSeqNumber = 1;
/* 5171 */       return this.currentTTCSeqNumber;
/*      */     } 
/*      */     
/* 5174 */     return this.currentTTCSeqNumber = (byte)(this.currentTTCSeqNumber + 1);
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T4CConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */