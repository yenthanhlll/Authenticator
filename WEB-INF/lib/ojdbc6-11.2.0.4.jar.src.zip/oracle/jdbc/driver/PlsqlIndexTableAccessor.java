/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PlsqlIndexTableAccessor
/*     */   extends Accessor
/*     */ {
/*     */   int elementInternalType;
/*     */   int maxNumberOfElements;
/*     */   int elementMaxLen;
/*     */   int ibtValueIndex;
/*     */   int ibtIndicatorIndex;
/*     */   int ibtLengthIndex;
/*     */   int ibtMetaIndex;
/*     */   int ibtByteLength;
/*     */   int ibtCharLength;
/*     */   
/*     */   PlsqlIndexTableAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
/*  44 */     init(paramOracleStatement, 998, 998, paramShort, paramBoolean);
/*  45 */     this.elementInternalType = paramInt2;
/*  46 */     this.maxNumberOfElements = paramInt4;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.elementMaxLen = paramInt3;
/*     */ 
/*     */     
/*  54 */     initForDataAccess(paramInt1, paramInt3, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  62 */     if (paramInt1 != 0) {
/*  63 */       this.externalType = paramInt1;
/*     */     }
/*  65 */     switch (this.elementInternalType) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 96:
/*  71 */         this.internalTypeMaxLength = ((OraclePreparedStatement)this.statement).maxIbtVarcharElementLength;
/*     */ 
/*     */         
/*  74 */         if (paramInt2 > this.internalTypeMaxLength) {
/*     */           
/*  76 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  77 */           sQLException1.fillInStackTrace();
/*  78 */           throw sQLException1;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  84 */         this.elementMaxLen = ((paramInt2 == 0) ? this.internalTypeMaxLength : paramInt2) + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  89 */         this.ibtCharLength = this.elementMaxLen * this.maxNumberOfElements;
/*     */         
/*  91 */         this.elementInternalType = 9;
/*     */         return;
/*     */ 
/*     */       
/*     */       case 6:
/*  96 */         this.internalTypeMaxLength = 21;
/*  97 */         this.elementMaxLen = this.internalTypeMaxLength + 1;
/*  98 */         this.ibtByteLength = this.elementMaxLen * this.maxNumberOfElements;
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 104 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/* 105 */     sQLException.fillInStackTrace();
/* 106 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object[] getPlsqlIndexTable(int paramInt) throws SQLException {
/*     */     BigDecimal[] arrayOfBigDecimal;
/*     */     char[] arrayOfChar;
/*     */     byte b1;
/*     */     byte[] arrayOfByte;
/*     */     byte b2;
/* 124 */     String[] arrayOfString = null;
/* 125 */     short[] arrayOfShort = this.statement.ibtBindIndicators;
/* 126 */     int i = ((arrayOfShort[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (arrayOfShort[this.ibtMetaIndex + 5] & 0xFFFF);
/*     */ 
/*     */     
/* 129 */     int j = this.ibtValueIndex;
/*     */ 
/*     */     
/* 132 */     switch (this.elementInternalType) {
/*     */ 
/*     */       
/*     */       case 9:
/* 136 */         arrayOfString = new String[i];
/* 137 */         arrayOfChar = this.statement.ibtBindChars;
/*     */         
/* 139 */         for (b1 = 0; b1 < i; b1++) {
/*     */           
/* 141 */           if (arrayOfShort[this.ibtIndicatorIndex + b1] == -1) {
/*     */             
/* 143 */             arrayOfString[b1] = null;
/*     */           }
/*     */           else {
/*     */             
/* 147 */             arrayOfString[b1] = new String(arrayOfChar, j + 1, arrayOfChar[j] >> 1);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 152 */           j += this.elementMaxLen;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 190 */         return (Object[])arrayOfString;case 6: arrayOfBigDecimal = new BigDecimal[i]; arrayOfByte = this.statement.ibtBindBytes; for (b2 = 0; b2 < i; b2++) { if (arrayOfShort[this.ibtIndicatorIndex + b2] == -1) { arrayOfBigDecimal[b2] = null; } else { byte b = arrayOfByte[j]; byte[] arrayOfByte1 = new byte[b]; System.arraycopy(arrayOfByte, j + 1, arrayOfByte1, 0, b); arrayOfBigDecimal[b2] = NUMBER.toBigDecimal(arrayOfByte1); }  j += this.elementMaxLen; }  return (Object[])arrayOfBigDecimal;
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/*     */     NUMBER[] arrayOfNUMBER;
/*     */     CharacterSet characterSet;
/*     */     char[] arrayOfChar;
/*     */     byte b1;
/*     */     byte[] arrayOfByte;
/*     */     byte b2;
/* 206 */     CHAR[] arrayOfCHAR = null;
/* 207 */     short[] arrayOfShort = this.statement.ibtBindIndicators;
/* 208 */     int i = ((arrayOfShort[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (arrayOfShort[this.ibtMetaIndex + 5] & 0xFFFF);
/*     */ 
/*     */     
/* 211 */     int j = this.ibtValueIndex;
/*     */ 
/*     */     
/* 214 */     switch (this.elementInternalType) {
/*     */ 
/*     */       
/*     */       case 9:
/* 218 */         arrayOfCHAR = new CHAR[i];
/*     */         
/* 220 */         characterSet = CharacterSet.make(2000);
/* 221 */         arrayOfChar = this.statement.ibtBindChars;
/*     */         
/* 223 */         for (b1 = 0; b1 < i; b1++) {
/*     */           
/* 225 */           if (arrayOfShort[this.ibtIndicatorIndex + b1] == -1) {
/*     */             
/* 227 */             arrayOfCHAR[b1] = null;
/*     */           }
/*     */           else {
/*     */             
/* 231 */             char c = arrayOfChar[j];
/* 232 */             byte[] arrayOfByte1 = new byte[c];
/*     */             
/* 234 */             DBConversion.javaCharsToUcs2Bytes(arrayOfChar, j + 1, arrayOfByte1, 0, c >> 1);
/*     */ 
/*     */             
/* 237 */             arrayOfCHAR[b1] = new CHAR(arrayOfByte1, characterSet);
/*     */           } 
/*     */           
/* 240 */           j += this.elementMaxLen;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 278 */         return (Datum[])arrayOfCHAR;case 6: arrayOfNUMBER = new NUMBER[i]; arrayOfByte = this.statement.ibtBindBytes; for (b2 = 0; b2 < i; b2++) { if (arrayOfShort[this.ibtIndicatorIndex + b2] == -1) { arrayOfNUMBER[b2] = null; } else { byte b = arrayOfByte[j]; byte[] arrayOfByte1 = new byte[b]; System.arraycopy(arrayOfByte, j + 1, arrayOfByte1, 0, b); arrayOfNUMBER[b2] = new NUMBER(arrayOfByte1); }  j += this.elementMaxLen; }  return (Datum[])arrayOfNUMBER;
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/* 283 */   } private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\PlsqlIndexTableAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */