/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.EventListener;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import oracle.jdbc.NotificationRegistration;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.jdbc.aq.AQNotificationListener;
/*     */ import oracle.jdbc.dcn.DatabaseChangeListener;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class NTFRegistration
/*     */ {
/*     */   private final boolean jdbcGetsNotification;
/*     */   private final String clientHost;
/*     */   private final int clientTCPPort;
/*     */   private final Properties options;
/*     */   private final boolean isPurgeOnNTF;
/*     */   private final String username;
/*     */   private final int namespace;
/*     */   private final int jdbcRegId;
/*     */   private final String dbName;
/*     */   private final short databaseVersion;
/*     */   private NotificationRegistration.RegistrationState state;
/*  73 */   private NTFEventListener[] listeners = new NTFEventListener[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTFRegistration(int paramInt1, int paramInt2, boolean paramBoolean, String paramString1, String paramString2, int paramInt3, Properties paramProperties, String paramString3, short paramShort) {
/*  88 */     this.namespace = paramInt2;
/*  89 */     this.clientHost = paramString2;
/*  90 */     this.clientTCPPort = paramInt3;
/*  91 */     this.options = paramProperties;
/*  92 */     this.jdbcRegId = paramInt1;
/*  93 */     this.username = paramString3;
/*  94 */     this.jdbcGetsNotification = paramBoolean;
/*  95 */     this.dbName = paramString1;
/*  96 */     this.state = NotificationRegistration.RegistrationState.ACTIVE;
/*  97 */     if (this.options.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0) {
/*     */       
/*  99 */       this.isPurgeOnNTF = true;
/*     */     } else {
/* 101 */       this.isPurgeOnNTF = false;
/* 102 */     }  this.databaseVersion = paramShort;
/*     */   }
/*     */ 
/*     */   
/*     */   short getDatabaseVersion() {
/* 107 */     return this.databaseVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void addListener(NTFEventListener paramNTFEventListener) throws SQLException {
/* 113 */     if (this.state == NotificationRegistration.RegistrationState.CLOSED) {
/*     */ 
/*     */       
/* 116 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 251);
/* 117 */       sQLException.fillInStackTrace();
/* 118 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 122 */     if (!this.jdbcGetsNotification) {
/*     */ 
/*     */ 
/*     */       
/* 126 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 247);
/* 127 */       sQLException.fillInStackTrace();
/* 128 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 132 */     int i = this.listeners.length;
/* 133 */     for (byte b = 0; b < i; b++) {
/* 134 */       if (this.listeners[b].getListener() == paramNTFEventListener.getListener()) {
/*     */ 
/*     */ 
/*     */         
/* 138 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 139 */         sQLException.fillInStackTrace();
/* 140 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 145 */     System.arraycopy(this.listeners, 0, arrayOfNTFEventListener, 0, i);
/* 146 */     arrayOfNTFEventListener[i] = paramNTFEventListener;
/*     */     
/* 148 */     this.listeners = arrayOfNTFEventListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void removeListener(EventListener paramEventListener) throws SQLException {
/* 158 */     byte b1 = 0;
/* 159 */     int i = this.listeners.length;
/*     */     
/* 161 */     for (b1 = 0; b1 < i && 
/* 162 */       this.listeners[b1].getListener() != paramEventListener; b1++);
/*     */     
/* 164 */     if (b1 == i) {
/*     */ 
/*     */ 
/*     */       
/* 168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 169 */       sQLException.fillInStackTrace();
/* 170 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 174 */     NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
/* 175 */     byte b2 = 0;
/* 176 */     for (b1 = 0; b1 < i; b1++) {
/* 177 */       if (this.listeners[b1].getListener() != paramEventListener) {
/* 178 */         arrayOfNTFEventListener[b2++] = this.listeners[b1];
/*     */       }
/*     */     } 
/* 181 */     this.listeners = arrayOfNTFEventListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notify(final NTFDCNEvent event) {
/* 190 */     long l = 0L;
/*     */     
/* 192 */     NTFEventListener[] arrayOfNTFEventListener = this.listeners;
/*     */ 
/*     */ 
/*     */     
/* 196 */     int i = arrayOfNTFEventListener.length;
/* 197 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 199 */       Executor executor = arrayOfNTFEventListener[b].getExecutor();
/*     */ 
/*     */ 
/*     */       
/* 203 */       if (executor != null) {
/*     */         
/* 205 */         final DatabaseChangeListener l = arrayOfNTFEventListener[b].getDCNListener();
/*     */         
/* 207 */         executor.execute(new Runnable() {
/*     */               public void run() {
/* 209 */                 l.onDatabaseChangeNotification(event);
/*     */               }
/*     */             });
/*     */       }
/*     */       else {
/*     */         
/* 215 */         arrayOfNTFEventListener[b].getDCNListener().onDatabaseChangeNotification(event);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (event.isDeregistrationEvent() || this.isPurgeOnNTF) {
/*     */       
/* 225 */       PhysicalConnection.ntfManager.removeRegistration(this);
/* 226 */       PhysicalConnection.ntfManager.freeJdbcRegId(getJdbcRegId());
/* 227 */       PhysicalConnection.ntfManager.cleanListenersT4C(getClientTCPPort());
/* 228 */       this.state = NotificationRegistration.RegistrationState.CLOSED;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notify(final NTFAQEvent event) {
/* 240 */     long l = 0L;
/*     */     
/* 242 */     NTFEventListener[] arrayOfNTFEventListener = this.listeners;
/*     */ 
/*     */ 
/*     */     
/* 246 */     int i = arrayOfNTFEventListener.length;
/* 247 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 249 */       Executor executor = arrayOfNTFEventListener[b].getExecutor();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 254 */       if (executor != null) {
/*     */         
/* 256 */         final AQNotificationListener l = arrayOfNTFEventListener[b].getAQListener();
/*     */         
/* 258 */         executor.execute(new Runnable() {
/*     */               public void run() {
/* 260 */                 l.onAQNotification(event);
/*     */               }
/*     */             });
/*     */       }
/*     */       else {
/*     */         
/* 266 */         arrayOfNTFEventListener[b].getAQListener().onAQNotification(event);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     if (event.getEventType() == AQNotificationEvent.EventType.DEREG || this.isPurgeOnNTF) {
/*     */       
/* 277 */       PhysicalConnection.ntfManager.removeRegistration(this);
/* 278 */       PhysicalConnection.ntfManager.freeJdbcRegId(getJdbcRegId());
/* 279 */       PhysicalConnection.ntfManager.cleanListenersT4C(getClientTCPPort());
/* 280 */       this.state = NotificationRegistration.RegistrationState.CLOSED;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getRegistrationOptions() {
/* 288 */     return this.options;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getJdbcRegId() {
/* 295 */     return this.jdbcRegId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUserName() {
/* 300 */     return this.username;
/*     */   }
/*     */   
/*     */   String getClientHost() {
/* 304 */     return this.clientHost;
/*     */   }
/*     */ 
/*     */   
/*     */   int getClientTCPPort() {
/* 309 */     return this.clientTCPPort;
/*     */   }
/*     */   
/*     */   public String getDatabaseName() {
/* 313 */     return this.dbName;
/*     */   }
/*     */   
/*     */   public NotificationRegistration.RegistrationState getState() {
/* 317 */     return this.state;
/*     */   }
/*     */   
/*     */   protected void setState(NotificationRegistration.RegistrationState paramRegistrationState) {
/* 321 */     this.state = paramRegistrationState;
/*     */   }
/*     */   
/*     */   int getNamespace() {
/* 325 */     return this.namespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 339 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 344 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\NTFRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */