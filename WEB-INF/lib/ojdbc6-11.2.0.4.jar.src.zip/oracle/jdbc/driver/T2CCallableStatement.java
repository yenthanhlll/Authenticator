/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T2CCallableStatement
/*      */   extends OracleCallableStatement
/*      */ {
/*   42 */   T2CConnection connection = null;
/*   43 */   int userResultSetType = -1;
/*   44 */   int userResultSetConcur = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   50 */   static int T2C_EXTEND_BUFFER = -3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   65 */   long[] t2cOutput = new long[10];
/*      */ 
/*      */ 
/*      */   
/*      */   static final int T2C_OUTPUT_USE_NIO = 5;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6;
/*      */ 
/*      */ 
/*      */   
/*      */   int extractedCharOffset;
/*      */ 
/*      */ 
/*      */   
/*      */   int extractedByteOffset;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2;
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3;
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4;
/*      */ 
/*      */ 
/*      */   
/*      */   T2CCallableStatement(T2CConnection paramT2CConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  104 */     super(paramT2CConnection, paramString, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */     
/*  107 */     this.userResultSetType = paramInt3;
/*  108 */     this.userResultSetConcur = paramInt4;
/*      */ 
/*      */     
/*  111 */     this.connection = paramT2CConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  127 */     byte[] arrayOfByte = new byte[paramInt2];
/*      */     
/*  129 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/*  131 */     return this.connection.conversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processDescribeData() throws SQLException {
/*  147 */     this.described = true;
/*  148 */     this.describedWithNames = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  159 */     if (this.accessors == null || this.numberOfDefinePositions > this.accessors.length) {
/*  160 */       this.accessors = new Accessor[this.numberOfDefinePositions];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  176 */     int i = this.connection.queryMetaData1Offset;
/*  177 */     int j = this.connection.queryMetaData2Offset;
/*  178 */     short[] arrayOfShort = this.connection.queryMetaData1;
/*  179 */     byte[] arrayOfByte = this.connection.queryMetaData2;
/*      */     
/*  181 */     for (byte b = 0; b < this.numberOfDefinePositions; 
/*  182 */       b++, i += 13) {
/*      */       
/*  184 */       short s1 = arrayOfShort[i + 0];
/*  185 */       short s2 = arrayOfShort[i + 1];
/*  186 */       short s3 = arrayOfShort[i + 11];
/*  187 */       boolean bool1 = (arrayOfShort[i + 2] != 0) ? true : false;
/*  188 */       short s4 = arrayOfShort[i + 3];
/*  189 */       short s5 = arrayOfShort[i + 4];
/*  190 */       boolean bool2 = false;
/*  191 */       boolean bool3 = false;
/*  192 */       boolean bool4 = false;
/*  193 */       short s6 = arrayOfShort[i + 5];
/*  194 */       short s7 = arrayOfShort[i + 6];
/*  195 */       String str1 = bytes2String(arrayOfByte, j, s7);
/*  196 */       short s8 = arrayOfShort[i + 12];
/*  197 */       String str2 = null;
/*  198 */       OracleTypeADT oracleTypeADT = null;
/*      */       
/*  200 */       j += s7;
/*      */       
/*  202 */       if (s8 > 0) {
/*      */         
/*  204 */         str2 = bytes2String(arrayOfByte, j, s8);
/*  205 */         j += s8;
/*  206 */         oracleTypeADT = new OracleTypeADT(str2, (Connection)this.connection);
/*  207 */         oracleTypeADT.tdoCState = (arrayOfShort[i + 7] & 0xFFFFL) << 48L | (arrayOfShort[i + 8] & 0xFFFFL) << 32L | (arrayOfShort[i + 9] & 0xFFFFL) << 16L | arrayOfShort[i + 10] & 0xFFFFL;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  215 */       Accessor accessor = this.accessors[b];
/*      */       
/*  217 */       if (accessor != null && !accessor.useForDescribeIfPossible(s1, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2))
/*      */       {
/*      */ 
/*      */         
/*  221 */         accessor = null;
/*      */       }
/*      */       
/*  224 */       if (accessor == null) {
/*      */         SQLException sQLException;
/*  226 */         switch (s1) {
/*      */ 
/*      */           
/*      */           case 1:
/*  230 */             accessor = new VarcharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */             
/*  234 */             if (s3 > 0) {
/*  235 */               accessor.setDisplaySize(s3);
/*      */             }
/*      */             break;
/*      */           
/*      */           case 96:
/*  240 */             accessor = new CharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */             
/*  244 */             if (s3 > 0) {
/*  245 */               accessor.setDisplaySize(s3);
/*      */             }
/*      */             break;
/*      */           
/*      */           case 2:
/*  250 */             accessor = new NumberAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 23:
/*  257 */             accessor = new RawAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 100:
/*  264 */             accessor = new BinaryFloatAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 101:
/*  271 */             accessor = new BinaryDoubleAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*  278 */             accessor = new LongAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  285 */             this.rowPrefetch = 1;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 24:
/*  290 */             accessor = new LongRawAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  297 */             this.rowPrefetch = 1;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 104:
/*  302 */             accessor = new RowidAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 102:
/*      */           case 116:
/*  311 */             accessor = new T2CResultSetAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 12:
/*  318 */             accessor = new DateAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 180:
/*  325 */             accessor = new TimestampAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 181:
/*  332 */             accessor = new TimestamptzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 231:
/*  339 */             accessor = new TimestampltzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 182:
/*  346 */             accessor = new IntervalymAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 183:
/*  353 */             accessor = new IntervaldsAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 112:
/*  360 */             accessor = new ClobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 113:
/*  367 */             accessor = new BlobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 114:
/*  374 */             accessor = new BfileAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 109:
/*  381 */             accessor = new NamedTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 111:
/*  389 */             accessor = new RefTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  398 */             sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unknown or unimplemented accessor type: " + s1);
/*      */             
/*  400 */             sQLException.fillInStackTrace();
/*  401 */             throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  406 */         this.accessors[b] = accessor;
/*      */       }
/*  408 */       else if (oracleTypeADT != null) {
/*      */ 
/*      */ 
/*      */         
/*  412 */         accessor.describeOtype = (OracleType)oracleTypeADT;
/*  413 */         accessor.initMetadata();
/*      */       } 
/*      */       
/*  416 */       accessor.columnName = str1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*      */     boolean bool3;
/*  457 */     this.t2cOutput[0] = 0L;
/*  458 */     this.t2cOutput[2] = 0L;
/*      */ 
/*      */ 
/*      */     
/*  462 */     this.lobPrefetchMetaData = null;
/*      */     
/*  464 */     boolean bool1 = !this.described ? true : false;
/*  465 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  470 */       bool3 = false;
/*      */ 
/*      */       
/*  473 */       if (this.connection.endToEndAnyChanged) {
/*      */         
/*  475 */         pushEndToEndValues();
/*      */         
/*  477 */         this.connection.endToEndAnyChanged = false;
/*      */       } 
/*      */ 
/*      */       
/*  481 */       byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
/*      */       
/*  483 */       int i = 0;
/*      */       
/*      */       try {
/*  486 */         i = T2CStatement.t2cParseExecuteDescribe(this, this.c_state, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, (this.currentRowBindAccessors != null), this.needToParse, bool1, bool2, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, this.ibtBindIndicators, this.ibtBindIndicatorOffset, this.ibtBindIndicatorSize, this.ibtBindBytes, this.ibtBindChars, this.ibtBindByteOffset, this.ibtBindCharOffset, this.returnParamMeta, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, this.preparedAllBinds, this.preparedCharBinds, this.outBindAccessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.connection.plsqlCompilerWarnings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  533 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  536 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
/*  537 */         sQLException.fillInStackTrace();
/*  538 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  543 */       this.validRows = (int)this.t2cOutput[1];
/*      */ 
/*      */       
/*  546 */       if (i == -1 || i == -4) {
/*      */         
/*  548 */         this.connection.checkError(i);
/*      */       }
/*  550 */       else if (i == T2C_EXTEND_BUFFER) {
/*      */         
/*  552 */         i = this.connection.queryMetaData1Size * 2;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  557 */       if (this.t2cOutput[3] != 0L) {
/*      */         
/*  559 */         foundPlsqlCompilerWarning();
/*      */       }
/*  561 */       else if (this.t2cOutput[2] != 0L) {
/*      */         
/*  563 */         this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  568 */       this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
/*      */ 
/*      */       
/*  571 */       this.needToParse = false;
/*  572 */       bool2 = true;
/*      */       
/*  574 */       if (this.sqlKind.isSELECT())
/*      */       {
/*  576 */         this.numberOfDefinePositions = i;
/*      */         
/*  578 */         if (this.numberOfDefinePositions > this.connection.queryMetaData1Size)
/*      */         {
/*  580 */           bool3 = true;
/*  581 */           bool2 = true;
/*      */ 
/*      */           
/*  584 */           this.connection.reallocateQueryMetaData(this.numberOfDefinePositions, this.numberOfDefinePositions * 8);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  591 */         this.numberOfDefinePositions = 0;
/*  592 */         this.validRows = i;
/*      */       }
/*      */     
/*  595 */     } while (bool3);
/*      */     
/*  597 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void pushEndToEndValues() throws SQLException {
/*  604 */     T2CConnection t2CConnection = this.connection;
/*  605 */     byte[] arrayOfByte1 = new byte[0];
/*  606 */     byte[] arrayOfByte2 = new byte[0];
/*  607 */     byte[] arrayOfByte3 = new byte[0];
/*  608 */     byte[] arrayOfByte4 = new byte[0];
/*      */     
/*  610 */     if (t2CConnection.endToEndValues != null) {
/*      */       
/*  612 */       if (t2CConnection.endToEndHasChanged[0]) {
/*      */         
/*  614 */         String str = t2CConnection.endToEndValues[0];
/*      */         
/*  616 */         if (str != null) {
/*  617 */           arrayOfByte1 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  620 */         t2CConnection.endToEndHasChanged[0] = false;
/*      */       } 
/*      */       
/*  623 */       if (t2CConnection.endToEndHasChanged[1]) {
/*      */         
/*  625 */         String str = t2CConnection.endToEndValues[1];
/*      */         
/*  627 */         if (str != null) {
/*  628 */           arrayOfByte2 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  631 */         t2CConnection.endToEndHasChanged[1] = false;
/*      */       } 
/*      */       
/*  634 */       if (t2CConnection.endToEndHasChanged[2]) {
/*      */         
/*  636 */         String str = t2CConnection.endToEndValues[2];
/*      */         
/*  638 */         if (str != null) {
/*  639 */           arrayOfByte3 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  642 */         t2CConnection.endToEndHasChanged[2] = false;
/*      */       } 
/*      */       
/*  645 */       if (t2CConnection.endToEndHasChanged[3]) {
/*      */         
/*  647 */         String str = t2CConnection.endToEndValues[3];
/*      */         
/*  649 */         if (str != null) {
/*  650 */           arrayOfByte4 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  653 */         t2CConnection.endToEndHasChanged[3] = false;
/*      */       } 
/*      */       
/*  656 */       T2CStatement.t2cEndToEndUpdate(this.c_state, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, t2CConnection.endToEndECIDSequenceNumber);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*  709 */     if (this.connection.endToEndAnyChanged) {
/*      */       
/*  711 */       pushEndToEndValues();
/*      */       
/*  713 */       this.connection.endToEndAnyChanged = false;
/*      */     } 
/*      */ 
/*      */     
/*  717 */     if (!paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  725 */       if (this.numberOfDefinePositions > 0)
/*      */       {
/*  727 */         doDefineExecuteFetch();
/*      */       }
/*      */       else
/*      */       {
/*  731 */         executeForDescribe();
/*      */       }
/*      */     
/*  734 */     } else if (this.numberOfDefinePositions > 0) {
/*  735 */       doDefineFetch();
/*      */     } 
/*      */ 
/*      */     
/*  739 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setupForDefine() throws SQLException {
/*  749 */     if (this.numberOfDefinePositions > this.connection.queryMetaData1Size) {
/*      */       
/*  751 */       int j = this.numberOfDefinePositions / 100 + 1;
/*      */       
/*  753 */       this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * j, this.connection.queryMetaData2Size * j * 8);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  758 */     short[] arrayOfShort = this.connection.queryMetaData1;
/*  759 */     int i = this.connection.queryMetaData1Offset;
/*      */ 
/*      */     
/*  762 */     for (byte b = 0; b < this.numberOfDefinePositions; 
/*  763 */       b++, i += 13) {
/*      */       
/*  765 */       Accessor accessor = this.accessors[b];
/*      */       
/*  767 */       if (accessor == null) {
/*      */         
/*  769 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  770 */         sQLException.fillInStackTrace();
/*  771 */         throw sQLException;
/*      */       } 
/*      */       
/*  774 */       arrayOfShort[i + 0] = (short)accessor.defineType;
/*      */       
/*  776 */       arrayOfShort[i + 11] = (short)accessor.charLength;
/*      */       
/*  778 */       arrayOfShort[i + 1] = (short)accessor.byteLength;
/*      */       
/*  780 */       arrayOfShort[i + 5] = accessor.formOfUse;
/*      */ 
/*      */       
/*  783 */       if (accessor.internalOtype != null) {
/*      */         
/*  785 */         long l = ((OracleTypeADT)accessor.internalOtype).getTdoCState();
/*      */ 
/*      */         
/*  788 */         arrayOfShort[i + 7] = (short)(int)((l & 0xFFFF000000000000L) >> 48L);
/*      */         
/*  790 */         arrayOfShort[i + 8] = (short)(int)((l & 0xFFFF00000000L) >> 32L);
/*      */         
/*  792 */         arrayOfShort[i + 9] = (short)(int)((l & 0xFFFF0000L) >> 16L);
/*      */         
/*  794 */         arrayOfShort[i + 10] = (short)(int)(l & 0xFFFFL);
/*      */       } 
/*      */ 
/*      */       
/*  798 */       switch (accessor.internalType) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 112:
/*      */         case 113:
/*  804 */           if (accessor.lobPrefetchSizeForThisColumn == -1) {
/*  805 */             accessor.lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/*      */           }
/*      */           
/*  808 */           arrayOfShort[i + 7] = (short)accessor.lobPrefetchSizeForThisColumn;
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object[] getLobPrefetchMetaData() {
/*  828 */     Object[] arrayOfObject = null;
/*  829 */     Object object = null;
/*  830 */     int[] arrayOfInt = null;
/*  831 */     byte b1 = 0;
/*  832 */     byte b2 = 0;
/*      */     
/*  834 */     if (this.accessors != null) {
/*  835 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */         
/*  837 */         switch ((this.accessors[b]).internalType) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 24:
/*  844 */             b2 = b;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 112:
/*      */           case 113:
/*  851 */             if (arrayOfInt == null)
/*      */             {
/*  853 */               arrayOfInt = new int[this.accessors.length];
/*      */             }
/*      */             
/*  856 */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn != -1) {
/*      */               
/*  858 */               b1++;
/*      */               
/*  860 */               arrayOfInt[b] = (this.accessors[b]).lobPrefetchSizeForThisColumn;
/*      */               
/*      */               break;
/*      */             } 
/*  864 */             arrayOfInt[b] = -1;
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*      */     }
/*  872 */     if (b1 > 0) {
/*      */       
/*  874 */       if (arrayOfObject == null)
/*      */       {
/*  876 */         arrayOfObject = new Object[] { null, new long[this.rowPrefetch * b1], new byte[this.accessors.length], new int[this.accessors.length], new Object[this.rowPrefetch * b1] };
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  898 */       for (byte b = 0; b < b2; b++) {
/*      */         
/*  900 */         switch ((this.accessors[b]).internalType) {
/*      */           
/*      */           case 112:
/*      */           case 113:
/*  904 */             (this.accessors[b]).lobPrefetchSizeForThisColumn = -1;
/*  905 */             arrayOfInt[b] = -1;
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*  910 */       arrayOfObject[0] = arrayOfInt;
/*      */     } 
/*      */ 
/*      */     
/*  914 */     return arrayOfObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {
/*  921 */     byte b1 = 0;
/*  922 */     byte b2 = (this.validRows == -2) ? 1 : this.validRows;
/*      */     
/*  924 */     byte[] arrayOfByte = (byte[])paramArrayOfObject[2];
/*  925 */     int[] arrayOfInt1 = (int[])paramArrayOfObject[3];
/*  926 */     long[] arrayOfLong = (long[])paramArrayOfObject[1];
/*  927 */     Object[] arrayOfObject = (Object[])paramArrayOfObject[4];
/*  928 */     int[] arrayOfInt2 = (int[])paramArrayOfObject[0];
/*      */     
/*  930 */     if (this.accessors != null) {
/*  931 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */         
/*  933 */         switch ((this.accessors[b]).internalType) {
/*      */ 
/*      */           
/*      */           case 112:
/*      */           case 113:
/*  938 */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn >= 0) {
/*      */               
/*  940 */               Accessor accessor = this.accessors[b];
/*      */               
/*  942 */               if (accessor.prefetchedLobDataL == null || accessor.prefetchedLobDataL.length < this.rowPrefetch) {
/*      */ 
/*      */                 
/*  945 */                 if (accessor.internalType == 112) {
/*  946 */                   accessor.prefetchedLobCharData = new char[this.rowPrefetch][];
/*      */                 } else {
/*  948 */                   accessor.prefetchedLobData = new byte[this.rowPrefetch][];
/*      */                 } 
/*  950 */                 accessor.prefetchedLobChunkSize = new int[this.rowPrefetch];
/*  951 */                 accessor.prefetchedClobFormOfUse = new byte[this.rowPrefetch];
/*  952 */                 accessor.prefetchedLobDataL = new int[this.rowPrefetch];
/*  953 */                 accessor.prefetchedLobSize = new long[this.rowPrefetch];
/*      */               } 
/*      */               
/*  956 */               int i = b2 * b1;
/*  957 */               for (byte b3 = 0; b3 < b2; b3++) {
/*      */                 
/*  959 */                 accessor.prefetchedLobChunkSize[b3] = arrayOfInt1[b];
/*      */                 
/*  961 */                 accessor.prefetchedClobFormOfUse[b3] = arrayOfByte[b];
/*      */ 
/*      */                 
/*  964 */                 accessor.prefetchedLobSize[b3] = arrayOfLong[i + b3];
/*      */ 
/*      */                 
/*  967 */                 accessor.prefetchedLobDataL[b3] = 0;
/*  968 */                 if (arrayOfInt2[b] > 0 && arrayOfLong[i + b3] > 0L)
/*      */                 {
/*      */                   
/*  971 */                   if (accessor.internalType == 112) {
/*      */                     
/*  973 */                     accessor.prefetchedLobCharData[b3] = (char[])arrayOfObject[i + b3];
/*      */                     
/*  975 */                     if (accessor.prefetchedLobCharData[b3] != null) {
/*  976 */                       accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobCharData[b3]).length;
/*      */                     }
/*      */                   }
/*      */                   else {
/*      */                     
/*  981 */                     accessor.prefetchedLobData[b3] = (byte[])arrayOfObject[i + b3];
/*      */                     
/*  983 */                     if (accessor.prefetchedLobData[b3] != null) {
/*  984 */                       accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobData[b3]).length;
/*      */                     }
/*      */                   } 
/*      */                 }
/*      */               } 
/*  989 */               b1++;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDefineFetch() throws SQLException {
/* 1002 */     if (!this.needToPrepareDefineBuffer) {
/* 1003 */       throw new Error("doDefineFetch called when needToPrepareDefineBuffer=false " + this.sqlObject.getSql(this.processEscapes, this.convertNcharLiterals));
/*      */     }
/*      */     
/* 1006 */     setupForDefine();
/*      */     
/* 1008 */     this.t2cOutput[2] = 0L;
/* 1009 */     this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1010 */     this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1011 */     if (this.connection.useNio) {
/* 1012 */       resetNioAttributesBeforeFetch();
/* 1013 */       allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1019 */     if (this.lobPrefetchMetaData == null) {
/* 1020 */       this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */     }
/* 1022 */     this.validRows = T2CStatement.t2cDefineFetch(this, this.c_state, this.rowPrefetch, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1035 */     if (this.validRows == -1 || this.validRows == -4) {
/* 1036 */       this.connection.checkError(this.validRows);
/*      */     }
/*      */     
/* 1039 */     if (this.t2cOutput[2] != 0L)
/*      */     {
/* 1041 */       this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */     }
/*      */ 
/*      */     
/* 1045 */     if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */     {
/* 1047 */       extractNioDefineBuffers(0);
/*      */     }
/* 1049 */     if (this.lobPrefetchMetaData != null)
/*      */     {
/* 1051 */       processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateNioBuffersIfRequired(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1061 */     if (this.nioBuffers == null) {
/* 1062 */       this.nioBuffers = new ByteBuffer[4];
/*      */     }
/* 1064 */     if (paramInt2 > 0)
/*      */     {
/* 1066 */       if (this.nioBuffers[0] == null || this.nioBuffers[0].capacity() < paramInt2) {
/*      */ 
/*      */         
/* 1069 */         this.nioBuffers[0] = ByteBuffer.allocateDirect(paramInt2);
/* 1070 */       } else if (this.nioBuffers[0] != null) {
/*      */         
/* 1072 */         this.nioBuffers[0].rewind();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1079 */     paramInt1 *= 2;
/* 1080 */     if (paramInt1 > 0)
/*      */     {
/* 1082 */       if (this.nioBuffers[1] == null || this.nioBuffers[1].capacity() < paramInt1) {
/*      */ 
/*      */         
/* 1085 */         this.nioBuffers[1] = ByteBuffer.allocateDirect(paramInt1);
/* 1086 */       } else if (this.nioBuffers[1] != null) {
/*      */         
/* 1088 */         this.nioBuffers[1].rewind();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1095 */     paramInt3 *= 2;
/* 1096 */     if (paramInt3 > 0)
/*      */     {
/* 1098 */       if (this.nioBuffers[2] == null || this.nioBuffers[2].capacity() < paramInt3) {
/*      */ 
/*      */         
/* 1101 */         this.nioBuffers[2] = ByteBuffer.allocateDirect(paramInt3);
/* 1102 */       } else if (this.nioBuffers[2] != null) {
/*      */         
/* 1104 */         this.nioBuffers[2].rewind();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDefineExecuteFetch() throws SQLException {
/* 1113 */     short[] arrayOfShort = null;
/*      */     
/* 1115 */     if (this.needToPrepareDefineBuffer || this.needToParse) {
/*      */       
/* 1117 */       setupForDefine();
/*      */       
/* 1119 */       arrayOfShort = this.connection.queryMetaData1;
/*      */     } 
/*      */     
/* 1122 */     this.t2cOutput[0] = 0L;
/* 1123 */     this.t2cOutput[2] = 0L;
/*      */     
/* 1125 */     byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
/* 1126 */     this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1127 */     this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1128 */     if (this.connection.useNio) {
/* 1129 */       resetNioAttributesBeforeFetch();
/* 1130 */       allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     if (this.lobPrefetchMetaData == null) {
/* 1137 */       this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */     }
/*      */     try {
/* 1140 */       this.validRows = T2CStatement.t2cDefineExecuteFetch(this, this.c_state, this.numberOfDefinePositions, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, (this.currentRowBindAccessors != null), this.needToParse, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, arrayOfShort, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.preparedAllBinds, this.preparedCharBinds, this.outBindAccessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1178 */     catch (IOException iOException) {
/*      */       
/* 1180 */       this.validRows = 0;
/*      */       
/* 1182 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1183 */       sQLException.fillInStackTrace();
/* 1184 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1188 */     if (this.validRows == -1) {
/* 1189 */       this.connection.checkError(this.validRows);
/*      */     }
/* 1191 */     if (this.t2cOutput[2] != 0L) {
/* 1192 */       this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1197 */     this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
/*      */     
/* 1199 */     if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */     {
/* 1201 */       extractNioDefineBuffers(0);
/*      */     }
/* 1203 */     if (this.lobPrefetchMetaData != null)
/*      */     {
/* 1205 */       processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */     }
/*      */     
/* 1208 */     this.needToParse = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1251 */     if (this.numberOfDefinePositions > 0)
/*      */     {
/* 1253 */       if (this.needToPrepareDefineBuffer) {
/* 1254 */         doDefineFetch();
/*      */       } else {
/*      */         
/* 1257 */         this.t2cOutput[2] = 0L;
/* 1258 */         this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1259 */         this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1260 */         if (this.connection.useNio) {
/* 1261 */           resetNioAttributesBeforeFetch();
/* 1262 */           allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1269 */         if (this.lobPrefetchMetaData == null) {
/* 1270 */           this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */         }
/* 1272 */         this.validRows = T2CStatement.t2cFetch(this.c_state, this.needToPrepareDefineBuffer, this.rowPrefetch, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1280 */         if (this.validRows == -1 || this.validRows == -4) {
/* 1281 */           this.connection.checkError(this.validRows);
/*      */         }
/* 1283 */         if (this.t2cOutput[2] != 0L)
/*      */         {
/* 1285 */           this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */         }
/*      */         
/* 1288 */         if (this.lobPrefetchMetaData != null)
/*      */         {
/* 1290 */           processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */         }
/* 1292 */         if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */         {
/* 1294 */           extractNioDefineBuffers(0);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNioAttributesBeforeFetch() {
/* 1303 */     this.extractedCharOffset = 0;
/* 1304 */     this.extractedByteOffset = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void extractNioDefineBuffers(int paramInt) throws SQLException {
/* 1313 */     if (this.accessors == null || this.defineIndicators == null || paramInt == this.numberOfDefinePositions) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1318 */     int i = 0;
/* 1319 */     int j = 0;
/* 1320 */     int k = 0;
/* 1321 */     int m = 0;
/* 1322 */     int n = 0;
/*      */ 
/*      */     
/* 1325 */     if (!this.hasStream) {
/*      */       
/* 1327 */       i = (this.defineBytes != null) ? this.defineBytes.length : 0;
/* 1328 */       j = (this.defineChars != null) ? this.defineChars.length : 0;
/* 1329 */       k = this.defineIndicators.length;
/*      */     }
/*      */     else {
/*      */       
/* 1333 */       if (this.numberOfDefinePositions > paramInt) {
/*      */         
/* 1335 */         n = (this.accessors[paramInt]).indicatorIndex;
/* 1336 */         m = (this.accessors[paramInt]).lengthIndex;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1341 */       for (int i1 = paramInt; i1 < this.numberOfDefinePositions; i1++) {
/*      */         
/* 1343 */         switch ((this.accessors[i1]).internalType) {
/*      */           case 8:
/*      */           case 24:
/*      */             break;
/*      */         } 
/*      */         
/* 1349 */         i += (this.accessors[i1]).byteLength;
/* 1350 */         j += (this.accessors[i1]).charLength;
/* 1351 */         k++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1356 */     ByteBuffer byteBuffer = this.nioBuffers[0];
/* 1357 */     if (byteBuffer != null && this.defineBytes != null)
/*      */     {
/* 1359 */       if (i > 0) {
/*      */         
/* 1361 */         byteBuffer.position(this.extractedByteOffset);
/* 1362 */         byteBuffer.get(this.defineBytes, this.extractedByteOffset, i);
/* 1363 */         this.extractedByteOffset += i;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1378 */     if (this.nioBuffers[1] != null && this.defineChars != null) {
/*      */       
/* 1380 */       byteBuffer = this.nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN);
/* 1381 */       CharBuffer charBuffer = byteBuffer.asCharBuffer();
/*      */       
/* 1383 */       if (j > 0) {
/*      */         
/* 1385 */         charBuffer.position(this.extractedCharOffset);
/* 1386 */         charBuffer.get(this.defineChars, this.extractedCharOffset, j);
/* 1387 */         this.extractedCharOffset += j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1406 */     if (this.nioBuffers[2] != null) {
/* 1407 */       byteBuffer = this.nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN);
/* 1408 */       ShortBuffer shortBuffer = byteBuffer.asShortBuffer();
/* 1409 */       if (this.hasStream) {
/*      */         
/* 1411 */         if (k > 0) {
/*      */           
/* 1413 */           shortBuffer.position(n);
/* 1414 */           shortBuffer.get(this.defineIndicators, n, k);
/* 1415 */           shortBuffer.position(m);
/* 1416 */           shortBuffer.get(this.defineIndicators, m, k);
/*      */         } 
/*      */       } else {
/*      */         
/* 1420 */         shortBuffer.get(this.defineIndicators);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1468 */     if (this.defineBytes != null) {
/*      */       
/* 1470 */       this.defineBytes = null;
/* 1471 */       this.accessorByteOffset = 0;
/*      */     } 
/*      */     
/* 1474 */     if (this.defineChars != null) {
/*      */       
/* 1476 */       this.defineChars = null;
/* 1477 */       this.accessorCharOffset = 0;
/*      */     } 
/*      */     
/* 1480 */     if (this.defineIndicators != null) {
/*      */       
/* 1482 */       this.defineIndicators = null;
/* 1483 */       this.accessorShortOffset = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1487 */     int i = T2CStatement.t2cCloseStatement(this.c_state);
/*      */     
/* 1489 */     this.nioBuffers = null;
/*      */     
/* 1491 */     if (i != 0) {
/* 1492 */       this.connection.checkError(i);
/*      */     }
/* 1494 */     this.t2cOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1512 */     if (this.streamList != null)
/*      */     {
/* 1514 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1518 */           this.nextStream.close();
/*      */         }
/* 1520 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 1523 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1524 */           sQLException.fillInStackTrace();
/* 1525 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1529 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
/* 1546 */     if (paramInt1 == 116 || paramInt1 == 102) {
/*      */ 
/*      */       
/* 1549 */       if (paramBoolean && paramString != null) {
/*      */         
/* 1551 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 1552 */         sQLException.fillInStackTrace();
/* 1553 */         throw sQLException;
/*      */       } 
/*      */       
/* 1556 */       return new T2CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1562 */     return super.allocateAccessor(paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeUsedStreams(int paramInt) throws SQLException {
/* 1570 */     while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1576 */         this.nextStream.close();
/*      */       }
/* 1578 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 1581 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1582 */         sQLException.fillInStackTrace();
/* 1583 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1587 */       this.nextStream = this.nextStream.nextStream;
/*      */     } 
/*      */     
/* 1590 */     if (this.nextStream != null) {
/*      */       
/*      */       try {
/* 1593 */         this.nextStream.needBytes();
/*      */       }
/* 1595 */       catch (IOException iOException) {
/*      */         
/* 1597 */         interalCloseOnIOException(iOException);
/*      */         
/* 1599 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1600 */         sQLException.fillInStackTrace();
/* 1601 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void interalCloseOnIOException(IOException paramIOException) throws SQLException {
/* 1610 */     this.closed = true;
/*      */     
/* 1612 */     if (this.currentResultSet != null) {
/* 1613 */       this.currentResultSet.closed = true;
/*      */     }
/* 1615 */     doClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetchDmlReturnParams() throws SQLException {
/* 1622 */     this.rowsDmlReturned = T2CStatement.t2cGetRowsDmlReturned(this.c_state);
/*      */     
/* 1624 */     if (this.rowsDmlReturned != 0) {
/*      */       
/* 1626 */       allocateDmlReturnStorage();
/*      */       
/* 1628 */       int i = T2CStatement.t2cFetchDmlReturnParams(this.c_state, this.returnParamAccessors, this.returnParamBytes, this.returnParamChars, this.returnParamIndicators);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1636 */       if (i == -1 || i == -4) {
/* 1637 */         this.connection.checkError(i);
/*      */       }
/*      */       
/* 1640 */       if (this.t2cOutput[2] != 0L)
/*      */       {
/* 1642 */         this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */       }
/*      */ 
/*      */       
/* 1646 */       if (this.connection.useNio && (i > 0 || i == -2))
/*      */       {
/* 1648 */         extractNioDefineBuffers(0);
/*      */       }
/*      */     } 
/* 1651 */     this.returnParamsFetched = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1662 */   static int PREAMBLE_PER_POSITION = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initializeIndicatorSubRange() {
/* 1668 */     this.bindIndicatorSubRange = this.numberOfBindPositions * PREAMBLE_PER_POSITION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int calculateIndicatorSubRangeSize() {
/* 1675 */     return this.numberOfBindPositions * PREAMBLE_PER_POSITION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getInoutIndicator(int paramInt) {
/* 1682 */     return this.bindIndicators[paramInt * PREAMBLE_PER_POSITION];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareBindPreambles(int paramInt1, int paramInt2) {
/* 1695 */     int i = calculateIndicatorSubRangeSize();
/* 1696 */     int j = this.bindIndicatorSubRange - i;
/* 1697 */     OracleTypeADT[] arrayOfOracleTypeADT = (this.parameterOtype == null) ? null : this.parameterOtype[this.firstRowInBatch];
/*      */ 
/*      */ 
/*      */     
/* 1701 */     for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */       short s;
/*      */       OracleTypeADT oracleTypeADT;
/* 1704 */       Binder binder = this.lastBinders[b];
/*      */ 
/*      */       
/* 1707 */       if (binder == this.theReturnParamBinder) {
/*      */         
/* 1709 */         oracleTypeADT = (OracleTypeADT)(this.returnParamAccessors[b]).internalOtype;
/* 1710 */         s = 0;
/*      */       }
/*      */       else {
/*      */         
/* 1714 */         oracleTypeADT = (arrayOfOracleTypeADT == null) ? null : arrayOfOracleTypeADT[b];
/*      */         
/* 1716 */         if (this.outBindAccessors == null) {
/* 1717 */           s = 0;
/*      */         } else {
/*      */           
/* 1720 */           Accessor accessor = this.outBindAccessors[b];
/*      */           
/* 1722 */           if (accessor == null) {
/* 1723 */             s = 0;
/* 1724 */           } else if (binder == this.theOutBinder) {
/*      */             
/* 1726 */             s = 1;
/*      */             
/* 1728 */             if (oracleTypeADT == null) {
/* 1729 */               oracleTypeADT = (OracleTypeADT)accessor.internalOtype;
/*      */             }
/*      */           } else {
/* 1732 */             s = 2;
/*      */           } 
/* 1734 */         }  s = binder.updateInoutIndicatorValue(s);
/*      */       } 
/*      */       
/* 1737 */       this.bindIndicators[j++] = s;
/*      */       
/* 1739 */       if (oracleTypeADT != null) {
/*      */         
/* 1741 */         long l = oracleTypeADT.getTdoCState();
/*      */         
/* 1743 */         this.bindIndicators[j + 0] = (short)(int)(l >> 48L & 0xFFFFL);
/*      */         
/* 1745 */         this.bindIndicators[j + 1] = (short)(int)(l >> 32L & 0xFFFFL);
/*      */         
/* 1747 */         this.bindIndicators[j + 2] = (short)(int)(l >> 16L & 0xFFFFL);
/*      */         
/* 1749 */         this.bindIndicators[j + 3] = (short)(int)(l & 0xFFFFL);
/*      */       } 
/*      */       
/* 1752 */       j += 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 1760 */     super.releaseBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*      */     boolean bool;
/* 1779 */     if (this.closed) {
/*      */       
/* 1781 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1782 */       sQLException.fillInStackTrace();
/* 1783 */       throw sQLException;
/*      */     } 
/*      */     
/* 1786 */     if (this.described == true) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1791 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/* 1795 */       this.connection.open(this);
/* 1796 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 1804 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1813 */       boolean bool1 = (this.sqlKind.isSELECT() && this.needToParse && (!this.described || !this.serverCursor)) ? true : false;
/* 1814 */       byte[] arrayOfByte = bool1 ? this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
/* 1815 */       this.numberOfDefinePositions = T2CStatement.t2cDescribe(this.c_state, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, arrayOfByte, arrayOfByte.length, bool1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1826 */       if (!this.described) {
/* 1827 */         this.described = true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1834 */       if (this.numberOfDefinePositions == -1)
/*      */       {
/* 1836 */         this.connection.checkError(this.numberOfDefinePositions);
/*      */       }
/*      */ 
/*      */       
/* 1840 */       if (this.numberOfDefinePositions != T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 1842 */       bool = true;
/*      */ 
/*      */ 
/*      */       
/* 1846 */       this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * 2, this.connection.queryMetaData2Size * 2);
/*      */ 
/*      */     
/*      */     }
/* 1850 */     while (bool);
/*      */     
/* 1852 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
/* 1861 */     int i = paramInt1 - 1;
/*      */     
/* 1863 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */       
/* 1865 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1866 */       sQLException.fillInStackTrace();
/* 1867 */       throw sQLException;
/*      */     } 
/*      */     
/* 1870 */     int j = getInternalType(paramInt2);
/*      */     
/* 1872 */     if (j == 995) {
/*      */       
/* 1874 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1875 */       sQLException.fillInStackTrace();
/* 1876 */       throw sQLException;
/*      */     } 
/*      */     
/* 1879 */     resetBatch();
/*      */     
/* 1881 */     this.currentRowNeedToPrepareBinds = true;
/*      */     
/* 1883 */     if (this.currentRowBindAccessors == null) {
/* 1884 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/*      */     
/* 1887 */     switch (paramInt2) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 70:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/* 1903 */         this.currentRowFormOfUse[i] = 2;
/*      */         break;
/*      */       case 2011:
/* 1906 */         paramInt4 = 0;
/* 1907 */         this.currentRowFormOfUse[i] = 2;
/*      */         break;
/*      */       case 2009:
/* 1910 */         paramInt4 = 0;
/* 1911 */         paramString = "SYS.XMLTYPE";
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1917 */         paramInt4 = 0;
/*      */         break;
/*      */     } 
/*      */     
/* 1921 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, paramInt1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1927 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\T2CCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */