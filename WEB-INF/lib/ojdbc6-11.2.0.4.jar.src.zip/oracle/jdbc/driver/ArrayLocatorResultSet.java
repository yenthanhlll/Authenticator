/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Array;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArrayLocatorResultSet
/*     */   extends OracleResultSetImpl
/*     */ {
/*  23 */   static int COUNT_UNLIMITED = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   Map map;
/*     */ 
/*     */ 
/*     */   
/*     */   long beginIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   int count;
/*     */ 
/*     */   
/*     */   long currentIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayLocatorResultSet(OracleConnection paramOracleConnection, ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, Map paramMap) throws SQLException {
/*  43 */     this(paramOracleConnection, paramArrayDescriptor, paramArrayOfbyte, 0L, COUNT_UNLIMITED, paramMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayLocatorResultSet(OracleConnection paramOracleConnection, ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*  63 */     super((PhysicalConnection)paramOracleConnection, (OracleStatement)null);
/*     */ 
/*     */     
/*  66 */     if (paramArrayDescriptor == null || paramOracleConnection == null) {
/*     */       
/*  68 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid arguments");
/*  69 */       sQLException.fillInStackTrace();
/*  70 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  75 */     this.close_statement_on_close = true;
/*     */     
/*  77 */     this.count = paramInt;
/*  78 */     this.currentIndex = 0L;
/*  79 */     this.beginIndex = paramLong;
/*     */     
/*  81 */     this.map = paramMap;
/*     */     
/*  83 */     OraclePreparedStatement oraclePreparedStatement = null;
/*     */ 
/*     */     
/*  86 */     ARRAY aRRAY = new ARRAY(paramArrayDescriptor, (Connection)paramOracleConnection, null);
/*     */     
/*  88 */     aRRAY.setLocator(paramArrayOfbyte);
/*     */ 
/*     */     
/*  91 */     if (paramArrayDescriptor.getBaseType() == 2002 || paramArrayDescriptor.getBaseType() == 2008) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       oraclePreparedStatement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)paramOracleConnection.prepareStatement("SELECT ROWNUM, SYS_NC_ROWINFO$ FROM TABLE( CAST(:1 AS " + paramArrayDescriptor.getName() + ") )")).preparedStatement;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 106 */       oraclePreparedStatement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)paramOracleConnection.prepareStatement("SELECT ROWNUM, COLUMN_VALUE FROM TABLE( CAST(:1 AS " + paramArrayDescriptor.getName() + ") )")).preparedStatement;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 111 */     oraclePreparedStatement.setArray(1, (Array)aRRAY);
/* 112 */     oraclePreparedStatement.executeQuery();
/*     */     
/* 114 */     this.statement = oraclePreparedStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean next() throws SQLException {
/* 123 */     synchronized (this.connection) {
/*     */ 
/*     */       
/* 126 */       if (this.currentIndex < this.beginIndex) {
/*     */         
/* 128 */         while (this.currentIndex < this.beginIndex) {
/*     */           
/* 130 */           this.currentIndex++;
/*     */           
/* 132 */           if (!super.next()) {
/* 133 */             return false;
/*     */           }
/*     */         } 
/* 136 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 140 */       if (this.count == COUNT_UNLIMITED)
/*     */       {
/* 142 */         return super.next();
/*     */       }
/* 144 */       if (this.currentIndex < this.beginIndex + this.count - 1L) {
/*     */         
/* 146 */         this.currentIndex++;
/*     */         
/* 148 */         return super.next();
/*     */       } 
/*     */ 
/*     */       
/* 152 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(int paramInt) throws SQLException {
/* 162 */     synchronized (this.connection) {
/*     */ 
/*     */       
/* 165 */       return getObject(paramInt, this.map);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int findColumn(String paramString) throws SQLException {
/* 175 */     synchronized (this.connection) {
/*     */ 
/*     */       
/* 178 */       if (paramString.equalsIgnoreCase("index"))
/* 179 */         return 1; 
/* 180 */       if (paramString.equalsIgnoreCase("value")) {
/* 181 */         return 2;
/*     */       }
/*     */       
/* 184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
/* 185 */       sQLException.fillInStackTrace();
/* 186 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\ArrayLocatorResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */