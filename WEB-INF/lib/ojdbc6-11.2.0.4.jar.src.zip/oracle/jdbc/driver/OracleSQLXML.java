/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.Writer;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stax.StAXResult;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import oracle.sql.DatumWithConnection;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.xdb.XMLType;
/*     */ import oracle.xml.parser.v2.XMLDocument;
/*     */ import oracle.xml.parser.v2.XMLSAXSerializer;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OracleSQLXML
/*     */   extends DatumWithConnection
/*     */   implements SQLXML, Opaqueable
/*     */ {
/*     */   private XMLType xdb;
/*     */   private boolean isReadable = false;
/*     */   private boolean isWriteable = false;
/*  93 */   private DOMResult domResult = null;
/*  94 */   private XMLSAXSerializer serializer = null;
/*  95 */   private ByteArrayOutputStream oStream = null;
/*     */   static final int INITIAL_BUFFER_SIZE = 16384;
/*     */   
/*     */   OracleSQLXML(Connection paramConnection) throws SQLException {
/*  99 */     setPhysicalConnectionOf(paramConnection);
/* 100 */     this.isReadable = false;
/* 101 */     this.isWriteable = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   OracleSQLXML(Connection paramConnection, OPAQUE paramOPAQUE) throws SQLException {
/* 107 */     setPhysicalConnectionOf(paramConnection);
/* 108 */     this.isReadable = true;
/* 109 */     this.isWriteable = false;
/* 110 */     if (paramOPAQUE instanceof XMLType) {
/* 111 */       this.xdb = (XMLType)paramOPAQUE;
/*     */     } else {
/* 113 */       this.xdb = new XMLType(paramOPAQUE.getDescriptor(), (Connection)getInternalConnection(), paramOPAQUE.getBytesValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   OracleSQLXML(OpaqueDescriptor paramOpaqueDescriptor, Connection paramConnection, byte[] paramArrayOfbyte) throws SQLException {
/* 118 */     this(paramConnection, new OPAQUE(paramOpaqueDescriptor, paramArrayOfbyte, paramConnection));
/*     */   }
/*     */ 
/*     */   
/*     */   OracleSQLXML(Connection paramConnection, InputStream paramInputStream) throws SQLException {
/* 123 */     setPhysicalConnectionOf(paramConnection);
/* 124 */     this.isReadable = true;
/* 125 */     this.isWriteable = false;
/* 126 */     this.xdb = new XMLType((Connection)getInternalConnection(), paramInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   OracleSQLXML(Connection paramConnection, XMLType paramXMLType) throws SQLException {
/* 132 */     setPhysicalConnectionOf(paramConnection);
/* 133 */     this.isReadable = true;
/* 134 */     this.isWriteable = false;
/* 135 */     this.xdb = paramXMLType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OPAQUE toOpaque() throws SQLException {
/* 142 */     return (OPAQUE)getXMLTypeInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XMLType getXMLTypeInternal() throws SQLException {
/* 148 */     if (this.isWriteable) {
/* 149 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 260);
/* 150 */       sQLException.fillInStackTrace();
/* 151 */       throw sQLException;
/*     */     } 
/* 153 */     if (this.serializer != null) {
/*     */       try {
/* 155 */         this.serializer.flush();
/*     */       }
/* 157 */       catch (IOException iOException) {
/*     */         
/* 159 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 160 */         sQLException.fillInStackTrace();
/* 161 */         throw sQLException;
/*     */       }
/*     */       finally {
/*     */         
/* 165 */         this.serializer = null;
/*     */       } 
/*     */     }
/* 168 */     if (this.oStream != null) {
/*     */       try {
/* 170 */         this.oStream.close();
/*     */       }
/* 172 */       catch (IOException iOException) {
/*     */         
/* 174 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 175 */         sQLException.fillInStackTrace();
/* 176 */         throw sQLException;
/*     */       } 
/*     */       
/* 179 */       this.xdb = XMLType.createXML((Connection)getInternalConnection(), new ByteArrayInputStream(this.oStream.toByteArray()));
/* 180 */       this.oStream = null;
/*     */     }
/* 182 */     else if (this.domResult != null) {
/* 183 */       XMLDocument xMLDocument; Node node = this.domResult.getNode();
/* 184 */       Document document = null;
/* 185 */       if (node instanceof Document) { document = (Document)node; }
/*     */       else
/* 187 */       { xMLDocument = new XMLDocument();
/* 188 */         node = xMLDocument.importNode(node, true);
/* 189 */         xMLDocument.insertBefore(node, null); }
/*     */       
/* 191 */       this.xdb = XMLType.createXML((Connection)getInternalConnection(), (Document)xMLDocument);
/* 192 */       this.domResult = null;
/*     */     } 
/* 194 */     if (this.xdb == null) {
/*     */       
/* 196 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 260);
/* 197 */       sQLException.fillInStackTrace();
/* 198 */       throw sQLException;
/*     */     } 
/* 200 */     return this.xdb;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConvertibleTo(Class paramClass) {
/* 212 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object toJdbc() throws SQLException {
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object makeJdbcArray(int paramInt) {
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void free() throws SQLException {
/* 232 */     this.isReadable = false;
/* 233 */     this.isWriteable = false;
/* 234 */     this.oStream = null;
/* 235 */     this.domResult = null;
/* 236 */     if (this.xdb != null) this.xdb.close(); 
/* 237 */     this.xdb = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getInputStream() throws SQLException {
/* 244 */     return new ByteArrayInputStream(this.xdb.getStringVal().getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/* 250 */     if (!this.isReadable) {
/* 251 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
/* 252 */       sQLException.fillInStackTrace();
/* 253 */       throw sQLException;
/*     */     } 
/* 255 */     this.isReadable = false;
/* 256 */     return getInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/* 262 */     if (!this.isReadable) {
/* 263 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
/* 264 */       sQLException.fillInStackTrace();
/* 265 */       throw sQLException;
/*     */     } 
/* 267 */     this.isReadable = false;
/* 268 */     return new StringReader(this.xdb.getStringVal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends javax.xml.transform.Source> T getSource(Class<T> paramClass) throws SQLException {
/* 275 */     if (!this.isReadable) {
/* 276 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
/* 277 */       sQLException1.fillInStackTrace();
/* 278 */       throw sQLException1;
/*     */     } 
/* 280 */     this.isReadable = false;
/* 281 */     if (paramClass == DOMSource.class) {
/* 282 */       Document document = this.xdb.getDocument();
/* 283 */       return (T)new DOMSource(document);
/*     */     } 
/* 285 */     if (paramClass == SAXSource.class) {
/* 286 */       InputSource inputSource = new InputSource(getInputStream());
/* 287 */       return (T)new SAXSource(inputSource);
/*     */     } 
/* 289 */     if (paramClass == StAXSource.class) {
/*     */       try {
/* 291 */         XMLInputFactory xMLInputFactory = XMLInputFactory.newInstance();
/* 292 */         XMLStreamReader xMLStreamReader = xMLInputFactory.createXMLStreamReader(getInputStream());
/* 293 */         return (T)new StAXSource(xMLStreamReader);
/*     */       }
/* 295 */       catch (XMLStreamException xMLStreamException) {
/*     */         
/* 297 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), xMLStreamException);
/* 298 */         sQLException1.fillInStackTrace();
/* 299 */         throw sQLException1;
/*     */       } 
/*     */     }
/*     */     
/* 303 */     if (paramClass == StreamSource.class) {
/* 304 */       return (T)new StreamSource(getInputStream());
/*     */     }
/*     */     
/* 307 */     this.isReadable = true;
/*     */     
/* 309 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 264);
/* 310 */     sQLException.fillInStackTrace();
/* 311 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() throws SQLException {
/* 319 */     if (!this.isReadable) {
/* 320 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
/* 321 */       sQLException.fillInStackTrace();
/* 322 */       throw sQLException;
/*     */     } 
/* 324 */     this.isReadable = false;
/* 325 */     return this.xdb.getStringVal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OutputStream getOutputStream() throws SQLException {
/* 333 */     if (this.oStream != null) throw new SQLException("Internal Error"); 
/* 334 */     this.oStream = new ByteArrayOutputStream(16384);
/* 335 */     return this.oStream;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream() throws SQLException {
/* 341 */     if (!this.isWriteable) {
/* 342 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
/* 343 */       sQLException.fillInStackTrace();
/* 344 */       throw sQLException;
/*     */     } 
/* 346 */     this.isWriteable = false;
/* 347 */     return getOutputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer setCharacterStream() throws SQLException {
/* 353 */     if (!this.isWriteable) {
/* 354 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
/* 355 */       sQLException.fillInStackTrace();
/* 356 */       throw sQLException;
/*     */     } 
/* 358 */     this.isWriteable = false;
/* 359 */     return new OutputStreamWriter(getOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends javax.xml.transform.Result> T setResult(Class<T> paramClass) throws SQLException {
/* 366 */     if (!this.isWriteable) {
/* 367 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
/* 368 */       sQLException1.fillInStackTrace();
/* 369 */       throw sQLException1;
/*     */     } 
/* 371 */     this.isWriteable = false;
/* 372 */     if (paramClass == DOMResult.class) {
/* 373 */       this.domResult = new DOMResult();
/* 374 */       return (T)this.domResult;
/*     */     } 
/* 376 */     if (paramClass == SAXResult.class) {
/* 377 */       this.serializer = new XMLSAXSerializer(getOutputStream());
/* 378 */       return (T)new SAXResult((ContentHandler)this.serializer);
/*     */     } 
/* 380 */     if (paramClass == StAXResult.class) {
/*     */       try {
/* 382 */         XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
/* 383 */         return (T)new StAXResult(xMLOutputFactory.createXMLStreamWriter(getOutputStream()));
/*     */       }
/* 385 */       catch (XMLStreamException xMLStreamException) {
/*     */         
/* 387 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), xMLStreamException);
/* 388 */         sQLException1.fillInStackTrace();
/* 389 */         throw sQLException1;
/*     */       } 
/*     */     }
/*     */     
/* 393 */     if (paramClass == StreamResult.class) {
/* 394 */       return (T)new StreamResult(getOutputStream());
/*     */     }
/*     */     
/* 397 */     this.isWriteable = true;
/*     */     
/* 399 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 263);
/* 400 */     sQLException.fillInStackTrace();
/* 401 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setString(String paramString) throws SQLException {
/* 409 */     if (!this.isWriteable) {
/* 410 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
/* 411 */       sQLException.fillInStackTrace();
/* 412 */       throw sQLException;
/*     */     } 
/* 414 */     this.isWriteable = false;
/* 415 */     this.xdb = new XMLType((Connection)getInternalConnection(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 420 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\driver\OracleSQLXML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */