/*    */ package oracle.jdbc.dcn;
/*    */ 
/*    */ import oracle.sql.ROWID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface RowChangeDescription
/*    */ {
/*    */   RowOperation getRowOperation();
/*    */   
/*    */   ROWID getRowid();
/*    */   
/*    */   public enum RowOperation
/*    */   {
/* 49 */     INSERT(TableChangeDescription.TableOperation.INSERT.getCode()),
/*    */ 
/*    */ 
/*    */     
/* 53 */     UPDATE(TableChangeDescription.TableOperation.UPDATE.getCode()),
/*    */ 
/*    */ 
/*    */     
/* 57 */     DELETE(TableChangeDescription.TableOperation.DELETE.getCode());
/*    */     private final int code;
/*    */     
/*    */     RowOperation(int param1Int1) {
/* 61 */       this.code = param1Int1;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final int getCode() {
/* 68 */       return this.code;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static final RowOperation getRowOperation(int param1Int) {
/* 75 */       if (param1Int == INSERT.getCode())
/* 76 */         return INSERT; 
/* 77 */       if (param1Int == UPDATE.getCode()) {
/* 78 */         return UPDATE;
/*    */       }
/* 80 */       return DELETE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\dcn\RowChangeDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */