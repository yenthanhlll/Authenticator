package oracle.jdbc.aq;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

public interface AQNotificationRegistration extends NotificationRegistration {
  void addListener(AQNotificationListener paramAQNotificationListener) throws SQLException;
  
  void addListener(AQNotificationListener paramAQNotificationListener, Executor paramExecutor) throws SQLException;
  
  void removeListener(AQNotificationListener paramAQNotificationListener) throws SQLException;
  
  String getQueueName();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\ojdbc6-11.2.0.4.jar!\oracle\jdbc\aq\AQNotificationRegistration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */