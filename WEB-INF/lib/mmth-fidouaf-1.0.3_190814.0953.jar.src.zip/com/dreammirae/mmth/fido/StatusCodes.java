/*     */ package com.dreammirae.mmth.fido;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum StatusCodes
/*     */ {
/*  27 */   CODE_1200(Long.valueOf(1200L), "OK"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   CODE_1202(Long.valueOf(1202L), "Accepted"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   CODE_1203(Long.valueOf(1203L), "Not Found Auth Type"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   CODE_1204(Long.valueOf(1204L), "Auth Data Validation Fail"),
/*     */ 
/*     */ 
/*     */   
/*  46 */   CODE_1400(Long.valueOf(1400L), "Bad Request"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   CODE_1401(Long.valueOf(1401L), "User Unauthorized"),
/*     */ 
/*     */ 
/*     */   
/*  55 */   CODE_1403(Long.valueOf(1403L), "Forbidden"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   CODE_1404(Long.valueOf(1404L), "Not Found URL"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   CODE_1408(Long.valueOf(1408L), "Request Timeout"),
/*     */ 
/*     */ 
/*     */   
/*  69 */   CODE_1480(Long.valueOf(1480L), "Unknown AAID"),
/*     */ 
/*     */ 
/*     */   
/*  73 */   CODE_1481(Long.valueOf(1481L), "Unknown KeyID"),
/*     */ 
/*     */ 
/*     */   
/*  77 */   CODE_1482(Long.valueOf(1481L), "Unknown TokenID"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   CODE_1489(Long.valueOf(1489L), "Untrusted facet ID"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   CODE_1490(Long.valueOf(1490L), "Channel Binding Refused"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   CODE_1491(Long.valueOf(1491L), "Request Invalid"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   CODE_1492(Long.valueOf(1492L), "Unacceptable Authenticator"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   CODE_1493(Long.valueOf(1493L), "Revoked Authenticator"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   CODE_1494(Long.valueOf(1494L), "Unacceptable Key"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   CODE_1495(Long.valueOf(1495L), "Unacceptable Algorithm"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   CODE_1496(Long.valueOf(1496L), "Unacceptable Attestation"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   CODE_1497(Long.valueOf(1497L), "Unacceptable Client Capabilities"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   CODE_1498(Long.valueOf(1498L), "Unacceptable Content"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   CODE_1500(Long.valueOf(1500L), "Internal Server Error"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   CODE_1001(Long.valueOf(1001L), "Device Unauthorized"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   CODE_1002(Long.valueOf(1002L), "Device APP Unauthorized"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   CODE_1003(Long.valueOf(1003L), "Exist Already"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   CODE_1004(Long.valueOf(1004L), "Disallowed multiple device"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   CODE_1005(Long.valueOf(1005L), "Disallowed multiple app agent"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   CODE_1006(Long.valueOf(1006L), "No Auth method type"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   CODE_1008(Long.valueOf(1008L), "Unknown app agent"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   CODE_1009(Long.valueOf(1009L), "No authentication request"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   CODE_1010(Long.valueOf(1010L), "Forbidden device"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   CODE_1011(Long.valueOf(1011L), "There has no OTP key to assign"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   CODE_1012(Long.valueOf(1012L), "There has no server challenge for this request."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   CODE_1013(Long.valueOf(1013L), "User's authentication has not completed."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   CODE_1014(Long.valueOf(1014L), "User's authentication result is invalid"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   CODE_1015(Long.valueOf(1015L), "The request invalid."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   CODE_1016(Long.valueOf(1016L), "LOST"),
/*     */ 
/*     */ 
/*     */   
/* 223 */   CODE_1017(Long.valueOf(1017L), "LOST_NOT_AVAILABLE"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   CODE_1101(Long.valueOf(1101L), "Unacceptable issue code request"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 239 */   CODE_1102(Long.valueOf(1102L), "Invalid issue code"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   CODE_1103(Long.valueOf(1103L), "Disacrd issue code"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   CODE_1301(Long.valueOf(1301L), "There has no fcm token"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   CODE_1302(Long.valueOf(1302L), "There has no fcm authorization key"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   CODE_6000(Long.valueOf(6000L), "Auth failed"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   CODE_6006(Long.valueOf(6006L), "OTP-SN NOT FOUND"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   CODE_6007(Long.valueOf(6007L), "Parameter error"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 275 */   CODE_6013(Long.valueOf(6013L), "FIDO Authentication has not been completed."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 280 */   CODE_6014(Long.valueOf(6014L), "Expired OTP verification request."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   CODE_6015(Long.valueOf(6015L), "Invalid request API for OTP verification."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   CODE_6016(Long.valueOf(6016L), "Invalid transaction information."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   CODE_6017(Long.valueOf(6017L), "Authentication challenge value has been expired."),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   CODE_6019(Long.valueOf(6019L), "Authentication error count exceeded"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 305 */   CODE_6023(Long.valueOf(6023L), "NOT_ISSUED"),
/*     */ 
/*     */ 
/*     */   
/* 309 */   CODE_6024(Long.valueOf(6024L), "SUSPEND"),
/*     */ 
/*     */ 
/*     */   
/* 313 */   CODE_6025(Long.valueOf(6025L), "DISUSED"),
/*     */ 
/*     */ 
/*     */   
/* 317 */   CODE_6026(Long.valueOf(6026L), "NOT_AVAILABLE");
/*     */   
/*     */   private final Long id;
/*     */   private final String message;
/*     */   
/*     */   StatusCodes(Long id, String message) {
/* 323 */     this.id = id;
/* 324 */     this.message = message;
/*     */   }
/*     */   
/*     */   public Long getId() {
/* 328 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 332 */     return this.message;
/*     */   }
/*     */   
/*     */   public static StatusCodes getUAFStatusCodes(long statusCode) {
/* 336 */     for (StatusCodes comp : values()) {
/* 337 */       if (comp.id.longValue() == statusCode) {
/* 338 */         return comp;
/*     */       }
/*     */     } 
/* 341 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\StatusCodes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */