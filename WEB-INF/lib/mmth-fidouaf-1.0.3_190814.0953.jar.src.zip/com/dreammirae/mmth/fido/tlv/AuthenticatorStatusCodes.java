/*    */ package com.dreammirae.mmth.fido.tlv;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AuthenticatorStatusCodes
/*    */ {
/* 17 */   UAF_CMD_STATUS_OK(0),
/*    */ 
/*    */   
/* 20 */   UAF_CMD_STATUS_ERR_UNKNOWN(1),
/*    */ 
/*    */   
/* 23 */   UAF_CMD_STATUS_ACCESS_DENIED(2),
/*    */ 
/*    */   
/* 26 */   UAF_CMD_STATUS_USER_NOT_ENROLLED(3),
/*    */ 
/*    */   
/* 29 */   UAF_CMD_STATUS_CANNOT_RENDER_TRANSACTION_CONTENT(4),
/*    */ 
/*    */   
/* 32 */   UAF_CMD_STATUS_USER_CANCELLED(5),
/*    */ 
/*    */   
/* 35 */   UAF_CMD_STATUS_CMD_NOT_SUPPORTED(6),
/*    */ 
/*    */   
/* 38 */   UAF_CMD_STATUS_ATTESTATION_NOT_SUPPORTED(7);
/*    */ 
/*    */   
/*    */   private final int id;
/*    */ 
/*    */ 
/*    */   
/*    */   AuthenticatorStatusCodes(int id) {
/* 46 */     this.id = id;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 50 */     return this.id;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\AuthenticatorStatusCodes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */