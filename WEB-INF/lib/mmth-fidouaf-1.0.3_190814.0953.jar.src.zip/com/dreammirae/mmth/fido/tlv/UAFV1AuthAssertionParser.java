/*     */ package com.dreammirae.mmth.fido.tlv;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalAlgorithmAndKeyException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalTLVException;
/*     */ import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.AuthAssertionLocator;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.misc.SysEnvCommon;
/*     */ import com.dreammirae.mmth.util.io.EndianUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UAFV1AuthAssertionParser
/*     */   extends UAFV1AssertionParser<AuthAssertionLocator>
/*     */ {
/*     */   private static final int VAL_LEN_TAG_COUNTERS = 4;
/*     */   private static final int VAL_LEN_TAG_ASSERTION_INFO = 5;
/*     */   private static final int IDX_ASSERTION_INFO_AUTENTICATOR = 0;
/*     */   private static final int IDX_ASSERTION_INFO_AUTHENTICATION_MODE = 2;
/*     */   private static final int IDX_ASSERTION_INFO_SIGNATURE_ALG_AND_ENCODEING = 3;
/*     */   private static final int TAG_UAFV1_AUTH_ASSERTION = 1;
/*     */   private static final int TAG_UAFV1_SIGNED_DATA = 2;
/*     */   private static final int TAG_AAID = 4;
/*     */   private static final int TAG_ASSERTION_INFO = 8;
/*     */   private static final int TAG_AUTHENTICATOR_NONCE = 16;
/*     */   private static final int TAG_FINAL_CHALLENGE = 32;
/*     */   private static final int TAG_TRANSACTION_CONTENT_HASH = 64;
/*     */   private static final int TAG_KEYID = 128;
/*     */   private static final int TAG_COUNTERS = 256;
/*     */   private static final int TAG_SIGNATURE = 512;
/*     */   private static final int TAG_EXTENSION = 1024;
/*     */   private static final int TAG_EXTENSION_NON_CRITICAL = 2048;
/*     */   private static final int TAG_EXTENSION_ID = 4096;
/*     */   private static final int TAG_EXTENSION_DATA = 8192;
/*     */   private static final int REQUIRED_TAGS = 1023;
/*  51 */   private int tagCodeValiation = 0;
/*     */   
/*     */   public UAFV1AuthAssertionParser() {
/*  54 */     super(new AuthAssertionLocator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parsePayloadImp(byte[] payload) throws IllegalTLVException {
/*  61 */     if ((this.tagCodeValiation & 0x3FF) != 1023) {
/*  62 */       throw new IllegalTLVException("TagCode[in SignAssertion] is not enough. please check the payload. " + 
/*  63 */           HexUtils.toHexString(payload));
/*     */     }
/*     */     
/*  66 */     if ((this.tagCodeValiation & 0x400) == 1024 || (this.tagCodeValiation & 0x800) == 2048) {
/*     */ 
/*     */       
/*  69 */       if ((this.tagCodeValiation & 0x1000) != 4096) {
/*  70 */         throw new IllegalTLVException("TagCode[TAG_EXTENSION/TAG_EXTENSION_NON_CRITICAL] must be included TAG_EXTENSION_ID tag.");
/*     */       }
/*     */ 
/*     */       
/*  74 */       if ((this.tagCodeValiation & 0x2000) != 8192) {
/*  75 */         throw new IllegalTLVException("TagCode[TAG_EXTENSION/TAG_EXTENSION_NON_CRITICAL] must be included TAG_EXTENSION_DATA tag.");
/*     */       }
/*     */ 
/*     */       
/*  79 */       this.locator.setExtension(true);
/*  80 */       this.locator.setNonCriticalExtension(((this.tagCodeValiation & 0x800) == 2048));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  85 */     int offset = 4;
/*     */     
/*  87 */     TagCodes signedCode = getTagCodes(payload, offset);
/*     */     
/*  89 */     if (!TagCodes.TAG_UAFV1_SIGNED_DATA.equals(signedCode)) {
/*  90 */       throw new IllegalTLVException("Assertion[tagCode] : Exp Code=" + TagCodes.TAG_UAFV1_SIGNED_DATA + ", but code is " + signedCode);
/*     */     }
/*     */ 
/*     */     
/*  94 */     int signedLen = getValueLength(payload, offset + 2);
/*     */     
/*  96 */     int totSignLen = signedLen + 2 + 2;
/*  97 */     byte[] tgSignData = new byte[totSignLen];
/*  98 */     System.arraycopy(payload, offset, tgSignData, 0, totSignLen);
/*     */     
/* 100 */     this.locator.setAssertionData(tgSignData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLocatorValue(TagCodes code, byte[] data) throws IllegalTLVException {
/* 106 */     if (TagCodes.TAG_SIGNATURE.equals(code)) {
/* 107 */       this.locator.setSignature(data);
/* 108 */     } else if (TagCodes.TAG_KEYID.equals(code)) {
/* 109 */       this.locator.setKeyId(Base64Utils.encodeUrl(data));
/* 110 */     } else if (TagCodes.TAG_FINAL_CHALLENGE.equals(code)) {
/* 111 */       this.locator.setFcParamHash(data);
/* 112 */     } else if (TagCodes.TAG_AAID.equals(code)) {
/* 113 */       this.locator.setAAID(SysEnvCommon.toUtf8(data));
/* 114 */     } else if (TagCodes.TAG_COUNTERS.equals(code)) {
/* 115 */       if (data.length != 4) {
/* 116 */         throw new IllegalTLVException("TagCode[TAG_COUNTERS in SignAssertion] value length must be 4");
/*     */       }
/*     */ 
/*     */       
/* 120 */       this.locator.setSignCounter(EndianUtils.toUInt32_ByLittleEndian(data, 0));
/* 121 */     } else if (TagCodes.TAG_ASSERTION_INFO.equals(code)) {
/*     */       
/* 123 */       if (data.length != 5) {
/* 124 */         throw new IllegalTLVException("TagCode[TAG_ASSERTION_INFO in SignAssertion] value length must be 5");
/*     */       }
/*     */ 
/*     */       
/* 128 */       this.locator.setAuthenticatorVersion(EndianUtils.toUInt16_ByLittleEndian(data, 0));
/* 129 */       this.locator.setAuthenticationMode(
/* 130 */           AuthenticationMode.getAuthenticationMode(EndianUtils.toUInt8(data, 2)));
/*     */       
/* 132 */       int algCode = EndianUtils.toUInt16_ByLittleEndian(data, 3);
/*     */       
/*     */       try {
/* 135 */         this.locator.setAuthenticationAlgorithms(AuthenticationAlgorithms.get(algCode));
/* 136 */       } catch (IllegalAlgorithmAndKeyException e) {
/* 137 */         throw new IllegalTLVException(e.getStatusCode(), e.getMessage());
/*     */       }
/*     */     
/* 140 */     } else if (TagCodes.TAG_AUTHENTICATOR_NONCE.equals(code)) {
/* 141 */       this.locator.setAuthenticatorNonce(data);
/* 142 */     } else if (TagCodes.TAG_TRANSACTION_CONTENT_HASH.equals(code)) {
/* 143 */       if (data.length != 0)
/* 144 */         this.locator.setTransactionContentHash(data); 
/* 145 */     } else if (TagCodes.TAG_EXTENSION_ID.equals(code)) {
/* 146 */       this.locator.setExtensionId(SysEnvCommon.toUtf8(data));
/* 147 */     } else if (TagCodes.TAG_EXTENSION_DATA.equals(code)) {
/* 148 */       this.locator.setExtensionData(data);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTagCode(TagCodes code) throws IllegalTLVException {
/* 156 */     if (TagCodes.TAG_UAFV1_AUTH_ASSERTION.equals(code)) {
/* 157 */       this.tagCodeValiation |= 0x1;
/* 158 */     } else if (TagCodes.TAG_UAFV1_SIGNED_DATA.equals(code)) {
/* 159 */       this.tagCodeValiation |= 0x2;
/* 160 */     } else if (TagCodes.TAG_AAID.equals(code)) {
/* 161 */       this.tagCodeValiation |= 0x4;
/* 162 */     } else if (TagCodes.TAG_ASSERTION_INFO.equals(code)) {
/* 163 */       this.tagCodeValiation |= 0x8;
/* 164 */     } else if (TagCodes.TAG_AUTHENTICATOR_NONCE.equals(code)) {
/* 165 */       this.tagCodeValiation |= 0x10;
/* 166 */     } else if (TagCodes.TAG_FINAL_CHALLENGE.equals(code)) {
/* 167 */       this.tagCodeValiation |= 0x20;
/* 168 */     } else if (TagCodes.TAG_TRANSACTION_CONTENT_HASH.equals(code)) {
/* 169 */       this.tagCodeValiation |= 0x40;
/* 170 */     } else if (TagCodes.TAG_KEYID.equals(code)) {
/* 171 */       this.tagCodeValiation |= 0x80;
/* 172 */     } else if (TagCodes.TAG_COUNTERS.equals(code)) {
/* 173 */       this.tagCodeValiation |= 0x100;
/* 174 */     } else if (TagCodes.TAG_SIGNATURE.equals(code)) {
/* 175 */       this.tagCodeValiation |= 0x200;
/* 176 */     } else if (TagCodes.TAG_EXTENSION.equals(code)) {
/* 177 */       this.tagCodeValiation |= 0x400;
/* 178 */     } else if (TagCodes.TAG_EXTENSION_NON_CRITICAL.equals(code)) {
/* 179 */       this.tagCodeValiation |= 0x800;
/* 180 */     } else if (TagCodes.TAG_EXTENSION_ID.equals(code)) {
/* 181 */       this.tagCodeValiation |= 0x1000;
/* 182 */     } else if (TagCodes.TAG_EXTENSION_DATA.equals(code)) {
/* 183 */       this.tagCodeValiation |= 0x2000;
/*     */     } else {
/* 185 */       throw new IllegalTLVException("TagCode[in signAssertion] is invalid. code=" + code);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws IllegalTLVException {
/* 190 */     String str = "Aj72AAQ-rgALLgkARkZGRiM1MjAxDi4FAAEAAgEADy4gALr09Ekhqxwoo1w-3lhWyIccim2Mc0t5Gb1Y1Zn2wom_Ci4gABotpjYQkOiowJubt9iT2CTc9eNdlHEknkmSuQ5YcWRUEC4gAH0aVBJ7IiUC9bebX7CAMGEVKkT5KzfiPGUnuvZl1NqbCS4gADmCL-07oUWhM1XUwJOsrTMkIk8NmKhl2DKWb3VeP7tNDS4EAAAAABAGLkAAFM4X6gfUDkERpsDImtpi1Sm2lrwnr3zGiARZfP9sb6hCJJGw7hBRlJWY0NnIaLdRL7VoUCfEKCsZyTy0Eu1ljg";
/*     */     
/* 192 */     byte[] payload = Base64Utils.decodeRaw(str);
/*     */     
/* 194 */     System.out.println(str.length());
/* 195 */     System.out.println(payload.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     UAFV1AuthAssertionParser parser = new UAFV1AuthAssertionParser();
/* 211 */     AuthAssertionLocator loc = parser.parsePayload(payload);
/*     */     
/* 213 */     System.out.println(loc);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\UAFV1AuthAssertionParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */