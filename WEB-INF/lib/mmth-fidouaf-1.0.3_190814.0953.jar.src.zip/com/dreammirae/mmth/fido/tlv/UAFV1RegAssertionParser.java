/*     */ package com.dreammirae.mmth.fido.tlv;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalAlgorithmAndKeyException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalTLVException;
/*     */ import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
/*     */ import com.dreammirae.mmth.fido.registry.PublicKeyRepresentationFormats;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.RegAssertionLocator;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.misc.SysEnvCommon;
/*     */ import com.dreammirae.mmth.util.io.EndianUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UAFV1RegAssertionParser
/*     */   extends UAFV1AssertionParser<RegAssertionLocator>
/*     */ {
/*     */   private static final int VAL_LEN_TAG_COUNTERS = 8;
/*     */   private static final int VAL_LEN_TAG_ASSERTION_INFO = 7;
/*     */   private static final int IDX_ASSERTION_INFO_AUTENTICATOR = 0;
/*     */   private static final int IDX_ASSERTION_INFO_AUTHENTICATION_MODE = 2;
/*     */   private static final int IDX_ASSERTION_INFO_SIGNATURE_ALG_AND_ENCODEING = 3;
/*     */   private static final int IDX_ASSERTION_INFO_PUBLIC_KEY_ALG_AND_ENCODEING = 5;
/*     */   private static final int TAG_UAFV1_REG_ASSERTION = 1;
/*     */   private static final int TAG_UAFV1_KRD = 2;
/*     */   private static final int TAG_AAID = 4;
/*     */   private static final int TAG_ASSERTION_INFO = 8;
/*     */   private static final int TAG_FINAL_CHALLENGE = 16;
/*     */   private static final int TAG_KEYID = 32;
/*     */   private static final int TAG_COUNTERS = 64;
/*     */   private static final int TAG_PUB_KEY = 128;
/*     */   private static final int TAG_SIGNATURE = 256;
/*     */   private static final int TAG_ATTESTATION_BASIC_FULL = 512;
/*     */   private static final int TAG_ATTESTATION_CERT = 1024;
/*     */   private static final int TAG_ATTESTATION_BASIC_SURROGATE = 2048;
/*     */   private static final int TAG_EXTENSION = 4096;
/*     */   private static final int TAG_EXTENSION_NON_CRITICAL = 8192;
/*     */   private static final int TAG_EXTENSION_ID = 16384;
/*     */   private static final int TAG_EXTENSION_DATA = 32768;
/*     */   private static final int REQUIRED_TAGS = 511;
/*  55 */   private int tagCodeValiation = 0;
/*     */   
/*     */   public UAFV1RegAssertionParser() {
/*  58 */     super(new RegAssertionLocator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parsePayloadImp(byte[] payload) throws IllegalTLVException {
/*  65 */     if ((this.tagCodeValiation & 0x1FF) != 511) {
/*  66 */       throw new IllegalTLVException("TagCode[in RegAssertion] is not enough. please check the payload. " + 
/*  67 */           HexUtils.toHexString(payload));
/*     */     }
/*     */     
/*  70 */     if ((this.tagCodeValiation & 0x200) == 512) {
/*  71 */       if ((this.tagCodeValiation & 0x400) != 1024) {
/*  72 */         throw new IllegalTLVException("TagCode[TAG_ATTESTATION_BASIC_FULL] must be included TAG_ATTESTATION_CERT tag.");
/*     */       }
/*     */       
/*  75 */       this.locator.setAttestationBasicFull(true);
/*  76 */     } else if ((this.tagCodeValiation & 0x800) == 2048) {
/*  77 */       this.locator.setAttestationBasicSurrogate(true);
/*     */     } else {
/*  79 */       throw new IllegalTLVException("TagCode[in RegAssertion TLV] must be included one of TAG_ATTESTATION_BASIC_FULL and TAG_ATTESTATION_BASIC_SURROGATE.");
/*     */     } 
/*     */ 
/*     */     
/*  83 */     if ((this.tagCodeValiation & 0x1000) == 4096 || (this.tagCodeValiation & 0x2000) == 8192) {
/*     */ 
/*     */       
/*  86 */       if ((this.tagCodeValiation & 0x4000) != 16384) {
/*  87 */         throw new IllegalTLVException("TagCode[TAG_EXTENSION/TAG_EXTENSION_NON_CRITICAL] must be included TAG_EXTENSION_ID tag.");
/*     */       }
/*     */ 
/*     */       
/*  91 */       if ((this.tagCodeValiation & 0x8000) != 32768) {
/*  92 */         throw new IllegalTLVException("TagCode[TAG_EXTENSION/TAG_EXTENSION_NON_CRITICAL] must be included TAG_EXTENSION_DATA tag.");
/*     */       }
/*     */ 
/*     */       
/*  96 */       this.locator.setExtension(true);
/*  97 */       this.locator.setNonCriticalExtension(((this.tagCodeValiation & 0x2000) == 8192));
/*     */     } 
/*     */ 
/*     */     
/* 101 */     int offset = 4;
/*     */     
/* 103 */     TagCodes krd = getTagCodes(payload, offset);
/*     */     
/* 105 */     if (!TagCodes.TAG_UAFV1_KRD.equals(krd)) {
/* 106 */       throw new IllegalTLVException("Assertion[tagCode] : Exp Code=" + TagCodes.TAG_UAFV1_KRD + ", but code is " + krd);
/*     */     }
/*     */ 
/*     */     
/* 110 */     int krdLen = getValueLength(payload, offset + 2);
/*     */     
/* 112 */     int totSignLen = krdLen + 2 + 2;
/* 113 */     byte[] tgSignData = new byte[totSignLen];
/* 114 */     System.arraycopy(payload, offset, tgSignData, 0, totSignLen);
/*     */     
/* 116 */     this.locator.setAssertionData(tgSignData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTagCode(TagCodes code) throws IllegalTLVException {
/* 123 */     if (TagCodes.TAG_UAFV1_REG_ASSERTION.equals(code)) {
/* 124 */       this.tagCodeValiation |= 0x1;
/* 125 */     } else if (TagCodes.TAG_UAFV1_KRD.equals(code)) {
/* 126 */       this.tagCodeValiation |= 0x2;
/* 127 */     } else if (TagCodes.TAG_AAID.equals(code)) {
/* 128 */       this.tagCodeValiation |= 0x4;
/* 129 */     } else if (TagCodes.TAG_ASSERTION_INFO.equals(code)) {
/* 130 */       this.tagCodeValiation |= 0x8;
/* 131 */     } else if (TagCodes.TAG_FINAL_CHALLENGE.equals(code)) {
/* 132 */       this.tagCodeValiation |= 0x10;
/* 133 */     } else if (TagCodes.TAG_KEYID.equals(code)) {
/* 134 */       this.tagCodeValiation |= 0x20;
/* 135 */     } else if (TagCodes.TAG_COUNTERS.equals(code)) {
/* 136 */       this.tagCodeValiation |= 0x40;
/* 137 */     } else if (TagCodes.TAG_PUB_KEY.equals(code)) {
/* 138 */       this.tagCodeValiation |= 0x80;
/* 139 */     } else if (TagCodes.TAG_SIGNATURE.equals(code)) {
/* 140 */       this.tagCodeValiation |= 0x100;
/* 141 */     } else if (TagCodes.TAG_ATTESTATION_BASIC_FULL.equals(code)) {
/* 142 */       this.tagCodeValiation |= 0x200;
/* 143 */     } else if (TagCodes.TAG_ATTESTATION_CERT.equals(code)) {
/* 144 */       this.tagCodeValiation |= 0x400;
/* 145 */     } else if (TagCodes.TAG_ATTESTATION_BASIC_SURROGATE.equals(code)) {
/* 146 */       this.tagCodeValiation |= 0x800;
/* 147 */     } else if (TagCodes.TAG_EXTENSION.equals(code)) {
/* 148 */       this.tagCodeValiation |= 0x1000;
/* 149 */     } else if (TagCodes.TAG_EXTENSION_NON_CRITICAL.equals(code)) {
/* 150 */       this.tagCodeValiation |= 0x2000;
/* 151 */     } else if (TagCodes.TAG_EXTENSION_ID.equals(code)) {
/* 152 */       this.tagCodeValiation |= 0x4000;
/* 153 */     } else if (TagCodes.TAG_EXTENSION_DATA.equals(code)) {
/* 154 */       this.tagCodeValiation |= 0x8000;
/*     */     } else {
/* 156 */       throw new IllegalTLVException("TagCode[in RegAssertion] is invalid. code=" + code);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLocatorValue(TagCodes code, byte[] data) throws IllegalTLVException {
/* 164 */     if (TagCodes.TAG_ATTESTATION_CERT.equals(code)) {
/* 165 */       this.locator.addAttestationCert(data);
/* 166 */     } else if (TagCodes.TAG_SIGNATURE.equals(code)) {
/* 167 */       this.locator.setSignature(data);
/* 168 */     } else if (TagCodes.TAG_KEYID.equals(code)) {
/* 169 */       this.locator.setKeyId(Base64Utils.encodeUrl(data));
/* 170 */     } else if (TagCodes.TAG_FINAL_CHALLENGE.equals(code)) {
/* 171 */       this.locator.setFcParamHash(data);
/* 172 */     } else if (TagCodes.TAG_AAID.equals(code)) {
/* 173 */       this.locator.setAAID(SysEnvCommon.toUtf8(data));
/* 174 */     } else if (TagCodes.TAG_PUB_KEY.equals(code)) {
/* 175 */       this.locator.setPublicKey(data);
/* 176 */     } else if (TagCodes.TAG_COUNTERS.equals(code)) {
/*     */       
/* 178 */       if (data.length != 8) {
/* 179 */         throw new IllegalTLVException("TagCode[TAG_COUNTERS in RegAssertion] value length must be 8");
/*     */       }
/*     */ 
/*     */       
/* 183 */       this.locator.setSignCounter(EndianUtils.toUInt32_ByLittleEndian(data, 0));
/* 184 */       this.locator.setRegCounter(EndianUtils.toUInt32_ByLittleEndian(data, 4));
/* 185 */     } else if (TagCodes.TAG_ASSERTION_INFO.equals(code)) {
/*     */       
/* 187 */       if (data.length != 7) {
/* 188 */         throw new IllegalTLVException("TagCode[TAG_ASSERTION_INFO in RegAssertion] value length must be 7");
/*     */       }
/*     */ 
/*     */       
/* 192 */       this.locator.setAuthenticatorVersion(EndianUtils.toUInt16_ByLittleEndian(data, 0));
/* 193 */       this.locator.setAuthenticationMode(
/* 194 */           AuthenticationMode.getAuthenticationMode(EndianUtils.toUInt8(data, 2)));
/*     */       
/* 196 */       int algCode = EndianUtils.toUInt16_ByLittleEndian(data, 3);
/*     */       
/* 198 */       int pubCode = EndianUtils.toUInt16_ByLittleEndian(data, 5);
/*     */       try {
/* 200 */         this.locator.setAuthenticationAlgorithms(AuthenticationAlgorithms.get(algCode));
/* 201 */         this.locator.setPublicKeyAlgAndEncoding(PublicKeyRepresentationFormats.get(pubCode));
/* 202 */       } catch (IllegalAlgorithmAndKeyException e) {
/* 203 */         throw new IllegalTLVException(e.getStatusCode(), e.getMessage());
/*     */       }
/*     */     
/* 206 */     } else if (TagCodes.TAG_EXTENSION_ID.equals(code)) {
/* 207 */       this.locator.setExtensionId(SysEnvCommon.toUtf8(data));
/* 208 */     } else if (TagCodes.TAG_EXTENSION_DATA.equals(code)) {
/* 209 */       this.locator.setExtensionData(data);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws IllegalTLVException {
/* 214 */     String assertion = "AT72BAM-cwELLgkAMDA0MyMwMDExDi4HAAEAAQQAAgEKLiAALIAg6Ksxznej7hkQfz4FzZK5J-TZD0SJov_cTl8Zh-UJLiAAVZ4ORw-oWUDFOKUPSWfQS2eOmFKJdgthOjys2XdEk1MNLggAAAAAAAMAAAAMLgMB3Tyva9te9fM-Y_rhD8GLwTTw8DnxdUZZVXNWCPOU8vtRBZk74ZM-bV1Rylzd4o2OJp9EMrJvL8OD2c5ExiGYVIKs5DxJXt7J5TaynmzFIgbZ-2LASxitXmdfvzD9LUH07NWU33Th_5rEY5Lbhpsn2e-DjCawiV3e6OfrxE2E5vnabVNlI9mqcKg7bnhPHHf8PzbEiMZ6xELkBca1Dh8A7CXPBQKbLPDLLttqUq-FWoJoTKy_qSBY2QRGkjKsT01lfPFaB6bGPm_nuPPeLiYRGo3g63ckZrNHJC4kcbGJBKbXO_DDVqtzaQA13Ae_qpK1pt_B3-X_U6tfhnH1HBD-RQEAAQc-ewMGLgQBBIIBAFGk2fdQdrNmQdVU_DFdbiIUzDOTXo9_ZSvhUyDziR_vdrb_1jYBDqA-Zt0AZ9X6c0kfAnYVCaKMYfOqIY8qxKsQi4PjSf8E4ZJHzbWzQWc2xNwySBA21zWKZqIwvkofntB4tQ_3NUriGQ0UE1Yv8dWjxNwF7rfF1wG2mPdYaH498lasEe_jb3iPNb1KqjRSQI5pUCr_eGGAK0cxlAEVd4XIemL4zOk9tWUZU_YvaxiE_Re7wHciLLVu7t4aPsnE_MLNepFqAvtQOj-xGRvDTR-_E0GwZ_XwlmcWrbfekw9ru1EVRup8U1dCJORjynVuIm0TdkkaWO9OWUd_I6ieObcFLm8CMIICazCCAdSgAwIBAgIJAOVwUB8QTiI9MA0GCSqGSIb3DQEBCwUAMDoxCzAJBgNVBAYTAktSMQ4wDAYDVQQKDAVNaXJhZTEbMBkGA1UEAwwSTWlyYWUgRklETyBSb290IENBMB4XDTE2MTExMDA2NDA1N1oXDTI2MTEwODA2NDA1N1owMTELMAkGA1UEBhMCS1IxDjAMBgNVBAoMBU1pcmFlMRIwEAYDVQQDDAkwMDQzIzAwMTEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCz5iQMeG7tKxehgswy7Apx0G1KtFf7UHar1ompXLYaF-9iO7ZK7Pf7GfUb5WaKAXkcG9aHdQQWSHS6SY4_ocSQFU7pjzB4OBIHk-aiGa0V85ak_0y6jud0Am3YvzIybXGi60xtFyg5XVsWjMMsGuqpjLZpo88G0KdCyEloj80LhPtUZvmB6iXTgKHc5Ich1ac2b9wYy5_-_YxzKbgox0bpRjjgOZwXu6ubjWVIUpJZTqwLIF1DMaUWInE9_ayUMMKL185yLT51YmDrbnAD0Ic84UyCPe_ovAypUbbWQRYMTePxlbWtuV4YSwBqqhyX1bwV2MwyCnMkE3_pRiKedBu_AgMBAAEwDQYJKoZIhvcNAQELBQADgYEAZh_QNbGEpWv53gRZtTs6HJrBm1q-FFpRVe17eA4_BTUmwFXxTsphYVIEqejQ7sdI-qJBj_nLPBGQIcSyPqbf7XDCsh2JF4q88wdI8T_m1G9LJhE3uawnuqydAvALdr8T1xWvkWt1P7qTCzEmeD8QMrndH42KjNTobbRPoZx-GH0";
/* 215 */     byte[] payload = Base64Utils.decodeRaw(assertion);
/*     */     
/* 217 */     UAFV1RegAssertionParser parser = new UAFV1RegAssertionParser();
/* 218 */     RegAssertionLocator loc = parser.parsePayload(payload);
/*     */     
/* 220 */     System.out.println(loc);
/*     */ 
/*     */     
/* 223 */     assertion = "AT72BAM-cwELLgkAMDA0MyMwMDExDi4HAAEAAQQAAgEKLiAA3FmKGWWXeBh2MTWrX7mQxjFis9SJY9IF9LCpVNXCZfIJLiAALqTW-K17aJ1YBfDl2sPWXZfF-4cfSR9BO9Q_Fn0iLOMNLggAAAAAAAEAAAAMLgMBwPVZMQdviRHSec6epT9S2E82dYMvntbmza03NsOlClrlbJdzhKik7w-4Uw7vhMQwPaal4aRRXi5WbwH_nO0Fg0DhxK2ukcrrWYSIboM_Oyzc3_cwmFUPr4u25w1hCn9ueqGDPQ6TKe-Fv53i7Q9I7U15GlYymi50mhEMSlou3Whk1rIbnlXjoUwklQt84ZyHKXMiVCxBJv4rgTCEeHTbiaQI1l8lwrDqnxU19bE1PpPAp9f73vN-uhbwFK6W7LxH7Z2kTlMNCDFKLkdeEtzUqr-dLgWqCGXOtCcMEZGsEXzvTZbQYuC1yX3sNIUGaAx4sExOTaGZVHc1sQ2aIh_X3QEAAQc-ewMGLgQBBIIBAKD_x-H-RwaK6L-MyJ0nu081X3rMfc4K676f7nOjGORM6PHtYhi_9Ztyb99TgXmBvkWb1MxObn1CO5Rh5xdOp38ZYJQKnAqM928A5z5dztObgkrup5eDguTONA6RqM3pS1opaza30_gDpZ0O0G50P71-wtgTc9oWjw61tC5efhRqi_LbdYtJPK2Y73HvxM8aipg2n1EIHI0NL6yy8fF1jFn60rSMFzKKuaZxg4tVBwsbU64IqUcOx6qoAXjQYJJbinHqQ_i3p6ON5N5oZsBy0L3LYTnjeGjNmbDJaVZPL0lgen9cAJiCfuKmm2BoPlyevbY9-nCu8ZlibIcPVEjYiWUFLm8CMIICazCCAdSgAwIBAgIJAOVwUB8QTiI9MA0GCSqGSIb3DQEBCwUAMDoxCzAJBgNVBAYTAktSMQ4wDAYDVQQKDAVNaXJhZTEbMBkGA1UEAwwSTWlyYWUgRklETyBSb290IENBMB4XDTE2MTExMDA2NDA1N1oXDTI2MTEwODA2NDA1N1owMTELMAkGA1UEBhMCS1IxDjAMBgNVBAoMBU1pcmFlMRIwEAYDVQQDDAkwMDQzIzAwMTEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCz5iQMeG7tKxehgswy7Apx0G1KtFf7UHar1ompXLYaF-9iO7ZK7Pf7GfUb5WaKAXkcG9aHdQQWSHS6SY4_ocSQFU7pjzB4OBIHk-aiGa0V85ak_0y6jud0Am3YvzIybXGi60xtFyg5XVsWjMMsGuqpjLZpo88G0KdCyEloj80LhPtUZvmB6iXTgKHc5Ich1ac2b9wYy5_-_YxzKbgox0bpRjjgOZwXu6ubjWVIUpJZTqwLIF1DMaUWInE9_ayUMMKL185yLT51YmDrbnAD0Ic84UyCPe_ovAypUbbWQRYMTePxlbWtuV4YSwBqqhyX1bwV2MwyCnMkE3_pRiKedBu_AgMBAAEwDQYJKoZIhvcNAQELBQADgYEAZh_QNbGEpWv53gRZtTs6HJrBm1q-FFpRVe17eA4_BTUmwFXxTsphYVIEqejQ7sdI-qJBj_nLPBGQIcSyPqbf7XDCsh2JF4q88wdI8T_m1G9LJhE3uawnuqydAvALdr8T1xWvkWt1P7qTCzEmeD8QMrndH42KjNTobbRPoZx-GH0";
/* 224 */     payload = Base64Utils.decodeRaw(assertion);
/* 225 */     loc = parser.parsePayload(payload);
/*     */     
/* 227 */     System.out.println(loc);
/*     */     
/* 229 */     assertion = "AT79BAM-fgELLgkAMDA0MyMwMDEwDi4HAAEAAQMAAwEKLiAA3FmKGWWXeBh2MTWrX7mQxjFis9SJY9IF9LCpVNXCZfIJLiAAJAKwXwVGKAzpP2Da7gDg4sUFphjN2Lelvwef52nXUXINLggAAAAAAAEAAAAMLg4BMIIBCgKCAQEAzgl3GtxdZjWrxSrF4wPxVtrV4XXjWmka_iv1hFrRWGi5Zwjhd0DFXZ76ZuFLATW1LiSTDuv7KCHthz8u0fKCqMlqg4_8NIVCiQLQs5CtJfByrg43M2OeV2Le5IzQshpJCyxhSnzkWfijHxlobspZ8lzgO9q1W5Mi7VR2RzMKcwd1v13bRkBK0azyFd_We4xEDlWp4X6YxyqHBJfMw-fBHQGlHNwyMdL3QItO7k9pDrbDoa2EAXuEptB-JDkLFrZ_zpt0y8U8bCwW0r0CJPHDVzCbuyVafypUwCKYgEAK6UfOFAF7DXr9XfPsXy3igQZAUTitXWd_gnHl6Kn3kQn0zQIDAQABBz53AwYuAAGdUQT7DLlqFkuGyFatqsLQ79VgLhbHzYcSqHkQOVcKQdo8tIk46wBRqQoQAJQ7e3LuL_CgVkDf1_Ljb6ZL6bHXbk-t63UToofiXaXoIvR54xKw3v-3DZDa1PYzCT05L-PRXUM4HS7i8brSBd8HcZluTgiUiHPAVKdGre7G--hRAtVb6AXfUCNy7WfSDtD0uHLq1vWfIlTmtIrOzOck63Hha4p3xESJyK45FPvJyPXXU73qi4_iwsTWR_oYaOTmE9pwPu5PLVzAVtRwbDOVbXIOYDL9vfyoxtMkPPCfmkTdHrRdD9veobSsSl5YHuSMlISTKKkySRfT2JC3MoQDYD3LBS5vAjCCAmswggHUoAMCAQICCQDlcFAfEE4iPDANBgkqhkiG9w0BAQsFADA6MQswCQYDVQQGEwJLUjEOMAwGA1UECgwFTWlyYWUxGzAZBgNVBAMMEk1pcmFlIEZJRE8gUm9vdCBDQTAeFw0xNjExMDkwOTA5MjFaFw0yNjExMDcwOTA5MjFaMDExCzAJBgNVBAYTAktSMQ4wDAYDVQQKDAVNaXJhZTESMBAGA1UEAwwJMDA0MyMwMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7OG11DgyjmxAmzlAMDZU-z3EjOkHM_WT6ZSsvrkfbd3f3ImefSFHeq3hYV6Bg_26MLoMtnWp6bvOx5prNnVXPfYSVMZRs7K08Wx9dUUkXh4g5Pp2N0FUlWc3OlbZ15u2wdgQzhK-VZtgJ_lMuYy1RAAwZxhFZPi8s5sa6a5OSySJSJfOGMykBHE4_PDvr13nO2EtBCGt5Y92bfEXm179yZOptSiO8LvpX5UaU1Fam_XFAg9_nsAGezCvA47a3il5nEkFz0l14syO9Kv9jvhlHzgjKNPWeJRgqRjj1InTjZDWIfCpvnhiCz8R2yT7P4IF5ZDZR9XdqiOMfEX-Hh8tGQIDAQABMA0GCSqGSIb3DQEBCwUAA4GBAI-lQ8j2T4lgLhOedx9lcAKmd9AdsU7hpF1DHPMPAe6r33rMyWCWekLH_4hIKvim2Y0klV6-OpwgG9a--ZVOvrSDHqNV6t2oMqpZqBhXU5GM4noF303i-LF9vZnGoCiTO1Kz919u_yC7j-PyaBCxXLg-SHLnnob3o5cRA-HE-DY5";
/* 230 */     payload = Base64Utils.decodeRaw(assertion);
/* 231 */     loc = parser.parsePayload(payload);
/*     */     
/* 233 */     System.out.println(loc);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\UAFV1RegAssertionParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */