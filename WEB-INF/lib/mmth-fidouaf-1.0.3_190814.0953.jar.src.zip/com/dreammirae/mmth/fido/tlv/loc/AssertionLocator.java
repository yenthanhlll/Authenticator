package com.dreammirae.mmth.fido.tlv.loc;

import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
import com.dreammirae.mmth.fido.registry.PublicKeyRepresentationFormats;
import com.dreammirae.mmth.fido.tlv.AuthenticationMode;
import java.io.Serializable;
import java.util.List;

public interface AssertionLocator extends Serializable {
  byte[] getAssertionData();
  
  void setAssertionData(byte[] paramArrayOfbyte);
  
  List<byte[]> getAttestationCert();
  
  void setAttestationCert(List<byte[]> paramList);
  
  byte[] getSignature();
  
  void setSignature(byte[] paramArrayOfbyte);
  
  boolean isAttestationBasicFull();
  
  void setAttestationBasicFull(boolean paramBoolean);
  
  boolean isAttestationBasicSurrogate();
  
  void setAttestationBasicSurrogate(boolean paramBoolean);
  
  String getKeyId();
  
  void setKeyId(String paramString);
  
  byte[] getFcParamHash();
  
  void setFcParamHash(byte[] paramArrayOfbyte);
  
  String getAAID();
  
  void setAAID(String paramString);
  
  byte[] getPublicKey();
  
  void setPublicKey(byte[] paramArrayOfbyte);
  
  long getRegCounter();
  
  void setRegCounter(long paramLong);
  
  long getSignCounter();
  
  void setSignCounter(long paramLong);
  
  int getAuthenticatorVersion();
  
  void setAuthenticatorVersion(int paramInt);
  
  AuthenticationMode getAuthenticationMode();
  
  void setAuthenticationMode(AuthenticationMode paramAuthenticationMode);
  
  AuthenticationAlgorithms getAuthenticationAlgorithms();
  
  void setAuthenticationAlgorithms(AuthenticationAlgorithms paramAuthenticationAlgorithms);
  
  PublicKeyRepresentationFormats getPublicKeyAlgAndEncoding();
  
  void setPublicKeyAlgAndEncoding(PublicKeyRepresentationFormats paramPublicKeyRepresentationFormats);
  
  byte[] getAuthenticatorNonce();
  
  void setAuthenticatorNonce(byte[] paramArrayOfbyte);
  
  byte[] getTransactionContentHash();
  
  void setTransactionContentHash(byte[] paramArrayOfbyte);
  
  boolean hasExtension();
  
  void setExtension(boolean paramBoolean);
  
  boolean isNonCriticalExtension();
  
  void setNonCriticalExtension(boolean paramBoolean);
  
  String getExtensionId();
  
  void setExtensionId(String paramString);
  
  byte[] getExtensionData();
  
  void setExtensionData(byte[] paramArrayOfbyte);
  
  void validateField() throws IllegalUafFieldException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\loc\AssertionLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */