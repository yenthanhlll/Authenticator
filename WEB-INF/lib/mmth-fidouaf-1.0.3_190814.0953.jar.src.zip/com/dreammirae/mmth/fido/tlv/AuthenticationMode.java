/*    */ package com.dreammirae.mmth.fido.tlv;
/*    */ 
/*    */ public enum AuthenticationMode
/*    */ {
/*  5 */   VERIFIED(1), TRANSACTION_CONFIRMATION(2);
/*    */   
/*    */   private final int mode;
/*    */   
/*    */   AuthenticationMode(int mode) {
/* 10 */     this.mode = mode;
/*    */   }
/*    */   
/*    */   public int getMode() {
/* 14 */     return this.mode;
/*    */   }
/*    */ 
/*    */   
/*    */   public static AuthenticationMode getAuthenticationMode(int mode) {
/* 19 */     for (AuthenticationMode am : values()) {
/* 20 */       if (am.mode == mode) {
/* 21 */         return am;
/*    */       }
/*    */     } 
/*    */     
/* 25 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\AuthenticationMode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */