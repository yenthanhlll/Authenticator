/*     */ package com.dreammirae.mmth.fido.tlv.loc;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
/*     */ import com.dreammirae.mmth.fido.registry.PublicKeyRepresentationFormats;
/*     */ import com.dreammirae.mmth.fido.tlv.AuthenticationMode;
/*     */ import com.dreammirae.mmth.fido.tlv.TagCodes;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegAssertionLocator
/*     */   implements AssertionLocator
/*     */ {
/*     */   private byte[] assertionData;
/*     */   private List<byte[]> attestationCert;
/*     */   private byte[] signature;
/*     */   private boolean isAttestationBasicFull;
/*     */   private boolean isAttestationBasicSurrogate;
/*     */   private String keyId;
/*     */   private byte[] fcParamHash;
/*     */   private String aaid;
/*     */   private byte[] publicKey;
/*     */   private long regCounter;
/*     */   private long signCounter;
/*     */   private int authenticatorVersion;
/*     */   private AuthenticationMode authenticationMode;
/*     */   private AuthenticationAlgorithms authenticationAlgorithms;
/*     */   private PublicKeyRepresentationFormats publicKeyRepresentationFormats;
/*     */   private boolean hasExtension;
/*     */   private boolean isNonCriticalExtension;
/*     */   private String extensionId;
/*     */   private byte[] extensionData;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public byte[] getAssertionData() {
/*  46 */     return this.assertionData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAssertionData(byte[] data) {
/*  54 */     this.assertionData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<byte[]> getAttestationCert() {
/*  62 */     return this.attestationCert;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttestationCert(List<byte[]> data) {
/*  70 */     this.attestationCert = data;
/*     */   }
/*     */   
/*     */   public void addAttestationCert(byte[] data) {
/*  74 */     if (this.attestationCert == null) {
/*  75 */       this.attestationCert = (List)new ArrayList<>();
/*     */     }
/*     */     
/*  78 */     this.attestationCert.add(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getSignature() {
/*  86 */     return this.signature;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSignature(byte[] data) {
/*  94 */     this.signature = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttestationBasicFull() {
/* 102 */     return this.isAttestationBasicFull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttestationBasicFull(boolean bool) {
/* 110 */     this.isAttestationBasicFull = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttestationBasicSurrogate() {
/* 118 */     return this.isAttestationBasicSurrogate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttestationBasicSurrogate(boolean bool) {
/* 126 */     this.isAttestationBasicSurrogate = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyId() {
/* 134 */     return this.keyId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyId(String data) {
/* 142 */     this.keyId = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFcParamHash() {
/* 150 */     return this.fcParamHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFcParamHash(byte[] data) {
/* 158 */     this.fcParamHash = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAAID() {
/* 166 */     return this.aaid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAAID(String data) {
/* 174 */     this.aaid = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPublicKey() {
/* 182 */     return this.publicKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublicKey(byte[] data) {
/* 190 */     this.publicKey = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRegCounter() {
/* 198 */     return this.regCounter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegCounter(long data) {
/* 206 */     this.regCounter = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSignCounter() {
/* 214 */     return this.signCounter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSignCounter(long data) {
/* 222 */     this.signCounter = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAuthenticatorVersion() {
/* 230 */     return this.authenticatorVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticatorVersion(int data) {
/* 238 */     this.authenticatorVersion = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationMode getAuthenticationMode() {
/* 246 */     return this.authenticationMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationMode(AuthenticationMode data) {
/* 254 */     this.authenticationMode = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationAlgorithms getAuthenticationAlgorithms() {
/* 262 */     return this.authenticationAlgorithms;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationAlgorithms(AuthenticationAlgorithms data) {
/* 270 */     this.authenticationAlgorithms = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PublicKeyRepresentationFormats getPublicKeyAlgAndEncoding() {
/* 278 */     return this.publicKeyRepresentationFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublicKeyAlgAndEncoding(PublicKeyRepresentationFormats data) {
/* 286 */     this.publicKeyRepresentationFormats = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExtension() {
/* 294 */     return this.hasExtension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtension(boolean bool) {
/* 302 */     this.hasExtension = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNonCriticalExtension() {
/* 310 */     return this.isNonCriticalExtension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNonCriticalExtension(boolean bool) {
/* 318 */     this.isNonCriticalExtension = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExtensionId() {
/* 326 */     return this.extensionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtensionId(String data) {
/* 334 */     this.extensionId = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getExtensionData() {
/* 342 */     return this.extensionData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtensionData(byte[] data) {
/* 350 */     this.extensionData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getAuthenticatorNonce() {
/* 359 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticatorNonce(byte[] data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getTransactionContentHash() {
/* 376 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionContentHash(byte[] data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAttestationType() {
/* 388 */     if (this.isAttestationBasicFull) {
/* 389 */       return TagCodes.TAG_ATTESTATION_BASIC_FULL.getId();
/*     */     }
/* 391 */     return TagCodes.TAG_ATTESTATION_BASIC_SURROGATE.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 400 */     if (StringUtils.isEmpty(this.aaid)) {
/* 401 */       throw new IllegalUafFieldException("Assertion[AAID] must be contain.");
/*     */     }
/* 403 */     if (this.aaid.length() != 9) {
/* 404 */       throw new IllegalUafFieldException("Assertion[AAID] size must be 9");
/*     */     }
/* 406 */     if (this.fcParamHash.length != 32) {
/* 407 */       throw new IllegalUafFieldException("Assertion[fcHash] must be hashed.");
/*     */     }
/* 409 */     if (StringUtils.isEmpty(this.keyId)) {
/* 410 */       throw new IllegalUafFieldException("Assertion[keyId] must be contain.");
/*     */     }
/* 412 */     if (this.regCounter < 0L) {
/* 413 */       throw new IllegalUafFieldException("Assertion[regCounter] can not be negative value.");
/*     */     }
/*     */     
/* 416 */     if (this.signCounter < 0L) {
/* 417 */       throw new IllegalUafFieldException("Assertion[signCounter] can not be negative value.");
/*     */     }
/*     */     
/* 420 */     if (!AuthenticationMode.VERIFIED.equals(this.authenticationMode)) {
/* 421 */       throw new IllegalUafFieldException("Assertion[authenticationMode] must be VERIFIED(0x01).");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 428 */     StringBuilder builder = new StringBuilder();
/* 429 */     builder.append("RegAssertionLocator [assertionData=").append(HexUtils.toHexString(this.assertionData)).append(", attestationCert=");
/*     */     
/* 431 */     if (this.attestationCert != null)
/*     */     {
/* 433 */       for (int i = 0; i < this.attestationCert.size(); i++) {
/* 434 */         if (i != 0) {
/* 435 */           builder.append("\t : \t");
/*     */         }
/* 437 */         builder.append(HexUtils.toHexString(this.attestationCert.get(i)));
/*     */       } 
/*     */     }
/*     */     
/* 441 */     builder.append(", signature=").append(HexUtils.toHexString(this.signature)).append(", isAttestationBasicFull=").append(this.isAttestationBasicFull).append(", isAttestationBasicSurrogate=").append(this.isAttestationBasicSurrogate).append(", keyId=").append(this.keyId)
/* 442 */       .append(", fcParamHash=").append(HexUtils.toHexString(this.fcParamHash)).append(", aaid=").append(this.aaid).append(", publicKey=").append(HexUtils.toHexString(this.publicKey)).append(", regCounter=").append(this.regCounter).append(", signCounter=")
/* 443 */       .append(this.signCounter).append(", authenticatorVersion=").append(this.authenticatorVersion).append(", authenticationMode=").append(this.authenticationMode).append(", authenticationAlgorithms=").append(this.authenticationAlgorithms)
/* 444 */       .append(", publicKeyRepresentationFormats=").append(this.publicKeyRepresentationFormats).append(", hasExtension=").append(this.hasExtension).append(", isNonCriticalExtension=").append(this.isNonCriticalExtension).append(", extensionId=")
/* 445 */       .append(this.extensionId).append(", extensionData=").append(HexUtils.toHexString(this.extensionData)).append("]");
/* 446 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 456 */     out.writeInt(1);
/* 457 */     SerializationUtils.writeSafeObject(out, this.assertionData);
/* 458 */     SerializationUtils.writeSafeObject(out, this.attestationCert);
/* 459 */     SerializationUtils.writeSafeObject(out, this.signature);
/* 460 */     out.writeBoolean(this.isAttestationBasicFull);
/* 461 */     out.writeBoolean(this.isAttestationBasicSurrogate);
/* 462 */     SerializationUtils.writeSafeUTF(out, this.keyId);
/* 463 */     SerializationUtils.writeSafeObject(out, this.fcParamHash);
/* 464 */     SerializationUtils.writeSafeUTF(out, this.aaid);
/* 465 */     SerializationUtils.writeSafeObject(out, this.publicKey);
/* 466 */     out.writeLong(this.regCounter);
/* 467 */     out.writeLong(this.signCounter);
/* 468 */     out.writeInt(this.authenticatorVersion);
/* 469 */     SerializationUtils.writeSafeObject(out, this.authenticationMode);
/* 470 */     SerializationUtils.writeSafeObject(out, this.authenticationAlgorithms);
/* 471 */     SerializationUtils.writeSafeObject(out, this.publicKeyRepresentationFormats);
/* 472 */     out.writeBoolean(this.hasExtension);
/* 473 */     out.writeBoolean(this.isNonCriticalExtension);
/* 474 */     SerializationUtils.writeSafeUTF(out, this.extensionId);
/* 475 */     SerializationUtils.writeSafeObject(out, this.extensionData);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 479 */     int ver = in.readInt();
/* 480 */     if (1 == ver) {
/* 481 */       this.assertionData = (byte[])SerializationUtils.readSafeObject(in);
/* 482 */       this.attestationCert = (List<byte[]>)SerializationUtils.readSafeObject(in);
/* 483 */       this.signature = (byte[])SerializationUtils.readSafeObject(in);
/* 484 */       this.isAttestationBasicFull = in.readBoolean();
/* 485 */       this.isAttestationBasicSurrogate = in.readBoolean();
/* 486 */       this.keyId = SerializationUtils.readSafeUTF(in);
/* 487 */       this.fcParamHash = (byte[])SerializationUtils.readSafeObject(in);
/* 488 */       this.aaid = SerializationUtils.readSafeUTF(in);
/* 489 */       this.publicKey = (byte[])SerializationUtils.readSafeObject(in);
/* 490 */       this.regCounter = in.readLong();
/* 491 */       this.signCounter = in.readLong();
/* 492 */       this.authenticatorVersion = in.readInt();
/* 493 */       this.authenticationMode = (AuthenticationMode)SerializationUtils.readSafeObject(in);
/* 494 */       this.authenticationAlgorithms = (AuthenticationAlgorithms)SerializationUtils.readSafeObject(in);
/* 495 */       this.publicKeyRepresentationFormats = (PublicKeyRepresentationFormats)SerializationUtils.readSafeObject(in);
/* 496 */       this.hasExtension = in.readBoolean();
/* 497 */       this.isNonCriticalExtension = in.readBoolean();
/* 498 */       this.extensionId = SerializationUtils.readSafeUTF(in);
/* 499 */       this.extensionData = (byte[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\loc\RegAssertionLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */