/*    */ package com.dreammirae.mmth.fido.tlv;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TagCodes
/*    */ {
/* 11 */   TAG_UAFV1_REG_ASSERTION(15873, true),
/*    */ 
/*    */   
/* 14 */   TAG_UAFV1_AUTH_ASSERTION(15874, true),
/*    */ 
/*    */   
/* 17 */   TAG_UAFV1_KRD(15875, true),
/*    */ 
/*    */   
/* 20 */   TAG_UAFV1_SIGNED_DATA(15876, true),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   TAG_ATTESTATION_CERT(11781, false),
/*    */ 
/*    */   
/* 32 */   TAG_SIGNATURE(11782, false),
/*    */ 
/*    */   
/* 35 */   TAG_ATTESTATION_BASIC_FULL(15879, true),
/*    */ 
/*    */   
/* 38 */   TAG_ATTESTATION_BASIC_SURROGATE(15880, true),
/*    */ 
/*    */   
/* 41 */   TAG_KEYID(11785, false),
/*    */ 
/*    */   
/* 44 */   TAG_FINAL_CHALLENGE(11786, false),
/*    */ 
/*    */   
/* 47 */   TAG_AAID(11787, false),
/*    */ 
/*    */   
/* 50 */   TAG_PUB_KEY(11788, false),
/*    */ 
/*    */   
/* 53 */   TAG_COUNTERS(11789, false),
/*    */ 
/*    */   
/* 56 */   TAG_ASSERTION_INFO(11790, false),
/*    */ 
/*    */   
/* 59 */   TAG_AUTHENTICATOR_NONCE(11791, false),
/*    */ 
/*    */   
/* 62 */   TAG_TRANSACTION_CONTENT_HASH(11792, false),
/*    */ 
/*    */   
/* 65 */   TAG_EXTENSION(15889, true),
/*    */ 
/*    */   
/* 68 */   TAG_EXTENSION_NON_CRITICAL(15890, true),
/*    */ 
/*    */   
/* 71 */   TAG_EXTENSION_ID(11795, false),
/*    */ 
/*    */   
/* 74 */   TAG_EXTENSION_DATA(11796, false);
/*    */   
/*    */   private final int id;
/*    */   
/*    */   private final boolean hasChildren;
/*    */   
/*    */   TagCodes(int id, boolean hasChildren) {
/* 81 */     this.id = id;
/* 82 */     this.hasChildren = hasChildren;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 86 */     return this.id;
/*    */   }
/*    */   
/*    */   public boolean hasChildren() {
/* 90 */     return this.hasChildren;
/*    */   }
/*    */   
/*    */   public static TagCodes get(int id) {
/* 94 */     for (TagCodes tag : values()) {
/* 95 */       if (tag.id == id) {
/* 96 */         return tag;
/*    */       }
/*    */     } 
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\TagCodes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */