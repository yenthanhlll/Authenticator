/*     */ package com.dreammirae.mmth.fido.tlv.loc;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
/*     */ import com.dreammirae.mmth.fido.registry.PublicKeyRepresentationFormats;
/*     */ import com.dreammirae.mmth.fido.tlv.AuthenticationMode;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthAssertionLocator
/*     */   implements AssertionLocator
/*     */ {
/*     */   private byte[] assertionData;
/*     */   private byte[] signature;
/*     */   private String keyId;
/*     */   private byte[] fcParamHash;
/*     */   private String aaid;
/*     */   private long signCounter;
/*     */   private int authenticatorVersion;
/*     */   private AuthenticationMode authenticationMode;
/*     */   private AuthenticationAlgorithms authenticationAlgorithms;
/*     */   private byte[] authnrNonce;
/*     */   private byte[] transactionContentHash;
/*     */   private boolean hasExtension;
/*     */   private boolean isNonCriticalExtension;
/*     */   private String extensionId;
/*     */   private byte[] extensionData;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public byte[] getAssertionData() {
/*  45 */     return this.assertionData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAssertionData(byte[] data) {
/*  53 */     this.assertionData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getSignature() {
/*  61 */     return this.signature;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSignature(byte[] data) {
/*  69 */     this.signature = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyId() {
/*  77 */     return this.keyId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyId(String data) {
/*  85 */     this.keyId = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFcParamHash() {
/*  93 */     return this.fcParamHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFcParamHash(byte[] data) {
/* 101 */     this.fcParamHash = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAAID() {
/* 109 */     return this.aaid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAAID(String data) {
/* 117 */     this.aaid = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSignCounter() {
/* 125 */     return this.signCounter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSignCounter(long data) {
/* 133 */     this.signCounter = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAuthenticatorVersion() {
/* 141 */     return this.authenticatorVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticatorVersion(int data) {
/* 149 */     this.authenticatorVersion = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationMode getAuthenticationMode() {
/* 157 */     return this.authenticationMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationMode(AuthenticationMode mode) {
/* 165 */     this.authenticationMode = mode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationAlgorithms getAuthenticationAlgorithms() {
/* 173 */     return this.authenticationAlgorithms;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticationAlgorithms(AuthenticationAlgorithms data) {
/* 181 */     this.authenticationAlgorithms = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getAuthenticatorNonce() {
/* 189 */     return this.authnrNonce;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthenticatorNonce(byte[] data) {
/* 197 */     this.authnrNonce = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getTransactionContentHash() {
/* 205 */     return this.transactionContentHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransactionContentHash(byte[] data) {
/* 213 */     this.transactionContentHash = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExtension() {
/* 221 */     return this.hasExtension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtension(boolean bool) {
/* 229 */     this.hasExtension = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNonCriticalExtension() {
/* 237 */     return this.isNonCriticalExtension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNonCriticalExtension(boolean bool) {
/* 245 */     this.isNonCriticalExtension = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExtensionId() {
/* 253 */     return this.extensionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtensionId(String data) {
/* 261 */     this.extensionId = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getExtensionData() {
/* 269 */     return this.extensionData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtensionData(byte[] data) {
/* 277 */     this.extensionData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<byte[]> getAttestationCert() {
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttestationCert(List<byte[]> data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttestationBasicFull() {
/* 303 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttestationBasicFull(boolean bool) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttestationBasicSurrogate() {
/* 320 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttestationBasicSurrogate(boolean bool) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPublicKey() {
/* 337 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublicKey(byte[] data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRegCounter() {
/* 354 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegCounter(long data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PublicKeyRepresentationFormats getPublicKeyAlgAndEncoding() {
/* 371 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublicKeyAlgAndEncoding(PublicKeyRepresentationFormats data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 387 */     if (StringUtils.isEmpty(this.aaid)) {
/* 388 */       throw new IllegalUafFieldException("Assertion[AAID] must be contain.");
/*     */     }
/* 390 */     if (this.aaid.length() != 9) {
/* 391 */       throw new IllegalUafFieldException("Assertion[AAID] size must be 9");
/*     */     }
/* 393 */     if (this.fcParamHash.length != 32) {
/* 394 */       throw new IllegalUafFieldException("Assertion[fcHash] must be hashed.");
/*     */     }
/* 396 */     if (StringUtils.isEmpty(this.keyId)) {
/* 397 */       throw new IllegalUafFieldException("Assertion[keyId] must be contain.");
/*     */     }
/* 399 */     if (AuthenticationMode.TRANSACTION_CONFIRMATION.equals(this.authenticationMode))
/*     */     {
/* 401 */       if (this.transactionContentHash == null || this.transactionContentHash.length == 0) {
/* 402 */         throw new IllegalUafFieldException("Assertion[transactionContentHash] must be contain when Assertion[transactionContentHash] is TRANSACTION_CONFIRMATION(0x02).");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 410 */     StringBuilder builder = new StringBuilder();
/* 411 */     builder.append("AuthAssertionLocator [assertionData=").append(HexUtils.toHexString(this.assertionData)).append(", signature=").append(HexUtils.toHexString(this.signature)).append(", keyId=").append(this.keyId).append(", fcParamHash=")
/* 412 */       .append(HexUtils.toHexString(this.fcParamHash)).append(", aaid=").append(this.aaid).append(", signCounter=").append(this.signCounter).append(", authenticatorVersion=").append(this.authenticatorVersion).append(", authenticationMode=").append(this.authenticationMode)
/* 413 */       .append(", authenticationAlgorithms=").append(this.authenticationAlgorithms).append(", authnrNonce=").append(HexUtils.toHexString(this.authnrNonce)).append(", transactionContentHash=").append(HexUtils.toHexString(this.transactionContentHash))
/* 414 */       .append(", hasExtension=").append(this.hasExtension).append(", isNonCriticalExtension=").append(this.isNonCriticalExtension).append(", extensionId=").append(this.extensionId).append(", extensionData=").append(HexUtils.toHexString(this.extensionData))
/* 415 */       .append("]");
/* 416 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 426 */     out.writeInt(1);
/* 427 */     SerializationUtils.writeSafeObject(out, this.assertionData);
/* 428 */     SerializationUtils.writeSafeObject(out, this.signature);
/* 429 */     SerializationUtils.writeSafeUTF(out, this.keyId);
/* 430 */     SerializationUtils.writeSafeObject(out, this.fcParamHash);
/* 431 */     SerializationUtils.writeSafeUTF(out, this.aaid);
/* 432 */     out.writeLong(this.signCounter);
/* 433 */     out.writeInt(this.authenticatorVersion);
/* 434 */     SerializationUtils.writeSafeObject(out, this.authenticationMode);
/* 435 */     SerializationUtils.writeSafeObject(out, this.authenticationAlgorithms);
/* 436 */     SerializationUtils.writeSafeObject(out, this.authnrNonce);
/* 437 */     SerializationUtils.writeSafeObject(out, this.transactionContentHash);
/* 438 */     out.writeBoolean(this.hasExtension);
/* 439 */     out.writeBoolean(this.isNonCriticalExtension);
/* 440 */     SerializationUtils.writeSafeUTF(out, this.extensionId);
/* 441 */     SerializationUtils.writeSafeObject(out, this.extensionData);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 445 */     int ver = in.readInt();
/* 446 */     if (1 == ver) {
/* 447 */       this.assertionData = (byte[])SerializationUtils.readSafeObject(in);
/* 448 */       this.signature = (byte[])SerializationUtils.readSafeObject(in);
/* 449 */       this.keyId = SerializationUtils.readSafeUTF(in);
/* 450 */       this.fcParamHash = (byte[])SerializationUtils.readSafeObject(in);
/* 451 */       this.aaid = SerializationUtils.readSafeUTF(in);
/* 452 */       this.signCounter = in.readLong();
/* 453 */       this.authenticatorVersion = in.readInt();
/* 454 */       this.authenticationMode = (AuthenticationMode)SerializationUtils.readSafeObject(in);
/* 455 */       this.authenticationAlgorithms = (AuthenticationAlgorithms)SerializationUtils.readSafeObject(in);
/* 456 */       this.authnrNonce = (byte[])SerializationUtils.readSafeObject(in);
/* 457 */       this.transactionContentHash = (byte[])SerializationUtils.readSafeObject(in);
/* 458 */       this.hasExtension = in.readBoolean();
/* 459 */       this.isNonCriticalExtension = in.readBoolean();
/* 460 */       this.extensionId = SerializationUtils.readSafeUTF(in);
/* 461 */       this.extensionData = (byte[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\loc\AuthAssertionLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */