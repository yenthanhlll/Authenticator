/*     */ package com.dreammirae.mmth.fido.tlv;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafParsingException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalTLVException;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.AssertionLocator;
/*     */ import com.dreammirae.mmth.util.io.EndianUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UAFV1AssertionParser<T extends AssertionLocator>
/*     */ {
/*  23 */   private static final Logger LOG = LoggerFactory.getLogger(UAFV1AssertionParser.class);
/*     */   
/*     */   protected static final int LEN_TAG_CODE = 2;
/*     */   
/*     */   protected static final int LEN_TAG_LENGTH = 2;
/*     */   
/*     */   protected final T locator;
/*     */   
/*     */   public UAFV1AssertionParser(T locator) {
/*  32 */     this.locator = locator;
/*     */   }
/*     */ 
/*     */   
/*     */   public T parsePayload(byte[] tlvData) throws IllegalTLVException {
/*  37 */     parseToLocator(tlvData, 0, tlvData.length);
/*     */     
/*  39 */     parsePayloadImp(tlvData);
/*     */     
/*  41 */     return this.locator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseToLocator(byte[] payload, int offset, int len) throws IllegalTLVException {
/*     */     try {
/*  49 */       while (offset < len)
/*     */       {
/*     */         
/*  52 */         int curIdx = offset;
/*     */ 
/*     */         
/*  55 */         TagCodes code = getTagCodes(payload, curIdx);
/*  56 */         curIdx += 2;
/*     */         
/*  58 */         int valLen = getValueLength(payload, curIdx);
/*  59 */         curIdx += 2;
/*     */         
/*  61 */         if (code != null) {
/*     */           
/*  63 */           setTagCode(code);
/*     */           
/*  65 */           if (code.hasChildren()) {
/*     */             
/*  67 */             parseToLocator(payload, curIdx, curIdx + valLen);
/*     */           }
/*     */           else {
/*     */             
/*  71 */             byte[] value = new byte[valLen];
/*  72 */             System.arraycopy(payload, curIdx, value, 0, valLen);
/*  73 */             setLocatorValue(code, value);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/*  78 */         offset = curIdx + valLen;
/*     */       }
/*     */     
/*  81 */     } catch (ArrayIndexOutOfBoundsException e) {
/*  82 */       throw new FidoUafParsingException("Failed to parse assertion... ", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TagCodes getTagCodes(byte[] payload, int offset) throws IllegalTLVException {
/*     */     try {
/*  93 */       int code = EndianUtils.toUInt16_ByLittleEndian(payload, offset);
/*  94 */       TagCodes tag = TagCodes.get(code);
/*     */       
/*  96 */       if (tag == null)
/*     */       {
/*  98 */         if (LOG.isWarnEnabled()) {
/*  99 */           int valLen = getValueLength(payload, offset + 2);
/* 100 */           LOG.warn("Assertion[TagCode] is invalid. [code=" + HexUtils.toHexString(code) + ", len=" + valLen + ", offset=" + offset + ", value=" + 
/*     */               
/* 102 */               HexUtils.toHexString(payload, offset + 2 + 2, valLen) + ", payload=" + 
/* 103 */               HexUtils.toHexString(payload) + "]");
/*     */         } 
/*     */       }
/*     */       
/* 107 */       return tag;
/*     */     }
/* 109 */     catch (IllegalArgumentException e) {
/* 110 */       throw new IllegalTLVException("Assertion[TagCode] is invalid... payload=" + HexUtils.toHexString(payload));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getValueLength(byte[] payload, int offset) throws IllegalTLVException {
/*     */     try {
/* 120 */       return EndianUtils.toUInt16_ByLittleEndian(payload, offset);
/* 121 */     } catch (Exception e) {
/* 122 */       throw new IllegalTLVException("Assertion[length] is invalid.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract void setLocatorValue(TagCodes paramTagCodes, byte[] paramArrayOfbyte) throws IllegalTLVException;
/*     */   
/*     */   protected abstract void parsePayloadImp(byte[] paramArrayOfbyte) throws IllegalTLVException;
/*     */   
/*     */   protected abstract void setTagCode(TagCodes paramTagCodes) throws IllegalTLVException;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\tlv\UAFV1AssertionParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */