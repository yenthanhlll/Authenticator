/*    */ package com.dreammirae.mmth.fido;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FidoUAFConstants
/*    */ {
/*    */   public static final String ENCODING = "UTF-8";
/* 15 */   public static final Charset ENCODING_CS = Charset.forName("UTF-8");
/*    */   public static final String ASSERTION_SCHEME = "UAFV1TLV";
/*    */   public static final int LEN_SERVER_DATA = 1536;
/*    */   public static final int LEN_APP_ID = 512;
/*    */   public static final int LEN_USERNAME = 128;
/*    */   public static final int LEN_SERVER_CHALLENGE_MAX = 64;
/*    */   public static final int LEN_SERVER_CHALLENGE_MIN = 8;
/*    */   public static final int LEN_AAID = 9;
/*    */   public static final int LEN_KEY_ID_MIN = 32;
/*    */   public static final int LEN_KEY_ID_MAX = 2048;
/*    */   public static final int LEN_FC_HASH = 32;
/*    */   public static final int LEN_FACET_ID = 512;
/*    */   public static final long REG_COUNT_EXCEED_LIMIT = 65535L;
/*    */   public static final int LEN_USERNAME_MIN = 1;
/*    */   public static final int LEN_USERNAME_MAX = 128;
/*    */   public static final int LEN_ASSERTION_MAX = 4096;
/*    */   public static final int LEN_EXTS_ID = 32;
/*    */   public static final int LEN_TRANSACTION_TEXT_CONTENTS = 200;
/*    */   public static final int TC_DISPLAY_NOT_SUPPORTED = 0;
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\FidoUAFConstants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */