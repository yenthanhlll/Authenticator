/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.Operation;
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ import com.dreammirae.mmth.fido.transport.ReturnUAFRequest;
/*    */ import com.dreammirae.mmth.fido.transport.UAFMessage;
/*    */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReturnUAFRequestSerializer
/*    */   extends UafMessageSerializer<ReturnUAFRequest>
/*    */ {
/*    */   private static final String MEM_UAF_REQUEST = "uafRequest";
/*    */   private static final String MEM_LIFETIME_MILLIS = "lifetimeMillis";
/*    */   private static final String MEM_CONTEXT = "context";
/*    */   
/*    */   protected JsonElement serializeImp(ReturnUAFRequest bean, Type type, JsonSerializationContext context) {
/* 24 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 26 */     if (bean.getStatusCode() != null) {
/* 27 */       jsonObject.add("statusCode", context.serialize(bean.getStatusCode()));
/*    */     }
/*    */     
/* 30 */     if (bean.getUafRequest() != null)
/*    */     {
/* 32 */       if (bean.isConformanceRequest()) {
/* 33 */         jsonObject.addProperty("uafRequest", bean.getUafRequest().getUafProtocolMessage());
/*    */       } else {
/* 35 */         jsonObject.addProperty("uafRequest", UafSerializeUtils.gson().toJson(bean.getUafRequest()));
/*    */       } 
/*    */     }
/*    */     
/* 39 */     if (bean.getOp() != null) {
/* 40 */       jsonObject.addProperty("op", bean.getOp().name());
/*    */     }
/*    */     
/* 43 */     if (bean.getLifetimeMillis() != null) {
/* 44 */       jsonObject.addProperty("lifetimeMillis", bean.getLifetimeMillis());
/*    */     }
/*    */     
/* 47 */     if (bean.getContext() != null && !bean.getContext().isEmpty()) {
/* 48 */       jsonObject.addProperty("context", UafSerializeUtils.gson().toJson(bean.getContext()));
/*    */     }
/*    */     
/* 51 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ReturnUAFRequest deserializeImp(JsonElement json, Type type, JsonDeserializationContext context) {
/* 57 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 59 */     ReturnUAFRequest returnUafReq = new ReturnUAFRequest();
/*    */     
/* 61 */     if (jsonObject.has("statusCode")) {
/* 62 */       StatusCodes statusCode = (StatusCodes)context.deserialize(jsonObject.get("statusCode"), StatusCodes.class);
/* 63 */       returnUafReq.setStatusCode(statusCode);
/*    */     } 
/*    */     
/* 66 */     if (jsonObject.has("op")) {
/* 67 */       String op = jsonObject.get("op").getAsString();
/* 68 */       returnUafReq.setOp(Operation.getOperation(op));
/*    */     } 
/*    */     
/* 71 */     if (jsonObject.has("uafRequest")) {
/* 72 */       String str = jsonObject.get("uafRequest").getAsString();
/* 73 */       UAFMessage message = (UAFMessage)UafSerializeUtils.gson().fromJson(str, UAFMessage.class);
/*    */       
/* 75 */       returnUafReq.setUafRequest(message);
/*    */     } 
/*    */     
/* 78 */     if (jsonObject.has("lifetimeMillis")) {
/* 79 */       returnUafReq.setLifetimeMillis(Long.valueOf(jsonObject.get("lifetimeMillis").getAsLong()));
/*    */     }
/*    */     
/* 82 */     if (jsonObject.has("context")) {
/* 83 */       RpContext rpCtx = (RpContext)context.deserialize(jsonObject.get("context"), RpContext.class);
/* 84 */       returnUafReq.setContext(rpCtx);
/*    */     } 
/*    */     
/* 87 */     return returnUafReq;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\ReturnUAFRequestSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */