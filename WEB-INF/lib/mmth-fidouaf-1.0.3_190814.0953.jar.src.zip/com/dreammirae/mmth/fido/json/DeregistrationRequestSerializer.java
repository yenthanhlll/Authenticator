/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.uaf.DeregisterAuthenticator;
/*    */ import com.dreammirae.mmth.fido.uaf.DeregistrationRequest;
/*    */ import com.dreammirae.mmth.fido.uaf.OperationHeader;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeregistrationRequestSerializer
/*    */   extends UafMessageSerializer<DeregistrationRequest>
/*    */ {
/*    */   private static final String MEM_HEADER = "header";
/*    */   private static final String MEM_AUTHENTICATORS = "authenticators";
/*    */   
/*    */   protected JsonElement serializeImp(DeregistrationRequest bean, Type type, JsonSerializationContext context) {
/* 21 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 23 */     if (bean.getHeader() != null) {
/* 24 */       jsonObject.add("header", context.serialize(bean.getHeader()));
/*    */     }
/*    */     
/* 27 */     if (bean.getAuthenticators() != null) {
/* 28 */       jsonObject.add("authenticators", context.serialize(bean.getAuthenticators()));
/*    */     }
/*    */     
/* 31 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected DeregistrationRequest deserializeImp(JsonElement json, Type type, JsonDeserializationContext context) {
/* 37 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 39 */     DeregistrationRequest request = new DeregistrationRequest();
/*    */     
/* 41 */     if (jsonObject.has("header")) {
/* 42 */       OperationHeader header = (OperationHeader)context.deserialize(jsonObject.get("header"), OperationHeader.class);
/* 43 */       request.setHeader(header);
/*    */     } 
/*    */ 
/*    */     
/* 47 */     if (jsonObject.has("authenticators")) {
/* 48 */       DeregisterAuthenticator[] authenticators = (DeregisterAuthenticator[])context.deserialize(jsonObject.get("authenticators"), DeregisterAuthenticator[].class);
/* 49 */       request.setAuthenticators(authenticators);
/*    */     } 
/*    */     
/* 52 */     return request;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\DeregistrationRequestSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */