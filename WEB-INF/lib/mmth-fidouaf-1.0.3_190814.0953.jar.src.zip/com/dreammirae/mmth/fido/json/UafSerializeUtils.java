/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ import com.dreammirae.mmth.fido.transport.GetUAFRequest;
/*    */ import com.dreammirae.mmth.fido.transport.ReturnUAFRequest;
/*    */ import com.dreammirae.mmth.fido.transport.SendUAFResponse;
/*    */ import com.dreammirae.mmth.fido.transport.ServerResponse;
/*    */ import com.dreammirae.mmth.fido.transport.UAFMessage;
/*    */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*    */ import com.dreammirae.mmth.fido.uaf.AuthenticationRequest;
/*    */ import com.dreammirae.mmth.fido.uaf.AuthenticationResponse;
/*    */ import com.dreammirae.mmth.fido.uaf.AuthenticatorRegistrationAssertion;
/*    */ import com.dreammirae.mmth.fido.uaf.AuthenticatorSignAssertion;
/*    */ import com.dreammirae.mmth.fido.uaf.DeregistrationRequest;
/*    */ import com.dreammirae.mmth.fido.uaf.RegistrationRequest;
/*    */ import com.dreammirae.mmth.fido.uaf.RegistrationResponse;
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UafSerializeUtils
/*    */ {
/* 35 */   private static Gson gson = null;
/*    */ 
/*    */ 
/*    */   
/* 39 */   private static GsonBuilder uafGsonBuilder = new GsonBuilder();
/*    */   static {
/* 41 */     Map<Class<?>, UafMessageSerializer<?>> map = getSerializers();
/* 42 */     for (Map.Entry<Class<?>, UafMessageSerializer<?>> entry : map.entrySet()) {
/* 43 */       uafGsonBuilder.registerTypeAdapter(entry.getKey(), entry.getValue());
/*    */     }
/*    */     
/* 46 */     uafGsonBuilder.excludeFieldsWithModifiers(new int[] { 504 });
/*    */   }
/*    */ 
/*    */   
/*    */   public static Gson gson() {
/* 51 */     if (gson == null) {
/* 52 */       gson = uafGsonBuilder.create();
/*    */     }
/*    */     
/* 55 */     return gson;
/*    */   }
/*    */ 
/*    */   
/*    */   protected static Map<Class<?>, UafMessageSerializer<?>> getSerializers() {
/* 60 */     Map<Class<?>, UafMessageSerializer<?>> serializer = new HashMap<>();
/* 61 */     serializer.put(GetUAFRequest.class, new GetUAFRequestSerializer());
/* 62 */     serializer.put(ReturnUAFRequest.class, new ReturnUAFRequestSerializer());
/* 63 */     serializer.put(SendUAFResponse.class, new SendUAFResponseSerializer());
/* 64 */     serializer.put(ServerResponse.class, new ServerResponseSerializer());
/* 65 */     serializer.put(RegistrationRequest.class, new RegistrationRequestSerializer());
/* 66 */     serializer.put(RegistrationResponse.class, new RegistrationResponseSerializer());
/* 67 */     serializer.put(AuthenticationRequest.class, new AuthenticationRequestSerializer());
/* 68 */     serializer.put(AuthenticationResponse.class, new AuthenticationResponseSerializer());
/* 69 */     serializer.put(DeregistrationRequest.class, new DeregistrationRequestSerializer());
/* 70 */     serializer.put(AuthenticatorRegistrationAssertion.class, new AuthenticatorRegistrationAssertionSerializer());
/* 71 */     serializer.put(AuthenticatorSignAssertion.class, new AuthenticatorSignAssertionSerializer());
/* 72 */     serializer.put(UAFMessage.class, new UAFProtocolMessageSerializer());
/* 73 */     serializer.put(StatusCodes.class, new StatusCodeSerializer());
/* 74 */     serializer.put(RpContext.class, new RpContextSerializer());
/*    */     
/* 76 */     return serializer;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\UafSerializeUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */