/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*    */ import com.dreammirae.mmth.fido.transport.IUafTransport;
/*    */ import com.dreammirae.mmth.fido.uaf.IUafProtocolMessage;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonDeserializer;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonParseException;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import com.google.gson.JsonSerializer;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ public abstract class UafMessageSerializer<T>
/*    */   implements JsonSerializer<T>, JsonDeserializer<T>
/*    */ {
/*    */   protected static final String MEM_OP = "op";
/*    */   protected static final String MEM_STATUS_CODE = "statusCode";
/*    */   
/*    */   public JsonElement serialize(T bean, Type type, JsonSerializationContext context) {
/* 23 */     validation(bean);
/* 24 */     return serializeImp(bean, type, context);
/*    */   }
/*    */ 
/*    */   
/*    */   public T deserialize(JsonElement json, Type type, JsonDeserializationContext context) throws JsonParseException {
/* 29 */     T obj = deserializeImp(json, type, context);
/* 30 */     validation(obj);
/* 31 */     return obj;
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract JsonElement serializeImp(T paramT, Type paramType, JsonSerializationContext paramJsonSerializationContext);
/*    */   
/*    */   protected abstract T deserializeImp(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext);
/*    */   
/*    */   protected void validation(T bean) {
/*    */     try {
/* 41 */       if (bean instanceof IUafTransport) {
/* 42 */         ((IUafTransport)bean).validate();
/*    */       }
/* 44 */       else if (bean instanceof IUafProtocolMessage) {
/* 45 */         ((IUafProtocolMessage)bean).validateField();
/*    */       } 
/* 47 */     } catch (IllegalUafFieldException e) {
/* 48 */       throw new IllegalUafJsonException(e.getStatusCode(), e.getMessage(), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\UafMessageSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */