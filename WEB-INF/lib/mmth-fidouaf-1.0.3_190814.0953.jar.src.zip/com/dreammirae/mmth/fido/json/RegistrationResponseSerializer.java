/*     */ package com.dreammirae.mmth.fido.json;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorRegistrationAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.FinalChallengeParams;
/*     */ import com.dreammirae.mmth.fido.uaf.OperationHeader;
/*     */ import com.dreammirae.mmth.fido.uaf.RegistrationResponse;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistrationResponseSerializer
/*     */   extends UafMessageSerializer<RegistrationResponse>
/*     */ {
/*     */   private static final String MEM_HEADER = "header";
/*     */   private static final String MEM_FC_PARAMS = "fcParams";
/*     */   private static final String MEM_ASSERTIONS = "assertions";
/*     */   
/*     */   protected JsonElement serializeImp(RegistrationResponse bean, Type type, JsonSerializationContext context) {
/*  25 */     JsonObject jsonObject = new JsonObject();
/*     */     
/*  27 */     if (bean.getHeader() != null) {
/*  28 */       jsonObject.add("header", context.serialize(bean.getHeader()));
/*     */     }
/*     */     
/*  31 */     if (bean.getFcParams() != null) {
/*  32 */       String jsonFcParams = UafSerializeUtils.gson().toJson(bean.getFcParams());
/*  33 */       jsonObject.addProperty("fcParams", Base64Utils.encodeUrl(jsonFcParams));
/*     */     } 
/*     */     
/*  36 */     if (bean.getAssertions() != null) {
/*  37 */       jsonObject.add("assertions", context.serialize(bean.getAssertions()));
/*     */     }
/*     */     
/*  40 */     return (JsonElement)jsonObject;
/*     */   }
/*     */ 
/*     */   
/*     */   protected RegistrationResponse deserializeImp(JsonElement json, Type type, JsonDeserializationContext context) {
/*     */     FinalChallengeParams params;
/*  46 */     JsonObject jsonObject = json.getAsJsonObject();
/*     */     
/*  48 */     if (!jsonObject.has("header") || jsonObject.get("header").isJsonNull()) {
/*  49 */       throw new IllegalUafJsonException("RegistrationResponse[header] must not be missing / null");
/*     */     }
/*     */     
/*  52 */     JsonElement elHeader = jsonObject.get("header");
/*  53 */     if (!elHeader.isJsonObject()) {
/*  54 */       throw new IllegalUafJsonException("RegistrationResponse[header] is invalid format.");
/*     */     }
/*     */     
/*  57 */     if (!jsonObject.has("fcParams")) {
/*  58 */       throw new IllegalUafJsonException("RegistrationResponse[fcParams] must not be missing.");
/*     */     }
/*     */     
/*  61 */     JsonElement elFcParam = jsonObject.get("fcParams");
/*  62 */     if (elFcParam.isJsonNull() || !elFcParam.isJsonPrimitive()) {
/*  63 */       throw new IllegalUafJsonException("RegistrationResponse[fcParams] must not be null.");
/*     */     }
/*     */     
/*  66 */     if (!jsonObject.has("assertions")) {
/*  67 */       throw new IllegalUafJsonException("RegistrationResponse[assertions] must not be missing.");
/*     */     }
/*     */     
/*  70 */     JsonElement elAssertion = jsonObject.get("assertions");
/*  71 */     if (!elAssertion.isJsonArray()) {
/*  72 */       throw new IllegalUafJsonException("RegistrationResponse[assertions] is invalid.");
/*     */     }
/*     */ 
/*     */     
/*  76 */     OperationHeader header = (OperationHeader)context.deserialize(elHeader, OperationHeader.class);
/*     */ 
/*     */ 
/*     */     
/*  80 */     String fcParams = elFcParam.getAsString();
/*     */     
/*  82 */     if (!Base64Utils.isBase64(fcParams)) {
/*  83 */       throw new IllegalUafJsonException("RegistrationResponse[fcParams] must be base64url encoded.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  89 */       String decFcParms = Base64Utils.decode(fcParams);
/*  90 */       params = (FinalChallengeParams)UafSerializeUtils.gson().fromJson(decFcParms, FinalChallengeParams.class);
/*  91 */     } catch (Exception e) {
/*  92 */       throw new IllegalUafJsonException("RegistrationResponse[fcParams] serialization is invalid.");
/*     */     } 
/*     */     
/*  95 */     AuthenticatorRegistrationAssertion[] assertions = (AuthenticatorRegistrationAssertion[])context.deserialize(elAssertion, AuthenticatorRegistrationAssertion[].class);
/*     */     
/*  97 */     RegistrationResponse response = new RegistrationResponse();
/*     */     
/*  99 */     response.setHeader(header);
/* 100 */     response.setFcParams(fcParams);
/* 101 */     response.setFcParamsDeserialized(params);
/* 102 */     response.setAssertions(assertions);
/*     */     
/* 104 */     return response;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\RegistrationResponseSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */