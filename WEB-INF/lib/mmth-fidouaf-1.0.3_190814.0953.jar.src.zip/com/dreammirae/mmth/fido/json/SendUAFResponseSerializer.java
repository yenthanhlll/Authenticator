/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*    */ import com.dreammirae.mmth.fido.transport.SendUAFResponse;
/*    */ import com.dreammirae.mmth.fido.transport.UAFMessage;
/*    */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*    */ import com.dreammirae.mmth.util.StringUtils;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SendUAFResponseSerializer
/*    */   extends UafMessageSerializer<SendUAFResponse>
/*    */ {
/*    */   private static final String MEM_UAF_RESPONSE = "uafResponse";
/*    */   private static final String MEM_CONTEXT = "context";
/*    */   
/*    */   protected JsonElement serializeImp(SendUAFResponse bean, Type type, JsonSerializationContext ctx) {
/* 23 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 25 */     if (bean.getUafResponse() != null) {
/* 26 */       jsonObject.addProperty("uafResponse", UafSerializeUtils.gson().toJson(bean.getUafResponse()));
/*    */     }
/*    */     
/* 29 */     if (bean.getContext() != null) {
/* 30 */       jsonObject.addProperty("context", UafSerializeUtils.gson().toJson(bean.getContext()));
/*    */     }
/*    */     
/* 33 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected SendUAFResponse deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/* 39 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 41 */     if (!jsonObject.has("uafResponse")) {
/* 42 */       throw new IllegalUafJsonException("SendUAFResponse[uafResponse] must not be missing.");
/*    */     }
/*    */     
/* 45 */     JsonElement el = jsonObject.get("uafResponse");
/*    */     
/* 47 */     UAFMessage uafRespMessage = null;
/*    */     
/* 49 */     String uafResponse = jsonObject.get("uafResponse").getAsString();
/*    */     try {
/* 51 */       uafRespMessage = (UAFMessage)UafSerializeUtils.gson().fromJson(uafResponse, UAFMessage.class);
/* 52 */     } catch (Exception e) {
/* 53 */       uafRespMessage = new UAFMessage();
/* 54 */       uafRespMessage.setUafProtocolMessage(uafResponse);
/*    */     } 
/*    */     
/* 57 */     if (StringUtils.isEmpty(uafRespMessage.getUafProtocolMessage())) {
/* 58 */       throw new IllegalUafJsonException("SendUAFResponse[uafResponse] must not be null/empty.");
/*    */     }
/*    */ 
/*    */     
/* 62 */     SendUAFResponse uafResp = new SendUAFResponse();
/* 63 */     uafResp.setUafResponse(uafRespMessage);
/*    */     
/* 65 */     if (jsonObject.has("context")) {
/* 66 */       el = jsonObject.get("context");
/* 67 */       String rpCtxStr = null;
/*    */       
/* 69 */       if (el.isJsonObject()) {
/*    */         
/* 71 */         JsonObject ctxObj = el.getAsJsonObject();
/* 72 */         rpCtxStr = UafSerializeUtils.gson().toJson((JsonElement)ctxObj);
/* 73 */       } else if (el.isJsonPrimitive()) {
/*    */         
/* 75 */         rpCtxStr = el.getAsString();
/*    */       } else {
/* 77 */         throw new IllegalUafJsonException("GetUAFRequest[context] is invalid");
/*    */       } 
/*    */       
/* 80 */       RpContext rpCtx = (RpContext)UafSerializeUtils.gson().fromJson(rpCtxStr, RpContext.class);
/* 81 */       uafResp.setContext(rpCtx);
/*    */     } 
/*    */     
/* 84 */     return uafResp;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\SendUAFResponseSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */