/*     */ package com.dreammirae.mmth.fido.json;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalTLVException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.fido.tlv.UAFV1AuthAssertionParser;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.AuthAssertionLocator;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorSignAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.Extension;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticatorSignAssertionSerializer
/*     */   extends UafMessageSerializer<AuthenticatorSignAssertion>
/*     */ {
/*     */   private static final String MEM_ASSERTION_SCHEME = "assertionScheme";
/*     */   private static final String MEM_ASSERTION = "assertion";
/*     */   private static final String MEM_EXTS = "exts";
/*     */   
/*     */   protected JsonElement serializeImp(AuthenticatorSignAssertion bean, Type type, JsonSerializationContext ctx) {
/*  28 */     JsonObject jsonObject = new JsonObject();
/*     */     
/*  30 */     if (bean.getAssertionScheme() != null) {
/*  31 */       jsonObject.addProperty("assertionScheme", bean.getAssertionScheme());
/*     */     }
/*     */     
/*  34 */     if (bean.getAssertion() != null) {
/*  35 */       jsonObject.addProperty("assertion", bean.getAssertion());
/*     */     }
/*     */     
/*  38 */     if (bean.getExts() != null) {
/*  39 */       jsonObject.add("exts", ctx.serialize(bean.getExts()));
/*     */     }
/*     */     
/*  42 */     return (JsonElement)jsonObject;
/*     */   }
/*     */   
/*     */   protected AuthenticatorSignAssertion deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/*     */     byte[] payload;
/*     */     AuthAssertionLocator loc;
/*  48 */     JsonObject jsonObject = json.getAsJsonObject();
/*     */     
/*  50 */     if (!jsonObject.has("assertionScheme") || jsonObject.get("assertionScheme").isJsonNull()) {
/*  51 */       throw new IllegalUafJsonException("AuthenticatorSignAssertion[assertionScheme] must not missing/null.");
/*     */     }
/*     */ 
/*     */     
/*  55 */     if (!jsonObject.has("assertion") || jsonObject.get("assertion").isJsonNull()) {
/*  56 */       throw new IllegalUafJsonException("AuthenticatorSignAssertion[assertion] must not missing/null.");
/*     */     }
/*     */     
/*  59 */     String assertion = jsonObject.get("assertion").getAsString();
/*  60 */     if (!Base64Utils.isBase64(assertion)) {
/*  61 */       throw new IllegalUafJsonException("AuthenticatorSignAssertion[assertion] must be base64url encoded.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  67 */       payload = Base64Utils.decodeRaw(assertion);
/*  68 */     } catch (Exception e) {
/*  69 */       throw new IllegalUafJsonException("AuthenticatorSignAssertion[assertion] is invalid.");
/*     */     } 
/*     */ 
/*     */     
/*  73 */     if (payload.length > 4096) {
/*  74 */       throw new IllegalUafJsonException("AuthenticatorSignAssertion[assertion] must not be greater than 4096");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  81 */       UAFV1AuthAssertionParser uAFV1AuthAssertionParser = new UAFV1AuthAssertionParser();
/*  82 */       loc = (AuthAssertionLocator)uAFV1AuthAssertionParser.parsePayload(payload);
/*  83 */     } catch (IllegalTLVException e) {
/*  84 */       throw new IllegalUafJsonException(e.getStatusCode(), e.getMessage(), e);
/*  85 */     } catch (Exception e) {
/*  86 */       throw new IllegalUafJsonException("AuthenticatorSignAssertion[assertion] is invalid.");
/*     */     } 
/*     */ 
/*     */     
/*  90 */     AuthenticatorSignAssertion signAssertion = new AuthenticatorSignAssertion();
/*     */     
/*  92 */     signAssertion.setAssertionScheme(jsonObject.get("assertionScheme").getAsString());
/*  93 */     signAssertion.setAssertion(assertion);
/*  94 */     signAssertion.setAssertionLocator(loc);
/*     */     
/*  96 */     if (jsonObject.has("exts")) {
/*  97 */       Extension[] exts = (Extension[])ctx.deserialize(jsonObject.get("exts"), Extension[].class);
/*  98 */       signAssertion.setExts(exts);
/*     */     } 
/*     */     
/* 101 */     return signAssertion;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\AuthenticatorSignAssertionSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */