/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.Operation;
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*    */ import com.dreammirae.mmth.fido.transport.GetUAFRequest;
/*    */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetUAFRequestSerializer
/*    */   extends UafMessageSerializer<GetUAFRequest>
/*    */ {
/*    */   private static final String MEM_OP = "op";
/*    */   private static final String MEM_CONTEXT = "context";
/*    */   
/*    */   protected JsonElement serializeImp(GetUAFRequest bean, Type type, JsonSerializationContext ctx) {
/* 22 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 24 */     if (bean.getOp() != null) {
/* 25 */       jsonObject.addProperty("op", bean.getOp().name());
/*    */     }
/*    */     
/* 28 */     if (bean.getContext() != null) {
/* 29 */       jsonObject.addProperty("context", UafSerializeUtils.gson().toJson(bean.getContext()));
/*    */     }
/*    */     
/* 32 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected GetUAFRequest deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/* 38 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 40 */     GetUAFRequest req = new GetUAFRequest();
/*    */     
/* 42 */     if (!jsonObject.has("op")) {
/* 43 */       throw new IllegalUafJsonException("GetUAFRequest[Op] must not be empty/missing.");
/*    */     }
/*    */     
/* 46 */     String op = jsonObject.get("op").getAsString();
/*    */     
/* 48 */     if (!Operation.isValidOperation(op)) {
/* 49 */       throw new IllegalUafJsonException("GetUAFRequest[Op] is invalid. Op can only be 'Reg', 'Auth', 'Dereg'. input=" + op);
/*    */     }
/*    */     
/* 52 */     req.setOp(Operation.valueOf(op));
/*    */ 
/*    */     
/* 55 */     if (jsonObject.has("context")) {
/* 56 */       JsonElement el = jsonObject.get("context");
/*    */       
/* 58 */       String rpCtxStr = null;
/*    */       
/* 60 */       if (el.isJsonObject()) {
/*    */         
/* 62 */         JsonObject ctxObj = el.getAsJsonObject();
/* 63 */         rpCtxStr = UafSerializeUtils.gson().toJson((JsonElement)ctxObj);
/* 64 */       } else if (el.isJsonPrimitive()) {
/*    */         
/* 66 */         rpCtxStr = el.getAsString();
/*    */       } else {
/* 68 */         throw new IllegalUafJsonException("GetUAFRequest[context] is invalid");
/*    */       } 
/*    */       
/* 71 */       RpContext rpCtx = (RpContext)UafSerializeUtils.gson().fromJson(rpCtxStr, RpContext.class);
/*    */ 
/*    */       
/* 74 */       req.setContext(rpCtx);
/*    */     } 
/*    */     
/* 77 */     return req;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\GetUAFRequestSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */