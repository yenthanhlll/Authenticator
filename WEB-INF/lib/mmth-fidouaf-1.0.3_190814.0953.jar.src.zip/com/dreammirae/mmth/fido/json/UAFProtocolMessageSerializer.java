/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.transport.UAFMessage;
/*    */ import com.dreammirae.mmth.fido.transport.additional.AdditionalMapData;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UAFProtocolMessageSerializer
/*    */   extends UafMessageSerializer<UAFMessage>
/*    */ {
/*    */   private static final String MEM_UAF_PROTOCOL_MESSAGE = "uafProtocolMessage";
/*    */   private static final String MEM_ADDITIONAL_DATA = "additionalData";
/*    */   private static final String MEM_HEADER = "header";
/*    */   
/*    */   protected JsonElement serializeImp(UAFMessage bean, Type type, JsonSerializationContext ctx) {
/* 26 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 28 */     if (!StringUtils.isEmpty(bean.getUafProtocolMessage())) {
/* 29 */       jsonObject.addProperty("uafProtocolMessage", bean.getUafProtocolMessage());
/*    */     }
/*    */     
/* 32 */     if (bean.getAdditionalData() != null) {
/* 33 */       jsonObject.add("additionalData", bean.getAdditionalData().jsonSerialization(ctx));
/*    */     }
/*    */     
/* 36 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected UAFMessage deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/* 42 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 44 */     UAFMessage message = new UAFMessage();
/*    */     
/* 46 */     if (jsonObject.has("uafProtocolMessage")) {
/* 47 */       message.setUafProtocolMessage(jsonObject.get("uafProtocolMessage").getAsString());
/*    */     }
/*    */     
/* 50 */     if (jsonObject.has("additionalData")) {
/* 51 */       JsonObject jsonAdditional = jsonObject.get("additionalData").getAsJsonObject();
/*    */       
/* 53 */       AdditionalMapData data = new AdditionalMapData();
/* 54 */       data.jsonDeserialization(jsonAdditional, ctx);
/*    */     } 
/*    */ 
/*    */     
/* 58 */     if (jsonObject.has("header")) {
/* 59 */       message.setUafProtocolMessage(json.getAsString());
/*    */     }
/*    */ 
/*    */     
/* 63 */     return message;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\UAFProtocolMessageSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */