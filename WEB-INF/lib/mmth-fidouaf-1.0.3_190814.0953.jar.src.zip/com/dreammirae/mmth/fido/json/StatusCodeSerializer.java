/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ public class StatusCodeSerializer
/*    */   extends UafMessageSerializer<StatusCodes>
/*    */ {
/*    */   protected JsonElement serializeImp(StatusCodes bean, Type type, JsonSerializationContext ctx) {
/* 14 */     return ctx.serialize(bean.getId());
/*    */   }
/*    */ 
/*    */   
/*    */   protected StatusCodes deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/* 19 */     long statusCode = json.getAsLong();
/* 20 */     return StatusCodes.getUAFStatusCodes(statusCode);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\StatusCodeSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */