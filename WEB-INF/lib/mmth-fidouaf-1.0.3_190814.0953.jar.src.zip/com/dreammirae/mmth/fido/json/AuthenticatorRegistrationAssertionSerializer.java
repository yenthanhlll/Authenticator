/*     */ package com.dreammirae.mmth.fido.json;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalTLVException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
/*     */ import com.dreammirae.mmth.fido.tlv.UAFV1RegAssertionParser;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.RegAssertionLocator;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorRegistrationAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.Extension;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticatorRegistrationAssertionSerializer
/*     */   extends UafMessageSerializer<AuthenticatorRegistrationAssertion>
/*     */ {
/*     */   private static final String MEM_ASSERTION_SCHEME = "assertionScheme";
/*     */   private static final String MEM_ASSERTION = "assertion";
/*     */   private static final String MEM_TC_DISPLAY_PNG_CHAS = "tcDisplayPNGCharacteristics";
/*     */   private static final String MEM_EXTS = "exts";
/*     */   
/*     */   protected JsonElement serializeImp(AuthenticatorRegistrationAssertion bean, Type type, JsonSerializationContext ctx) {
/*  32 */     JsonObject jsonObject = new JsonObject();
/*     */     
/*  34 */     if (bean.getAssertionScheme() != null) {
/*  35 */       jsonObject.addProperty("assertionScheme", bean.getAssertionScheme());
/*     */     }
/*     */     
/*  38 */     if (bean.getAssertion() != null) {
/*  39 */       jsonObject.addProperty("assertion", bean.getAssertion());
/*     */     }
/*     */     
/*  42 */     if (bean.getTcDisplayPNGCharacteristics() != null) {
/*  43 */       jsonObject.add("tcDisplayPNGCharacteristics", ctx.serialize(bean.getTcDisplayPNGCharacteristics()));
/*     */     }
/*     */     
/*  46 */     if (bean.getExts() != null) {
/*  47 */       jsonObject.add("exts", ctx.serialize(bean.getExts()));
/*     */     }
/*     */     
/*  50 */     return (JsonElement)jsonObject;
/*     */   }
/*     */ 
/*     */   
/*     */   protected AuthenticatorRegistrationAssertion deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/*     */     byte[] payload;
/*     */     RegAssertionLocator loc;
/*  57 */     JsonObject jsonObject = json.getAsJsonObject();
/*     */     
/*  59 */     if (!jsonObject.has("assertionScheme") || jsonObject.get("assertionScheme").isJsonNull()) {
/*  60 */       throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[assertionScheme] must not missing/null.");
/*     */     }
/*     */ 
/*     */     
/*  64 */     if (!jsonObject.has("assertion") || jsonObject.get("assertion").isJsonNull()) {
/*  65 */       throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[assertion] must not missing/null.");
/*     */     }
/*     */     
/*  68 */     String assertion = jsonObject.get("assertion").getAsString();
/*  69 */     if (!Base64Utils.isBase64(assertion)) {
/*  70 */       throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[assertion] must be base64url encoded.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  76 */       payload = Base64Utils.decodeRaw(assertion);
/*  77 */     } catch (Exception e) {
/*  78 */       throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[assertion] is invalid.");
/*     */     } 
/*     */ 
/*     */     
/*  82 */     if (payload.length > 4096) {
/*  83 */       throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[assertion] must not be greater than 4096");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  90 */       UAFV1RegAssertionParser uAFV1RegAssertionParser = new UAFV1RegAssertionParser();
/*  91 */       loc = (RegAssertionLocator)uAFV1RegAssertionParser.parsePayload(payload);
/*  92 */     } catch (IllegalTLVException e) {
/*  93 */       throw new IllegalUafJsonException(e.getStatusCode(), e.getMessage(), e);
/*  94 */     } catch (Exception e) {
/*  95 */       throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[assertion] is invalid.");
/*     */     } 
/*     */     
/*  98 */     AuthenticatorRegistrationAssertion regAssertion = new AuthenticatorRegistrationAssertion();
/*  99 */     regAssertion.setAssertionScheme(jsonObject.get("assertionScheme").getAsString());
/* 100 */     regAssertion.setAssertion(assertion);
/* 101 */     regAssertion.setAssertionLocator(loc);
/*     */     
/* 103 */     if (jsonObject.has("tcDisplayPNGCharacteristics")) {
/*     */       try {
/* 105 */         DisplayPNGCharacteristicsDescriptor[] tcDisplayPNGCharacteristics = (DisplayPNGCharacteristicsDescriptor[])ctx.deserialize(jsonObject
/* 106 */             .get("tcDisplayPNGCharacteristics"), DisplayPNGCharacteristicsDescriptor[].class);
/* 107 */         regAssertion.setTcDisplayPNGCharacteristics(tcDisplayPNGCharacteristics);
/* 108 */       } catch (Exception e) {
/* 109 */         throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[tcDisplayPNGCharacteristics] is invalid.");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (jsonObject.has("exts")) {
/*     */       
/*     */       try {
/* 118 */         Extension[] exts = (Extension[])ctx.deserialize(jsonObject.get("exts"), Extension[].class);
/* 119 */         regAssertion.setExts(exts);
/* 120 */       } catch (Exception e) {
/* 121 */         throw new IllegalUafJsonException("AuthenticatorRegistrationAssertion[exts] is invalid.");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 126 */     return regAssertion;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\AuthenticatorRegistrationAssertionSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */