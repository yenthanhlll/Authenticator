/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ import com.dreammirae.mmth.fido.transport.ServerResponse;
/*    */ import com.dreammirae.mmth.fido.transport.Token;
/*    */ import com.dreammirae.mmth.fido.transport.UAFMessage;
/*    */ import com.dreammirae.mmth.util.StringUtils;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerResponseSerializer
/*    */   extends UafMessageSerializer<ServerResponse>
/*    */ {
/*    */   private static final String MEM_DESCRIPTION = "description";
/*    */   private static final String MEM_ADDITIONAL_TOKEN = "additionalTokens";
/*    */   private static final String MEM_LOCATION = "location";
/*    */   private static final String MEM_POST_DATA = "postData";
/*    */   private static final String MEM_NEW_UAF_REQUEST = "newUAFRequest";
/*    */   
/*    */   protected JsonElement serializeImp(ServerResponse bean, Type type, JsonSerializationContext ctx) {
/* 26 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 28 */     if (bean.getStatusCode() != null) {
/* 29 */       jsonObject.add("statusCode", ctx.serialize(bean.getStatusCode()));
/*    */     }
/*    */     
/* 32 */     if (!StringUtils.isEmpty(bean.getDescription())) {
/* 33 */       jsonObject.addProperty("description", bean.getDescription());
/*    */     }
/*    */     
/* 36 */     if (bean.getAdditionalTokens() != null) {
/* 37 */       jsonObject.add("additionalTokens", ctx.serialize(bean.getAdditionalTokens()));
/*    */     }
/*    */     
/* 40 */     if (!StringUtils.isEmpty(bean.getLocation())) {
/* 41 */       jsonObject.addProperty("location", bean.getLocation());
/*    */     }
/*    */     
/* 44 */     if (!StringUtils.isEmpty(bean.getPostData())) {
/* 45 */       jsonObject.addProperty("postData", bean.getPostData());
/*    */     }
/*    */     
/* 48 */     if (bean.getNewUAFRequest() != null) {
/* 49 */       jsonObject.addProperty("newUAFRequest", UafSerializeUtils.gson().toJson(bean.getNewUAFRequest()));
/*    */     }
/*    */     
/* 52 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ServerResponse deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/* 58 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 60 */     ServerResponse resp = new ServerResponse();
/*    */     
/* 62 */     if (jsonObject.has("statusCode")) {
/* 63 */       StatusCodes statCode = (StatusCodes)ctx.deserialize(jsonObject.get("statusCode"), StatusCodes.class);
/* 64 */       resp.setStatusCode(statCode);
/*    */     } 
/*    */     
/* 67 */     if (jsonObject.has("description")) {
/* 68 */       resp.setLocation(jsonObject.get("description").getAsString());
/*    */     }
/*    */     
/* 71 */     if (jsonObject.has("additionalTokens")) {
/* 72 */       Token[] addToken = (Token[])ctx.deserialize(jsonObject.get("additionalTokens"), Token[].class);
/* 73 */       resp.setAdditionalTokens(addToken);
/*    */     } 
/*    */     
/* 76 */     if (jsonObject.has("location")) {
/* 77 */       resp.setLocation(jsonObject.get("location").getAsString());
/*    */     }
/*    */     
/* 80 */     if (jsonObject.has("postData")) {
/* 81 */       resp.setPostData(jsonObject.get("postData").getAsString());
/*    */     }
/*    */     
/* 84 */     if (jsonObject.has("newUAFRequest")) {
/* 85 */       UAFMessage uafMessage = (UAFMessage)ctx.deserialize(jsonObject.get("newUAFRequest"), UAFMessage.class);
/* 86 */       resp.setNewUAFRequest(uafMessage);
/*    */     } 
/*    */     
/* 89 */     return resp;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\ServerResponseSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */