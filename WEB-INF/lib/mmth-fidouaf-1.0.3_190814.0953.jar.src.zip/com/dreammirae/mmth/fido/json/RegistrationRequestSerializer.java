/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.uaf.OperationHeader;
/*    */ import com.dreammirae.mmth.fido.uaf.Policy;
/*    */ import com.dreammirae.mmth.fido.uaf.RegistrationRequest;
/*    */ import com.dreammirae.mmth.util.StringUtils;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistrationRequestSerializer
/*    */   extends UafMessageSerializer<RegistrationRequest>
/*    */ {
/*    */   private static final String MEM_HEADER = "header";
/*    */   private static final String MEM_CHALLENGE = "challenge";
/*    */   private static final String MEM_USERNAME = "username";
/*    */   private static final String MEM_POLICY = "policy";
/*    */   
/*    */   protected JsonElement serializeImp(RegistrationRequest bean, Type type, JsonSerializationContext context) {
/* 24 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 26 */     if (bean.getHeader() != null) {
/* 27 */       jsonObject.add("header", context.serialize(bean.getHeader()));
/*    */     }
/*    */     
/* 30 */     if (!StringUtils.isEmpty(bean.getChallenge())) {
/* 31 */       jsonObject.addProperty("challenge", bean.getChallenge());
/*    */     }
/*    */     
/* 34 */     if (!StringUtils.isEmpty(bean.getUsername())) {
/* 35 */       jsonObject.addProperty("username", bean.getUsername());
/*    */     }
/*    */     
/* 38 */     if (bean.getPolicy() != null) {
/* 39 */       jsonObject.add("policy", context.serialize(bean.getPolicy()));
/*    */     }
/*    */     
/* 42 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected RegistrationRequest deserializeImp(JsonElement json, Type type, JsonDeserializationContext context) {
/* 48 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 50 */     RegistrationRequest request = new RegistrationRequest();
/*    */     
/* 52 */     if (jsonObject.has("header")) {
/* 53 */       OperationHeader header = (OperationHeader)context.deserialize(jsonObject.get("header"), OperationHeader.class);
/* 54 */       request.setHeader(header);
/*    */     } 
/*    */     
/* 57 */     if (jsonObject.has("challenge")) {
/* 58 */       request.setChallenge(jsonObject.get("challenge").getAsString());
/*    */     }
/*    */     
/* 61 */     if (jsonObject.has("username")) {
/* 62 */       request.setUsername(jsonObject.get("username").getAsString());
/*    */     }
/*    */     
/* 65 */     if (jsonObject.has("policy")) {
/* 66 */       Policy policy = (Policy)context.deserialize(jsonObject.get("policy"), Policy.class);
/* 67 */       request.setPolicy(policy);
/*    */     } 
/*    */     
/* 70 */     return request;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\RegistrationRequestSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */