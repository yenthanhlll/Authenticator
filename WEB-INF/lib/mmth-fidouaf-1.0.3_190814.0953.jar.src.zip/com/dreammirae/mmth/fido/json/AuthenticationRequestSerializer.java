/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.uaf.AuthenticationRequest;
/*    */ import com.dreammirae.mmth.fido.uaf.OperationHeader;
/*    */ import com.dreammirae.mmth.fido.uaf.Policy;
/*    */ import com.dreammirae.mmth.fido.uaf.Transaction;
/*    */ import com.dreammirae.mmth.util.StringUtils;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationRequestSerializer
/*    */   extends UafMessageSerializer<AuthenticationRequest>
/*    */ {
/*    */   private static final String MEM_HEADER = "header";
/*    */   private static final String MEM_CHALLENGE = "challenge";
/*    */   private static final String MEM_POLICY = "policy";
/*    */   private static final String MEM_TRANSACTION = "transaction";
/*    */   
/*    */   protected JsonElement serializeImp(AuthenticationRequest bean, Type type, JsonSerializationContext context) {
/* 25 */     JsonObject jsonObject = new JsonObject();
/*    */     
/* 27 */     if (bean.getHeader() != null) {
/* 28 */       jsonObject.add("header", context.serialize(bean.getHeader()));
/*    */     }
/*    */     
/* 31 */     if (!StringUtils.isEmpty(bean.getChallenge())) {
/* 32 */       jsonObject.addProperty("challenge", bean.getChallenge());
/*    */     }
/*    */     
/* 35 */     if (bean.getPolicy() != null) {
/* 36 */       jsonObject.add("policy", context.serialize(bean.getPolicy()));
/*    */     }
/*    */     
/* 39 */     if (bean.getTransaction() != null) {
/* 40 */       jsonObject.add("transaction", context.serialize(bean.getTransaction()));
/*    */     }
/*    */     
/* 43 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected AuthenticationRequest deserializeImp(JsonElement json, Type type, JsonDeserializationContext context) {
/* 49 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 51 */     AuthenticationRequest request = new AuthenticationRequest();
/*    */     
/* 53 */     if (jsonObject.has("header")) {
/* 54 */       OperationHeader header = (OperationHeader)context.deserialize(jsonObject.get("header"), OperationHeader.class);
/* 55 */       request.setHeader(header);
/*    */     } 
/*    */     
/* 58 */     if (jsonObject.has("challenge")) {
/* 59 */       request.setChallenge(jsonObject.get("challenge").getAsString());
/*    */     }
/*    */     
/* 62 */     if (jsonObject.has("policy")) {
/* 63 */       Policy policy = (Policy)context.deserialize(jsonObject.get("policy"), Policy.class);
/* 64 */       request.setPolicy(policy);
/*    */     } 
/*    */     
/* 67 */     if (jsonObject.has("transaction")) {
/* 68 */       Transaction[] transaction = (Transaction[])context.deserialize(jsonObject.get("transaction"), Transaction[].class);
/* 69 */       request.setTransaction(transaction);
/*    */     } 
/*    */     
/* 72 */     return request;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\AuthenticationRequestSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */