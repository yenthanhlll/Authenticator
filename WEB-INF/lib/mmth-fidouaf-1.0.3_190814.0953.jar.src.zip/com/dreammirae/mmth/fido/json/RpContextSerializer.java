/*    */ package com.dreammirae.mmth.fido.json;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ public class RpContextSerializer
/*    */   extends UafMessageSerializer<RpContext>
/*    */ {
/*    */   protected JsonElement serializeImp(RpContext bean, Type type, JsonSerializationContext ctx) {
/* 15 */     JsonObject jsonObject = new JsonObject();
/* 16 */     bean.jsonSerialize(jsonObject, type, ctx);
/* 17 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected RpContext deserializeImp(JsonElement json, Type type, JsonDeserializationContext ctx) {
/* 23 */     JsonObject jsonObject = json.getAsJsonObject();
/*    */     
/* 25 */     RpContext rpContext = new RpContext();
/*    */     
/* 27 */     rpContext.jsonDeserialization(jsonObject, ctx);
/*    */     
/* 29 */     return rpContext;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\json\RpContextSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */