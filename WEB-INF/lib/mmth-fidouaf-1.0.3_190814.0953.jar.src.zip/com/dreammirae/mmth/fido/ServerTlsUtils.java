/*     */ package com.dreammirae.mmth.fido;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.uaf.ChannelBinding;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.notary.SHA;
/*     */ import java.net.URL;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerTlsUtils
/*     */ {
/*  30 */   private static final Logger LOG = LoggerFactory.getLogger(ServerTlsUtils.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChannelBinding[] readServerTlsInformation(String rpServerUrl) {
/*     */     try {
/*  36 */       SSLContext sslContext = SSLContext.getInstance("SSL");
/*  37 */       sslContext.init(null, new TrustManager[] { new X509TrustManagerImp() }, new SecureRandom());
/*  38 */       HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
/*  39 */       HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifierImp());
/*     */       
/*  41 */       URL destinationURL = new URL(rpServerUrl);
/*  42 */       HttpsURLConnection conn = (HttpsURLConnection)destinationURL.openConnection();
/*  43 */       conn.connect();
/*     */       
/*  45 */       Certificate[] certs = conn.getServerCertificates();
/*  46 */       int len = certs.length;
/*  47 */       ChannelBinding[] channelBindings = new ChannelBinding[len];
/*     */       
/*  49 */       for (int i = 0; i < len; i++) {
/*  50 */         if (certs[i] instanceof X509Certificate) {
/*     */           
/*     */           try {
/*  53 */             X509Certificate x509Cert = (X509Certificate)certs[i];
/*  54 */             x509Cert.checkValidity();
/*     */             
/*  56 */             byte[] encCert = x509Cert.getEncoded();
/*     */             
/*  58 */             ChannelBinding cb = new ChannelBinding();
/*  59 */             cb.setTlsServerCertificate(Base64Utils.encodeUrl(encCert));
/*  60 */             cb.setServerEndPoint(Base64Utils.encodeUrl(SHA.sha256(encCert)));
/*     */             
/*  62 */             channelBindings[i] = cb;
/*     */             
/*  64 */             if (LOG.isDebugEnabled()) {
/*  65 */               LOG.debug("Certificate is active for current date");
/*     */             }
/*  67 */           } catch (CertificateExpiredException|java.security.cert.CertificateEncodingException|java.security.cert.CertificateNotYetValidException cee) {
/*     */             
/*  69 */             LOG.error("Certificate is expired", cee);
/*     */           }
/*     */         
/*  72 */         } else if (LOG.isDebugEnabled()) {
/*  73 */           LOG.debug("Certificate is not X509Certificate type.");
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  78 */       return channelBindings;
/*     */     }
/*  80 */     catch (KeyManagementException|java.security.NoSuchAlgorithmException|java.io.IOException e) {
/*  81 */       LOG.error("Failed to read remote server certication... ", e);
/*     */ 
/*     */       
/*  84 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class HostnameVerifierImp implements HostnameVerifier {
/*     */     private HostnameVerifierImp() {}
/*     */     
/*     */     public boolean verify(String hostname, SSLSession session) {
/*  92 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class X509TrustManagerImp
/*     */     implements X509TrustManager
/*     */   {
/*     */     private X509TrustManagerImp() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public X509Certificate[] getAcceptedIssuers() {
/* 114 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\ServerTlsUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */