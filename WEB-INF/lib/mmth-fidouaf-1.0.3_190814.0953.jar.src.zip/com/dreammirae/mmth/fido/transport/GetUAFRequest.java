/*     */ package com.dreammirae.mmth.fido.transport;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GetUAFRequest
/*     */   implements IUafTransport
/*     */ {
/*     */   private Operation op;
/*     */   private String previousRequest;
/*     */   private RpContext context;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public Operation getOp() {
/*  42 */     return this.op;
/*     */   }
/*     */   
/*     */   public void setOp(Operation op) {
/*  46 */     this.op = op;
/*     */   }
/*     */   
/*     */   public String getPreviousRequest() {
/*  50 */     return this.previousRequest;
/*     */   }
/*     */   
/*     */   public void setPreviousRequest(String previousRequest) {
/*  54 */     this.previousRequest = previousRequest;
/*     */   }
/*     */   
/*     */   public RpContext getContext() {
/*  58 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(RpContext context) {
/*  62 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() throws IllegalUafFieldException {
/*  68 */     if (this.op == null) {
/*  69 */       throw new IllegalUafFieldException("GetUAFRequest[Op] must not be null.");
/*     */     }
/*     */   }
/*     */   
/*     */   public String toShorten() {
/*  74 */     StringBuilder sb = new StringBuilder();
/*  75 */     sb.append("GetUAFRequest [op=").append(this.op).append(", context=").append(this.context).append("]");
/*  76 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  81 */     StringBuilder sb = new StringBuilder();
/*  82 */     sb.append("GetUAFRequest [op=").append(this.op).append(", previousRequest=").append(this.previousRequest)
/*  83 */       .append(", context=").append(this.context).append("]");
/*  84 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/*  94 */     out.writeInt(1);
/*  95 */     SerializationUtils.writeSafeObject(out, this.op);
/*  96 */     SerializationUtils.writeSafeUTF(out, this.previousRequest);
/*  97 */     SerializationUtils.writeSafeObject(out, this.context);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 101 */     int ver = in.readInt();
/* 102 */     if (1 == ver) {
/* 103 */       this.op = (Operation)SerializationUtils.readSafeObject(in);
/* 104 */       this.previousRequest = SerializationUtils.readSafeUTF(in);
/* 105 */       this.context = (RpContext)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\GetUAFRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */