/*    */ package com.dreammirae.mmth.fido.transport.additional;
/*    */ 
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdditionalMapData
/*    */   extends AdditionalData
/*    */ {
/*    */   private Map<String, JsonElement> mapData;
/*    */   
/*    */   protected void jsonSerializationImp(JsonObject parent, JsonSerializationContext ctx) {
/* 18 */     if (this.mapData == null) {
/*    */       return;
/*    */     }
/*    */     
/* 22 */     for (Map.Entry<String, JsonElement> entry : this.mapData.entrySet()) {
/* 23 */       parent.add(entry.getKey(), entry.getValue());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void jsonDeserializationImp(JsonObject additionalData, JsonDeserializationContext ctx) {
/* 30 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)additionalData.entrySet()) {
/*    */       
/* 32 */       if (this.mapData == null) {
/* 33 */         this.mapData = new HashMap<>();
/*    */       }
/*    */       
/* 36 */       this.mapData.put(entry.getKey(), entry.getValue());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, JsonElement> getMapData() {
/* 42 */     return this.mapData;
/*    */   }
/*    */   
/*    */   public void setMapData(Map<String, JsonElement> mapData) {
/* 46 */     this.mapData = mapData;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\additional\AdditionalMapData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */