/*    */ package com.dreammirae.mmth.fido.transport.jwt;
/*    */ 
/*    */ import com.dreammirae.mmth.misc.Base64Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JWTHeader
/*    */ {
/*    */   private static final String JSON_FORMAT = "{\"alg\":\"%s\",\"typ\":\"%s\"}";
/*    */   private static final String DEFAULT_ALG = "HS256";
/*    */   private static final String DEFAULT_TYP = "JWT";
/* 12 */   private String alg = "HS256";
/* 13 */   private String typ = "JWT";
/*    */ 
/*    */ 
/*    */   
/*    */   public JWTHeader() {}
/*    */ 
/*    */   
/*    */   public JWTHeader(String alg, String typ) {
/* 21 */     this.alg = alg;
/* 22 */     this.typ = typ;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAlg() {
/* 29 */     return this.alg;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAlg(String alg) {
/* 36 */     this.alg = alg;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTyp() {
/* 43 */     return this.typ;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTyp(String typ) {
/* 50 */     this.typ = typ;
/*    */   }
/*    */   
/*    */   public String getHeader() {
/* 54 */     return Base64Utils.encodeUrl(String.format("{\"alg\":\"%s\",\"typ\":\"%s\"}", new Object[] { this.alg, this.typ }));
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\jwt\JWTHeader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */