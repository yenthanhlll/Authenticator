/*     */ package com.dreammirae.mmth.fido.transport;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReturnUAFRequest
/*     */   implements IUafTransport
/*     */ {
/*     */   private StatusCodes statusCode;
/*     */   private UAFMessage uafRequest;
/*     */   private Operation op;
/*     */   private Long lifetimeMillis;
/*     */   private RpContext context;
/*     */   private transient boolean isConformanceRequest;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public ReturnUAFRequest() {}
/*     */   
/*     */   public ReturnUAFRequest(boolean isConformanceRequest) {
/*  57 */     this.isConformanceRequest = isConformanceRequest;
/*     */   }
/*     */   
/*     */   public StatusCodes getStatusCode() {
/*  61 */     return this.statusCode;
/*     */   }
/*     */   
/*     */   public void setStatusCode(StatusCodes statusCode) {
/*  65 */     this.statusCode = statusCode;
/*     */   }
/*     */   
/*     */   public UAFMessage getUafRequest() {
/*  69 */     return this.uafRequest;
/*     */   }
/*     */   
/*     */   public void setUafRequest(UAFMessage uafRequest) {
/*  73 */     this.uafRequest = uafRequest;
/*     */   }
/*     */   
/*     */   public Operation getOp() {
/*  77 */     return this.op;
/*     */   }
/*     */   
/*     */   public void setOp(Operation op) {
/*  81 */     this.op = op;
/*     */   }
/*     */   
/*     */   public Long getLifetimeMillis() {
/*  85 */     return this.lifetimeMillis;
/*     */   }
/*     */   
/*     */   public void setLifetimeMillis(Long lifetimeMillis) {
/*  89 */     this.lifetimeMillis = lifetimeMillis;
/*     */   }
/*     */   
/*     */   public RpContext getContext() {
/*  93 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(RpContext context) {
/*  97 */     this.context = context;
/*     */   }
/*     */   
/*     */   public boolean isConformanceRequest() {
/* 101 */     return this.isConformanceRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public void validate() throws IllegalUafFieldException {
/* 106 */     if (this.statusCode == null) {
/* 107 */       throw new IllegalUafFieldException("ReturnUAFRequest[StatusCode] must not be null/empty/missing");
/*     */     }
/*     */     
/* 110 */     if (StatusCodes.CODE_1200.equals(this.statusCode)) {
/*     */       
/* 112 */       if (this.op == null) {
/* 113 */         throw new IllegalUafFieldException("ReturnUAFRequest[Op] should not be null/empty/missing");
/*     */       }
/*     */       
/* 116 */       if (this.uafRequest == null) {
/* 117 */         throw new IllegalUafFieldException("ReturnUAFRequest[uafRequest] should not be null/empty/missing");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toShorten() {
/* 124 */     StringBuilder sb = new StringBuilder();
/* 125 */     sb.append("ReturnUAFRequest [statusCode=").append((this.statusCode != null) ? this.statusCode.getId() : null).append(", op=").append(this.op).append("]");
/* 126 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 131 */     StringBuilder sb = new StringBuilder();
/* 132 */     sb.append("ReturnUAFRequest [statusCode=").append(this.statusCode).append(", uafRequest=").append(this.uafRequest)
/* 133 */       .append(", op=").append(this.op).append(", lifetimeMillis=").append(this.lifetimeMillis).append("]");
/* 134 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 144 */     out.writeInt(1);
/* 145 */     SerializationUtils.writeSafeObject(out, this.statusCode);
/* 146 */     SerializationUtils.writeSafeObject(out, this.uafRequest);
/* 147 */     SerializationUtils.writeSafeObject(out, this.op);
/* 148 */     out.writeLong(this.lifetimeMillis.longValue());
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 152 */     int ver = in.readInt();
/* 153 */     if (1 == ver) {
/* 154 */       this.statusCode = (StatusCodes)SerializationUtils.readSafeObject(in);
/* 155 */       this.uafRequest = (UAFMessage)SerializationUtils.readSafeObject(in);
/* 156 */       this.op = (Operation)SerializationUtils.readSafeObject(in);
/* 157 */       this.lifetimeMillis = Long.valueOf(in.readLong());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\ReturnUAFRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */