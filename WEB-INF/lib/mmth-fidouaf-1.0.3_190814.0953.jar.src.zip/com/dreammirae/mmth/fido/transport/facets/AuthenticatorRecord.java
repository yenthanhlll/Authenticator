/*    */ package com.dreammirae.mmth.fido.transport.facets;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatorRecord
/*    */ {
/*    */   private static final String DLM = "#";
/*    */   private String AAID;
/*    */   private String KeyID;
/*    */   private String deviceId;
/*    */   private String username;
/*    */   private String status;
/*    */   
/*    */   public String getAAID() {
/* 15 */     return this.AAID;
/*    */   }
/*    */   public AuthenticatorRecord setAAID(String aAID) {
/* 18 */     this.AAID = aAID;
/* 19 */     return this;
/*    */   }
/*    */   public String getKeyID() {
/* 22 */     return this.KeyID;
/*    */   }
/*    */   public AuthenticatorRecord setKeyID(String keyID) {
/* 25 */     this.KeyID = keyID;
/* 26 */     return this;
/*    */   }
/*    */   public String getDeviceId() {
/* 29 */     return this.deviceId;
/*    */   }
/*    */   public AuthenticatorRecord setDeviceId(String deviceId) {
/* 32 */     this.deviceId = deviceId;
/* 33 */     return this;
/*    */   }
/*    */   public String getUsername() {
/* 36 */     return this.username;
/*    */   }
/*    */   public AuthenticatorRecord setUsername(String username) {
/* 39 */     this.username = username;
/* 40 */     return this;
/*    */   }
/*    */   public String getStatus() {
/* 43 */     return this.status;
/*    */   }
/*    */   public AuthenticatorRecord setStatus(String status) {
/* 46 */     this.status = status;
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return this.AAID + "#" + this.KeyID;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\facets\AuthenticatorRecord.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */