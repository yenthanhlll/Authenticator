/*    */ package com.dreammirae.mmth.fido.transport.facets;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.uaf.Version;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ public class TrustedFacets
/*    */ {
/*    */   private Version version;
/*    */   private String[] ids;
/*    */   
/*    */   public Version getVersion() {
/* 13 */     return this.version;
/*    */   }
/*    */   
/*    */   public TrustedFacets setVersion(Version version) {
/* 17 */     this.version = version;
/* 18 */     return this;
/*    */   }
/*    */   
/*    */   public String[] getIds() {
/* 22 */     return this.ids;
/*    */   }
/*    */   
/*    */   public TrustedFacets setIds(String[] ids) {
/* 26 */     this.ids = ids;
/* 27 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 32 */     StringBuilder builder = new StringBuilder();
/* 33 */     builder.append("TrustedFacets [version=").append(this.version).append(", ids=").append(Arrays.toString((Object[])this.ids)).append("]");
/* 34 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\facets\TrustedFacets.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */