/*     */ package com.dreammirae.mmth.fido.transport.context;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.bean.HashMapWrapper;
/*     */ import com.dreammirae.mmth.util.io.BeanMapperUtils;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RpContext
/*     */   extends HashMapWrapper
/*     */ {
/*     */   private static final String REGEX_USERNAME = "^[a-zA-Z0-9]{1}[a-zA-Z0-9\\!\\@\\#\\?\\-\\_\\.]{3,127}$";
/*     */   private static final String REGEX_DEVICE_ID = "^[A-Z0-9]{64}$";
/*     */   private static final String REGEX_DEVICE_TYPE = "^(AD|AW|IU|AI)$";
/*     */   private static final String REGEX_PKGNAME = "^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+[a-zA-Z0-9_]$";
/*     */   private static final String REGEX_ISSUE_CODE = "^[0-9]{5}$";
/*     */   private static final String REGEX_TRAN_INFO = "^[A-Z0-9]+$";
/*     */   private static final String DEFAULT_MODEL = "N/A";
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public RpContext() {
/* 154 */     super(5);
/*     */   }
/*     */   
/*     */   public RpContext(Map<? extends String, ? extends Object> m) {
/* 158 */     super(m);
/*     */   }
/*     */   
/*     */   public static <T> T convertToObject(RpContext data, Class<T> clazz) throws Exception {
/* 162 */     return (T)BeanMapperUtils.mapToBean((Map)data, clazz);
/*     */   }
/*     */   
/*     */   public static RpContext convertFromObject(Object obj) throws Exception {
/* 166 */     Map<String, Object> map = BeanMapperUtils.beanToMap(obj);
/* 167 */     return new RpContext(map);
/*     */   }
/*     */   
/*     */   public void validateRequiredField(String... keys) throws FidoUafStatusCodeException {
/* 171 */     for (String key : keys) {
/* 172 */       if (get(key) == null) {
/* 173 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[" + key + "] is requried in RP Context.");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void set(String key, Object value) {
/* 179 */     put(key, value);
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 183 */     String val = (String)get("userName", String.class);
/*     */     
/* 185 */     if (StringUtils.isEmpty(val)) {
/* 186 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[userName] is requried in RP Context.");
/*     */     }
/*     */     
/* 189 */     if (!val.matches("^[a-zA-Z0-9]{1}[a-zA-Z0-9\\!\\@\\#\\?\\-\\_\\.]{3,127}$")) {
/* 190 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[userName] is illegal value. The userName(4~128) only accept uppercase and lowercase letters, numbers and special characters('.','!','@','#','$,'-','_','?'). value=" + val);
/*     */     }
/*     */     
/* 193 */     return val;
/*     */   }
/*     */   
/*     */   public String getDeviceId() {
/* 197 */     String val = (String)get("deviceId", String.class);
/*     */     
/* 199 */     if (StringUtils.isEmpty(val)) {
/* 200 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[deviceId] is requried in RP Context.");
/*     */     }
/*     */     
/* 203 */     if (!val.matches("^[A-Z0-9]{64}$")) {
/* 204 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[deviceId] is illegal value. The deviceId length must be 64. value=" + val);
/*     */     }
/*     */     
/* 207 */     return val;
/*     */   }
/*     */   
/*     */   public String getDeviceType() {
/* 211 */     String val = (String)get("deviceType", String.class);
/*     */     
/* 213 */     if (StringUtils.isEmpty(val)) {
/* 214 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[deviceType] is requried in RP Context.");
/*     */     }
/*     */     
/* 217 */     if (!val.matches("^(AD|AW|IU|AI)$")) {
/* 218 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[deviceType] is illegal value. The deviceType only accept AD,AW,AI and IU. value=" + val);
/*     */     }
/*     */     
/* 221 */     return val;
/*     */   }
/*     */   
/*     */   public String getNewDeviceId() {
/* 225 */     String val = (String)get("newDeviceId", String.class);
/*     */     
/* 227 */     if (StringUtils.isEmpty(val)) {
/* 228 */       return val;
/*     */     }
/*     */     
/* 231 */     if (!val.matches("^[A-Z0-9]{64}$")) {
/* 232 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[newDeviceId] is illegal value. The deviceId length must be 64. value=" + val);
/*     */     }
/*     */     
/* 235 */     return val;
/*     */   }
/*     */   
/*     */   public String getNewDeviceType() {
/* 239 */     String val = (String)get("newDeviceType", String.class);
/*     */     
/* 241 */     if (StringUtils.isEmpty(val)) {
/* 242 */       return val;
/*     */     }
/*     */     
/* 245 */     if (!val.matches("^(AD|AW|IU|AI)$")) {
/* 246 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[newDeviceType] is illegal value. The deviceType only accept AD,AW,AI and IU. value=" + val);
/*     */     }
/*     */     
/* 249 */     return val;
/*     */   }
/*     */   
/*     */   public String getPkgName() {
/* 253 */     String val = (String)get("pkgName", String.class);
/*     */     
/* 255 */     if (StringUtils.isEmpty(val)) {
/* 256 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[pkgName] is requried in RP Context.");
/*     */     }
/* 258 */     if (!val.matches("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+[a-zA-Z0-9_]$")) {
/* 259 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[deviceType] is illegal value. It is not pkgName expression. value=" + val);
/*     */     }
/*     */     
/* 262 */     return val;
/*     */   }
/*     */   
/*     */   public String getModel() {
/* 266 */     String val = (String)get("model", String.class);
/*     */     
/* 268 */     if (StringUtils.isEmpty(val)) {
/* 269 */       return "N/A";
/*     */     }
/*     */     
/* 272 */     return val;
/*     */   }
/*     */   
/*     */   public String getAlias(String defaultValue) {
/* 276 */     String val = (String)get("alias", String.class);
/*     */     
/* 278 */     if (StringUtils.isEmpty(val)) {
/* 279 */       return defaultValue;
/*     */     }
/*     */     
/* 282 */     return val;
/*     */   }
/*     */   
/*     */   public String getIssueCode() {
/* 286 */     String val = (String)get("issueCode", String.class);
/*     */     
/* 288 */     if (StringUtils.isEmpty(val)) {
/* 289 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[issueCode] is requried in RP Context.");
/*     */     }
/*     */     
/* 292 */     if (!val.matches("^[0-9]{5}$")) {
/* 293 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[issueCode] is illegal value. It must be 5-digit number characters. value=" + val);
/*     */     }
/*     */     
/* 296 */     return val;
/*     */   }
/*     */   
/*     */   public String getTranInfo() {
/* 300 */     String val = (String)get("tranInfo", String.class);
/*     */     
/* 302 */     if (!StringUtils.isEmpty(val) && 
/* 303 */       !val.matches("^[A-Z0-9]+$")) {
/* 304 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Field[tranInfo] is illegal value. The deviceId length must be 64. value=" + val);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 309 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   public void jsonSerialize(JsonObject jsonObject, Type type, JsonSerializationContext ctx) {
/* 314 */     if (containsKey("issueCodeTotalAttempts")) {
/* 315 */       Integer num = (Integer)get("issueCodeTotalAttempts", Integer.class);
/* 316 */       jsonObject.addProperty("issueCodeTotalAttempts", num);
/*     */     } 
/*     */     
/* 319 */     if (containsKey("issueCodeNumOfFailures")) {
/* 320 */       Integer num = (Integer)get("issueCodeNumOfFailures", Integer.class);
/* 321 */       jsonObject.addProperty("issueCodeNumOfFailures", num);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void jsonDeserialization(JsonObject json, JsonDeserializationContext ctx) {
/* 327 */     for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)json.entrySet()) {
/*     */       
/* 329 */       String key = entry.getKey();
/*     */       
/* 331 */       if (key.equals("deviceId") || key.equals("deviceType") || key
/* 332 */         .equals("newDeviceId") || key.equals("newDeviceType") || key
/* 333 */         .equals("tranInfo") || key.equals("AAID")) {
/*     */         
/* 335 */         String str1 = ((JsonElement)entry.getValue()).getAsString();
/* 336 */         put(key, str1.toUpperCase()); continue;
/*     */       } 
/* 338 */       if (key.equals("userVerification")) {
/*     */         
/* 340 */         Long val = Long.valueOf(((JsonElement)entry.getValue()).getAsLong());
/* 341 */         put(key, val);
/*     */         
/*     */         continue;
/*     */       } 
/* 345 */       String str = ((JsonElement)entry.getValue()).getAsString();
/* 346 */       put(key, str);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface RpContextKeys {
/*     */     public static final String USERNAME = "userName";
/*     */     public static final String DEVICE_ID = "deviceId";
/*     */     public static final String DEVICE_TYPE = "deviceType";
/*     */     public static final String PACKAGE_NAME = "pkgName";
/*     */     public static final String MODEL = "model";
/*     */     public static final String ALIAS = "alias";
/*     */     public static final String ISSUE_CODE = "issueCode";
/*     */     public static final String TRANSACTION = "transaction";
/*     */     public static final String TRAN_INFO = "tranInfo";
/*     */     public static final String AAID = "AAID";
/*     */     public static final String USER_VERIFICATION = "userVerification";
/*     */     public static final String TID = "tid";
/*     */     public static final String EXTERNAL_REQUEST_EXPIRED = "externalRequestExpired";
/*     */     public static final String TOKEN_ID = "tokenId";
/*     */     public static final String ISSUE_CODE_TOTAL_ATTEMPTS = "issueCodeTotalAttempts";
/*     */     public static final String ISSUE_CODE_NUM_OF_FAILURES = "issueCodeNumOfFailures";
/*     */     public static final String IS_LOCAL_FAILED_REQUEST = "isLocalFailedRequest";
/*     */     public static final String NEW_DEVICE_ID = "newDeviceId";
/*     */     public static final String NEW_DEVICE_TYPE = "newDeviceType";
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\context\RpContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */