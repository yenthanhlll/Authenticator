/*    */ package com.dreammirae.mmth.fido.transport.jwt;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.handler.notary.INotary;
/*    */ import com.dreammirae.mmth.fido.handler.notary.SimpleNotary;
/*    */ 
/*    */ public class JWTCreator
/*    */ {
/*  8 */   private static final String DEFAULT_HEADER = (new JWTHeader()).getHeader();
/*  9 */   private static final INotary DEFAULT_NOTARY = SimpleNotary.getInstance();
/*    */   
/*    */   private static final String DELIMITER_JWT = ".";
/*    */ 
/*    */   
/*    */   public static String getJWT(JWTHeader header, JWTBody body) {
/* 15 */     StringBuilder sb = new StringBuilder(64);
/* 16 */     sb.append(header.getHeader()).append(".").append(body.getBody());
/* 17 */     String sign = DEFAULT_NOTARY.sign(sb.toString());
/* 18 */     sb.append(".").append(sign);
/* 19 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public static String getJWT(JWTBody body) {
/* 23 */     StringBuilder sb = new StringBuilder(64);
/* 24 */     sb.append(DEFAULT_HEADER).append(".").append(body.getBody());
/* 25 */     String sign = DEFAULT_NOTARY.sign(sb.toString());
/* 26 */     sb.append(".").append(sign);
/* 27 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\jwt\JWTCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */