/*     */ package com.dreammirae.mmth.fido.transport;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerResponse
/*     */   implements IUafTransport
/*     */ {
/*     */   private StatusCodes statusCode;
/*     */   private String description;
/*     */   private Token[] additionalTokens;
/*     */   private String location;
/*     */   private String postData;
/*     */   private UAFMessage newUAFRequest;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public StatusCodes getStatusCode() {
/*  38 */     return this.statusCode;
/*     */   }
/*     */   
/*     */   public void setStatusCode(StatusCodes statusCode) {
/*  42 */     this.statusCode = statusCode;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  46 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  50 */     this.description = description;
/*     */   }
/*     */   
/*     */   public Token[] getAdditionalTokens() {
/*  54 */     return this.additionalTokens;
/*     */   }
/*     */   
/*     */   public void setAdditionalTokens(Token[] additionalTokens) {
/*  58 */     this.additionalTokens = additionalTokens;
/*     */   }
/*     */   
/*     */   public String getLocation() {
/*  62 */     return this.location;
/*     */   }
/*     */   
/*     */   public void setLocation(String location) {
/*  66 */     this.location = location;
/*     */   }
/*     */   
/*     */   public String getPostData() {
/*  70 */     return this.postData;
/*     */   }
/*     */   
/*     */   public void setPostData(String postData) {
/*  74 */     this.postData = postData;
/*     */   }
/*     */   
/*     */   public UAFMessage getNewUAFRequest() {
/*  78 */     return this.newUAFRequest;
/*     */   }
/*     */   
/*     */   public void setNewUAFRequest(UAFMessage newUAFRequest) {
/*  82 */     this.newUAFRequest = newUAFRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() throws IllegalUafFieldException {
/*  88 */     if (this.statusCode == null) {
/*  89 */       throw new IllegalUafFieldException("ServerResponse[StatusCode] must not be null/empty/missing");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toShorten() {
/*  95 */     StringBuilder sb = new StringBuilder();
/*  96 */     sb.append("ServerResponse [statusCode=").append((this.statusCode != null) ? this.statusCode.getId() : null).append("]");
/*  97 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 102 */     StringBuilder builder = new StringBuilder();
/* 103 */     builder.append("ServerResponse [statusCode=").append(this.statusCode).append(", description=").append(this.description)
/* 104 */       .append(", additionalTokens=").append(Arrays.toString((Object[])this.additionalTokens)).append(", location=")
/* 105 */       .append(this.location).append(", postData=").append(this.postData).append(", newUAFRequest=")
/* 106 */       .append(this.newUAFRequest).append("]");
/* 107 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 117 */     out.writeInt(1);
/* 118 */     SerializationUtils.writeSafeObject(out, this.statusCode);
/* 119 */     SerializationUtils.writeSafeUTF(out, this.description);
/* 120 */     SerializationUtils.writeSafeObject(out, this.additionalTokens);
/* 121 */     SerializationUtils.writeSafeUTF(out, this.location);
/* 122 */     SerializationUtils.writeSafeUTF(out, this.postData);
/* 123 */     SerializationUtils.writeSafeObject(out, this.newUAFRequest);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 127 */     int ver = in.readInt();
/* 128 */     if (ver == 1) {
/* 129 */       this.statusCode = (StatusCodes)SerializationUtils.readSafeObject(in);
/* 130 */       this.description = SerializationUtils.readSafeUTF(in);
/* 131 */       this.additionalTokens = (Token[])SerializationUtils.readSafeObject(in);
/* 132 */       this.location = SerializationUtils.readSafeUTF(in);
/* 133 */       this.postData = SerializationUtils.readSafeUTF(in);
/* 134 */       this.newUAFRequest = (UAFMessage)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\ServerResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */