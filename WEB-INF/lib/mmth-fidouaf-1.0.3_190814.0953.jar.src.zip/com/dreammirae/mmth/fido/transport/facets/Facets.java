/*    */ package com.dreammirae.mmth.fido.transport.facets;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class Facets
/*    */ {
/*    */   private TrustedFacets[] trustedFacets;
/*    */   
/*    */   public TrustedFacets[] getTrustedFacets() {
/* 10 */     return this.trustedFacets;
/*    */   }
/*    */   
/*    */   public void setTrustedFacets(TrustedFacets[] trustedFacets) {
/* 14 */     this.trustedFacets = trustedFacets;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 19 */     StringBuilder builder = new StringBuilder();
/* 20 */     builder.append("Facets [trustedFacets=").append(Arrays.toString((Object[])this.trustedFacets)).append("]");
/* 21 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\facets\Facets.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */