/*     */ package com.dreammirae.mmth.fido.transport.facets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistrationRecord
/*     */ {
/*     */   private AuthenticatorRecord authenticator;
/*     */   private String privateKey;
/*     */   private String SignCounter;
/*     */   private String AuthenticatorVersion;
/*     */   private String tcDisplayPNGCharacteristics;
/*     */   private String username;
/*     */   private String userId;
/*     */   private String deviceId;
/*     */   private String timeStamp;
/*     */   private String status;
/*     */   private String attestCert;
/*     */   private String attestDataToSign;
/*     */   private String attestSignature;
/*     */   private String attestVerifiedStatus;
/*     */   
/*     */   public AuthenticatorRecord getAuthenticator() {
/*  24 */     return this.authenticator;
/*     */   }
/*     */   public RegistrationRecord setAuthenticator(AuthenticatorRecord authenticator) {
/*  27 */     this.authenticator = authenticator;
/*  28 */     return this;
/*     */   }
/*     */   public String getPrivateKey() {
/*  31 */     return this.privateKey;
/*     */   }
/*     */   public RegistrationRecord setPrivateKey(String privateKey) {
/*  34 */     this.privateKey = privateKey;
/*  35 */     return this;
/*     */   }
/*     */   public String getSignCounter() {
/*  38 */     return this.SignCounter;
/*     */   }
/*     */   public RegistrationRecord setSignCounter(String signCounter) {
/*  41 */     this.SignCounter = signCounter;
/*  42 */     return this;
/*     */   }
/*     */   public String getAuthenticatorVersion() {
/*  45 */     return this.AuthenticatorVersion;
/*     */   }
/*     */   public RegistrationRecord setAuthenticatorVersion(String authenticatorVersion) {
/*  48 */     this.AuthenticatorVersion = authenticatorVersion;
/*  49 */     return this;
/*     */   }
/*     */   public String getTcDisplayPNGCharacteristics() {
/*  52 */     return this.tcDisplayPNGCharacteristics;
/*     */   }
/*     */   public RegistrationRecord setTcDisplayPNGCharacteristics(String tcDisplayPNGCharacteristics) {
/*  55 */     this.tcDisplayPNGCharacteristics = tcDisplayPNGCharacteristics;
/*  56 */     return this;
/*     */   }
/*     */   public String getUsername() {
/*  59 */     return this.username;
/*     */   }
/*     */   public RegistrationRecord setUsername(String username) {
/*  62 */     this.username = username;
/*  63 */     return this;
/*     */   }
/*     */   public String getUserId() {
/*  66 */     return this.userId;
/*     */   }
/*     */   public RegistrationRecord setUserId(String userId) {
/*  69 */     this.userId = userId;
/*  70 */     return this;
/*     */   }
/*     */   public String getDeviceId() {
/*  73 */     return this.deviceId;
/*     */   }
/*     */   public RegistrationRecord setDeviceId(String deviceId) {
/*  76 */     this.deviceId = deviceId;
/*  77 */     return this;
/*     */   }
/*     */   public String getTimeStamp() {
/*  80 */     return this.timeStamp;
/*     */   }
/*     */   public RegistrationRecord setTimeStamp(String timeStamp) {
/*  83 */     this.timeStamp = timeStamp;
/*  84 */     return this;
/*     */   }
/*     */   public String getStatus() {
/*  87 */     return this.status;
/*     */   }
/*     */   public RegistrationRecord setStatus(String status) {
/*  90 */     this.status = status;
/*  91 */     return this;
/*     */   }
/*     */   public String getAttestCert() {
/*  94 */     return this.attestCert;
/*     */   }
/*     */   public RegistrationRecord setAttestCert(String attestCert) {
/*  97 */     this.attestCert = attestCert;
/*  98 */     return this;
/*     */   }
/*     */   public String getAttestDataToSign() {
/* 101 */     return this.attestDataToSign;
/*     */   }
/*     */   public RegistrationRecord setAttestDataToSign(String attestDataToSign) {
/* 104 */     this.attestDataToSign = attestDataToSign;
/* 105 */     return this;
/*     */   }
/*     */   public String getAttestSignature() {
/* 108 */     return this.attestSignature;
/*     */   }
/*     */   public RegistrationRecord setAttestSignature(String attestSignature) {
/* 111 */     this.attestSignature = attestSignature;
/* 112 */     return this;
/*     */   }
/*     */   public String getAttestVerifiedStatus() {
/* 115 */     return this.attestVerifiedStatus;
/*     */   }
/*     */   public RegistrationRecord setAttestVerifiedStatus(String attestVerifiedStatus) {
/* 118 */     this.attestVerifiedStatus = attestVerifiedStatus;
/* 119 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\facets\RegistrationRecord.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */