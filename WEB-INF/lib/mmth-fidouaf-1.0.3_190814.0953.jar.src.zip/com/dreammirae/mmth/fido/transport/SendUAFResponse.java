/*    */ package com.dreammirae.mmth.fido.transport;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*    */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SendUAFResponse
/*    */   implements IUafTransport
/*    */ {
/*    */   private UAFMessage uafResponse;
/*    */   private RpContext context;
/*    */   private transient boolean isConformanceRequest;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public SendUAFResponse() {}
/*    */   
/*    */   public SendUAFResponse(boolean isConformanceRequest) {
/* 29 */     this.isConformanceRequest = isConformanceRequest;
/*    */   }
/*    */   
/*    */   public UAFMessage getUafResponse() {
/* 33 */     return this.uafResponse;
/*    */   }
/*    */   
/*    */   public void setUafResponse(UAFMessage uafResponse) {
/* 37 */     this.uafResponse = uafResponse;
/*    */   }
/*    */   
/*    */   public RpContext getContext() {
/* 41 */     return this.context;
/*    */   }
/*    */   
/*    */   public void setContext(RpContext context) {
/* 45 */     this.context = context;
/*    */   }
/*    */   
/*    */   public boolean isConformanceRequest() {
/* 49 */     return this.isConformanceRequest;
/*    */   }
/*    */ 
/*    */   
/*    */   public void validate() throws IllegalUafFieldException {
/* 54 */     if (this.uafResponse == null) {
/* 55 */       throw new IllegalUafFieldException("SendUAFResponse[uafResponse] must not be null/empty/missing.");
/*    */     }
/*    */     
/* 58 */     this.uafResponse.validate();
/*    */   }
/*    */   
/*    */   public String toShorten() {
/* 62 */     StringBuilder sb = new StringBuilder();
/* 63 */     sb.append("SendUAFResponse [context=").append(this.context).append("]");
/* 64 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     StringBuilder builder = new StringBuilder();
/* 70 */     builder.append("SendUAFResponse [uafResponse=").append(this.uafResponse).append(", context=").append(this.context)
/* 71 */       .append("]");
/* 72 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 82 */     out.writeInt(1);
/* 83 */     SerializationUtils.writeSafeObject(out, this.uafResponse);
/* 84 */     SerializationUtils.writeSafeObject(out, this.context);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 88 */     int ver = in.readInt();
/* 89 */     if (1 == ver) {
/* 90 */       this.uafResponse = (UAFMessage)SerializationUtils.readSafeObject(in);
/* 91 */       this.context = (RpContext)SerializationUtils.readSafeObject(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\SendUAFResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */