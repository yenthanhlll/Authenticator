package com.dreammirae.mmth.fido.transport.jwt;

public interface JWTBody {
  String getBody();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\jwt\JWTBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */