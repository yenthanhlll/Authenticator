/*    */ package com.dreammirae.mmth.fido.transport.additional;
/*    */ 
/*    */ import com.google.gson.JsonDeserializationContext;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.JsonSerializationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AdditionalData
/*    */ {
/*    */   public JsonElement jsonSerialization(JsonSerializationContext ctx) {
/* 19 */     JsonObject jsonObject = new JsonObject();
/* 20 */     jsonSerializationImp(jsonObject, ctx);
/* 21 */     return (JsonElement)jsonObject;
/*    */   }
/*    */   
/*    */   public void jsonDeserialization(JsonObject additionalData, JsonDeserializationContext ctx) {
/* 25 */     jsonDeserializationImp(additionalData, ctx);
/*    */   }
/*    */   
/*    */   protected abstract void jsonSerializationImp(JsonObject paramJsonObject, JsonSerializationContext paramJsonSerializationContext);
/*    */   
/*    */   protected abstract void jsonDeserializationImp(JsonObject paramJsonObject, JsonDeserializationContext paramJsonDeserializationContext);
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\additional\AdditionalData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */