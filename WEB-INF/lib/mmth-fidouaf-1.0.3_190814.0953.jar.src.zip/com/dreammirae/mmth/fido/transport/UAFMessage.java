/*     */ package com.dreammirae.mmth.fido.transport;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.transport.additional.AdditionalData;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UAFMessage
/*     */   implements IUafTransport
/*     */ {
/*     */   private String uafProtocolMessage;
/*     */   private AdditionalData additionalData;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public UAFMessage() {}
/*     */   
/*     */   public UAFMessage(String uafProtocolMessage) {
/*  50 */     this.uafProtocolMessage = uafProtocolMessage;
/*     */   }
/*     */   
/*     */   public String getUafProtocolMessage() {
/*  54 */     return this.uafProtocolMessage;
/*     */   }
/*     */   
/*     */   public void setUafProtocolMessage(String uafProtocolMessage) {
/*  58 */     this.uafProtocolMessage = uafProtocolMessage;
/*     */   }
/*     */   
/*     */   public AdditionalData getAdditionalData() {
/*  62 */     return this.additionalData;
/*     */   }
/*     */   
/*     */   public void setAdditionalData(AdditionalData additionalData) {
/*  66 */     this.additionalData = additionalData;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() throws IllegalUafFieldException {
/*  72 */     if (this.additionalData == null && StringUtils.isEmpty(this.uafProtocolMessage)) {
/*  73 */       throw new IllegalUafFieldException("UAFMessage[uafProtocolMessage] must not be null/empty/missing");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  79 */     StringBuilder builder = new StringBuilder();
/*  80 */     builder.append("RegReqUafMessage [uafProtocolMessage=").append(this.uafProtocolMessage).append(", additionalData=").append(this.additionalData).append("]");
/*  81 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/*  91 */     out.writeInt(1);
/*  92 */     SerializationUtils.writeSafeUTF(out, this.uafProtocolMessage);
/*  93 */     SerializationUtils.writeSafeObject(out, this.additionalData);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*  97 */     int ver = in.readInt();
/*  98 */     if (1 == ver) {
/*  99 */       this.uafProtocolMessage = SerializationUtils.readSafeUTF(in);
/* 100 */       this.additionalData = (AdditionalData)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\UAFMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */