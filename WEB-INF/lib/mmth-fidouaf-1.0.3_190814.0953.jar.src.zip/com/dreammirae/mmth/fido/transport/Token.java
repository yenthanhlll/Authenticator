/*    */ package com.dreammirae.mmth.fido.transport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Token
/*    */ {
/*    */   private TokenType type;
/*    */   private String value;
/*    */   
/*    */   public TokenType getType() {
/* 13 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(TokenType type) {
/* 17 */     this.type = type;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 21 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 25 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 30 */     StringBuilder builder = new StringBuilder();
/* 31 */     builder.append("Token [type=").append(this.type).append(", value=").append(this.value).append("]");
/* 32 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\Token.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */