/*    */ package com.dreammirae.mmth.fido.transport;
/*    */ 
/*    */ public enum TokenType
/*    */ {
/*  5 */   HTTP_COOKIE,
/*  6 */   OAUTH,
/*  7 */   OAUTH2,
/*  8 */   SAML1_1,
/*  9 */   SAML_2,
/* 10 */   JWT,
/* 11 */   OPENID_CONNECT;
/*    */   
/*    */   public static TokenType getTokenType(String name) {
/* 14 */     for (TokenType type : values()) {
/* 15 */       if (type.name().equalsIgnoreCase(name)) {
/* 16 */         return type;
/*    */       }
/*    */     } 
/*    */     
/* 20 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\transport\TokenType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */