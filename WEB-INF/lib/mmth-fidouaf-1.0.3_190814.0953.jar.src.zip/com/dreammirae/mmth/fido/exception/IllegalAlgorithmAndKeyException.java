/*    */ package com.dreammirae.mmth.fido.exception;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ 
/*    */ public class IllegalAlgorithmAndKeyException
/*    */   extends FidoUafStatusCodeException {
/*    */   public IllegalAlgorithmAndKeyException(StatusCodes statusCode, String message, Throwable cause) {
/*  8 */     super(statusCode, message, cause);
/*    */   }
/*    */   private static final long serialVersionUID = 1L;
/*    */   public IllegalAlgorithmAndKeyException(StatusCodes statusCode, String message) {
/* 12 */     super(statusCode, message);
/*    */   }
/*    */   
/*    */   public IllegalAlgorithmAndKeyException(StatusCodes statusCode, Throwable cause) {
/* 16 */     super(statusCode, cause);
/*    */   }
/*    */   
/*    */   public IllegalAlgorithmAndKeyException(StatusCodes statusCode) {
/* 20 */     super(statusCode);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\exception\IllegalAlgorithmAndKeyException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */