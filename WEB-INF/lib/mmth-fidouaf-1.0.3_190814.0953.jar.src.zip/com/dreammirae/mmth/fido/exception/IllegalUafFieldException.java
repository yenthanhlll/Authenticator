/*    */ package com.dreammirae.mmth.fido.exception;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalUafFieldException
/*    */   extends FidoUafStatusCodeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public IllegalUafFieldException(StatusCodes statusCode) {
/* 15 */     super(statusCode);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException(StatusCodes statusCode, String message, Throwable cause) {
/* 19 */     super(statusCode, message, cause);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException(StatusCodes statusCode, String message) {
/* 23 */     super(statusCode, message);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException(StatusCodes statusCode, Throwable cause) {
/* 27 */     super(statusCode, cause);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException() {
/* 31 */     this(StatusCodes.CODE_1498);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException(String message, Throwable cause) {
/* 35 */     this(StatusCodes.CODE_1498, message, cause);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException(String message) {
/* 39 */     this(StatusCodes.CODE_1498, message);
/*    */   }
/*    */   
/*    */   public IllegalUafFieldException(Throwable cause) {
/* 43 */     this(StatusCodes.CODE_1498, cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\exception\IllegalUafFieldException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */