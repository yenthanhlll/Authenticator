/*    */ package com.dreammirae.mmth.fido.exception;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ 
/*    */ public class FidoUafStatusCodeException
/*    */   extends RuntimeException {
/*    */   private final StatusCodes statusCode;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public FidoUafStatusCodeException(StatusCodes statusCode) {
/* 11 */     this.statusCode = statusCode;
/*    */   }
/*    */   
/*    */   public FidoUafStatusCodeException(StatusCodes statusCode, String message, Throwable cause) {
/* 15 */     super(message, cause);
/* 16 */     this.statusCode = statusCode;
/*    */   }
/*    */   
/*    */   public FidoUafStatusCodeException(StatusCodes statusCode, String message) {
/* 20 */     super(message);
/* 21 */     this.statusCode = statusCode;
/*    */   }
/*    */   
/*    */   public FidoUafStatusCodeException(StatusCodes statusCode, Throwable cause) {
/* 25 */     super(cause);
/* 26 */     this.statusCode = statusCode;
/*    */   }
/*    */   
/*    */   public StatusCodes getStatusCode() {
/* 30 */     return this.statusCode;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\exception\FidoUafStatusCodeException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */