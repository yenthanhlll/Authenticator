/*    */ package com.dreammirae.mmth.fido.exception;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ import com.google.gson.JsonParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalUafJsonException
/*    */   extends JsonParseException
/*    */ {
/*    */   private final StatusCodes statusCodes;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public IllegalUafJsonException(StatusCodes statusCodes, String msg, Throwable cause) {
/* 23 */     super(msg, cause);
/* 24 */     this.statusCodes = statusCodes;
/*    */   }
/*    */   
/*    */   public IllegalUafJsonException(StatusCodes statusCodes, String msg) {
/* 28 */     super(msg);
/* 29 */     this.statusCodes = statusCodes;
/*    */   }
/*    */   
/*    */   public IllegalUafJsonException(StatusCodes statusCodes, Throwable cause) {
/* 33 */     super(cause);
/* 34 */     this.statusCodes = statusCodes;
/*    */   }
/*    */   
/*    */   public IllegalUafJsonException(String msg, Throwable cause) {
/* 38 */     this(StatusCodes.CODE_1498, msg, cause);
/*    */   }
/*    */   
/*    */   public IllegalUafJsonException(String msg) {
/* 42 */     this(StatusCodes.CODE_1498, msg);
/*    */   }
/*    */   
/*    */   public IllegalUafJsonException(Throwable cause) {
/* 46 */     this(StatusCodes.CODE_1498, cause);
/*    */   }
/*    */   
/*    */   public StatusCodes getStatusCode() {
/* 50 */     return this.statusCodes;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\exception\IllegalUafJsonException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */