/*    */ package com.dreammirae.mmth.fido.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FidoUafParsingException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public FidoUafParsingException() {}
/*    */   
/*    */   public FidoUafParsingException(String message, Throwable cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public FidoUafParsingException(String message) {
/* 20 */     super(message);
/*    */   }
/*    */   
/*    */   public FidoUafParsingException(Throwable cause) {
/* 24 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\exception\FidoUafParsingException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */