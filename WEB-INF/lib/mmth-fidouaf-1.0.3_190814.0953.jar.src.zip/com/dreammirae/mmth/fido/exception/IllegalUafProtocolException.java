/*    */ package com.dreammirae.mmth.fido.exception;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.StatusCodes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalUafProtocolException
/*    */   extends FidoUafStatusCodeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public IllegalUafProtocolException(StatusCodes statusCode, String message, Throwable cause) {
/* 15 */     super(statusCode, message, cause);
/*    */   }
/*    */   
/*    */   public IllegalUafProtocolException(StatusCodes statusCode, String message) {
/* 19 */     super(statusCode, message);
/*    */   }
/*    */   
/*    */   public IllegalUafProtocolException(StatusCodes statusCode, Throwable cause) {
/* 23 */     super(statusCode, cause);
/*    */   }
/*    */   
/*    */   public IllegalUafProtocolException(StatusCodes statusCode) {
/* 27 */     super(statusCode);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\exception\IllegalUafProtocolException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */