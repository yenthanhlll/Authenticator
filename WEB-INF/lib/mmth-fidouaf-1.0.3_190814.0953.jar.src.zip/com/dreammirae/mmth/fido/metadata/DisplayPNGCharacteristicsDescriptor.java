/*     */ package com.dreammirae.mmth.fido.metadata;
/*     */ 
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayPNGCharacteristicsDescriptor
/*     */   implements Serializable
/*     */ {
/*     */   private Integer width;
/*     */   private Integer height;
/*     */   private Byte bitDepth;
/*     */   private Byte colorType;
/*     */   private Byte compression;
/*     */   private Byte filter;
/*     */   private Byte interlace;
/*     */   private RGBPalletteEntry[] plte;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public Integer getWidth() {
/*  34 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(Integer width) {
/*  38 */     this.width = width;
/*     */   }
/*     */   
/*     */   public Integer getHeight() {
/*  42 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(Integer height) {
/*  46 */     this.height = height;
/*     */   }
/*     */   
/*     */   public Byte getBitDepth() {
/*  50 */     return this.bitDepth;
/*     */   }
/*     */   
/*     */   public void setBitDepth(Byte bitDepth) {
/*  54 */     this.bitDepth = bitDepth;
/*     */   }
/*     */   
/*     */   public Byte getColorType() {
/*  58 */     return this.colorType;
/*     */   }
/*     */   
/*     */   public void setColorType(Byte colorType) {
/*  62 */     this.colorType = colorType;
/*     */   }
/*     */   
/*     */   public Byte getCompression() {
/*  66 */     return this.compression;
/*     */   }
/*     */   
/*     */   public void setCompression(Byte compression) {
/*  70 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public Byte getFilter() {
/*  74 */     return this.filter;
/*     */   }
/*     */   
/*     */   public void setFilter(Byte filter) {
/*  78 */     this.filter = filter;
/*     */   }
/*     */   
/*     */   public Byte getInterlace() {
/*  82 */     return this.interlace;
/*     */   }
/*     */   
/*     */   public void setInterlace(Byte interlace) {
/*  86 */     this.interlace = interlace;
/*     */   }
/*     */   
/*     */   public RGBPalletteEntry[] getPlte() {
/*  90 */     return this.plte;
/*     */   }
/*     */   
/*     */   public void setPlte(RGBPalletteEntry[] plte) {
/*  94 */     this.plte = plte;
/*     */   }
/*     */ 
/*     */   
/*     */   public long imageAreaCode() {
/*  99 */     long result = 0L;
/* 100 */     if (this.width != null) {
/* 101 */       result |= (0xFFFFFFFFL & this.width.intValue()) << 32L;
/*     */     }
/*     */     
/* 104 */     if (this.height != null) {
/* 105 */       result |= 0xFFFFFFFFL & this.height.intValue();
/*     */     }
/*     */     
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 116 */     int prime = 31;
/* 117 */     int result = 1;
/* 118 */     result = 31 * result + ((this.bitDepth == null) ? 0 : this.bitDepth.hashCode());
/* 119 */     result = 31 * result + ((this.colorType == null) ? 0 : this.colorType.hashCode());
/* 120 */     result = 31 * result + ((this.compression == null) ? 0 : this.compression.hashCode());
/* 121 */     result = 31 * result + ((this.filter == null) ? 0 : this.filter.hashCode());
/* 122 */     result = 31 * result + ((this.height == null) ? 0 : this.height.hashCode());
/* 123 */     result = 31 * result + ((this.interlace == null) ? 0 : this.interlace.hashCode());
/* 124 */     result = 31 * result + Arrays.hashCode((Object[])this.plte);
/* 125 */     result = 31 * result + ((this.width == null) ? 0 : this.width.hashCode());
/* 126 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 134 */     if (this == obj)
/* 135 */       return true; 
/* 136 */     if (obj == null)
/* 137 */       return false; 
/* 138 */     if (getClass() != obj.getClass())
/* 139 */       return false; 
/* 140 */     DisplayPNGCharacteristicsDescriptor other = (DisplayPNGCharacteristicsDescriptor)obj;
/* 141 */     if (this.bitDepth == null) {
/* 142 */       if (other.bitDepth != null)
/* 143 */         return false; 
/* 144 */     } else if (!this.bitDepth.equals(other.bitDepth)) {
/* 145 */       return false;
/* 146 */     }  if (this.colorType == null) {
/* 147 */       if (other.colorType != null)
/* 148 */         return false; 
/* 149 */     } else if (!this.colorType.equals(other.colorType)) {
/* 150 */       return false;
/* 151 */     }  if (this.compression == null) {
/* 152 */       if (other.compression != null)
/* 153 */         return false; 
/* 154 */     } else if (!this.compression.equals(other.compression)) {
/* 155 */       return false;
/* 156 */     }  if (this.filter == null) {
/* 157 */       if (other.filter != null)
/* 158 */         return false; 
/* 159 */     } else if (!this.filter.equals(other.filter)) {
/* 160 */       return false;
/* 161 */     }  if (this.height == null) {
/* 162 */       if (other.height != null)
/* 163 */         return false; 
/* 164 */     } else if (!this.height.equals(other.height)) {
/* 165 */       return false;
/* 166 */     }  if (this.interlace == null) {
/* 167 */       if (other.interlace != null)
/* 168 */         return false; 
/* 169 */     } else if (!this.interlace.equals(other.interlace)) {
/* 170 */       return false;
/* 171 */     }  if (!Arrays.equals((Object[])this.plte, (Object[])other.plte))
/* 172 */       return false; 
/* 173 */     if (this.width == null) {
/* 174 */       if (other.width != null)
/* 175 */         return false; 
/* 176 */     } else if (!this.width.equals(other.width)) {
/* 177 */       return false;
/* 178 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 185 */     StringBuilder builder = new StringBuilder(511);
/* 186 */     builder.append("DisplayPNGCharacteristicsDescriptor [width=").append(this.width).append(", height=").append(this.height).append(", bitDepth=").append(this.bitDepth).append(", colorType=").append(this.colorType).append(", compression=").append(this.compression)
/* 187 */       .append(", filter=").append(this.filter).append(", interlace=").append(this.interlace).append(", plte=").append(Arrays.toString((Object[])this.plte)).append("]");
/* 188 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 199 */     out.writeInt(1);
/* 200 */     SerializationUtils.writeSafeInteger(out, this.width);
/* 201 */     SerializationUtils.writeSafeInteger(out, this.height);
/* 202 */     SerializationUtils.writeSafeByte(out, this.bitDepth);
/* 203 */     SerializationUtils.writeSafeByte(out, this.colorType);
/* 204 */     SerializationUtils.writeSafeByte(out, this.compression);
/* 205 */     SerializationUtils.writeSafeByte(out, this.filter);
/* 206 */     SerializationUtils.writeSafeByte(out, this.interlace);
/* 207 */     SerializationUtils.writeSafeObject(out, this.plte);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 211 */     int ver = in.readInt();
/* 212 */     if (1 == ver) {
/* 213 */       this.width = SerializationUtils.readSafeInt(in);
/* 214 */       this.height = SerializationUtils.readSafeInt(in);
/* 215 */       this.bitDepth = SerializationUtils.readSafeByte(in);
/* 216 */       this.colorType = SerializationUtils.readSafeByte(in);
/* 217 */       this.compression = SerializationUtils.readSafeByte(in);
/* 218 */       this.filter = SerializationUtils.readSafeByte(in);
/* 219 */       this.interlace = SerializationUtils.readSafeByte(in);
/* 220 */       this.plte = (RGBPalletteEntry[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\DisplayPNGCharacteristicsDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */