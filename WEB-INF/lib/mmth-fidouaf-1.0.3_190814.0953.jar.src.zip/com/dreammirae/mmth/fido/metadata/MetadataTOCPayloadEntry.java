/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MetadataTOCPayloadEntry
/*    */   implements Serializable
/*    */ {
/*    */   private String aaid;
/*    */   private String hash;
/*    */   private String url;
/*    */   private StatusReport[] statusReports;
/*    */   private String timeOfLastStatusChange;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public String getAaid() {
/* 24 */     return this.aaid;
/*    */   }
/*    */   
/*    */   public void setAaid(String aaid) {
/* 28 */     this.aaid = aaid;
/*    */   }
/*    */   
/*    */   public String getHash() {
/* 32 */     return this.hash;
/*    */   }
/*    */   
/*    */   public void setHash(String hash) {
/* 36 */     this.hash = hash;
/*    */   }
/*    */   
/*    */   public String getUrl() {
/* 40 */     return this.url;
/*    */   }
/*    */   
/*    */   public void setUrl(String url) {
/* 44 */     this.url = url;
/*    */   }
/*    */   
/*    */   public StatusReport[] getStatusReports() {
/* 48 */     return this.statusReports;
/*    */   }
/*    */   
/*    */   public void setStatusReports(StatusReport[] statusReports) {
/* 52 */     this.statusReports = statusReports;
/*    */   }
/*    */   
/*    */   public String getTimeOfLastStatusChange() {
/* 56 */     return this.timeOfLastStatusChange;
/*    */   }
/*    */   
/*    */   public void setTimeOfLastStatusChange(String timeOfLastStatusChange) {
/* 60 */     this.timeOfLastStatusChange = timeOfLastStatusChange;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     StringBuilder builder = new StringBuilder();
/* 66 */     builder.append("{aaid:").append(this.aaid).append(", hash:").append(this.hash).append(", url:").append(this.url)
/* 67 */       .append(", statusReports:").append(Arrays.toString((Object[])this.statusReports)).append(", timeOfLastStatusChange:")
/* 68 */       .append(this.timeOfLastStatusChange).append("}");
/* 69 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 79 */     out.writeInt(1);
/* 80 */     SerializationUtils.writeSafeUTF(out, this.aaid);
/* 81 */     SerializationUtils.writeSafeUTF(out, this.hash);
/* 82 */     SerializationUtils.writeSafeUTF(out, this.url);
/* 83 */     SerializationUtils.writeSafeObject(out, this.statusReports);
/* 84 */     SerializationUtils.writeSafeUTF(out, this.timeOfLastStatusChange);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 88 */     int ver = in.readInt();
/* 89 */     if (1 == ver) {
/* 90 */       this.aaid = SerializationUtils.readSafeUTF(in);
/* 91 */       this.hash = SerializationUtils.readSafeUTF(in);
/* 92 */       this.url = SerializationUtils.readSafeUTF(in);
/* 93 */       this.statusReports = (StatusReport[])SerializationUtils.readSafeObject(in);
/* 94 */       this.timeOfLastStatusChange = SerializationUtils.readSafeUTF(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\MetadataTOCPayloadEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */