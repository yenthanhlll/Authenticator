/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JWTHeader
/*    */ {
/*    */   private String alg;
/*    */   private String typ;
/*    */   private String[] x5c;
/*    */   
/*    */   public String getAlg() {
/* 16 */     return this.alg;
/*    */   }
/*    */   
/*    */   public void setAlg(String alg) {
/* 20 */     this.alg = alg;
/*    */   }
/*    */   
/*    */   public String getTyp() {
/* 24 */     return this.typ;
/*    */   }
/*    */   
/*    */   public void setTyp(String typ) {
/* 28 */     this.typ = typ;
/*    */   }
/*    */   
/*    */   public String[] getX5c() {
/* 32 */     return this.x5c;
/*    */   }
/*    */   
/*    */   public void setX5c(String[] x5c) {
/* 36 */     this.x5c = x5c;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 41 */     StringBuilder builder = new StringBuilder(63);
/* 42 */     builder.append("{alg=").append(this.alg).append(", typ=").append(this.typ).append(", x5c=").append(Arrays.toString((Object[])this.x5c))
/* 43 */       .append("}");
/* 44 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\JWTHeader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */