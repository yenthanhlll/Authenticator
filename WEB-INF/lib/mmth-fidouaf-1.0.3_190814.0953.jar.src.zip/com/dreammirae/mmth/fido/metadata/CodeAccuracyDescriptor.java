/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ public class CodeAccuracyDescriptor
/*    */   implements Serializable
/*    */ {
/*    */   private short base;
/*    */   private short minLength;
/*    */   private short maxRetries;
/*    */   private short blockSlowdown;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public short getBase() {
/* 20 */     return this.base;
/*    */   }
/*    */   
/*    */   public void setBase(short base) {
/* 24 */     this.base = base;
/*    */   }
/*    */   
/*    */   public short getMinLength() {
/* 28 */     return this.minLength;
/*    */   }
/*    */   
/*    */   public void setMinLength(short minLength) {
/* 32 */     this.minLength = minLength;
/*    */   }
/*    */   
/*    */   public short getMaxRetries() {
/* 36 */     return this.maxRetries;
/*    */   }
/*    */   
/*    */   public void setMaxRetries(short maxRetries) {
/* 40 */     this.maxRetries = maxRetries;
/*    */   }
/*    */   
/*    */   public short getBlockSlowdown() {
/* 44 */     return this.blockSlowdown;
/*    */   }
/*    */   
/*    */   public void setBlockSlowdown(short blockSlowdown) {
/* 48 */     this.blockSlowdown = blockSlowdown;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     StringBuilder builder = new StringBuilder(255);
/* 54 */     builder.append("CodeAccuracyDescriptor [base=").append(this.base).append(", minLength=").append(this.minLength)
/* 55 */       .append(", maxRetries=").append(this.maxRetries).append(", blockSlowdown=").append(this.blockSlowdown)
/* 56 */       .append("]");
/* 57 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 68 */     out.writeInt(1);
/* 69 */     out.writeShort(this.base);
/* 70 */     out.writeShort(this.minLength);
/* 71 */     out.writeShort(this.maxRetries);
/* 72 */     out.writeShort(this.blockSlowdown);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 76 */     int ver = in.readInt();
/* 77 */     if (1 == ver) {
/* 78 */       this.base = in.readShort();
/* 79 */       this.minLength = in.readShort();
/* 80 */       this.maxRetries = in.readShort();
/* 81 */       this.blockSlowdown = in.readShort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\CodeAccuracyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */