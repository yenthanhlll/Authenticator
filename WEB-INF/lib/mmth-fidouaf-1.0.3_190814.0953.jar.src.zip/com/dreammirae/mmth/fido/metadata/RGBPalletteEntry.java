/*     */ package com.dreammirae.mmth.fido.metadata;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RGBPalletteEntry
/*     */   implements Serializable
/*     */ {
/*     */   private short r;
/*     */   private short g;
/*     */   private short b;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public RGBPalletteEntry() {}
/*     */   
/*     */   public RGBPalletteEntry(short r, short g, short b) {
/*  26 */     this.r = r;
/*  27 */     this.g = g;
/*  28 */     this.b = b;
/*     */   }
/*     */   
/*     */   public short getR() {
/*  32 */     return this.r;
/*     */   }
/*     */   
/*     */   public void setR(short r) {
/*  36 */     this.r = r;
/*     */   }
/*     */   
/*     */   public short getG() {
/*  40 */     return this.g;
/*     */   }
/*     */   
/*     */   public void setG(short g) {
/*  44 */     this.g = g;
/*     */   }
/*     */   
/*     */   public short getB() {
/*  48 */     return this.b;
/*     */   }
/*     */   
/*     */   public void setB(short b) {
/*  52 */     this.b = b;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  57 */     StringBuilder builder = new StringBuilder();
/*  58 */     builder.append("RGBPalletteEntry [r=").append(this.r).append(", g=").append(this.g).append(", b=").append(this.b).append("]");
/*  59 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  67 */     int prime = 31;
/*  68 */     int result = 1;
/*  69 */     result = 31 * result + this.b;
/*  70 */     result = 31 * result + this.g;
/*  71 */     result = 31 * result + this.r;
/*  72 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  80 */     if (this == obj)
/*  81 */       return true; 
/*  82 */     if (obj == null)
/*  83 */       return false; 
/*  84 */     if (getClass() != obj.getClass())
/*  85 */       return false; 
/*  86 */     RGBPalletteEntry other = (RGBPalletteEntry)obj;
/*  87 */     if (this.b != other.b)
/*  88 */       return false; 
/*  89 */     if (this.g != other.g)
/*  90 */       return false; 
/*  91 */     if (this.r != other.r)
/*  92 */       return false; 
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 105 */     out.writeInt(1);
/* 106 */     out.writeShort(this.r);
/* 107 */     out.writeShort(this.b);
/* 108 */     out.writeShort(this.g);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 112 */     int ver = in.readInt();
/* 113 */     if (1 == ver) {
/* 114 */       this.r = in.readShort();
/* 115 */       this.b = in.readShort();
/* 116 */       this.g = in.readShort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\RGBPalletteEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */