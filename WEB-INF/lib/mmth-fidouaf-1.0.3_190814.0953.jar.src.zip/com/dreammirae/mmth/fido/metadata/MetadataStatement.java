/*     */ package com.dreammirae.mmth.fido.metadata;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.uaf.Version;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetadataStatement
/*     */   implements Serializable
/*     */ {
/*     */   private String aaid;
/*     */   private String description;
/*     */   private Integer authenticatorVersion;
/*     */   private Version[] upv;
/*     */   private String assertionScheme;
/*     */   private Integer authenticationAlgorithm;
/*     */   private Integer publicKeyAlgAndEncoding;
/*     */   private int[] attestationTypes;
/*     */   private VerificationMethodDescriptor[][] userVerificationDetails;
/*     */   private Integer keyProtection;
/*     */   private Integer matcherProtection;
/*     */   private Long attachmentHint;
/*     */   private Boolean isSecondFactorOnly;
/*     */   private Integer tcDisplay;
/*     */   private String tcDisplayContentType;
/*     */   private DisplayPNGCharacteristicsDescriptor[] tcDisplayPNGCharacteristics;
/*     */   private String[] attestationRootCertificates;
/*     */   private String icon;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getAaid() {
/*  39 */     return this.aaid;
/*     */   }
/*     */   
/*     */   public void setAaid(String aaid) {
/*  43 */     this.aaid = aaid;
/*     */   }
/*     */   
/*     */   public String getDescription() {
/*  47 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  51 */     this.description = description;
/*     */   }
/*     */   
/*     */   public int getAuthenticatorVersion() {
/*  55 */     return this.authenticatorVersion.intValue();
/*     */   }
/*     */   
/*     */   public void setAuthenticatorVersion(int authenticatorVersion) {
/*  59 */     this.authenticatorVersion = Integer.valueOf(authenticatorVersion);
/*     */   }
/*     */   
/*     */   public Version[] getUpv() {
/*  63 */     return this.upv;
/*     */   }
/*     */   
/*     */   public void setUpv(Version[] upv) {
/*  67 */     this.upv = upv;
/*     */   }
/*     */   
/*     */   public String getAssertionScheme() {
/*  71 */     return this.assertionScheme;
/*     */   }
/*     */   
/*     */   public void setAssertionScheme(String assertionScheme) {
/*  75 */     this.assertionScheme = assertionScheme;
/*     */   }
/*     */   
/*     */   public int getAuthenticationAlgorithm() {
/*  79 */     return this.authenticationAlgorithm.intValue();
/*     */   }
/*     */   
/*     */   public void setAuthenticationAlgorithm(int authenticationAlgorithm) {
/*  83 */     this.authenticationAlgorithm = Integer.valueOf(authenticationAlgorithm);
/*     */   }
/*     */   
/*     */   public int getPublicKeyAlgAndEncoding() {
/*  87 */     return this.publicKeyAlgAndEncoding.intValue();
/*     */   }
/*     */   
/*     */   public void setPublicKeyAlgAndEncoding(int publicKeyAlgAndEncoding) {
/*  91 */     this.publicKeyAlgAndEncoding = Integer.valueOf(publicKeyAlgAndEncoding);
/*     */   }
/*     */   
/*     */   public int[] getAttestationTypes() {
/*  95 */     return this.attestationTypes;
/*     */   }
/*     */   
/*     */   public void setAttestationTypes(int[] attestationTypes) {
/*  99 */     this.attestationTypes = attestationTypes;
/*     */   }
/*     */   
/*     */   public VerificationMethodDescriptor[][] getUserVerificationDetails() {
/* 103 */     return this.userVerificationDetails;
/*     */   }
/*     */   
/*     */   public void setUserVerificationDetails(VerificationMethodDescriptor[][] userVerificationDetails) {
/* 107 */     this.userVerificationDetails = userVerificationDetails;
/*     */   }
/*     */   
/*     */   public int getKeyProtection() {
/* 111 */     return this.keyProtection.intValue();
/*     */   }
/*     */   
/*     */   public void setKeyProtection(int keyProtection) {
/* 115 */     this.keyProtection = Integer.valueOf(keyProtection);
/*     */   }
/*     */   
/*     */   public int getMatcherProtection() {
/* 119 */     return this.matcherProtection.intValue();
/*     */   }
/*     */   
/*     */   public void setMatcherProtection(int matcherProtection) {
/* 123 */     this.matcherProtection = Integer.valueOf(matcherProtection);
/*     */   }
/*     */   
/*     */   public long getAttachmentHint() {
/* 127 */     return this.attachmentHint.longValue();
/*     */   }
/*     */   
/*     */   public void setAttachmentHint(long attachmentHint) {
/* 131 */     this.attachmentHint = Long.valueOf(attachmentHint);
/*     */   }
/*     */   
/*     */   public boolean isSecondFactorOnly() {
/* 135 */     return this.isSecondFactorOnly.booleanValue();
/*     */   }
/*     */   
/*     */   public void setSecondFactorOnly(boolean isSecondFactorOnly) {
/* 139 */     this.isSecondFactorOnly = Boolean.valueOf(isSecondFactorOnly);
/*     */   }
/*     */   
/*     */   public int getTcDisplay() {
/* 143 */     return this.tcDisplay.intValue();
/*     */   }
/*     */   
/*     */   public void setTcDisplay(int tcDisplay) {
/* 147 */     this.tcDisplay = Integer.valueOf(tcDisplay);
/*     */   }
/*     */   
/*     */   public String getTcDisplayContentType() {
/* 151 */     return this.tcDisplayContentType;
/*     */   }
/*     */   
/*     */   public void setTcDisplayContentType(String tcDisplayContentType) {
/* 155 */     this.tcDisplayContentType = tcDisplayContentType;
/*     */   }
/*     */   
/*     */   public DisplayPNGCharacteristicsDescriptor[] getTcDisplayPNGCharacteristics() {
/* 159 */     return this.tcDisplayPNGCharacteristics;
/*     */   }
/*     */   
/*     */   public void setTcDisplayPNGCharacteristics(DisplayPNGCharacteristicsDescriptor[] tcDisplayPNGCharacteristics) {
/* 163 */     this.tcDisplayPNGCharacteristics = tcDisplayPNGCharacteristics;
/*     */   }
/*     */   
/*     */   public String[] getAttestationRootCertificates() {
/* 167 */     return this.attestationRootCertificates;
/*     */   }
/*     */   
/*     */   public void setAttestationRootCertificates(String[] attestationRootCertificates) {
/* 171 */     this.attestationRootCertificates = attestationRootCertificates;
/*     */   }
/*     */   
/*     */   public String getIcon() {
/* 175 */     return this.icon;
/*     */   }
/*     */   
/*     */   public void setIcon(String icon) {
/* 179 */     this.icon = icon;
/*     */   }
/*     */   
/*     */   public boolean isValidAttestaionType(int attestType) {
/* 183 */     if (this.attestationTypes == null) {
/* 184 */       return true;
/*     */     }
/*     */     
/* 187 */     for (int type : this.attestationTypes) {
/* 188 */       if (type == attestType) {
/* 189 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 193 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean validateMetadataStatement(MetadataStatement ms) {
/* 198 */     if (StringUtils.isEmpty(ms.aaid) || ms.aaid.length() != 9) {
/* 199 */       return false;
/*     */     }
/*     */     
/* 202 */     if (StringUtils.isEmpty(ms.description)) {
/* 203 */       return false;
/*     */     }
/*     */     
/* 206 */     if (ms.authenticatorVersion == null) {
/* 207 */       return false;
/*     */     }
/*     */     
/* 210 */     if (ms.upv == null) {
/* 211 */       return false;
/*     */     }
/*     */     
/* 214 */     if (StringUtils.isEmpty(ms.assertionScheme)) {
/* 215 */       return false;
/*     */     }
/*     */     
/* 218 */     if (ms.authenticationAlgorithm == null) {
/* 219 */       return false;
/*     */     }
/*     */     
/* 222 */     if (ms.publicKeyAlgAndEncoding == null) {
/* 223 */       return false;
/*     */     }
/*     */     
/* 226 */     if (ms.attestationTypes == null) {
/* 227 */       return false;
/*     */     }
/*     */     
/* 230 */     if (ms.userVerificationDetails == null) {
/* 231 */       return false;
/*     */     }
/*     */     
/* 234 */     if (ms.keyProtection == null) {
/* 235 */       return false;
/*     */     }
/*     */     
/* 238 */     if (ms.matcherProtection == null) {
/* 239 */       return false;
/*     */     }
/*     */     
/* 242 */     if (ms.attachmentHint == null) {
/* 243 */       return false;
/*     */     }
/*     */     
/* 246 */     if (ms.isSecondFactorOnly == null) {
/* 247 */       return false;
/*     */     }
/*     */     
/* 250 */     if (ms.tcDisplay == null) {
/* 251 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 255 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 260 */     StringBuilder builder = new StringBuilder(2048);
/* 261 */     builder.append("MetadataStatement [aaid=").append(this.aaid).append(", description=").append(this.description)
/* 262 */       .append(", authenticatorVersion=").append(this.authenticatorVersion).append(", upv=")
/* 263 */       .append(Arrays.toString((Object[])this.upv)).append(", assertionScheme=").append(this.assertionScheme)
/* 264 */       .append(", authenticationAlgorithm=").append(this.authenticationAlgorithm)
/* 265 */       .append(", publicKeyAlgAndEncoding=").append(this.publicKeyAlgAndEncoding).append(", attestationTypes=")
/* 266 */       .append(Arrays.toString(this.attestationTypes)).append(", userVerificationDetails=")
/* 267 */       .append(Arrays.toString((Object[])this.userVerificationDetails)).append(", keyProtection=").append(this.keyProtection)
/* 268 */       .append(", matcherProtection=").append(this.matcherProtection).append(", attachmentHint=")
/* 269 */       .append(this.attachmentHint).append(", isSecondFactorOnly=").append(this.isSecondFactorOnly)
/* 270 */       .append(", tcDisplay=").append(this.tcDisplay).append(", tcDisplayContentType=").append(this.tcDisplayContentType)
/* 271 */       .append(", tcDisplayPNGCharacteristics=").append(Arrays.toString((Object[])this.tcDisplayPNGCharacteristics))
/* 272 */       .append(", attestationRootCertificates=").append(Arrays.toString((Object[])this.attestationRootCertificates))
/* 273 */       .append(", icon=").append(this.icon).append("]");
/* 274 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 284 */     out.writeInt(1);
/* 285 */     SerializationUtils.writeSafeUTF(out, this.aaid);
/* 286 */     SerializationUtils.writeSafeUTF(out, this.description);
/* 287 */     out.writeInt(this.authenticatorVersion.intValue());
/* 288 */     SerializationUtils.writeSafeObject(out, this.upv);
/* 289 */     SerializationUtils.writeSafeUTF(out, this.assertionScheme);
/* 290 */     out.writeInt(this.authenticationAlgorithm.intValue());
/* 291 */     out.writeInt(this.publicKeyAlgAndEncoding.intValue());
/* 292 */     SerializationUtils.writeSafeObject(out, this.attestationTypes);
/* 293 */     SerializationUtils.writeSafeObject(out, this.userVerificationDetails);
/* 294 */     out.writeInt(this.keyProtection.intValue());
/* 295 */     out.writeInt(this.matcherProtection.intValue());
/* 296 */     out.writeLong(this.attachmentHint.longValue());
/* 297 */     out.writeBoolean(this.isSecondFactorOnly.booleanValue());
/* 298 */     out.writeInt(this.tcDisplay.intValue());
/* 299 */     SerializationUtils.writeSafeUTF(out, this.tcDisplayContentType);
/* 300 */     SerializationUtils.writeSafeObject(out, this.tcDisplayPNGCharacteristics);
/* 301 */     SerializationUtils.writeSafeObject(out, this.attestationRootCertificates);
/* 302 */     SerializationUtils.writeSafeUTF(out, this.icon);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 306 */     int ver = in.readInt();
/*     */     
/* 308 */     if (1 == ver) {
/* 309 */       this.aaid = SerializationUtils.readSafeUTF(in);
/* 310 */       this.description = SerializationUtils.readSafeUTF(in);
/* 311 */       this.authenticatorVersion = Integer.valueOf(in.readInt());
/* 312 */       this.upv = (Version[])SerializationUtils.readSafeObject(in);
/* 313 */       this.assertionScheme = SerializationUtils.readSafeUTF(in);
/* 314 */       this.authenticationAlgorithm = Integer.valueOf(in.readInt());
/* 315 */       this.publicKeyAlgAndEncoding = Integer.valueOf(in.readInt());
/* 316 */       this.attestationTypes = (int[])SerializationUtils.readSafeObject(in);
/* 317 */       this.userVerificationDetails = (VerificationMethodDescriptor[][])SerializationUtils.readSafeObject(in);
/* 318 */       this.keyProtection = Integer.valueOf(in.readInt());
/* 319 */       this.matcherProtection = Integer.valueOf(in.readInt());
/* 320 */       this.attachmentHint = Long.valueOf(in.readLong());
/* 321 */       this.isSecondFactorOnly = Boolean.valueOf(in.readBoolean());
/* 322 */       this.tcDisplay = Integer.valueOf(in.readInt());
/* 323 */       this.tcDisplayContentType = SerializationUtils.readSafeUTF(in);
/* 324 */       this.tcDisplayPNGCharacteristics = (DisplayPNGCharacteristicsDescriptor[])SerializationUtils.readSafeObject(in);
/* 325 */       this.attestationRootCertificates = (String[])SerializationUtils.readSafeObject(in);
/* 326 */       this.icon = SerializationUtils.readSafeUTF(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\MetadataStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */