/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ public class PatternAccuracyDescriptor
/*    */   implements Serializable
/*    */ {
/*    */   private long minComplexity;
/*    */   private short maxRetries;
/*    */   private short blockSlowdown;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public long getMinComplexity() {
/* 19 */     return this.minComplexity;
/*    */   }
/*    */   
/*    */   public void setMinComplexity(long minComplexity) {
/* 23 */     this.minComplexity = minComplexity;
/*    */   }
/*    */   
/*    */   public short getMaxRetries() {
/* 27 */     return this.maxRetries;
/*    */   }
/*    */   
/*    */   public void setMaxRetries(short maxRetries) {
/* 31 */     this.maxRetries = maxRetries;
/*    */   }
/*    */   
/*    */   public short getBlockSlowdown() {
/* 35 */     return this.blockSlowdown;
/*    */   }
/*    */   
/*    */   public void setBlockSlowdown(short blockSlowdown) {
/* 39 */     this.blockSlowdown = blockSlowdown;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     StringBuilder builder = new StringBuilder();
/* 45 */     builder.append("PatternAccuracyDescriptor [minComplexity=").append(this.minComplexity).append(", maxRetries=")
/* 46 */       .append(this.maxRetries).append(", blockSlowdown=").append(this.blockSlowdown).append("]");
/* 47 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 57 */     out.writeInt(1);
/* 58 */     out.writeLong(this.minComplexity);
/* 59 */     out.writeShort(this.maxRetries);
/* 60 */     out.writeShort(this.blockSlowdown);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 64 */     int ver = in.readInt();
/* 65 */     if (1 == ver) {
/* 66 */       this.minComplexity = in.readLong();
/* 67 */       this.maxRetries = in.readShort();
/* 68 */       this.blockSlowdown = in.readShort();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\PatternAccuracyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */