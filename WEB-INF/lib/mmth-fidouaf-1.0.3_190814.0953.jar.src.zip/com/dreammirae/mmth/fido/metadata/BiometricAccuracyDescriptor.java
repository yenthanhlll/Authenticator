/*     */ package com.dreammirae.mmth.fido.metadata;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BiometricAccuracyDescriptor
/*     */   implements Serializable
/*     */ {
/*     */   private double FAR;
/*     */   private double FRR;
/*     */   private double EER;
/*     */   private double FAAR;
/*     */   private short maxReferenceDataSets;
/*     */   private short maxRetries;
/*     */   private short blockSlowdown;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public double getFAR() {
/*  29 */     return this.FAR;
/*     */   }
/*     */   
/*     */   public void setFAR(double fAR) {
/*  33 */     this.FAR = fAR;
/*     */   }
/*     */   
/*     */   public double getFRR() {
/*  37 */     return this.FRR;
/*     */   }
/*     */   
/*     */   public void setFRR(double fRR) {
/*  41 */     this.FRR = fRR;
/*     */   }
/*     */   
/*     */   public double getEER() {
/*  45 */     return this.EER;
/*     */   }
/*     */   
/*     */   public void setEER(double eER) {
/*  49 */     this.EER = eER;
/*     */   }
/*     */   
/*     */   public double getFAAR() {
/*  53 */     return this.FAAR;
/*     */   }
/*     */   
/*     */   public void setFAAR(double fAAR) {
/*  57 */     this.FAAR = fAAR;
/*     */   }
/*     */   
/*     */   public short getMaxReferenceDataSets() {
/*  61 */     return this.maxReferenceDataSets;
/*     */   }
/*     */   
/*     */   public void setMaxReferenceDataSets(short maxReferenceDataSets) {
/*  65 */     this.maxReferenceDataSets = maxReferenceDataSets;
/*     */   }
/*     */   
/*     */   public short getMaxRetries() {
/*  69 */     return this.maxRetries;
/*     */   }
/*     */   
/*     */   public void setMaxRetries(short maxRetries) {
/*  73 */     this.maxRetries = maxRetries;
/*     */   }
/*     */   
/*     */   public short getBlockSlowdown() {
/*  77 */     return this.blockSlowdown;
/*     */   }
/*     */   
/*     */   public void setBlockSlowdown(short blockSlowdown) {
/*  81 */     this.blockSlowdown = blockSlowdown;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  86 */     StringBuilder builder = new StringBuilder(511);
/*  87 */     builder.append("BiometricAccuracyDescriptor [FAR=").append(this.FAR).append(", FRR=").append(this.FRR).append(", EER=")
/*  88 */       .append(this.EER).append(", FAAR=").append(this.FAAR).append(", maxReferenceDataSets=")
/*  89 */       .append(this.maxReferenceDataSets).append(", maxRetries=").append(this.maxRetries).append(", blockSlowdown=")
/*  90 */       .append(this.blockSlowdown).append("]");
/*  91 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 102 */     out.writeInt(1);
/* 103 */     out.writeDouble(this.FAR);
/* 104 */     out.writeDouble(this.EER);
/* 105 */     out.writeDouble(this.FAAR);
/* 106 */     out.writeShort(this.maxReferenceDataSets);
/* 107 */     out.writeShort(this.maxRetries);
/* 108 */     out.writeShort(this.blockSlowdown);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 112 */     int ver = in.readInt();
/* 113 */     if (1 == ver) {
/* 114 */       this.FAR = in.readDouble();
/* 115 */       this.EER = in.readDouble();
/* 116 */       this.FAAR = in.readDouble();
/* 117 */       this.maxReferenceDataSets = in.readShort();
/* 118 */       this.maxRetries = in.readShort();
/* 119 */       this.blockSlowdown = in.readShort();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\BiometricAccuracyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */