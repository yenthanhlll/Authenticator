/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ 
/*    */ public class StatusReport implements Serializable {
/*    */   private AuthenticatorStatus status;
/*    */   private String effectiveDate;
/*    */   private String certificate;
/*    */   private String url;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public enum AuthenticatorStatus {
/* 13 */     FIDO_CERTIFIED, NOT_FIDO_CERTIFIED, USER_VERIFICATION_BYPASS, ATTESTATION_KEY_COMPROMISE, USER_KEY_REMOTE_COMPROMISE, USER_KEY_PHYSICAL_COMPROMISE, UPDATE_AVAILABLE, REVOKED;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthenticatorStatus getStatus() {
/* 26 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(AuthenticatorStatus status) {
/* 30 */     this.status = status;
/*    */   }
/*    */   
/*    */   public String getEffectiveDate() {
/* 34 */     return this.effectiveDate;
/*    */   }
/*    */   
/*    */   public void setEffectiveDate(String effectiveDate) {
/* 38 */     this.effectiveDate = effectiveDate;
/*    */   }
/*    */   
/*    */   public String getCertificate() {
/* 42 */     return this.certificate;
/*    */   }
/*    */   
/*    */   public void setCertificate(String certificate) {
/* 46 */     this.certificate = certificate;
/*    */   }
/*    */   
/*    */   public String getUrl() {
/* 50 */     return this.url;
/*    */   }
/*    */   
/*    */   public void setUrl(String url) {
/* 54 */     this.url = url;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     StringBuilder builder = new StringBuilder();
/* 60 */     builder.append("{status:").append(this.status).append(", effectiveDate:").append(this.effectiveDate)
/* 61 */       .append(", certificate:").append(this.certificate).append(", url:").append(this.url).append("}");
/* 62 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 72 */     out.writeInt(1);
/* 73 */     SerializationUtils.writeSafeObject(out, this.status);
/* 74 */     SerializationUtils.writeSafeUTF(out, this.effectiveDate);
/* 75 */     SerializationUtils.writeSafeUTF(out, this.certificate);
/* 76 */     SerializationUtils.writeSafeUTF(out, this.url);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 80 */     int ver = in.readInt();
/* 81 */     if (1 == ver) {
/* 82 */       this.status = (AuthenticatorStatus)SerializationUtils.readSafeObject(in);
/* 83 */       this.effectiveDate = SerializationUtils.readSafeUTF(in);
/* 84 */       this.certificate = SerializationUtils.readSafeUTF(in);
/* 85 */       this.url = SerializationUtils.readSafeUTF(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\StatusReport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */