/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MetadataTOCPayload
/*    */   implements Serializable
/*    */ {
/*    */   private int no;
/*    */   private String nextUpdate;
/*    */   private MetadataTOCPayloadEntry[] entries;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public int getNo() {
/* 22 */     return this.no;
/*    */   }
/*    */   
/*    */   public void setNo(int no) {
/* 26 */     this.no = no;
/*    */   }
/*    */   
/*    */   public String getNextUpdate() {
/* 30 */     return this.nextUpdate;
/*    */   }
/*    */   
/*    */   public void setNextUpdate(String nextUpdate) {
/* 34 */     this.nextUpdate = nextUpdate;
/*    */   }
/*    */   
/*    */   public MetadataTOCPayloadEntry[] getEntries() {
/* 38 */     return this.entries;
/*    */   }
/*    */   
/*    */   public void setEntries(MetadataTOCPayloadEntry[] entries) {
/* 42 */     this.entries = entries;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     StringBuilder builder = new StringBuilder(2048);
/* 48 */     builder.append("{no:").append(this.no).append(", nextUpdate:").append(this.nextUpdate).append(", entries:")
/* 49 */       .append(Arrays.toString((Object[])this.entries)).append("}");
/* 50 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 60 */     out.writeInt(1);
/* 61 */     out.writeInt(this.no);
/* 62 */     SerializationUtils.writeSafeUTF(out, this.nextUpdate);
/* 63 */     SerializationUtils.writeSafeObject(out, this.entries);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 67 */     int ver = in.readInt();
/* 68 */     if (1 == ver) {
/* 69 */       this.no = in.readInt();
/* 70 */       this.nextUpdate = SerializationUtils.readSafeUTF(in);
/* 71 */       this.entries = (MetadataTOCPayloadEntry[])SerializationUtils.readSafeObject(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\MetadataTOCPayload.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */