/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VerificationMethodDescriptor
/*    */   implements Serializable
/*    */ {
/*    */   private long userVerification;
/*    */   private BiometricAccuracyDescriptor baDesc;
/*    */   private CodeAccuracyDescriptor caDesc;
/*    */   private PatternAccuracyDescriptor paDesc;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public long getUserVerification() {
/* 22 */     return this.userVerification;
/*    */   }
/*    */   
/*    */   public void setUserVerification(long userVerification) {
/* 26 */     this.userVerification = userVerification;
/*    */   }
/*    */   
/*    */   public BiometricAccuracyDescriptor getBaDesc() {
/* 30 */     return this.baDesc;
/*    */   }
/*    */   
/*    */   public void setBaDesc(BiometricAccuracyDescriptor baDesc) {
/* 34 */     this.baDesc = baDesc;
/*    */   }
/*    */   
/*    */   public CodeAccuracyDescriptor getCaDesc() {
/* 38 */     return this.caDesc;
/*    */   }
/*    */   
/*    */   public void setCaDesc(CodeAccuracyDescriptor caDesc) {
/* 42 */     this.caDesc = caDesc;
/*    */   }
/*    */   
/*    */   public PatternAccuracyDescriptor getPaDesc() {
/* 46 */     return this.paDesc;
/*    */   }
/*    */   
/*    */   public void setPaDesc(PatternAccuracyDescriptor paDesc) {
/* 50 */     this.paDesc = paDesc;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     StringBuilder builder = new StringBuilder();
/* 56 */     builder.append("VerificationMethodDescriptor [userVerification=").append(this.userVerification).append(", baDesc=")
/* 57 */       .append(this.baDesc).append(", caDesc=").append(this.caDesc).append(", paDesc=").append(this.paDesc).append("]");
/* 58 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 68 */     out.writeInt(1);
/* 69 */     out.writeLong(this.userVerification);
/* 70 */     SerializationUtils.writeSafeObject(out, this.baDesc);
/* 71 */     SerializationUtils.writeSafeObject(out, this.caDesc);
/* 72 */     SerializationUtils.writeSafeObject(out, this.paDesc);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 76 */     int ver = in.readInt();
/* 77 */     if (1 == ver) {
/* 78 */       this.userVerification = in.readLong();
/* 79 */       this.baDesc = (BiometricAccuracyDescriptor)SerializationUtils.readSafeObject(in);
/* 80 */       this.caDesc = (CodeAccuracyDescriptor)SerializationUtils.readSafeObject(in);
/* 81 */       this.paDesc = (PatternAccuracyDescriptor)SerializationUtils.readSafeObject(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\VerificationMethodDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */