/*    */ package com.dreammirae.mmth.fido.metadata;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VerificationMethodANDCombinations
/*    */   implements Serializable
/*    */ {
/*    */   private VerificationMethodDescriptor[] VerificationMethodANDCombinations;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public VerificationMethodDescriptor[] getVerificationMethodANDCombinations() {
/* 20 */     return this.VerificationMethodANDCombinations;
/*    */   }
/*    */   
/*    */   public void setVerificationMethodANDCombinations(VerificationMethodDescriptor[] verificationMethodANDCombinations) {
/* 24 */     this.VerificationMethodANDCombinations = verificationMethodANDCombinations;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     StringBuilder builder = new StringBuilder();
/* 30 */     builder.append("VerificationMethodANDCombinations [VerificationMethodANDCombinations=")
/* 31 */       .append(Arrays.toString((Object[])this.VerificationMethodANDCombinations)).append("]");
/* 32 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 42 */     out.writeInt(1);
/* 43 */     SerializationUtils.writeSafeObject(out, this.VerificationMethodANDCombinations);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 47 */     int ver = in.readInt();
/* 48 */     if (1 == ver)
/* 49 */       this.VerificationMethodANDCombinations = (VerificationMethodDescriptor[])SerializationUtils.readSafeObject(in); 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\metadata\VerificationMethodANDCombinations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */