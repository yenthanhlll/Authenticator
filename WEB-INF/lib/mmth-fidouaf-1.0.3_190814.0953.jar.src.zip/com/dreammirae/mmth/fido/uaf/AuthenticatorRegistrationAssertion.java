/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.RegAssertionLocator;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ import org.joda.time.DateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticatorRegistrationAssertion
/*     */   implements IUafProtocol
/*     */ {
/*     */   private String assertionScheme;
/*     */   private String assertion;
/*     */   private DisplayPNGCharacteristicsDescriptor[] tcDisplayPNGCharacteristics;
/*     */   private Extension[] exts;
/*     */   private transient RegAssertionLocator assertionLocator;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getAssertionScheme() {
/*  43 */     return this.assertionScheme;
/*     */   }
/*     */   
/*     */   public void setAssertionScheme(String assertionScheme) {
/*  47 */     this.assertionScheme = assertionScheme;
/*     */   }
/*     */   
/*     */   public String getAssertion() {
/*  51 */     return this.assertion;
/*     */   }
/*     */   
/*     */   public void setAssertion(String assertion) {
/*  55 */     this.assertion = assertion;
/*     */   }
/*     */   
/*     */   public DisplayPNGCharacteristicsDescriptor[] getTcDisplayPNGCharacteristics() {
/*  59 */     return this.tcDisplayPNGCharacteristics;
/*     */   }
/*     */   
/*     */   public void setTcDisplayPNGCharacteristics(DisplayPNGCharacteristicsDescriptor[] tcDisplayPNGCharacteristics) {
/*  63 */     this.tcDisplayPNGCharacteristics = tcDisplayPNGCharacteristics;
/*     */   }
/*     */   
/*     */   public Extension[] getExts() {
/*  67 */     return this.exts;
/*     */   }
/*     */   
/*     */   public void setExts(Extension[] exts) {
/*  71 */     this.exts = exts;
/*     */   }
/*     */   
/*     */   public RegAssertionLocator getAssertionLocator() {
/*  75 */     return this.assertionLocator;
/*     */   }
/*     */   
/*     */   public void setAssertionLocator(RegAssertionLocator assertionLocator) {
/*  79 */     this.assertionLocator = assertionLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/*  85 */     if (StringUtils.isEmpty(this.assertionScheme)) {
/*  86 */       throw new IllegalUafFieldException("AuthenticatorRegistrationAssertion[assertionScheme] must not be null/empty/missing.");
/*     */     }
/*     */     
/*  89 */     if (!"UAFV1TLV".equals(this.assertionScheme)) {
/*  90 */       throw new IllegalUafFieldException("AuthenticatorRegistrationAssertion[assertionScheme] must be UAFV1TLV");
/*     */     }
/*     */ 
/*     */     
/*  94 */     if (StringUtils.isEmpty(this.assertion)) {
/*  95 */       throw new IllegalUafFieldException("AuthenticatorRegistrationAssertion[assertion] must not be null/empty/missing.");
/*     */     }
/*     */     
/*  98 */     if (this.assertionLocator == null) {
/*  99 */       throw new IllegalUafFieldException("AuthenticatorRegistrationAssertion[assertion] is failed to parse.");
/*     */     }
/* 101 */     this.assertionLocator.validateField();
/*     */     
/* 103 */     if (this.exts != null) {
/* 104 */       for (Extension ext : this.exts) {
/* 105 */         ext.validateField();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     StringBuilder builder = new StringBuilder();
/* 113 */     builder.append("AuthenticatorRegistrationAssertion [assertionScheme=").append(this.assertionScheme)
/* 114 */       .append(", assertion=").append(this.assertion).append(", tcDisplayPNGCharacteristics=")
/* 115 */       .append(Arrays.toString((Object[])this.tcDisplayPNGCharacteristics)).append(", exts=").append(Arrays.toString((Object[])this.exts))
/* 116 */       .append(", assertionLocator=").append(this.assertionLocator).append("]");
/* 117 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 127 */     out.writeInt(1);
/* 128 */     SerializationUtils.writeSafeUTF(out, this.assertionScheme);
/* 129 */     SerializationUtils.writeSafeUTF(out, this.assertion);
/* 130 */     SerializationUtils.writeSafeObject(out, this.tcDisplayPNGCharacteristics);
/* 131 */     SerializationUtils.writeSafeObject(out, this.exts);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 135 */     int ver = in.readInt();
/* 136 */     if (1 == ver) {
/* 137 */       this.assertionScheme = SerializationUtils.readSafeUTF(in);
/* 138 */       this.assertion = SerializationUtils.readSafeUTF(in);
/* 139 */       this.tcDisplayPNGCharacteristics = (DisplayPNGCharacteristicsDescriptor[])SerializationUtils.readSafeObject(in);
/* 140 */       this.exts = (Extension[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 146 */     System.out.println((new DateTime(2019, 3, 20, 0, 0, 0)).getMillis());
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\AuthenticatorRegistrationAssertion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */