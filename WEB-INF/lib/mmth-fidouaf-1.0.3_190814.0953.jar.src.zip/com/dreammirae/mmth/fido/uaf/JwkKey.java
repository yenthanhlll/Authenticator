/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JwkKey
/*     */   implements Serializable
/*     */ {
/*     */   private static final String DEFAULT_KTV = "EC";
/*     */   private static final String DEFAULT_CRV = "P-256";
/*  52 */   private String ktv = "EC";
/*  53 */   private String crv = "P-256";
/*     */   
/*     */   private String x;
/*     */   
/*     */   private String y;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getKtv() {
/*  62 */     return this.ktv;
/*     */   }
/*     */   
/*     */   public void setKtv(String ktv) {
/*  66 */     this.ktv = ktv;
/*     */   }
/*     */   
/*     */   public String getCrv() {
/*  70 */     return this.crv;
/*     */   }
/*     */   
/*     */   public void setCrv(String crv) {
/*  74 */     this.crv = crv;
/*     */   }
/*     */   
/*     */   public String getX() {
/*  78 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(String x) {
/*  82 */     this.x = x;
/*     */   }
/*     */   
/*     */   public String getY() {
/*  86 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(String y) {
/*  90 */     this.y = y;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     StringBuilder builder = new StringBuilder();
/*  96 */     builder.append("JwkKey [ktv=").append(this.ktv).append(", crv=").append(this.crv).append(", x=").append(this.x).append(", y=")
/*  97 */       .append(this.y).append("]");
/*  98 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 108 */     out.writeInt(1);
/* 109 */     SerializationUtils.writeSafeUTF(out, this.ktv);
/* 110 */     SerializationUtils.writeSafeUTF(out, this.crv);
/* 111 */     SerializationUtils.writeSafeUTF(out, this.x);
/* 112 */     SerializationUtils.writeSafeUTF(out, this.y);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 116 */     int ver = in.readInt();
/* 117 */     if (1 == ver) {
/* 118 */       this.ktv = SerializationUtils.readSafeUTF(in);
/* 119 */       this.crv = SerializationUtils.readSafeUTF(in);
/* 120 */       this.x = SerializationUtils.readSafeUTF(in);
/* 121 */       this.y = SerializationUtils.readSafeUTF(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\JwkKey.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */