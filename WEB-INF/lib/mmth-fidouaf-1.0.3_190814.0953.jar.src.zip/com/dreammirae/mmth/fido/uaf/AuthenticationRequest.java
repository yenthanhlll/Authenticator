/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationRequest
/*     */   implements IUafProtocolMessage
/*     */ {
/*     */   private OperationHeader header;
/*     */   private String challenge;
/*     */   private Transaction[] transaction;
/*     */   private Policy policy;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public OperationHeader getHeader() {
/*  60 */     return this.header;
/*     */   }
/*     */   
/*     */   public void setHeader(OperationHeader header) {
/*  64 */     this.header = header;
/*     */   }
/*     */   
/*     */   public String getChallenge() {
/*  68 */     return this.challenge;
/*     */   }
/*     */   
/*     */   public void setChallenge(String challenge) {
/*  72 */     this.challenge = challenge;
/*     */   }
/*     */   
/*     */   public Transaction[] getTransaction() {
/*  76 */     return this.transaction;
/*     */   }
/*     */   
/*     */   public void setTransaction(Transaction[] transaction) {
/*  80 */     this.transaction = transaction;
/*     */   }
/*     */   
/*     */   public Policy getPolicy() {
/*  84 */     return this.policy;
/*     */   }
/*     */   
/*     */   public void setPolicy(Policy policy) {
/*  88 */     this.policy = policy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/*  94 */     if (this.header == null) {
/*  95 */       throw new IllegalUafJsonException("AuthenticationRequest[header] must not be null/missing/empty.");
/*     */     }
/*  97 */     this.header.validateField();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     StringBuilder builder = new StringBuilder();
/* 104 */     builder.append("AuthenticationRequest [header=").append(this.header).append(", challenge=").append(this.challenge)
/* 105 */       .append(", transaction=").append(Arrays.toString((Object[])this.transaction)).append(", policy=").append(this.policy)
/* 106 */       .append("]");
/* 107 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 117 */     out.writeInt(1);
/* 118 */     SerializationUtils.writeSafeObject(out, this.header);
/* 119 */     SerializationUtils.writeSafeUTF(out, this.challenge);
/* 120 */     SerializationUtils.writeSafeObject(out, this.transaction);
/* 121 */     SerializationUtils.writeSafeObject(out, this.policy);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 125 */     int ver = in.readInt();
/* 126 */     if (1 == ver) {
/* 127 */       this.header = (OperationHeader)SerializationUtils.readSafeObject(in);
/* 128 */       this.challenge = SerializationUtils.readSafeUTF(in);
/* 129 */       this.transaction = (Transaction[])SerializationUtils.readSafeObject(in);
/* 130 */       this.policy = (Policy)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\AuthenticationRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */