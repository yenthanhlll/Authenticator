/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Version
/*     */   implements IUafProtocol
/*     */ {
/*     */   private static final short CURRENT_MAJOR_VER = 1;
/*     */   private static final short CURRENT_MIMOR_VER = 0;
/*  22 */   private Short major = null;
/*  23 */   private Short minor = null;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public Version() {}
/*     */   
/*     */   public Version(Short major, Short minor) {
/*  30 */     this.major = major;
/*  31 */     this.minor = minor;
/*     */   }
/*     */   
/*     */   public void setMajor(Short major) {
/*  35 */     this.major = major;
/*     */   }
/*     */   
/*     */   public void setMinor(Short minor) {
/*  39 */     this.minor = minor;
/*     */   }
/*     */   
/*     */   public Short getMajor() {
/*  43 */     return this.major;
/*     */   }
/*     */   
/*     */   public Short getMinor() {
/*  47 */     return this.minor;
/*     */   }
/*     */   
/*     */   public static Version getCurrentVersion() {
/*  51 */     return new Version(Short.valueOf((short)1), Short.valueOf((short)0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  57 */     int result = 0;
/*  58 */     if (this.major != null) {
/*  59 */       result |= (0xFFFF & this.major.shortValue()) << 16;
/*     */     }
/*     */     
/*  62 */     if (this.minor != null) {
/*  63 */       result |= 0xFFFF & this.minor.shortValue();
/*     */     }
/*     */     
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  77 */     if (this == obj)
/*  78 */       return true; 
/*  79 */     if (obj == null)
/*  80 */       return false; 
/*  81 */     if (getClass() != obj.getClass()) {
/*  82 */       return false;
/*     */     }
/*  84 */     return (hashCode() == obj.hashCode());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafJsonException {
/*  90 */     if (this.major == null) {
/*  91 */       throw new IllegalUafJsonException("Version[major] must not be null/empty/missing.");
/*     */     }
/*  93 */     if (this.minor == null) {
/*  94 */       throw new IllegalUafJsonException("Version[minor] must not be null/empty/missing.");
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/*  99 */     StringBuilder builder = new StringBuilder();
/* 100 */     builder.append("V").append(this.major).append(".").append(this.minor);
/* 101 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 112 */     out.writeInt(1);
/* 113 */     out.writeShort(this.major.shortValue());
/* 114 */     out.writeShort(this.minor.shortValue());
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 118 */     int ver = in.readInt();
/* 119 */     if (1 == ver) {
/* 120 */       this.major = Short.valueOf(in.readShort());
/* 121 */       this.minor = Short.valueOf(in.readShort());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\Version.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */