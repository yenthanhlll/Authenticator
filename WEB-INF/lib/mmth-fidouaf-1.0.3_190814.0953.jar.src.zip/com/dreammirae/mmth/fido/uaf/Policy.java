/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Policy
/*     */   implements IUafProtocol
/*     */ {
/*     */   private MatchCriteria[][] accepted;
/*     */   private MatchCriteria[] disallowed;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public MatchCriteria[][] getAccepted() {
/* 145 */     return this.accepted;
/*     */   }
/*     */   
/*     */   public Policy setAccepted(MatchCriteria[][] accepted) {
/* 149 */     this.accepted = accepted;
/* 150 */     return this;
/*     */   }
/*     */   
/*     */   public MatchCriteria[] getDisallowed() {
/* 154 */     return this.disallowed;
/*     */   }
/*     */   
/*     */   public Policy setDisallowed(MatchCriteria[] disallowed) {
/* 158 */     this.disallowed = disallowed;
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 165 */     if (this.accepted == null) {
/* 166 */       throw new IllegalUafFieldException("Policy[accepted] must not be null/empty/missing.");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 172 */     StringBuilder builder = new StringBuilder();
/* 173 */     builder.append("Policy [accepted=");
/*     */     
/* 175 */     for (MatchCriteria[] matchCriterias : this.accepted) {
/* 176 */       builder.append(Arrays.toString((Object[])matchCriterias)).append(", ");
/*     */     }
/*     */     
/* 179 */     builder.append(", disallowed=").append(Arrays.toString((Object[])this.disallowed)).append("]");
/* 180 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 190 */     out.writeInt(1);
/* 191 */     SerializationUtils.writeSafeObject(out, this.accepted);
/* 192 */     SerializationUtils.writeSafeObject(out, this.disallowed);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 196 */     int ver = in.readInt();
/* 197 */     if (1 == ver) {
/* 198 */       this.accepted = (MatchCriteria[][])SerializationUtils.readSafeObject(in);
/* 199 */       this.disallowed = (MatchCriteria[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\Policy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */