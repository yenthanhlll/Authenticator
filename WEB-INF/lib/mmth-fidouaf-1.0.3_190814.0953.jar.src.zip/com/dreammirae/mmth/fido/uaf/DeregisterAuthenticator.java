/*    */ package com.dreammirae.mmth.fido.uaf;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*    */ import com.dreammirae.mmth.util.StringUtils;
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeregisterAuthenticator
/*    */   implements IUafProtocol
/*    */ {
/*    */   private String aaid;
/*    */   private String keyID;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public String getAaid() {
/* 24 */     return this.aaid;
/*    */   }
/*    */   
/*    */   public void setAaid(String aaid) {
/* 28 */     this.aaid = aaid;
/*    */   }
/*    */   
/*    */   public String getKeyID() {
/* 32 */     return this.keyID;
/*    */   }
/*    */   
/*    */   public void setKeyID(String keyID) {
/* 36 */     this.keyID = keyID;
/*    */   }
/*    */ 
/*    */   
/*    */   public void validateField() throws IllegalUafFieldException {
/* 41 */     if (StringUtils.isEmpty(this.aaid)) {
/* 42 */       throw new IllegalUafFieldException("DeregisterAuthenticator[aaid] must not be null/empty/missing.");
/*    */     }
/*    */     
/* 45 */     if (this.aaid.length() != 9) {
/* 46 */       throw new IllegalUafFieldException("DeregisterAuthenticator[aaid] length must not be 9");
/*    */     }
/*    */     
/* 49 */     if (StringUtils.isEmpty(this.keyID)) {
/* 50 */       throw new IllegalUafFieldException("DeregisterAuthenticator[keyID] must not be null/empty/missing.");
/*    */     }
/*    */     
/* 53 */     if (this.keyID.length() < 32) {
/* 54 */       throw new IllegalUafFieldException("DeregisterAuthenticator[aaid] length must not be greater then 32");
/*    */     }
/*    */     
/* 57 */     if (this.keyID.length() > 2048) {
/* 58 */       throw new IllegalUafFieldException("DeregisterAuthenticator[aaid] length must not be less then 2048");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     StringBuilder builder = new StringBuilder();
/* 65 */     builder.append("DeregisterAuthenticator [aaid=").append(this.aaid).append(", keyID=").append(this.keyID).append("]");
/* 66 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 76 */     out.writeInt(1);
/* 77 */     SerializationUtils.writeSafeUTF(out, this.aaid);
/* 78 */     SerializationUtils.writeSafeUTF(out, this.keyID);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 82 */     int ver = in.readInt();
/* 83 */     if (1 == ver) {
/* 84 */       this.aaid = SerializationUtils.readSafeUTF(in);
/* 85 */       this.keyID = SerializationUtils.readSafeUTF(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\DeregisterAuthenticator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */