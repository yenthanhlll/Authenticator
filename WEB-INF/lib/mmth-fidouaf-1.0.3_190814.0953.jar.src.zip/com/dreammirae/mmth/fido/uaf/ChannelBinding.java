/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelBinding
/*     */   implements IUafProtocol
/*     */ {
/*     */   private String serverEndPoint;
/*     */   private String tlsServerCertificate;
/*     */   private String tlsUnique;
/*     */   private String cid_pubkey;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getServerEndPoint() {
/* 108 */     return this.serverEndPoint;
/*     */   }
/*     */   
/*     */   public void setServerEndPoint(String serverEndPoint) {
/* 112 */     this.serverEndPoint = serverEndPoint;
/*     */   }
/*     */   
/*     */   public String getTlsServerCertificate() {
/* 116 */     return this.tlsServerCertificate;
/*     */   }
/*     */   
/*     */   public void setTlsServerCertificate(String tlsServerCertificate) {
/* 120 */     this.tlsServerCertificate = tlsServerCertificate;
/*     */   }
/*     */   
/*     */   public String getTlsUnique() {
/* 124 */     return this.tlsUnique;
/*     */   }
/*     */   
/*     */   public void setTlsUnique(String tlsUnique) {
/* 128 */     this.tlsUnique = tlsUnique;
/*     */   }
/*     */   
/*     */   public String getCid_pubkey() {
/* 132 */     return this.cid_pubkey;
/*     */   }
/*     */   
/*     */   public void setCid_pubkey(String cid_pubkey) {
/* 136 */     this.cid_pubkey = cid_pubkey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int prime = 31;
/* 155 */     int result = 1;
/* 156 */     result = 31 * result + ((this.cid_pubkey == null) ? 0 : this.cid_pubkey.hashCode());
/* 157 */     result = 31 * result + ((this.serverEndPoint == null) ? 0 : this.serverEndPoint.hashCode());
/* 158 */     result = 31 * result + ((this.tlsServerCertificate == null) ? 0 : this.tlsServerCertificate.hashCode());
/* 159 */     result = 31 * result + ((this.tlsUnique == null) ? 0 : this.tlsUnique.hashCode());
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 168 */     if (this == obj)
/* 169 */       return true; 
/* 170 */     if (obj == null)
/* 171 */       return false; 
/* 172 */     if (getClass() != obj.getClass())
/* 173 */       return false; 
/* 174 */     ChannelBinding other = (ChannelBinding)obj;
/* 175 */     if (this.cid_pubkey == null) {
/* 176 */       if (other.cid_pubkey != null)
/* 177 */         return false; 
/* 178 */     } else if (!this.cid_pubkey.equals(other.cid_pubkey)) {
/* 179 */       return false;
/* 180 */     }  if (this.serverEndPoint == null) {
/* 181 */       if (other.serverEndPoint != null)
/* 182 */         return false; 
/* 183 */     } else if (!this.serverEndPoint.equals(other.serverEndPoint)) {
/* 184 */       return false;
/* 185 */     }  if (this.tlsServerCertificate == null) {
/* 186 */       if (other.tlsServerCertificate != null)
/* 187 */         return false; 
/* 188 */     } else if (!this.tlsServerCertificate.equals(other.tlsServerCertificate)) {
/* 189 */       return false;
/* 190 */     }  if (this.tlsUnique == null) {
/* 191 */       if (other.tlsUnique != null)
/* 192 */         return false; 
/* 193 */     } else if (!this.tlsUnique.equals(other.tlsUnique)) {
/* 194 */       return false;
/* 195 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     StringBuilder builder = new StringBuilder();
/* 203 */     builder.append("ChannelBinding [serverEndPoint=").append(this.serverEndPoint).append(", tlsServerCertificate=")
/* 204 */       .append(this.tlsServerCertificate).append(", tlsUnique=").append(this.tlsUnique).append(", cid_pubkey=")
/* 205 */       .append(this.cid_pubkey).append("]");
/* 206 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 216 */     out.writeInt(1);
/* 217 */     SerializationUtils.writeSafeUTF(out, this.serverEndPoint);
/* 218 */     SerializationUtils.writeSafeUTF(out, this.tlsServerCertificate);
/* 219 */     SerializationUtils.writeSafeUTF(out, this.tlsUnique);
/* 220 */     SerializationUtils.writeSafeUTF(out, this.cid_pubkey);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 224 */     int ver = in.readInt();
/* 225 */     if (1 == ver) {
/* 226 */       this.serverEndPoint = SerializationUtils.readSafeUTF(in);
/* 227 */       this.tlsServerCertificate = SerializationUtils.readSafeUTF(in);
/* 228 */       this.tlsUnique = SerializationUtils.readSafeUTF(in);
/* 229 */       this.cid_pubkey = SerializationUtils.readSafeUTF(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\ChannelBinding.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */