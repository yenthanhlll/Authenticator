package com.dreammirae.mmth.fido.uaf;

public interface IUafProtocolResponseMessage extends IUafProtocolMessage {
  FinalChallengeParams getFcParamsDeserialized();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\IUafProtocolResponseMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */