/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transaction
/*     */   implements IUafProtocol
/*     */ {
/*     */   public static final String TC_DISPLAY_CONTENT_TYPE_TEXT_PALIN = "text/plain";
/*     */   public static final String TC_DISPLAY_CONTENT_TYPE_IMAGE_PNG = "image/png";
/*     */   private String contentType;
/*     */   private String content;
/*     */   private DisplayPNGCharacteristicsDescriptor tcDisplayPNGCharacteristics;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getContentType() {
/*  48 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void setContentType(String contentType) {
/*  52 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */   public String getContent() {
/*  56 */     return this.content;
/*     */   }
/*     */   
/*     */   public void setContent(String content) {
/*  60 */     this.content = content;
/*     */   }
/*     */   
/*     */   public DisplayPNGCharacteristicsDescriptor getTcDisplayPNGCharacteristics() {
/*  64 */     return this.tcDisplayPNGCharacteristics;
/*     */   }
/*     */   
/*     */   public void setTcDisplayPNGCharacteristics(DisplayPNGCharacteristicsDescriptor tcDisplayPNGCharacteristics) {
/*  68 */     this.tcDisplayPNGCharacteristics = tcDisplayPNGCharacteristics;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/*  74 */     if (StringUtils.isEmpty(this.contentType)) {
/*  75 */       throw new IllegalUafFieldException("Transaction[contentType] must not be null/empty/missing.");
/*     */     }
/*     */     
/*  78 */     if (!isValidContentType(this.contentType)) {
/*  79 */       throw new IllegalUafFieldException("Transaction[contentType] is invalid.");
/*     */     }
/*     */     
/*  82 */     if (StringUtils.isEmpty(this.content)) {
/*  83 */       throw new IllegalUafFieldException("Transaction[contentType] must not be null/empty/missing.");
/*     */     }
/*     */     
/*  86 */     if ("text/plain".equals(this.contentType) && 
/*  87 */       this.content.length() > 200) {
/*  88 */       throw new IllegalUafFieldException("Transaction[content] must not be greater than 200");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  93 */     if (Base64Utils.isBase64(this.content)) {
/*  94 */       throw new IllegalUafFieldException("Transaction[content] must not be base64url encoded.");
/*     */     }
/*     */     
/*  97 */     if ("image/png".equals(this.contentType) && 
/*  98 */       this.tcDisplayPNGCharacteristics == null) {
/*  99 */       throw new IllegalUafFieldException("Transaction[tcDisplayPNGCharacteristics] must be present if the contentType is 'image/png'");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidContentType(String contentType) {
/* 107 */     return ("text/plain".equals(contentType) || "image/png"
/* 108 */       .equals(contentType));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     StringBuilder builder = new StringBuilder();
/* 114 */     builder.append("Transaction [contentType=").append(this.contentType).append(", content=").append(this.content)
/* 115 */       .append(", tcDisplayPNGCharacteristics=").append(this.tcDisplayPNGCharacteristics).append("]");
/* 116 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 126 */     out.writeInt(1);
/* 127 */     SerializationUtils.writeSafeUTF(out, this.contentType);
/* 128 */     SerializationUtils.writeSafeUTF(out, this.content);
/* 129 */     SerializationUtils.writeSafeObject(out, this.tcDisplayPNGCharacteristics);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 133 */     int ver = in.readInt();
/* 134 */     if (1 == ver) {
/* 135 */       this.contentType = SerializationUtils.readSafeUTF(in);
/* 136 */       this.content = SerializationUtils.readSafeUTF(in);
/* 137 */       this.tcDisplayPNGCharacteristics = (DisplayPNGCharacteristicsDescriptor)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\Transaction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */