/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistrationResponse
/*     */   implements IUafProtocolResponseMessage
/*     */ {
/*     */   private OperationHeader header;
/*     */   private FinalChallengeParams fcParamsDeserialized;
/*     */   private String fcParams;
/*     */   private AuthenticatorRegistrationAssertion[] assertions;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getFcParams() {
/*  37 */     return this.fcParams;
/*     */   }
/*     */   
/*     */   public void setFcParams(String fcParams) {
/*  41 */     this.fcParams = fcParams;
/*     */   }
/*     */ 
/*     */   
/*     */   public FinalChallengeParams getFcParamsDeserialized() {
/*  46 */     return this.fcParamsDeserialized;
/*     */   }
/*     */   
/*     */   public void setFcParamsDeserialized(FinalChallengeParams fcParamsDeserialized) {
/*  50 */     this.fcParamsDeserialized = fcParamsDeserialized;
/*     */   }
/*     */ 
/*     */   
/*     */   public OperationHeader getHeader() {
/*  55 */     return this.header;
/*     */   }
/*     */   
/*     */   public void setHeader(OperationHeader header) {
/*  59 */     this.header = header;
/*     */   }
/*     */   
/*     */   public AuthenticatorRegistrationAssertion[] getAssertions() {
/*  63 */     return this.assertions;
/*     */   }
/*     */   
/*     */   public void setAssertions(AuthenticatorRegistrationAssertion[] assertions) {
/*  67 */     this.assertions = assertions;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  72 */     StringBuilder builder = new StringBuilder();
/*  73 */     builder.append("RegistrationResponse [header=").append(this.header).append(", fcParams=").append(this.fcParams)
/*  74 */       .append(", assertions=").append(Arrays.toString((Object[])this.assertions)).append("]");
/*  75 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/*  82 */     if (this.header == null) {
/*  83 */       throw new IllegalUafFieldException("RegistrationResponse[header] must not be null/empty/missing.");
/*     */     }
/*  85 */     this.header.validateField();
/*     */ 
/*     */     
/*  88 */     if (StringUtils.isEmpty(this.fcParams)) {
/*  89 */       throw new IllegalUafFieldException("RegistrationResponse[fcParams] must not be null/empty/missing.");
/*     */     }
/*  91 */     if (this.assertions == null || this.assertions.length == 0) {
/*  92 */       throw new IllegalUafFieldException("RegistrationResponse[assertions] must not be be null/empty/missing.");
/*     */     }
/*  94 */     if (this.assertions.length > 1) {
/*  95 */       throw new IllegalUafFieldException("RegistrationResponse[assertions] must be contain only.");
/*     */     }
/*  97 */     this.fcParamsDeserialized.validateField();
/*     */     
/*  99 */     for (AuthenticatorRegistrationAssertion ass : this.assertions) {
/* 100 */       ass.validateField();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 113 */     out.writeInt(1);
/* 114 */     SerializationUtils.writeSafeObject(out, this.header);
/* 115 */     SerializationUtils.writeSafeObject(out, this.fcParams);
/* 116 */     SerializationUtils.writeSafeObject(out, this.assertions);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 120 */     int ver = in.readInt();
/* 121 */     if (1 == ver) {
/* 122 */       this.header = (OperationHeader)SerializationUtils.readSafeObject(in);
/* 123 */       this.fcParams = (String)SerializationUtils.readSafeObject(in);
/* 124 */       this.assertions = (AuthenticatorRegistrationAssertion[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\RegistrationResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */