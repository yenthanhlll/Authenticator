/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.FidoUAFUtils;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FinalChallengeParams
/*     */   implements IUafProtocol
/*     */ {
/*     */   private String appID;
/*     */   private String challenge;
/*     */   private String facetID;
/*     */   private ChannelBinding channelBinding;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getAppID() {
/*  81 */     return this.appID;
/*     */   }
/*     */   
/*     */   public void setAppID(String appID) {
/*  85 */     this.appID = appID;
/*     */   }
/*     */   
/*     */   public String getChallenge() {
/*  89 */     return this.challenge;
/*     */   }
/*     */   
/*     */   public void setChallenge(String challenge) {
/*  93 */     this.challenge = challenge;
/*     */   }
/*     */   
/*     */   public String getFacetID() {
/*  97 */     return this.facetID;
/*     */   }
/*     */   
/*     */   public void setFacetID(String facetID) {
/* 101 */     this.facetID = facetID;
/*     */   }
/*     */   
/*     */   public ChannelBinding getChannelBinding() {
/* 105 */     return this.channelBinding;
/*     */   }
/*     */   
/*     */   public void setChannelBinding(ChannelBinding channelBinding) {
/* 109 */     this.channelBinding = channelBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 115 */     if (StringUtils.isEmpty(this.appID)) {
/* 116 */       throw new IllegalUafFieldException("FinalChallengeParams[appID] must not be null/empty/missing.");
/*     */     }
/* 118 */     if (this.appID.length() > 512) {
/* 119 */       throw new IllegalUafFieldException("FinalChallengeParams[appID] must be between 1 and 512");
/*     */     }
/*     */     
/* 122 */     if (StringUtils.isEmpty(this.challenge)) {
/* 123 */       throw new IllegalUafFieldException("FinalChallengeParams[challenge] must not be null/empty/missing.");
/*     */     }
/* 125 */     if (!Base64Utils.isBase64(this.challenge)) {
/* 126 */       throw new IllegalUafFieldException("FinalChallengeParams[challenge] must be base64url encoded.");
/*     */     }
/* 128 */     if (this.challenge.length() < 8) {
/* 129 */       throw new IllegalUafFieldException("FinalChallengeParams[challenge] must not be less than 8");
/*     */     }
/*     */     
/* 132 */     if (this.challenge.length() > 64) {
/* 133 */       throw new IllegalUafFieldException("FinalChallengeParams[challenge] must not be greater than 64");
/*     */     }
/*     */     
/* 136 */     if (StringUtils.isEmpty(this.facetID)) {
/* 137 */       throw new IllegalUafFieldException("FinalChallengeParams[facetID] must not be null/empty/missing.");
/*     */     }
/*     */     
/* 140 */     if (this.facetID.length() > 512) {
/* 141 */       throw new IllegalUafFieldException("FinalChallengeParams[facetID] must not be greater than 512");
/*     */     }
/*     */     
/* 144 */     if (!FidoUAFUtils.validateFacetId(this.facetID)) {
/* 145 */       throw new IllegalUafFieldException("FinalChallengeParams[facetID] is invalid. facetID = " + this.facetID);
/*     */     }
/*     */     
/* 148 */     if (this.channelBinding == null) {
/* 149 */       throw new IllegalUafFieldException("FinalChallengeParams[channelBinding] must not be null/empty/missing.");
/*     */     }
/*     */     
/* 152 */     this.channelBinding.validateField();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     StringBuilder sb = new StringBuilder();
/* 158 */     sb.append("FinalChallengeParams [appID=").append(this.appID).append(", challenge=").append(this.challenge)
/* 159 */       .append(", facetID=").append(this.facetID).append(", channelBinding=").append(this.channelBinding).append("]");
/* 160 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 170 */     out.writeInt(1);
/* 171 */     SerializationUtils.writeSafeUTF(out, this.appID);
/* 172 */     SerializationUtils.writeSafeUTF(out, this.challenge);
/* 173 */     SerializationUtils.writeSafeUTF(out, this.facetID);
/* 174 */     SerializationUtils.writeSafeObject(out, this.channelBinding);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 178 */     int ver = in.readInt();
/* 179 */     if (1 == ver) {
/* 180 */       this.appID = SerializationUtils.readSafeUTF(in);
/* 181 */       this.challenge = SerializationUtils.readSafeUTF(in);
/* 182 */       this.facetID = SerializationUtils.readSafeUTF(in);
/* 183 */       this.channelBinding = (ChannelBinding)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\FinalChallengeParams.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */