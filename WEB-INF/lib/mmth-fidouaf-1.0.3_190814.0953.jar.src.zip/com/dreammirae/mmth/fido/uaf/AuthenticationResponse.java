/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationResponse
/*     */   implements IUafProtocolResponseMessage
/*     */ {
/*     */   private OperationHeader header;
/*     */   private String fcParams;
/*     */   private FinalChallengeParams fcParamsDeserialized;
/*     */   private AuthenticatorSignAssertion[] assertions;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public OperationHeader getHeader() {
/*  46 */     return this.header;
/*     */   }
/*     */   
/*     */   public void setHeader(OperationHeader header) {
/*  50 */     this.header = header;
/*     */   }
/*     */   
/*     */   public String getFcParams() {
/*  54 */     return this.fcParams;
/*     */   }
/*     */   
/*     */   public void setFcParams(String fcParams) {
/*  58 */     this.fcParams = fcParams;
/*     */   }
/*     */   
/*     */   public AuthenticatorSignAssertion[] getAssertions() {
/*  62 */     return this.assertions;
/*     */   }
/*     */   
/*     */   public void setAssertions(AuthenticatorSignAssertion[] assertions) {
/*  66 */     this.assertions = assertions;
/*     */   }
/*     */ 
/*     */   
/*     */   public FinalChallengeParams getFcParamsDeserialized() {
/*  71 */     return this.fcParamsDeserialized;
/*     */   }
/*     */   
/*     */   public void setFcParamsDeserialized(FinalChallengeParams fcParamDeserialized) {
/*  75 */     this.fcParamsDeserialized = fcParamDeserialized;
/*     */   }
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/*  80 */     if (this.header == null) {
/*  81 */       throw new IllegalUafFieldException("AuthenticationResponse[header] must not be null/empty/missing.");
/*     */     }
/*  83 */     if (StringUtils.isEmpty(this.fcParams)) {
/*  84 */       throw new IllegalUafFieldException("AuthenticationResponse[fcParams] must not be null/empty/missing.");
/*     */     }
/*  86 */     if (this.assertions == null || this.assertions.length == 0) {
/*  87 */       throw new IllegalUafFieldException("AuthenticationResponse[assertions] must not be be null/empty/missing.");
/*     */     }
/*  89 */     this.header.validateField();
/*  90 */     this.fcParamsDeserialized.validateField();
/*     */     
/*  92 */     for (AuthenticatorSignAssertion ass : this.assertions) {
/*  93 */       ass.validateField();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     StringBuilder sb = new StringBuilder();
/* 100 */     sb.append("AuthenticationResponse [header=").append(this.header).append(", fcParams=").append(this.fcParams)
/* 101 */       .append(", assertions=").append(Arrays.toString((Object[])this.assertions)).append("]");
/* 102 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 112 */     out.writeInt(1);
/* 113 */     SerializationUtils.writeSafeObject(out, this.header);
/* 114 */     SerializationUtils.writeSafeObject(out, this.fcParams);
/* 115 */     SerializationUtils.writeSafeObject(out, this.assertions);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 119 */     int ver = in.readInt();
/* 120 */     if (1 == ver) {
/* 121 */       this.header = (OperationHeader)SerializationUtils.readSafeObject(in);
/* 122 */       this.fcParams = (String)SerializationUtils.readSafeObject(in);
/* 123 */       this.assertions = (AuthenticatorSignAssertion[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\AuthenticationResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */