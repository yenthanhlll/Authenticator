/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.AuthAssertionLocator;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticatorSignAssertion
/*     */   implements IUafProtocol
/*     */ {
/*     */   private String assertionScheme;
/*     */   private String assertion;
/*     */   private Extension[] exts;
/*     */   private transient AuthAssertionLocator assertionLocator;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String getAssertionScheme() {
/*  44 */     return this.assertionScheme;
/*     */   }
/*     */   
/*     */   public void setAssertionScheme(String assertionScheme) {
/*  48 */     this.assertionScheme = assertionScheme;
/*     */   }
/*     */   
/*     */   public String getAssertion() {
/*  52 */     return this.assertion;
/*     */   }
/*     */   
/*     */   public void setAssertion(String assertion) {
/*  56 */     this.assertion = assertion;
/*     */   }
/*     */   
/*     */   public Extension[] getExts() {
/*  60 */     return this.exts;
/*     */   }
/*     */   
/*     */   public void setExts(Extension[] exts) {
/*  64 */     this.exts = exts;
/*     */   }
/*     */   
/*     */   public AuthAssertionLocator getAssertionLocator() {
/*  68 */     return this.assertionLocator;
/*     */   }
/*     */   
/*     */   public void setAssertionLocator(AuthAssertionLocator assertionLocator) {
/*  72 */     this.assertionLocator = assertionLocator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/*  77 */     if (StringUtils.isEmpty(this.assertionScheme)) {
/*  78 */       throw new IllegalUafFieldException("AuthenticatorSignAssertion[assertionScheme] must not be null/empty/missing.");
/*     */     }
/*     */     
/*  81 */     if (StringUtils.isEmpty(this.assertion)) {
/*  82 */       throw new IllegalUafFieldException("AuthenticatorSignAssertion[assertion] must not be null/empty/missing.");
/*     */     }
/*  84 */     if (!"UAFV1TLV".equals(this.assertionScheme)) {
/*  85 */       throw new IllegalUafFieldException("AuthenticatorRegistrationAssertion[assertionScheme] must be UAFV1TLV");
/*     */     }
/*     */ 
/*     */     
/*  89 */     if (this.assertionLocator == null) {
/*  90 */       throw new IllegalUafFieldException("AuthenticatorSignAssertion[assertion] is failed to parse.");
/*     */     }
/*  92 */     this.assertionLocator.validateField();
/*     */     
/*  94 */     if (this.exts != null) {
/*  95 */       for (Extension ext : this.exts) {
/*  96 */         ext.validateField();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     StringBuilder builder = new StringBuilder();
/* 104 */     builder.append("AuthenticatorSignAssertion [assertionScheme=").append(this.assertionScheme).append(", assertion=")
/* 105 */       .append(this.assertion).append(", exts=").append(Arrays.toString((Object[])this.exts)).append(", assertionLocator=")
/* 106 */       .append(this.assertionLocator).append("]");
/* 107 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 117 */     out.writeInt(1);
/* 118 */     SerializationUtils.writeSafeUTF(out, this.assertionScheme);
/* 119 */     SerializationUtils.writeSafeUTF(out, this.assertion);
/* 120 */     SerializationUtils.writeSafeObject(out, this.exts);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 124 */     int ver = in.readInt();
/* 125 */     if (1 == ver) {
/* 126 */       this.assertionScheme = SerializationUtils.readSafeUTF(in);
/* 127 */       this.assertion = SerializationUtils.readSafeUTF(in);
/* 128 */       this.exts = (Extension[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\AuthenticatorSignAssertion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */