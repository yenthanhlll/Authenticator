/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Extension
/*     */   implements IUafProtocol
/*     */ {
/*     */   private String id;
/*     */   private String data;
/*     */   private Boolean fail_if_unknown;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public Extension() {}
/*     */   
/*     */   public Extension(String id, String data, boolean fail_if_unknown) {
/*  71 */     this.id = id;
/*  72 */     this.data = data;
/*  73 */     this.fail_if_unknown = Boolean.valueOf(fail_if_unknown);
/*     */   }
/*     */   
/*     */   public String getId() {
/*  77 */     return this.id;
/*     */   }
/*     */   
/*     */   public Extension setId(String id) {
/*  81 */     this.id = id;
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   public String getData() {
/*  86 */     return this.data;
/*     */   }
/*     */   
/*     */   public Extension setData(String data) {
/*  90 */     this.data = data;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   public Boolean isFailIfUnknown() {
/*  95 */     return this.fail_if_unknown;
/*     */   }
/*     */   
/*     */   public Extension setFailIfUnknown(Boolean fail_if_unknown) {
/*  99 */     this.fail_if_unknown = fail_if_unknown;
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 105 */     if (StringUtils.isEmpty(this.id)) {
/* 106 */       throw new IllegalUafJsonException("Extension[id] is required. ");
/*     */     }
/*     */     
/* 109 */     if (this.id.length() > 32) {
/* 110 */       throw new IllegalUafJsonException("Extension[id] can not be greater than 32");
/*     */     }
/*     */     
/* 113 */     if (StringUtils.isEmpty(this.data)) {
/* 114 */       throw new IllegalUafJsonException("Extension[data] is required. ");
/*     */     }
/*     */     
/* 117 */     if (!Base64Utils.isBase64(this.data)) {
/* 118 */       throw new IllegalUafJsonException("Extension[data] must base64url encoded. ");
/*     */     }
/*     */     
/* 121 */     if (this.fail_if_unknown == null) {
/* 122 */       throw new IllegalUafJsonException("Extension[fail_if_unknown] is required. ");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     StringBuilder sb = new StringBuilder();
/* 130 */     sb.append("Extension [id=").append(this.id).append(", data=").append(this.data).append(", fail_if_unknown=")
/* 131 */       .append(this.fail_if_unknown).append("]");
/* 132 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 142 */     out.writeInt(1);
/* 143 */     SerializationUtils.writeSafeUTF(out, this.id);
/* 144 */     SerializationUtils.writeSafeUTF(out, this.data);
/* 145 */     out.writeBoolean(this.fail_if_unknown.booleanValue());
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 149 */     int ver = in.readInt();
/* 150 */     if (1 == ver) {
/* 151 */       this.id = SerializationUtils.readSafeUTF(in);
/* 152 */       this.data = SerializationUtils.readSafeUTF(in);
/* 153 */       this.fail_if_unknown = Boolean.valueOf(in.readBoolean());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\Extension.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */