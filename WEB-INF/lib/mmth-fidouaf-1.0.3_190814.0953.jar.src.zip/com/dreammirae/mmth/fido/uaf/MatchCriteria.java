/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MatchCriteria
/*     */   implements IUafProtocol
/*     */ {
/*     */   private String[] aaid;
/*     */   private String vendorID;
/*     */   private String[] keyIDs;
/*     */   private Long userVerification;
/*     */   private Short keyProtection;
/*     */   private Short matcherProtection;
/*     */   private Long attachmentHint;
/*     */   private Short tcDisplay;
/*     */   private Short[] authenticationAlgorithms;
/*     */   private String[] assertionSchemes;
/*     */   private Short[] attestationTypes;
/*     */   private Short authenticatorVersion;
/*     */   private Extension[] exts;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public String[] getAaid() {
/* 250 */     return this.aaid;
/*     */   }
/*     */   
/*     */   public MatchCriteria setAaid(String[] aaid) {
/* 254 */     this.aaid = aaid;
/* 255 */     return this;
/*     */   }
/*     */   
/*     */   public String getVendorID() {
/* 259 */     return this.vendorID;
/*     */   }
/*     */   
/*     */   public MatchCriteria setVendorID(String vendorID) {
/* 263 */     this.vendorID = vendorID;
/* 264 */     return this;
/*     */   }
/*     */   
/*     */   public String[] getKeyIDs() {
/* 268 */     return this.keyIDs;
/*     */   }
/*     */   
/*     */   public MatchCriteria setKeyIDs(String[] keyIDs) {
/* 272 */     this.keyIDs = keyIDs;
/* 273 */     return this;
/*     */   }
/*     */   
/*     */   public Long getUserVerification() {
/* 277 */     return this.userVerification;
/*     */   }
/*     */   
/*     */   public MatchCriteria setUserVerification(Long userVerification) {
/* 281 */     this.userVerification = userVerification;
/* 282 */     return this;
/*     */   }
/*     */   
/*     */   public short getKeyProtection() {
/* 286 */     return this.keyProtection.shortValue();
/*     */   }
/*     */   
/*     */   public MatchCriteria setKeyProtection(Short keyProtection) {
/* 290 */     this.keyProtection = keyProtection;
/* 291 */     return this;
/*     */   }
/*     */   
/*     */   public Short getMatcherProtection() {
/* 295 */     return this.matcherProtection;
/*     */   }
/*     */   
/*     */   public MatchCriteria setMatcherProtection(Short matcherProtection) {
/* 299 */     this.matcherProtection = matcherProtection;
/* 300 */     return this;
/*     */   }
/*     */   
/*     */   public Long getAttachmentHint() {
/* 304 */     return this.attachmentHint;
/*     */   }
/*     */   
/*     */   public MatchCriteria setAttachmentHint(Long attachmentHint) {
/* 308 */     this.attachmentHint = attachmentHint;
/* 309 */     return this;
/*     */   }
/*     */   
/*     */   public Short getTcDisplay() {
/* 313 */     return this.tcDisplay;
/*     */   }
/*     */   
/*     */   public MatchCriteria setTcDisplay(Short tcDisplay) {
/* 317 */     this.tcDisplay = tcDisplay;
/* 318 */     return this;
/*     */   }
/*     */   
/*     */   public Short[] getAuthenticationAlgorithms() {
/* 322 */     return this.authenticationAlgorithms;
/*     */   }
/*     */   
/*     */   public MatchCriteria setAuthenticationAlgorithms(Short[] authenticationAlgorithms) {
/* 326 */     this.authenticationAlgorithms = authenticationAlgorithms;
/* 327 */     return this;
/*     */   }
/*     */   
/*     */   public String[] getAssertionSchemes() {
/* 331 */     return this.assertionSchemes;
/*     */   }
/*     */   
/*     */   public MatchCriteria setAssertionSchemes(String[] assertionSchemes) {
/* 335 */     this.assertionSchemes = assertionSchemes;
/* 336 */     return this;
/*     */   }
/*     */   
/*     */   public Short[] getAttestationTypes() {
/* 340 */     return this.attestationTypes;
/*     */   }
/*     */   
/*     */   public MatchCriteria setAttestationTypes(Short[] attestationTypes) {
/* 344 */     this.attestationTypes = attestationTypes;
/* 345 */     return this;
/*     */   }
/*     */   
/*     */   public Short getAuthenticatorVersion() {
/* 349 */     return this.authenticatorVersion;
/*     */   }
/*     */   
/*     */   public MatchCriteria setAuthenticatorVersion(Short authenticatorVersion) {
/* 353 */     this.authenticatorVersion = authenticatorVersion;
/* 354 */     return this;
/*     */   }
/*     */   
/*     */   public Extension[] getExts() {
/* 358 */     return this.exts;
/*     */   }
/*     */   
/*     */   public MatchCriteria setExts(Extension[] exts) {
/* 362 */     this.exts = exts;
/* 363 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 371 */     if (this.aaid != null) {
/*     */ 
/*     */       
/* 374 */       if (!StringUtils.isEmpty(this.vendorID)) {
/* 375 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with vendorId field.");
/*     */       }
/*     */       
/* 378 */       if (this.keyProtection != null) {
/* 379 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with keyProtection field.");
/*     */       }
/*     */       
/* 382 */       if (this.matcherProtection != null) {
/* 383 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with matcherProtection field.");
/*     */       }
/*     */       
/* 386 */       if (this.tcDisplay != null) {
/* 387 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with tcDisplay field.");
/*     */       }
/*     */       
/* 390 */       if (this.authenticationAlgorithms != null) {
/* 391 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with authenticationAlgorithms field.");
/*     */       }
/*     */       
/* 394 */       if (this.assertionSchemes != null) {
/* 395 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with assertionSchemes field.");
/*     */       }
/*     */       
/* 398 */       if (this.attestationTypes != null) {
/* 399 */         throw new IllegalUafJsonException("MatchCriteria[aaid] must not be combined with attestationTypes field.");
/*     */       
/*     */       }
/*     */     }
/* 403 */     else if (this.authenticationAlgorithms == null || this.assertionSchemes == null) {
/* 404 */       throw new IllegalUafJsonException("MatchCriteria[aaid] is not provided - at least authenticationAlgorithms and assertionSchemes must be provided.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 412 */     StringBuilder builder = new StringBuilder();
/* 413 */     builder.append("MatchCriteria [aaid=").append(Arrays.toString((Object[])this.aaid)).append(", vendorID=").append(this.vendorID)
/* 414 */       .append(", keyIDs=").append(Arrays.toString((Object[])this.keyIDs)).append(", userVerification=")
/* 415 */       .append(this.userVerification).append(", keyProtection=").append(this.keyProtection)
/* 416 */       .append(", matcherProtection=").append(this.matcherProtection).append(", attachmentHint=")
/* 417 */       .append(this.attachmentHint).append(", tcDisplay=").append(this.tcDisplay).append(", authenticationAlgorithms=")
/* 418 */       .append(Arrays.toString((Object[])this.authenticationAlgorithms)).append(", assertionSchemes=")
/* 419 */       .append(Arrays.toString((Object[])this.assertionSchemes)).append(", attestationTypes=")
/* 420 */       .append(Arrays.toString((Object[])this.attestationTypes)).append(", authenticatorVersion=")
/* 421 */       .append(this.authenticatorVersion).append(", exts=").append(Arrays.toString((Object[])this.exts)).append("]");
/* 422 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 432 */     out.writeInt(1);
/* 433 */     SerializationUtils.writeSafeObject(out, this.aaid);
/* 434 */     SerializationUtils.writeSafeUTF(out, this.vendorID);
/* 435 */     SerializationUtils.writeSafeObject(out, this.keyIDs);
/* 436 */     SerializationUtils.writeSafeLong(out, this.userVerification);
/* 437 */     SerializationUtils.writeSafeShort(out, this.keyProtection);
/* 438 */     SerializationUtils.writeSafeShort(out, this.matcherProtection);
/* 439 */     SerializationUtils.writeSafeLong(out, this.attachmentHint);
/* 440 */     SerializationUtils.writeSafeShort(out, this.tcDisplay);
/* 441 */     SerializationUtils.writeSafeObject(out, this.authenticationAlgorithms);
/* 442 */     SerializationUtils.writeSafeObject(out, this.assertionSchemes);
/* 443 */     SerializationUtils.writeSafeObject(out, this.attestationTypes);
/* 444 */     SerializationUtils.writeSafeShort(out, this.authenticatorVersion);
/* 445 */     SerializationUtils.writeSafeObject(out, this.exts);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 449 */     int ver = in.readInt();
/* 450 */     if (1 == ver) {
/* 451 */       this.aaid = (String[])SerializationUtils.readSafeObject(in);
/* 452 */       this.vendorID = SerializationUtils.readSafeUTF(in);
/* 453 */       this.keyIDs = (String[])SerializationUtils.readSafeObject(in);
/* 454 */       this.userVerification = SerializationUtils.readSafeLong(in);
/* 455 */       this.keyProtection = SerializationUtils.readSafeShort(in);
/* 456 */       this.matcherProtection = SerializationUtils.readSafeShort(in);
/* 457 */       this.attachmentHint = SerializationUtils.readSafeLong(in);
/* 458 */       this.tcDisplay = SerializationUtils.readSafeShort(in);
/* 459 */       this.authenticationAlgorithms = (Short[])SerializationUtils.readSafeObject(in);
/* 460 */       this.assertionSchemes = (String[])SerializationUtils.readSafeObject(in);
/* 461 */       this.attestationTypes = (Short[])SerializationUtils.readSafeObject(in);
/* 462 */       this.authenticatorVersion = SerializationUtils.readSafeShort(in);
/* 463 */       this.exts = (Extension[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\MatchCriteria.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */