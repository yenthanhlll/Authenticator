/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OperationHeader
/*     */   implements IUafProtocol
/*     */ {
/*     */   private Version upv;
/*     */   private Operation op;
/*     */   private String appID;
/*     */   private String serverData;
/*     */   private Extension[] exts;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public OperationHeader() {}
/*     */   
/*     */   public OperationHeader(Version upv, Operation op) {
/*  59 */     this.upv = upv;
/*  60 */     this.op = op;
/*     */   }
/*     */   
/*     */   public Version getUpv() {
/*  64 */     return this.upv;
/*     */   }
/*     */   
/*     */   public void setUpv(Version upv) {
/*  68 */     this.upv = upv;
/*     */   }
/*     */   
/*     */   public Operation getOp() {
/*  72 */     return this.op;
/*     */   }
/*     */   
/*     */   public void setOp(Operation op) {
/*  76 */     this.op = op;
/*     */   }
/*     */   
/*     */   public String getAppID() {
/*  80 */     return this.appID;
/*     */   }
/*     */   
/*     */   public void setAppID(String appID) {
/*  84 */     this.appID = appID;
/*     */   }
/*     */   
/*     */   public String getServerData() {
/*  88 */     return this.serverData;
/*     */   }
/*     */   
/*     */   public void setServerData(String serverData) {
/*  92 */     this.serverData = serverData;
/*     */   }
/*     */   
/*     */   public Extension[] getExts() {
/*  96 */     return this.exts;
/*     */   }
/*     */   
/*     */   public void setExts(Extension[] exts) {
/* 100 */     this.exts = exts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 108 */     if (this.op == null) {
/* 109 */       throw new IllegalUafFieldException("OperationHeader[op] must not be null/empty/missing or invalid value(Only accepts Reg,Auth,Dereg).");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (this.upv == null) {
/* 116 */       throw new IllegalUafFieldException("OperationHeader[upv] must not be null/empty/missing.");
/*     */     }
/*     */     
/* 119 */     this.upv.validateField();
/*     */ 
/*     */     
/* 122 */     if (!StringUtils.isEmpty(this.appID))
/*     */     {
/* 124 */       if (this.appID.length() > 512) {
/* 125 */         throw new IllegalUafFieldException("OperationHeader[appID] must be between 1 and 512");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (!StringUtils.isEmpty(this.serverData) && 
/* 132 */       this.serverData.length() > 1536) {
/* 133 */       throw new IllegalUafFieldException("OperationHeader[serverData] must be between 1 and 1536");
/*     */     }
/*     */ 
/*     */     
/* 137 */     if (this.exts != null) {
/* 138 */       for (Extension ext : this.exts) {
/* 139 */         ext.validateField();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 150 */     int prime = 31;
/* 151 */     int result = 1;
/* 152 */     result = 31 * result + ((this.appID == null) ? 0 : this.appID.hashCode());
/* 153 */     result = 31 * result + Arrays.hashCode((Object[])this.exts);
/* 154 */     result = 31 * result + ((this.op == null) ? 0 : this.op.hashCode());
/* 155 */     result = 31 * result + ((this.serverData == null) ? 0 : this.serverData.hashCode());
/* 156 */     result = 31 * result + ((this.upv == null) ? 0 : this.upv.hashCode());
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 165 */     if (this == obj)
/* 166 */       return true; 
/* 167 */     if (obj == null)
/* 168 */       return false; 
/* 169 */     if (getClass() != obj.getClass())
/* 170 */       return false; 
/* 171 */     OperationHeader other = (OperationHeader)obj;
/* 172 */     if (this.appID == null) {
/* 173 */       if (other.appID != null)
/* 174 */         return false; 
/* 175 */     } else if (!this.appID.equals(other.appID)) {
/* 176 */       return false;
/* 177 */     }  if (!Arrays.equals((Object[])this.exts, (Object[])other.exts))
/* 178 */       return false; 
/* 179 */     if (this.op != other.op)
/* 180 */       return false; 
/* 181 */     if (this.serverData == null) {
/* 182 */       if (other.serverData != null)
/* 183 */         return false; 
/* 184 */     } else if (!this.serverData.equals(other.serverData)) {
/* 185 */       return false;
/* 186 */     }  if (this.upv == null) {
/* 187 */       if (other.upv != null)
/* 188 */         return false; 
/* 189 */     } else if (!this.upv.equals(other.upv)) {
/* 190 */       return false;
/* 191 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 198 */     StringBuilder sb = new StringBuilder();
/* 199 */     sb.append("OperationHeader [upv=").append(this.upv).append(", op=").append(this.op).append(", appID=").append(this.appID)
/* 200 */       .append(", serverData=").append(this.serverData).append(", exts=").append(Arrays.toString((Object[])this.exts)).append("]");
/* 201 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 211 */     out.writeInt(1);
/* 212 */     SerializationUtils.writeSafeObject(out, this.upv);
/* 213 */     SerializationUtils.writeSafeObject(out, this.op);
/* 214 */     SerializationUtils.writeSafeUTF(out, this.appID);
/* 215 */     SerializationUtils.writeSafeUTF(out, this.serverData);
/* 216 */     SerializationUtils.writeSafeObject(out, this.exts);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 220 */     int ver = in.readInt();
/* 221 */     if (1 == ver) {
/* 222 */       this.upv = (Version)SerializationUtils.readSafeObject(in);
/* 223 */       this.op = (Operation)SerializationUtils.readSafeObject(in);
/* 224 */       this.appID = SerializationUtils.readSafeUTF(in);
/* 225 */       this.serverData = SerializationUtils.readSafeUTF(in);
/* 226 */       this.exts = (Extension[])SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\OperationHeader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */