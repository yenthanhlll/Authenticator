/*     */ package com.dreammirae.mmth.fido.uaf;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistrationRequest
/*     */   implements IUafProtocolMessage
/*     */ {
/*     */   private OperationHeader header;
/*     */   private String challenge;
/*     */   private String username;
/*     */   private Policy policy;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int version = 1;
/*     */   
/*     */   public OperationHeader getHeader() {
/*  81 */     return this.header;
/*     */   }
/*     */   
/*     */   public void setHeader(OperationHeader header) {
/*  85 */     this.header = header;
/*     */   }
/*     */   
/*     */   public String getChallenge() {
/*  89 */     return this.challenge;
/*     */   }
/*     */   
/*     */   public void setChallenge(String challenge) {
/*  93 */     this.challenge = challenge;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  97 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 101 */     this.username = username;
/*     */   }
/*     */   
/*     */   public Policy getPolicy() {
/* 105 */     return this.policy;
/*     */   }
/*     */   
/*     */   public void setPolicy(Policy policy) {
/* 109 */     this.policy = policy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateField() throws IllegalUafFieldException {
/* 115 */     if (this.header == null) {
/* 116 */       throw new IllegalUafFieldException("RegistrationRequest[header] must not be null/empty/missing.");
/*     */     }
/* 118 */     if (StringUtils.isEmpty(this.challenge)) {
/* 119 */       throw new IllegalUafFieldException("RegistrationRequest[challenge] must not be null/empty/missing.");
/*     */     }
/* 121 */     if (!Base64Utils.isBase64(this.challenge)) {
/* 122 */       throw new IllegalUafFieldException("RegistrationRequest[challenge] must be base64url encoded.");
/*     */     }
/* 124 */     if (this.challenge.length() < 8) {
/* 125 */       throw new IllegalUafFieldException("RegistrationRequest[challenge] must not be less than 8");
/*     */     }
/* 127 */     if (this.challenge.length() > 64) {
/* 128 */       throw new IllegalUafFieldException("RegistrationRequest[challenge] must not be greater than 64");
/*     */     }
/* 130 */     if (StringUtils.isEmpty(this.username)) {
/* 131 */       throw new IllegalUafFieldException("RegistrationRequest[username] must not be be null/empty/missing.");
/*     */     }
/* 133 */     if (this.username.length() > 128) {
/* 134 */       throw new IllegalUafFieldException("RegistrationRequest[username] must not be greater than 128");
/*     */     }
/* 136 */     if (this.policy == null) {
/* 137 */       throw new IllegalUafFieldException("RegistrationRequest[policy] must not be be null/empty/missing.");
/*     */     }
/* 139 */     this.header.validateField();
/* 140 */     this.policy.validateField();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     StringBuilder builder = new StringBuilder();
/* 147 */     builder.append("RegistrationRequest [header=").append(this.header).append(", challenge=").append(this.challenge)
/* 148 */       .append(", username=").append(this.username).append(", policy=").append(this.policy).append("]");
/* 149 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 159 */     out.writeInt(1);
/* 160 */     SerializationUtils.writeSafeObject(out, this.header);
/* 161 */     SerializationUtils.writeSafeUTF(out, this.challenge);
/* 162 */     SerializationUtils.writeSafeUTF(out, this.username);
/* 163 */     SerializationUtils.writeSafeObject(out, this.policy);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 167 */     int ver = in.readInt();
/* 168 */     if (1 == ver) {
/* 169 */       this.header = (OperationHeader)SerializationUtils.readSafeObject(in);
/* 170 */       this.challenge = SerializationUtils.readSafeUTF(in);
/* 171 */       this.username = SerializationUtils.readSafeUTF(in);
/* 172 */       this.policy = (Policy)SerializationUtils.readSafeObject(in);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\RegistrationRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */