/*    */ package com.dreammirae.mmth.fido.uaf;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.Operation;
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*    */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeregistrationRequest
/*    */   implements IUafProtocolMessage
/*    */ {
/*    */   private OperationHeader header;
/*    */   private DeregisterAuthenticator[] authenticators;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public OperationHeader getHeader() {
/* 23 */     return this.header;
/*    */   }
/*    */   
/*    */   public void setHeader(OperationHeader header) {
/* 27 */     this.header = header;
/*    */   }
/*    */   
/*    */   public DeregisterAuthenticator[] getAuthenticators() {
/* 31 */     return this.authenticators;
/*    */   }
/*    */   
/*    */   public void setAuthenticators(DeregisterAuthenticator[] authenticators) {
/* 35 */     this.authenticators = authenticators;
/*    */   }
/*    */ 
/*    */   
/*    */   public void validateField() throws IllegalUafFieldException {
/* 40 */     if (this.header == null) {
/* 41 */       throw new IllegalUafJsonException("AuthenticationRequest[header] must not be null/missing/empty.");
/*    */     }
/*    */     
/* 44 */     if (!Operation.Dereg.equals(this.header.getOp())) {
/* 45 */       throw new IllegalUafFieldException("OperationHeader[op] must not be null/empty/missing or only be Dereg.");
/*    */     }
/*    */     
/* 48 */     if (this.header.getUpv() == null) {
/* 49 */       throw new IllegalUafFieldException("OperationHeader[upv] must not be null/empty/missing.");
/*    */     }
/*    */     
/* 52 */     if (this.authenticators == null) {
/* 53 */       throw new IllegalUafJsonException("AuthenticationRequest[authenticators] must not be null/missing/empty.");
/*    */     }
/*    */     
/* 56 */     for (DeregisterAuthenticator authenticator : this.authenticators) {
/* 57 */       authenticator.validateField();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     StringBuilder builder = new StringBuilder();
/* 65 */     builder.append("DeregistrationRequest [header=").append(this.header).append(", authenticators=")
/* 66 */       .append(Arrays.toString((Object[])this.authenticators)).append("]");
/* 67 */     return builder.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException, ClassNotFoundException {
/* 77 */     out.writeInt(1);
/* 78 */     SerializationUtils.writeSafeObject(out, this.header);
/* 79 */     SerializationUtils.writeSafeObject(out, this.authenticators);
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 83 */     int ver = in.readInt();
/* 84 */     if (1 == ver) {
/* 85 */       this.header = (OperationHeader)SerializationUtils.readSafeObject(in);
/* 86 */       this.authenticators = (DeregisterAuthenticator[])SerializationUtils.readSafeObject(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fid\\uaf\DeregistrationRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */