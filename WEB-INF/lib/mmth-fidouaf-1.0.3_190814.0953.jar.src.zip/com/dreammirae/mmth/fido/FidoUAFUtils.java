/*    */ package com.dreammirae.mmth.fido;
/*    */ 
/*    */ import com.dreammirae.mmth.util.StringUtils;
/*    */ import java.net.URI;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ public class FidoUAFUtils
/*    */ {
/* 11 */   private static final Pattern PATTERN_FACETS = Pattern.compile("^((android:apk-key-hash:)+[a-zA-Z0-9\\+\\_\\-\\/]{20,}|(ios:bundle-id:)+[a-zA-Z0-9]?((.+[a-zA-Z0-9]){1,}))$");
/*    */   private static final String PREFIX_CALLER_FACET = "https";
/*    */   
/*    */   public static boolean validateFacetId(String facetId) {
/* 15 */     if (StringUtils.isEmpty(facetId)) {
/* 16 */       return false;
/*    */     }
/*    */     
/* 19 */     Matcher matcher = PATTERN_FACETS.matcher(facetId);
/*    */     
/* 21 */     if (matcher.matches()) {
/* 22 */       return true;
/*    */     }
/*    */     
/* 25 */     if (!facetId.startsWith("https")) {
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     return validateURIWithHttp(facetId);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean validateURIWithHttp(String uri) {
/*    */     try {
/* 35 */       URI u = URI.create(uri);
/* 36 */       return u.getScheme().startsWith("https");
/* 37 */     } catch (Exception e1) {
/* 38 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 44 */     String[] facetId = { "android:apk-key-hash:Tqm01JT@@", "android:apk-keyaMZmz10drt1ioAg3srzyzAQDbOo", "android:apk-key-hash:9rbgAd1GHxD4USYU/TqZOdFib94", "android:apk-key-hash:qEQ6H1L9SLlC7Vy2RcjIL/iHeIM", "android:apk-key-hash:SvYZ4Sgas9T2+6DpNj566iscuns", "android:apk-key-hash:6URnT6fxySeiTmb5b2PfIqGhHDM", "android:apk-key-hash:n5NzMo68EKCfX7XG9ouMy841T6o", "ios:bundle-id:org.fidoalliance.ios.conformance", "https://demo-oc.intel.com", "ios:bundle-id:com.etri.rpclient" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     for (String string : facetId)
/* 62 */       System.out.println(string + "  " + validateFacetId(string)); 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\FidoUAFUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */