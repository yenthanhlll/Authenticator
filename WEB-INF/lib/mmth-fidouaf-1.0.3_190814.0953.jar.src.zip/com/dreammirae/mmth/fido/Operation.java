/*    */ package com.dreammirae.mmth.fido;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Operation
/*    */ {
/* 22 */   Reg,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 27 */   Auth,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   Dereg;
/*    */   
/*    */   public static boolean isValidOperation(String name) {
/* 35 */     Operation op = getOperation(name);
/* 36 */     return (op != null);
/*    */   }
/*    */   
/*    */   public static Operation getOperation(String name) {
/* 40 */     for (Operation op : values()) {
/* 41 */       if (op.name().equals(name)) {
/* 42 */         return op;
/*    */       }
/*    */     } 
/*    */     
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\Operation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */