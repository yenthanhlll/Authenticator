/*    */ package com.dreammirae.mmth.fido.handler;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.Operation;
/*    */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*    */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*    */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageCallback;
/*    */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageSupporter;
/*    */ import com.dreammirae.mmth.fido.json.UafSerializeUtils;
/*    */ import com.dreammirae.mmth.fido.uaf.RegistrationRequest;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegUAFRequestHandler<T extends IFidoRegistrionLocator>
/*    */   extends UAFRequestHandler<T>
/*    */ {
/*    */   protected RegUAFRequestHandler(ReqMessageSupporter<T> supporter, ReqMessageCallback<T> callback) {
/* 24 */     super(supporter, callback);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String generateMessageImp(List<T> registrations, String username) throws FidoUafStatusCodeException {
/* 31 */     RegistrationRequest[] regReq = new RegistrationRequest[1];
/* 32 */     RegistrationRequest reg = new RegistrationRequest();
/* 33 */     reg.setHeader(getHeader());
/* 34 */     reg.setPolicy(getPolicy(registrations));
/* 35 */     reg.setUsername(username);
/* 36 */     reg.setChallenge(getServerDataLocator().getChallenge());
/* 37 */     regReq[0] = reg;
/*    */     
/* 39 */     return UafSerializeUtils.gson().toJson(regReq);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Operation getOperation() {
/* 44 */     return Operation.Reg;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\RegUAFRequestHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */