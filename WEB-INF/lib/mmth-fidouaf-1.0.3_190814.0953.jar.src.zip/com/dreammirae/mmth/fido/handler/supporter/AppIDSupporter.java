/*    */ package com.dreammirae.mmth.fido.handler.supporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AppIDSupporter
/*    */ {
/*    */   public String returnAppId() {
/* 13 */     if (AppIDPolicy.SPECIFIC_FACET.equals(returnAppIDPolicy()))
/* 14 */       return returnFacetId(); 
/* 15 */     if (AppIDPolicy.TRUSTED_FACETS_URI.equals(returnAppIDPolicy())) {
/* 16 */       return returnTrustedFacetsURI();
/*    */     }
/* 18 */     return null;
/*    */   }
/*    */   
/*    */   protected abstract AppIDPolicy returnAppIDPolicy();
/*    */   
/*    */   protected abstract String returnTrustedFacetsURI();
/*    */   
/*    */   protected abstract String returnFacetId();
/*    */   
/*    */   public abstract String[] trustedFacets();
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\AppIDSupporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */