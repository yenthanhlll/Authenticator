package com.dreammirae.mmth.fido.handler.bean;

import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
import com.dreammirae.mmth.fido.registry.PublicKeyRepresentationFormats;

public interface IFidoRegistrionLocator {
  String getAaid();
  
  String getKeyId();
  
  PublicKeyRepresentationFormats getPublicKeyAlgAndEncoding();
  
  byte[] getPublicKey();
  
  long getLatestSignCounter();
  
  boolean hasTcDisplayInfomation();
  
  DisplayPNGCharacteristicsDescriptor[] getTcDisplayPNGCharacteristics();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\bean\IFidoRegistrionLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */