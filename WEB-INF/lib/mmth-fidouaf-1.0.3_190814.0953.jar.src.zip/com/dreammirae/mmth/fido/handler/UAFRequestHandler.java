/*     */ package com.dreammirae.mmth.fido.handler;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*     */ import com.dreammirae.mmth.fido.handler.bean.IServerDataLocator;
/*     */ import com.dreammirae.mmth.fido.handler.bean.ServerDataCreator;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.PolicySupporter;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageCallback;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageSupporter;
/*     */ import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
/*     */ import com.dreammirae.mmth.fido.metadata.MetadataStatement;
/*     */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*     */ import com.dreammirae.mmth.fido.uaf.Extension;
/*     */ import com.dreammirae.mmth.fido.uaf.MatchCriteria;
/*     */ import com.dreammirae.mmth.fido.uaf.OperationHeader;
/*     */ import com.dreammirae.mmth.fido.uaf.Policy;
/*     */ import com.dreammirae.mmth.fido.uaf.Transaction;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.bean.Tuple;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UAFRequestHandler<T extends IFidoRegistrionLocator>
/*     */ {
/*     */   private static final String RP_CTX_KEY_TRANSACTION = "transaction";
/*     */   protected final ReqMessageSupporter<T> supporter;
/*     */   protected final ReqMessageCallback<T> callback;
/*     */   private RpContext rpCtx;
/*     */   private IServerDataLocator serverDataLocator;
/*     */   private OperationHeader header;
/*     */   private boolean isTranConfirm;
/*     */   private List<Tuple<T, List<byte[]>>> transactionContents;
/*     */   private Transaction[] transaction;
/*     */   
/*     */   protected UAFRequestHandler(ReqMessageSupporter<T> supporter, ReqMessageCallback<T> callback) {
/*  73 */     this.supporter = supporter;
/*  74 */     this.callback = callback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateUafProtocolMessage(String username) throws FidoUafStatusCodeException {
/*  86 */     List<T> registrations = this.supporter.retrunFidoRegistrionLocator(username, getOperation(), this.isTranConfirm, this.rpCtx);
/*     */ 
/*     */     
/*  89 */     if (!Operation.Dereg.equals(getOperation())) {
/*  90 */       this.isTranConfirm = isTransaction();
/*     */       
/*  92 */       if (this.isTranConfirm) {
/*  93 */         this.transactionContents = new ArrayList<>();
/*  94 */         this.transaction = generateTransactions(this.transactionContents, registrations, username);
/*     */       } 
/*     */       
/*  97 */       this.serverDataLocator = this.supporter.returnServerData(getOperation(), username, this.isTranConfirm, this.rpCtx);
/*     */     } 
/*     */     
/* 100 */     this.header = createOperationHeader(username);
/*     */ 
/*     */     
/* 103 */     String uafProtocolMessage = generateMessageImp(registrations, username);
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (Operation.Reg.equals(getOperation())) {
/* 108 */       this.callback.callbackRegRequest(this.serverDataLocator, getContextLocator());
/* 109 */     } else if (Operation.Dereg.equals(getOperation())) {
/* 110 */       this.callback.callbackDeregRequest(registrations, getContextLocator());
/* 111 */     } else if (this.isTranConfirm) {
/* 112 */       this.callback.callbackTcRequest(this.serverDataLocator, this.transactionContents, getContextLocator());
/*     */     } else {
/* 114 */       this.callback.callbackAuthRequest(this.serverDataLocator, registrations, getContextLocator());
/*     */     } 
/*     */ 
/*     */     
/* 118 */     return uafProtocolMessage;
/*     */   }
/*     */   
/*     */   public RpContext getContextLocator() {
/* 122 */     return this.rpCtx;
/*     */   }
/*     */   
/*     */   public void setContextLocator(RpContext contextLoc) {
/* 126 */     this.rpCtx = contextLoc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String generateMessageImp(List<T> paramList, String paramString) throws FidoUafStatusCodeException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Operation getOperation();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IServerDataLocator getServerDataLocator() {
/* 143 */     return this.serverDataLocator;
/*     */   }
/*     */   
/*     */   protected OperationHeader getHeader() {
/* 147 */     return this.header;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Policy getPolicy(List<T> registrations) {
/* 152 */     PolicySupporter ps = this.supporter.returnPolicySupporter(this.rpCtx);
/*     */     
/* 154 */     Policy policy = new Policy();
/*     */     
/* 156 */     if (registrations == null || registrations.isEmpty()) {
/*     */       
/* 158 */       policy.setAccepted(ps.returnAllowed());
/* 159 */       policy.setDisallowed(ps.returnDisallowed());
/*     */     
/*     */     }
/* 162 */     else if (Operation.Reg.equals(getOperation())) {
/* 163 */       policy.setAccepted(ps.returnAllowed());
/* 164 */       policy.setDisallowed(createDisallow(registrations, ps.returnDisallowed()));
/*     */     } else {
/* 166 */       policy.setAccepted(createAllowed(registrations));
/*     */     } 
/*     */ 
/*     */     
/* 170 */     return policy;
/*     */   }
/*     */   
/*     */   protected boolean isTranConfirm() {
/* 174 */     return this.isTranConfirm;
/*     */   }
/*     */   
/*     */   protected Transaction[] getTransactions() {
/* 178 */     return this.transaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isTransaction() {
/* 191 */     if (!Operation.Auth.equals(getOperation())) {
/* 192 */       return false;
/*     */     }
/*     */     
/* 195 */     if (getContextLocator() == null) {
/* 196 */       return false;
/*     */     }
/*     */     
/* 199 */     String tran = (String)getContextLocator().get("transaction", String.class);
/* 200 */     return !StringUtils.isEmpty(tran);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OperationHeader createOperationHeader(String username) throws FidoUafStatusCodeException {
/* 207 */     OperationHeader header = new OperationHeader();
/* 208 */     header.setUpv(this.supporter.returnCurrentVersion());
/* 209 */     header.setOp(getOperation());
/* 210 */     header.setAppID(this.supporter.returnAppIDSupporter(this.rpCtx).returnAppId());
/*     */ 
/*     */     
/* 213 */     if (!Operation.Dereg.equals(getOperation())) {
/* 214 */       header.setServerData(ServerDataCreator.generateServerData(this.serverDataLocator));
/*     */     }
/*     */ 
/*     */     
/* 218 */     Extension[] exts = this.supporter.returnOperationHeaderExtentions(getOperation(), username, getContextLocator());
/* 219 */     if (exts != null) {
/* 220 */       header.setExts(exts);
/*     */     }
/*     */     
/* 223 */     return header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Transaction[] generateTransactions(List<Tuple<T, List<byte[]>>> toBeStored, List<T> registrations, String username) throws FidoUafStatusCodeException {
/* 233 */     String trContents = (String)getContextLocator().get("transaction", String.class);
/*     */     
/* 235 */     byte[] txtData = null;
/*     */ 
/*     */     
/* 238 */     Map<DisplayPNGCharacteristicsDescriptor, Transaction> tranMap = new HashMap<>(registrations.size());
/* 239 */     Map<Long, byte[]> imgByArea = (Map)new HashMap<>(registrations.size());
/*     */     
/* 241 */     List<T> copy = Collections.unmodifiableList(registrations);
/*     */     
/* 243 */     boolean tcNotSupported = false;
/*     */     
/* 245 */     for (IFidoRegistrionLocator iFidoRegistrionLocator : copy) {
/*     */ 
/*     */       
/* 248 */       MetadataStatement metadata = this.supporter.returnMetadataStatement(iFidoRegistrionLocator.getAaid(), this.rpCtx);
/*     */ 
/*     */       
/* 251 */       if (metadata == null || 0 == metadata.getTcDisplay()) {
/* 252 */         registrations.remove(iFidoRegistrionLocator);
/* 253 */         tcNotSupported = true;
/*     */         
/*     */         continue;
/*     */       } 
/* 257 */       List<byte[]> data = (List)new ArrayList<>();
/* 258 */       Tuple<T, List<byte[]>> tuple = new Tuple(iFidoRegistrionLocator, data);
/*     */ 
/*     */       
/* 261 */       if ("text/plain".equals(metadata.getTcDisplayContentType())) {
/*     */         
/* 263 */         if (txtData == null) {
/* 264 */           txtData = this.supporter.returnTextData(username, trContents, this.rpCtx);
/*     */         }
/*     */         
/* 267 */         ((List<byte[]>)tuple.getElement2()).add(txtData);
/*     */       } else {
/*     */         
/* 270 */         DisplayPNGCharacteristicsDescriptor[] desc = metadata.getTcDisplayPNGCharacteristics();
/* 271 */         if (iFidoRegistrionLocator.getTcDisplayPNGCharacteristics() != null)
/*     */         {
/* 273 */           desc = iFidoRegistrionLocator.getTcDisplayPNGCharacteristics();
/*     */         }
/*     */         
/* 276 */         for (DisplayPNGCharacteristicsDescriptor descriptor : desc) {
/* 277 */           byte[] imgData = imgByArea.get(Long.valueOf(descriptor.imageAreaCode()));
/*     */           
/* 279 */           if (imgData == null) {
/* 280 */             imgData = this.supporter.returnImageData(username, descriptor, trContents, this.rpCtx);
/* 281 */             imgByArea.put(Long.valueOf(descriptor.imageAreaCode()), imgData);
/*     */           } 
/*     */ 
/*     */           
/* 285 */           if (!tranMap.containsKey(descriptor)) {
/* 286 */             tranMap.put(descriptor, generateTransacion("image/png", imgData, descriptor));
/*     */           }
/*     */ 
/*     */           
/* 290 */           ((List<byte[]>)tuple.getElement2()).add(imgData);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 296 */       toBeStored.add(tuple);
/*     */     } 
/*     */ 
/*     */     
/* 300 */     if (tcNotSupported && registrations.size() < 1) {
/* 301 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1403, "Transaction confirm request is invalid.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 306 */     List<Transaction> tranList = new ArrayList<>(registrations.size());
/*     */     
/* 308 */     if (txtData != null) {
/* 309 */       Transaction txtTransaction = generateTransacion("text/plain", txtData, null);
/* 310 */       tranList.add(txtTransaction);
/*     */     } 
/*     */     
/* 313 */     if (!tranMap.isEmpty()) {
/* 314 */       tranList.addAll(tranMap.values());
/*     */     }
/*     */     
/* 317 */     return tranList.<Transaction>toArray(new Transaction[tranList.size()]);
/*     */   }
/*     */   
/*     */   private Transaction generateTransacion(String conentType, byte[] contents, DisplayPNGCharacteristicsDescriptor desc) {
/* 321 */     Transaction tran = new Transaction();
/* 322 */     tran.setContentType(conentType);
/* 323 */     tran.setContent(Base64Utils.encodeUrl(contents));
/* 324 */     tran.setTcDisplayPNGCharacteristics(desc);
/* 325 */     return tran;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MatchCriteria[] createDisallow(List<T> registrations, MatchCriteria[] disallowed) {
/* 332 */     if (registrations == null || registrations.isEmpty()) {
/* 333 */       return disallowed;
/*     */     }
/*     */     
/* 336 */     int len = registrations.size();
/* 337 */     MatchCriteria[] disallow = new MatchCriteria[len];
/* 338 */     for (int i = 0; i < len; i++) {
/* 339 */       disallow[i] = new MatchCriteria();
/* 340 */       disallow[i].setAaid(new String[] { ((IFidoRegistrionLocator)registrations.get(i)).getAaid() });
/* 341 */       disallow[i].setKeyIDs(new String[] { ((IFidoRegistrionLocator)registrations.get(i)).getKeyId() });
/*     */     } 
/*     */     
/* 344 */     if (disallowed == null || disallowed.length == 0) {
/* 345 */       return disallow;
/*     */     }
/*     */     
/* 348 */     MatchCriteria[] tot = new MatchCriteria[len + disallowed.length];
/* 349 */     System.arraycopy(disallow, 0, tot, 0, len);
/* 350 */     System.arraycopy(disallowed, 0, tot, len, disallowed.length);
/*     */     
/* 352 */     return tot;
/*     */   }
/*     */   
/*     */   private MatchCriteria[][] createAllowed(List<T> registrations) {
/* 356 */     int len = registrations.size();
/* 357 */     MatchCriteria[][] matchCriteria = new MatchCriteria[len][1];
/*     */     
/* 359 */     for (int i = 0; i < len; i++) {
/* 360 */       matchCriteria[i] = new MatchCriteria[1];
/* 361 */       matchCriteria[i][0] = new MatchCriteria();
/* 362 */       matchCriteria[i][0].setAaid(new String[] { ((IFidoRegistrionLocator)registrations.get(i)).getAaid() });
/* 363 */       matchCriteria[i][0].setKeyIDs(new String[] { ((IFidoRegistrionLocator)registrations.get(i)).getKeyId() });
/*     */     } 
/*     */     
/* 366 */     return matchCriteria;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IFidoRegistrionLocator> UAFRequestHandler<T> createRequestHandler(Operation op, ReqMessageSupporter<T> supporter, ReqMessageCallback<T> callback, RpContext contextLocator) {
/*     */     UAFRequestHandler<T> handler;
/* 377 */     if (Operation.Reg.equals(op)) {
/* 378 */       handler = new RegUAFRequestHandler<>(supporter, callback);
/* 379 */     } else if (Operation.Auth.equals(op)) {
/* 380 */       handler = new AuthUAFRequestHandler<>(supporter, callback);
/*     */     } else {
/* 382 */       handler = new DeregUAFRequestHandler<>(supporter, callback);
/*     */     } 
/*     */     
/* 385 */     handler.setContextLocator(contextLocator);
/*     */     
/* 387 */     return handler;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\UAFRequestHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */