package com.dreammirae.mmth.fido.handler.supporter;

import com.dreammirae.mmth.fido.Operation;
import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
import com.dreammirae.mmth.fido.handler.bean.IServerDataLocator;
import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
import com.dreammirae.mmth.fido.metadata.MetadataStatement;
import com.dreammirae.mmth.fido.transport.context.RpContext;
import com.dreammirae.mmth.fido.uaf.Extension;
import com.dreammirae.mmth.fido.uaf.Version;
import java.util.List;

public interface ReqMessageSupporter<T extends com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator> {
  IServerDataLocator returnServerData(Operation paramOperation, String paramString, boolean paramBoolean, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  List<T> retrunFidoRegistrionLocator(String paramString, Operation paramOperation, boolean paramBoolean, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  Version returnCurrentVersion();
  
  AppIDSupporter returnAppIDSupporter(RpContext paramRpContext);
  
  PolicySupporter returnPolicySupporter(RpContext paramRpContext);
  
  byte[] returnImageData(String paramString1, DisplayPNGCharacteristicsDescriptor paramDisplayPNGCharacteristicsDescriptor, String paramString2, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  byte[] returnTextData(String paramString1, String paramString2, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  MetadataStatement returnMetadataStatement(String paramString, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  Extension[] returnOperationHeaderExtentions(Operation paramOperation, String paramString, RpContext paramRpContext) throws FidoUafStatusCodeException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\ReqMessageSupporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */