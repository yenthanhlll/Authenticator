/*     */ package com.dreammirae.mmth.fido.handler;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.RespMessageCallback;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.RespMessageSupporter;
/*     */ import com.dreammirae.mmth.fido.json.UafSerializeUtils;
/*     */ import com.dreammirae.mmth.fido.metadata.MetadataStatement;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.AuthAssertionLocator;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticationResponse;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorSignAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.IUafProtocolResponseMessage;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.google.gson.JsonParseException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthUAFResponseHandler<T extends IFidoRegistrionLocator>
/*     */   extends UAFResponseHandler<AuthenticationResponse, T>
/*     */ {
/*  34 */   private static final Logger LOG = LoggerFactory.getLogger(AuthUAFResponseHandler.class);
/*     */   private static final int NOT_SUPPORTED_SIGN_COUNTER = 0;
/*     */   
/*     */   protected AuthUAFResponseHandler(RespMessageSupporter<T> supporter, RespMessageCallback<T> callback) {
/*  38 */     super(supporter, callback);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AuthenticationResponse[] parseMesssageImp(String uafProtocolMessage) throws FidoUafStatusCodeException {
/*     */     try {
/*  45 */       AuthenticationResponse[] respArr = (AuthenticationResponse[])UafSerializeUtils.gson().fromJson(uafProtocolMessage, AuthenticationResponse[].class);
/*     */       
/*  47 */       if (respArr == null) {
/*  48 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "uafResponse(AuthenticationResponse[]) must not be null/empty/missing.");
/*     */       }
/*     */       
/*  51 */       return respArr;
/*  52 */     } catch (IllegalUafJsonException e) {
/*  53 */       throw new FidoUafStatusCodeException(e.getStatusCode(), e);
/*  54 */     } catch (JsonParseException e) {
/*  55 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateAssertionImp(AuthenticationResponse uafResponse) throws FidoUafStatusCodeException {
/*  62 */     AuthenticatorSignAssertion[] arrayOfAuthenticatorSignAssertion = uafResponse.getAssertions(); int i = arrayOfAuthenticatorSignAssertion.length; byte b = 0; if (b < i) { AuthenticatorSignAssertion assertion = arrayOfAuthenticatorSignAssertion[b];
/*  63 */       AuthAssertionLocator loc = assertion.getAssertionLocator();
/*     */ 
/*     */       
/*  66 */       MetadataStatement metadata = getMetadata(loc.getAAID());
/*     */ 
/*     */       
/*  69 */       validateAssertionScheme(metadata, assertion.getAssertionScheme());
/*     */ 
/*     */ 
/*     */       
/*  73 */       T info = getRegistration(loc.getAAID(), loc.getKeyId());
/*     */       
/*  75 */       validateAssertion(info, metadata, assertion.getAssertionLocator(), uafResponse.getFcParams());
/*     */       
/*  77 */       LOG.info(StringUtils.concat(new Object[] { "### Ready to authentication. Success to validate assertion for AAID=", loc.getAAID(), ", KeyId=", loc.getKeyId() }));
/*     */       
/*  79 */       callbackAuthentication(assertion, info); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Operation getOpreation() {
/*  88 */     return Operation.Auth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateAssertion(T info, MetadataStatement metadata, AuthAssertionLocator loc, String fcp) throws FidoUafStatusCodeException {
/* 104 */     if (loc.getAuthenticatorVersion() < metadata.getAuthenticatorVersion())
/*     */     {
/* 106 */       LOG.warn(StringUtils.concat(new Object[] { "@@@ Metadata(AAID).AuthenticatorVersion less than or equal to(<=) a.assertion.authenticatorVersion. AAID = ", loc
/* 107 */               .getAAID(), ", assertion.authenticatorVersion=", HexUtils.toHexString(loc.getAuthenticatorVersion()) }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (loc.getSignCounter() != 0L)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 119 */       if (info.getLatestSignCounter() >= loc.getSignCounter()) {
/* 120 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Assertion[signCounter] must be increament before.");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     validateFcpHash(loc.getFcParamHash(), loc.getAuthenticationAlgorithms(), fcp);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     validateAuthenticationMode(loc.getAuthenticationMode(), metadata);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     boolean verifySign = validateSignature(loc.getAuthenticationAlgorithms(), info.getPublicKeyAlgAndEncoding(), loc.getAssertionData(), loc.getSignature(), info.getPublicKey());
/*     */     
/* 139 */     if (!verifySign)
/* 140 */       throw new IllegalUafFieldException(StatusCodes.CODE_1498, "Assertion[signature] is not verifed."); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\AuthUAFResponseHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */