package com.dreammirae.mmth.fido.handler.supporter;

import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
import com.dreammirae.mmth.fido.handler.bean.IServerDataLocator;
import com.dreammirae.mmth.fido.transport.context.RpContext;
import com.dreammirae.mmth.util.bean.Tuple;
import java.util.List;

public interface ReqMessageCallback<T extends com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator> {
  void callbackRegRequest(IServerDataLocator paramIServerDataLocator, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  void callbackAuthRequest(IServerDataLocator paramIServerDataLocator, List<T> paramList, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  void callbackTcRequest(IServerDataLocator paramIServerDataLocator, List<Tuple<T, List<byte[]>>> paramList, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  void callbackDeregRequest(List<T> paramList, RpContext paramRpContext) throws FidoUafStatusCodeException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\ReqMessageCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */