/*     */ package com.dreammirae.mmth.fido.handler;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*     */ import com.dreammirae.mmth.fido.handler.bean.IServerDataLocator;
/*     */ import com.dreammirae.mmth.fido.handler.bean.ServerDataCreator;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.AppIDSupporter;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.RespMessageCallback;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.RespMessageSupporter;
/*     */ import com.dreammirae.mmth.fido.metadata.MetadataStatement;
/*     */ import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
/*     */ import com.dreammirae.mmth.fido.registry.PublicKeyRepresentationFormats;
/*     */ import com.dreammirae.mmth.fido.tlv.AuthenticationMode;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.AuthAssertionLocator;
/*     */ import com.dreammirae.mmth.fido.transport.UAFMessage;
/*     */ import com.dreammirae.mmth.fido.transport.context.RpContext;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorRegistrationAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorSignAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.ChannelBinding;
/*     */ import com.dreammirae.mmth.fido.uaf.Extension;
/*     */ import com.dreammirae.mmth.fido.uaf.FinalChallengeParams;
/*     */ import com.dreammirae.mmth.fido.uaf.IUafProtocolResponseMessage;
/*     */ import com.dreammirae.mmth.fido.uaf.OperationHeader;
/*     */ import com.dreammirae.mmth.fido.uaf.Version;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Arrays;
/*     */ import org.bouncycastle.crypto.CryptoException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UAFResponseHandler<V extends IUafProtocolResponseMessage, T extends IFidoRegistrionLocator>
/*     */ {
/*     */   protected final RespMessageSupporter<T> supporter;
/*     */   protected final RespMessageCallback<T> callback;
/*     */   private RpContext rpContext;
/*     */   private IServerDataLocator serverDataLoc;
/*     */   private Extension[] exts;
/*     */   
/*     */   protected UAFResponseHandler(RespMessageSupporter<T> supporter, RespMessageCallback<T> callback) {
/*  72 */     this.supporter = supporter;
/*  73 */     this.callback = callback;
/*     */   }
/*     */   
/*     */   public void parseUafProtocolMessage(UAFMessage uafMessage) throws FidoUafStatusCodeException {
/*  77 */     String uafProtocolMessage = uafMessage.getUafProtocolMessage();
/*     */ 
/*     */     
/*  80 */     if (StringUtils.isEmpty(uafProtocolMessage)) {
/*  81 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498);
/*     */     }
/*     */     
/*  84 */     V[] uafResponses = parseMesssageImp(uafProtocolMessage);
/*     */ 
/*     */     
/*  87 */     checkProtocol(uafResponses);
/*     */ 
/*     */     
/*  90 */     for (V uafResponse : uafResponses) {
/*     */       
/*  92 */       validateOperationHeader(uafResponse.getHeader());
/*     */       
/*  94 */       validateFinalChallengeParams(uafResponse.getFcParamsDeserialized());
/*     */       
/*  96 */       validateAssertionImp(uafResponse);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public RpContext getContextLocator() {
/* 102 */     return this.rpContext;
/*     */   }
/*     */   
/*     */   public void setContextLocator(RpContext contextLoc) {
/* 106 */     this.rpContext = contextLoc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract V[] parseMesssageImp(String paramString) throws FidoUafStatusCodeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void validateAssertionImp(V paramV) throws FidoUafStatusCodeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Operation getOpreation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void callbackRegistration(AuthenticatorRegistrationAssertion assertion, MetadataStatement metadata) throws FidoUafStatusCodeException {
/* 133 */     this.callback.callbackRegistration(this.serverDataLoc, assertion.getAssertionLocator(), assertion
/* 134 */         .getTcDisplayPNGCharacteristics(), this.exts, metadata, getContextLocator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void callbackAuthentication(AuthenticatorSignAssertion assertion, T info) throws FidoUafStatusCodeException {
/* 139 */     AuthAssertionLocator loc = assertion.getAssertionLocator();
/* 140 */     if (AuthenticationMode.TRANSACTION_CONFIRMATION.equals(loc.getAuthenticationMode())) {
/* 141 */       this.callback.callbackTransactionConfirm(this.serverDataLoc, loc, (IFidoRegistrionLocator)info, loc.getSignCounter(), loc
/* 142 */           .getTransactionContentHash(), this.exts, getContextLocator());
/*     */     } else {
/* 144 */       this.callback.callbackAuthentication(this.serverDataLoc, loc, (IFidoRegistrionLocator)info, loc.getSignCounter(), this.exts, getContextLocator());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IServerDataLocator getServerDataLoc() {
/* 153 */     return this.serverDataLoc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MetadataStatement getMetadata(String aaid) throws FidoUafStatusCodeException {
/* 160 */     MetadataStatement metadata = this.supporter.returnPolicySupporter().returnMetadataStatement(aaid);
/*     */     
/* 162 */     if (metadata == null) {
/* 163 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1480, StringUtils.concat(new Object[] { "There has no metadata information by aaid=", aaid }));
/*     */     }
/* 165 */     return metadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateAssertionScheme(MetadataStatement metadata, String assertonScheme) throws FidoUafStatusCodeException {
/* 172 */     if (!metadata.getAssertionScheme().equals(assertonScheme)) {
/* 173 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1480, StringUtils.concat(new Object[] { "AssertionScheme does not matches the metadata(AAID).assertionScheme. aaid=", metadata.getAaid() }));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateFcpHash(byte[] fcpHashed, AuthenticationAlgorithms alg, String fcParams) throws FidoUafStatusCodeException {
/* 178 */     byte[] hashing = AuthenticationAlgorithms.hashingWithAlg(alg, fcParams);
/*     */     
/* 180 */     if (!Arrays.equals(fcpHashed, hashing)) {
/* 181 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "[FCHash] must be equal to TAG_FINAL_CHALLENGE.value");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateRegCounter(long regCounter, String aaid) throws FidoUafStatusCodeException {
/* 193 */     long limit = this.supporter.returnLimitRegCounter(aaid);
/* 194 */     if (regCounter > limit) {
/* 195 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, StringUtils.concat(new Object[] { "Assertion[regCounter] is exceedingly high. limit=", Long.valueOf(limit) }));
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean validateSignature(AuthenticationAlgorithms alg, byte[] signedData, byte[] signature, X509Certificate cert) throws FidoUafStatusCodeException {
/*     */     try {
/* 201 */       return alg.verify_signature(signedData, signature, cert);
/* 202 */     } catch (CryptoException e) {
/* 203 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Failed to verify signature");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean validateSignature(AuthenticationAlgorithms alg, PublicKeyRepresentationFormats pkFormat, byte[] signedData, byte[] signature, byte[] publicKey) throws FidoUafStatusCodeException {
/*     */     try {
/* 209 */       PublicKey pubKey = pkFormat.getPublicKeyFromBytes(alg, publicKey);
/* 210 */       return alg.verify_signature(signedData, signature, pubKey);
/* 211 */     } catch (CryptoException e) {
/* 212 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Failed to verify signature");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateAuthenticationMode(AuthenticationMode mode, MetadataStatement metadata) throws FidoUafStatusCodeException {
/* 220 */     if (this.serverDataLoc.isTransaction()) {
/*     */       
/* 222 */       if (0 == metadata.getTcDisplay()) {
/* 223 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1403, "The authenticator for signed by user does not support transaction confirmation. (Use another registered one.)");
/*     */       }
/*     */       
/* 226 */       if (!AuthenticationMode.TRANSACTION_CONFIRMATION.equals(mode)) {
/* 227 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "The AuthenticationMode is expected to be TRANSACTION_CONFIRMATION.");
/*     */       
/*     */       }
/*     */     }
/* 231 */     else if (!AuthenticationMode.VERIFIED.equals(mode)) {
/* 232 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "The AuthenticationMode is expected to be VERIFIED.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T getRegistration(String aaid, String keyId) throws FidoUafStatusCodeException {
/* 246 */     IFidoRegistrionLocator iFidoRegistrionLocator = this.supporter.returnRegistrationInfo(aaid, keyId);
/*     */     
/* 248 */     if (iFidoRegistrionLocator == null) {
/* 249 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1481, StringUtils.concat(new Object[] { "There has no registarion for KeyId=", keyId, ", AAID=", aaid }));
/*     */     }
/*     */     
/* 252 */     return (T)iFidoRegistrionLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkProtocol(V[] uafResponses) throws FidoUafStatusCodeException {
/* 263 */     if (uafResponses.length != 1) {
/* 264 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "uafResponse must be contain only one dictionary.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateOperationHeader(OperationHeader header) throws FidoUafStatusCodeException {
/* 277 */     if (!getOpreation().equals(header.getOp())) {
/* 278 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, StringUtils.concat(new Object[] { "Header[op] must be ", getOpreation().name() }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 286 */     Version[] supportedVer = this.supporter.returnSupportedVersions();
/* 287 */     boolean checked = false;
/* 288 */     for (Version version : supportedVer) {
/* 289 */       if (version.equals(header.getUpv())) {
/* 290 */         checked = !checked;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 295 */     if (!checked) {
/* 296 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, StringUtils.concat(new Object[] { "Header[upv] is not supported protocol version. upv=", header.getUpv() }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     String appId = this.supporter.returnAppIDSupporter().returnAppId();
/*     */     
/* 306 */     if (!StringUtils.isEmpty(appId) && 
/* 307 */       !header.getAppID().equals(appId)) {
/* 308 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "Header[appId] must be the same as that of the server.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     this.serverDataLoc = ServerDataCreator.parseServerData(header.getServerData());
/* 317 */     this.exts = header.getExts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateFinalChallengeParams(FinalChallengeParams fcp) throws FidoUafStatusCodeException {
/* 330 */     AppIDSupporter appIdsup = this.supporter.returnAppIDSupporter();
/* 331 */     if (StringUtils.isEmpty(appIdsup.returnAppId())) {
/*     */ 
/*     */       
/* 334 */       if (!fcp.getFacetID().equalsIgnoreCase(fcp.getAppID())) {
/* 335 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1489, "FinalChallengeParams[appID] : If Request.header[appID] is missing or empty the appID=FacetID");
/*     */       }
/*     */     }
/* 338 */     else if (!fcp.getAppID().equals(appIdsup.returnAppId())) {
/* 339 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1489, "FinalChallengeParams[appID] must be equal the one stored by the FIDO Server.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     String[] facetIds = appIdsup.trustedFacets();
/* 347 */     boolean checked = false;
/* 348 */     for (String id : facetIds) {
/* 349 */       if (id.equals(fcp.getFacetID())) {
/* 350 */         checked = !checked;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 355 */     if (!checked) {
/* 356 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1489, StringUtils.concat(new Object[] { fcp.getFacetID(), " is not trusted facet." }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     if (!fcp.getChallenge().equals(this.serverDataLoc.getChallenge())) {
/* 363 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "ServerChallenge is invaild.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 375 */     if (this.supporter.returnCheckChannelBindingPolicy()) {
/*     */       
/* 377 */       ChannelBinding[] storedCBs = this.supporter.returnChannelBinding();
/* 378 */       checked = false;
/* 379 */       for (ChannelBinding binding : storedCBs) {
/* 380 */         if (binding.equals(fcp.getChannelBinding())) {
/* 381 */           checked = !checked;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 386 */       if (!checked) {
/* 387 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1490, "Channel Binding is invalid.");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IFidoRegistrionLocator> UAFResponseHandler<?, T> createUAFResponseHandler(Operation op, RespMessageSupporter<T> supporter, RespMessageCallback<T> callback, RpContext context) {
/*     */     UAFResponseHandler<?, T> handler;
/* 398 */     if (Operation.Reg.equals(op)) {
/* 399 */       handler = new RegUAFResponseHandler<>(supporter, callback);
/*     */     } else {
/* 401 */       handler = new AuthUAFResponseHandler<>(supporter, callback);
/*     */     } 
/*     */     
/* 404 */     if (context != null) {
/* 405 */       handler.setContextLocator(context);
/*     */     }
/*     */     
/* 408 */     return handler;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\UAFResponseHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */