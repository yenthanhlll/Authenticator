package com.dreammirae.mmth.fido.handler.supporter;

import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
import com.dreammirae.mmth.fido.handler.bean.IServerDataLocator;
import com.dreammirae.mmth.fido.metadata.DisplayPNGCharacteristicsDescriptor;
import com.dreammirae.mmth.fido.metadata.MetadataStatement;
import com.dreammirae.mmth.fido.tlv.loc.AuthAssertionLocator;
import com.dreammirae.mmth.fido.tlv.loc.RegAssertionLocator;
import com.dreammirae.mmth.fido.transport.context.RpContext;
import com.dreammirae.mmth.fido.uaf.Extension;

public interface RespMessageCallback<T extends com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator> {
  void callbackRegistration(IServerDataLocator paramIServerDataLocator, RegAssertionLocator paramRegAssertionLocator, DisplayPNGCharacteristicsDescriptor[] paramArrayOfDisplayPNGCharacteristicsDescriptor, Extension[] paramArrayOfExtension, MetadataStatement paramMetadataStatement, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  void callbackAuthentication(IServerDataLocator paramIServerDataLocator, AuthAssertionLocator paramAuthAssertionLocator, T paramT, long paramLong, Extension[] paramArrayOfExtension, RpContext paramRpContext) throws FidoUafStatusCodeException;
  
  void callbackTransactionConfirm(IServerDataLocator paramIServerDataLocator, AuthAssertionLocator paramAuthAssertionLocator, T paramT, long paramLong, byte[] paramArrayOfbyte, Extension[] paramArrayOfExtension, RpContext paramRpContext) throws FidoUafStatusCodeException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\RespMessageCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */