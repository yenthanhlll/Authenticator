/*    */ package com.dreammirae.mmth.fido.handler.supporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AppIDPolicy
/*    */ {
/* 11 */   EMPTY, SPECIFIC_FACET, TRUSTED_FACETS_URI;
/*    */   
/*    */   public static AppIDPolicy valueByName(String value) {
/* 14 */     AppIDPolicy[] arrayOfAppIDPolicy = values(); int i = arrayOfAppIDPolicy.length; byte b = 0; if (b < i) { AppIDPolicy policy = arrayOfAppIDPolicy[b];
/* 15 */       return policy; }
/*    */ 
/*    */     
/* 18 */     return EMPTY;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\AppIDPolicy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */