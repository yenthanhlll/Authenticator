/*     */ package com.dreammirae.mmth.fido.handler.bean;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleServerDataLocator
/*     */   implements IServerDataLocator
/*     */ {
/*     */   private Operation op;
/*     */   private String username;
/*     */   private String challenge;
/*     */   private long lifeTimeTs;
/*     */   private boolean isTransaction;
/*     */   private String serverData;
/*     */   
/*     */   public SimpleServerDataLocator() {}
/*     */   
/*     */   public SimpleServerDataLocator(Operation op, String username, String challenge, long lifeTimeTs, boolean isTransaction) {
/*  29 */     this.op = op;
/*  30 */     this.username = username;
/*  31 */     this.challenge = challenge;
/*  32 */     this.lifeTimeTs = lifeTimeTs;
/*  33 */     this.isTransaction = isTransaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public Operation getOp() {
/*  38 */     return this.op;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOp(Operation op) {
/*  43 */     this.op = op;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/*  48 */     return this.username;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUsername(String username) {
/*  53 */     this.username = username;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getChallenge() {
/*  58 */     return this.challenge;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChallenge(String challenge) {
/*  63 */     this.challenge = challenge;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLifeTimeTs() {
/*  68 */     return this.lifeTimeTs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLifeTimeTs(long lifeTimeTs) {
/*  73 */     this.lifeTimeTs = lifeTimeTs;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransaction() {
/*  78 */     return this.isTransaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransaction(boolean isTransaction) {
/*  83 */     this.isTransaction = isTransaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerData(String serverData) {
/*  88 */     this.serverData = serverData;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerData() {
/*  93 */     return this.serverData;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuilder builder = new StringBuilder(511);
/*  99 */     builder.append("SimpleServerData [op=").append(this.op).append(", username=").append(this.username).append(", challenge=")
/* 100 */       .append(this.challenge).append(", lifeTimeTs=").append(this.lifeTimeTs).append(", isTransaction=")
/* 101 */       .append(this.isTransaction).append("]");
/* 102 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\bean\SimpleServerDataLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */