package com.dreammirae.mmth.fido.handler.bean;

import com.dreammirae.mmth.fido.Operation;

public interface IServerDataLocator {
  Operation getOp();
  
  void setOp(Operation paramOperation);
  
  String getUsername();
  
  void setUsername(String paramString);
  
  String getChallenge();
  
  void setChallenge(String paramString);
  
  long getLifeTimeTs();
  
  void setLifeTimeTs(long paramLong);
  
  boolean isTransaction();
  
  void setTransaction(boolean paramBoolean);
  
  void setServerData(String paramString);
  
  String getServerData();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\bean\IServerDataLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */