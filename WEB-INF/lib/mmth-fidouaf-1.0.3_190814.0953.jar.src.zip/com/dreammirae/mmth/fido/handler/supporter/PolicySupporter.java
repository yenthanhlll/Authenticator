package com.dreammirae.mmth.fido.handler.supporter;

import com.dreammirae.mmth.fido.metadata.MetadataStatement;
import com.dreammirae.mmth.fido.uaf.MatchCriteria;

public interface PolicySupporter {
  MatchCriteria[][] returnAllowed();
  
  MatchCriteria[] returnDisallowed();
  
  MetadataStatement returnMetadataStatement(String paramString);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\PolicySupporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */