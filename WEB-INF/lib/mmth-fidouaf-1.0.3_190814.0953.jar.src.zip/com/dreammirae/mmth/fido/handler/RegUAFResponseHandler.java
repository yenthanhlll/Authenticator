/*     */ package com.dreammirae.mmth.fido.handler;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafFieldException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalUafJsonException;
/*     */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.RespMessageCallback;
/*     */ import com.dreammirae.mmth.fido.handler.supporter.RespMessageSupporter;
/*     */ import com.dreammirae.mmth.fido.json.UafSerializeUtils;
/*     */ import com.dreammirae.mmth.fido.metadata.MetadataStatement;
/*     */ import com.dreammirae.mmth.fido.registry.AuthenticationAlgorithms;
/*     */ import com.dreammirae.mmth.fido.tlv.loc.RegAssertionLocator;
/*     */ import com.dreammirae.mmth.fido.uaf.AuthenticatorRegistrationAssertion;
/*     */ import com.dreammirae.mmth.fido.uaf.IUafProtocolResponseMessage;
/*     */ import com.dreammirae.mmth.fido.uaf.RegistrationResponse;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.cert.CertificateVerificationException;
/*     */ import com.dreammirae.mmth.util.cert.CertificateVerifier;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.notary.X509Utils;
/*     */ import com.google.gson.JsonParseException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.PKIXCertPathBuilderResult;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegUAFResponseHandler<T extends IFidoRegistrionLocator>
/*     */   extends UAFResponseHandler<RegistrationResponse, T>
/*     */ {
/*  48 */   private static final Logger LOG = LoggerFactory.getLogger(RegUAFResponseHandler.class);
/*     */   
/*     */   protected RegUAFResponseHandler(RespMessageSupporter<T> supporter, RespMessageCallback<T> callback) {
/*  51 */     super(supporter, callback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RegistrationResponse[] parseMesssageImp(String uafProtocolMessage) throws FidoUafStatusCodeException {
/*     */     try {
/*  59 */       RegistrationResponse[] respArr = (RegistrationResponse[])UafSerializeUtils.gson().fromJson(uafProtocolMessage, RegistrationResponse[].class);
/*     */       
/*  61 */       if (respArr == null) {
/*  62 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, "uafResponse(RegistrationResponse[]) must not be null/empty/missing.");
/*     */       }
/*     */       
/*  65 */       return respArr;
/*  66 */     } catch (IllegalUafJsonException e) {
/*  67 */       throw new FidoUafStatusCodeException(e.getStatusCode(), e.getMessage());
/*  68 */     } catch (JsonParseException e) {
/*  69 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, StringUtils.concat(new Object[] { "Failed to parse message : uafResponse=", uafProtocolMessage }));
/*  70 */     } catch (Exception e) {
/*  71 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498, StringUtils.concat(new Object[] { "Failed to parse message : uafResponse=", uafProtocolMessage }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateAssertionImp(RegistrationResponse uafResponse) throws FidoUafStatusCodeException {
/*  78 */     AuthenticatorRegistrationAssertion[] arrayOfAuthenticatorRegistrationAssertion = uafResponse.getAssertions(); int i = arrayOfAuthenticatorRegistrationAssertion.length; byte b = 0; if (b < i) { AuthenticatorRegistrationAssertion assertion = arrayOfAuthenticatorRegistrationAssertion[b];
/*  79 */       RegAssertionLocator loc = assertion.getAssertionLocator();
/*     */ 
/*     */       
/*  82 */       MetadataStatement metadata = getMetadata(loc.getAAID());
/*     */ 
/*     */       
/*  85 */       validateAssertionScheme(metadata, assertion.getAssertionScheme());
/*     */       
/*  87 */       validateAssertion(metadata, loc, uafResponse.getFcParams());
/*     */       
/*  89 */       LOG.info(StringUtils.concat(new Object[] { "### Ready to registration. Success to validate assertion for AAID=", loc.getAAID(), ", KeyId=", loc.getKeyId() }));
/*     */       
/*  91 */       callbackRegistration(assertion, metadata); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Operation getOpreation() {
/*  99 */     return Operation.Reg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateAssertion(MetadataStatement metadata, RegAssertionLocator loc, String fcp) throws FidoUafStatusCodeException {
/*     */     boolean verifySign;
/* 116 */     if (!metadata.isValidAttestaionType(loc.getAttestationType()))
/*     */     {
/* 118 */       LOG.warn(StringUtils.concat(new Object[] { "@@@ Doesn't contain the preferred attestation. AAID = ", loc
/* 119 */               .getAAID(), ", assertion.AttestationType=", HexUtils.toHexString(loc.getAttestationType()), "... Please check the metadata for AAID=", loc
/* 120 */               .getAAID() }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     validateFcpHash(loc.getFcParamHash(), loc.getAuthenticationAlgorithms(), fcp);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (loc.getAuthenticatorVersion() < metadata.getAuthenticatorVersion())
/*     */     {
/* 133 */       LOG.warn(StringUtils.concat(new Object[] { "@@@ Metadata(AAID).AuthenticatorVersion less than or equal to(<=) a.assertion.authenticatorVersion. AAID = ", loc
/*     */               
/* 135 */               .getAAID(), ", assertion.authenticatorVersion=", 
/* 136 */               HexUtils.toHexString(loc.getAuthenticatorVersion()) }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     validateRegCounter(loc.getRegCounter(), loc.getAAID());
/* 145 */     AuthenticationAlgorithms alg = loc.getAuthenticationAlgorithms();
/*     */ 
/*     */     
/* 148 */     if (loc.isAttestationBasicFull()) {
/*     */       
/* 150 */       String[] rootCerts = metadata.getAttestationRootCertificates();
/*     */       
/* 152 */       if (rootCerts == null || rootCerts.length < 1) {
/* 153 */         throw new FidoUafStatusCodeException(StatusCodes.CODE_1496, StringUtils.concat(new Object[] { "There has no AttestationRootCertificates for Metadata[AAID]. AAID=", loc
/* 154 */                 .getAAID() }));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 160 */       List<byte[]> certs = loc.getAttestationCert();
/* 161 */       X509Certificate endPointCert = parseCertificate(certs.get(0));
/*     */ 
/*     */       
/* 164 */       validateCertificatePath(rootCerts, certs, endPointCert);
/*     */ 
/*     */       
/* 167 */       validateCertExpired(endPointCert);
/*     */ 
/*     */       
/* 170 */       verifySign = validateSignature(alg, loc.getAssertionData(), loc.getSignature(), endPointCert);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 177 */       verifySign = validateSignature(alg, loc.getPublicKeyAlgAndEncoding(), loc.getAssertionData(), loc
/* 178 */           .getSignature(), loc.getPublicKey());
/*     */     } 
/*     */     
/* 181 */     if (!verifySign) {
/* 182 */       throw new IllegalUafFieldException(StatusCodes.CODE_1498, "Assertion[signature] is not verifed.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateCertificatePath(String[] rootCerts, List<byte[]> certs, X509Certificate endPointCert) throws FidoUafStatusCodeException {
/* 192 */     Set<X509Certificate> chains = new HashSet<>();
/*     */ 
/*     */     
/*     */     try {
/* 196 */       for (byte[] bc : certs) {
/* 197 */         chains.add(parseCertificate(bc));
/*     */       }
/*     */ 
/*     */       
/* 201 */       for (String rootCert : rootCerts) {
/* 202 */         byte[] rootCertBytes = Base64Utils.decodeRaw(rootCert);
/* 203 */         chains.add(parseCertificate(rootCertBytes));
/*     */         
/* 205 */         PKIXCertPathBuilderResult result = CertificateVerifier.verifyCertificate(endPointCert, chains);
/* 206 */         if (LOG.isDebugEnabled()) {
/* 207 */           LOG.debug(result.toString());
/*     */         }
/*     */       }
/*     */     
/* 211 */     } catch (CertificateVerificationException e) {
/* 212 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1496, "Failed to certificate path validation.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateCertExpired(X509Certificate cert) {
/*     */     try {
/* 222 */       cert.checkValidity();
/* 223 */     } catch (CertificateExpiredException|java.security.cert.CertificateNotYetValidException e) {
/* 224 */       LOG.warn(StringUtils.concat(new Object[] { "@@@ certificate is expired. certificate=", cert.toString() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private X509Certificate parseCertificate(byte[] cert) throws FidoUafStatusCodeException {
/*     */     try {
/* 234 */       return X509Utils.parseDer(cert);
/* 235 */     } catch (CertificateException e) {
/* 236 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1496, "Failed to parse certificate.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\RegUAFResponseHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */