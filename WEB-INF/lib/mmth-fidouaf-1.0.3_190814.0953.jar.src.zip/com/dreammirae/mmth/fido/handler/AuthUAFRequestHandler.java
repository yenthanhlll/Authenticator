/*    */ package com.dreammirae.mmth.fido.handler;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.Operation;
/*    */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*    */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*    */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageCallback;
/*    */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageSupporter;
/*    */ import com.dreammirae.mmth.fido.json.UafSerializeUtils;
/*    */ import com.dreammirae.mmth.fido.uaf.AuthenticationRequest;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthUAFRequestHandler<T extends IFidoRegistrionLocator>
/*    */   extends UAFRequestHandler<T>
/*    */ {
/*    */   protected AuthUAFRequestHandler(ReqMessageSupporter<T> supporter, ReqMessageCallback<T> callback) {
/* 25 */     super(supporter, callback);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String generateMessageImp(List<T> registrations, String username) throws FidoUafStatusCodeException {
/* 32 */     AuthenticationRequest[] authReqs = new AuthenticationRequest[1];
/* 33 */     AuthenticationRequest authReq = new AuthenticationRequest();
/* 34 */     authReq.setHeader(getHeader());
/* 35 */     authReq.setChallenge(getServerDataLocator().getChallenge());
/* 36 */     authReq.setPolicy(getPolicy(registrations));
/*    */     
/* 38 */     if (isTranConfirm())
/*    */     {
/* 40 */       authReq.setTransaction(getTransactions());
/*    */     }
/* 42 */     authReqs[0] = authReq;
/*    */     
/* 44 */     return UafSerializeUtils.gson().toJson(authReqs);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Operation getOperation() {
/* 49 */     return Operation.Auth;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\AuthUAFRequestHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */