package com.dreammirae.mmth.fido.handler.supporter;

import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
import com.dreammirae.mmth.fido.uaf.ChannelBinding;
import com.dreammirae.mmth.fido.uaf.Version;

public interface RespMessageSupporter<T extends com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator> {
  Version[] returnSupportedVersions();
  
  AppIDSupporter returnAppIDSupporter();
  
  PolicySupporter returnPolicySupporter();
  
  boolean returnCheckChannelBindingPolicy();
  
  ChannelBinding[] returnChannelBinding() throws FidoUafStatusCodeException;
  
  long returnLimitRegCounter(String paramString);
  
  T returnRegistrationInfo(String paramString1, String paramString2) throws FidoUafStatusCodeException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\supporter\RespMessageSupporter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */