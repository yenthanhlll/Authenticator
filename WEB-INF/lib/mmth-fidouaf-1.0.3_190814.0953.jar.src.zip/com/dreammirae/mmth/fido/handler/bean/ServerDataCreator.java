/*     */ package com.dreammirae.mmth.fido.handler.bean;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.Operation;
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.fido.handler.notary.SimpleNotary;
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerDataCreator
/*     */ {
/*     */   private static final String SERVER_DATA_DELIMITER = ".";
/*     */   private static final String SERVER_DATA_DELIMITER_SPLIT = "\\.";
/*     */   
/*     */   public static String generateServerData(IServerDataLocator serverData) throws FidoUafStatusCodeException {
/*  33 */     if (serverData.getOp() == null) {
/*  34 */       throw new IllegalArgumentException("op must be included.");
/*     */     }
/*     */     
/*  37 */     if (StringUtils.isEmpty(serverData.getChallenge())) {
/*  38 */       throw new IllegalArgumentException("challenge must be included.");
/*     */     }
/*     */     
/*  41 */     if (StringUtils.isEmpty(serverData.getUsername())) {
/*  42 */       throw new IllegalArgumentException("Username must be included.");
/*     */     }
/*  44 */     StringBuilder sb = new StringBuilder(1536);
/*  45 */     sb.append(Base64Utils.encodeUrl(serverData.getOp().name())).append(".")
/*  46 */       .append(Base64Utils.encodeUrl(serverData.getUsername())).append(".")
/*  47 */       .append(serverData.getChallenge()).append(".")
/*  48 */       .append(Base64Utils.encodeUrl(Long.toString(serverData.getLifeTimeTs())))
/*  49 */       .append(".")
/*  50 */       .append(Base64Utils.encodeUrl(Boolean.toString(serverData.isTransaction())));
/*     */     
/*  52 */     String data = Base64Utils.encodeUrl(sb.toString());
/*     */     
/*  54 */     String signature = SimpleNotary.getInstance().sign(data);
/*     */     
/*  56 */     sb.setLength(0);
/*     */     
/*  58 */     sb.append(data).append(".").append(signature);
/*     */     
/*  60 */     String sendServerData = Base64Utils.encodeUrl(sb.toString());
/*     */     
/*  62 */     serverData.setServerData(sendServerData);
/*     */     
/*  64 */     return sendServerData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IServerDataLocator parseServerData(String receivedServerData) throws FidoUafStatusCodeException {
/*  75 */     String serverData = Base64Utils.decode(receivedServerData);
/*  76 */     String[] sdToken = serverData.split("\\.");
/*     */     
/*  78 */     if (sdToken.length != 2) {
/*  79 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1491, "Header[serverData] is invalid.");
/*     */     }
/*     */     
/*  82 */     boolean verify = SimpleNotary.getInstance().verify(sdToken[0], sdToken[1]);
/*     */     
/*  84 */     if (!verify) {
/*  85 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1491, "Header[serverData] is invalid.");
/*     */     }
/*     */     
/*  88 */     String[] dataToken = Base64Utils.decode(sdToken[0]).split("\\.");
/*     */     
/*  90 */     if (dataToken.length != 5) {
/*  91 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1491, "Header[serverData] is invalid.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  96 */       IServerDataLocator serverDataLoc = new SimpleServerDataLocator();
/*     */       
/*  98 */       serverDataLoc.setOp(Operation.getOperation(Base64Utils.decode(dataToken[0])));
/*  99 */       serverDataLoc.setUsername(Base64Utils.decode(dataToken[1]));
/* 100 */       serverDataLoc.setChallenge(dataToken[2]);
/* 101 */       serverDataLoc.setLifeTimeTs(Long.parseLong(Base64Utils.decode(dataToken[3])));
/* 102 */       serverDataLoc.setTransaction(Boolean.parseBoolean(Base64Utils.decode(dataToken[4])));
/* 103 */       serverDataLoc.setServerData(receivedServerData);
/*     */       
/* 105 */       return serverDataLoc;
/* 106 */     } catch (Exception e) {
/* 107 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1491, "Header[serverData] is invalid.", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\bean\ServerDataCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */