/*    */ package com.dreammirae.mmth.fido.handler;
/*    */ 
/*    */ import com.dreammirae.mmth.fido.Operation;
/*    */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*    */ import com.dreammirae.mmth.fido.handler.bean.IFidoRegistrionLocator;
/*    */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageCallback;
/*    */ import com.dreammirae.mmth.fido.handler.supporter.ReqMessageSupporter;
/*    */ import com.dreammirae.mmth.fido.json.UafSerializeUtils;
/*    */ import com.dreammirae.mmth.fido.uaf.DeregisterAuthenticator;
/*    */ import com.dreammirae.mmth.fido.uaf.DeregistrationRequest;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeregUAFRequestHandler<T extends IFidoRegistrionLocator>
/*    */   extends UAFRequestHandler<T>
/*    */ {
/*    */   protected DeregUAFRequestHandler(ReqMessageSupporter<T> supporter, ReqMessageCallback<T> callback) {
/* 26 */     super(supporter, callback);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String generateMessageImp(List<T> registrations, String username) throws FidoUafStatusCodeException {
/* 34 */     int len = registrations.size();
/* 35 */     DeregisterAuthenticator[] authenticators = new DeregisterAuthenticator[len];
/* 36 */     for (int i = 0; i < len; i++) {
/* 37 */       authenticators[i] = new DeregisterAuthenticator();
/* 38 */       authenticators[i].setAaid(((IFidoRegistrionLocator)registrations.get(i)).getAaid());
/* 39 */       authenticators[i].setKeyID(((IFidoRegistrionLocator)registrations.get(i)).getKeyId());
/*    */     } 
/*    */     
/* 42 */     DeregistrationRequest[] deregReq = new DeregistrationRequest[1];
/* 43 */     DeregistrationRequest dereg = new DeregistrationRequest();
/* 44 */     dereg.setHeader(getHeader());
/* 45 */     dereg.setAuthenticators(authenticators);
/* 46 */     deregReq[0] = dereg;
/*    */     
/* 48 */     return UafSerializeUtils.gson().toJson(deregReq);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Operation getOperation() {
/* 53 */     return Operation.Dereg;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\DeregUAFRequestHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */