/*    */ package com.dreammirae.mmth.fido.handler.notary;
/*    */ 
/*    */ import com.dreammirae.mmth.misc.Base64Utils;
/*    */ import com.dreammirae.mmth.util.notary.HMAC;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleNotary
/*    */   implements INotary
/*    */ {
/*    */   private static final String NOTARY_SECRET = "MMTH-NOTARY-SERVICE";
/*    */   private static INotary instance;
/*    */   
/*    */   public static INotary getInstance() {
/* 28 */     if (instance == null) {
/* 29 */       instance = new SimpleNotary();
/*    */     }
/*    */     
/* 32 */     return instance;
/*    */   }
/*    */   
/*    */   public String sign(String targetData) {
/*    */     try {
/* 37 */       return Base64Utils.encodeUrl(HMAC.sign(targetData, "MMTH-NOTARY-SERVICE"));
/* 38 */     } catch (Exception exception) {
/*    */ 
/*    */       
/* 41 */       return null;
/*    */     } 
/*    */   }
/*    */   public boolean verify(String targetData, String signature) {
/*    */     try {
/* 46 */       return MessageDigest.isEqual(Base64Utils.decodeRaw(signature), HMAC.sign(targetData, "MMTH-NOTARY-SERVICE"));
/* 47 */     } catch (Exception exception) {
/*    */ 
/*    */       
/* 50 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\handler\notary\SimpleNotary.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */