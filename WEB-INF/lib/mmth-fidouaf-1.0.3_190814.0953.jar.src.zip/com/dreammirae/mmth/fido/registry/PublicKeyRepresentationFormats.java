/*     */ package com.dreammirae.mmth.fido.registry;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalAlgorithmAndKeyException;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.notary.RSASSA_PSS_SHA256;
/*     */ import com.dreammirae.mmth.util.notary.SECP256K1;
/*     */ import com.dreammirae.mmth.util.notary.SECP256R1;
/*     */ import java.security.PublicKey;
/*     */ import org.bouncycastle.crypto.CryptoException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PublicKeyRepresentationFormats
/*     */ {
/*  27 */   UAF_ALG_KEY_ECC_X962_RAW(256)
/*     */   {
/*     */     public PublicKey getPublicKeyFromBytes(AuthenticationAlgorithms alg, byte[] pubKeyBytes) throws CryptoException
/*     */     {
/*  31 */       if (AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256R1_ECDSA_SHA256_RAW.equals(alg) || AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256R1_ECDSA_SHA256_DER
/*  32 */         .equals(alg)) {
/*  33 */         return SECP256R1.getPublicKeyfromRaw(pubKeyBytes);
/*     */       }
/*     */       
/*  36 */       if (AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256K1_ECDSA_SHA256_RAW.equals(alg) || AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256K1_ECDSA_SHA256_DER
/*  37 */         .equals(alg)) {
/*  38 */         return SECP256K1.getPublicKeyfromRaw(pubKeyBytes);
/*     */       }
/*     */       
/*  41 */       throw new CryptoException("FIDO UAF가 지원하지 않는 포맷입니다. PublicKeyFormat=" + Integer.toHexString(getId()) + ", Algorithms=" + 
/*  42 */           Integer.toHexString(alg.getId()));
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */   
/*  48 */   UAF_ALG_KEY_ECC_X962_DER(257)
/*     */   {
/*     */     
/*     */     public PublicKey getPublicKeyFromBytes(AuthenticationAlgorithms alg, byte[] pubKeyBytes) throws CryptoException
/*     */     {
/*  53 */       if (AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256R1_ECDSA_SHA256_RAW.equals(alg) || AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256R1_ECDSA_SHA256_DER
/*  54 */         .equals(alg)) {
/*     */         
/*  56 */         byte[] rawBytes = SECP256R1.getRawPublicKey(pubKeyBytes);
/*  57 */         return SECP256R1.getPublicKeyfromRaw(rawBytes);
/*     */       } 
/*     */       
/*  60 */       if (AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256K1_ECDSA_SHA256_RAW.equals(alg) || AuthenticationAlgorithms.UAF_ALG_SIGN_SECP256K1_ECDSA_SHA256_DER
/*  61 */         .equals(alg)) {
/*  62 */         byte[] rawBytes = SECP256K1.getRawPublicKey(pubKeyBytes);
/*  63 */         return SECP256K1.getPublicKeyfromRaw(rawBytes);
/*     */       } 
/*     */       
/*  66 */       throw new CryptoException("FIDO UAF가 지원하지 않는 포맷입니다. PublicKeyFormat=" + Integer.toHexString(getId()) + ", Algorithms=" + 
/*  67 */           Integer.toHexString(alg.getId()));
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  72 */   UAF_ALG_KEY_RSA_2048_PSS_RAW(258)
/*     */   {
/*     */     
/*     */     public PublicKey getPublicKeyFromBytes(AuthenticationAlgorithms alg, byte[] pubKeyBytes) throws CryptoException
/*     */     {
/*  77 */       if (AuthenticationAlgorithms.UAF_ALG_SIGN_RSASSA_PSS_SHA256_RAW.equals(alg) || AuthenticationAlgorithms.UAF_ALG_SIGN_RSASSA_PSS_SHA256_DER
/*  78 */         .equals(alg)) {
/*  79 */         return RSASSA_PSS_SHA256.getPublicKeyfromRaw(pubKeyBytes);
/*     */       }
/*     */       
/*  82 */       throw new CryptoException("FIDO UAF가 지원하지 않는 포맷입니다. PublicKeyFormat=" + Integer.toHexString(getId()) + ", Algorithms=" + 
/*  83 */           Integer.toHexString(alg.getId()));
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  88 */   UAF_ALG_KEY_RSA_2048_PSS_DER(259)
/*     */   {
/*     */     public PublicKey getPublicKeyFromBytes(AuthenticationAlgorithms alg, byte[] pubKeyBytes) throws CryptoException
/*     */     {
/*  92 */       if (AuthenticationAlgorithms.UAF_ALG_SIGN_RSASSA_PSS_SHA256_RAW.equals(alg) || AuthenticationAlgorithms.UAF_ALG_SIGN_RSASSA_PSS_SHA256_DER
/*  93 */         .equals(alg)) {
/*  94 */         return RSASSA_PSS_SHA256.getPublicKeyfromDer(pubKeyBytes);
/*     */       }
/*  96 */       throw new CryptoException("FIDO UAF가 지원하지 않는 포맷입니다. PublicKeyFormat=" + Integer.toHexString(getId()) + ", Algorithms=" + 
/*  97 */           Integer.toHexString(alg.getId()));
/*     */     }
/*     */   };
/*     */   
/*     */   private final int id;
/*     */   
/*     */   PublicKeyRepresentationFormats(int id) {
/* 104 */     this.id = id;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 108 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public static PublicKeyRepresentationFormats get(int id) throws IllegalAlgorithmAndKeyException {
/* 113 */     for (PublicKeyRepresentationFormats format : values()) {
/* 114 */       if (format.id == id) {
/* 115 */         return format;
/*     */       }
/*     */     } 
/*     */     
/* 119 */     throw new IllegalAlgorithmAndKeyException(StatusCodes.CODE_1495, "This id[" + HexUtils.toHexString((short)id) + "] is unsupported public key format.");
/*     */   }
/*     */   
/*     */   public abstract PublicKey getPublicKeyFromBytes(AuthenticationAlgorithms paramAuthenticationAlgorithms, byte[] paramArrayOfbyte) throws CryptoException;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\registry\PublicKeyRepresentationFormats.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */