/*    */ package com.dreammirae.mmth.fido.registry;
/*    */ 
/*    */ public enum UserVerificationMethods
/*    */ {
/*  5 */   USER_VERIFY_PRESENCE(1L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 10 */   USER_VERIFY_FINGERPRINT(2L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 15 */   USER_VERIFY_PASSCODE(4L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 20 */   USER_VERIFY_VOICEPRINT(8L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 25 */   USER_VERIFY_FACEPRINT(16L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   USER_VERIFY_LOCATION(32L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   USER_VERIFY_EYEPRINT(64L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   USER_VERIFY_PATTERN(128L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   USER_VERIFY_HANDPRINT(256L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   USER_VERIFY_NONE(512L),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   USER_VERIFY_ALL(1024L);
/*    */   
/*    */   private final long code;
/*    */   
/*    */   UserVerificationMethods(long code) {
/* 60 */     this.code = code;
/*    */   }
/*    */   
/*    */   public long getCode() {
/* 64 */     return this.code;
/*    */   }
/*    */ 
/*    */   
/*    */   public static UserVerificationMethods getUserVerificationMethods(long code) {
/* 69 */     for (UserVerificationMethods method : values()) {
/* 70 */       if (method.code == code) {
/* 71 */         return method;
/*    */       }
/*    */     } 
/*    */     
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\registry\UserVerificationMethods.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */