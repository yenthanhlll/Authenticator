/*     */ package com.dreammirae.mmth.fido.registry;
/*     */ 
/*     */ import com.dreammirae.mmth.fido.StatusCodes;
/*     */ import com.dreammirae.mmth.fido.exception.FidoUafStatusCodeException;
/*     */ import com.dreammirae.mmth.fido.exception.IllegalAlgorithmAndKeyException;
/*     */ import com.dreammirae.mmth.misc.SysEnvCommon;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.notary.RSASSA_PSS_SHA256;
/*     */ import com.dreammirae.mmth.util.notary.SECP256K1;
/*     */ import com.dreammirae.mmth.util.notary.SECP256R1;
/*     */ import com.dreammirae.mmth.util.notary.SHA;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import org.bouncycastle.crypto.CryptoException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum AuthenticationAlgorithms
/*     */ {
/*  29 */   UAF_ALG_SIGN_SECP256R1_ECDSA_SHA256_RAW(1)
/*     */   {
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, PublicKey pubkey) throws CryptoException
/*     */     {
/*  33 */       byte[] dERSignature = SECP256R1.getDEREncodedSignature(signature);
/*  34 */       return SECP256R1.verify(signedData, dERSignature, pubkey);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, X509Certificate x509Certificate) throws CryptoException {
/*  39 */       return verify_signature(signedData, signature, x509Certificate.getPublicKey());
/*     */     }
/*     */   },
/*     */   
/*  43 */   UAF_ALG_SIGN_SECP256R1_ECDSA_SHA256_DER(2)
/*     */   {
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, PublicKey pubkey) throws CryptoException
/*     */     {
/*  47 */       return SECP256R1.verify(signedData, signature, pubkey);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, X509Certificate x509Certificate) throws CryptoException {
/*  52 */       return verify_signature(signedData, signature, x509Certificate.getPublicKey());
/*     */     }
/*     */   },
/*     */   
/*  56 */   UAF_ALG_SIGN_RSASSA_PSS_SHA256_RAW(3)
/*     */   {
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, PublicKey pubkey) throws CryptoException
/*     */     {
/*  60 */       return RSASSA_PSS_SHA256.verify(signedData, signature, pubkey);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, X509Certificate x509Certificate) throws CryptoException {
/*  65 */       return RSASSA_PSS_SHA256.verify(signedData, signature, x509Certificate);
/*     */     }
/*     */   },
/*     */   
/*  69 */   UAF_ALG_SIGN_RSASSA_PSS_SHA256_DER(4)
/*     */   {
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, PublicKey pubkey) throws CryptoException {
/*  72 */       byte[] rawSignature = RSASSA_PSS_SHA256.getRawSignature(signature);
/*  73 */       return RSASSA_PSS_SHA256.verify(signedData, rawSignature, pubkey);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, X509Certificate x509Certificate) throws CryptoException {
/*  78 */       byte[] rawSignature = RSASSA_PSS_SHA256.getRawSignature(signature);
/*  79 */       return RSASSA_PSS_SHA256.verify(signedData, rawSignature, x509Certificate);
/*     */     }
/*     */   },
/*  82 */   UAF_ALG_SIGN_SECP256K1_ECDSA_SHA256_RAW(5)
/*     */   {
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, PublicKey pubkey) throws CryptoException
/*     */     {
/*  86 */       byte[] dERSignature = SECP256K1.getDEREncodedSignature(signature);
/*  87 */       return SECP256K1.verify(signedData, dERSignature, pubkey);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, X509Certificate x509Certificate) throws CryptoException {
/*  92 */       return verify_signature(signedData, signature, x509Certificate.getPublicKey());
/*     */     }
/*     */   },
/*  95 */   UAF_ALG_SIGN_SECP256K1_ECDSA_SHA256_DER(6)
/*     */   {
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, PublicKey pubkey) throws CryptoException
/*     */     {
/*  99 */       return SECP256K1.verify(signedData, signature, pubkey);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean verify_signature(byte[] signedData, byte[] signature, X509Certificate x509Certificate) throws CryptoException {
/* 104 */       return verify_signature(signedData, signature, x509Certificate.getPublicKey());
/*     */     }
/*     */   };
/*     */   
/*     */   private final int id;
/*     */   
/*     */   AuthenticationAlgorithms(int id) {
/* 111 */     this.id = id;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 115 */     return this.id;
/*     */   }
/*     */   
/*     */   public static AuthenticationAlgorithms get(int id) throws IllegalAlgorithmAndKeyException {
/* 119 */     for (AuthenticationAlgorithms tag : values()) {
/* 120 */       if (tag.id == id) {
/* 121 */         return tag;
/*     */       }
/*     */     } 
/*     */     
/* 125 */     throw new IllegalAlgorithmAndKeyException(StatusCodes.CODE_1495, "This id[" + HexUtils.toHexString((short)id) + "] is unsupported algorithm.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] hashingWithAlg(AuthenticationAlgorithms alg, String data) throws FidoUafStatusCodeException {
/*     */     try {
/* 144 */       return SHA.sha256(SysEnvCommon.getUtf8Bytes(data));
/* 145 */     } catch (Exception e) {
/* 146 */       throw new FidoUafStatusCodeException(StatusCodes.CODE_1498);
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract boolean verify_signature(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, PublicKey paramPublicKey) throws CryptoException;
/*     */   
/*     */   public abstract boolean verify_signature(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, X509Certificate paramX509Certificate) throws CryptoException;
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-fidouaf-1.0.3_190814.0953.jar!\com\dreammirae\mmth\fido\registry\AuthenticationAlgorithms.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */