package com.dreammirae.timeotp;

import com.dreammirae.gt.otp.Core;
import com.dreammirae.gt.otp.OtpResult;
import com.dreammirae.gt.otp.Policy;
import com.dreammirae.gt.otp.Token;
import com.dreammirae.gt.otp.Tool;
import com.dreammirae.hwotp.MrOtpException;
import com.dreammirae.hwotp.MrOtpResult;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public class OTP_MIRAE {
  private static Core a;
  
  private static byte[] b = null;
  
  private static boolean c = !(System.getProperty("MIRAE_TIMEOTP_DEBUG") == null);
  
  private static Policy d = new Policy();
  
  static {
    b = (a = Core.getInstance()).getSeedEncKey("hanabank", "9933DCD52BD09D47E906DD9C5E58AE5E");
    d.setNormAuthTmSkew(1);
    d.setUserSyncTmSkew(5);
    d.setAdminSyncTmSkew(120);
    d.setInitAuthTmSkew(30);
    d.setLongAuthTmSkew(10);
    d.setLongTerm(60);
    d.setServerTmSkew(0);
    a.setPolicy(d);
  }
  
  public static String info() {
    return String.format("Mirae TIMEOTP Library (ver:%s, %s)", new Object[] { "2.1.0", "2019-04-12 17:01:17" });
  }
  
  public static MrOtpResult verify(String paramString1, String paramString2, String paramString3) {
    MrOtpResult mrOtpResult;
    (mrOtpResult = new MrOtpResult()).setTokenKey(paramString2);
    try {
      if (paramString1 == null || paramString2 == null || paramString3 == null)
        throw new MrOtpException(6007); 
      if (paramString1.length() < 8)
        throw new MrOtpException(6007); 
      if (paramString2.trim().length() != 140)
        throw new MrOtpException(6007); 
      if (paramString3.length() != 6 || !b(paramString3))
        throw new MrOtpException(6010); 
      Token token;
      (token = a(paramString2)).setSn(paramString1.trim());
      byte[] arrayOfByte;
      Tool.toString(arrayOfByte = a(Tool.hexToByteArray(token.getSeed())));
      token.setSecret(a(Tool.hexToByteArray(token.getSeed())));
      OtpResult otpResult;
      switch ((otpResult = a.verifyOTP(paramString3, token)).getReturnCode()) {
        case 0:
          mrOtpResult.setRcCode(0);
          mrOtpResult.setTokenKey(a(token, otpResult.getLastAuthTm(), otpResult.getSkew()));
          break;
        case 6001:
          mrOtpResult.setRcCode(6001);
          break;
        case 6002:
          mrOtpResult.setRcCode(6002);
          mrOtpResult.setTokenKey(a(token, otpResult.getLastAuthTm()));
          break;
        default:
          mrOtpResult.setRcCode(otpResult.getReturnCode());
          break;
      } 
      if (c)
        System.out.println(otpResult); 
    } catch (MrOtpException mrOtpException) {
      mrOtpResult.setRcCode(mrOtpException.getCode());
    } catch (Exception exception) {
      (paramString1 = null).printStackTrace();
      mrOtpResult.setRcCode(6005);
    } 
    return mrOtpResult;
  }
  
  public static MrOtpResult syncUser(String paramString1, String paramString2, String paramString3) {
    MrOtpResult mrOtpResult;
    (mrOtpResult = new MrOtpResult()).setTokenKey(paramString2);
    try {
      if (paramString1 == null || paramString2 == null || paramString3 == null)
        throw new MrOtpException(6007); 
      if (paramString1.length() < 8)
        throw new MrOtpException(6007); 
      if (paramString2.trim().length() != 140)
        throw new MrOtpException(6007); 
      if (paramString3.length() != 6 || !b(paramString3))
        throw new MrOtpException(6010); 
      Token token;
      (token = a(paramString2)).setSn(paramString1.trim());
      token.setSecret(a(Tool.hexToByteArray(token.getSeed())));
      OtpResult otpResult;
      switch ((otpResult = a.syncOTPUser(paramString3, token)).getReturnCode()) {
        case 0:
          mrOtpResult.setRcCode(0);
          mrOtpResult.setTokenKey(a(token, otpResult.getLastAuthTm(), otpResult.getSkew()));
          break;
        case 6003:
          mrOtpResult.setRcCode(6003);
          break;
        case 6004:
          mrOtpResult.setRcCode(6004);
          mrOtpResult.setTokenKey(a(token, token.getLastAuthTm()));
          break;
        default:
          mrOtpResult.setRcCode(otpResult.getReturnCode());
          break;
      } 
      if (c)
        System.out.println(otpResult); 
    } catch (MrOtpException mrOtpException) {
      mrOtpResult.setRcCode(mrOtpException.getCode());
    } catch (Exception exception) {
      (paramString1 = null).printStackTrace();
      mrOtpResult.setRcCode(6005);
    } 
    return mrOtpResult;
  }
  
  public static MrOtpResult syncAdmin(String paramString1, String paramString2, String paramString3, String paramString4) {
    MrOtpResult mrOtpResult;
    (mrOtpResult = new MrOtpResult()).setTokenKey(paramString2);
    try {
      if (paramString1 == null || paramString2 == null || paramString3 == null)
        throw new MrOtpException(6007); 
      if (paramString1.length() < 8)
        throw new MrOtpException(6007); 
      if (paramString2.trim().length() != 140)
        throw new MrOtpException(6007); 
      if (paramString3.length() != 6 || !b(paramString3))
        throw new MrOtpException(6010); 
      if (paramString4.length() != 6 || !b(paramString4))
        throw new MrOtpException(6010); 
      Token token;
      (token = a(paramString2)).setSn(paramString1.trim());
      token.setSecret(a(Tool.hexToByteArray(token.getSeed())));
      OtpResult otpResult;
      switch ((otpResult = a.syncOtpAdmin(paramString3, paramString4, token)).getReturnCode()) {
        case 0:
          mrOtpResult.setRcCode(0);
          mrOtpResult.setTokenKey(a(token, otpResult.getLastAuthTm(), otpResult.getSkew()));
          break;
        case 6003:
          mrOtpResult.setRcCode(6003);
          break;
        case 6004:
          mrOtpResult.setRcCode(6004);
          mrOtpResult.setTokenKey(a(token, token.getLastAuthTm()));
          break;
        default:
          mrOtpResult.setRcCode(otpResult.getReturnCode());
          break;
      } 
      if (c)
        System.out.println(otpResult); 
    } catch (MrOtpException mrOtpException) {
      mrOtpResult.setRcCode(mrOtpException.getCode());
    } catch (Exception exception) {
      (paramString1 = null).printStackTrace();
      mrOtpResult.setRcCode(6005);
    } 
    return mrOtpResult;
  }
  
  public static boolean policy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    Policy policy = new Policy();
    try {
      policy.setNormAuthTmSkew(paramInt1);
      policy.setUserSyncTmSkew(paramInt2);
      policy.setAdminSyncTmSkew(paramInt3);
      policy.setInitAuthTmSkew(paramInt4);
      policy.setLongAuthTmSkew(paramInt5);
      policy.setLongTerm(paramInt6);
    } catch (IllegalArgumentException illegalArgumentException2) {
      IllegalArgumentException illegalArgumentException1;
      (illegalArgumentException1 = null).printStackTrace();
      return false;
    } 
    OtpResult otpResult;
    return ((otpResult = a.setPolicy(policy)).getReturnCode() == 0);
  }
  
  public static MrOtpResult unlock(String paramString1, String paramString2) {
    MrOtpResult mrOtpResult;
    (mrOtpResult = new MrOtpResult()).setTokenKey(paramString2);
    try {
      if (paramString1 == null || paramString2 == null)
        throw new MrOtpException(6007); 
      if (paramString1.length() < 8)
        throw new MrOtpException(6007); 
      if (paramString2.trim().length() != 140)
        throw new MrOtpException(6007); 
      Token token;
      (token = a(paramString2)).setSn(paramString1.trim());
      token.setSecret(a(Tool.hexToByteArray(token.getSeed())));
      OtpResult otpResult;
      switch ((otpResult = a.genOTPUnlockCode(token)).getReturnCode()) {
        case 0:
          mrOtpResult.setRcCode(0);
          mrOtpResult.setTokenKey(a(token, otpResult.getLastAuthTm(), otpResult.getSkew()));
          mrOtpResult.setUnlock(otpResult.getUnlockCode());
          break;
        default:
          mrOtpResult.setRcCode(otpResult.getReturnCode());
          break;
      } 
      if (c)
        System.out.println(otpResult); 
    } catch (MrOtpException mrOtpException) {
      mrOtpResult.setRcCode(mrOtpException.getCode());
    } catch (Exception exception) {
      (paramString1 = null).printStackTrace();
      mrOtpResult.setRcCode(6005);
    } 
    return mrOtpResult;
  }
  
  public static String policyInfo() {
    return a.getPolicy().toString();
  }
  
  private static byte[] a(byte[] paramArrayOfbyte) throws Exception {
    return a.DECRYPT(null, null, b, null, paramArrayOfbyte);
  }
  
  private static Token a(String paramString) throws MrOtpException {
    Token token = new Token();
    String str1 = paramString.substring(0, 64);
    String str2 = paramString.substring(64, 65);
    String str3 = paramString.substring(65, 66);
    String str4 = paramString.substring(66, 76);
    String str5 = paramString.substring(76, 86);
    String str6 = paramString.substring(86, 91);
    String str7 = paramString.substring(91, 96);
    String str8 = paramString.substring(96, 100);
    paramString = paramString.substring(100, 140);
    if (c) {
      System.out.println();
      System.out.println("----------------------------");
      System.out.println(" key        =[" + str1 + "]");
      System.out.println(" algType    =[" + str2 + "]");
      System.out.println(" cycle      =[" + str3 + "]");
      System.out.println(" lastAuthTm =[" + str4 + "]");
      System.out.println(" timeOffset =[" + str5 + "]");
      System.out.println(" intOrgCode =[" + str6 + "]");
      System.out.println(" reserved   =[" + str7 + "]");
      System.out.println(" end        =[" + str8 + "]");
      System.out.println(" checksum   =[" + paramString + "]");
      System.out.println("----------------------------");
    } 
    str7 = (str7 = String.valueOf(str1) + str2 + str3 + ToolsUtil.padRight(str4, 10) + ToolsUtil.padRight(str5, 10) + str6 + str7 + str8).toUpperCase();
    try {
      str7 = (str7 = ToolsUtil.SHA1(str7)).toUpperCase();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      (paramString = null).printStackTrace();
      throw new MrOtpException(6015);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      (paramString = null).printStackTrace();
      throw new MrOtpException(6015);
    } 
    if (c)
      System.out.println("csum=[" + str7 + "]"); 
    if (!paramString.equalsIgnoreCase(str7))
      throw new MrOtpException(6015); 
    token.setAlg(str2);
    token.setCycle(str3);
    token.setIntOrgCd(str6);
    token.setSeed(str1);
    token.setLastAuthTm(Integer.parseInt(str4.trim()));
    token.setTimeSkew(Integer.parseInt(str5.trim()));
    return token;
  }
  
  private static String a(Token paramToken, int paramInt) {
    return a(paramToken, paramInt, paramToken.getTimeSkew());
  }
  
  private static String a(Token paramToken, int paramInt1, int paramInt2) {
    String str2;
    String str3 = ToolsUtil.padRight("", 5);
    String str4 = "ZZZZ";
    StringBuffer stringBuffer = new StringBuffer();
    String str1 = (str1 = String.valueOf(paramToken.getSeed()) + paramToken.getAlg() + paramToken.getCycle() + ToolsUtil.padRight(Integer.toString(paramInt1), 10) + ToolsUtil.padRight(Integer.toString(paramInt2), 10) + paramToken.getIntOrgCd() + str3 + str4).toUpperCase();
    try {
      str2 = (str2 = ToolsUtil.SHA1(str1)).toUpperCase();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      (str1 = null).printStackTrace();
      return null;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      (str1 = null).printStackTrace();
      return null;
    } 
    stringBuffer.append(str1).append(str2);
    return stringBuffer.toString();
  }
  
  private static boolean b(String paramString) {
    try {
      Integer.parseInt(paramString);
    } catch (NumberFormatException numberFormatException) {
      return false;
    } 
    return true;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\timeotp\OTP_MIRAE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */