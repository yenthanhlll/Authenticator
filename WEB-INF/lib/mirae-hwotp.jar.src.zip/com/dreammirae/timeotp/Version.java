package com.dreammirae.timeotp;

public class Version {
  public static final String BUILD_DATE = "2019-04-12 17:01:17";
  
  public static final String VERSION = "2.1.0";
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\timeotp\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */