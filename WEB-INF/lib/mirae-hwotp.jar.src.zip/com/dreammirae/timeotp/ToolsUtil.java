package com.dreammirae.timeotp;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class ToolsUtil {
  public static String zeroPad(String paramString, int paramInt) {
    return zeroPad((new Integer(paramString)).intValue(), paramInt);
  }
  
  public static String zeroPad(int paramInt1, int paramInt2) {
    return String.format("%0" + paramInt2 + "d", new Object[] { Integer.valueOf(paramInt1) });
  }
  
  public static String padRight(String paramString, int paramInt) {
    return String.format("%1$-" + paramInt + "s", new Object[] { paramString });
  }
  
  public static String padLeft(String paramString, int paramInt) {
    return String.format("%1$#" + paramInt + "s", new Object[] { paramString });
  }
  
  public static String HMAC_SHA1(String paramString1, String paramString2) throws SignatureException {
    byte[] arrayOfByte = HMAC_SHA1(paramString1.getBytes(), paramString2.getBytes());
    return new String(arrayOfByte);
  }
  
  public static byte[] HMAC_SHA1(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws SignatureException {
    try {
      SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte2, "HmacSHA1");
      Mac mac;
      (mac = Mac.getInstance("HmacSHA1")).init(secretKeySpec);
      paramArrayOfbyte1 = mac.doFinal(paramArrayOfbyte1);
    } catch (Exception exception) {
      throw new SignatureException("Failed to generate HMAC : " + exception.getMessage());
    } 
    return paramArrayOfbyte1;
  }
  
  public static String SHA1(String paramString) throws NoSuchAlgorithmException, UnsupportedEncodingException {
    MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
    byte[] arrayOfByte = paramString.getBytes("UTF-8");
    messageDigest.update(arrayOfByte, 0, arrayOfByte.length);
    return convertToHex(arrayOfByte = messageDigest.digest());
  }
  
  public static String convertToHex(byte[] paramArrayOfbyte) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b = 0;
    while (b < paramArrayOfbyte.length) {
      int i = paramArrayOfbyte[b] >>> 4 & 0xF;
      byte b1 = 0;
      while (true) {
        if (i >= 0 && i <= 9) {
          stringBuffer.append((char)(i + 48));
        } else {
          stringBuffer.append((char)(i + 97 - 10));
        } 
        i = paramArrayOfbyte[b] & 0xF;
        if (b1++ > 0)
          b++; 
      } 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\timeotp\ToolsUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */