package com.dreammirae.hwotp;

import com.dreammirae.aotp.AOTP;
import com.dreammirae.aotp.AOTPToken;
import com.dreammirae.timeotp.OTP_MIRAE;
import com.dreammirae.timeotp.ToolsUtil;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HwOTP {
  public static MrOtpResult genChallenge(String paramString1, String paramString2, String paramString3) {
    AOTPToken aOTPToken;
    MrOtpResult mrOtpResult = new MrOtpResult();
    try {
      aOTPToken = a(paramString1, paramString2);
    } catch (MrOtpException mrOtpException) {
      (paramString2 = null).printStackTrace();
      return mrOtpResult.setRcCode(paramString2.getCode());
    } 
    if (!(paramString2 = aOTPToken.getModelCd()).equals("19"))
      return mrOtpResult.setRcCode(6017); 
    (mrOtpResult = AOTP.genChallenge(aOTPToken, paramString3, AOTP.challengeTimeOverMin)).setTokenKey(aOTPToken.getTokenKeyAll());
    return mrOtpResult;
  }
  
  public static MrOtpResult verify(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    MrOtpResult mrOtpResult = new MrOtpResult();
    if (paramString1 == null || paramString1.length() != 2) {
      mrOtpResult.setRcCode(6007);
      return mrOtpResult;
    } 
    try {
      AOTPToken aOTPToken;
      if (paramString1.equals("03")) {
        (mrOtpResult = AOTP.verifyOTP(aOTPToken = a(paramString2, paramString3), paramString5, paramString4)).setTokenKey(aOTPToken.getTokenKeyAll());
        return mrOtpResult;
      } 
      if (aOTPToken.equals("01") || aOTPToken.equals("02"))
        return OTP_MIRAE.verify(paramString2, paramString3, paramString4); 
      mrOtpResult.setRcCode(6007);
      return mrOtpResult;
    } catch (MrOtpException mrOtpException) {
      mrOtpResult.setRcCode(mrOtpException.getCode());
      return mrOtpResult;
    } 
  }
  
  public static MrOtpResult unlock(String paramString1, String paramString2, String paramString3) {
    MrOtpResult mrOtpResult = new MrOtpResult();
    if (paramString1 == null || paramString1.length() != 2) {
      mrOtpResult.setRcCode(6007);
      return mrOtpResult;
    } 
    try {
      AOTPToken aOTPToken;
      if (paramString1.equals("03")) {
        (mrOtpResult = AOTP.genUnlockCode(aOTPToken = a(paramString2, paramString3))).setTokenKey(aOTPToken.getTokenKeyAll());
        return mrOtpResult;
      } 
      if (aOTPToken.equals("01") || aOTPToken.equals("02"))
        return OTP_MIRAE.unlock(paramString2, paramString3); 
      mrOtpResult.setRcCode(6007);
      return mrOtpResult;
    } catch (MrOtpException mrOtpException) {
      mrOtpResult.setRcCode(mrOtpException.getCode());
      return mrOtpResult;
    } 
  }
  
  public static MrOtpResult syncUser(String paramString1, String paramString2, String paramString3) {
    return OTP_MIRAE.syncUser(paramString1, paramString2, paramString3);
  }
  
  public static MrOtpResult syncAdmin(String paramString1, String paramString2, String paramString3, String paramString4) {
    return OTP_MIRAE.syncAdmin(paramString1, paramString2, paramString3, paramString4);
  }
  
  public static boolean policy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
    boolean bool;
    if (bool = OTP_MIRAE.policy(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6)) {
      AOTP.challengeTimeOverMin = paramInt7;
      return true;
    } 
    return false;
  }
  
  private static AOTPToken a(String paramString1, String paramString2) throws MrOtpException {
    AOTPToken aOTPToken = new AOTPToken();
    if (paramString2.length() != 223)
      throw new MrOtpException(6016); 
    String str1 = paramString2.substring(0, 64);
    String str2 = paramString2.substring(64, 65);
    String str3 = paramString2.substring(65, 79);
    String str4 = paramString2.substring(79, 81);
    String str5 = paramString2.substring(81, 82);
    String str6 = paramString2.substring(82, 85);
    String str7 = paramString2.substring(85, 149);
    String str8 = paramString2.substring(149, 163);
    String str9 = paramString2.substring(163, 177);
    String str10 = paramString2.substring(177, 178);
    String str11 = paramString2.substring(178, 179);
    String str12 = paramString2.substring(179, 183);
    paramString2 = paramString2.substring(183, 223);
    try {
      SimpleDateFormat simpleDateFormat;
      Date date2 = (simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss")).parse(str8);
      Timestamp timestamp1 = new Timestamp(date2.getTime());
      Date date3 = simpleDateFormat.parse(str9);
      Timestamp timestamp2 = new Timestamp(date3.getTime());
      Date date1 = simpleDateFormat.parse(str3);
      Timestamp timestamp3 = new Timestamp(date1.getTime());
      String str = (str = String.valueOf(str1) + str2 + simpleDateFormat.format(date1) + str4 + str5 + str6 + str7 + simpleDateFormat.format(date2) + simpleDateFormat.format(date3) + str10 + str11 + str12).toUpperCase();
      try {
        str = (str = ToolsUtil.SHA1(str)).toUpperCase();
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        (paramString1 = null).printStackTrace();
        throw new MrOtpException(6015);
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        (paramString1 = null).printStackTrace();
        throw new MrOtpException(6015);
      } 
      if (!paramString2.equalsIgnoreCase(str))
        throw new MrOtpException(6015); 
      aOTPToken.setTokenId(paramString1);
      aOTPToken.setTokenKey(str1);
      aOTPToken.setAlgType(str2);
      aOTPToken.setOtpAuthTm(timestamp3);
      aOTPToken.setModelCd(str4);
      aOTPToken.setPinUseYn(str5);
      aOTPToken.setUnlockCnt(Integer.parseInt(str6.trim()));
      aOTPToken.setOtpChal(str7);
      aOTPToken.setChalGenTm(timestamp1);
      aOTPToken.setChalExpTm(timestamp2);
      aOTPToken.setChalUseYn(str10);
      aOTPToken.setChalLen(str11);
      return aOTPToken;
    } catch (ParseException parseException2) {
      ParseException parseException1;
      (parseException1 = null).printStackTrace();
      throw new MrOtpException(6016);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\hwotp\HwOTP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */