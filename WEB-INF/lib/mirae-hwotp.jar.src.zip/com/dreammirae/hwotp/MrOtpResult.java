package com.dreammirae.hwotp;

public class MrOtpResult {
  private int a = 0;
  
  private String b;
  
  private String c;
  
  private String d = null;
  
  public String getChallenge() {
    return this.d;
  }
  
  public void setChallenge(String paramString) {
    this.d = paramString;
  }
  
  public int getRcCode() {
    return this.a;
  }
  
  public String getTokenKey() {
    return this.c;
  }
  
  public MrOtpResult setTokenKey(String paramString) {
    this.c = paramString;
    return this;
  }
  
  public MrOtpResult setRcCode(int paramInt) {
    this.a = paramInt;
    return this;
  }
  
  public String getUnlock() {
    return this.b;
  }
  
  public MrOtpResult setUnlock(String paramString) {
    this.b = paramString;
    return this;
  }
  
  public String toString() {
    return "MrOtpResult [rcCode=" + this.a + ", tokenKey=" + this.c + "]";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\hwotp\MrOtpResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */