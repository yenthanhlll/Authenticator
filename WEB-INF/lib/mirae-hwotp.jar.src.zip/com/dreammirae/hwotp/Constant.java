package com.dreammirae.hwotp;

public final class Constant {
  public static final String JAR_INFO = "Mirae technology TimeOtp Core Library(java), ver:2.0.1";
  
  public static final int RC_0_OK = 0;
  
  public static final int RC_0_VERIFY_SUCCESS = 0;
  
  public static final int RC_0_UNLOCK_SUCCESS = 0;
  
  public static final int RC_6000_VERIFY_FAIL = 6000;
  
  public static final int RC_6001_VERIFY_EQL_OTP = 6001;
  
  public static final int RC_6002_SYNC_NEED = 6002;
  
  public static final int RC_6003_SYNC_FAIL = 6003;
  
  public static final int RC_6004_SYNC_EQL_OTP = 6004;
  
  public static final int RC_6005_UNDEFINED = 6005;
  
  public static final int RC_6007_INVALID_INPUT = 6007;
  
  public static final int RC_6010_INVALID_OTP = 6010;
  
  public static final int RC_6011_CHALLENGE_EXPIRED = 6011;
  
  public static final int RC_6012_TOKENFILE_NOTFOUND = 6012;
  
  public static final int RC_6013_TOKENFILE_PIN_ERR = 6013;
  
  public static final int RC_6014_GEN_UNLOCKCODE_FAIL = 6014;
  
  public static final int RC_6015_CSUM_FAIL = 6015;
  
  public static final int RC_6016_TOKEN_PARSE_FAIL = 6016;
  
  public static final int RC_6017_NOT_SUPPORT = 6017;
  
  public static int[] OTP_LENGTH_MOD = new int[] { 0, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\hwotp\Constant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */