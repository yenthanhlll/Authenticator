package com.dreammirae.hwotp;

public class MrOtpException extends Exception {
  private int a;
  
  public MrOtpException(int paramInt) {
    this.a = paramInt;
  }
  
  public int getCode() {
    return this.a;
  }
  
  public void setCode(int paramInt) {
    this.a = paramInt;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\hwotp\MrOtpException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */