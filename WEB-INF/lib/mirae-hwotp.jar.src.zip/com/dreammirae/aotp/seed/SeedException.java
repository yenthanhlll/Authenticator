package com.dreammirae.aotp.seed;

public class SeedException extends Exception {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\seed\SeedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */