package com.dreammirae.aotp;

import java.util.List;

public final class AOTPResult {
  private int a = 0;
  
  private String b = null;
  
  private String c = null;
  
  private List d = null;
  
  public AOTPResult() {
    this.a = 6005;
  }
  
  public final int getReturnCode() {
    return this.a;
  }
  
  public final void setReturnCode(int paramInt) {
    this.a = paramInt;
  }
  
  public final String getUnlockCode() {
    return this.b;
  }
  
  public final void setUnlockCode(String paramString) {
    if (paramString == null)
      return; 
    this.b = paramString;
  }
  
  public final String getChallenge() {
    return this.c;
  }
  
  public final void setChallenge(String paramString) {
    this.c = paramString;
  }
  
  public final List getImportTokens() {
    return this.d;
  }
  
  public final void setImportTokens(List paramList) {
    this.d = paramList;
  }
  
  public final String toString() {
    return "AOTPResult [returnCode=" + this.a + ", unlockCode=" + this.b + ", challeng=" + this.c + "]";
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\AOTPResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */