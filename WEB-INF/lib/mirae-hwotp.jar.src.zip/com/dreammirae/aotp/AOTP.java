package com.dreammirae.aotp;

import com.dreammirae.aotp.keyfile.InvalidPinException;
import com.dreammirae.aotp.keyfile.a;
import com.dreammirae.aotp.keyfile.e;
import com.dreammirae.hwotp.MrOtpResult;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;

public class AOTP {
  private static final Core a = Core.getInstance();
  
  private static HashMap b;
  
  public static int challengeTimeOverMin = 3;
  
  public static MrOtpResult genChallenge(AOTPToken paramAOTPToken, String paramString, int paramInt) {
    MrOtpResult mrOtpResult = null;
    try {
      if (paramString == null) {
        mrOtpResult = a.generateChallenge(paramAOTPToken, paramInt);
      } else {
        mrOtpResult = a.generateChallenge(paramAOTPToken, paramString, paramInt);
      } 
    } catch (Throwable throwable) {
      (paramAOTPToken = null).printStackTrace();
    } 
    return mrOtpResult;
  }
  
  public static MrOtpResult verifyOTP(AOTPToken paramAOTPToken, String paramString1, String paramString2) {
    MrOtpResult mrOtpResult = null;
    try {
      if (paramString1 == null) {
        mrOtpResult = a.verifyOtp(paramAOTPToken, paramString2);
      } else {
        mrOtpResult = a.verifyOtp(paramAOTPToken, paramString2, paramString1);
      } 
    } catch (Throwable throwable) {
      (paramAOTPToken = null).printStackTrace();
    } 
    return mrOtpResult;
  }
  
  public static MrOtpResult genUnlockCode(AOTPToken paramAOTPToken) {
    MrOtpResult mrOtpResult = null;
    try {
      mrOtpResult = a.generateUnlockCode(paramAOTPToken);
    } catch (Throwable throwable) {
      (paramAOTPToken = null).printStackTrace();
    } 
    return mrOtpResult;
  }
  
  public static AOTPResult importToken(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    AOTPResult aOTPResult = new AOTPResult();
    try {
      long l1;
      long l2;
      if (paramString1 == null || paramString2 == null || paramString3 == null || paramString4 == null || paramString5 == null)
        throw new AOTPException(6007); 
      paramString1 = paramString1.trim();
      paramString2 = paramString2.trim();
      paramString3 = paramString3.trim();
      paramString4 = paramString4.trim();
      paramString5 = paramString5.trim();
      paramString3 = paramString3.toUpperCase();
      if (!b.containsKey(paramString3))
        throw new AOTPException(6007); 
      try {
        l1 = Long.parseLong(paramString4);
        l2 = Long.parseLong(paramString5);
      } catch (NumberFormatException numberFormatException) {
        throw new AOTPException(6007);
      } 
      e e;
      a[] arrayOfA1 = (e = a.a(paramString1, paramString2)).a();
      paramString4 = e.b().h();
      paramString5 = e.b().g();
      String str2 = (e.b().e() == "00") ? "N" : "Y";
      String str3 = e.b().a();
      String str4 = e.b().b();
      String str1 = e.b().d();
      ArrayList<AOTPToken> arrayList = new ArrayList(arrayOfA1.length);
      a[] arrayOfA2;
      int i = (arrayOfA2 = arrayOfA1).length;
      for (byte b = 0; b < i; b++) {
        a a;
        long l;
        if ((l = Long.parseLong((a = arrayOfA2[b]).b())) >= l1 && l <= l2) {
          AOTPToken aOTPToken;
          (aOTPToken = new AOTPToken()).setTokenId(a.b());
          aOTPToken.setTokenKey(Tool.toString(a.SEED_ENCRYPT(a.a())));
          aOTPToken.setChalLen(paramString4);
          aOTPToken.setUnlockCnt(0);
          aOTPToken.setModelCd(paramString5);
          aOTPToken.setPinUseYn(str2);
          aOTPToken.setAlgType(str3);
          aOTPToken.setProdDt(str4);
          aOTPToken.setExpireDt(str1);
          aOTPToken.setNationCd(paramString3);
          arrayList.add(aOTPToken);
        } 
      } 
      aOTPResult.setImportTokens(arrayList);
      aOTPResult.setReturnCode(0);
    } catch (FileNotFoundException fileNotFoundException) {
      aOTPResult.setReturnCode(6012);
    } catch (InvalidPinException invalidPinException) {
      aOTPResult.setReturnCode(6013);
    } catch (AOTPException aOTPException) {
      aOTPResult.setReturnCode(aOTPException.getCode());
    } catch (Throwable throwable) {
      (paramString1 = null).printStackTrace();
    } 
    return aOTPResult;
  }
  
  static {
    (b = new HashMap<Object, Object>()).put("AF", "AFGHANISTAN(아프가니스탄)");
    b.put("AL", "ALBANIA(알바니아)");
    b.put("DZ", "ALGERIA(알제리)");
    b.put("AS", "AMERICAN SAMOA(미국령 사모아)");
    b.put("AD", "ANDORRA(안도라)");
    b.put("AO", "ANGOLA(앙골라)");
    b.put("AI", "ANGUILLA(안길라)");
    b.put("AQ", "ANTARCTICA(남극)");
    b.put("AG", "ANTIGUA AND BARBUDA(안티구아 바부다)");
    b.put("AR", "ARGENTINA(아르헨티나)");
    b.put("AM", "ARMENIA(아르메니아)");
    b.put("AW", "ARUBA(아루바)");
    b.put("AU", "AUSTRALIA(오스트레일리아)");
    b.put("AT", "AUSTRIA(오스트리아)");
    b.put("AZ", "AZERBAIJAN(아제르바이잔)");
    b.put("BS", "BAHAMAS(바하마)");
    b.put("BH", "BAHRAIN(바레인)");
    b.put("BD", "BANGLADESH(방글라데시)");
    b.put("BB", "BARBADOS(바베이도스)");
    b.put("BE", "BELGIUM(벨기에)");
    b.put("BZ", "BELIZE(벨리즈)");
    b.put("BJ", "BENIN(베넹)");
    b.put("BM", "BERMUDA(버뮤다)");
    b.put("BT", "BHUTAN(부탄)");
    b.put("BO", "BOLIVIA(볼리비아)");
    b.put("BA", "BOSNIA HERCEGOVINA(보스니아 헤르체고비나)");
    b.put("BW", "BOTSWANA(보트와나)");
    b.put("BV", "BOUVET ISLAND(부베이 섬)");
    b.put("BR", "BRAZIL(브라질)");
    b.put("IO", "BRITISH INDIAN OCEAN TERRITORY(영인도 제도)");
    b.put("BN", "BRUNEI DARUSSALAM(브루나이)");
    b.put("BG", "BULGARIA(불가리아)");
    b.put("BF", "BURKINA FASO(부르키나파소)");
    b.put("BI", "BURUNDI(브룬디)");
    b.put("BY", "BELARUS(벨라루스)");
    b.put("KH", "CAMBODIA(캄보디아)");
    b.put("CM", "CAMEROON(카메룬)");
    b.put("CA", "CANADA(캐나다)");
    b.put("CV", "CAPE VERDE(까뽀베르데)");
    b.put("KY", "CAYMAN ISLANDS(카이만 군도)");
    b.put("CF", "CENTRAL AFRICAN REPUBLIC(중앙 아프리카)");
    b.put("TD", "CHAD(차드)");
    b.put("CL", "CHILE(칠레)");
    b.put("CN", "CHINA(중국)");
    b.put("CX", "CHRISTMAS ISLAND(크리스마스 섬)");
    b.put("CC", "COCOS (KEELING) ISLANDS(코코스킬링 제도)");
    b.put("CO", "COLOMBIA(콜롬비아)");
    b.put("KM", "COMOROS(코모르)");
    b.put("CG", "CONGO(콩고)");
    b.put("CK", "COOK ISLANDS(쿠크 군도)");
    b.put("CR", "COSTA RICA(코스타리카)");
    b.put("CI", "COTE D'IVOIRE(코트디부와르)");
    b.put("HR", "CROATIA(크로아티아)");
    b.put("CU", "CUBA(쿠바)");
    b.put("CY", "CYPRUS(사이프러스)");
    b.put("CZ", "CZECH REPUBLIC(체코)");
    b.put("CS", "CZECHOSLOVAKIA(체코슬로바키아)");
    b.put("DK", "DENMARK(덴마크)");
    b.put("DJ", "DJIBOUTI(지부티)");
    b.put("DM", "DOMINICA(도미니카)");
    b.put("DO", "DOMINICAN REPUBLIC(도미니카 공화국)");
    b.put("TP", "EAST TIMOR(동티모르)");
    b.put("EC", "ECUADOR(에쿠아도르)");
    b.put("EG", "EGYPT(이집트)");
    b.put("SV", "EL SALVADOR(엘살바도르)");
    b.put("GQ", "EQUATORIAL GUINEA(적도 기니)");
    b.put("EE", "ESTONIA(에스토니아)");
    b.put("ET", "ETHIOPIA(이디오피아)");
    b.put("FK", "FALKLAND ISLANDS (포클랜드)");
    b.put("FO", "FAROE ISLANDS(페로 군도)");
    b.put("FJ", "FIJI(피지)");
    b.put("FI", "FINLAND(핀란드)");
    b.put("FR", "FRANCE(프랑스)");
    b.put("GF", "FRENCH GUIANA(프랑스령 기아나)");
    b.put("PF", "FRENCH POLYNESIA(프랑스령 폴리네시아)");
    b.put("TF", "FRENCH SOUTHERN TERRITORIES(프랑스 남부 지역)");
    b.put("GA", "GABON(가봉)");
    b.put("GM", "GAMBIA(감비아)");
    b.put("GE", "GEORGIA(그루지야)");
    b.put("DE", "GERMANY(독일)");
    b.put("GH", "GHANA(가나)");
    b.put("GI", "GIBRALTAR(지브랄타)");
    b.put("GR", "GREECE(그리스)");
    b.put("GL", "GREENLAND(그린랜드)");
    b.put("GD", "GRENADA(그레나다)");
    b.put("GP", "GUADELOUPE(과달로프)");
    b.put("GU", "GUAM(괌)");
    b.put("GT", "GUATEMALA(과테말라)");
    b.put("GN", "GUINEA(기니)");
    b.put("GW", "GUINEA-BISSAU(기네비쏘)");
    b.put("GY", "GUYANA(가이아나)");
    b.put("HT", "HAITI(아이티)");
    b.put("HM", "HEARD AND MC DONALD ISLANDS(허드 섬 및 맥도날드 군도)");
    b.put("HN", "HONDURAS(온두라스)");
    b.put("HK", "HONG KONG(홍콩)");
    b.put("HU", "HUNGARY(헝가리)");
    b.put("IS", "ICELAND(아이슬랜드)");
    b.put("IN", "INDIA(인도)");
    b.put("ID", "INDONESIA(인도네시아)");
    b.put("IR", "IRAN (ISLAMIC REPUBLIC OF) - 이란(이슬람 공화국)");
    b.put("IQ", "IRAQ(이라크)");
    b.put("IE", "IRELAND(아일랜드)");
    b.put("IL", "ISRAEL(이스라엘)");
    b.put("IT", "ITALY(이탈리아)");
    b.put("JM", "JAMAICA(자메이카)");
    b.put("JP", "JAPAN(일본)");
    b.put("JO", "JORDAN(요르단)");
    b.put("KZ", "KAZAKHSTAN(카자흐스탄)");
    b.put("KE", "KENYA(케냐)");
    b.put("KI", "KIRIBATI(키리바시)");
    b.put("KP", "DEMOCRATIC PEOPLE'S REPUBLIC OF KOREA(북한)");
    b.put("KR", "REPUBLIC OF KOREA(대한민국)");
    b.put("KW", "KUWAIT(쿠웨이트)");
    b.put("KG", "KYRGYZSTAN(키르기스스탄)");
    b.put("LA", "LAO PEOPLE'S DEMOCRATIC REPUBLIC(라오스)");
    b.put("LV", "LATVIA(라트비아)");
    b.put("LB", "LEBANON(레바논)");
    b.put("LS", "LESOTHO(레소토)");
    b.put("LR", "LIBERIA(리베리아)");
    b.put("LY", "LIBYAN ARAB JAMAHIRIYA(리비아)");
    b.put("LI", "LIECHTENSTEIN(리히텐슈타인)");
    b.put("LT", "LITHUANIA(리투아니아)");
    b.put("LU", "LUXEMBOURG(룩셈부르크)");
    b.put("MO", "MACAU(마카오)");
    b.put("MG", "MADAGASCAR(마다가스카르)");
    b.put("MW", "MALAWI(말라위)");
    b.put("MY", "MALAYSIA(말레이지아)");
    b.put("MV", "MALDIVES(몰디브)");
    b.put("ML", "MALI(말리)");
    b.put("MT", "MALTA(말타)");
    b.put("MH", "MARSHALL ISLANDS(마샬 군도)");
    b.put("MQ", "MARTINIQUE(말티니크)");
    b.put("MR", "MAURITANIA(말티니크)");
    b.put("MU", "MAURITIUS(모리셔스)");
    b.put("MX", "MEXICO(멕시코)");
    b.put("FM", "MICRONESIA(마이크로네시아)");
    b.put("MD", "MOLDOVA, REPUBLIC OF(몰도바)");
    b.put("MC", "MONACO(모나코)");
    b.put("MN", "MONGOLIA(몽골)");
    b.put("MS", "MONTSERRAT(몬트세라트)");
    b.put("MA", "MOROCCO(모로코)");
    b.put("MZ", "MOZAMBIQUE(모잠비크)");
    b.put("MM", "MYANMAR(미얀마)");
    b.put("NA", "NAMIBIA(나미비아)");
    b.put("NR", "NAURU(나우루)");
    b.put("NP", "NEPAL(네팔)");
    b.put("NL", "NETHERLANDS(네덜란드)");
    b.put("AN", "NETHERLANDS ANTILLES(네덜란드령 안틸레스)");
    b.put("NT", "NEUTRAL ZONE(중립 지대)");
    b.put("NC", "NEW CALEDONIA(뉴 칼레도니아)");
    b.put("NZ", "NEW ZEALAND(뉴질랜드)");
    b.put("NI", "NICARAGUA(니카라과)");
    b.put("NE", "NIGER(니제르)");
    b.put("NG", "NIGERIA(나이지리아)");
    b.put("NU", "NIUE(니우에)");
    b.put("NF", "NORFOLK ISLAND(노퍽)");
    b.put("MP", "NORTHERN MARIANA ISLANDS(북마리아나 군도)");
    b.put("NO", "NORWAY(노르웨이)");
    b.put("OM", "OMAN(오만)");
    b.put("PK", "PAKISTAN(파키스탄)");
    b.put("PW", "PALAU(팔라우)");
    b.put("PA", "PANAMA(파나마)");
    b.put("PG", "PAPUA NEW GUINEA(파푸아뉴기니)");
    b.put("PY", "PARAGUAY(파라과이)");
    b.put("PE", "PERU(페루)");
    b.put("PH", "PHILIPPINES(필리핀)");
    b.put("PN", "PITCAIRN(핏케언 군도)");
    b.put("PL", "POLAND(폴란드)");
    b.put("PT", "PORTUGAL(포르투갈)");
    b.put("PR", "PUERTO RICO(푸에르토리코)");
    b.put("QA", "QATAR(카타르)");
    b.put("RE", "REUNION(리유니언)");
    b.put("RO", "ROMANIA(루마니아)");
    b.put("RU", "RUSSIAN FEDERATION(러시아)");
    b.put("RW", "RWANDA(르완다)");
    b.put("SH", "ST. HELENA(세인트 헬레나)");
    b.put("KN", "SAINT KITTS AND NEVIS(세인트 크리스토퍼 니비스)");
    b.put("LC", "SAINT LUCIA(세인트 루시아)");
    b.put("PM", "ST. PIERRE AND MIQUELON(세인트 피에르 미퀠론)");
    b.put("VC", "SAINT VINCENT AND THE GRENADINES(세인트 빈센트 그레나딘스)");
    b.put("WS", "SAMOA(사모아)");
    b.put("SM", "SAN MARINO(산마리노)");
    b.put("ST", "SAO TOME AND PRINCIPE(쌍투메 프린시페)");
    b.put("SA", "SAUDI ARABIA(사우디아라비아)");
    b.put("SN", "SENEGAL(세네갈)");
    b.put("SC", "SEYCHELLES(세이셸)");
    b.put("SL", "SIERRA LEONE(시에라리온)");
    b.put("SG", "SINGAPORE(싱가포르)");
    b.put("SK", "SLOVAKIA(슬로바키아)");
    b.put("SI", "SLOVENIA(슬로베니아)");
    b.put("SB", "SOLOMON ISLANDS(솔로몬 군도)");
    b.put("SO", "SOMALIA(소말리아)");
    b.put("ZA", "SOUTH AFRICA(남아프리카)");
    b.put("ES", "SPAIN(스페인)");
    b.put("LK", "SRI LANKA(스리랑카)");
    b.put("SD", "SUDAN(수단)");
    b.put("SR", "SURINAME(수리남)");
    b.put("SJ", "SVALBARD AND JAN MAYEN ISLANDS(스발바르드 얀마이엔 제도)");
    b.put("SZ", "SWAZILAND(스와질랜드)");
    b.put("SE", "SWEDEN(스웨덴)");
    b.put("CH", "SWITZERLAND(스위스)");
    b.put("SY", "SYRIAN ARAB REPUBLIC(시리아)");
    b.put("TW", "TAIWAN, PROVINCE OF CHINA(대만)");
    b.put("TJ", "TAJIKISTAN(타지키스탄)");
    b.put("TZ", "TANZANIA, UNITED REPUBLIC OF(탄자니아)");
    b.put("TH", "THAILAND(태국)");
    b.put("TG", "TOGO(토고)");
    b.put("TK", "TOKELAU(토켈라우)");
    b.put("TO", "TONGA(통가)");
    b.put("TT", "TRINIDAD AND TOBAGO(트리니다드 토바고)");
    b.put("TN", "TUNISIA(튀니지)");
    b.put("TR", "TURKEY(터어키)");
    b.put("TM", "TURKMENISTAN(투르크메니스탄)");
    b.put("TC", "TURKS AND CAICOS ISLANDS(터크스 카이코스 제도)");
    b.put("TV", "TUVALU(투발루)");
    b.put("UG", "UGANDA(우간다)");
    b.put("UA", "UKRAINE(우크라이나)");
    b.put("AE", "UNITED ARAB EMIRATES(아랍에미리트)");
    b.put("GB", "UNITED KINGDOM(영국)");
    b.put("US", "UNITED STATES(미국)");
    b.put("UM", "UNITED STATES MINOR OUTLYING ISLANDS(미국령 소군도)");
    b.put("UY", "URUGUAY(우루과이)");
    b.put("SU", "USSR(구소련)");
    b.put("UZ", "UZBEKISTAN(우즈베키스탄)");
    b.put("VU", "VANUATU(바누아투)");
    b.put("VA", "VATICAN CITY STATE (HOLY SEE)-바티칸");
    b.put("VE", "VENEZUELA(베네수엘라)");
    b.put("VN", "VIET NAM(베트남)");
    b.put("VG", "VIRGIN ISLANDS (BRITISH)-영국령 버진아일랜드");
    b.put("VI", "VIRGIN ISLANDS (U.S.)-미국령 버진아일랜드");
    b.put("WF", "WALLIS AND FUTUNA ISLANDS(월리스 후트나)");
    b.put("EH", "WESTERN SAHARA(사하라)");
    b.put("YE", "YEMEN, REPUBLIC OF(예멘)");
    b.put("YU", "YUGOSLAVIA(유고슬라비아)");
    b.put("ZR", "ZAIRE(자이르)");
    b.put("ZM", "ZAMBIA(잠비아)");
    b.put("ZW", "ZIMBABWE(짐바브웨)");
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\AOTP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */