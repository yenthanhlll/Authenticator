package com.dreammirae.aotp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Tool {
  private static SecureRandom a;
  
  private static final char[] b = "0123456789ABCDEF".toCharArray();
  
  public static final TimeZone DFT_TIME_ZONE = TimeZone.getTimeZone("Asia/Seoul");
  
  static {
    try {
      a = SecureRandom.getInstance("SHA1PRNG");
      return;
    } catch (NoSuchAlgorithmException noSuchAlgorithmException2) {
      NoSuchAlgorithmException noSuchAlgorithmException1;
      (noSuchAlgorithmException1 = null).printStackTrace();
      return;
    } 
  }
  
  public static int randomInt(int paramInt) {
    if (a == null)
      throw new RuntimeException("SecureRandom not instantiated!"); 
    return a.nextInt(paramInt) + 1;
  }
  
  public static byte[] randomBytes(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException("len must > 0"); 
    byte[] arrayOfByte = new byte[paramInt];
    if (a == null)
      throw new RuntimeException("SecureRandom not instantiated!"); 
    a.nextBytes(arrayOfByte);
    return arrayOfByte;
  }
  
  public static TimeZone defaultTimeZone() {
    return DFT_TIME_ZONE;
  }
  
  public static long byteArrayToLong(byte[] paramArrayOfbyte) {
    return byteArrayToLong(paramArrayOfbyte, 0);
  }
  
  public static long byteArrayToLong(byte[] paramArrayOfbyte, int paramInt) {
    long l = 0L;
    for (byte b = 0; b < 8; b++) {
      int i = 7 - b << 3;
      l += (paramArrayOfbyte[b + paramInt] & 0xFF) << i;
    } 
    return l;
  }
  
  public static Date str2Date(String paramString) throws ParseException {
    return str2Date(paramString, "yyyyMMdd", DFT_TIME_ZONE);
  }
  
  public static Date str2Date(String paramString1, String paramString2, TimeZone paramTimeZone) throws ParseException {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString2);
    try {
      simpleDateFormat.setTimeZone(paramTimeZone);
      Date date = simpleDateFormat.parse(paramString1);
    } catch (ParseException parseException) {
      throw paramString1 = null;
    } 
    return (Date)paramString1;
  }
  
  public static String date2Str(Date paramDate) {
    return date2Str(paramDate, "yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("Asia/Seoul"));
  }
  
  public static String date2Str(Date paramDate, String paramString, TimeZone paramTimeZone) {
    String str;
    if (paramDate == null || paramString == null || paramTimeZone == null)
      return null; 
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString);
    try {
      simpleDateFormat.setTimeZone(paramTimeZone);
      str = simpleDateFormat.format(paramDate);
    } catch (Exception exception) {
      return null;
    } 
    return str;
  }
  
  public static byte[] toBytesFromShort(short paramShort) {
    ByteBuffer byteBuffer;
    (byteBuffer = ByteBuffer.allocate(2)).putShort(paramShort);
    return byteBuffer.array();
  }
  
  public static String onlyNum(String paramString) {
    return (paramString == null) ? null : paramString.replaceAll("[^0-9]", "");
  }
  
  public static void String2file(String paramString1, String paramString2) {
    try {
      BufferedWriter bufferedWriter;
      (bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(paramString1), "UTF-8"))).write(paramString2);
      bufferedWriter.close();
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  public static byte[] readFile(String paramString) {
    FileInputStream fileInputStream = null;
    try {
      int i;
      byte[] arrayOfByte = new byte[i = (fileInputStream = new FileInputStream(new File(paramString))).available()];
      fileInputStream.read(arrayOfByte);
      fileInputStream.close();
    } catch (IOException iOException) {
      return null;
    } finally {
      try {
        fileInputStream.close();
      } catch (Exception exception) {}
    } 
    return (byte[])paramString;
  }
  
  public static boolean isNumber(String paramString) {
    if (paramString == null)
      return false; 
    try {
      Long.parseLong(paramString);
      return true;
    } catch (NumberFormatException numberFormatException) {
      return false;
    } 
  }
  
  public static boolean isHex(String paramString) {
    if (paramString == null)
      return false; 
    try {
      toBytesFromString(paramString);
      return true;
    } catch (IllegalArgumentException illegalArgumentException) {
      return false;
    } 
  }
  
  public static boolean isNullorEmpty(String paramString) {
    return (paramString == null) ? true : ("".equals(paramString.trim()));
  }
  
  public static byte[] hash(String paramString, byte[] paramArrayOfbyte) throws NoSuchAlgorithmException {
    MessageDigest messageDigest;
    (messageDigest = MessageDigest.getInstance(paramString)).update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    byte[] arrayOfByte;
    return arrayOfByte = messageDigest.digest();
  }
  
  public static byte[] AES(String paramString, byte[] paramArrayOfbyte, int paramInt) throws Exception {
    if (paramArrayOfbyte == null)
      return null; 
    if (paramInt != 1 && paramInt != 2)
      return null; 
    byte[] arrayOfByte2 = new byte[16];
    byte[] arrayOfByte3 = new byte[16];
    byte[] arrayOfByte4 = new byte[4];
    byte[] arrayOfByte1;
    System.arraycopy(arrayOfByte1 = hash("SHA-1", paramString.getBytes()), 0, arrayOfByte2, 0, 16);
    System.arraycopy(arrayOfByte1, 16, arrayOfByte4, 0, 4);
    System.arraycopy(arrayOfByte1 = hash("SHA-1", arrayOfByte4), 0, arrayOfByte3, 0, 16);
    return AES(arrayOfByte2, arrayOfByte3, paramArrayOfbyte, paramInt);
  }
  
  public static byte[] AES(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, int paramInt) throws Exception {
    byte[] arrayOfByte2 = paramArrayOfbyte1;
    String str1 = "AES";
    SecretKeySpec secretKeySpec = new SecretKeySpec(arrayOfByte2, str1);
    SecretKeySpec secretKeySpec = secretKeySpec;
    IvParameterSpec ivParameterSpec = new IvParameterSpec(paramArrayOfbyte2);
    String str2;
    Cipher cipher;
    (cipher = Cipher.getInstance(str2 = "AES/CBC/PKCS5Padding")).init(paramInt, secretKeySpec, ivParameterSpec);
    byte[] arrayOfByte1;
    return arrayOfByte1 = cipher.doFinal(paramArrayOfbyte3);
  }
  
  public static byte[] hexToByteArray(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return null; 
    byte[] arrayOfByte = new byte[paramString.length() / 2];
    for (byte b = 0; b < arrayOfByte.length; b++)
      arrayOfByte[b] = (byte)Integer.parseInt(paramString.substring(2 * b, 2 * b + 2), 16); 
    return arrayOfByte;
  }
  
  public static String toString(byte[] paramArrayOfbyte) {
    return (paramArrayOfbyte == null) ? null : toString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static final String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (paramArrayOfbyte == null)
      return null; 
    char[] arrayOfChar = new char[paramInt2 << 1];
    byte b1 = 0;
    byte b2 = 0;
    while (b1 < paramInt2) {
      byte b = paramArrayOfbyte[paramInt1 + b1++];
      arrayOfChar[b2++] = b[b >>> 4 & 0xF];
      arrayOfChar[b2++] = b[b & 0xF];
    } 
    return new String(arrayOfChar);
  }
  
  public static String toReversedString(byte[] paramArrayOfbyte) {
    return toReversedString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static final String toReversedString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    char[] arrayOfChar = new char[paramInt2 << 1];
    paramInt2 = paramInt1 + paramInt2 - 1;
    byte b = 0;
    while (paramInt2 >= paramInt1) {
      byte b1 = paramArrayOfbyte[paramInt1 + paramInt2--];
      arrayOfChar[b++] = b[b1 >>> 4 & 0xF];
      arrayOfChar[b++] = b[b1 & 0xF];
    } 
    return new String(arrayOfChar);
  }
  
  public static byte[] toBytesFromString(String paramString) {
    int i;
    byte[] arrayOfByte = new byte[((i = paramString.length()) + 1) / 2];
    byte b1 = 0;
    byte b2 = 0;
    if (i % 2 == 1) {
      b2++;
      b1++;
      arrayOfByte[0] = (byte)fromDigit(paramString.charAt(0));
    } 
    while (b1 < i) {
      arrayOfByte[b2] = (byte)(fromDigit(paramString.charAt(b1++)) << 4);
      arrayOfByte[b2++] = (byte)(arrayOfByte[b2++] | (byte)fromDigit(paramString.charAt(b1++)));
    } 
    return arrayOfByte;
  }
  
  public static byte[] toReversedBytesFromString(String paramString) {
    int i;
    byte[] arrayOfByte = new byte[((i = paramString.length()) + 1) / 2];
    byte b = 0;
    if (i % 2 == 1) {
      b++;
      arrayOfByte[0] = (byte)fromDigit(paramString.charAt(--i));
    } 
    while (i > 0) {
      arrayOfByte[b] = (byte)fromDigit(paramString.charAt(--i));
      arrayOfByte[b++] = (byte)(arrayOfByte[b++] | (byte)(fromDigit(paramString.charAt(--i)) << 4));
    } 
    return arrayOfByte;
  }
  
  public static int fromDigit(char paramChar) {
    if (paramChar >= '0' && paramChar <= '9')
      return paramChar - 48; 
    if (paramChar >= 'A' && paramChar <= 'F')
      return paramChar - 65 + 10; 
    if (paramChar >= 'a' && paramChar <= 'f')
      return paramChar - 97 + 10; 
    throw new IllegalArgumentException("Invalid hexadecimal digit: ".concat(String.valueOf(paramChar)));
  }
  
  public static int stringToInt(String paramString, int paramInt) {
    try {
      return Integer.parseInt(paramString.trim());
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  public static String toString(int paramInt) {
    char[] arrayOfChar = new char[8];
    for (byte b = 7; b >= 0; b--) {
      arrayOfChar[b] = b[paramInt & 0xF];
      paramInt >>>= 4;
    } 
    return new String(arrayOfChar);
  }
  
  public static String toString(int[] paramArrayOfint) {
    int i;
    char[] arrayOfChar = new char[(i = paramArrayOfint.length) << 3];
    byte b1 = 0;
    byte b2 = 0;
    while (b1 < i) {
      int j = paramArrayOfint[b1];
      arrayOfChar[b2++] = b[j >>> 28 & 0xF];
      arrayOfChar[b2++] = b[j >>> 24 & 0xF];
      arrayOfChar[b2++] = b[j >>> 20 & 0xF];
      arrayOfChar[b2++] = b[j >>> 16 & 0xF];
      arrayOfChar[b2++] = b[j >>> 12 & 0xF];
      arrayOfChar[b2++] = b[j >>> 8 & 0xF];
      arrayOfChar[b2++] = b[j >>> 4 & 0xF];
      arrayOfChar[b2++] = b[j & 0xF];
      b1++;
    } 
    return new String(arrayOfChar);
  }
  
  public static String toString(long paramLong) {
    char[] arrayOfChar = new char[16];
    for (byte b = 15; b >= 0; b--) {
      arrayOfChar[b] = b[(int)(paramLong & 0xFL)];
      paramLong >>>= 4L;
    } 
    return new String(arrayOfChar);
  }
  
  public static String toUnicodeString(byte[] paramArrayOfbyte) {
    return toUnicodeString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public static final String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b1 = 0;
    byte b2 = 0;
    stringBuffer.append('\n').append("\"");
    while (b1 < paramInt2) {
      stringBuffer.append("\\u");
      byte b = paramArrayOfbyte[paramInt1 + b1++];
      stringBuffer.append(b[b >>> 4 & 0xF]);
      stringBuffer.append(b[b & 0xF]);
      b = paramArrayOfbyte[paramInt1 + b1++];
      stringBuffer.append(b[b >>> 4 & 0xF]);
      stringBuffer.append(b[b & 0xF]);
      if (++b2 % 8 == 0)
        stringBuffer.append("\"+\n").append("\""); 
    } 
    stringBuffer.append("\"\n");
    return stringBuffer.toString();
  }
  
  public static String toUnicodeString(int[] paramArrayOfint) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b1 = 0;
    byte b2 = 0;
    stringBuffer.append('\n').append("\"");
    while (b1 < paramArrayOfint.length) {
      int i = paramArrayOfint[b1++];
      stringBuffer.append("\\u");
      stringBuffer.append(b[i >>> 28 & 0xF]);
      stringBuffer.append(b[i >>> 24 & 0xF]);
      stringBuffer.append(b[i >>> 20 & 0xF]);
      stringBuffer.append(b[i >>> 16 & 0xF]);
      stringBuffer.append("\\u");
      stringBuffer.append(b[i >>> 12 & 0xF]);
      stringBuffer.append(b[i >>> 8 & 0xF]);
      stringBuffer.append(b[i >>> 4 & 0xF]);
      stringBuffer.append(b[i & 0xF]);
      if (++b2 % 4 == 0)
        stringBuffer.append("\"+\n").append("\""); 
    } 
    stringBuffer.append("\"\n");
    return stringBuffer.toString();
  }
  
  public static byte[] toBytesFromUnicode(String paramString) {
    int i;
    byte[] arrayOfByte = new byte[i = paramString.length() << 1];
    for (byte b = 0; b < i; b++) {
      char c = paramString.charAt(b >>> 1);
      arrayOfByte[b] = (byte)(((b & 0x1) == 0) ? (c >>> 8) : c);
    } 
    return arrayOfByte;
  }
  
  public static String dumpString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, String paramString) {
    if (paramArrayOfbyte == null)
      return String.valueOf(paramString) + "null\n"; 
    StringBuffer stringBuffer = new StringBuffer(paramInt2 * 3);
    if (paramInt2 > 32)
      stringBuffer.append(paramString).append("Hexadecimal dump of ").append(paramInt2).append(" bytes...\n"); 
    int i = paramInt1 + paramInt2;
    int j;
    if ((j = Integer.toString(paramInt2).length()) < 4)
      j = 4; 
    while (paramInt1 < i) {
      if (paramInt2 > 32) {
        String str = "         ".concat(String.valueOf(paramInt1));
        stringBuffer.append(paramString).append(str.substring(str.length() - j)).append(": ");
      } 
      byte b;
      for (b = 0; b < 32 && paramInt1 + b + 7 < i; b += 8)
        stringBuffer.append(toString(paramArrayOfbyte, paramInt1 + b, 8)).append(' '); 
      if (b < 32)
        while (b < 32 && paramInt1 + b < i) {
          stringBuffer.append(byteToString(paramArrayOfbyte[paramInt1 + b]));
          b++;
        }  
      stringBuffer.append('\n');
      paramInt1 += 32;
    } 
    return stringBuffer.toString();
  }
  
  public static String dumpString(byte[] paramArrayOfbyte) {
    return (paramArrayOfbyte == null) ? "null\n" : dumpString(paramArrayOfbyte, 0, paramArrayOfbyte.length, "");
  }
  
  public static String dumpString(byte[] paramArrayOfbyte, String paramString) {
    return (paramArrayOfbyte == null) ? "null\n" : dumpString(paramArrayOfbyte, 0, paramArrayOfbyte.length, paramString);
  }
  
  public static String dumpString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return dumpString(paramArrayOfbyte, paramInt1, paramInt2, "");
  }
  
  public static String byteToString(int paramInt) {
    char[] arrayOfChar = { b[paramInt >>> 4 & 0xF], b[paramInt & 0xF] };
    return new String(arrayOfChar);
  }
  
  public static final byte[] trim(BigInteger paramBigInteger) {
    byte[] arrayOfByte1;
    if ((arrayOfByte1 = paramBigInteger.toByteArray()).length == 0 || arrayOfByte1[0] != 0)
      return arrayOfByte1; 
    int i = arrayOfByte1.length;
    byte b;
    for (b = 1; arrayOfByte1[b] == 0 && b < i; b++);
    byte[] arrayOfByte2 = new byte[i - b];
    System.arraycopy(arrayOfByte1, b, arrayOfByte2, 0, i - b);
    return arrayOfByte2;
  }
  
  public static final String dump(BigInteger paramBigInteger) {
    return dumpString(trim(paramBigInteger));
  }
  
  public static byte[] toBytesFromLong(long paramLong) {
    byte[] arrayOfByte;
    (arrayOfByte = new byte[8])[7] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[6] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[5] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[4] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[3] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[2] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[1] = (byte)(int)paramLong;
    paramLong >>>= 8L;
    arrayOfByte[0] = (byte)(int)paramLong;
    return arrayOfByte;
  }
  
  public static byte[] toBytesFromInt(int paramInt) {
    return new byte[] { (byte)(paramInt >>> 24), (byte)(paramInt >> 16), (byte)(paramInt >> 8), (byte)paramInt };
  }
  
  public static int byteArrayToInt(byte[] paramArrayOfbyte) {
    return byteArrayToInt(paramArrayOfbyte, 0);
  }
  
  public static int byteArrayToInt(byte[] paramArrayOfbyte, int paramInt) {
    int i = 0;
    for (byte b = 0; b < 4; b++) {
      int j = 3 - b << 3;
      i += (paramArrayOfbyte[b + paramInt] & 0xFF) << j;
    } 
    return i;
  }
  
  public static boolean isExpired(Date paramDate) {
    return (paramDate == null) ? true : ((paramDate.compareTo(new Date()) < 0));
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\Tool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */