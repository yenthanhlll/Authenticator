package com.dreammirae.aotp.keyfile;

public class InvalidTokenFormatException extends Exception {
  public InvalidTokenFormatException() {}
  
  public InvalidTokenFormatException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\InvalidTokenFormatException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */