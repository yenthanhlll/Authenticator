package com.dreammirae.aotp.keyfile;

import com.dreammirae.aotp.Tool;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class a {
  private byte[] a = new byte[20];
  
  private byte[] b;
  
  private String c = "";
  
  private byte[] d = new byte[20];
  
  protected final void a(byte[] paramArrayOfbyte) {
    this.d = paramArrayOfbyte;
  }
  
  public final byte[] a() {
    return this.a;
  }
  
  protected final void b(byte[] paramArrayOfbyte) {
    this.a = paramArrayOfbyte;
  }
  
  public final String b() {
    return this.c;
  }
  
  protected final void a(String paramString) {
    if (paramString == null)
      return; 
    this.c = paramString;
  }
  
  public final void c(byte[] paramArrayOfbyte) {
    this.b = paramArrayOfbyte;
  }
  
  public final String toString() {
    StringBuffer stringBuffer;
    (stringBuffer = new StringBuffer()).append(this.c).append(",").append(Tool.toString(this.a)).append(",");
    if (this.b != null)
      stringBuffer.append(Tool.toString(this.b)); 
    stringBuffer.append(",").append(Tool.toString(this.d)).append(b.a);
    return stringBuffer.toString();
  }
  
  public static e a(String paramString1, String paramString2) throws Exception {
    c c;
    return (c = b(paramString1, paramString2)).a();
  }
  
  private static c b(String paramString1, String paramString2) throws FileNotFoundException, InvalidTokenFormatException {
    File file = new File(paramString1);
    BufferedInputStream bufferedInputStream = null;
    if (!file.exists())
      throw new FileNotFoundException(paramString1); 
    try {
      String str1;
      if ((str1 = a(bufferedInputStream = new BufferedInputStream(new FileInputStream(file)))) == null || str1.length() != 6)
        throw new InvalidTokenFormatException(); 
      String str2 = str1.substring(0, 4);
      str1 = str1.substring(4, 6);
      if (!"_STR".equals(str2))
        throw new InvalidTokenFormatException(); 
      if ("24".equals(str1))
        return new f(paramString1, paramString2, str1); 
    } catch (Throwable throwable) {
      throw new InvalidTokenFormatException(throwable);
    } finally {
      try {
        if (bufferedInputStream != null)
          bufferedInputStream.close(); 
      } catch (IOException iOException) {}
    } 
    throw new InvalidTokenFormatException();
  }
  
  private static String a(BufferedInputStream paramBufferedInputStream) throws Exception {
    byte[] arrayOfByte = new byte[6];
    String str = null;
    try {
      paramBufferedInputStream.mark(6);
      int i;
      if ((i = paramBufferedInputStream.read(arrayOfByte)) == 6)
        str = new String(arrayOfByte); 
      paramBufferedInputStream.reset();
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
      throw exception1;
    } 
    return str;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */