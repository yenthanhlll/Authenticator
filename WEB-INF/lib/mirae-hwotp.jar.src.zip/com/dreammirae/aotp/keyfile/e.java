package com.dreammirae.aotp.keyfile;

public final class e {
  private Header a = null;
  
  private a[] b = null;
  
  public final a[] a() {
    return this.b;
  }
  
  protected final void a(a[] paramArrayOfa) {
    this.b = paramArrayOfa;
  }
  
  public final Header b() {
    return this.a;
  }
  
  protected final void a(Header paramHeader) {
    this.a = paramHeader;
  }
  
  public final String toString() {
    StringBuffer stringBuffer;
    (stringBuffer = new StringBuffer()).append("-----------------------------").append(b.a).append("#HEADER INFO").append(b.a).append("-----------------------------").append(b.a).append(this.a.toString()).append(b.a).append("-----------------------------").append(b.a).append("#BODY INFO").append(b.a).append("-----------------------------").append(b.a);
    for (byte b = 0; b < this.b.length; b++)
      stringBuffer.append(this.b[b].toString()); 
    stringBuffer.append("-----------------------------").append(b.a);
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */