package com.dreammirae.aotp.keyfile;

public interface c {
  e a() throws Exception;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */