package com.dreammirae.aotp.keyfile;

public class InvalidCheckSumException extends Exception {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\InvalidCheckSumException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */