package com.dreammirae.aotp.keyfile;

public final class b {
  public static final String a = System.getProperty("line.separator");
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */