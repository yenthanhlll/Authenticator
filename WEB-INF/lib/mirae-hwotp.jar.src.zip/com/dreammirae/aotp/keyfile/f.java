package com.dreammirae.aotp.keyfile;

import com.dreammirae.aotp.Tool;
import com.dreammirae.aotp.a.a;
import com.dreammirae.aotp.b.a;
import com.dreammirae.aotp.seed.a;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;

public final class f implements c {
  private e a = null;
  
  private String b = null;
  
  private String c = null;
  
  private String d = null;
  
  private a e = new a();
  
  protected f(String paramString1, String paramString2, String paramString3) {
    this.a = new e();
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramString3;
  }
  
  public final e a() throws Exception {
    null = new File(this.b);
    Header header = new Header();
    BufferedInputStream bufferedInputStream = null;
    byte[] arrayOfByte1 = new byte[16];
    byte[] arrayOfByte2 = new byte[180];
    byte[] arrayOfByte3 = new byte[5];
    byte[] arrayOfByte4 = new byte[5];
    byte[] arrayOfByte5 = new byte[2];
    byte[] arrayOfByte6 = new byte[2];
    byte[] arrayOfByte7 = new byte[10];
    byte[] arrayOfByte8 = new byte[10];
    byte[] arrayOfByte9 = new byte[8];
    byte[] arrayOfByte10 = new byte[8];
    byte[] arrayOfByte11 = new byte[2];
    byte[] arrayOfByte12 = new byte[1];
    byte[] arrayOfByte13 = new byte[1];
    byte[] arrayOfByte14 = new byte[1];
    byte[] arrayOfByte15 = new byte[80];
    byte[] arrayOfByte16 = new byte[1];
    byte[] arrayOfByte17 = new byte[1];
    byte[] arrayOfByte18 = new byte[1];
    byte[] arrayOfByte19 = new byte[36];
    byte[] arrayOfByte20 = new byte[20];
    try {
      bufferedInputStream = new BufferedInputStream(new FileInputStream(null));
      byte[] arrayOfByte22 = new byte[200];
      int j;
      if ((j = bufferedInputStream.read(arrayOfByte22)) != 200)
        throw new InvalidTokenFormatException(); 
      System.arraycopy(arrayOfByte22, 6, arrayOfByte3, 0, 5);
      System.arraycopy(arrayOfByte22, 11, arrayOfByte4, 0, 5);
      System.arraycopy(arrayOfByte22, 16, arrayOfByte5, 0, 2);
      System.arraycopy(arrayOfByte22, 18, arrayOfByte6, 0, 2);
      System.arraycopy(arrayOfByte22, 20, arrayOfByte7, 0, 10);
      System.arraycopy(arrayOfByte22, 30, arrayOfByte8, 0, 10);
      System.arraycopy(arrayOfByte22, 40, arrayOfByte9, 0, 8);
      System.arraycopy(arrayOfByte22, 48, arrayOfByte10, 0, 8);
      System.arraycopy(arrayOfByte22, 56, arrayOfByte11, 0, 2);
      System.arraycopy(arrayOfByte22, 58, arrayOfByte12, 0, 1);
      System.arraycopy(arrayOfByte22, 59, arrayOfByte13, 0, 1);
      System.arraycopy(arrayOfByte22, 60, arrayOfByte14, 0, 1);
      System.arraycopy(arrayOfByte22, 61, arrayOfByte15, 0, 80);
      System.arraycopy(arrayOfByte22, 141, arrayOfByte16, 0, 1);
      System.arraycopy(arrayOfByte22, 142, arrayOfByte17, 0, 1);
      System.arraycopy(arrayOfByte22, 143, arrayOfByte18, 0, 1);
      System.arraycopy(arrayOfByte22, 144, arrayOfByte19, 0, 36);
      System.arraycopy(arrayOfByte22, 180, arrayOfByte20, 0, 20);
      byte[] arrayOfByte21;
      System.arraycopy(arrayOfByte21 = a.a(this.c.getBytes()), 0, arrayOfByte1, 0, 16);
      System.arraycopy(arrayOfByte22, 0, arrayOfByte2, 0, 180);
      if (!Arrays.equals(arrayOfByte21 = a.a("HmacSHA1", arrayOfByte1, arrayOfByte2), arrayOfByte20))
        throw new InvalidPinException(); 
      header.o(this.d);
      header.i(new String(arrayOfByte3));
      header.f(new String(arrayOfByte4));
      header.k(new String(arrayOfByte5));
      header.h(new String(arrayOfByte6));
      header.l(new String(arrayOfByte7));
      header.d(new String(arrayOfByte8));
      header.c(new String(arrayOfByte9));
      header.e(new String(arrayOfByte10));
      header.m(new String(arrayOfByte11));
      header.j(new String(arrayOfByte12));
      header.a(new String(arrayOfByte13));
      header.n(new String(arrayOfByte14));
      header.b(new String(arrayOfByte15, "ms949"));
      header.p(new String(arrayOfByte16));
      header.q(new String(arrayOfByte17));
      header.r(new String(arrayOfByte18));
      header.g(new String(arrayOfByte19));
      header.a(arrayOfByte20);
      this.a.a(header);
      int i;
      a[] arrayOfA = new a[i = Integer.parseInt(header.c()) - Integer.parseInt(header.f()) + 1];
      for (byte b = 0; b < i; b++) {
        arrayOfByte4 = new byte[100];
        arrayOfByte5 = new byte[4];
        arrayOfByte6 = new byte[32];
        arrayOfByte7 = new byte[32];
        arrayOfByte8 = new byte[12];
        arrayOfByte9 = new byte[20];
        arrayOfByte10 = new byte[80];
        int k;
        if ((k = bufferedInputStream.read(arrayOfByte4)) != 100)
          throw new InvalidTokenFormatException(); 
        System.arraycopy(arrayOfByte4, 0, arrayOfByte10, 0, 80);
        System.arraycopy(arrayOfByte4, 80, arrayOfByte9, 0, 20);
        byte[] arrayOfByte;
        if (!Arrays.equals(arrayOfByte = a.a("hmacSHA1", arrayOfByte1, arrayOfByte10), arrayOfByte9))
          throw new InvalidCheckSumException(); 
        System.arraycopy(arrayOfByte4, 0, arrayOfByte5, 0, 4);
        System.arraycopy(arrayOfByte4, 4, arrayOfByte6, 0, 32);
        System.arraycopy(arrayOfByte4, 36, arrayOfByte7, 0, 32);
        System.arraycopy(arrayOfByte4, 68, arrayOfByte8, 0, 12);
        arrayOfByte = new byte[20];
        a.a(arrayOfByte1, arrayOfByte, arrayOfByte6);
        arrayOfByte4 = new byte[20];
        a.a(arrayOfByte1, arrayOfByte4, arrayOfByte7);
        arrayOfA[b] = new a();
        arrayOfA[b].a(Integer.toString(Tool.byteArrayToInt(arrayOfByte5)));
        arrayOfA[b].b(arrayOfByte);
        arrayOfA[b].c(arrayOfByte4);
        arrayOfA[b].a(arrayOfByte9);
      } 
      this.a.a(arrayOfA);
      null.getName();
    } finally {
      if (bufferedInputStream != null)
        bufferedInputStream.close(); 
    } 
    return this.a;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */