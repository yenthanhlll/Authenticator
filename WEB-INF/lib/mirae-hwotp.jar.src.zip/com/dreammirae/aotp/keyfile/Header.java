package com.dreammirae.aotp.keyfile;

import com.dreammirae.aotp.Tool;
import java.io.Serializable;

public final class Header implements Serializable {
  private String a = "_STR";
  
  private String b = "";
  
  private String c = "";
  
  private String d = "";
  
  private String e = "";
  
  private String f = "";
  
  private String g = "";
  
  private String h = "";
  
  private String i = "";
  
  private String j = "";
  
  private String k = "";
  
  private String l = "";
  
  private String m = "";
  
  private String n = "";
  
  private String o = "0";
  
  private String p = "";
  
  private String q = "";
  
  private String r = "";
  
  private String s = "";
  
  private byte[] t = new byte[20];
  
  public final String a() {
    return this.m;
  }
  
  protected final void a(String paramString) {
    this.m = paramString;
  }
  
  protected final void a(byte[] paramArrayOfbyte) {
    this.t = paramArrayOfbyte;
  }
  
  protected final void b(String paramString) {
    this.p = paramString;
  }
  
  public final String b() {
    return this.i;
  }
  
  protected final void c(String paramString) {
    this.i = paramString;
  }
  
  public final String c() {
    return this.h;
  }
  
  protected final void d(String paramString) {
    this.h = paramString;
  }
  
  public final String d() {
    return this.j;
  }
  
  protected final void e(String paramString) {
    this.j = paramString;
  }
  
  protected final void f(String paramString) {
    this.d = paramString;
  }
  
  protected final void g(String paramString) {
    this.s = paramString;
  }
  
  public final String e() {
    return this.f;
  }
  
  protected final void h(String paramString) {
    this.f = paramString;
  }
  
  protected final void i(String paramString) {
    this.c = paramString;
  }
  
  protected final void j(String paramString) {
    this.l = paramString;
  }
  
  protected final void k(String paramString) {
    this.e = paramString;
  }
  
  public final String f() {
    return this.g;
  }
  
  protected final void l(String paramString) {
    this.g = paramString;
  }
  
  public final String g() {
    return this.k;
  }
  
  protected final void m(String paramString) {
    this.k = paramString;
  }
  
  protected final void n(String paramString) {
    this.n = paramString;
  }
  
  protected final void o(String paramString) {
    this.b = paramString;
  }
  
  protected final void p(String paramString) {
    if ("1".equals(paramString) || "2".equals(paramString)) {
      this.o = paramString;
      return;
    } 
    this.o = "0";
  }
  
  public final void q(String paramString) {
    this.q = paramString;
  }
  
  public final String h() {
    return this.r;
  }
  
  public final void r(String paramString) {
    this.r = paramString;
  }
  
  public final String toString() {
    StringBuffer stringBuffer;
    (stringBuffer = new StringBuffer()).append("signature=[").append(this.a).append("]").append(b.a).append("ver=[").append(this.b).append("]").append(b.a).append("orgcode=[").append(this.c).append("]").append(b.a).append("extOrgCode=[").append(this.d).append("]").append(b.a).append("snLength=[").append(this.e).append("]").append(b.a).append("maxPinFail=[").append(this.f).append("]").append(b.a).append("startSn=[").append(this.g).append("]").append(b.a).append("endSn=[").append(this.h).append("]").append(b.a).append("crDate=[").append(this.i).append("]").append(b.a).append("exDate=[").append(this.j).append("]").append(b.a).append("tokenType=[").append(this.k).append("]").append(b.a).append("pinType=[").append(this.l).append("]").append(b.a).append("algType=[").append(this.m).append("]").append(b.a).append("useType=[").append(this.n).append("]").append(b.a).append("comment=[").append(this.p).append("]").append(b.a).append("cycle=[").append(this.o).append("]").append(b.a).append("deviceExpire=[").append(this.q).append("]").append(b.a).append("challengeLength=[").append(this.r).append("]").append(b.a).append("filler=[").append(this.s).append("]").append(b.a).append("chksum=[").append(Tool.toString(this.t)).append("]");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\keyfile\Header.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */