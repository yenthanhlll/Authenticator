package com.dreammirae.aotp.a;

import com.dreammirae.aotp.Tool;
import java.security.NoSuchAlgorithmException;

public final class b {
  private String a;
  
  public b(String paramString) throws NoSuchAlgorithmException {
    if ("SHA-224".equalsIgnoreCase(paramString.toUpperCase())) {
      this.a = paramString;
      return;
    } 
    if ("SHA-256".equalsIgnoreCase(paramString.toUpperCase())) {
      this.a = paramString;
      return;
    } 
    if ("SHA-384".equalsIgnoreCase(paramString.toUpperCase())) {
      this.a = paramString;
      return;
    } 
    if ("SHA-512".equalsIgnoreCase(paramString.toUpperCase())) {
      this.a = paramString;
      return;
    } 
    throw new NoSuchAlgorithmException("algorithm must be one of SHA-256, SHA-384, or SHA-512");
  }
  
  public final byte[] a(byte[] paramArrayOfbyte) {
    if (this.a == "SHA-224") {
      paramArrayOfbyte = paramArrayOfbyte;
      byte[] arrayOfByte3 = new byte[28];
      byte[] arrayOfByte4 = new byte[64];
      paramArrayOfbyte = b(paramArrayOfbyte);
      int[] arrayOfInt1 = { 
          1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 
          607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 
          770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 
          113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, 
          -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 
          659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, 
          -1866530822, -1538233109, -1090935817, -965641998 };
      int[] arrayOfInt2 = { -1056596264, 914150663, 812702999, -150054599, -4191439, 1750603025, 1694076839, -1090891868 };
      byte b2;
      for (b2 = 0; b2 < paramArrayOfbyte.length / 64; b2++) {
        int[] arrayOfInt = new int[64];
        int i = arrayOfInt2[0];
        int j = arrayOfInt2[1];
        int k = arrayOfInt2[2];
        int m = arrayOfInt2[3];
        int n = arrayOfInt2[4];
        int i1 = arrayOfInt2[5];
        int i2 = arrayOfInt2[6];
        int i3 = arrayOfInt2[7];
        System.arraycopy(paramArrayOfbyte, b2 * 64, arrayOfByte4, 0, 64);
        byte b3;
        for (b3 = 0; b3 < 16; b3++) {
          arrayOfInt[b3] = 0;
          for (byte b4 = 0; b4 < 4; b4++)
            arrayOfInt[b3] = arrayOfInt[b3] | (arrayOfByte4[(b3 << 2) + b4] & 0xFF) << 24 - (b4 << 3); 
        } 
        for (b3 = 16; b3 < 64; b3++) {
          int i4 = Integer.rotateRight(arrayOfInt[b3 - 15], 7) ^ Integer.rotateRight(arrayOfInt[b3 - 15], 18) ^ arrayOfInt[b3 - 15] >>> 3;
          int i5 = Integer.rotateRight(arrayOfInt[b3 - 2], 17) ^ Integer.rotateRight(arrayOfInt[b3 - 2], 19) ^ arrayOfInt[b3 - 2] >>> 10;
          arrayOfInt[b3] = arrayOfInt[b3 - 16] + i4 + arrayOfInt[b3 - 7] + i5;
        } 
        for (b3 = 0; b3 < 64; b3++) {
          int i4 = Integer.rotateRight(i, 2) ^ Integer.rotateRight(i, 13) ^ Integer.rotateRight(i, 22);
          int i6 = i & j ^ i & k ^ j & k;
          int i8 = i4 + i6;
          int i5 = Integer.rotateRight(n, 6) ^ Integer.rotateRight(n, 11) ^ Integer.rotateRight(n, 25);
          int i9 = n & i1 ^ (n ^ 0xFFFFFFFF) & i2;
          int i7 = i3 + i5 + i9 + arrayOfInt1[b3] + arrayOfInt[b3];
          i3 = i2;
          i2 = i1;
          i1 = n;
          n = m + i7;
          m = k;
          k = j;
          j = i;
          i = i7 + i8;
        } 
        arrayOfInt2[0] = arrayOfInt2[0] + i;
        arrayOfInt2[1] = arrayOfInt2[1] + j;
        arrayOfInt2[2] = arrayOfInt2[2] + k;
        arrayOfInt2[3] = arrayOfInt2[3] + m;
        arrayOfInt2[4] = arrayOfInt2[4] + n;
        arrayOfInt2[5] = arrayOfInt2[5] + i1;
        arrayOfInt2[6] = arrayOfInt2[6] + i2;
        arrayOfInt2[7] = arrayOfInt2[7] + i3;
      } 
      for (b2 = 0; b2 < 7; b2++)
        System.arraycopy(Tool.toBytesFromInt(arrayOfInt2[b2]), 0, arrayOfByte3, 4 * b2, 4); 
      return arrayOfByte3;
    } 
    if (this.a == "SHA-256") {
      paramArrayOfbyte = paramArrayOfbyte;
      byte[] arrayOfByte3 = new byte[32];
      byte[] arrayOfByte4 = new byte[64];
      paramArrayOfbyte = b(paramArrayOfbyte);
      int[] arrayOfInt1 = { 
          1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 
          607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 
          770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 
          113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, 
          -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 
          659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, 
          -1866530822, -1538233109, -1090935817, -965641998 };
      int[] arrayOfInt2 = { 1779033703, -1150833019, 1013904242, -1521486534, 1359893119, -1694144372, 528734635, 1541459225 };
      byte b2;
      for (b2 = 0; b2 < paramArrayOfbyte.length / 64; b2++) {
        int[] arrayOfInt = new int[64];
        int i = arrayOfInt2[0];
        int j = arrayOfInt2[1];
        int k = arrayOfInt2[2];
        int m = arrayOfInt2[3];
        int n = arrayOfInt2[4];
        int i1 = arrayOfInt2[5];
        int i2 = arrayOfInt2[6];
        int i3 = arrayOfInt2[7];
        System.arraycopy(paramArrayOfbyte, b2 * 64, arrayOfByte4, 0, 64);
        byte b3;
        for (b3 = 0; b3 < 16; b3++) {
          arrayOfInt[b3] = 0;
          for (byte b4 = 0; b4 < 4; b4++)
            arrayOfInt[b3] = arrayOfInt[b3] | (arrayOfByte4[(b3 << 2) + b4] & 0xFF) << 24 - (b4 << 3); 
        } 
        for (b3 = 16; b3 < 64; b3++) {
          int i4 = Integer.rotateRight(arrayOfInt[b3 - 15], 7) ^ Integer.rotateRight(arrayOfInt[b3 - 15], 18) ^ arrayOfInt[b3 - 15] >>> 3;
          int i5 = Integer.rotateRight(arrayOfInt[b3 - 2], 17) ^ Integer.rotateRight(arrayOfInt[b3 - 2], 19) ^ arrayOfInt[b3 - 2] >>> 10;
          arrayOfInt[b3] = arrayOfInt[b3 - 16] + i4 + arrayOfInt[b3 - 7] + i5;
        } 
        for (b3 = 0; b3 < 64; b3++) {
          int i4 = Integer.rotateRight(i, 2) ^ Integer.rotateRight(i, 13) ^ Integer.rotateRight(i, 22);
          int i6 = i & j ^ i & k ^ j & k;
          int i8 = i4 + i6;
          int i5 = Integer.rotateRight(n, 6) ^ Integer.rotateRight(n, 11) ^ Integer.rotateRight(n, 25);
          int i9 = n & i1 ^ (n ^ 0xFFFFFFFF) & i2;
          int i7 = i3 + i5 + i9 + arrayOfInt1[b3] + arrayOfInt[b3];
          i3 = i2;
          i2 = i1;
          i1 = n;
          n = m + i7;
          m = k;
          k = j;
          j = i;
          i = i7 + i8;
        } 
        arrayOfInt2[0] = arrayOfInt2[0] + i;
        arrayOfInt2[1] = arrayOfInt2[1] + j;
        arrayOfInt2[2] = arrayOfInt2[2] + k;
        arrayOfInt2[3] = arrayOfInt2[3] + m;
        arrayOfInt2[4] = arrayOfInt2[4] + n;
        arrayOfInt2[5] = arrayOfInt2[5] + i1;
        arrayOfInt2[6] = arrayOfInt2[6] + i2;
        arrayOfInt2[7] = arrayOfInt2[7] + i3;
      } 
      for (b2 = 0; b2 < 8; b2++)
        System.arraycopy(Tool.toBytesFromInt(arrayOfInt2[b2]), 0, arrayOfByte3, 4 * b2, 4); 
      return arrayOfByte3;
    } 
    if (this.a == "SHA-384") {
      paramArrayOfbyte = paramArrayOfbyte;
      byte[] arrayOfByte3 = new byte[48];
      byte[] arrayOfByte4 = new byte[128];
      paramArrayOfbyte = c(paramArrayOfbyte);
      long[] arrayOfLong3 = { 
          4794697086780616226L, 8158064640168781261L, -5349999486874862801L, -1606136188198331460L, 4131703408338449720L, 6480981068601479193L, -7908458776815382629L, -6116909921290321640L, -2880145864133508542L, 1334009975649890238L, 
          2608012711638119052L, 6128411473006802146L, 8268148722764581231L, -9160688886553864527L, -7215885187991268811L, -4495734319001033068L, -1973867731355612462L, -1171420211273849373L, 1135362057144423861L, 2597628984639134821L, 
          3308224258029322869L, 5365058923640841347L, 6679025012923562964L, 8573033837759648693L, -7476448914759557205L, -6327057829258317296L, -5763719355590565569L, -4658551843659510044L, -4116276920077217854L, -3051310485924567259L, 
          489312712824947311L, 1452737877330783856L, 2861767655752347644L, 3322285676063803686L, 5560940570517711597L, 5996557281743188959L, 7280758554555802590L, 8532644243296465576L, -9096487096722542874L, -7894198246740708037L, 
          -6719396339535248540L, -6333637450476146687L, -4446306890439682159L, -4076793802049405392L, -3345356375505022440L, -2983346525034927856L, -860691631967231958L, 1182934255886127544L, 1847814050463011016L, 2177327727835720531L, 
          2830643537854262169L, 3796741975233480872L, 4115178125766777443L, 5681478168544905931L, 6601373596472566643L, 7507060721942968483L, 8399075790359081724L, 8693463985226723168L, -8878714635349349518L, -8302665154208450068L, 
          -8016688836872298968L, -6606660893046293015L, -4685533653050689259L, -4147400797238176981L, -3880063495543823972L, -3348786107499101689L, -1523767162380948706L, -757361751448694408L, 500013540394364858L, 748580250866718886L, 
          1242879168328830382L, 1977374033974150939L, 2944078676154940804L, 3659926193048069267L, 4368137639120453308L, 4836135668995329356L, 5532061633213252278L, 6448918945643986474L, 6902733635092675308L, 7801388544844847127L };
      long[] arrayOfLong4 = { -3766243637369397544L, 7105036623409894663L, -7973340178411365097L, 1526699215303891257L, 7436329637833083697L, -8163818279084223215L, -2662702644619276377L, 5167115440072839076L };
      byte b2;
      for (b2 = 0; b2 < paramArrayOfbyte.length / 128; b2++) {
        long[] arrayOfLong = new long[80];
        long l1 = arrayOfLong4[0];
        long l2 = arrayOfLong4[1];
        long l3 = arrayOfLong4[2];
        long l4 = arrayOfLong4[3];
        long l5 = arrayOfLong4[4];
        long l6 = arrayOfLong4[5];
        long l7 = arrayOfLong4[6];
        long l8 = arrayOfLong4[7];
        System.arraycopy(paramArrayOfbyte, b2 * 128, arrayOfByte4, 0, 128);
        byte b3;
        for (b3 = 0; b3 < 16; b3++) {
          arrayOfLong[b3] = 0L;
          for (byte b4 = 0; b4 < 8; b4++)
            arrayOfLong[b3] = arrayOfLong[b3] | (arrayOfByte4[(b3 << 3) + b4] & 0xFFL) << 56 - (b4 << 3); 
        } 
        for (b3 = 16; b3 < 80; b3++)
          arrayOfLong[b3] = b(arrayOfLong[b3 - 2]) + arrayOfLong[b3 - 7] + a(arrayOfLong[b3 - 15]) + arrayOfLong[b3 - 16]; 
        for (b3 = 0; b3 < 80; b3++) {
          long l9 = l8 + a(l5, l6, l7) + d(l5) + arrayOfLong[b3] + arrayOfLong3[b3];
          long l10 = c(l1) + b(l1, l2, l3);
          l8 = l7;
          l7 = l6;
          l6 = l5;
          l5 = l4 + l9;
          l4 = l3;
          l3 = l2;
          l2 = l1;
          l1 = l9 + l10;
        } 
        arrayOfLong4[0] = arrayOfLong4[0] + l1;
        arrayOfLong4[1] = arrayOfLong4[1] + l2;
        arrayOfLong4[2] = arrayOfLong4[2] + l3;
        arrayOfLong4[3] = arrayOfLong4[3] + l4;
        arrayOfLong4[4] = arrayOfLong4[4] + l5;
        arrayOfLong4[5] = arrayOfLong4[5] + l6;
        arrayOfLong4[6] = arrayOfLong4[6] + l7;
        arrayOfLong4[7] = arrayOfLong4[7] + l8;
      } 
      for (b2 = 0; b2 < 6; b2++)
        System.arraycopy(Tool.toBytesFromLong(arrayOfLong4[b2]), 0, arrayOfByte3, b2 * 8, 8); 
      return arrayOfByte3;
    } 
    paramArrayOfbyte = paramArrayOfbyte;
    byte[] arrayOfByte1 = new byte[64];
    byte[] arrayOfByte2 = new byte[128];
    paramArrayOfbyte = c(paramArrayOfbyte);
    long[] arrayOfLong1 = { 
        4794697086780616226L, 8158064640168781261L, -5349999486874862801L, -1606136188198331460L, 4131703408338449720L, 6480981068601479193L, -7908458776815382629L, -6116909921290321640L, -2880145864133508542L, 1334009975649890238L, 
        2608012711638119052L, 6128411473006802146L, 8268148722764581231L, -9160688886553864527L, -7215885187991268811L, -4495734319001033068L, -1973867731355612462L, -1171420211273849373L, 1135362057144423861L, 2597628984639134821L, 
        3308224258029322869L, 5365058923640841347L, 6679025012923562964L, 8573033837759648693L, -7476448914759557205L, -6327057829258317296L, -5763719355590565569L, -4658551843659510044L, -4116276920077217854L, -3051310485924567259L, 
        489312712824947311L, 1452737877330783856L, 2861767655752347644L, 3322285676063803686L, 5560940570517711597L, 5996557281743188959L, 7280758554555802590L, 8532644243296465576L, -9096487096722542874L, -7894198246740708037L, 
        -6719396339535248540L, -6333637450476146687L, -4446306890439682159L, -4076793802049405392L, -3345356375505022440L, -2983346525034927856L, -860691631967231958L, 1182934255886127544L, 1847814050463011016L, 2177327727835720531L, 
        2830643537854262169L, 3796741975233480872L, 4115178125766777443L, 5681478168544905931L, 6601373596472566643L, 7507060721942968483L, 8399075790359081724L, 8693463985226723168L, -8878714635349349518L, -8302665154208450068L, 
        -8016688836872298968L, -6606660893046293015L, -4685533653050689259L, -4147400797238176981L, -3880063495543823972L, -3348786107499101689L, -1523767162380948706L, -757361751448694408L, 500013540394364858L, 748580250866718886L, 
        1242879168328830382L, 1977374033974150939L, 2944078676154940804L, 3659926193048069267L, 4368137639120453308L, 4836135668995329356L, 5532061633213252278L, 6448918945643986474L, 6902733635092675308L, 7801388544844847127L };
    long[] arrayOfLong2 = { 7640891576956012808L, -4942790177534073029L, 4354685564936845355L, -6534734903238641935L, 5840696475078001361L, -7276294671716946913L, 2270897969802886507L, 6620516959819538809L };
    byte b1;
    for (b1 = 0; b1 < paramArrayOfbyte.length / 128; b1++) {
      long[] arrayOfLong = new long[80];
      long l1 = arrayOfLong2[0];
      long l2 = arrayOfLong2[1];
      long l3 = arrayOfLong2[2];
      long l4 = arrayOfLong2[3];
      long l5 = arrayOfLong2[4];
      long l6 = arrayOfLong2[5];
      long l7 = arrayOfLong2[6];
      long l8 = arrayOfLong2[7];
      System.arraycopy(paramArrayOfbyte, b1 * 128, arrayOfByte2, 0, 128);
      byte b2;
      for (b2 = 0; b2 < 16; b2++) {
        arrayOfLong[b2] = 0L;
        for (byte b3 = 0; b3 < 8; b3++)
          arrayOfLong[b2] = arrayOfLong[b2] | (arrayOfByte2[(b2 << 3) + b3] & 0xFFL) << 56 - (b3 << 3); 
      } 
      for (b2 = 16; b2 < 80; b2++)
        arrayOfLong[b2] = b(arrayOfLong[b2 - 2]) + arrayOfLong[b2 - 7] + a(arrayOfLong[b2 - 15]) + arrayOfLong[b2 - 16]; 
      for (b2 = 0; b2 < 80; b2++) {
        long l9 = l8 + a(l5, l6, l7) + d(l5) + arrayOfLong[b2] + arrayOfLong1[b2];
        long l10 = c(l1) + b(l1, l2, l3);
        l8 = l7;
        l7 = l6;
        l6 = l5;
        l5 = l4 + l9;
        l4 = l3;
        l3 = l2;
        l2 = l1;
        l1 = l9 + l10;
      } 
      arrayOfLong2[0] = arrayOfLong2[0] + l1;
      arrayOfLong2[1] = arrayOfLong2[1] + l2;
      arrayOfLong2[2] = arrayOfLong2[2] + l3;
      arrayOfLong2[3] = arrayOfLong2[3] + l4;
      arrayOfLong2[4] = arrayOfLong2[4] + l5;
      arrayOfLong2[5] = arrayOfLong2[5] + l6;
      arrayOfLong2[6] = arrayOfLong2[6] + l7;
      arrayOfLong2[7] = arrayOfLong2[7] + l8;
    } 
    for (b1 = 0; b1 < 8; b1++)
      System.arraycopy(Tool.toBytesFromLong(arrayOfLong2[b1]), 0, arrayOfByte1, b1 * 8, 8); 
    return arrayOfByte1;
  }
  
  private static long a(long paramLong) {
    return Long.rotateRight(paramLong, 1) ^ Long.rotateRight(paramLong, 8) ^ paramLong >>> 7L;
  }
  
  private static long b(long paramLong) {
    return Long.rotateRight(paramLong, 19) ^ Long.rotateRight(paramLong, 61) ^ paramLong >>> 6L;
  }
  
  private static long c(long paramLong) {
    return Long.rotateRight(paramLong, 28) ^ Long.rotateRight(paramLong, 34) ^ Long.rotateRight(paramLong, 39);
  }
  
  private static long d(long paramLong) {
    return Long.rotateRight(paramLong, 14) ^ Long.rotateRight(paramLong, 18) ^ Long.rotateRight(paramLong, 41);
  }
  
  private static long a(long paramLong1, long paramLong2, long paramLong3) {
    return paramLong1 & paramLong2 ^ (paramLong1 ^ 0xFFFFFFFFFFFFFFFFL) & paramLong3;
  }
  
  private static long b(long paramLong1, long paramLong2, long paramLong3) {
    return paramLong1 & paramLong2 ^ paramLong1 & paramLong3 ^ paramLong2 & paramLong3;
  }
  
  private static byte[] b(byte[] paramArrayOfbyte) {
    int i;
    int j = (i = paramArrayOfbyte.length) % 64;
    if (64 - j >= 9) {
      j = 64 - j;
    } else {
      j = 128 - j;
    } 
    byte[] arrayOfByte1;
    (arrayOfByte1 = new byte[j])[0] = Byte.MIN_VALUE;
    long l = (i << 3);
    for (byte b1 = 0; b1 < 8; b1++)
      arrayOfByte1[arrayOfByte1.length - 1 - b1] = (byte)(int)(l >>> b1 * 8 & 0xFFL); 
    byte[] arrayOfByte2 = new byte[i + j];
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte2, 0, i);
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, i, arrayOfByte1.length);
    return arrayOfByte2;
  }
  
  private static byte[] c(byte[] paramArrayOfbyte) {
    int i;
    int j = (i = paramArrayOfbyte.length) % 128;
    9;
    byte[] arrayOfByte1;
    (arrayOfByte1 = new byte[j = 128 - j])[0] = Byte.MIN_VALUE;
    long l = (i << 3);
    for (byte b1 = 0; b1 < 8; b1++)
      arrayOfByte1[j - 1 - b1] = (byte)(int)(l >> b1 * 8 & 0xFFL); 
    byte[] arrayOfByte2 = new byte[i + j];
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte2, 0, i);
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, i, j);
    return arrayOfByte2;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */