package com.dreammirae.aotp.a;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class a {
  public static byte[] a(byte[] paramArrayOfbyte) throws Exception {
    try {
      MessageDigest messageDigest;
      (messageDigest = MessageDigest.getInstance("SHA-1")).update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      return paramArrayOfbyte = messageDigest.digest();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      return null;
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */