package com.dreammirae.aotp.b;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class a {
  public static byte[] a(String paramString, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
    Mac mac = Mac.getInstance(paramString);
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "RAW");
    mac.init(secretKeySpec);
    return mac.doFinal(paramArrayOfbyte2);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */