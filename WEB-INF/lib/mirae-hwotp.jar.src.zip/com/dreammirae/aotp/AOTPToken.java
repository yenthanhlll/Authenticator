package com.dreammirae.aotp;

import com.dreammirae.timeotp.ToolsUtil;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AOTPToken implements Serializable {
  private String a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private Timestamp e;
  
  private Timestamp f;
  
  private String g;
  
  private String h;
  
  private Timestamp i;
  
  private int j;
  
  private String k;
  
  private String l;
  
  private String m;
  
  private String n;
  
  private String o;
  
  private String p;
  
  private String q;
  
  private static String r = "ZZZZ";
  
  public String getNationCd() {
    return this.a;
  }
  
  public void setNationCd(String paramString) {
    this.a = paramString;
  }
  
  public String getTokenId() {
    return this.b;
  }
  
  public void setTokenId(String paramString) {
    this.b = paramString;
  }
  
  public String getTokenKey() {
    return this.c;
  }
  
  public void setTokenKey(String paramString) {
    this.c = paramString;
  }
  
  public String getOtpChal() {
    return this.d;
  }
  
  public void setOtpChal(String paramString) {
    this.d = paramString;
  }
  
  public Timestamp getChalGenTm() {
    return this.e;
  }
  
  public void setChalGenTm(Timestamp paramTimestamp) {
    this.e = paramTimestamp;
  }
  
  public Timestamp getChalExpTm() {
    return this.f;
  }
  
  public void setChalExpTm(Timestamp paramTimestamp) {
    this.f = paramTimestamp;
  }
  
  public String getChalUseYn() {
    return this.g;
  }
  
  public void setChalUseYn(String paramString) {
    this.g = paramString;
  }
  
  public String getChalLen() {
    return this.h;
  }
  
  public void setChalLen(String paramString) {
    this.h = paramString;
  }
  
  public Timestamp getOtpAuthTm() {
    return this.i;
  }
  
  public void setOtpAuthTm(Timestamp paramTimestamp) {
    this.i = paramTimestamp;
  }
  
  public int getUnlockCnt() {
    return this.j;
  }
  
  public void setUnlockCnt(int paramInt) {
    this.j = paramInt;
  }
  
  public String getModelCd() {
    return this.k;
  }
  
  public void setModelCd(String paramString) {
    this.k = paramString;
  }
  
  public String getPinUseYn() {
    return this.l;
  }
  
  public void setPinUseYn(String paramString) {
    this.l = paramString;
  }
  
  public String getAlgType() {
    return this.m;
  }
  
  public void setAlgType(String paramString) {
    this.m = paramString;
  }
  
  public String getProdDt() {
    return this.n;
  }
  
  public void setProdDt(String paramString) {
    this.n = paramString;
  }
  
  public String getExpireDt() {
    return this.o;
  }
  
  public void setExpireDt(String paramString) {
    this.o = paramString;
  }
  
  public String getReserved1() {
    return this.p;
  }
  
  public void setReserved1(String paramString) {
    this.p = paramString;
  }
  
  public String getReserved2() {
    return this.q;
  }
  
  public void setReserved2(String paramString) {
    this.q = paramString;
  }
  
  public String toString() {
    return "AOTPToken [nationCd=" + this.a + ", tokenId=" + this.b + ", tokenKey=" + this.c + ", otpChal=" + this.d + ", chalGenTm=" + this.e + ", chalExpTm=" + this.f + ", chalUseYn=" + this.g + ", chalLen=" + this.h + ", otpAuthTm=" + this.i + ", unlockCnt=" + this.j + ", modelCd=" + this.k + ", pinUseYn=" + this.l + ", algType=" + this.m + ", prodDt=" + this.n + ", expireDt=" + this.o + ", reserved1=" + this.p + ", reserved2=" + this.q + "]";
  }
  
  public String getTokenKeyAll() {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    String str1 = "19901230113050";
    String str2 = "19901230113050";
    String str3 = "19901230113050";
    if (this.i != null)
      str1 = simpleDateFormat.format(new Date(this.i.getTime())); 
    if (this.e != null)
      str2 = simpleDateFormat.format(new Date(this.e.getTime())); 
    if (this.f != null)
      str3 = simpleDateFormat.format(new Date(this.f.getTime())); 
    if (this.d == null || this.d.length() != 64)
      this.d = "                                                                "; 
    if (this.g == null)
      this.g = "Y"; 
    StringBuffer stringBuffer;
    (stringBuffer = new StringBuffer(this.c)).append(this.m);
    stringBuffer.append(str1);
    stringBuffer.append(this.k);
    stringBuffer.append(this.l);
    stringBuffer.append(ToolsUtil.padRight(Integer.toString(this.j), 3));
    stringBuffer.append(this.d);
    stringBuffer.append(str2);
    stringBuffer.append(str3);
    stringBuffer.append(this.g);
    stringBuffer.append(this.h);
    stringBuffer.append(r);
    str1 = stringBuffer.toString();
    try {
      str1 = (str1 = ToolsUtil.SHA1(str1)).toUpperCase();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      (stringBuffer = null).printStackTrace();
      return null;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      (stringBuffer = null).printStackTrace();
      return null;
    } 
    return stringBuffer.append(str1).toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\AOTPToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */