package com.dreammirae.aotp;

public class AOTPException extends Exception {
  private int a;
  
  public AOTPException(int paramInt) {
    this.a = paramInt;
  }
  
  public int getCode() {
    return this.a;
  }
  
  public void setCode(int paramInt) {
    this.a = paramInt;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\AOTPException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */