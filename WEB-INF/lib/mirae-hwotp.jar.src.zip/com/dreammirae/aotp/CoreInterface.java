package com.dreammirae.aotp;

import com.dreammirae.hwotp.MrOtpResult;

public interface CoreInterface {
  MrOtpResult generateChallenge(AOTPToken paramAOTPToken);
  
  MrOtpResult generateChallenge(AOTPToken paramAOTPToken, int paramInt);
  
  MrOtpResult generateChallenge(AOTPToken paramAOTPToken, String paramString);
  
  MrOtpResult generateChallenge(AOTPToken paramAOTPToken, String paramString, int paramInt);
  
  MrOtpResult verifyOtp(AOTPToken paramAOTPToken, String paramString);
  
  MrOtpResult verifyOtp(AOTPToken paramAOTPToken, String paramString1, String paramString2);
  
  MrOtpResult generateUnlockCode(AOTPToken paramAOTPToken);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\CoreInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */