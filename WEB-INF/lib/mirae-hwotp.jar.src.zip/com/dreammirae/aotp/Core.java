package com.dreammirae.aotp;

import com.dreammirae.aotp.a.b;
import com.dreammirae.aotp.b.a;
import com.dreammirae.aotp.seed.a;
import com.dreammirae.hwotp.Constant;
import com.dreammirae.hwotp.MrOtpResult;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;

public final class Core implements CoreInterface {
  public static final int DFT_CHALLENGE_TIMEOUT_MIN = 3;
  
  public static final int LEN_CHALLENGE_RANDOM = 20;
  
  public static final int LEN_TRAN_HASH = 32;
  
  private static byte[] a = null;
  
  private static Core b = null;
  
  private static boolean c = false;
  
  static {
    try {
      byte[] arrayOfByte1 = Tool.hash("sha1", Tool.toBytesFromString("52deb518bc2e0fb5fcecac56b9679f106536e5f5e16bbc0e5863ffbdc971fbea00de301846659e4a2933660c0cf5b7cf"));
      byte[] arrayOfByte2 = new byte[16];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, 16);
      a = Tool.toBytesFromString("43463034393446464343344543394330");
      c = "Y".equalsIgnoreCase(System.getProperty("MIRAE_AOTP_DEBUG", "N"));
      return;
    } catch (NoSuchAlgorithmException noSuchAlgorithmException2) {
      NoSuchAlgorithmException noSuchAlgorithmException1;
      (noSuchAlgorithmException1 = null).printStackTrace();
      return;
    } 
  }
  
  public final MrOtpResult generateChallenge(AOTPToken paramAOTPToken) {
    return generateChallenge(paramAOTPToken, null, 3);
  }
  
  public final MrOtpResult generateChallenge(AOTPToken paramAOTPToken, int paramInt) {
    return generateChallenge(paramAOTPToken, null, paramInt);
  }
  
  public final MrOtpResult generateChallenge(AOTPToken paramAOTPToken, String paramString) {
    return generateChallenge(paramAOTPToken, paramString, 3);
  }
  
  public final MrOtpResult generateChallenge(AOTPToken paramAOTPToken, String paramString, int paramInt) {
    MrOtpResult mrOtpResult = new MrOtpResult();
    try {
      if (paramAOTPToken == null) {
        if (c)
          a("invalid AOTP_TOKEN"); 
        throw new AOTPException(6007);
      } 
      if (paramInt <= 0) {
        if (c)
          a("invalid challengeTimeoutMin. ".concat(String.valueOf(paramInt))); 
        throw new AOTPException(6007);
      } 
      byte[] arrayOfByte2 = null;
      if (paramString != null) {
        if (!Tool.isHex(paramString)) {
          if (c)
            a("invalid tranHashHex. ".concat(String.valueOf(paramString))); 
          throw new AOTPException(6007);
        } 
        if ((arrayOfByte2 = Tool.toBytesFromString(paramString)).length != 32) {
          if (c)
            a("invalid tranHashHex length.  " + arrayOfByte2.length); 
          throw new AOTPException(6007);
        } 
      } 
      byte[] arrayOfByte1 = Tool.randomBytes(20);
      byte[] arrayOfByte3;
      byte b;
      Arrays.fill(arrayOfByte3 = new byte[b = (arrayOfByte2 == null) ? 20 : 52], (byte)0);
      System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, 20);
      if (arrayOfByte2 != null)
        System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 20, 32); 
      String str1 = a(arrayOfByte3, Integer.parseInt(paramAOTPToken.getChalLen()));
      String str2 = Tool.toString(SEED_ENCRYPT(arrayOfByte1));
      Arrays.fill(arrayOfByte1, (byte)0);
      Arrays.fill(arrayOfByte3, (byte)0);
      paramAOTPToken.setOtpChal(str2);
      paramAOTPToken.setChalUseYn("N");
      Date date1 = new Date();
      Date date2;
      (date2 = new Date()).setTime(date1.getTime() + (paramInt * 1000 * 60));
      paramAOTPToken.setChalGenTm(new Timestamp(date1.getTime()));
      paramAOTPToken.setChalExpTm(new Timestamp(date2.getTime()));
      mrOtpResult.setChallenge(str1);
      mrOtpResult.setRcCode(0);
    } catch (AOTPException aOTPException) {
      mrOtpResult.setRcCode(aOTPException.getCode());
    } catch (Throwable throwable2) {
      Throwable throwable1;
      (throwable1 = null).printStackTrace();
    } 
    return mrOtpResult;
  }
  
  private String a(byte[] paramArrayOfbyte, int paramInt) throws NoSuchAlgorithmException {
    b b;
    return b(paramArrayOfbyte = (b = new b("SHA-256")).a(paramArrayOfbyte), paramInt);
  }
  
  public final MrOtpResult verifyOtp(AOTPToken paramAOTPToken, String paramString) {
    return verifyOtp(paramAOTPToken, paramString, null);
  }
  
  public final MrOtpResult verifyOtp(AOTPToken paramAOTPToken, String paramString1, String paramString2) {
    MrOtpResult mrOtpResult = new MrOtpResult();
    try {
      if (paramAOTPToken == null) {
        if (c)
          a("invalid AOTP_TOKEN"); 
        throw new AOTPException(6007);
      } 
      if (paramString1 == null) {
        if (c)
          a("invalid otp."); 
        throw new AOTPException(6007);
      } 
      if (!Tool.isNumber(paramString1) || paramString1.length() != 6) {
        if (c)
          a("invalid otp.".concat(String.valueOf(paramString1))); 
        throw new AOTPException(6010);
      } 
      if (paramAOTPToken.getChalExpTm() == null) {
        if (c)
          a("invalid AOTP_TOKEN.CHAL_EXP_TM"); 
        throw new AOTPException(6007);
      } 
      if (Tool.isNullorEmpty(paramAOTPToken.getOtpChal()) || !Tool.isHex(paramAOTPToken.getOtpChal())) {
        if (c)
          a("invalid AOTP_TOKEN.OTP_CHAL. " + paramAOTPToken.getOtpChal()); 
        throw new AOTPException(6007);
      } 
      byte[] arrayOfByte2;
      if ((arrayOfByte2 = SEED_DECRYPT(Tool.toBytesFromString(paramAOTPToken.getOtpChal()))).length != 20) {
        if (c)
          a("invalid AOTP_TOKEN.OTP_CHAL length " + arrayOfByte2.length); 
        throw new AOTPException(6007);
      } 
      if (paramString2 != null && (!Tool.isHex(paramString2) || paramString2.length() != 64)) {
        if (c)
          a("invalid tranHash.  ".concat(String.valueOf(paramString2))); 
        throw new AOTPException(6007);
      } 
      byte b;
      byte[] arrayOfByte3;
      Arrays.fill(arrayOfByte3 = new byte[b = (paramString2 == null) ? 20 : 52], (byte)0);
      System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, 20);
      arrayOfByte2 = (paramString2 == null) ? null : Tool.toBytesFromString(paramString2);
      if (paramString2 != null)
        System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 20, 32); 
      paramString2 = a(arrayOfByte3, Integer.parseInt(paramAOTPToken.getChalLen()));
      arrayOfByte2 = SEED_DECRYPT(Tool.toBytesFromString(paramAOTPToken.getTokenKey()));
      byte[] arrayOfByte1;
      String str = b(arrayOfByte1 = a.a("HmacSHA256", arrayOfByte2, paramString2.getBytes()), 6);
      if (c)
        a("serverOTP : ".concat(String.valueOf(str))); 
      Arrays.fill(arrayOfByte2, (byte)0);
      Arrays.fill(arrayOfByte3, (byte)0);
      if (str.equals(paramString1)) {
        if ("Y".equalsIgnoreCase(paramAOTPToken.getChalUseYn())) {
          mrOtpResult.setRcCode(6001);
        } else {
          mrOtpResult.setRcCode(0);
          paramAOTPToken.setChalUseYn("Y");
          paramAOTPToken.setOtpAuthTm(new Timestamp((new Date()).getTime()));
        } 
      } else {
        mrOtpResult.setRcCode(6000);
      } 
    } catch (AOTPException aOTPException) {
      mrOtpResult.setRcCode(aOTPException.getCode());
    } catch (Throwable throwable2) {
      Throwable throwable1;
      (throwable1 = null).printStackTrace();
    } 
    return mrOtpResult;
  }
  
  public final MrOtpResult generateUnlockCode(AOTPToken paramAOTPToken) {
    MrOtpResult mrOtpResult = new MrOtpResult();
    try {
      if (paramAOTPToken == null) {
        if (c)
          a("invalid AOTP_TOKEN"); 
        throw new AOTPException(6007);
      } 
      if (paramAOTPToken.getTokenKey() == null || paramAOTPToken.getTokenKey().length() != 64 || !Tool.isHex(paramAOTPToken.getTokenKey())) {
        if (c)
          a("invalid AOTP_TOKEN.TOKEN_KEY!"); 
        throw new AOTPException(6007);
      } 
      if (!"Y".equalsIgnoreCase(paramAOTPToken.getPinUseYn()))
        throw new AOTPException(6014); 
      short s = (short)paramAOTPToken.getUnlockCnt();
      byte[] arrayOfByte1 = SEED_DECRYPT(Tool.toBytesFromString(paramAOTPToken.getTokenKey()));
      byte[] arrayOfByte2 = Tool.toBytesFromShort(s);
      String str = b(arrayOfByte2 = a.a("HmacSHA256", arrayOfByte1, arrayOfByte2), 6);
      Arrays.fill(arrayOfByte1, (byte)0);
      paramAOTPToken.setUnlockCnt(s + 1);
      mrOtpResult.setRcCode(0);
      mrOtpResult.setUnlock(str);
    } catch (AOTPException aOTPException) {
      mrOtpResult.setRcCode(aOTPException.getCode());
    } catch (Throwable throwable2) {
      Throwable throwable1;
      (throwable1 = null).printStackTrace();
    } 
    return mrOtpResult;
  }
  
  public final byte[] SEED_ENCRYPT(byte[] paramArrayOfbyte) throws Exception {
    byte[] arrayOfByte = new byte[32];
    a.b(a, arrayOfByte, paramArrayOfbyte);
    return arrayOfByte;
  }
  
  public final byte[] SEED_DECRYPT(byte[] paramArrayOfbyte) throws Exception {
    byte[] arrayOfByte = new byte[20];
    a.a(a, arrayOfByte, paramArrayOfbyte);
    return arrayOfByte;
  }
  
  public static synchronized Core getInstance() {
    if (b == null)
      b = new Core(); 
    return b;
  }
  
  private static String b(byte[] paramArrayOfbyte, int paramInt) {
    String str = "";
    try {
      int j = (paramArrayOfbyte[paramArrayOfbyte.length - 1] & Byte.MAX_VALUE) % 28;
      int i;
      for (str = Integer.toString(i = (i = (paramArrayOfbyte[j] & Byte.MAX_VALUE) << 24 | (paramArrayOfbyte[j + 1] & 0xFF) << 16 | (paramArrayOfbyte[j + 2] & 0xFF) << 8 | paramArrayOfbyte[j + 3] & 0xFF) % Constant.OTP_LENGTH_MOD[paramInt]); str.length() < paramInt; str = "0".concat(String.valueOf(str)));
    } catch (Exception exception2) {
      Exception exception1;
      (exception1 = null).printStackTrace();
    } 
    return str;
  }
  
  private static void a(String paramString) {
    System.out.println(String.format("[%s] - %s", new Object[] { Tool.date2Str(new Date()), paramString }));
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mirae-hwotp.jar!\com\dreammirae\aotp\Core.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */