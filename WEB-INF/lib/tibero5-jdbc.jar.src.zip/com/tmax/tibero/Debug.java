package com.tmax.tibero;

import java.io.PrintWriter;
import java.sql.DriverManager;

public class Debug {
  public static final boolean TRACE = false;
  
  public static final boolean NETWORK = false;
  
  public static final boolean CONNECTION = false;
  
  private static PrintWriter lw = null;
  
  public static String getHexFromBytes(byte[] paramArrayOfbyte) {
    return null;
  }
  
  public static String getHexFromBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    return null;
  }
  
  public static PrintWriter getLogWriter() {
    return lw;
  }
  
  public static void log(String paramString) {}
  
  public static void logMethod(String paramString, Object[] paramArrayOfObject) {}
  
  public static void logMethod(String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject) {}
  
  public static void logThrowable(Throwable paramThrowable) {}
  
  public static void logReturn(String paramString, Object paramObject) {}
  
  public static void setLogWriter(PrintWriter paramPrintWriter) {
    lw = paramPrintWriter;
  }
  
  static {
    lw = DriverManager.getLogWriter();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\Debug.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */