package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.data.DataType;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.msg.TbBindparamUdt;
import com.tmax.tibero.jdbc.msg.TbOutParamUdt;
import com.tmax.tibero.jdbc.util.TbCommon;
import java.lang.reflect.Array;
import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public class TbArray implements Array {
  private TbConnection conn;
  
  private int baseType;
  
  private int numOfElements;
  
  private TbArrayDescriptor descriptor;
  
  private TbOutParamUdt outParams;
  
  private TbBindparamUdt inParams;
  
  public TbArray(TbArrayDescriptor paramTbArrayDescriptor, Connection paramConnection, Object[] paramArrayOfObject) throws SQLException {
    this.descriptor = paramTbArrayDescriptor;
    this.conn = (TbConnection)paramConnection;
    int i = this.descriptor.getElementsType();
    int j = this.descriptor.getBaseType();
    setAttribute(i, j, paramArrayOfObject);
  }
  
  public TbArray(Connection paramConnection, byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
    if (!(paramObject instanceof TbOutParamUdt))
      throw TbError.newSQLException(-590713); 
    this.conn = (TbConnection)paramConnection;
    this.outParams = (TbOutParamUdt)paramObject;
    this.numOfElements = this.outParams.subOutParam.length;
    this.baseType = this.outParams.dataType;
  }
  
  private TbBindparamUdt setAttribute(int paramInt1, int paramInt2, Object[] paramArrayOfObject) throws SQLException {
    TbBindparamUdt[] arrayOfTbBindparamUdt = new TbBindparamUdt[paramArrayOfObject.length];
    int i;
    for (i = 0; i < paramArrayOfObject.length; i++)
      arrayOfTbBindparamUdt[i] = new TbBindparamUdt(); 
    i = 0;
    boolean bool = true;
    i = bool & 0xFF | paramInt1 << 8 & 0xFFFFFF00;
    DataTypeConverter dataTypeConverter = this.conn.getTypeConverter();
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      byte[] arrayOfByte1;
      switch (paramInt1) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 10:
        case 13:
        case 18:
        case 19:
        case 20:
          arrayOfByte1 = dataTypeConverter.castFromObject(paramArrayOfObject[b], paramInt1);
          arrayOfTbBindparamUdt[b].set(i, arrayOfByte1, arrayOfByte1.length, 0, null);
          break;
        case 29:
        case 30:
          arrayOfTbBindparamUdt[b] = ((TbArray)paramArrayOfObject[b]).getInParams();
          break;
        case 28:
          arrayOfTbBindparamUdt[b] = ((TbStruct)paramArrayOfObject[b]).getInParams();
          break;
        default:
          throw TbError.newSQLException(-590703, DataType.getDBTypeName(paramInt1));
      } 
    } 
    byte[] arrayOfByte = new byte[12];
    TbCommon.int2Bytes(paramInt2, arrayOfByte, 0, 4);
    TbCommon.int2Bytes(paramInt1, arrayOfByte, 4, 4);
    TbCommon.int2Bytes(paramArrayOfObject.length, arrayOfByte, 8, 4);
    i = bool & 0xFF | paramInt2 << 8 & 0xFFFFFF00;
    this.inParams = new TbBindparamUdt();
    this.inParams.set(i, arrayOfByte, arrayOfByte.length, paramArrayOfObject.length, arrayOfTbBindparamUdt);
    return this.inParams;
  }
  
  TbBindparamUdt getInParams() {
    return this.inParams;
  }
  
  TbOutParamUdt getOutParams() {
    return this.outParams;
  }
  
  public TbArrayDescriptor getDescriptor() {
    return this.descriptor;
  }
  
  public void free() throws SQLException {
    this.conn = null;
    this.descriptor = null;
  }
  
  public Object getArray() throws SQLException {
    return getArray(this.outParams.subOutParam);
  }
  
  private Object getArray(TbOutParamUdt[] paramArrayOfTbOutParamUdt) throws SQLException {
    int k;
    String str;
    int i = paramArrayOfTbOutParamUdt.length;
    int j = (paramArrayOfTbOutParamUdt[0]).dataType;
    switch (this.conn.getMapDateToTimestamp()) {
      case 0:
        k = DataType.getSqlType(j, 0, false);
        break;
      default:
        k = DataType.getSqlType(j, 0, true);
        break;
    } 
    if (j == 29 || j == 30) {
      str = "java.lang.Object";
    } else {
      str = DataType.getDataTypeClassName(j);
    } 
    try {
      Class<?> clazz = Class.forName(str);
      Object object = Array.newInstance(clazz, i);
      for (byte b = 0; b < i; b++) {
        Object object1 = null;
        if (j == 29 || j == 28 || j == 30) {
          object1 = getArray((paramArrayOfTbOutParamUdt[b]).subOutParam);
        } else {
          object1 = this.conn.getTypeConverter().toObject((paramArrayOfTbOutParamUdt[b]).value, 0, (paramArrayOfTbOutParamUdt[b]).value.length, j, k, null);
        } 
        Array.set(object, b, object1);
      } 
      return object;
    } catch (ClassNotFoundException classNotFoundException) {
      throw TbError.newSQLException(-590705, classNotFoundException.getMessage());
    } 
  }
  
  public Object getArray(long paramLong, int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public Object getArray(long paramLong, int paramInt, Map<String, Class<?>> paramMap) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public Object getArray(Map<String, Class<?>> paramMap) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public int getBaseType() throws SQLException {
    return this.baseType;
  }
  
  public String getBaseTypeName() throws SQLException {
    return DataType.getDBTypeName(this.baseType);
  }
  
  public int getNumOfElements() {
    return this.numOfElements;
  }
  
  public int getElementsType() {
    return (getOutParams()).dataType;
  }
  
  public int getNumOfSubElements() {
    return (getOutParams()).subOutParamArrayCnt;
  }
  
  public int getSubElementsType() {
    return ((getOutParams()).subOutParam[0]).dataType;
  }
  
  public ResultSet getResultSet() throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public ResultSet getResultSet(long paramLong, int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public ResultSet getResultSet(long paramLong, int paramInt, Map<String, Class<?>> paramMap) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public ResultSet getResultSet(Map<String, Class<?>> paramMap) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */