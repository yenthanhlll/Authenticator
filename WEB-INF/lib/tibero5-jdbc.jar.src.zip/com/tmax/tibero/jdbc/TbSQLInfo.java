package com.tmax.tibero.jdbc;

public class TbSQLInfo {
  private String sqlid;
  
  private String hashval;
  
  public String getHashval() {
    return this.hashval;
  }
  
  public void setHashval(String paramString) {
    this.hashval = paramString;
  }
  
  public String getSqlid() {
    return this.sqlid;
  }
  
  public void setSqlid(String paramString) {
    this.sqlid = paramString;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbSQLInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */