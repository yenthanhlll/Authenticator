package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.data.Row;
import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public class TbRSFwOnly extends TbResultSetBase {
  private Row row;
  
  private int chunkOffset;
  
  protected int lastFetchedCnt;
  
  protected TbRSFwOnly(TbStatement paramTbStatement, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    super(paramTbStatement, paramInt1, paramInt2, paramInt3);
  }
  
  public void buildRowTable(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    this.chunkOffset = 1;
    if (this.rowsFetchedCnt + paramInt < 0)
      throw TbError.newSQLException(-90613); 
    this.lastFetchedCnt = this.rowsFetchedCnt;
    this.rowsFetchedCnt += paramInt;
    this.currentFetchCount = paramInt;
    if (this.row == null)
      this.row = new Row(this.columnCount); 
    this.rowChunk = paramArrayOfbyte;
  }
  
  private void checkRowIndex(int paramInt) throws SQLException {
    if (paramInt < 0)
      throw TbError.newSQLException(-90635); 
    if ((this.stmt.getMaxRows() != 0 && paramInt >= this.stmt.getMaxRows()) || (paramInt >= this.rowsFetchedCnt && this.fetchComplete))
      throw TbError.newSQLException(-90647); 
    if (paramInt < this.lastFetchedCnt || (this.stmt.getMaxRows() != 0 && paramInt >= this.stmt.getMaxRows()) || paramInt >= this.rowsFetchedCnt)
      throw TbError.newSQLException(-90624); 
  }
  
  protected Row getCurrentRow() throws SQLException {
    checkRowIndex(this.currentRowIndex);
    return this.row;
  }
  
  public synchronized boolean next() throws SQLException {
    if (!super.next()) {
      closeCursor();
      return false;
    } 
    this.chunkOffset += this.row.buildRowData(this.rowChunk, this.chunkOffset, this.cols);
    return true;
  }
  
  protected void removeCurrentRow() throws SQLException {}
  
  protected void reset() {
    super.reset();
    if (this.row != null) {
      this.row.close();
      this.row = null;
    } 
  }
  
  public boolean absolute(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public void afterLast() throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public void beforeFirst() throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public boolean first() throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public boolean isLast() throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public boolean last() throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public boolean previous() throws SQLException {
    throw TbError.newSQLException(-90620);
  }
  
  public boolean relative(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90620);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbRSFwOnly.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */