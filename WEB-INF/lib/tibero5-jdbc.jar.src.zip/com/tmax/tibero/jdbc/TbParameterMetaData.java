package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.ParameterMetaData;
import java.sql.SQLException;

public class TbParameterMetaData implements ParameterMetaData {
  int parameterCnt = 0;
  
  TbParameterMetaData(int paramInt) {
    this.parameterCnt = paramInt;
  }
  
  public String getParameterClassName(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public int getParameterCount() throws SQLException {
    return this.parameterCnt;
  }
  
  public int getParameterMode(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public int getParameterType(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public String getParameterTypeName(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public int getPrecision(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public int getScale(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public int isNullable(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public boolean isSigned(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    return paramClass.isInstance(this);
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    try {
      return paramClass.cast(this);
    } catch (ClassCastException classCastException) {
      throw TbError.newSQLException(-90657);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbParameterMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */