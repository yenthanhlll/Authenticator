package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.data.DataType;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.msg.TbBindparamUdt;
import com.tmax.tibero.jdbc.msg.TbOutParamUdt;
import com.tmax.tibero.jdbc.util.TbCommon;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Struct;
import java.util.Map;

public class TbStruct implements Struct {
  private int baseType;
  
  private TbStructDescriptor descriptor;
  
  TbConnection conn;
  
  Object[] objectArray;
  
  private TbOutParamUdt outParams;
  
  private TbBindparamUdt inParams;
  
  private int numOfFields;
  
  public TbStruct(TbStructDescriptor paramTbStructDescriptor, Connection paramConnection, Object[] paramArrayOfObject) throws SQLException {
    this.descriptor = paramTbStructDescriptor;
    this.conn = (TbConnection)paramConnection;
    this.objectArray = paramArrayOfObject;
    this.baseType = paramTbStructDescriptor.getBaseType();
    int i = paramTbStructDescriptor.getNumOfFields();
    int[] arrayOfInt = paramTbStructDescriptor.getAttributeType();
    setAttribute(i, arrayOfInt, paramArrayOfObject);
  }
  
  public TbStruct(Connection paramConnection, byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
    if (!(paramObject instanceof TbOutParamUdt))
      throw TbError.newSQLException(-590713); 
    this.conn = (TbConnection)paramConnection;
    this.outParams = (TbOutParamUdt)paramObject;
    this.numOfFields = this.outParams.subOutParam.length;
    this.baseType = this.outParams.dataType;
  }
  
  private TbBindparamUdt setAttribute(int paramInt, int[] paramArrayOfint, Object[] paramArrayOfObject) throws SQLException {
    TbBindparamUdt[] arrayOfTbBindparamUdt = new TbBindparamUdt[paramArrayOfObject.length];
    int i;
    for (i = 0; i < paramArrayOfObject.length; i++)
      arrayOfTbBindparamUdt[i] = new TbBindparamUdt(); 
    i = 0;
    boolean bool = true;
    DataTypeConverter dataTypeConverter = this.conn.getTypeConverter();
    for (byte b = 0; b < paramInt; b++) {
      byte[] arrayOfByte1;
      i = bool & 0xFF | paramArrayOfint[b] << 8 & 0xFFFFFF00;
      switch (paramArrayOfint[b]) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 10:
        case 13:
        case 18:
        case 19:
        case 20:
          arrayOfByte1 = dataTypeConverter.castFromObject(paramArrayOfObject[b], paramArrayOfint[b]);
          arrayOfTbBindparamUdt[b].set(i, arrayOfByte1, arrayOfByte1.length, 0, null);
          break;
        case 29:
        case 30:
          arrayOfTbBindparamUdt[b] = ((TbArray)paramArrayOfObject[b]).getInParams();
          break;
        case 28:
          arrayOfTbBindparamUdt[b] = ((TbStruct)paramArrayOfObject[b]).getInParams();
          break;
        default:
          throw TbError.newSQLException(-590703, DataType.getDBTypeName(paramArrayOfint[b]));
      } 
    } 
    byte[] arrayOfByte = new byte[8];
    TbCommon.int2Bytes(this.baseType, arrayOfByte, 0, 4);
    TbCommon.int2Bytes(paramInt, arrayOfByte, 4, 4);
    i = bool & 0xFF | this.baseType << 8 & 0xFFFFFF00;
    this.inParams = new TbBindparamUdt();
    this.inParams.set(i, arrayOfByte, arrayOfByte.length, paramArrayOfObject.length, arrayOfTbBindparamUdt);
    return this.inParams;
  }
  
  TbBindparamUdt getInParams() {
    return this.inParams;
  }
  
  public TbStructDescriptor getDescriptor() throws SQLException {
    return this.descriptor;
  }
  
  public void setDescriptor(TbStructDescriptor paramTbStructDescriptor) {
    this.descriptor = paramTbStructDescriptor;
  }
  
  public int getNumOfFields() {
    return this.numOfFields;
  }
  
  private Object[] getStruct(TbOutParamUdt[] paramArrayOfTbOutParamUdt) throws SQLException {
    int i = paramArrayOfTbOutParamUdt.length;
    Object object = Array.newInstance(Object.class, i);
    DataTypeConverter dataTypeConverter = this.conn.getTypeConverter();
    for (byte b = 0; b < i; b++) {
      int j = (paramArrayOfTbOutParamUdt[b]).dataType;
      Object object1 = null;
      if (j == 28) {
        object1 = getStruct((paramArrayOfTbOutParamUdt[b]).subOutParam);
      } else if (j == 1) {
        byte[] arrayOfByte = new byte[(paramArrayOfTbOutParamUdt[b]).value.length + 1];
        int k = (paramArrayOfTbOutParamUdt[b]).value.length;
        arrayOfByte[0] = (byte)k;
        System.arraycopy((paramArrayOfTbOutParamUdt[b]).value, 0, arrayOfByte, 1, (paramArrayOfTbOutParamUdt[b]).value.length);
        Object object2 = this.conn.getTypeConverter().toObject(arrayOfByte, 0, (paramArrayOfTbOutParamUdt[b]).value.length, j, DataType.getSqlType(j), null);
      } else {
        switch (this.conn.getMapDateToTimestamp()) {
          case 0:
            object1 = dataTypeConverter.toObject((paramArrayOfTbOutParamUdt[b]).value, 0, (paramArrayOfTbOutParamUdt[b]).value.length, j, DataType.getSqlType(j, 0, false), null);
            break;
          default:
            object1 = dataTypeConverter.toObject((paramArrayOfTbOutParamUdt[b]).value, 0, (paramArrayOfTbOutParamUdt[b]).value.length, j, DataType.getSqlType(j, 0, true), null);
            break;
        } 
      } 
      Array.set(object, b, object1);
    } 
    return (Object[])object;
  }
  
  public static Object toStruct(Object paramObject, Connection paramConnection) {
    TbStruct tbStruct = null;
    if (paramObject != null && paramObject instanceof TbStruct)
      tbStruct = (TbStruct)paramObject; 
    return tbStruct;
  }
  
  public String getSQLTypeName() throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public Object[] getAttributes() throws SQLException {
    return getStruct(this.outParams.subOutParam);
  }
  
  public Object[] getAttributes(Map<String, Class<?>> paramMap) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbStruct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */