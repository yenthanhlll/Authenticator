package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.comm.TbLobAccessor;
import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public abstract class TbLob {
  public static final int MAX_CHUNK_SIZE = 32000;
  
  public static final int MODE_READONLY = 0;
  
  public static final int MODE_READWRITE = 1;
  
  public static final int LOBLOC_LEN = 96;
  
  public static final int LOBLOC_DATA_APPENDED = 4;
  
  private TbConnection conn = null;
  
  private byte[] locator = null;
  
  private byte[] data = null;
  
  private boolean endOfStream = false;
  
  private boolean isEmpty = false;
  
  private boolean isDataAppendMode = false;
  
  public TbLob(TbConnection paramTbConnection, byte[] paramArrayOfbyte) {
    this.conn = paramTbConnection;
    if (paramArrayOfbyte.length == 1) {
      this.locator = paramArrayOfbyte;
      this.isEmpty = true;
    } else if ((paramArrayOfbyte[5] & 0x4) == 4) {
      this.locator = new byte[96];
      System.arraycopy(paramArrayOfbyte, 0, this.locator, 0, 96);
      int i = paramArrayOfbyte.length - 96;
      this.data = new byte[i];
      System.arraycopy(paramArrayOfbyte, 96, this.data, 0, i);
      this.isDataAppendMode = true;
    } else {
      this.locator = paramArrayOfbyte;
    } 
  }
  
  public void checkInvalidActionOnEmpty() throws SQLException {
    if (this.isEmpty)
      throw TbError.newSQLException(-90629); 
  }
  
  public void close() throws SQLException {
    checkInvalidActionOnEmpty();
    getLobAccessor().close(this);
  }
  
  public void free() throws SQLException {
    checkInvalidActionOnEmpty();
    getLobAccessor().freeTemporary(this);
  }
  
  public TbConnection getConnection() {
    return this.conn;
  }
  
  public byte[] getLobData() {
    return this.data;
  }
  
  public byte[] getLocator() {
    return this.locator;
  }
  
  protected abstract TbLobAccessor getLobAccessor();
  
  public int getLocatorLength() {
    return (this.locator == null) ? 0 : this.locator.length;
  }
  
  public boolean isEndOfStream() {
    return this.endOfStream;
  }
  
  public long length() throws SQLException {
    checkInvalidActionOnEmpty();
    return (this.isDataAppendMode == true) ? ((this.data == null) ? 0L : this.data.length) : getLobAccessor().length(this);
  }
  
  public void open(int paramInt) throws SQLException {
    checkInvalidActionOnEmpty();
    if (paramInt != 0 && paramInt != 1)
      throw TbError.newSQLException(-590769); 
    getLobAccessor().open(this, paramInt);
  }
  
  public long position(TbLob paramTbLob, long paramLong) throws SQLException {
    checkInvalidActionOnEmpty();
    if (paramLong < 1L)
      throw TbError.newSQLException(-590766, paramLong); 
    return getLobAccessor().position(this, paramTbLob, paramLong - 1L);
  }
  
  public void setEndOfStream(boolean paramBoolean) {
    this.endOfStream = paramBoolean;
  }
  
  public void setLocator(byte[] paramArrayOfbyte) {
    this.locator = paramArrayOfbyte;
  }
  
  public void truncate(long paramLong) throws SQLException {
    checkInvalidActionOnEmpty();
    if (paramLong < 0L)
      throw TbError.newSQLException(-590765, paramLong); 
    getLobAccessor().truncate(this, paramLong);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbLob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */