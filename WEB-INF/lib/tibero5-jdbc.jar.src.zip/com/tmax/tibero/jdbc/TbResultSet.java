package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.data.Column;
import com.tmax.tibero.jdbc.data.RsetType;
import com.tmax.tibero.jdbc.data.TbDate;
import com.tmax.tibero.jdbc.data.TbTimestamp;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;

public abstract class TbResultSet implements ResultSet {
  protected SQLWarning warnings = null;
  
  protected RsetType rsetType = RsetType.FWRD;
  
  protected int rowsFetchedCnt = 0;
  
  protected boolean haveLocator = false;
  
  protected TbResultSet(RsetType paramRsetType) {
    if (paramRsetType != null)
      this.rsetType = paramRsetType.getCopy(); 
  }
  
  public synchronized void addWarning(SQLWarning paramSQLWarning) {
    if (this.warnings != null) {
      this.warnings.setNextWarning(paramSQLWarning);
    } else {
      this.warnings = paramSQLWarning;
    } 
  }
  
  public abstract void buildRowTable(int paramInt, byte[] paramArrayOfbyte) throws SQLException;
  
  abstract void checkColumnIndex(int paramInt) throws SQLException;
  
  public synchronized void clearWarnings() throws SQLException {
    this.warnings = null;
  }
  
  public int getBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public abstract Column[] getCols() throws SQLException;
  
  abstract int getColumnCount() throws SQLException;
  
  protected abstract int getColumnDataType(int paramInt) throws SQLException;
  
  protected abstract int getColumnMaxLength(int paramInt) throws SQLException;
  
  protected abstract String getColumnName(int paramInt) throws SQLException;
  
  protected abstract boolean getColumnNullable(int paramInt) throws SQLException;
  
  protected abstract int getColumnPrecision(int paramInt) throws SQLException;
  
  protected abstract int getColumnScale(int paramInt) throws SQLException;
  
  protected abstract int getColumnSqlType(int paramInt) throws SQLException;
  
  public int getConcurrency() throws SQLException {
    return this.rsetType.getConcurrency();
  }
  
  public int getHoldability() throws SQLException {
    return this.rsetType.getHoldability();
  }
  
  public InputStream getLongByteStream(int paramInt) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public abstract ResultSetMetaData getMetaData() throws SQLException;
  
  public abstract byte[] getRowChunk(int paramInt) throws SQLException;
  
  public RsetType getRsetType() {
    return this.rsetType;
  }
  
  public int getType() throws SQLException {
    return this.rsetType.getType();
  }
  
  public long getUpdateCount() {
    return this.rowsFetchedCnt;
  }
  
  public abstract TbDate getTbDate(int paramInt) throws SQLException;
  
  public abstract TbTimestamp getTbTimestamp(int paramInt) throws SQLException;
  
  public abstract void updateTbTimestamp(int paramInt, TbTimestamp paramTbTimestamp) throws SQLException;
  
  public abstract void updateTbTimestamp(String paramString, TbTimestamp paramTbTimestamp) throws SQLException;
  
  public synchronized SQLWarning getWarnings() throws SQLException {
    return this.warnings;
  }
  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    return paramClass.isInstance(this);
  }
  
  protected void reset() {
    this.warnings = null;
    this.rsetType = null;
    this.rowsFetchedCnt = 0;
    this.haveLocator = true;
  }
  
  public abstract void setFetchCompleted(int paramInt) throws SQLException;
  
  public void setHaveLocator(boolean paramBoolean) {
    this.haveLocator = paramBoolean;
  }
  
  public void setRsetType(RsetType paramRsetType) {
    this.rsetType = paramRsetType;
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    try {
      return paramClass.cast(this);
    } catch (ClassCastException classCastException) {
      throw TbError.newSQLException(-90657);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */