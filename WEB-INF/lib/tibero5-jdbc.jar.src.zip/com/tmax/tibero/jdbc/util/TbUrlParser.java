package com.tmax.tibero.jdbc.util;

import com.tmax.tibero.DriverConstants;
import com.tmax.tibero.jdbc.data.ConnectionInfo;
import com.tmax.tibero.jdbc.data.NodeInfo;
import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class TbUrlParser {
  private static final int START = 0;
  
  private static final int DESCRIPTION = 1;
  
  private static final int FAILOVER = 2;
  
  private static final int LOAD_BALANCE = 3;
  
  private static final int PROTOCOL = 4;
  
  private static final int ADDRESS_LIST = 5;
  
  private static final int ADDRESS = 6;
  
  private static final int ACCEPT = 7;
  
  private static final int DATABASE_NAME = 8;
  
  private static final int ERROR = -1;
  
  private static final String KEYWORD_JDBC = "jdbc";
  
  private static final String KEYWORD_TIBERO = DriverConstants.JDBC_URL_BRAND_NAME;
  
  private static final String KEYWORD_THIN = "thin";
  
  private static final String KEYWORD_DEFAULT = "default";
  
  private static final String KEYWORD_CONNECTION = "connection";
  
  public static String makeURL(ConnectionInfo paramConnectionInfo) throws SQLException {
    StringBuffer stringBuffer = new StringBuffer("jdbc:" + KEYWORD_TIBERO);
    String str1 = paramConnectionInfo.getDriverType();
    if (str1 == null || str1.equals("")) {
      stringBuffer.append(":").append("thin");
      paramConnectionInfo.setDriverType("thin");
    } else {
      if (!str1.equals("thin"))
        throw TbError.newSQLException(-90605); 
      stringBuffer.append(":").append(str1);
    } 
    if (paramConnectionInfo.getNodeList() != null) {
      NodeInfo nodeInfo = paramConnectionInfo.getNodeList().get(0);
      String str = nodeInfo.getAddress();
      if (str == null || str.equals(""))
        throw TbError.newSQLException(-90605); 
      stringBuffer.append(":@").append(nodeInfo.getAddress());
      stringBuffer.append(":").append(nodeInfo.getPort());
    } 
    String str2 = paramConnectionInfo.getDatabaseName();
    if (str2 != null && !str2.equals(""))
      stringBuffer.append(":").append(paramConnectionInfo.getDatabaseName()); 
    return stringBuffer.substring(0, stringBuffer.length());
  }
  
  private static NodeInfo parseAddr(int paramInt, ParsingInfo paramParsingInfo) {
    int i = 8629;
    String str = "localhost";
    NodeInfo nodeInfo = null;
    while (paramParsingInfo.state == 6) {
      if (paramParsingInfo.startsWith(")")) {
        paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
        paramParsingInfo.state = 5;
        break;
      } 
      if (!paramParsingInfo.startsWith("(")) {
        paramParsingInfo.state = -1;
        break;
      } 
      paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
      if (paramParsingInfo.regionMatches(true, 0, "HOST", 0, "HOST".length())) {
        int j = "HOST".length();
        paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(j);
        str = parseHost(paramParsingInfo);
        continue;
      } 
      if (paramParsingInfo.regionMatches(true, 0, "PORT", 0, "PORT".length())) {
        int j = "PORT".length();
        paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(j);
        i = parsePort(paramParsingInfo);
        continue;
      } 
      paramParsingInfo.state = -1;
    } 
    if (paramParsingInfo.state != -1)
      nodeInfo = new NodeInfo(str, i, paramInt); 
    return nodeInfo;
  }
  
  public static ConnectionInfo parseDescription(String paramString1, Properties paramProperties, String paramString2) throws SQLException {
    byte b = 0;
    boolean bool1 = false;
    boolean bool2 = false;
    String str1 = "tcp";
    Vector<NodeInfo> vector = new Vector();
    String str2 = null;
    ParsingInfo parsingInfo = new ParsingInfo(null, 0);
    while (parsingInfo.state != 7) {
      int i;
      NodeInfo nodeInfo;
      switch (parsingInfo.state) {
        case 0:
          i = paramString2.indexOf('(');
          parsingInfo.scanStr = paramString2.substring(i + 1).trim();
          if (parsingInfo.regionMatches(true, 0, "DESCRIPTION", 0, "DESCRIPTION".length())) {
            i = "DESCRIPTION".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            if (!parsingInfo.startsWith("=")) {
              parsingInfo.state = -1;
              continue;
            } 
            parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
            parsingInfo.state = 1;
            continue;
          } 
          parsingInfo.state = -1;
        case 1:
          if (parsingInfo.startsWith(")")) {
            parsingInfo.state = 7;
            continue;
          } 
          if (!parsingInfo.startsWith("(")) {
            parsingInfo.state = -1;
            continue;
          } 
          parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
          if (parsingInfo.regionMatches(true, 0, "FAILOVER", 0, "FAILOVER".length())) {
            i = "FAILOVER".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            parsingInfo.state = 2;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "LOAD_BALANCE", 0, "LOAD_BALANCE".length())) {
            i = "LOAD_BALANCE".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            parsingInfo.state = 3;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "PROTOCOL", 0, "PROTOCOL".length())) {
            i = "PROTOCOL".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            parsingInfo.state = 4;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "ADDRESS_LIST", 0, "ADDRESS_LIST".length())) {
            i = "ADDRESS_LIST".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            if (!parsingInfo.startsWith("=")) {
              parsingInfo.state = -1;
              continue;
            } 
            parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
            parsingInfo.state = 5;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "ADDRESS", 0, "ADDRESS".length())) {
            i = "ADDRESS".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            parsingInfo.state = 6;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "DATABASE_NAME", 0, "DATABASE_NAME".length())) {
            i = "DATABASE_NAME".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            parsingInfo.state = 8;
            continue;
          } 
          parsingInfo.state = -1;
        case 2:
          bool1 = parseOnOff(parsingInfo);
        case 3:
          bool2 = parseOnOff(parsingInfo);
        case 4:
          str1 = parseProtocol(parsingInfo);
        case 5:
          if (parsingInfo.startsWith(")")) {
            parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
            parsingInfo.state = 1;
            continue;
          } 
          if (!parsingInfo.startsWith("(")) {
            parsingInfo.state = -1;
            continue;
          } 
          parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
          if (parsingInfo.regionMatches(true, 0, "PRIMARY", 0, "PRIMARY".length())) {
            i = "PRIMARY".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            if (!parsingInfo.startsWith("=")) {
              parsingInfo.state = -1;
              continue;
            } 
            parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
            b = 1;
            parsingInfo.state = 6;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "BACKUP", 0, "BACKUP".length())) {
            i = "BACKUP".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            if (!parsingInfo.startsWith("=")) {
              parsingInfo.state = -1;
              continue;
            } 
            parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
            b = 2;
            parsingInfo.state = 6;
            continue;
          } 
          if (parsingInfo.regionMatches(true, 0, "ADDRESS", 0, "ADDRESS".length())) {
            i = "ADDRESS".length();
            parsingInfo.scanStr = parsingInfo.substringWithTrim(i);
            if (!parsingInfo.startsWith("=")) {
              parsingInfo.state = -1;
              continue;
            } 
            parsingInfo.scanStr = parsingInfo.substringWithTrim(1);
            b = 0;
            parsingInfo.state = 6;
            continue;
          } 
          parsingInfo.state = -1;
        case 6:
          nodeInfo = parseAddr(b, parsingInfo);
          vector.add(nodeInfo);
        case 8:
          str2 = parseDatabaseName(parsingInfo);
        case -1:
          throw TbError.newSQLException(-90605);
      } 
    } 
    ConnectionInfo connectionInfo = new ConnectionInfo(paramProperties);
    connectionInfo.setURL(paramString1);
    connectionInfo.setFailOver(bool1);
    connectionInfo.setLoadBalance(bool2);
    connectionInfo.setNodeList(vector);
    connectionInfo.setNetworkProtocol(str1);
    if (str2 != null && str2.length() > 0)
      connectionInfo.setDatabaseName(str2); 
    return connectionInfo;
  }
  
  private static String parseHost(ParsingInfo paramParsingInfo) {
    if (!paramParsingInfo.startsWith("=")) {
      paramParsingInfo.state = -1;
      return null;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    byte b;
    for (b = 0; b < paramParsingInfo.scanStr.length() && ") \t\r\n\f".indexOf(paramParsingInfo.scanStr.charAt(b)) == -1; b++);
    String str = paramParsingInfo.scanStr.substring(0, b);
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(b);
    if (!paramParsingInfo.startsWith(")")) {
      paramParsingInfo.state = -1;
      return null;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    paramParsingInfo.state = 6;
    return str;
  }
  
  private static boolean parseOnOff(ParsingInfo paramParsingInfo) {
    if (!paramParsingInfo.startsWith("=")) {
      paramParsingInfo.state = -1;
      return false;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    if (paramParsingInfo.regionMatches(true, 0, "ON", 0, "ON".length())) {
      int i = "ON".length();
      paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(i);
      if (paramParsingInfo.startsWith(")")) {
        paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
        paramParsingInfo.state = 1;
        return true;
      } 
      paramParsingInfo.state = -1;
    } else if (paramParsingInfo.regionMatches(true, 0, "OFF", 0, "OFF".length())) {
      int i = "OFF".length();
      paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(i);
      if (paramParsingInfo.startsWith(")")) {
        paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
        paramParsingInfo.state = 1;
        return false;
      } 
      paramParsingInfo.state = -1;
    } else {
      paramParsingInfo.state = -1;
    } 
    return false;
  }
  
  private static int parsePort(ParsingInfo paramParsingInfo) {
    int i = -1;
    if (!paramParsingInfo.startsWith("=")) {
      paramParsingInfo.state = -1;
      return -1;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    byte b;
    for (b = 0; b < paramParsingInfo.scanStr.length() && ") \t\r\n\f".indexOf(paramParsingInfo.scanStr.charAt(b)) == -1; b++);
    try {
      i = Integer.parseInt(paramParsingInfo.scanStr.substring(0, b));
    } catch (NumberFormatException numberFormatException) {
      paramParsingInfo.state = -1;
      return -1;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(b);
    if (!paramParsingInfo.startsWith(")")) {
      paramParsingInfo.state = -1;
      return -1;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    paramParsingInfo.state = 6;
    return i;
  }
  
  private static String parseProtocol(ParsingInfo paramParsingInfo) {
    if (!paramParsingInfo.startsWith("=")) {
      paramParsingInfo.state = -1;
      return null;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    byte b;
    for (b = 0; b < paramParsingInfo.scanStr.length() && ") \t\r\n\f".indexOf(paramParsingInfo.scanStr.charAt(b)) == -1; b++);
    String str = paramParsingInfo.scanStr.substring(0, b);
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(b);
    if (!paramParsingInfo.startsWith(")")) {
      paramParsingInfo.state = -1;
      return null;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    paramParsingInfo.state = 1;
    return str;
  }
  
  private static String parseDatabaseName(ParsingInfo paramParsingInfo) {
    if (!paramParsingInfo.startsWith("=")) {
      paramParsingInfo.state = -1;
      return null;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    byte b;
    for (b = 0; b < paramParsingInfo.scanStr.length() && ") \t\r\n\f".indexOf(paramParsingInfo.scanStr.charAt(b)) == -1; b++);
    String str = paramParsingInfo.scanStr.substring(0, b);
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(b);
    if (!paramParsingInfo.startsWith(")")) {
      paramParsingInfo.state = -1;
      return null;
    } 
    paramParsingInfo.scanStr = paramParsingInfo.substringWithTrim(1);
    paramParsingInfo.state = 1;
    return str;
  }
  
  public static ConnectionInfo parseUrl(String paramString, Properties paramProperties) throws SQLException {
    if (paramString == null)
      throw TbError.newSQLException(-90605); 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":\n");
    int i = stringTokenizer.countTokens();
    if (i == 0) {
      ConnectionInfo connectionInfo = new ConnectionInfo(paramProperties);
      connectionInfo.setURL(makeURL(connectionInfo));
      return connectionInfo;
    } 
    if (i == 3) {
      if (!"jdbc".equals(stringTokenizer.nextToken()) || !"default".equals(stringTokenizer.nextToken()))
        throw TbError.newSQLException(-90605); 
      String str = stringTokenizer.nextToken();
      if (!"connection".equals(str))
        throw TbError.newSQLException(-90605); 
      ConnectionInfo connectionInfo = new ConnectionInfo();
      connectionInfo.setInternal(true);
      return connectionInfo;
    } 
    if (i >= 4) {
      int j = 8629;
      String str1 = "localhost";
      Properties properties = new Properties(paramProperties);
      if (!"jdbc".equals(stringTokenizer.nextToken()) || !KEYWORD_TIBERO.equals(stringTokenizer.nextToken()))
        throw TbError.newSQLException(-90605); 
      String str2 = stringTokenizer.nextToken();
      if (!"thin".equals(str2) && !"tbcli".equals(str2))
        throw TbError.newSQLException(-90605); 
      properties.setProperty("driverType", str2);
      String str3 = stringTokenizer.nextToken();
      if (str3.trim().length() == 0)
        throw TbError.newSQLException(-90605); 
      int k = str3.indexOf('/');
      int m = str3.indexOf('@');
      if (str3.trim().charAt(m + 1) == '(')
        return parseDescription(paramString, properties, str3); 
      if (m != -1) {
        str1 = str3.substring(m + 1);
        if (str1.trim().length() == 0)
          throw TbError.newSQLException(-90605); 
      } else {
        throw TbError.newSQLException(-90605);
      } 
      if (k != -1) {
        String str4 = str3.substring(0, k);
        String str5 = str3.substring(k + 1, m);
        if (str4.trim().length() == 0 && str5.trim().length() != 0)
          throw TbError.newSQLException(-90605); 
        properties.setProperty("user", str4);
        properties.setProperty("password", str5);
      } 
      if (i == 5) {
        String str = stringTokenizer.nextToken();
        if (str.trim().length() == 0)
          throw TbError.newSQLException(-90605); 
        try {
          j = Integer.parseInt(str);
        } catch (NumberFormatException numberFormatException) {
          properties.setProperty("databaseName", str);
        } 
      } else if (i == 6) {
        String str4 = stringTokenizer.nextToken();
        if (str4.trim().length() == 0)
          throw TbError.newSQLException(-90605); 
        try {
          j = Integer.parseInt(str4);
        } catch (NumberFormatException numberFormatException) {
          throw TbError.newSQLException(-90605);
        } 
        String str5 = stringTokenizer.nextToken();
        if (str5.trim().length() == 0)
          throw TbError.newSQLException(-90605); 
        properties.setProperty("databaseName", str5);
      } 
      ConnectionInfo connectionInfo = new ConnectionInfo(properties);
      connectionInfo.setURL(paramString);
      NodeInfo nodeInfo = new NodeInfo(str1, j, 0);
      Vector<NodeInfo> vector = new Vector();
      vector.add(nodeInfo);
      connectionInfo.setNodeList(vector);
      return connectionInfo;
    } 
    return null;
  }
  
  public static boolean isInternalUrl(String paramString) {
    if (paramString != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(paramString.trim(), ":\n");
      if (stringTokenizer.countTokens() == 3 && "jdbc".equals(stringTokenizer.nextToken()) && "default".equals(stringTokenizer.nextToken()) && "connection".equals(stringTokenizer.nextToken()))
        return true; 
    } 
    return false;
  }
  
  public static boolean isTiberoUrl(String paramString) {
    if (paramString == null)
      return false; 
    int i = paramString.indexOf(':');
    if (i == -1)
      return false; 
    int j = paramString.indexOf(':', i + 1);
    return (j == -1) ? false : paramString.regionMatches(true, i + 1, KEYWORD_TIBERO, 0, j - i - 1);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdb\\util\TbUrlParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */