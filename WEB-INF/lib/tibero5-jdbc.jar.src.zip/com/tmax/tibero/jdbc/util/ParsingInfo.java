package com.tmax.tibero.jdbc.util;

class ParsingInfo {
  String scanStr;
  
  int state;
  
  ParsingInfo(String paramString, int paramInt) {
    this.scanStr = paramString;
    this.state = paramInt;
  }
  
  boolean startsWith(String paramString) {
    return this.scanStr.startsWith(paramString);
  }
  
  String substringWithTrim(int paramInt) {
    return this.scanStr.substring(paramInt).trim();
  }
  
  boolean regionMatches(boolean paramBoolean, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    return this.scanStr.regionMatches(paramBoolean, paramInt1, paramString, paramInt2, paramInt3);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdb\\util\ParsingInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */