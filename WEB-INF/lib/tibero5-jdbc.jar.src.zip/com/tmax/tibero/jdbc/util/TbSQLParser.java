package com.tmax.tibero.jdbc.util;

import com.tmax.tibero.jdbc.data.BigLiteral;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;

public class TbSQLParser {
  private static String originalSql;
  
  private static int length;
  
  private static StringBuffer parsedSql;
  
  private static StringBuffer token;
  
  private static char chr;
  
  private static int index;
  
  private static int openParenCnt;
  
  private static boolean isLocate;
  
  private static boolean isString;
  
  private static final byte[] IDEOGRAPHIC_SPACE = new byte[] { -29, Byte.MIN_VALUE, Byte.MIN_VALUE };
  
  private static void appendFunctionName(String paramString) throws SQLException {
    parsedSql.append(paramString);
    skipWhitespace();
    processSQL();
  }
  
  private static void appendFunctionPrefix(String paramString) throws SQLException {
    skipWhitespace();
    if (index < length && (chr = originalSql.charAt(index)) == '(') {
      index++;
    } else {
      String str = new String(index + ": '(' is expected");
      throw TbError.newSQLException(-90632, str);
    } 
    parsedSql.append(paramString);
    skipWhitespace();
    processSQL();
  }
  
  private static void checkCurrentChar(char paramChar) throws SQLException {
    chr = originalSql.charAt(index - 1);
    if (chr != paramChar) {
      String str = new String(index + ": '" + paramChar + "' is expected");
      throw TbError.newSQLException(-90632, str);
    } 
  }
  
  public static String getBigLiteral(String paramString, int paramInt, ArrayList<BigLiteral> paramArrayList) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b1 = 0;
    byte b2 = 0;
    char[] arrayOfChar = new char[paramString.length() + 1];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    while (true) {
      if (arrayOfChar[b1] == '-' && arrayOfChar[b1 + 1] == '-') {
        stringBuffer.append(arrayOfChar[b1++]);
        stringBuffer.append(arrayOfChar[b1++]);
        while (arrayOfChar[b1] != '\n') {
          if (arrayOfChar[b1] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b1++]);
        } 
        stringBuffer.append(arrayOfChar[b1++]);
        continue;
      } 
      if (arrayOfChar[b1] == '"') {
        stringBuffer.append(arrayOfChar[b1++]);
        while (arrayOfChar[b1] != '"') {
          if (arrayOfChar[b1] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b1++]);
        } 
        stringBuffer.append(arrayOfChar[b1++]);
        continue;
      } 
      if (arrayOfChar[b1] == '\'') {
        byte b = ++b1;
        StringBuffer stringBuffer1 = new StringBuffer();
        while (arrayOfChar[b1] != '\'') {
          if (arrayOfChar[b1] == '\000') {
            stringBuffer.append('\'');
            stringBuffer.append(stringBuffer1);
            return stringBuffer.toString();
          } 
          stringBuffer1.append(arrayOfChar[b1++]);
        } 
        if (b1 - b > 65535 / paramInt) {
          BigLiteral bigLiteral = new BigLiteral(b2++, paramString.substring(b, b1));
          paramArrayList.add(bigLiteral);
          stringBuffer.append('?');
        } else {
          stringBuffer.append('\'');
          stringBuffer.append(stringBuffer1);
          stringBuffer.append('\'');
        } 
        b1++;
        continue;
      } 
      if (arrayOfChar[b1] == '/' && arrayOfChar[b1 + 1] == '*') {
        stringBuffer.append(arrayOfChar[b1++]);
        stringBuffer.append(arrayOfChar[b1++]);
        while (true) {
          if (arrayOfChar[b1] != '*' || arrayOfChar[b1 + 1] != '/') {
            if (arrayOfChar[b1] == '\000')
              return stringBuffer.toString(); 
            stringBuffer.append(arrayOfChar[b1++]);
            continue;
          } 
          stringBuffer.append(arrayOfChar[b1++]);
          stringBuffer.append(arrayOfChar[b1++]);
        } 
        break;
      } 
      if (arrayOfChar[b1] == '\000')
        return stringBuffer.toString(); 
      if (arrayOfChar[b1] == '?' || (arrayOfChar[b1] == ':' && arrayOfChar[b1 + 1] != '=')) {
        stringBuffer.append(arrayOfChar[b1++]);
        b2++;
        continue;
      } 
      stringBuffer.append(arrayOfChar[b1++]);
    } 
  }
  
  public static int getParamCount(String paramString, int paramInt) {
    byte b1 = 0;
    byte b2 = 0;
    boolean bool = false;
    char[] arrayOfChar = new char[paramString.length() + 1];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    while (true) {
      if (arrayOfChar[b1] == '-' && arrayOfChar[b1 + 1] == '-') {
        for (b1 += 2; arrayOfChar[b1] != '\n'; b1++) {
          if (arrayOfChar[b1] == '\000')
            return b2; 
        } 
        b1++;
        continue;
      } 
      if (arrayOfChar[b1] == '"') {
        while (arrayOfChar[++b1] != '"') {
          if (arrayOfChar[b1] == '\000')
            return b2; 
          b1++;
        } 
        b1++;
        continue;
      } 
      if (arrayOfChar[b1] == '\'') {
        while (arrayOfChar[++b1] != '\'') {
          if (arrayOfChar[b1] == '\000')
            return b2; 
          b1++;
        } 
        b1++;
        continue;
      } 
      if (arrayOfChar[b1] == '/' && arrayOfChar[b1 + 1] == '*') {
        for (b1 += 2;; b1 += 2) {
          if (arrayOfChar[b1] != '*' || arrayOfChar[b1 + 1] != '/') {
            if (arrayOfChar[b1] == '\000')
              return b2; 
            b1++;
            continue;
          } 
        } 
        break;
      } 
      if ((!TbSQLTypeScanner.isPSMStmt(paramInt) && paramString.regionMatches(true, b1, "returning", 0, 9)) || bool) {
        byte b = b1;
        if (!bool) {
          b1 += 9;
          b = b1;
        } 
        while (arrayOfChar[b1] != ';') {
          if (arrayOfChar[b1] == '\000')
            return b2; 
          if (!bool && paramString.regionMatches(true, b1, "into", 0, 3)) {
            bool = true;
            b1 = b;
            break;
          } 
          b1++;
        } 
        b1++;
        if (!bool)
          continue; 
      } 
      if (arrayOfChar[b1] == '\000')
        return b2; 
      if (arrayOfChar[b1] == '?' || (arrayOfChar[b1] == ':' && arrayOfChar[b1 + 1] != '='))
        b2++; 
      b1++;
    } 
  }
  
  public static String[] getParamNames(String paramString) {
    byte b = 0;
    char[] arrayOfChar = new char[paramString.length() + 1];
    ArrayList<String> arrayList = new ArrayList();
    StringBuffer stringBuffer = new StringBuffer();
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    label69: while (true) {
      if (arrayOfChar[b] == '-' && arrayOfChar[b + 1] == '-') {
        for (b += 2; arrayOfChar[b] != '\n'; b++) {
          if (arrayOfChar[b] == '\000')
            return (String[])arrayList.toArray((Object[])new String[0]); 
        } 
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '"') {
        while (arrayOfChar[++b] != '"') {
          if (arrayOfChar[b] == '\000')
            return (String[])arrayList.toArray((Object[])new String[0]); 
          b++;
        } 
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '\'') {
        while (arrayOfChar[++b] != '\'') {
          if (arrayOfChar[b] == '\000')
            return (String[])arrayList.toArray((Object[])new String[0]); 
          b++;
        } 
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '/' && arrayOfChar[b + 1] == '*') {
        for (b += 2;; b += 2) {
          if (arrayOfChar[b] != '*' || arrayOfChar[b + 1] != '/') {
            if (arrayOfChar[b] == '\000')
              return (String[])arrayList.toArray((Object[])new String[0]); 
            b++;
            continue;
          } 
        } 
        break;
      } 
      if (arrayOfChar[b] == '\000')
        return (String[])arrayList.toArray((Object[])new String[0]); 
      if (arrayOfChar[b] == '?') {
        arrayList.add("?");
      } else if (arrayOfChar[b] == ':' && arrayOfChar[b + 1] != '=') {
        b++;
        stringBuffer.delete(0, stringBuffer.length());
        while (true) {
          if (arrayOfChar[b] == '\000')
            return arrayList.<String>toArray(new String[0]); 
          if (Character.isLetterOrDigit(arrayOfChar[b]) || arrayOfChar[b] == '_') {
            stringBuffer.append(arrayOfChar[b]);
          } else {
            if (stringBuffer.length() > 0) {
              arrayList.add(stringBuffer.toString());
              continue label69;
            } 
            continue label69;
          } 
          b++;
        } 
        break;
      } 
      b++;
    } 
  }
  
  public static String getRowIdAddedRefetchSql(String paramString, int paramInt) throws SQLException {
    if (paramString == null)
      throw TbError.newSQLException(-90608, "null"); 
    if (paramInt <= 0)
      return paramString; 
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("select * from (").append(paramString).append(") ");
    if (paramInt > 0)
      stringBuffer.append(" WHERE ROWID = ? "); 
    for (byte b = 1; b < paramInt; b++)
      stringBuffer.append(" OR ROWID = ? "); 
    return stringBuffer.toString();
  }
  
  public static String getRowIdAddedSelectSql(String paramString) throws SQLException {
    if (paramString == null)
      throw TbError.newSQLException(-90608, "null"); 
    String str = paramString.toUpperCase();
    int i = str.indexOf("SELECT");
    if (i == -1)
      return null; 
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SELECT ROWID,").append(paramString.substring(6 + i));
    return stringBuffer.toString();
  }
  
  private static void init() {
    index = 0;
    openParenCnt = 0;
    isString = false;
    isLocate = false;
  }
  
  private static void makeToken() {
    while (index < length && (Character.isJavaIdentifierPart(chr = originalSql.charAt(index)) || chr == '?')) {
      token.append(chr);
      index++;
    } 
  }
  
  public static synchronized String parse(String paramString) throws SQLException {
    init();
    parsedSql = new StringBuffer(paramString.length());
    token = new StringBuffer(32);
    originalSql = paramString;
    length = originalSql.length();
    processSQL();
    return parsedSql.substring(0, parsedSql.length());
  }
  
  private static void processCall() throws SQLException {
    parsedSql.append("CALL");
    processSQL();
  }
  
  private static void processDate() throws SQLException {
    parsedSql.append("TO_DATE (");
    skipWhitespace();
    processSQL();
    parsedSql.append(", 'YYYY-MM-DD')");
  }
  
  private static void processEscape() throws SQLException {
    parsedSql.append("ESCAPE ");
    skipWhitespace();
    processSQL();
  }
  
  private static void processFunction() throws SQLException {
    parsedSql.append("?");
    processSQL();
  }
  
  private static void processOuterJoin() throws SQLException {
    parsedSql.append(" ( ");
    skipWhitespace();
    processSQL();
    parsedSql.append(" ) ");
  }
  
  private static void processScalarFunction() throws SQLException {
    token.delete(0, token.length());
    skipWhitespace();
    makeToken();
    String str = token.substring(0, token.length()).toUpperCase().intern();
    if (str == "ABS") {
      appendFunctionName(str);
    } else if (str == "ACOS") {
      appendFunctionName(str);
    } else if (str == "ASIN") {
      appendFunctionName(str);
    } else if (str == "ATAN") {
      appendFunctionName(str);
    } else if (str == "ATAN2") {
      appendFunctionName(str);
    } else if (str == "CEILING") {
      appendFunctionName("CEIL");
    } else if (str == "COS") {
      appendFunctionName(str);
    } else if (str == "EXP") {
      appendFunctionName(str);
    } else if (str == "FLOOR") {
      appendFunctionName(str);
    } else if (str == "LOG") {
      appendFunctionName("LN");
    } else if (str == "LOG10") {
      appendFunctionPrefix("LOG ( 10, ");
    } else if (str.equals("MOD")) {
      appendFunctionName(str);
    } else if (str == "PI") {
      appendFunctionPrefix("( 3.141592653589793238462643383279502884197169399375 ");
    } else if (str == "POWER") {
      appendFunctionName(str);
    } else if (str == "ROUND") {
      appendFunctionName(str);
    } else if (str == "SIGN") {
      appendFunctionName(str);
    } else if (str == "SIN") {
      appendFunctionName(str);
    } else if (str == "SQRT") {
      appendFunctionName(str);
    } else if (str == "TAN") {
      appendFunctionName(str);
    } else if (str == "TRUNCATE") {
      appendFunctionName("TRUNC");
    } else if (str == "ASCII") {
      appendFunctionName(str);
    } else if (str == "CHAR") {
      appendFunctionName("CHR");
    } else if (str == "CONCAT") {
      appendFunctionName(str);
    } else if (str == "LCASE") {
      appendFunctionName("LOWER");
    } else if (str == "LENGTH") {
      appendFunctionName(str);
    } else if (str == "LOCATE") {
      isLocate = true;
      appendFunctionName("INSTR");
    } else if (str == "LTRIM") {
      appendFunctionName(str);
    } else if (str.equals("REPLACE")) {
      appendFunctionName(str);
    } else if (str == "RTRIM") {
      appendFunctionName(str);
    } else if (str == "SUBSTRING") {
      appendFunctionName("SUBSTR");
    } else if (str == "UCASE") {
      appendFunctionName("UPPER");
    } else if (str == "CURDATE") {
      appendFunctionPrefix("(CURRENT_DATE");
    } else if (str == "CURTIME") {
      appendFunctionPrefix("(CURRENT_TIMESTAMP");
    } else if (str == "DAYOFMONTH") {
      appendFunctionPrefix("EXTRACT ( DAY FROM ");
    } else if (str == "HOUR") {
      appendFunctionPrefix("EXTRACT ( HOUR FROM ");
    } else if (str == "MINUTE") {
      appendFunctionPrefix("EXTRACT ( MINUTE FROM ");
    } else if (str == "MONTH") {
      appendFunctionPrefix("EXTRACT ( MONTH FROM ");
    } else if (str == "NOW") {
      appendFunctionPrefix("(CURRENT_TIMESTAMP");
    } else if (str == "SECOND") {
      appendFunctionPrefix("EXTRACT ( SECOND FROM ");
    } else if (str == "YEAR") {
      appendFunctionPrefix("EXTRACT ( YEAR FROM ");
    } else if (str == "USER") {
      appendFunctionPrefix("(USER");
    } else {
      String str1 = new String("unsuppoted SQL92 Token: \"" + str + "\"");
      throw TbError.newSQLException(-90632, str1);
    } 
  }
  
  private static void processSQL() throws SQLException {
    StringBuffer stringBuffer1 = null;
    StringBuffer stringBuffer2 = null;
    boolean bool = false;
    label65: while (index < length) {
      chr = originalSql.charAt(index++);
      char c = Character.MIN_VALUE;
      if (isString) {
        parsedSql.append(chr);
        if (chr == '\'')
          isString = false; 
        continue;
      } 
      switch (chr) {
        case '\'':
          if (isLocate) {
            if (stringBuffer1 == null) {
              stringBuffer1 = new StringBuffer();
              stringBuffer2 = new StringBuffer();
            } 
            if (!bool) {
              stringBuffer1.append(chr);
              continue;
            } 
            stringBuffer2.append(chr);
            continue;
          } 
          parsedSql.append(chr);
          isString = true;
          continue;
        case '{':
          openParenCnt++;
          token.delete(0, token.length());
          skipWhitespace();
          makeToken();
          processToken();
          checkCurrentChar('}');
          continue;
        case '}':
          openParenCnt--;
          if (openParenCnt < 0) {
            String str = new String(index + ": Unnecessary '" + chr + "' exists");
            throw TbError.newSQLException(-90632, str);
          } 
          return;
      } 
      if (index < length)
        c = originalSql.charAt(index); 
      if (chr == '/' && c == '*') {
        parsedSql.append(chr);
        parsedSql.append(c);
        while (true) {
          index++;
          chr = originalSql.charAt(index);
          c = originalSql.charAt(index + 1);
          parsedSql.append(chr);
          if (chr == '*' && c == '/')
            continue label65; 
        } 
      } 
      if (chr == '-' && c == '-') {
        parsedSql.append(chr);
        parsedSql.append(c);
        index++;
        while (index < length && (chr = originalSql.charAt(index)) != '\n') {
          parsedSql.append(chr);
          index++;
        } 
        continue;
      } 
      if (isLocate && chr != ' ' && chr != '(') {
        if (chr == ')') {
          parsedSql.append(stringBuffer2);
          parsedSql.append(", ");
          parsedSql.append(stringBuffer1);
          parsedSql.append(chr);
          isLocate = false;
        } 
        if (stringBuffer1 == null) {
          stringBuffer1 = new StringBuffer();
          stringBuffer2 = new StringBuffer();
        } 
        if (chr == ',') {
          bool = true;
          continue;
        } 
        if (!bool) {
          stringBuffer1.append(chr);
          continue;
        } 
        stringBuffer2.append(chr);
        continue;
      } 
      parsedSql.append(chr);
    } 
  }
  
  private static void processTime() throws SQLException {
    parsedSql.append("TO_DATE (");
    skipWhitespace();
    processSQL();
    parsedSql.append(", 'HH24:MI:SS')");
  }
  
  private static void processTimestamp() throws SQLException {
    parsedSql.append("TO_TIMESTAMP (");
    skipWhitespace();
    processSQL();
    parsedSql.append(", 'YYYY-MM-DD HH24:MI:SS.FF')");
  }
  
  private static void processToken() throws SQLException {
    String str = token.substring(0, token.length());
    if (str.equalsIgnoreCase("?")) {
      processFunction();
    } else if (str.equalsIgnoreCase("CALL")) {
      processCall();
    } else if (str.equalsIgnoreCase("TS")) {
      processTimestamp();
    } else if (str.equalsIgnoreCase("T")) {
      processTime();
    } else if (str.equalsIgnoreCase("D")) {
      processDate();
    } else if (str.equalsIgnoreCase("ESCAPE")) {
      processEscape();
    } else if (str.equalsIgnoreCase("FN")) {
      processScalarFunction();
    } else if (str.equalsIgnoreCase("OJ")) {
      processOuterJoin();
    } else {
      String str1 = new String(index + ": \"" + token + "\" token is not supported");
      throw TbError.newSQLException(-90632, str1);
    } 
  }
  
  public static String replace(String paramString) {
    byte b = 0;
    char[] arrayOfChar = new char[paramString.length() + 1];
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    while (true) {
      if (arrayOfChar[b] == '-' && arrayOfChar[b + 1] == '-') {
        stringBuffer.append(arrayOfChar[b]);
        stringBuffer.append(arrayOfChar[b + 1]);
        for (b += 2; arrayOfChar[b] != '\n'; b++) {
          if (arrayOfChar[b] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b]);
        } 
        stringBuffer.append(arrayOfChar[b]);
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '"') {
        stringBuffer.append(arrayOfChar[b]);
        while (arrayOfChar[++b] != '"') {
          if (arrayOfChar[b] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b]);
          b++;
        } 
        stringBuffer.append(arrayOfChar[b]);
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '\'') {
        stringBuffer.append(arrayOfChar[b]);
        while (arrayOfChar[++b] != '\'') {
          if (arrayOfChar[b] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b]);
          b++;
        } 
        stringBuffer.append(arrayOfChar[b]);
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '/' && arrayOfChar[b + 1] == '*') {
        stringBuffer.append(arrayOfChar[b]);
        stringBuffer.append(arrayOfChar[b + 1]);
        for (b += 2;; b += 2) {
          if (arrayOfChar[b] != '*' || arrayOfChar[b + 1] != '/') {
            if (arrayOfChar[b] == '\000')
              return stringBuffer.toString(); 
            stringBuffer.append(arrayOfChar[b]);
            b++;
            continue;
          } 
          stringBuffer.append(arrayOfChar[b]);
          stringBuffer.append(arrayOfChar[b + 1]);
        } 
        break;
      } 
      if (arrayOfChar[b] == '\000')
        return stringBuffer.toString(); 
      if (arrayOfChar[b] == '?' && Character.isDigit(arrayOfChar[b + 1])) {
        byte b1 = b;
        for (b += 2; Character.isDigit(arrayOfChar[b]); b++);
        if (Character.isLetter(arrayOfChar[b])) {
          stringBuffer.append(paramString.substring(b1, b));
          continue;
        } 
        stringBuffer.append(":");
        stringBuffer.append(paramString.substring(b1 + 1, b));
        continue;
      } 
      stringBuffer.append(arrayOfChar[b]);
      b++;
    } 
  }
  
  public static String replaceIDEOGraphicSpace(String paramString) {
    char c;
    try {
      c = (new String(IDEOGRAPHIC_SPACE, "utf8")).charAt(0);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      return paramString;
    } 
    if (paramString == null || paramString.indexOf(c) < 0)
      return paramString; 
    byte b = 0;
    char[] arrayOfChar = new char[paramString.length() + 1];
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    while (true) {
      if (arrayOfChar[b] == '-' && arrayOfChar[b + 1] == '-') {
        stringBuffer.append(arrayOfChar[b]);
        stringBuffer.append(arrayOfChar[b + 1]);
        for (b += 2; arrayOfChar[b] != '\n'; b++) {
          if (arrayOfChar[b] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b]);
        } 
        stringBuffer.append(arrayOfChar[b]);
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '"') {
        stringBuffer.append(arrayOfChar[b]);
        while (arrayOfChar[++b] != '"') {
          if (arrayOfChar[b] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b]);
          b++;
        } 
        stringBuffer.append(arrayOfChar[b]);
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '\'') {
        stringBuffer.append(arrayOfChar[b]);
        while (arrayOfChar[++b] != '\'') {
          if (arrayOfChar[b] == '\000')
            return stringBuffer.toString(); 
          stringBuffer.append(arrayOfChar[b]);
          b++;
        } 
        stringBuffer.append(arrayOfChar[b]);
        b++;
        continue;
      } 
      if (arrayOfChar[b] == '/' && arrayOfChar[b + 1] == '*') {
        stringBuffer.append(arrayOfChar[b]);
        stringBuffer.append(arrayOfChar[b + 1]);
        for (b += 2;; b += 2) {
          if (arrayOfChar[b] != '*' || arrayOfChar[b + 1] != '/') {
            if (arrayOfChar[b] == '\000')
              return stringBuffer.toString(); 
            stringBuffer.append(arrayOfChar[b]);
            b++;
            continue;
          } 
          stringBuffer.append(arrayOfChar[b]);
          stringBuffer.append(arrayOfChar[b + 1]);
        } 
        break;
      } 
      if (arrayOfChar[b] == '\000')
        return stringBuffer.toString(); 
      if (arrayOfChar[b] == c) {
        stringBuffer.append(" ");
        b++;
        continue;
      } 
      stringBuffer.append(arrayOfChar[b]);
      b++;
    } 
  }
  
  private static void skipWhitespace() {
    while (index < length) {
      chr = originalSql.charAt(index);
      if (chr != ' ' && chr != '\t' && chr != '\r' && chr != '\n')
        break; 
      parsedSql.append(chr);
      index++;
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdb\\util\TbSQLParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */