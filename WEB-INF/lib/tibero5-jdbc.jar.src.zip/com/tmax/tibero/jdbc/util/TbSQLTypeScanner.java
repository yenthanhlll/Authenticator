package com.tmax.tibero.jdbc.util;

public class TbSQLTypeScanner {
  private static final char NULL = '\000';
  
  private static final int STATE_START = 0;
  
  private static final int STATE_1 = 1;
  
  private static final int STATE_2 = 2;
  
  private static final int STATE_3 = 3;
  
  private static final int STATE_4 = 4;
  
  private static final int STATE_5 = 5;
  
  private static final int STATE_6 = 6;
  
  private static final int STATE_DONE = 10;
  
  public static final int STMT_UNKNOWN = 0;
  
  public static final int STMT_QUERY = 16;
  
  public static final int STMT_DML = 32;
  
  public static final int STMT_DML_DELETE = 33;
  
  public static final int STMT_DML_UPDATE = 34;
  
  public static final int STMT_DML_INSERT = 36;
  
  public static final int STMT_DML_MERGE = 40;
  
  public static final int STMT_PSM = 64;
  
  public static final int STMT_PSM_BEGIN = 65;
  
  public static final int STMT_PSM_CALL = 66;
  
  public static final int STMT_PSM_DECLARE = 68;
  
  private int state;
  
  private int index;
  
  private int textLen;
  
  private String text;
  
  public int getCurrentIndex() {
    return this.index;
  }
  
  private char getNextChar() {
    return (this.index < this.textLen) ? this.text.charAt(this.index++) : Character.MIN_VALUE;
  }
  
  public synchronized int getSQLType(String paramString) {
    this.index = 0;
    this.textLen = paramString.length();
    this.text = paramString;
    String str = getToken();
    if (str.equals("("))
      str = getToken(); 
    return str.equals("SELECT") ? 16 : (str.equals("DELETE") ? 33 : (str.equals("INSERT") ? 36 : (str.equals("UPDATE") ? 34 : (str.equals("MERGE") ? 40 : (str.equals("BEGIN") ? 65 : (str.equals("DECLARE") ? 68 : (str.equals("CALL") ? 66 : 0)))))));
  }
  
  private String getToken() {
    this.state = 0;
    StringBuffer stringBuffer = new StringBuffer(32);
    while (this.state != 10) {
      char c = getNextChar();
      boolean bool = true;
      switch (this.state) {
        case 0:
          switch (c) {
            case '/':
              this.state = 1;
              break;
            case '-':
              this.state = 4;
              break;
            case '\'':
              this.state = 6;
              break;
            case '(':
            case ')':
              if (stringBuffer.length() > 0) {
                this.state = 10;
                bool = false;
                ungetNextChar();
                break;
              } 
              this.state = 10;
              bool = true;
              break;
            case '\t':
            case '\n':
            case '\r':
            case ' ':
              if (stringBuffer.length() > 0)
                this.state = 10; 
              bool = false;
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          break;
        case 1:
          switch (c) {
            case '*':
              this.state = 2;
              bool = false;
              stringBuffer.delete(stringBuffer.length() - 1, stringBuffer.length());
              break;
            case '(':
            case ')':
              this.state = 10;
              bool = false;
              ungetNextChar();
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          this.state = 0;
          break;
        case 2:
          switch (c) {
            case '*':
              this.state = 3;
              bool = false;
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          bool = false;
          break;
        case 3:
          switch (c) {
            case '*':
              bool = false;
              break;
            case '/':
              this.state = 0;
              bool = false;
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          this.state = 2;
          bool = false;
          break;
        case 4:
          switch (c) {
            case '-':
              this.state = 5;
              bool = false;
              stringBuffer.delete(stringBuffer.length() - 1, stringBuffer.length());
              break;
            case '(':
            case ')':
              this.state = 10;
              bool = false;
              ungetNextChar();
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          this.state = 0;
          break;
        case 5:
          switch (c) {
            case '\n':
            case '\r':
              this.state = 0;
              ungetNextChar();
              bool = false;
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          bool = false;
          break;
        case 6:
          switch (c) {
            case '\'':
              this.state = 0;
              break;
            case '\000':
              this.state = 10;
              bool = false;
              break;
          } 
          break;
      } 
      if (bool)
        stringBuffer.append(c); 
    } 
    return stringBuffer.substring(0, stringBuffer.length()).toUpperCase();
  }
  
  private void ungetNextChar() {
    this.index--;
  }
  
  public static boolean isDMLStmt(int paramInt) {
    return ((paramInt & 0x20) > 0);
  }
  
  public static boolean isPSMStmt(int paramInt) {
    return ((paramInt & 0x40) > 0);
  }
  
  public static boolean isQueryStmt(int paramInt) {
    return ((paramInt & 0x10) > 0);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdb\\util\TbSQLTypeScanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */