package com.tmax.tibero.jdbc;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class TbXMLOutputStream extends ByteArrayOutputStream {
  public ByteArrayInputStream getInputStream() {
    return new ByteArrayInputStream(this.buf, 0, this.count);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbXMLOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */