package com.tmax.tibero.jdbc.comm;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.data.ConnectionInfo;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import com.tmax.tibero.jdbc.data.StreamBuffer;
import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.msg.TbMsgFactory;
import com.tmax.tibero.jdbc.msg.common.TbMsg;
import com.tmax.tibero.jdbc.util.TbCommon;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class TbStream {
  private Socket socket;
  
  private TbConnection conn;
  
  private InputStream input;
  
  private OutputStream output;
  
  private String host;
  
  private int port;
  
  private int tduSize = 0;
  
  private int msgType;
  
  private int msgBodySize = 0;
  
  private StreamBuffer readBuf;
  
  private StreamBuffer writeBuf;
  
  private TbStreamDataReader reader;
  
  private TbStreamDataWriter writer;
  
  private StreamBuffer dplBuf;
  
  private TbStreamDataWriter dplWriter;
  
  private boolean bufWriting;
  
  public TbStream(TbConnection paramTbConnection, Socket paramSocket, DataTypeConverter paramDataTypeConverter, ConnectionInfo paramConnectionInfo) throws SQLException {
    try {
      this.conn = paramTbConnection;
      initTCP(paramSocket, paramDataTypeConverter, paramConnectionInfo);
    } catch (ConnectException connectException) {
      throw TbError.newSQLException(-90401, connectException.getMessage());
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90400, iOException.getMessage());
    } 
  }
  
  public TbStream(TbConnection paramTbConnection, String paramString, int paramInt, DataTypeConverter paramDataTypeConverter, ConnectionInfo paramConnectionInfo) throws SQLException {
    try {
      this.conn = paramTbConnection;
      this.host = paramString;
      this.port = paramInt;
      if (paramConnectionInfo.getNetworkProtocol().equalsIgnoreCase("TCPS")) {
        initTCPS(paramDataTypeConverter, paramConnectionInfo);
      } else {
        Socket socket = new Socket();
        InetSocketAddress inetSocketAddress = (this.host != null) ? new InetSocketAddress(paramString, paramInt) : new InetSocketAddress(InetAddress.getByName(null), paramInt);
        socket.connect(inetSocketAddress, paramConnectionInfo.getLoginTimeout());
        initTCP(socket, paramDataTypeConverter, paramConnectionInfo);
      } 
    } catch (ConnectException connectException) {
      throw TbError.newSQLException(-90401, connectException.getMessage());
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90400, iOException.getMessage());
    } 
  }
  
  public void close() throws SQLException {
    try {
      reset();
      IOException iOException = null;
      try {
        if (this.input != null)
          this.input.close(); 
      } catch (IOException iOException1) {
        iOException = iOException1;
      } 
      try {
        if (this.output != null)
          this.output.close(); 
      } catch (IOException iOException1) {
        iOException = iOException1;
      } 
      try {
        if (this.socket != null && !this.conn.info.isInternal())
          this.socket.close(); 
      } catch (IOException iOException1) {
        iOException = iOException1;
      } 
      if (iOException != null)
        throw iOException; 
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90409, iOException.getMessage());
    } 
  }
  
  public TbStreamDataWriter createDirPathWriter(int paramInt) {
    if (this.dplBuf == null) {
      this.dplBuf = new StreamBuffer(paramInt);
    } else if (paramInt != this.dplBuf.getSize()) {
      this.dplBuf.resize(paramInt);
    } 
    if (this.dplWriter == null)
      this.dplWriter = new TbStreamDataWriter(this.dplBuf); 
    return this.dplWriter;
  }
  
  public void flush() throws SQLException {
    flushInternal(this.writeBuf);
  }
  
  public void flush(TbStreamDataWriter paramTbStreamDataWriter) throws SQLException {
    synchronized (this.writeBuf) {
      flushInternal(paramTbStreamDataWriter.getStreamBuf());
    } 
  }
  
  private void flushInternal(StreamBuffer paramStreamBuffer) throws SQLException {
    try {
      this.bufWriting = true;
      if (paramStreamBuffer.getCurDataSize() > 0) {
        this.output.write(paramStreamBuffer.getRawBytes(), 0, paramStreamBuffer.getCurDataSize());
        this.output.flush();
      } 
      this.bufWriting = false;
    } catch (IOException iOException) {
      this.bufWriting = false;
      this.conn.reconnect();
      throw TbError.newSQLException(-90406, iOException.getMessage());
    } 
  }
  
  public int getMsgType() {
    return this.msgType;
  }
  
  public TbStreamDataWriter getMsgWriter() {
    return this.writer;
  }
  
  public StreamBuffer getReadStreamBuffer() {
    return this.readBuf;
  }
  
  public StreamBuffer getWriteStreamBuffer() {
    return this.writeBuf;
  }
  
  public void handshakeSSL() throws SQLException {
    try {
      InetSocketAddress inetSocketAddress = new InetSocketAddress(this.host, this.port);
      this.socket.connect(inetSocketAddress, 0);
      ((SSLSocket)this.socket).setUseClientMode(true);
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90400, iOException.getMessage());
    } 
  }
  
  private void initTCP(Socket paramSocket, DataTypeConverter paramDataTypeConverter, ConnectionInfo paramConnectionInfo) throws IOException {
    this.socket = paramSocket;
    this.socket.setTcpNoDelay(true);
    this.socket.setKeepAlive(paramConnectionInfo.isFailOver());
    this.socket.setSoTimeout(paramConnectionInfo.getLoginTimeout());
    this.input = paramSocket.getInputStream();
    this.output = paramSocket.getOutputStream();
    this.tduSize = paramConnectionInfo.getTDU();
    this.readBuf = new StreamBuffer(this.tduSize);
    this.writeBuf = new StreamBuffer(this.tduSize);
    this.reader = new TbStreamDataReader(this.readBuf, paramDataTypeConverter);
    this.writer = new TbStreamDataWriter(this.writeBuf, paramDataTypeConverter);
    this.bufWriting = false;
  }
  
  private void initTCPS(DataTypeConverter paramDataTypeConverter, ConnectionInfo paramConnectionInfo) throws IOException {
    try {
      SSLContext sSLContext = SSLContext.getInstance("SSLv23");
      SSLSocketFactory sSLSocketFactory = sSLContext.getSocketFactory();
      this.socket = sSLSocketFactory.createSocket();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new IOException(noSuchAlgorithmException.getMessage());
    } 
    this.socket.setTcpNoDelay(true);
    this.socket.setKeepAlive(paramConnectionInfo.isFailOver());
    this.socket.setSoTimeout(paramConnectionInfo.getLoginTimeout());
    this.input = this.socket.getInputStream();
    this.output = this.socket.getOutputStream();
    this.tduSize = paramConnectionInfo.getTDU();
    this.readBuf = new StreamBuffer(this.tduSize);
    this.writeBuf = new StreamBuffer(this.tduSize);
    this.reader = new TbStreamDataReader(this.readBuf, paramDataTypeConverter);
    this.writer = new TbStreamDataWriter(this.writeBuf, paramDataTypeConverter);
    this.bufWriting = false;
  }
  
  public void readChunkData(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
    synchronized (this.readBuf) {
      if (readNBytes(paramArrayOfbyte, 0, paramInt) != paramInt)
        throw TbError.newSQLException(-590729); 
      this.msgBodySize = 0;
    } 
  }
  
  public TbMsg readMsg() throws SQLException {
    TbMsg tbMsg = null;
    synchronized (this.readBuf) {
      byte[] arrayOfByte = new byte[16];
      readNBytes(arrayOfByte, 0, 16);
      this.msgType = TbCommon.bytes2Int(arrayOfByte, 0, 4);
      this.msgBodySize = TbCommon.bytes2Int(arrayOfByte, 4, 4);
      tbMsg = TbMsgFactory.createMessage(this.msgType);
      if (this.msgBodySize <= 0)
        return tbMsg; 
      this.readBuf.init(this.msgBodySize);
      if (readNBytes(this.readBuf.getRawBytes(), 0, this.msgBodySize) != this.msgBodySize)
        throw TbError.newSQLException(-590729); 
      this.readBuf.setCurDataSize(this.msgBodySize);
      this.reader.initialize(this.readBuf);
      this.msgBodySize = 0;
      tbMsg.deserialize(this.reader);
    } 
    return tbMsg;
  }
  
  private int readNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    try {
      long l = 0L;
      int i = 0;
      if (this.conn.isActivatedTimer())
        l = System.currentTimeMillis(); 
      int j = 0;
      while (i != paramInt2) {
        j = this.input.read(paramArrayOfbyte, paramInt1 + i, paramInt2 - i);
        if (j == -1)
          throw new IOException("End Of Stream"); 
        i += j;
      } 
      if (this.conn.isActivatedTimer())
        this.conn.addWaitingTime(System.currentTimeMillis() - l); 
      return i;
    } catch (IOException iOException) {
      this.conn.reconnect();
      throw TbError.newSQLException(-90405, iOException.getMessage());
    } 
  }
  
  public void reset() {
    this.tduSize = 0;
    this.input = null;
    this.output = null;
    this.bufWriting = false;
    this.reader.reset();
    this.writer.reset();
  }
  
  public void setSoTimeout(int paramInt) {
    try {
      this.socket.setSoTimeout(paramInt);
    } catch (Exception exception) {}
  }
  
  public void startWritingPacketData() {
    this.writer.initialize(this.writeBuf);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\comm\TbStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */