package com.tmax.tibero.jdbc.comm;

import com.tmax.tibero.DriverConstants;
import com.tmax.tibero.jdbc.TbBlob;
import com.tmax.tibero.jdbc.TbCallableStatement;
import com.tmax.tibero.jdbc.TbClobBase;
import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.TbLob;
import com.tmax.tibero.jdbc.TbPreparedStatement;
import com.tmax.tibero.jdbc.TbResultSet;
import com.tmax.tibero.jdbc.TbResultSetBase;
import com.tmax.tibero.jdbc.TbResultSetFactory;
import com.tmax.tibero.jdbc.TbSQLInfo;
import com.tmax.tibero.jdbc.TbSavepoint;
import com.tmax.tibero.jdbc.TbStatement;
import com.tmax.tibero.jdbc.data.BatchInfo;
import com.tmax.tibero.jdbc.data.BindData;
import com.tmax.tibero.jdbc.data.BindItem;
import com.tmax.tibero.jdbc.data.ConnectionInfo;
import com.tmax.tibero.jdbc.data.DataType;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import com.tmax.tibero.jdbc.data.NodeInfo;
import com.tmax.tibero.jdbc.data.ServerInfo;
import com.tmax.tibero.jdbc.data.ZoneInfo;
import com.tmax.tibero.jdbc.data.binder.Binder;
import com.tmax.tibero.jdbc.data.charset.Charset;
import com.tmax.tibero.jdbc.data.charset.CharsetMetaData;
import com.tmax.tibero.jdbc.dpl.TbDirPathMetaData;
import com.tmax.tibero.jdbc.dpl.TbDirPathStream;
import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.msg.TbBindparamUdt;
import com.tmax.tibero.jdbc.msg.TbClntInfoParam;
import com.tmax.tibero.jdbc.msg.TbColNameList;
import com.tmax.tibero.jdbc.msg.TbColumnDesc;
import com.tmax.tibero.jdbc.msg.TbMsgBatchUpdateReply;
import com.tmax.tibero.jdbc.msg.TbMsgConnectReply;
import com.tmax.tibero.jdbc.msg.TbMsgDplLoadStreamReply;
import com.tmax.tibero.jdbc.msg.TbMsgDplPrepareReply;
import com.tmax.tibero.jdbc.msg.TbMsgEreply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteCallReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteCountReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteNeedDataReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecutePivotReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecutePrefetchNoDescReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecutePrefetchReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecutePsmPrefetchReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecutePsmReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteRsetNoDescReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteRsetReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteUdtCallReply;
import com.tmax.tibero.jdbc.msg.TbMsgExecuteUdtPsmReply;
import com.tmax.tibero.jdbc.msg.TbMsgFetchPivotReply;
import com.tmax.tibero.jdbc.msg.TbMsgFetchReply;
import com.tmax.tibero.jdbc.msg.TbMsgGetLastExecutedSqlinfoReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobCloseReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobCreateTempReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobInlobReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobInstrReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobLengthReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobOpenReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobReadReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobTruncReply;
import com.tmax.tibero.jdbc.msg.TbMsgLobWriteReply;
import com.tmax.tibero.jdbc.msg.TbMsgLongReadReply;
import com.tmax.tibero.jdbc.msg.TbMsgOkReply;
import com.tmax.tibero.jdbc.msg.TbMsgPrepareReply;
import com.tmax.tibero.jdbc.msg.TbMsgSend;
import com.tmax.tibero.jdbc.msg.TbMsgSessInfoReply;
import com.tmax.tibero.jdbc.msg.TbNlsParam;
import com.tmax.tibero.jdbc.msg.TbOutParam;
import com.tmax.tibero.jdbc.msg.TbOutParamUdt;
import com.tmax.tibero.jdbc.msg.TbPivotInfo;
import com.tmax.tibero.jdbc.msg.TbPvValType;
import com.tmax.tibero.jdbc.msg.TbSessAttrDesc;
import com.tmax.tibero.jdbc.msg.common.TbMsg;
import com.tmax.tibero.jdbc.util.TbCommon;
import com.tmax.tibero.jdbc.util.TbSQLTypeScanner;
import java.io.ByteArrayOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.BatchUpdateException;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

public class TbCommType4 implements TbComm, TbClobAccessor, TbBlobAccessor {
  public TbConnection conn = null;
  
  public TbStream stream = null;
  
  public DataTypeConverter typeConverter = null;
  
  private boolean logonWithNewPassword;
  
  public TbCommType4() {}
  
  public TbCommType4(TbConnection paramTbConnection) {
    this.conn = paramTbConnection;
    this.typeConverter = paramTbConnection.getTypeConverter();
  }
  
  private int[] batchUpdate(TbPreparedStatement paramTbPreparedStatement, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    byte b = 0;
    int i = paramTbPreparedStatement.getParameterCnt();
    int j = paramInt2 - paramInt1;
    boolean bool = true;
    byte[][] arrayOfByte = paramTbPreparedStatement.getParamTypes();
    Binder[][] arrayOfBinder = paramTbPreparedStatement.getBinder();
    synchronized (this.stream) {
      TbStreamDataWriter tbStreamDataWriter = this.stream.getMsgWriter();
      this.stream.startWritingPacketData();
      tbStreamDataWriter.writeInt(31, 4);
      tbStreamDataWriter.writeInt(0, 4);
      tbStreamDataWriter.writeLong(0L, 8);
      tbStreamDataWriter.writeLenAndDBEncodedPadString(paramTbPreparedStatement.getOriginalSql());
      int k = tbStreamDataWriter.getBufferedDataSize();
      tbStreamDataWriter.makeBufferAvailable(20);
      tbStreamDataWriter.moveOffset(20);
      int m = tbStreamDataWriter.getBufferedDataSize();
      for (int n = paramInt1; n < paramInt2; n++) {
        for (byte b1 = 0; b1 < (arrayOfBinder[n]).length; b1++) {
          int i1 = 1;
          i1 |= arrayOfByte[n][b1] << 8 & 0xFFFFFF00;
          tbStreamDataWriter.writeInt(i1, 4);
          arrayOfBinder[n][b1].bind(this.conn, paramTbPreparedStatement, tbStreamDataWriter, n, b1, 0);
        } 
        b++;
        if (tbStreamDataWriter.getBufferedDataSize() > DriverConstants.BATCH_SEND_SIZE) {
          batchUpdateFlush(paramTbPreparedStatement, k, j, b, paramInt3, bool);
          bool = false;
          b = 0;
          tbStreamDataWriter.setCurDataSize(m);
        } 
      } 
      if (bool || tbStreamDataWriter.getBufferedDataSize() - m > 0)
        batchUpdateFlush(paramTbPreparedStatement, k, j, b, paramInt3, bool); 
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 32:
          return batchUpdateReply((TbMsgBatchUpdateReply)tbMsg, j, i);
        case 76:
          throwEreply(-90515, tbMsg);
          return null;
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return null;
  }
  
  private void batchUpdateFlush(TbPreparedStatement paramTbPreparedStatement, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) throws SQLException {
    int i = paramTbPreparedStatement.getParameterCnt();
    TbStreamDataWriter tbStreamDataWriter = this.stream.getMsgWriter();
    tbStreamDataWriter.reWriteInt(paramInt1, paramInt2, 4);
    tbStreamDataWriter.reWriteInt(paramInt1 + 4, paramInt3, 4);
    tbStreamDataWriter.reWriteInt(paramInt1 + 8, i, 4);
    if (this.conn.getAutoCommit())
      paramInt4 |= 0x1; 
    if (!paramBoolean)
      paramInt4 |= 0x1000; 
    tbStreamDataWriter.reWriteInt(paramInt1 + 12, paramInt4, 4);
    tbStreamDataWriter.reWriteInt(paramInt1 + 16, paramInt3 * i, 4);
    tbStreamDataWriter.reWriteInt(4, tbStreamDataWriter.getBufferedDataSize() - 16, 4);
    this.stream.flush();
  }
  
  public int[] batchUpdateLoop(TbPreparedStatement paramTbPreparedStatement, ArrayList<BatchInfo> paramArrayList) throws SQLException {
    int i = paramTbPreparedStatement.getBatchFlag();
    int j = paramArrayList.size();
    int k = paramTbPreparedStatement.getBatchRowCount();
    int m = 0;
    int n = 0;
    int[] arrayOfInt = new int[k];
    try {
      if (j == 0)
        return batchUpdate(paramTbPreparedStatement, 0, k, i); 
      for (byte b = 0; b < j; b++) {
        BatchInfo batchInfo = paramArrayList.get(b);
        int i1 = batchInfo.getCurrentRowIndex();
        if (m < i1) {
          int[] arrayOfInt1 = batchUpdate(paramTbPreparedStatement, m, i1, i);
          System.arraycopy(arrayOfInt1, 0, arrayOfInt, n, arrayOfInt1.length);
          n += arrayOfInt1.length;
          m = i1;
        } 
        paramTbPreparedStatement.setBindData(batchInfo.getDeferredRow());
        arrayOfInt[n++] = prepareExecute(paramTbPreparedStatement, paramTbPreparedStatement.getOriginalSql(), batchInfo.getCurrentRowIndex());
        m++;
      } 
      if (m < k) {
        int[] arrayOfInt1 = batchUpdate(paramTbPreparedStatement, m, k, i);
        System.arraycopy(arrayOfInt1, 0, arrayOfInt, n, arrayOfInt1.length);
      } 
      return arrayOfInt;
    } catch (BatchUpdateException batchUpdateException) {
      int i1 = (batchUpdateException.getUpdateCounts()).length;
      int[] arrayOfInt1 = new int[n + i1 + 1];
      System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, n + 1);
      System.arraycopy(batchUpdateException.getUpdateCounts(), 0, arrayOfInt1, n, i1);
      throw new BatchUpdateException(batchUpdateException.getMessage(), batchUpdateException.getSQLState(), batchUpdateException.getErrorCode(), arrayOfInt1);
    } 
  }
  
  private int[] batchUpdateReply(TbMsgBatchUpdateReply paramTbMsgBatchUpdateReply, int paramInt1, int paramInt2) throws SQLException {
    int[] arrayOfInt = new int[paramTbMsgBatchUpdateReply.executedCnt];
    if (paramTbMsgBatchUpdateReply.affectedCnt == null) {
      for (byte b = 0; b < paramTbMsgBatchUpdateReply.executedCnt; b++)
        arrayOfInt[b] = 1; 
    } else {
      for (byte b = 0; b < paramTbMsgBatchUpdateReply.executedCnt; b++)
        arrayOfInt[b] = (paramTbMsgBatchUpdateReply.affectedCnt[b]).cnt; 
    } 
    if (paramInt2 > 0 && paramInt1 != paramTbMsgBatchUpdateReply.executedCnt) {
      SQLException sQLException = paramTbMsgBatchUpdateReply.getException(-90515);
      throw new BatchUpdateException(sQLException.getMessage(), sQLException.getSQLState(), sQLException.getErrorCode(), arrayOfInt);
    } 
    return arrayOfInt;
  }
  
  public void cancel() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.CANCEL(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90526, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void cancelStatement() throws SQLException {
    TbMsgSend.STMTCANCEL(this.stream, this.conn.getSessionId(), this.conn.getSerialNo(), 0);
  }
  
  public void close() throws SQLException {
    reset();
  }
  
  public boolean close(TbLob paramTbLob) throws SQLException {
    return lobClose(paramTbLob);
  }
  
  public void closeCursor(TbResultSet paramTbResultSet, int paramInt) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.CLOSE_CSR(this.stream, paramInt);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90507, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void closeSession() throws SQLException {
    boolean bool = this.conn.getAutoCommit() ? true : false;
    synchronized (this.stream) {
      TbMsgSend.CLOSE_SESS(this.stream, bool);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90503, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void commit() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.COMMIT(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90510, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void createStream() throws SQLException {
    String str = null;
    if (this.conn.info.isInternal()) {
      Socket socket = TbSocketRegistry.getSocket();
      if (socket == null)
        throw TbError.newSQLException(-590720); 
      str = "server internally";
      if (this.stream != null) {
        synchronized (this.stream) {
          this.stream = new TbStream(this.conn, socket, this.typeConverter, this.conn.info);
        } 
      } else {
        this.stream = new TbStream(this.conn, socket, this.typeConverter, this.conn.info);
      } 
    } else {
      NodeInfo nodeInfo = this.conn.info.getClusterNode();
      if (nodeInfo == null)
        throw TbError.newSQLException(-590721); 
      while (true) {
        str = nodeInfo.getAddress() + ":" + nodeInfo.getPort();
        if (this.stream != null)
          synchronized (this.stream) {
            this.stream = new TbStream(this.conn, nodeInfo.getAddress(), nodeInfo.getPort(), this.typeConverter, this.conn.info);
            break;
          }  
        try {
          this.stream = new TbStream(this.conn, nodeInfo.getAddress(), nodeInfo.getPort(), this.typeConverter, this.conn.info);
          break;
        } catch (SQLException sQLException) {
          this.stream = null;
          nodeInfo = this.conn.info.getSecondaryNode();
          if (nodeInfo == null)
            throw sQLException; 
        } 
      } 
      nodeInfo = null;
    } 
  }
  
  public byte[] createTemporaryBlob() throws SQLException {
    return lobCreateTemporary(12);
  }
  
  public byte[] createTemporaryClob() throws SQLException {
    return lobCreateTemporary(13);
  }
  
  public byte[] createTemporaryNClob() throws SQLException {
    return lobCreateTemporary(20);
  }
  
  public void describeConnectInfo() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DESCRIBE_CONNECT_INFO(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 0:
          logonConnectReply((TbMsgConnectReply)tbMsg);
          break;
        case 76:
          throwEreply(-90502, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void describeSessInfo() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DESCRIBE_SESS_INFO(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 2:
          logonSessInfoReply((TbMsgSessInfoReply)tbMsg);
          break;
        case 76:
          throwEreply(-90502, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void dirPathAbort() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DPL_ABORT(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90541, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void dirPathDataSave(int paramInt) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DPL_DATASAVE(this.stream, paramInt);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90538, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void dirPathFinish() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DPL_FINISH(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90539, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void dirPathFlushRow() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DPL_FLUSH_ROW(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90540, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void dirPathLoadStream(TbDirPathStream paramTbDirPathStream, TbStreamDataWriter paramTbStreamDataWriter, int paramInt) throws SQLException {
    synchronized (this.stream) {
      TbMsgDplLoadStreamReply tbMsgDplLoadStreamReply;
      int i;
      int j;
      try {
        paramTbStreamDataWriter.reWriteInt(0, 57, 4);
        paramTbStreamDataWriter.reWriteLong(8, 0L, 8);
        paramTbStreamDataWriter.reWriteInt(16, paramInt, 4);
        paramTbStreamDataWriter.reWriteInt(20, paramTbStreamDataWriter.getBufferedDataSize() - 24, 4);
        paramTbStreamDataWriter.putPadding(4);
        paramTbStreamDataWriter.reWriteInt(4, paramTbStreamDataWriter.getBufferedDataSize() - 16, 4);
        this.stream.flush(paramTbStreamDataWriter);
      } finally {
        paramTbStreamDataWriter.clearDPLBuffer();
      } 
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 58:
          tbMsgDplLoadStreamReply = (TbMsgDplLoadStreamReply)tbMsg;
          i = tbMsgDplLoadStreamReply.rowCnt;
          j = tbMsgDplLoadStreamReply.returnCode;
          paramTbDirPathStream.addRowCnt(i);
          paramTbDirPathStream.setReturnCode(j);
          if (j == 3)
            throw tbMsgDplLoadStreamReply.getException(-90537); 
          break;
        case 76:
          throwEreply(-90537, tbMsg);
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void dirPathPrepare(TbDirPathStream paramTbDirPathStream) throws SQLException {
    TbDirPathMetaData tbDirPathMetaData = paramTbDirPathStream.getDPLMetaData();
    int i = tbDirPathMetaData.getColumnCnt();
    TbColNameList[] arrayOfTbColNameList = new TbColNameList[i];
    byte b;
    for (b = 0; b < i; b++) {
      arrayOfTbColNameList[b] = new TbColNameList();
      arrayOfTbColNameList[b].set(tbDirPathMetaData.getColumn(b + 1));
    } 
    b = (tbDirPathMetaData.getLogFlag() == true) ? 1 : 0;
    synchronized (this.stream) {
      TbColumnDesc[] arrayOfTbColumnDesc;
      TbMsgSend.DPL_PREPARE(this.stream, b, tbDirPathMetaData.getSchema(), tbDirPathMetaData.getTable(), i, arrayOfTbColNameList);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 56:
          if (i != ((TbMsgDplPrepareReply)tbMsg).colMeta.length)
            throw TbError.newSQLException(-90544); 
          arrayOfTbColumnDesc = ((TbMsgDplPrepareReply)tbMsg).colMeta;
          paramTbDirPathStream.getDPLMetaData().setColumnMetas(arrayOfTbColumnDesc);
          return;
        case 76:
          throwEreply(-90536, tbMsg);
          break;
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
  }
  
  public void dirPathPrepareParallel(TbDirPathStream paramTbDirPathStream) throws SQLException {
    TbDirPathMetaData tbDirPathMetaData = paramTbDirPathStream.getDPLMetaData();
    int i = tbDirPathMetaData.getColumnCnt();
    TbColNameList[] arrayOfTbColNameList = new TbColNameList[i];
    byte b;
    for (b = 0; b < i; b++) {
      arrayOfTbColNameList[b] = new TbColNameList();
      arrayOfTbColNameList[b].set(tbDirPathMetaData.getColumn(b + 1));
    } 
    b = (tbDirPathMetaData.getLogFlag() == true) ? 1 : 0;
    boolean bool = (tbDirPathMetaData.getParallelFlag() == true) ? true : false;
    synchronized (this.stream) {
      TbColumnDesc[] arrayOfTbColumnDesc;
      TbMsgSend.DPL_PREPARE_PARALLEL(this.stream, b, bool, tbDirPathMetaData.getSchema(), tbDirPathMetaData.getTable(), tbDirPathMetaData.getPartition(), i, arrayOfTbColNameList);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 56:
          if (i != ((TbMsgDplPrepareReply)tbMsg).colMeta.length)
            throw TbError.newSQLException(-90544); 
          arrayOfTbColumnDesc = ((TbMsgDplPrepareReply)tbMsg).colMeta;
          paramTbDirPathStream.getDPLMetaData().setColumnMetas(arrayOfTbColumnDesc);
          return;
        case 76:
          throwEreply(-90536, tbMsg);
          break;
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
  }
  
  public int execute(TbPreparedStatement paramTbPreparedStatement, String paramString, int paramInt) throws SQLException {
    synchronized (this.stream) {
      processExecute(paramTbPreparedStatement, paramString, paramInt, true);
      TbMsg tbMsg = this.stream.readMsg();
      while (true) {
        TbMsgExecutePsmReply tbMsgExecutePsmReply;
        switch (tbMsg.getMsgType()) {
          case 75:
            justOKReply((TbMsgOkReply)tbMsg);
            return TbSQLTypeScanner.isPSMStmt(paramTbPreparedStatement.getSqlType()) ? 1 : 0;
          case 2:
            return 0;
          case 12:
            return executePrefetchNoDescReply(paramTbPreparedStatement, (TbMsgExecutePrefetchNoDescReply)tbMsg);
          case 13:
            return executeCountReply((TbStatement)paramTbPreparedStatement, (TbMsgExecuteCountReply)tbMsg);
          case 8:
            return executeRsetReply((TbStatement)paramTbPreparedStatement, (TbMsgExecuteRsetReply)tbMsg);
          case 10:
            return executeRsetNoDescReply(paramTbPreparedStatement, (TbMsgExecuteRsetNoDescReply)tbMsg);
          case 16:
            return executeNeedDataReply(tbMsg, paramTbPreparedStatement, paramInt);
          case 15:
            tbMsgExecutePsmReply = (TbMsgExecutePsmReply)tbMsg;
            return executeCallReply(paramTbPreparedStatement, paramInt, tbMsgExecutePsmReply.paramData);
          case 9:
            tbMsg = executePivotReply((TbStatement)paramTbPreparedStatement, (TbMsgExecutePivotReply)tbMsg);
            continue;
          case 187:
            return executeUdtPsmReply(paramTbPreparedStatement, paramInt, (TbMsgExecuteUdtPsmReply)tbMsg);
          case 76:
            return executeEreply(paramTbPreparedStatement, paramString, tbMsg, paramInt);
        } 
        throwProtocolError(tbMsg.getMsgType());
      } 
    } 
  }
  
  public int executeUdt(TbPreparedStatement paramTbPreparedStatement, String paramString, int paramInt) throws SQLException {
    synchronized (this.stream) {
      processExecuteUdt(paramTbPreparedStatement, paramString, paramInt, true);
      TbMsg tbMsg = this.stream.readMsg();
      while (true) {
        TbMsgExecutePsmReply tbMsgExecutePsmReply;
        switch (tbMsg.getMsgType()) {
          case 75:
            justOKReply((TbMsgOkReply)tbMsg);
            return TbSQLTypeScanner.isPSMStmt(paramTbPreparedStatement.getSqlType()) ? 1 : 0;
          case 2:
            return 0;
          case 12:
            return executePrefetchNoDescReply(paramTbPreparedStatement, (TbMsgExecutePrefetchNoDescReply)tbMsg);
          case 13:
            return executeCountReply((TbStatement)paramTbPreparedStatement, (TbMsgExecuteCountReply)tbMsg);
          case 8:
            return executeRsetReply((TbStatement)paramTbPreparedStatement, (TbMsgExecuteRsetReply)tbMsg);
          case 10:
            return executeRsetNoDescReply(paramTbPreparedStatement, (TbMsgExecuteRsetNoDescReply)tbMsg);
          case 16:
            return executeNeedDataReply(tbMsg, paramTbPreparedStatement, paramInt);
          case 15:
            tbMsgExecutePsmReply = (TbMsgExecutePsmReply)tbMsg;
            return executeCallReply(paramTbPreparedStatement, paramInt, tbMsgExecutePsmReply.paramData);
          case 9:
            tbMsg = executePivotReply((TbStatement)paramTbPreparedStatement, (TbMsgExecutePivotReply)tbMsg);
            continue;
          case 187:
            return executeUdtPsmReply(paramTbPreparedStatement, paramInt, (TbMsgExecuteUdtPsmReply)tbMsg);
          case 76:
            return executeEreply(paramTbPreparedStatement, paramString, tbMsg, paramInt);
        } 
        throwProtocolError(tbMsg.getMsgType());
      } 
    } 
  }
  
  private int executeUdtPsmReply(TbPreparedStatement paramTbPreparedStatement, int paramInt, TbMsgExecuteUdtPsmReply paramTbMsgExecuteUdtPsmReply) throws SQLException {
    TbOutParamUdt[] arrayOfTbOutParamUdt = paramTbMsgExecuteUdtPsmReply.paramData;
    byte b = -1;
    byte b1 = (arrayOfTbOutParamUdt == null) ? 0 : arrayOfTbOutParamUdt.length;
    BindData bindData = paramTbPreparedStatement.getBindData();
    int i = paramTbPreparedStatement.getParameterCnt();
    if (bindData.getOutParameterCnt() != b1)
      throw TbError.newSQLException(-90618); 
    if (arrayOfTbOutParamUdt == null || !(paramTbPreparedStatement instanceof TbCallableStatement))
      return 1; 
    TbCallableStatement tbCallableStatement = (TbCallableStatement)paramTbPreparedStatement;
    for (byte b2 = 0; b2 < b1; b2++) {
      while (++b < i && !bindData.isOutParameterOn(b))
        b++; 
      if (b >= i)
        throw TbError.newSQLException(-90618); 
      BindItem bindItem1 = bindData.getBindItem(b);
      BindItem bindItem2 = tbCallableStatement.getOutItems(b);
      int j = 0;
      for (byte b3 = 0; b3 < (arrayOfTbOutParamUdt[b2]).subOutParam.length; b3++)
        j += ((arrayOfTbOutParamUdt[b2]).subOutParam[b3]).value.length; 
      byte[] arrayOfByte = new byte[j + (arrayOfTbOutParamUdt[b2]).value.length];
      System.arraycopy((arrayOfTbOutParamUdt[b2]).value, 0, arrayOfByte, 0, (arrayOfTbOutParamUdt[b2]).value.length);
      int k = (arrayOfTbOutParamUdt[b2]).value.length;
      for (byte b4 = 0; b4 < (arrayOfTbOutParamUdt[b2]).subOutParam.length; b4++) {
        System.arraycopy(((arrayOfTbOutParamUdt[b2]).subOutParam[b4]).value, 0, arrayOfByte, k, ((arrayOfTbOutParamUdt[b2]).subOutParam[b4]).value.length);
        k += ((arrayOfTbOutParamUdt[b2]).subOutParam[b4]).value.length;
      } 
      bindItem2.set(bindItem1.getSQLType(), arrayOfByte.length, (arrayOfTbOutParamUdt[b2]).colMeta);
      tbCallableStatement.setOutParamUdt(b, (arrayOfTbOutParamUdt[b2]).dataType, arrayOfByte, arrayOfTbOutParamUdt[b2]);
    } 
    return 1;
  }
  
  private int executeCallReply(TbPreparedStatement paramTbPreparedStatement, int paramInt, TbOutParam[] paramArrayOfTbOutParam) throws SQLException {
    byte b = -1;
    byte b1 = (paramArrayOfTbOutParam == null) ? 0 : paramArrayOfTbOutParam.length;
    BindData bindData = paramTbPreparedStatement.getBindData();
    int i = paramTbPreparedStatement.getParameterCnt();
    if (bindData.getOutParameterCnt() != b1)
      throw TbError.newSQLException(-90618); 
    if (paramArrayOfTbOutParam == null || !(paramTbPreparedStatement instanceof TbCallableStatement))
      return 1; 
    TbCallableStatement tbCallableStatement = (TbCallableStatement)paramTbPreparedStatement;
    for (byte b2 = 0; b2 < b1; b2++) {
      while (++b < i && !bindData.isOutParameterOn(b))
        b++; 
      if (b >= i)
        throw TbError.newSQLException(-90618); 
      BindItem bindItem1 = bindData.getBindItem(b);
      BindItem bindItem2 = tbCallableStatement.getOutItems(b);
      bindItem2.set(bindItem1.getSQLType(), (paramArrayOfTbOutParam[b2]).value.length, (paramArrayOfTbOutParam[b2]).colMeta);
      tbCallableStatement.setOutParam(b, (paramArrayOfTbOutParam[b2]).dataType, (paramArrayOfTbOutParam[b2]).value);
    } 
    return 1;
  }
  
  private int executePsmPrefetchReply(TbCallableStatement paramTbCallableStatement, int paramInt, TbMsgExecutePsmPrefetchReply paramTbMsgExecutePsmPrefetchReply) throws SQLException {
    TbOutParam[] arrayOfTbOutParam = paramTbMsgExecutePsmPrefetchReply.paramData;
    byte b = -1;
    byte b1 = (arrayOfTbOutParam == null) ? 0 : arrayOfTbOutParam.length;
    BindData bindData = paramTbCallableStatement.getBindData();
    int i = paramTbCallableStatement.getParameterCnt();
    if (bindData.getOutParameterCnt() != b1)
      throw TbError.newSQLException(-90618); 
    if (arrayOfTbOutParam == null)
      return 1; 
    byte b2 = 0;
    boolean bool = true;
    for (byte b3 = 0; b3 < b1; b3++) {
      while (++b < i && !bindData.isOutParameterOn(b))
        b++; 
      if (b >= i)
        throw TbError.newSQLException(-90618); 
      BindItem bindItem1 = bindData.getBindItem(b);
      BindItem bindItem2 = paramTbCallableStatement.getOutItems(b);
      bindItem2.set(bindItem1.getSQLType(), (arrayOfTbOutParam[b3]).value.length, (arrayOfTbOutParam[b3]).colMeta);
      paramTbCallableStatement.setOutParam(b, (arrayOfTbOutParam[b3]).dataType, (arrayOfTbOutParam[b3]).value);
      if (bool && (arrayOfTbOutParam[b3]).dataType == 16) {
        b2 = b3;
        bool = false;
      } 
    } 
    TbResultSet tbResultSet = this.typeConverter.toResultSet(paramTbMsgExecutePsmPrefetchReply.colCnt, paramTbMsgExecutePsmPrefetchReply.hiddenColCnt, paramTbMsgExecutePsmPrefetchReply.csrId, paramTbMsgExecutePsmPrefetchReply.colMeta, (TbStatement)paramTbCallableStatement);
    byte[] arrayOfByte = tbResultSet.getRowChunk(paramTbMsgExecutePsmPrefetchReply.rowChunkSize);
    this.stream.readChunkData(arrayOfByte, paramTbMsgExecutePsmPrefetchReply.rowChunkSize);
    paramTbCallableStatement.setPrefetchColIndex(b2);
    paramTbCallableStatement.setFetchCompleted(paramTbMsgExecutePsmPrefetchReply.isFetchCompleted);
    paramTbCallableStatement.setRowCnt(paramTbMsgExecutePsmPrefetchReply.rowCnt);
    paramTbCallableStatement.setChunk(arrayOfByte);
    return 1;
  }
  
  private int executeCountReply(TbStatement paramTbStatement, TbMsgExecuteCountReply paramTbMsgExecuteCountReply) throws SQLException {
    long l = (0xFFFFFFFF00000000L & paramTbMsgExecuteCountReply.cntHigh << 32L) + (0xFFFFFFFFL & paramTbMsgExecuteCountReply.cntLow);
    return (int)l;
  }
  
  public int executeDirect(TbStatement paramTbStatement, String paramString) throws SQLException {
    boolean bool = this.conn.getAutoCommit() ? true : false;
    synchronized (this.stream) {
      TbMsgSend.EXECDIR(this.stream, bool, paramTbStatement.getPreFetchSize(), paramString);
      TbMsg tbMsg = this.stream.readMsg();
      while (true) {
        switch (tbMsg.getMsgType()) {
          case 75:
            justOKReply((TbMsgOkReply)tbMsg);
            return TbSQLTypeScanner.isPSMStmt(paramTbStatement.getSqlType()) ? 1 : 0;
          case 2:
            return 0;
          case 13:
            return executeCountReply(paramTbStatement, (TbMsgExecuteCountReply)tbMsg);
          case 8:
            return executeRsetReply(paramTbStatement, (TbMsgExecuteRsetReply)tbMsg);
          case 14:
          case 15:
            return 1;
          case 11:
            return executePrefetchReply(paramTbStatement, (TbMsgExecutePrefetchReply)tbMsg);
          case 9:
            tbMsg = executePivotReply(paramTbStatement, (TbMsgExecutePivotReply)tbMsg);
            continue;
          case 76:
            return executeDirectEreply(paramTbStatement, paramString, tbMsg);
        } 
        throwProtocolError(tbMsg.getMsgType());
      } 
    } 
  }
  
  private int executeDirectEreply(TbStatement paramTbStatement, String paramString, TbMsg paramTbMsg) throws SQLException {
    SQLException sQLException = getErrorMessage(-90508, paramTbMsg);
    if (sQLException.getErrorCode() == -12018)
      return executeDirect(paramTbStatement, paramString); 
    throw sQLException;
  }
  
  private int executeEreply(TbPreparedStatement paramTbPreparedStatement, String paramString, TbMsg paramTbMsg, int paramInt) throws SQLException {
    SQLException sQLException = getErrorMessage(-90508, paramTbMsg);
    if (sQLException.getErrorCode() == -12018) {
      paramTbPreparedStatement.setPPID(null);
      paramTbPreparedStatement.buildColMetaArray(0, 0, null);
      return prepareExecute(paramTbPreparedStatement, paramString, paramInt);
    } 
    throw sQLException;
  }
  
  private int executeNeedDataReply(TbMsg paramTbMsg, TbPreparedStatement paramTbPreparedStatement, int paramInt) throws SQLException {
    TbMsgExecuteCallReply tbMsgExecuteCallReply;
    BindData bindData = paramTbPreparedStatement.getBindData();
    Binder[][] arrayOfBinder = paramTbPreparedStatement.getBinder();
    TbMsg tbMsg = paramTbMsg;
    int i = paramTbPreparedStatement.getCurCsrId();
    int j = bindData.getDFRParameterCnt();
    TbStreamDataWriter tbStreamDataWriter = this.stream.getMsgWriter();
    while (j > 0) {
      int k = ((TbMsgExecuteNeedDataReply)tbMsg).paramIndex;
      BindItem bindItem = bindData.getBindItem(k);
      if (bindItem.getParamMode() != 8)
        throw TbError.newSQLException(-590717, bindItem.toString()); 
      this.stream.startWritingPacketData();
      tbStreamDataWriter.writeInt(54, 4);
      tbStreamDataWriter.writeInt(0, 4);
      tbStreamDataWriter.writeLong(0L, 8);
      tbStreamDataWriter.writeInt(k, 4);
      tbStreamDataWriter.writeInt(i, 4);
      arrayOfBinder[paramInt][k].bindDFR(this.conn, paramTbPreparedStatement, tbStreamDataWriter, paramInt, k, bindItem.getLength());
      TbMsgSend.PUT_DATA(this.stream, k, i, new byte[0], 0);
      tbMsg = this.stream.readMsg();
      if (tbMsg.getMsgType() == 16) {
        paramTbPreparedStatement.setCurCsrId(((TbMsgExecuteNeedDataReply)tbMsg).csrId);
      } else if (tbMsg.getMsgType() == 76) {
        throwEreply(-90508, tbMsg);
      } else {
        break;
      } 
      j--;
    } 
    switch (tbMsg.getMsgType()) {
      case 14:
        tbMsgExecuteCallReply = (TbMsgExecuteCallReply)tbMsg;
        return executeCallReply(paramTbPreparedStatement, paramInt, tbMsgExecuteCallReply.paramData);
      case 13:
        return executeCountReply((TbStatement)paramTbPreparedStatement, (TbMsgExecuteCountReply)tbMsg);
      case 75:
        justOKReply((TbMsgOkReply)tbMsg);
        return TbSQLTypeScanner.isPSMStmt(paramTbPreparedStatement.getSqlType()) ? 1 : 0;
      case 8:
        return executeRsetReply((TbStatement)paramTbPreparedStatement, (TbMsgExecuteRsetReply)tbMsg);
    } 
    throwProtocolError(tbMsg.getMsgType());
    return 0;
  }
  
  private TbMsg executePivotReply(TbStatement paramTbStatement, TbMsgExecutePivotReply paramTbMsgExecutePivotReply) throws SQLException {
    TbPivotInfo[] arrayOfTbPivotInfo = new TbPivotInfo[paramTbMsgExecutePivotReply.pivotInfo.length];
    for (byte b = 0; b < paramTbMsgExecutePivotReply.pivotInfo.length; b++) {
      arrayOfTbPivotInfo[b] = new TbPivotInfo();
      (arrayOfTbPivotInfo[b]).colIdx = (paramTbMsgExecutePivotReply.pivotInfo[b]).colIdx;
      (arrayOfTbPivotInfo[b]).chunkCnt = (paramTbMsgExecutePivotReply.pivotInfo[b]).chunkCnt;
      if ((paramTbMsgExecutePivotReply.pivotInfo[b]).valType != null) {
        (arrayOfTbPivotInfo[b]).valType = new TbPvValType[(paramTbMsgExecutePivotReply.pivotInfo[b]).valType.length];
        for (byte b1 = 0; b1 < (paramTbMsgExecutePivotReply.pivotInfo[b]).valType.length; b1++) {
          (arrayOfTbPivotInfo[b]).valType[b1] = new TbPvValType();
          ((arrayOfTbPivotInfo[b]).valType[b1]).type = ((paramTbMsgExecutePivotReply.pivotInfo[b]).valType[b1]).type;
        } 
      } 
    } 
    paramTbStatement.setPivotInfo(arrayOfTbPivotInfo);
    paramTbStatement.addPivotData(paramTbMsgExecutePivotReply.chunk);
    while (true) {
      TbMsgSend.FETCH_PIVOT(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 21:
          paramTbStatement.addPivotData(((TbMsgFetchPivotReply)tbMsg).chunk);
          continue;
      } 
      return tbMsg;
    } 
  }
  
  private int executePrefetchNoDescReply(TbPreparedStatement paramTbPreparedStatement, TbMsgExecutePrefetchNoDescReply paramTbMsgExecutePrefetchNoDescReply) throws SQLException {
    TbResultSet tbResultSet = this.typeConverter.toResultSet(paramTbPreparedStatement.getOutColCnt(), paramTbPreparedStatement.getHiddenColCnt(), paramTbMsgExecutePrefetchNoDescReply.csrId, paramTbPreparedStatement.getColMetaArray(), (TbStatement)paramTbPreparedStatement);
    byte[] arrayOfByte = tbResultSet.getRowChunk(paramTbMsgExecutePrefetchNoDescReply.rowChunkSize);
    this.stream.readChunkData(arrayOfByte, paramTbMsgExecutePrefetchNoDescReply.rowChunkSize);
    tbResultSet.setFetchCompleted(paramTbMsgExecutePrefetchNoDescReply.isFetchCompleted);
    tbResultSet.buildRowTable(paramTbMsgExecutePrefetchNoDescReply.rowCnt, arrayOfByte);
    paramTbPreparedStatement.setResultSet(tbResultSet);
    return (int)tbResultSet.getUpdateCount();
  }
  
  private int executePrefetchReply(TbStatement paramTbStatement, TbMsgExecutePrefetchReply paramTbMsgExecutePrefetchReply) throws SQLException {
    TbResultSet tbResultSet = this.typeConverter.toResultSet(paramTbMsgExecutePrefetchReply.colCnt, paramTbMsgExecutePrefetchReply.hiddenColCnt, paramTbMsgExecutePrefetchReply.csrId, paramTbMsgExecutePrefetchReply.colMeta, paramTbStatement);
    byte[] arrayOfByte = tbResultSet.getRowChunk(paramTbMsgExecutePrefetchReply.rowChunkSize);
    this.stream.readChunkData(arrayOfByte, paramTbMsgExecutePrefetchReply.rowChunkSize);
    tbResultSet.setFetchCompleted(paramTbMsgExecutePrefetchReply.isFetchCompleted);
    tbResultSet.buildRowTable(paramTbMsgExecutePrefetchReply.rowCnt, arrayOfByte);
    paramTbStatement.setResultSet(tbResultSet);
    return (int)tbResultSet.getUpdateCount();
  }
  
  private int executeRsetNoDescReply(TbPreparedStatement paramTbPreparedStatement, TbMsgExecuteRsetNoDescReply paramTbMsgExecuteRsetNoDescReply) throws SQLException {
    TbResultSet tbResultSet = this.typeConverter.toResultSet(paramTbPreparedStatement.getOutColCnt(), paramTbPreparedStatement.getHiddenColCnt(), paramTbMsgExecuteRsetNoDescReply.csrId, paramTbPreparedStatement.getColMetaArray(), (TbStatement)paramTbPreparedStatement);
    paramTbPreparedStatement.setResultSet(tbResultSet);
    return (int)tbResultSet.getUpdateCount();
  }
  
  private int executeRsetReply(TbStatement paramTbStatement, TbMsgExecuteRsetReply paramTbMsgExecuteRsetReply) throws SQLException {
    TbResultSet tbResultSet = this.typeConverter.toResultSet(paramTbMsgExecuteRsetReply.colCnt, paramTbMsgExecuteRsetReply.hiddenColCnt, paramTbMsgExecuteRsetReply.csrId, paramTbMsgExecuteRsetReply.colMeta, paramTbStatement);
    paramTbStatement.setResultSet(tbResultSet);
    return paramTbMsgExecuteRsetReply.affectedCnt;
  }
  
  public void fetch(TbStatement paramTbStatement, TbResultSetBase paramTbResultSetBase) throws SQLException {
    synchronized (this.stream) {
      SQLException sQLException;
      String str;
      int i = paramTbResultSetBase.getFetchSize();
      int j = paramTbResultSetBase.getPreparedFetchCnt();
      if (j <= 0) {
        TbMsgSend.FETCH(this.stream, paramTbResultSetBase.getCursorId(), i);
        j = i * -1;
      } 
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 19:
          fetchReply(paramTbStatement, (TbMsgFetchReply)tbMsg, paramTbResultSetBase);
          j--;
          break;
        case 76:
          sQLException = getErrorMessage(-90509, tbMsg);
          str = sQLException.getSQLState();
          if (sQLException.getErrorCode() == -12018)
            ((TbMsgEreply)tbMsg).changeRootException(new SQLException(TbError.getMsg(-12031), str, -12031)); 
          throwEreply(-90509, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
      paramTbResultSetBase.setPreparedFetchCnt(j);
    } 
  }
  
  private void fetchReply(TbStatement paramTbStatement, TbMsgFetchReply paramTbMsgFetchReply, TbResultSetBase paramTbResultSetBase) throws SQLException {
    byte[] arrayOfByte = paramTbResultSetBase.getRowChunk(paramTbMsgFetchReply.rowChunkSize);
    this.stream.readChunkData(arrayOfByte, paramTbMsgFetchReply.rowChunkSize);
    paramTbResultSetBase.setFetchCompleted(paramTbMsgFetchReply.isFetchCompleted);
    paramTbResultSetBase.buildRowTable(paramTbMsgFetchReply.rowCnt, arrayOfByte);
  }
  
  public void freeTemporary(TbLob paramTbLob) throws SQLException {
    lobFreeTemporary(paramTbLob);
  }
  
  public TbResultSet describeCSRReply(TbStatement paramTbStatement, int paramInt) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.DESCRIBE_CSR(this.stream, paramInt);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 11:
          return doDescribeCSRPrefetch(paramTbStatement, (TbMsgExecutePrefetchReply)tbMsg);
        case 76:
          throwEreply(-90546, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
    return null;
  }
  
  private TbResultSet doDescribeCSRPrefetch(TbStatement paramTbStatement, TbMsgExecutePrefetchReply paramTbMsgExecutePrefetchReply) throws SQLException {
    if (paramTbMsgExecutePrefetchReply.colMeta == null)
      throw TbError.newSQLException(-90644); 
    TbResultSet tbResultSet = TbResultSetFactory.buildResultSet(paramTbStatement, paramTbMsgExecutePrefetchReply.csrId, paramTbMsgExecutePrefetchReply.colMeta.length, 0);
    this.typeConverter.buildColumnMetadata(paramTbMsgExecutePrefetchReply.colMeta, tbResultSet, paramTbMsgExecutePrefetchReply.colMeta.length);
    byte[] arrayOfByte = tbResultSet.getRowChunk(paramTbMsgExecutePrefetchReply.rowChunkSize);
    this.stream.readChunkData(arrayOfByte, paramTbMsgExecutePrefetchReply.rowChunkSize);
    tbResultSet.setFetchCompleted(paramTbMsgExecutePrefetchReply.isFetchCompleted);
    tbResultSet.buildRowTable(paramTbMsgExecutePrefetchReply.rowCnt, arrayOfByte);
    paramTbStatement.addSubResultSet(tbResultSet);
    return tbResultSet;
  }
  
  public SQLException getErrorMessage(int paramInt, TbMsg paramTbMsg) throws SQLException {
    TbMsgEreply tbMsgEreply = (TbMsgEreply)paramTbMsg;
    if (tbMsgEreply.flag == Integer.MIN_VALUE)
      reset(); 
    return tbMsgEreply.getException(paramInt);
  }
  
  public TbSQLInfo getLastExecutedSqlinfo() throws SQLException {
    synchronized (this.stream) {
      TbMsgGetLastExecutedSqlinfoReply tbMsgGetLastExecutedSqlinfoReply;
      TbSQLInfo tbSQLInfo;
      TbMsgSend.GET_LAST_EXECUTED_SQLINFO(this.stream, this.conn.getSessionId());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 74:
          tbMsgGetLastExecutedSqlinfoReply = (TbMsgGetLastExecutedSqlinfoReply)tbMsg;
          tbSQLInfo = new TbSQLInfo();
          tbSQLInfo.setSqlid(tbMsgGetLastExecutedSqlinfoReply.sqlid);
          tbSQLInfo.setHashval(tbMsgGetLastExecutedSqlinfoReply.hashval);
          return tbSQLInfo;
        case 76:
          throwEreply(-90535, tbMsg);
          break;
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return null;
  }
  
  public TbStream getStream() {
    return this.stream;
  }
  
  protected TbConnection getTbConnection() {
    return this.conn;
  }
  
  public TbStream getTbStream() {
    return this.stream;
  }
  
  public SQLWarning getWarningMessage() throws SQLException {
    return null;
  }
  
  private void justOKReply(TbMsgOkReply paramTbMsgOkReply) {
    if (paramTbMsgOkReply.warningMsg != null && paramTbMsgOkReply.warningMsg.length() > 0)
      this.conn.addWarning(new SQLWarning(paramTbMsgOkReply.warningMsg)); 
  }
  
  public long length(TbLob paramTbLob) throws SQLException {
    long l = lobLength(paramTbLob);
    return (paramTbLob instanceof TbBlob) ? l : (l / this.typeConverter.getUCS2MaxBytesPerChar());
  }
  
  private boolean lobClose(TbLob paramTbLob) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.LOB_CLOSE(this.stream, paramTbLob.getLocator(), paramTbLob.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 51:
          paramTbLob.setLocator(((TbMsgLobCloseReply)tbMsg).slobLoc);
          return true;
        case 76:
          throw getErrorMessage(-90522, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return false;
  }
  
  private byte[] lobCreateTemporary(int paramInt) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.LOB_CREATE_TEMP(this.stream, paramInt);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 44:
          return ((TbMsgLobCreateTempReply)tbMsg).slobLoc;
        case 76:
          throw getErrorMessage(-90524, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return null;
  }
  
  private void lobFreeTemporary(TbLob paramTbLob) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.LOB_DELETE_TEMP(this.stream, paramTbLob.getLocator(), paramTbLob.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throw getErrorMessage(-90525, tbMsg);
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  private long lobLength(TbLob paramTbLob) throws SQLException {
    synchronized (this.stream) {
      TbMsgLobLengthReply tbMsgLobLengthReply;
      TbMsgSend.LOB_LENGTH(this.stream, paramTbLob.getLocator(), paramTbLob.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 34:
          tbMsgLobLengthReply = (TbMsgLobLengthReply)tbMsg;
          return (0xFFFFFFFF00000000L & tbMsgLobLengthReply.lenHigh << 32L) + (0xFFFFFFFFL & tbMsgLobLengthReply.lenLow);
        case 76:
          throw getErrorMessage(-90523, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return 0L;
  }
  
  private boolean lobOpen(TbLob paramTbLob, int paramInt) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.LOB_OPEN(this.stream, paramInt, paramTbLob.getLocator(), paramTbLob.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 49:
          paramTbLob.setLocator(((TbMsgLobOpenReply)tbMsg).slobLoc);
          return true;
        case 76:
          throw getErrorMessage(-90521, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return false;
  }
  
  private long lobPosition(TbLob paramTbLob, String paramString, long paramLong) throws SQLException {
    int i = (int)(paramLong >> 32L);
    int j = (int)(paramLong & 0xFFFFFFFFL);
    synchronized (this.stream) {
      TbMsgLobInstrReply tbMsgLobInstrReply;
      TbMsgSend.LOB_INSTR(this.stream, i, j, paramTbLob.getLocator(), paramTbLob.getLocatorLength(), paramString);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 40:
          tbMsgLobInstrReply = (TbMsgLobInstrReply)tbMsg;
          return 0xFFFFFFFF00000000L & (tbMsgLobInstrReply.offsetHigh << 32) + (0xFFFFFFFFL & tbMsgLobInstrReply.offsetLow);
        case 76:
          throw getErrorMessage(-90518, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return 0L;
  }
  
  private long lobPosition(TbLob paramTbLob1, TbLob paramTbLob2, long paramLong) throws SQLException {
    int i = (int)(paramLong >> 32L);
    int j = (int)(paramLong & 0xFFFFFFFFL);
    synchronized (this.stream) {
      TbMsgLobInlobReply tbMsgLobInlobReply;
      TbMsgSend.LOB_INLOB(this.stream, i, j, paramTbLob1.getLocator(), paramTbLob1.getLocatorLength(), paramTbLob2.getLocator(), paramTbLob2.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 47:
          tbMsgLobInlobReply = (TbMsgLobInlobReply)tbMsg;
          return 0xFFFFFFFF00000000L & (tbMsgLobInlobReply.offsetHigh << 32) + (0xFFFFFFFFL & tbMsgLobInlobReply.offsetLow);
        case 76:
          throw getErrorMessage(-90519, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return 0L;
  }
  
  private int lobRead(TbLob paramTbLob, long paramLong1, char[] paramArrayOfchar, byte[] paramArrayOfbyte, long paramLong2, int paramInt) throws SQLException {
    int i = (int)(paramLong1 >> 32L);
    int j = (int)(paramLong1 & 0xFFFFFFFFL);
    synchronized (this.stream) {
      TbMsgSend.LOB_READ(this.stream, i, j, paramInt, paramTbLob.getLocator(), paramTbLob.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 36:
          return lobReadReply((TbMsgLobReadReply)tbMsg, paramTbLob, paramLong1, paramArrayOfchar, paramArrayOfbyte, paramLong2, paramInt);
        case 76:
          throw getErrorMessage(-90516, tbMsg);
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
    return 0;
  }
  
  private int lobReadReply(TbMsgLobReadReply paramTbMsgLobReadReply, TbLob paramTbLob, long paramLong1, char[] paramArrayOfchar, byte[] paramArrayOfbyte, long paramLong2, int paramInt) throws SQLException {
    int i = 0;
    if (paramTbMsgLobReadReply.data != null)
      i = paramTbMsgLobReadReply.data.length; 
    if (i == paramInt) {
      paramTbLob.setEndOfStream(false);
    } else {
      paramTbLob.setEndOfStream(true);
    } 
    if (i <= 0)
      return 0; 
    if (paramTbLob instanceof com.tmax.tibero.jdbc.TbClob || paramTbLob instanceof com.tmax.tibero.jdbc.TbNClob)
      return this.typeConverter.fixedBytesToChars(paramTbMsgLobReadReply.data, 0, i, paramArrayOfchar, (int)paramLong2, (int)(paramArrayOfchar.length - paramLong2)); 
    System.arraycopy(paramTbMsgLobReadReply.data, 0, paramArrayOfbyte, (int)paramLong2, i);
    return i;
  }
  
  private void lobTruncate(TbLob paramTbLob, long paramLong) throws SQLException {
    int i = (int)(paramLong >> 32L);
    int j = (int)(paramLong & 0xFFFFFFFFL);
    synchronized (this.stream) {
      TbMsgSend.LOB_TRUNC(this.stream, i, j, paramTbLob.getLocator(), paramTbLob.getLocatorLength());
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 38:
          paramTbLob.setLocator(((TbMsgLobTruncReply)tbMsg).slobLoc);
          break;
        case 76:
          throw getErrorMessage(-90520, tbMsg);
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  private void lobWrite(TbLob paramTbLob, long paramLong1, char[] paramArrayOfchar, byte[] paramArrayOfbyte, long paramLong2, long paramLong3, int paramInt) throws SQLException {
    int i = (int)(paramLong1 >> 32L);
    int j = (int)(paramLong1 & 0xFFFFFFFFL);
    int k = 0;
    byte[] arrayOfByte = null;
    if (paramTbLob instanceof com.tmax.tibero.jdbc.TbClob || paramTbLob instanceof com.tmax.tibero.jdbc.TbNClob) {
      int m = this.typeConverter.getUCS2MaxBytesPerChar() * (int)paramLong3;
      arrayOfByte = new byte[m];
      k = m;
      this.typeConverter.charsToFixedBytes(paramArrayOfchar, (int)paramLong2, (int)paramLong3, arrayOfByte, 0, k);
    } else {
      int m = TbCommon.getPadLength((int)paramLong3);
      arrayOfByte = new byte[(int)paramLong3 + m];
      k = (int)paramLong3;
      System.arraycopy(paramArrayOfbyte, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
      TbCommon.writePadding(arrayOfByte, (int)paramLong3, m);
    } 
    synchronized (this.stream) {
      TbMsgSend.LOB_WRITE(this.stream, i, j, paramInt, paramTbLob.getLocator(), paramTbLob.getLocatorLength(), arrayOfByte, k);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 42:
          lobWriteReply(paramTbLob, (TbMsgLobWriteReply)tbMsg, paramInt);
          break;
        case 76:
          throw getErrorMessage(-90517, tbMsg);
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  private void lobWriteReply(TbLob paramTbLob, TbMsgLobWriteReply paramTbMsgLobWriteReply, int paramInt) {
    if ((paramInt & 0x2000000) == 0)
      return; 
    paramTbLob.setLocator(paramTbMsgLobWriteReply.slobLoc);
  }
  
  public synchronized void logon() throws SQLException {
    while (true) {
      synchronized (this.stream) {
        TbMsg tbMsg = this.stream.readMsg();
        switch (tbMsg.getMsgType()) {
          case 0:
            if (!logonConnectReply((TbMsgConnectReply)tbMsg))
              return; 
            logonAuthRequest();
            break;
          case 2:
            logonSessInfoReply((TbMsgSessInfoReply)tbMsg);
            if (this.conn.info.getNetworkProtocol().equalsIgnoreCase("TCPS"))
              logonAcceptSSLConnReply(); 
            return;
          case 76:
            logonEreply(tbMsg);
            return;
          default:
            throwProtocolError(tbMsg.getMsgType());
            break;
        } 
      } 
    } 
  }
  
  private void logonAcceptSSLConnReply() throws SQLException {
    TbMsg tbMsg = this.stream.readMsg();
    switch (tbMsg.getMsgType()) {
      case 144:
        this.stream.handshakeSSL();
        return;
      case 76:
        throwEreply(-90502, tbMsg);
        return;
    } 
    throwProtocolError(tbMsg.getMsgType());
  }
  
  private void logonAuthRequest() throws SQLException {
    String str1 = this.conn.info.getUser();
    String str2 = this.conn.info.getPassword();
    if (str2.length() >= 2 && str2.startsWith("\"") && str2.endsWith("\""))
      str2 = str2.substring(1, str2.length() - 1); 
    String str3 = this.conn.info.getDatabaseName();
    if (str3.length() >= 2 && str3.startsWith("\"") && str3.endsWith("\""))
      str3 = str3.substring(1, str3.length() - 1); 
    String str4 = this.conn.info.getProgramName();
    if (str4 == null)
      str4 = "JDBC Thin Client"; 
    String str5 = System.getProperty("user.name");
    String str6 = null;
    try {
      str6 = InetAddress.getLocalHost().getHostName();
    } catch (UnknownHostException unknownHostException) {}
    TbClntInfoParam[] arrayOfTbClntInfoParam = new TbClntInfoParam[7];
    int i;
    for (i = 0; i < 7; i++)
      arrayOfTbClntInfoParam[i] = new TbClntInfoParam(); 
    arrayOfTbClntInfoParam[0].set(0, "-1");
    arrayOfTbClntInfoParam[1].set(1, str4);
    arrayOfTbClntInfoParam[2].set(2, null);
    arrayOfTbClntInfoParam[3].set(3, str5);
    arrayOfTbClntInfoParam[4].set(4, str6);
    i = 0;
    String str7 = this.conn.info.getNewPassword();
    if (this.logonWithNewPassword)
      if (str7 != null && str7.length() != 0) {
        i |= 0x10;
        arrayOfTbClntInfoParam[5].set(5, str2);
        str2 = str7;
      } else {
        arrayOfTbClntInfoParam[5].set(5, null);
      }  
    TbNlsParam[] arrayOfTbNlsParam = new TbNlsParam[9];
    for (byte b = 0; b < 9; b++)
      arrayOfTbNlsParam[b] = new TbNlsParam(); 
    arrayOfTbNlsParam[0].set(0, null);
    arrayOfTbNlsParam[1].set(1, null);
    arrayOfTbNlsParam[2].set(2, null);
    arrayOfTbNlsParam[3].set(6, null);
    arrayOfTbNlsParam[4].set(3, CharsetMetaData.getNLSLanguage(Locale.getDefault()));
    arrayOfTbNlsParam[5].set(4, null);
    arrayOfTbNlsParam[6].set(5, null);
    TimeZone timeZone = TimeZone.getDefault();
    String str8 = ZoneInfo.convertStandardTimeZoneID(timeZone.getID());
    arrayOfTbNlsParam[7].set(7, str8);
    TbMsgSend.AUTH_REQ_WITH_VER(this.stream, 2, 5, i, str1, str3, str2, arrayOfTbClntInfoParam.length, arrayOfTbClntInfoParam, arrayOfTbNlsParam.length, arrayOfTbNlsParam, 1);
  }
  
  private boolean logonConnectReply(TbMsgConnectReply paramTbMsgConnectReply) throws SQLException {
    if (this.conn.info.isLoadBalance() && !this.conn.isMiddleOfFailover() && paramTbMsgConnectReply.flags == 4096) {
      ConnectionInfo connectionInfo = this.conn.info;
      try {
        this.conn.close();
      } catch (SQLException sQLException) {}
      this.conn.openConnection(connectionInfo);
      return false;
    } 
    int i = Charset.getCharset(this.conn.info.getCharacterSet());
    if (i == -1)
      i = paramTbMsgConnectReply.charset; 
    if (paramTbMsgConnectReply.protocolMajor < 2)
      throw TbError.newSQLException(-90203); 
    ServerInfo serverInfo = new ServerInfo(i, paramTbMsgConnectReply.ncharset, paramTbMsgConnectReply.svrIsBigendian, paramTbMsgConnectReply.svrIsNanobase, paramTbMsgConnectReply.tbMajor, paramTbMsgConnectReply.tbMinor, paramTbMsgConnectReply.tbProductName, paramTbMsgConnectReply.tbProductVersion, paramTbMsgConnectReply.protocolMajor, paramTbMsgConnectReply.protocolMinor);
    this.conn.setServerInfo(serverInfo);
    this.conn.setMthrPid(paramTbMsgConnectReply.mthrPid);
    this.typeConverter.setCharset(this.conn.getServerCharSet(), this.conn.getServerNCharSet());
    this.conn.setMaxDFRCharCount();
    return true;
  }
  
  private void logonEreply(TbMsg paramTbMsg) throws SQLException {
    ConnectionInfo connectionInfo = this.conn.info;
    SQLException sQLException = getErrorMessage(-90502, paramTbMsg);
    if (sQLException.getErrorCode() == -12060) {
      try {
        this.conn.close();
      } catch (SQLException sQLException1) {}
      this.conn.openConnection(connectionInfo);
      connectionInfo = null;
    } else if (sQLException.getErrorCode() == -12004) {
      logon();
    } else {
      throw sQLException;
    } 
  }
  
  private void logonSessInfoReply(TbMsgSessInfoReply paramTbMsgSessInfoReply) {
    this.conn.setSessionId(paramTbMsgSessInfoReply.sessionId);
    this.conn.setSerialNo(paramTbMsgSessInfoReply.serialNo);
    this.conn.setNLSDate((paramTbMsgSessInfoReply.nlsData[0]).nlsParamVal);
    this.conn.setNLSTimestamp((paramTbMsgSessInfoReply.nlsData[2]).nlsParamVal);
    boolean bool = false;
    if (paramTbMsgSessInfoReply.nlsData.length > 8 && (paramTbMsgSessInfoReply.nlsData[8]).nlsParamVal != null && (paramTbMsgSessInfoReply.nlsData[8]).nlsParamVal.equals("Y"))
      bool = true; 
    if (bool) {
      this.conn.setNLSWarning(bool);
      SQLException sQLException = TbError.newSQLException(-90547);
      this.conn.addWarning(new SQLWarning(sQLException.getMessage(), sQLException.getSQLState(), -90547));
    } 
  }
  
  public boolean open(TbLob paramTbLob, int paramInt) throws SQLException {
    return lobOpen(paramTbLob, paramInt);
  }
  
  public void openSession() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.OPEN_SESS(this.stream);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90504, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public long position(TbBlob paramTbBlob, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
    return lobPosition((TbLob)paramTbBlob, paramArrayOfbyte.toString(), paramLong);
  }
  
  public long position(TbClobBase paramTbClobBase, char[] paramArrayOfchar, long paramLong) throws SQLException {
    long l = lobPosition((TbLob)paramTbClobBase, paramArrayOfchar.toString(), paramLong);
    return l * this.typeConverter.getUCS2MaxBytesPerChar();
  }
  
  public long position(TbLob paramTbLob1, TbLob paramTbLob2, long paramLong) throws SQLException {
    long l = lobPosition(paramTbLob1, paramTbLob2, paramLong);
    return (paramTbLob1 instanceof TbBlob) ? l : (l * this.typeConverter.getUCS2MaxBytesPerChar());
  }
  
  public void prepare(TbPreparedStatement paramTbPreparedStatement, String paramString, Vector<Integer> paramVector) throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.PREPARE(this.stream, paramString);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 4:
          prepareReply(paramTbPreparedStatement, (TbMsgPrepareReply)tbMsg, paramVector);
          return;
        case 76:
          throwEreply(-90506, tbMsg);
          return;
      } 
      throwProtocolError(tbMsg.getMsgType());
    } 
  }
  
  public int prepareExecute(TbPreparedStatement paramTbPreparedStatement, String paramString, int paramInt) throws SQLException {
    if (paramTbPreparedStatement.getPPID() != null)
      return paramTbPreparedStatement.isUdt() ? executeUdt(paramTbPreparedStatement, paramString, paramInt) : execute(paramTbPreparedStatement, paramString, paramInt); 
    synchronized (this.stream) {
      if (paramTbPreparedStatement.isUdt()) {
        processExecuteUdt(paramTbPreparedStatement, paramString, paramInt, false);
      } else {
        processExecute(paramTbPreparedStatement, paramString, paramInt, false);
      } 
      TbMsg tbMsg = this.stream.readMsg();
      while (true) {
        TbMsgExecuteCountReply tbMsgExecuteCountReply;
        TbMsgExecutePrefetchReply tbMsgExecutePrefetchReply;
        TbMsgExecuteRsetReply tbMsgExecuteRsetReply;
        TbMsgExecutePsmReply tbMsgExecutePsmReply;
        TbMsgExecutePsmPrefetchReply tbMsgExecutePsmPrefetchReply;
        TbMsgExecuteCallReply tbMsgExecuteCallReply;
        TbMsgExecuteUdtCallReply tbMsgExecuteUdtCallReply;
        switch (tbMsg.getMsgType()) {
          case 75:
            justOKReply((TbMsgOkReply)tbMsg);
            return TbSQLTypeScanner.isPSMStmt(paramTbPreparedStatement.getSqlType()) ? 1 : 0;
          case 2:
            return 0;
          case 13:
            tbMsgExecuteCountReply = (TbMsgExecuteCountReply)tbMsg;
            paramTbPreparedStatement.setPPID(tbMsgExecuteCountReply.ppid);
            return executeCountReply((TbStatement)paramTbPreparedStatement, tbMsgExecuteCountReply);
          case 11:
            tbMsgExecutePrefetchReply = (TbMsgExecutePrefetchReply)tbMsg;
            paramTbPreparedStatement.setPPID(tbMsgExecutePrefetchReply.ppid);
            paramTbPreparedStatement.buildColMetaArray(tbMsgExecutePrefetchReply.colCnt, tbMsgExecutePrefetchReply.hiddenColCnt, tbMsgExecutePrefetchReply.colMeta);
            return executePrefetchReply((TbStatement)paramTbPreparedStatement, tbMsgExecutePrefetchReply);
          case 8:
            tbMsgExecuteRsetReply = (TbMsgExecuteRsetReply)tbMsg;
            paramTbPreparedStatement.setPPID(tbMsgExecuteRsetReply.ppid);
            paramTbPreparedStatement.buildColMetaArray(tbMsgExecuteRsetReply.colCnt, tbMsgExecuteRsetReply.hiddenColCnt, tbMsgExecuteRsetReply.colMeta);
            return executeRsetReply((TbStatement)paramTbPreparedStatement, tbMsgExecuteRsetReply);
          case 16:
            return executeNeedDataReply(tbMsg, paramTbPreparedStatement, paramInt);
          case 15:
            tbMsgExecutePsmReply = (TbMsgExecutePsmReply)tbMsg;
            return executeCallReply(paramTbPreparedStatement, paramInt, tbMsgExecutePsmReply.paramData);
          case 183:
            tbMsgExecutePsmPrefetchReply = (TbMsgExecutePsmPrefetchReply)tbMsg;
            paramTbPreparedStatement.setPPID(tbMsgExecutePsmPrefetchReply.ppid);
            paramTbPreparedStatement.buildColMetaArray(tbMsgExecutePsmPrefetchReply.colCnt, tbMsgExecutePsmPrefetchReply.hiddenColCnt, tbMsgExecutePsmPrefetchReply.colMeta);
            if (!(paramTbPreparedStatement instanceof TbCallableStatement))
              return 1; 
            return executePsmPrefetchReply((TbCallableStatement)paramTbPreparedStatement, paramInt, tbMsgExecutePsmPrefetchReply);
          case 14:
            tbMsgExecuteCallReply = (TbMsgExecuteCallReply)tbMsg;
            return executeCallReply(paramTbPreparedStatement, paramInt, tbMsgExecuteCallReply.paramData);
          case 187:
            return executeUdtPsmReply(paramTbPreparedStatement, paramInt, (TbMsgExecuteUdtPsmReply)tbMsg);
          case 186:
            tbMsgExecuteUdtCallReply = (TbMsgExecuteUdtCallReply)tbMsg;
            return executeUdtCallReply(paramTbPreparedStatement, paramInt, tbMsgExecuteUdtCallReply.paramData);
          case 9:
            tbMsg = executePivotReply((TbStatement)paramTbPreparedStatement, (TbMsgExecutePivotReply)tbMsg);
            continue;
          case 76:
            throwEreply(-90508, tbMsg);
            break;
        } 
        throwProtocolError(tbMsg.getMsgType());
      } 
    } 
  }
  
  private int executeUdtCallReply(TbPreparedStatement paramTbPreparedStatement, int paramInt, TbOutParamUdt[] paramArrayOfTbOutParamUdt) throws SQLException {
    byte b = -1;
    byte b1 = (paramArrayOfTbOutParamUdt == null) ? 0 : paramArrayOfTbOutParamUdt.length;
    BindData bindData = paramTbPreparedStatement.getBindData();
    int i = paramTbPreparedStatement.getParameterCnt();
    if (bindData.getOutParameterCnt() != b1)
      throw TbError.newSQLException(-90618); 
    if (paramArrayOfTbOutParamUdt == null || !(paramTbPreparedStatement instanceof TbCallableStatement))
      return 1; 
    TbCallableStatement tbCallableStatement = (TbCallableStatement)paramTbPreparedStatement;
    for (byte b2 = 0; b2 < b1; b2++) {
      while (++b < i && !bindData.isOutParameterOn(b))
        b++; 
      if (b >= i)
        throw TbError.newSQLException(-90618); 
      BindItem bindItem1 = bindData.getBindItem(b);
      BindItem bindItem2 = tbCallableStatement.getOutItems(b);
      bindItem2.set(bindItem1.getSQLType(), (paramArrayOfTbOutParamUdt[b2]).value.length, (paramArrayOfTbOutParamUdt[b2]).colMeta);
      tbCallableStatement.setOutParam(b, (paramArrayOfTbOutParamUdt[b2]).dataType, (paramArrayOfTbOutParamUdt[b2]).value);
    } 
    return 1;
  }
  
  private void prepareReply(TbPreparedStatement paramTbPreparedStatement, TbMsgPrepareReply paramTbMsgPrepareReply, Vector<Integer> paramVector) {
    if (paramTbMsgPrepareReply.isPreparedDdl == 1) {
      paramTbPreparedStatement.setPPID(null);
      paramTbPreparedStatement.setParameterCnt(0);
    } else {
      int i = paramTbMsgPrepareReply.bindParamCnt;
      paramTbPreparedStatement.setPPID(paramTbMsgPrepareReply.ppid);
      paramTbPreparedStatement.setParameterCnt(i);
      for (byte b = 0; b < i; b++)
        paramVector.add(b, new Integer((paramTbMsgPrepareReply.bindParamMeta[b]).type)); 
      paramTbPreparedStatement.buildColMetaArray(paramTbMsgPrepareReply.outColCnt, paramTbMsgPrepareReply.hiddenColCnt, paramTbMsgPrepareReply.colDesc);
    } 
  }
  
  private void processExecute(TbPreparedStatement paramTbPreparedStatement, String paramString, int paramInt, boolean paramBoolean) throws SQLException {
    TbStreamDataWriter tbStreamDataWriter = this.stream.getMsgWriter();
    boolean bool = this.conn.getAutoCommit() ? true : false;
    BindData bindData = paramTbPreparedStatement.getBindData();
    Binder[][] arrayOfBinder = paramTbPreparedStatement.getBinder();
    int i = bindData.getParameterCnt();
    this.stream.startWritingPacketData();
    if (paramBoolean) {
      tbStreamDataWriter.writeInt(5, 4);
    } else {
      tbStreamDataWriter.writeInt(7, 4);
    } 
    tbStreamDataWriter.writeInt(0, 4);
    tbStreamDataWriter.writeLong(0L, 8);
    if (paramBoolean) {
      tbStreamDataWriter.writeBytes(paramTbPreparedStatement.getPPID());
    } else {
      tbStreamDataWriter.writeLenAndDBEncodedPadString((paramString == null) ? "" : paramString);
    } 
    tbStreamDataWriter.writeInt(bool, 4);
    tbStreamDataWriter.writeInt(paramTbPreparedStatement.getPreFetchSize(), 4);
    tbStreamDataWriter.writeInt(i, 4);
    for (byte b = 0; b < i; b++) {
      if (arrayOfBinder[paramInt][b] == null)
        throw TbError.newSQLException(-90627); 
      BindItem bindItem = bindData.getBindItem(b);
      int j = bindItem.getParamMode() & 0xFF | paramTbPreparedStatement.getParamType(paramInt, b) << 8 & 0xFFFFFF00;
      tbStreamDataWriter.writeInt(j, 4);
      arrayOfBinder[paramInt][b].bind(this.conn, paramTbPreparedStatement, tbStreamDataWriter, paramInt, b, bindItem.getLength());
    } 
    tbStreamDataWriter.reWriteInt(4, tbStreamDataWriter.getBufferedDataSize() - 16, 4);
    this.stream.flush();
  }
  
  private void processExecuteUdt(TbPreparedStatement paramTbPreparedStatement, String paramString, int paramInt, boolean paramBoolean) throws SQLException {
    boolean bool = this.conn.getAutoCommit() ? true : false;
    BindData bindData = paramTbPreparedStatement.getBindData();
    int i = bindData.getParameterCnt();
    this.stream.startWritingPacketData();
    if (paramBoolean) {
      TbBindparamUdt[] arrayOfTbBindparamUdt = paramTbPreparedStatement.getParamUdtArrayOfRow(paramInt);
      TbMsgSend.EXECUTE_UDT(this.stream, paramTbPreparedStatement.getPPID(), bool, paramTbPreparedStatement.getPreFetchSize(), i, arrayOfTbBindparamUdt);
    } else {
      Binder[][] arrayOfBinder = paramTbPreparedStatement.getBinder();
      TbBindparamUdt[] arrayOfTbBindparamUdt = paramTbPreparedStatement.getParamUdtArrayOfRow(paramInt);
      for (byte b = 0; b < i; b++) {
        if (arrayOfTbBindparamUdt[b] == null) {
          String str;
          TbBindparamUdt tbBindparamUdt;
          int k;
          int m;
          byte[] arrayOfByte;
          BindItem bindItem = bindData.getBindItem(b);
          int j = DataType.getDataType(bindItem.getSQLType());
          switch (j) {
            case 3:
              str = paramTbPreparedStatement.getParamString(paramInt, b);
              tbBindparamUdt = new TbBindparamUdt();
              k = bindItem.getParamMode();
              m = k & 0xFF | j << 8 & 0xFFFFFF00;
              arrayOfByte = this.typeConverter.fromString(str);
              tbBindparamUdt.set(m, arrayOfByte, arrayOfByte.length, 0, null);
              arrayOfTbBindparamUdt[b] = tbBindparamUdt;
              break;
          } 
        } 
      } 
      TbMsgSend.PREPARE_EXECUTE_UDT(this.stream, paramString, bool, paramTbPreparedStatement.getPreFetchSize(), i, arrayOfTbBindparamUdt);
    } 
  }
  
  public long read(TbBlob paramTbBlob, long paramLong1, byte[] paramArrayOfbyte, long paramLong2, long paramLong3) throws SQLException {
    int i = 0;
    int j = 0;
    long l = 0L;
    do {
      if (paramLong3 - l >= 32000L) {
        i = 32000;
      } else {
        i = (int)(paramLong3 - l);
      } 
      j = lobRead((TbLob)paramTbBlob, paramLong1 + l, null, paramArrayOfbyte, paramLong2 + l, i);
      l += j;
    } while (paramLong3 > l && i == j);
    return l;
  }
  
  public long read(TbClobBase paramTbClobBase, long paramLong1, char[] paramArrayOfchar, long paramLong2, long paramLong3) throws SQLException {
    int i = 0;
    int j = 0;
    long l1 = 0L;
    byte b = 2;
    long l2 = paramLong1 * b;
    int k = 32000 / b;
    do {
      if (paramLong3 - l1 >= k) {
        i = k;
      } else {
        i = (int)(paramLong3 - l1);
      } 
      j = lobRead((TbLob)paramTbClobBase, l2, paramArrayOfchar, null, paramLong2 + l1, i * b);
      l1 += j;
      l2 += (j * b);
    } while (paramLong3 > l1 && !paramTbClobBase.isEndOfStream());
    return l1;
  }
  
  public String readLong(byte[] paramArrayOfbyte) throws SQLException {
    StringBuffer stringBuffer = new StringBuffer();
    TbMsgLongReadReply tbMsgLongReadReply = null;
    byte[] arrayOfByte = new byte[3];
    int i = 0;
    char[] arrayOfChar = new char[DriverConstants.MIN_DEFERRED_BYTE_SIZE];
    while (true) {
      synchronized (this.stream) {
        TbMsgSend.LONG_READ(this.stream, DriverConstants.MIN_DEFERRED_BYTE_SIZE, paramArrayOfbyte, paramArrayOfbyte.length);
        TbMsg tbMsg = this.stream.readMsg();
        switch (tbMsg.getMsgType()) {
          case 53:
            tbMsgLongReadReply = (TbMsgLongReadReply)tbMsg;
            paramArrayOfbyte = new byte[tbMsgLongReadReply.longLoc.length];
            System.arraycopy(tbMsgLongReadReply.longLoc, 0, paramArrayOfbyte, 0, paramArrayOfbyte.length);
            if (tbMsgLongReadReply.data != null && tbMsgLongReadReply.data.length != 0) {
              byte[] arrayOfByte1;
              if (i) {
                arrayOfByte1 = new byte[tbMsgLongReadReply.data.length + i];
                System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
                System.arraycopy(tbMsgLongReadReply.data, 0, arrayOfByte1, i, tbMsgLongReadReply.data.length);
                i = 0;
              } else {
                arrayOfByte1 = tbMsgLongReadReply.data;
              } 
              int j = this.typeConverter.getEndingBytePos(arrayOfByte1, arrayOfByte1.length - 1);
              if (j > arrayOfByte1.length - 1) {
                j = this.typeConverter.getLeadingBytePos(arrayOfByte1, arrayOfByte1.length - 1);
                i = arrayOfByte1.length - j;
                System.arraycopy(arrayOfByte1, j, arrayOfByte, 0, i);
              } 
              int k = this.typeConverter.bytesToChars(arrayOfByte1, 0, j + 1, arrayOfChar, 0, j + 1);
              stringBuffer.append(arrayOfChar, 0, k);
            } 
            break;
          case 76:
            throw getErrorMessage(-90534, tbMsg);
          default:
            throwProtocolError(tbMsg.getMsgType());
            break;
        } 
      } 
      if (tbMsgLongReadReply.isLastData != 0)
        return stringBuffer.toString(); 
    } 
  }
  
  public byte[] readLongRaw(byte[] paramArrayOfbyte) throws SQLException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    TbMsgLongReadReply tbMsgLongReadReply = null;
    while (true) {
      synchronized (this.stream) {
        TbMsgSend.LONG_READ(this.stream, DriverConstants.MIN_DEFERRED_BYTE_SIZE, paramArrayOfbyte, paramArrayOfbyte.length);
        TbMsg tbMsg = this.stream.readMsg();
        switch (tbMsg.getMsgType()) {
          case 53:
            tbMsgLongReadReply = (TbMsgLongReadReply)tbMsg;
            paramArrayOfbyte = new byte[tbMsgLongReadReply.longLoc.length];
            System.arraycopy(tbMsgLongReadReply.longLoc, 0, paramArrayOfbyte, 0, paramArrayOfbyte.length);
            byteArrayOutputStream.write(tbMsgLongReadReply.data, 0, tbMsgLongReadReply.data.length);
            break;
          case 76:
            throw getErrorMessage(-90534, tbMsg);
          default:
            throwProtocolError(tbMsg.getMsgType());
            break;
        } 
      } 
      if (tbMsgLongReadReply.isLastData != 0)
        return byteArrayOutputStream.toByteArray(); 
    } 
  }
  
  public void reset() {
    try {
      synchronized (this.stream) {
        if (this.stream != null) {
          this.stream.close();
          this.stream = null;
        } 
      } 
    } catch (SQLException sQLException) {}
    if (this.conn != null) {
      this.conn.reset();
      this.conn = null;
    } 
  }
  
  public void resetSession() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.RESET_SESS(this.stream);
    } 
  }
  
  public void rollback() throws SQLException {
    synchronized (this.stream) {
      TbMsgSend.ROLLBACK(this.stream, null);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90511, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void rollback(TbSavepoint paramTbSavepoint) throws SQLException {
    String str = null;
    if (paramTbSavepoint != null)
      try {
        str = paramTbSavepoint.getSavepointName();
      } catch (SQLException sQLException) {
        str = "SVPT" + paramTbSavepoint.getSavepointId();
      }  
    synchronized (this.stream) {
      TbMsgSend.ROLLBACK(this.stream, str);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90511, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void setClientInfo(String[] paramArrayOfString) throws SQLClientInfoException {
    TbSessAttrDesc[] arrayOfTbSessAttrDesc = new TbSessAttrDesc[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++)
      arrayOfTbSessAttrDesc[b].set(b, paramArrayOfString[b]); 
    synchronized (this.stream) {
      try {
        TbMsgSend.SESS_ATTR(this.stream, arrayOfTbSessAttrDesc.length, arrayOfTbSessAttrDesc);
        TbMsg tbMsg = this.stream.readMsg();
        switch (tbMsg.getMsgType()) {
          case 75:
            justOKReply((TbMsgOkReply)tbMsg);
            break;
          case 76:
            throwEreply(-90545, tbMsg);
            break;
          default:
            throwProtocolError(tbMsg.getMsgType());
            break;
        } 
      } catch (SQLException sQLException) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        for (byte b1 = 0; b1 < paramArrayOfString.length; b1++)
          hashMap.put(TbConnection.CLIENT_INFO_KEYS[b1], paramArrayOfString[b1]); 
        throw new SQLClientInfoException(sQLException.getMessage(), sQLException.getSQLState(), hashMap);
      } 
    } 
  }
  
  public void setIsolationLevel(int paramInt) throws SQLException {
    boolean bool = false;
    if (paramInt == 2) {
      bool = false;
    } else if (paramInt == 8) {
      bool = true;
    } else {
      throw TbError.newSQLException(-590722);
    } 
    synchronized (this.stream) {
      TbMsgSend.SET_ISL_LVL(this.stream, bool);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90513, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void setSavePoint(TbSavepoint paramTbSavepoint) throws SQLException {
    String str = null;
    try {
      str = paramTbSavepoint.getSavepointName();
    } catch (SQLException sQLException) {
      str = "SVPT" + paramTbSavepoint.getSavepointId();
    } 
    synchronized (this.stream) {
      TbMsgSend.SAVEPT(this.stream, str);
      TbMsg tbMsg = this.stream.readMsg();
      switch (tbMsg.getMsgType()) {
        case 75:
          justOKReply((TbMsgOkReply)tbMsg);
          break;
        case 76:
          throwEreply(-90514, tbMsg);
          break;
        default:
          throwProtocolError(tbMsg.getMsgType());
          break;
      } 
    } 
  }
  
  public void setLogonWithNewPassword(boolean paramBoolean) {
    this.logonWithNewPassword = paramBoolean;
  }
  
  private void throwEreply(int paramInt, TbMsg paramTbMsg) throws SQLException {
    SQLException sQLException = getErrorMessage(paramInt, paramTbMsg);
    throw sQLException;
  }
  
  private void throwProtocolError(int paramInt) throws SQLException {
    throw TbError.newSQLException(-590727, paramInt);
  }
  
  public void truncate(TbLob paramTbLob, long paramLong) throws SQLException {
    if (paramTbLob instanceof com.tmax.tibero.jdbc.TbNClob) {
      paramLong *= this.typeConverter.getMaxBytesPerNChar();
    } else if (paramTbLob instanceof com.tmax.tibero.jdbc.TbClob) {
      paramLong *= this.typeConverter.getUCS2MaxBytesPerChar();
    } 
    lobTruncate(paramTbLob, paramLong);
  }
  
  public long write(TbBlob paramTbBlob, long paramLong1, byte[] paramArrayOfbyte, long paramLong2, long paramLong3) throws SQLException {
    boolean bool1 = true;
    boolean bool2 = false;
    int i = 0;
    long l = 0L;
    int j = 0;
    if (paramLong3 <= 32000L) {
      lobWrite((TbLob)paramTbBlob, paramLong1, null, paramArrayOfbyte, paramLong2, paramLong3, 50331648);
      return paramLong3;
    } 
    while (true) {
      if (paramLong3 - l > 32000L) {
        i = 32000;
      } else {
        i = (int)(paramLong3 - l);
        bool2 = true;
      } 
      j = 0;
      if (bool1) {
        j = 16777216;
      } else if (bool2) {
        j = 33554432;
      } 
      try {
        lobWrite((TbLob)paramTbBlob, paramLong1 + l, null, paramArrayOfbyte, paramLong2 + l, i, j);
      } catch (SQLException sQLException) {
        if (!bool1)
          cancel(); 
        throw sQLException;
      } 
      l += i;
      bool1 = false;
      if (paramLong3 <= l)
        return l; 
    } 
  }
  
  public long write(TbClobBase paramTbClobBase, long paramLong1, char[] paramArrayOfchar, long paramLong2, long paramLong3) throws SQLException {
    boolean bool1 = true;
    boolean bool2 = false;
    int i = 0;
    long l1 = 0L;
    int j = 0;
    byte b = 2;
    int k = 32000 / b;
    long l2 = paramLong1 * b;
    if (paramLong3 <= k) {
      lobWrite((TbLob)paramTbClobBase, l2, paramArrayOfchar, null, paramLong2, paramLong3, 50331648);
      return paramLong3;
    } 
    while (true) {
      if (paramLong3 - l1 > k) {
        i = k;
      } else {
        i = (int)(paramLong3 - l1);
        bool2 = true;
      } 
      j = 0;
      if (bool1) {
        j = 16777216;
      } else if (bool2) {
        j = 33554432;
      } 
      try {
        lobWrite((TbLob)paramTbClobBase, l2, paramArrayOfchar, null, paramLong2 + l1, i, j);
      } catch (SQLException sQLException) {
        if (!bool1)
          cancel(); 
        throw sQLException;
      } 
      l1 += i;
      l2 += (i * b);
      bool1 = false;
      if (paramLong3 <= l1)
        return l1; 
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\comm\TbCommType4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */