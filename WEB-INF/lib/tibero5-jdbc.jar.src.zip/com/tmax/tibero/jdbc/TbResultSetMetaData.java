package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.data.DataType;
import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.msg.TbColumnDesc;
import com.tmax.tibero.jdbc.util.TbCommon;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class TbResultSetMetaData implements ResultSetMetaData {
  private TbResultSet rset = null;
  
  private TbPreparedStatement preparedStatement = null;
  
  private TbColumnDesc[] columnDesc = null;
  
  private int mapDateToTimestamp;
  
  public TbResultSetMetaData(TbResultSet paramTbResultSet) {
    this.rset = paramTbResultSet;
    this.mapDateToTimestamp = ((TbResultSetBase)paramTbResultSet).stmt.conn.getMapDateToTimestamp();
  }
  
  public TbResultSetMetaData(TbPreparedStatement paramTbPreparedStatement) {
    this.preparedStatement = paramTbPreparedStatement;
    this.columnDesc = paramTbPreparedStatement.getColMetaArray();
    this.mapDateToTimestamp = paramTbPreparedStatement.conn.getMapDateToTimestamp();
  }
  
  public String getCatalogName(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return "";
  }
  
  public String getColumnClassName(int paramInt) throws SQLException {
    if (this.rset != null)
      return DataType.getDataTypeClassName(this.rset.getColumnDataType(paramInt)); 
    if (this.columnDesc != null)
      return DataType.getDataTypeClassName((this.columnDesc[paramInt - 1]).dataType); 
    throw TbError.newSQLException(-590784);
  }
  
  public int getColumnCount() throws SQLException {
    if (this.rset != null)
      return this.rset.getColumnCount(); 
    if (this.columnDesc != null)
      return this.preparedStatement.getColumnCount(); 
    throw TbError.newSQLException(-590784);
  }
  
  private int getColumnDataType(int paramInt) throws SQLException {
    if (this.rset != null)
      return this.rset.getColumnDataType(paramInt); 
    if (this.columnDesc != null)
      return (this.columnDesc[paramInt - 1]).dataType; 
    throw TbError.newSQLException(-590784);
  }
  
  private int getColumnMaxLength(int paramInt) throws SQLException {
    if (this.rset != null)
      return this.rset.getColumnMaxLength(paramInt); 
    if (this.columnDesc != null)
      return (this.columnDesc[paramInt - 1]).maxSize; 
    throw TbError.newSQLException(-590784);
  }
  
  public int getColumnDisplaySize(int paramInt) throws SQLException {
    int k;
    int i = getColumnDataType(paramInt);
    int j = getColumnMaxLength(paramInt);
    if (j > 0)
      return j; 
    switch (i) {
      case 2:
      case 3:
        k = getColumnName(paramInt).length();
        return (k == 0) ? 1 : k;
      case 1:
        return 45;
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
        return 24;
      case 15:
        return 14;
      case 12:
      case 13:
        return 400000000;
    } 
    return 65535;
  }
  
  public String getColumnLabel(int paramInt) throws SQLException {
    return getColumnName(paramInt);
  }
  
  public String getColumnName(int paramInt) throws SQLException {
    if (this.rset != null)
      return this.rset.getColumnName(paramInt); 
    if (this.columnDesc != null)
      return (this.columnDesc[paramInt - 1]).name; 
    throw TbError.newSQLException(-590784);
  }
  
  public int getColumnType(int paramInt) throws SQLException {
    if (this.rset != null)
      return this.rset.getColumnSqlType(paramInt); 
    if (this.columnDesc != null) {
      if ((this.columnDesc[paramInt - 1]).dataType == 16)
        return -1; 
      switch (this.mapDateToTimestamp) {
        case 0:
        case 2:
          return DataType.getSqlType((this.columnDesc[paramInt - 1]).dataType, 0, false);
        case 1:
          return DataType.getSqlType((this.columnDesc[paramInt - 1]).dataType, 0, true);
      } 
    } 
    throw TbError.newSQLException(-590784);
  }
  
  public String getColumnTypeName(int paramInt) throws SQLException {
    return DataType.getDBTypeName(getColumnDataType(paramInt), getColumnPrecision(paramInt));
  }
  
  private int getColumnPrecision(int paramInt) throws SQLException {
    if (this.rset != null)
      return this.rset.getColumnPrecision(paramInt); 
    if (this.columnDesc != null)
      return (this.columnDesc[paramInt - 1]).precision; 
    throw TbError.newSQLException(-590784);
  }
  
  public int getPrecision(int paramInt) throws SQLException {
    int i = getColumnPrecision(paramInt);
    int j = getColumnDataType(paramInt);
    switch (j) {
      case 2:
      case 3:
        return getColumnMaxLength(paramInt);
      case 12:
      case 13:
        return -1;
      case 10:
      case 11:
        return Integer.MAX_VALUE;
    } 
    return (i < 0) ? 0 : i;
  }
  
  public int getScale(int paramInt) throws SQLException {
    int i = 0;
    if (this.rset != null) {
      i = this.rset.getColumnScale(paramInt);
    } else if (this.columnDesc != null) {
      i = (this.columnDesc[paramInt - 1]).scale;
    } else {
      throw TbError.newSQLException(-590784);
    } 
    return (i < 0) ? 0 : i;
  }
  
  private void checkColumnIndex(int paramInt) throws SQLException {
    if (this.rset != null) {
      this.rset.checkColumnIndex(paramInt);
    } else if (this.columnDesc != null) {
      int i = this.preparedStatement.getColumnCount();
      if (i < 0)
        throw TbError.newSQLException(-90607); 
      if (paramInt <= 0 || paramInt > i)
        throw TbError.newSQLException(-90609); 
    } else {
      throw TbError.newSQLException(-590784);
    } 
  }
  
  public String getSchemaName(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return "";
  }
  
  public String getTableName(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return "";
  }
  
  public boolean isAutoIncrement(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return false;
  }
  
  public boolean isCaseSensitive(int paramInt) throws SQLException {
    int i = getColumnDataType(paramInt);
    return (DataType.isCharacterCategory(i) || i == 13 || i == 10);
  }
  
  public boolean isCurrency(int paramInt) throws SQLException {
    int i = getColumnDataType(paramInt);
    return (i == 1);
  }
  
  public boolean isDefinitelyWritable(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return false;
  }
  
  public int isNullable(int paramInt) throws SQLException {
    boolean bool;
    if (this.rset != null) {
      bool = this.rset.getColumnNullable(paramInt);
    } else if (this.columnDesc != null) {
      bool = TbCommon.getBitmapAt(0, (this.columnDesc[paramInt - 1]).etcMeta);
    } else {
      throw TbError.newSQLException(-590784);
    } 
    return bool ? 1 : 0;
  }
  
  public boolean isReadOnly(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return false;
  }
  
  public boolean isSearchable(int paramInt) throws SQLException {
    int i = getColumnDataType(paramInt);
    return (i != 11 && i != 10 && i != 12 && i != 13);
  }
  
  public boolean isSigned(int paramInt) throws SQLException {
    return DataType.isNumberCategory(getColumnDataType(paramInt));
  }
  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    return paramClass.isInstance(this);
  }
  
  public boolean isWritable(int paramInt) throws SQLException {
    checkColumnIndex(paramInt);
    return true;
  }
  
  public void reset() {
    this.rset = null;
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    try {
      return paramClass.cast(this);
    } catch (ClassCastException classCastException) {
      throw TbError.newSQLException(-90657);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbResultSetMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */