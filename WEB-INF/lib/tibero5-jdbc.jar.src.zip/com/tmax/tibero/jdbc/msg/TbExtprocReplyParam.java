package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import java.sql.SQLException;

public class TbExtprocReplyParam {
  public byte[] dataValue;
  
  public int dataValueLen;
  
  public void set(byte[] paramArrayOfbyte, int paramInt) {
    this.dataValue = paramArrayOfbyte;
    this.dataValueLen = paramInt;
  }
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    int i = paramTbStreamDataReader.readInt32();
    if (i != 0) {
      this.dataValue = new byte[i];
      paramTbStreamDataReader.readPadBytes(this.dataValue, 0, i);
    } else {
      paramTbStreamDataReader.moveReadOffset(4);
      this.dataValue = new byte[0];
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbExtprocReplyParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */