package com.tmax.tibero.jdbc.msg.common;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public abstract class TbMsgError extends TbMsg {
  public boolean haveError = true;
  
  private SQLException prevException;
  
  private SQLException rootException;
  
  protected void readErrorStackInfo(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    int i = paramTbStreamDataReader.readInt32();
    if (i == 0) {
      this.haveError = false;
      paramTbStreamDataReader.moveReadOffset(4);
      return;
    } 
    paramTbStreamDataReader.moveReadOffset(4);
    paramTbStreamDataReader.moveReadOffset(4);
    int j = paramTbStreamDataReader.readInt32();
    if (j <= 0) {
      this.haveError = false;
      return;
    } 
    paramTbStreamDataReader.moveReadOffset(4);
    for (byte b = 0; b < j; b++) {
      paramTbStreamDataReader.moveReadOffset(8);
      paramTbStreamDataReader.moveReadOffset(4);
      int k = paramTbStreamDataReader.readInt32();
      paramTbStreamDataReader.moveReadOffset(4);
      paramTbStreamDataReader.moveReadOffset(4);
      paramTbStreamDataReader.moveReadOffset(1);
      byte[] arrayOfByte = new byte[6];
      paramTbStreamDataReader.readBytes(arrayOfByte, 0, 6);
      int i1 = 6;
      int i2;
      for (i2 = 0; i2 < 6; i2++) {
        if (arrayOfByte[i2] == 0) {
          i1 = i2;
          break;
        } 
      } 
      String str = paramTbStreamDataReader.readDBDecodedString(712).trim();
      if (null != str) {
        i2 = str.indexOf(false);
        if (i2 > 0)
          str = str.substring(0, i2); 
      } 
      paramTbStreamDataReader.moveReadOffset(1);
      paramTbStreamDataReader.moveReadOffset(4);
      int m = paramTbStreamDataReader.readInt32();
      int n = paramTbStreamDataReader.readInt32();
      paramTbStreamDataReader.moveReadOffset(4);
      paramTbStreamDataReader.moveReadOffset(12);
      paramTbStreamDataReader.moveReadOffset(80);
      paramTbStreamDataReader.moveReadOffset(4);
      paramTbStreamDataReader.moveReadOffset(80);
      SQLException sQLException = TbError.newSQLException(str, k);
      if (this.prevException == null) {
        this.rootException = sQLException;
      } else {
        this.prevException.setNextException(sQLException);
      } 
      this.prevException = sQLException;
    } 
  }
  
  public SQLException getException(int paramInt) {
    return !this.haveError ? TbError.newSQLException(paramInt) : this.rootException;
  }
  
  public void changeRootException(SQLException paramSQLException) {
    paramSQLException.setNextException(this.rootException.getNextException());
    this.rootException = paramSQLException;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\common\TbMsgError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */