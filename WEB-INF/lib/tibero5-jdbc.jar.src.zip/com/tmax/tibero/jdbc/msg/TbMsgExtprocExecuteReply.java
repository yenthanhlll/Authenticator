package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.msg.common.TbMsgError;
import java.sql.SQLException;

public class TbMsgExtprocExecuteReply extends TbMsgError {
  public String dbmsOutput;
  
  public byte[] errstack;
  
  public int errstackLen;
  
  public int replyParamArrayCnt;
  
  public TbExtprocReplyParam[] replyParam;
  
  public void serialize(TbStreamDataWriter paramTbStreamDataWriter) throws SQLException {}
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    skipDbmsOutput(paramTbStreamDataReader);
    int i = paramTbStreamDataReader.readInt32();
    if (i != 0) {
      this.errstack = new byte[i];
      paramTbStreamDataReader.readPadBytes(this.errstack, 0, i);
    } else {
      paramTbStreamDataReader.moveReadOffset(4);
      this.errstack = new byte[0];
    } 
    int j = paramTbStreamDataReader.readInt32();
    if (j > 0) {
      this.replyParam = new TbExtprocReplyParam[j];
      for (byte b = 0; b < j; b++) {
        this.replyParam[b] = new TbExtprocReplyParam();
        this.replyParam[b].deserialize(paramTbStreamDataReader);
      } 
    } else {
      this.replyParam = null;
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbMsgExtprocExecuteReply.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */