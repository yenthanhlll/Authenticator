package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import java.sql.SQLException;

public class TbTbcmNode {
  public int id;
  
  public int local;
  
  public int clusterAddr;
  
  public int clusterPort;
  
  public String name;
  
  public void set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) {
    this.id = paramInt1;
    this.local = paramInt2;
    this.clusterAddr = paramInt3;
    this.clusterPort = paramInt4;
    this.name = paramString;
  }
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.id = paramTbStreamDataReader.readInt32();
    this.local = paramTbStreamDataReader.readInt32();
    this.clusterAddr = paramTbStreamDataReader.readInt32();
    this.clusterPort = paramTbStreamDataReader.readInt32();
    int i = paramTbStreamDataReader.readInt32();
    this.name = paramTbStreamDataReader.readDBDecodedPadString(i);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbTbcmNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */