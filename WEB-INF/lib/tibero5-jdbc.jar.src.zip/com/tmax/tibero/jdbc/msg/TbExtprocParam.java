package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import java.sql.SQLException;

public class TbExtprocParam {
  public int flag;
  
  public int maxlen;
  
  public byte[] dataValue;
  
  public int dataValueLen;
  
  public void set(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
    this.flag = paramInt1;
    this.maxlen = paramInt2;
    this.dataValue = paramArrayOfbyte;
    this.dataValueLen = paramInt3;
  }
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.flag = paramTbStreamDataReader.readInt32();
    this.maxlen = paramTbStreamDataReader.readInt32();
    int i = paramTbStreamDataReader.readInt32();
    if (i != 0) {
      this.dataValue = new byte[i];
      paramTbStreamDataReader.readPadBytes(this.dataValue, 0, i);
    } else {
      paramTbStreamDataReader.moveReadOffset(4);
      this.dataValue = new byte[0];
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbExtprocParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */