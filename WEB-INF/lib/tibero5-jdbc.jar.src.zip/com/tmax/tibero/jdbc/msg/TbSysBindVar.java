package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import java.sql.SQLException;

public class TbSysBindVar {
  public int type;
  
  public byte[] dtv;
  
  public int dtvLen;
  
  public String literal;
  
  public void set(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, String paramString) {
    this.type = paramInt1;
    this.dtv = paramArrayOfbyte;
    this.dtvLen = paramInt2;
    this.literal = paramString;
  }
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.type = paramTbStreamDataReader.readInt32();
    int i = paramTbStreamDataReader.readInt32();
    if (i != 0) {
      this.dtv = new byte[i];
      paramTbStreamDataReader.readPadBytes(this.dtv, 0, i);
    } else {
      paramTbStreamDataReader.moveReadOffset(4);
      this.dtv = new byte[0];
    } 
    int j = paramTbStreamDataReader.readInt32();
    this.literal = paramTbStreamDataReader.readDBDecodedPadString(j);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbSysBindVar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */