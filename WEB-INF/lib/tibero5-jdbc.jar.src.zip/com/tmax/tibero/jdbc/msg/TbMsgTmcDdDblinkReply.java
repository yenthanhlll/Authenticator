package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.msg.common.TbMsg;
import java.sql.SQLException;

public class TbMsgTmcDdDblinkReply extends TbMsg {
  public int ownerId;
  
  public String userName;
  
  public String password;
  
  public String dbName;
  
  public void serialize(TbStreamDataWriter paramTbStreamDataWriter) throws SQLException {}
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.ownerId = paramTbStreamDataReader.readInt32();
    int i = paramTbStreamDataReader.readInt32();
    this.userName = paramTbStreamDataReader.readDBDecodedPadString(i);
    int j = paramTbStreamDataReader.readInt32();
    this.password = paramTbStreamDataReader.readDBDecodedPadString(j);
    int k = paramTbStreamDataReader.readInt32();
    this.dbName = paramTbStreamDataReader.readDBDecodedPadString(k);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbMsgTmcDdDblinkReply.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */