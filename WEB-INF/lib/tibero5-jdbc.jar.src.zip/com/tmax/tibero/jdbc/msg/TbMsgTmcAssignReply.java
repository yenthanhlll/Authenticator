package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.msg.common.TbMsg;
import java.sql.SQLException;

public class TbMsgTmcAssignReply extends TbMsg {
  public int fromNodeId;
  
  public int fromSid;
  
  public int fromSessSerialNo;
  
  public int vconHandle;
  
  public int availRcid;
  
  public void serialize(TbStreamDataWriter paramTbStreamDataWriter) throws SQLException {}
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.fromNodeId = paramTbStreamDataReader.readInt32();
    this.fromSid = paramTbStreamDataReader.readInt32();
    this.fromSessSerialNo = paramTbStreamDataReader.readInt32();
    this.vconHandle = paramTbStreamDataReader.readInt32();
    this.availRcid = paramTbStreamDataReader.readInt32();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbMsgTmcAssignReply.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */