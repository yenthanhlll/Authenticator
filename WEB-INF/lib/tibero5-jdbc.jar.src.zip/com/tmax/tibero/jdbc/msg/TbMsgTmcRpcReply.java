package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.msg.common.TbMsg;
import java.sql.SQLException;

public class TbMsgTmcRpcReply extends TbMsg {
  public int fromNodeId;
  
  public int fromSid;
  
  public int fromSessSerialNo;
  
  public int toNodeId;
  
  public int toSid;
  
  public int toSessSerialNo;
  
  public int type;
  
  public int seqno;
  
  public byte[] arg;
  
  public int argLen;
  
  public void serialize(TbStreamDataWriter paramTbStreamDataWriter) throws SQLException {}
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.fromNodeId = paramTbStreamDataReader.readInt32();
    this.fromSid = paramTbStreamDataReader.readInt32();
    this.fromSessSerialNo = paramTbStreamDataReader.readInt32();
    this.toNodeId = paramTbStreamDataReader.readInt32();
    this.toSid = paramTbStreamDataReader.readInt32();
    this.toSessSerialNo = paramTbStreamDataReader.readInt32();
    this.type = paramTbStreamDataReader.readInt32();
    this.seqno = paramTbStreamDataReader.readInt32();
    int i = paramTbStreamDataReader.readInt32();
    if (i != 0) {
      this.arg = new byte[i];
      paramTbStreamDataReader.readPadBytes(this.arg, 0, i);
    } else {
      paramTbStreamDataReader.moveReadOffset(4);
      this.arg = new byte[0];
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbMsgTmcRpcReply.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */