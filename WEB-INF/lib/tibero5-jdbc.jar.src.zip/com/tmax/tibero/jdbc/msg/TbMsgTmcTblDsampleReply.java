package com.tmax.tibero.jdbc.msg;

import com.tmax.tibero.jdbc.comm.TbStreamDataReader;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.msg.common.TbMsg;
import java.sql.SQLException;

public class TbMsgTmcTblDsampleReply extends TbMsg {
  public int gtid;
  
  public int tabletNo;
  
  public int blkcnt;
  
  public int idxsArrayCnt;
  
  public TbIdxInfo[] idxs;
  
  public int sblksArrayCnt;
  
  public TbSampleBlk[] sblks;
  
  public int isFinished;
  
  public void serialize(TbStreamDataWriter paramTbStreamDataWriter) throws SQLException {}
  
  public void deserialize(TbStreamDataReader paramTbStreamDataReader) throws SQLException {
    this.gtid = paramTbStreamDataReader.readInt32();
    this.tabletNo = paramTbStreamDataReader.readInt32();
    this.blkcnt = paramTbStreamDataReader.readInt32();
    int i = paramTbStreamDataReader.readInt32();
    if (i > 0) {
      this.idxs = new TbIdxInfo[i];
      for (byte b = 0; b < i; b++) {
        this.idxs[b] = new TbIdxInfo();
        this.idxs[b].deserialize(paramTbStreamDataReader);
      } 
    } else {
      this.idxs = null;
    } 
    int j = paramTbStreamDataReader.readInt32();
    if (j > 0) {
      this.sblks = new TbSampleBlk[j];
      for (byte b = 0; b < j; b++) {
        this.sblks[b] = new TbSampleBlk();
        this.sblks[b].deserialize(paramTbStreamDataReader);
      } 
    } else {
      this.sblks = null;
    } 
    this.isFinished = paramTbStreamDataReader.readInt32();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\msg\TbMsgTmcTblDsampleReply.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */