package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TbArrayDescriptor {
  private String owner;
  
  private String pkgName;
  
  private String typeName;
  
  private TbConnection conn;
  
  private int baseType;
  
  private int elementsType;
  
  private int elementsCount;
  
  private boolean initialized;
  
  public TbArrayDescriptor(String paramString1, String paramString2, String paramString3, Connection paramConnection) throws SQLException {
    this.owner = paramString1;
    this.conn = (TbConnection)paramConnection;
    this.typeName = paramString3;
    this.pkgName = paramString2;
    if (!this.initialized)
      getArrayTypeInfo(); 
  }
  
  public static TbArrayDescriptor createDescriptor(String paramString1, String paramString2, String paramString3, Connection paramConnection) throws SQLException {
    if (paramString1 == null || paramString1.length() == 0 || paramString3 == null || paramString3.length() == 0 || paramString3 == null || paramString3.length() == 0 || paramConnection == null)
      throw new IllegalArgumentException(); 
    return new TbArrayDescriptor(paramString1.toUpperCase(), paramString2.toUpperCase(), paramString3.toUpperCase(), paramConnection);
  }
  
  public String getTypeName() {
    return this.typeName;
  }
  
  public String getPackageName() {
    return this.pkgName;
  }
  
  public String getOwner() {
    return this.owner;
  }
  
  private void getArrayTypeInfo() throws SQLException {
    String str1 = getPackageName();
    String str2 = getTypeName();
    String str3 = "select kind, FLD1, COL_CNT from sys._dd_psmmember where name = ?  and obj_id in (select object_id from all_objects where object_name = ? and owner = ?) ";
    PreparedStatement preparedStatement = this.conn.prepareStatement(str3);
    preparedStatement.setString(1, str2);
    preparedStatement.setString(2, str1);
    preparedStatement.setString(3, getOwner());
    ResultSet resultSet = preparedStatement.executeQuery();
    if (resultSet.next()) {
      int i = resultSet.getInt(1);
      switch (i) {
        case 31:
          this.baseType = 28;
          break;
        case 32:
          this.baseType = 29;
          break;
        case 33:
          this.baseType = 30;
          break;
        default:
          throw TbError.newSQLException(-590704, Integer.toString(i));
      } 
      this.elementsCount = resultSet.getInt(2);
    } else {
      throw new SQLException("Type does not exist : " + this.owner + ", " + str1 + ", " + str2);
    } 
    String str4 = "select T.type_no, T.precision, T.scale, T.meta_obj_id, T.meta_member_no from sys._dd_psmmember M,  sys._dd_psmtdef T where M.OBJ_ID = T.OBJ_ID and M.MEMBER_NO = T.MEMBER_NO and M.name = ? and M.obj_id in (select object_id from all_objects where object_name = ? and owner = ?) ";
    preparedStatement = this.conn.prepareStatement(str4);
    preparedStatement.setString(1, str2);
    preparedStatement.setString(2, str1);
    preparedStatement.setString(3, getOwner());
    resultSet = preparedStatement.executeQuery();
    if (resultSet.next()) {
      this.elementsType = resultSet.getInt(1);
    } else {
      throw new SQLException("Element Type Info does not exist : " + this.owner + ", " + str1 + ", " + str2);
    } 
    this.initialized = true;
  }
  
  public int getBaseType() {
    return this.baseType;
  }
  
  public int getElementsType() {
    return this.elementsType;
  }
  
  public int getElementsCount() {
    return this.elementsCount;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbArrayDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */