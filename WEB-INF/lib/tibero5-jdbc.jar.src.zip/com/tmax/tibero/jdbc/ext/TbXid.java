package com.tmax.tibero.jdbc.ext;

import java.io.Serializable;
import javax.transaction.xa.Xid;

public class TbXid implements Xid, Serializable {
  private static final long serialVersionUID = 8653403137105513841L;
  
  private int formatId;
  
  private byte[] gtrid;
  
  private byte[] bqual;
  
  public static int DATA_SIZE = 128;
  
  public static int SERIALIZED_SIZE = 24 + DATA_SIZE;
  
  public TbXid(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws TbXAException {
    if (paramArrayOfbyte1 != null && paramArrayOfbyte1.length > 64)
      throw new TbXAException(-4, "GTRID is null or greater than 64"); 
    if (paramArrayOfbyte2 != null && paramArrayOfbyte2.length > 64)
      throw new TbXAException(-4, "BQUAL is null or greater than 64"); 
    this.formatId = paramInt;
    this.gtrid = paramArrayOfbyte1;
    this.bqual = paramArrayOfbyte2;
  }
  
  public int getFormatId() {
    return this.formatId;
  }
  
  public byte[] getGlobalTransactionId() {
    return this.gtrid;
  }
  
  public byte[] getBranchQualifier() {
    return this.bqual;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\ext\TbXid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */