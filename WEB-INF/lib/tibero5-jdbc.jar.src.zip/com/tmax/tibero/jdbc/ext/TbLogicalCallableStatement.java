package com.tmax.tibero.jdbc.ext;

import com.tmax.tibero.jdbc.TbCallableStatement;
import com.tmax.tibero.jdbc.TbPreparedStatement;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

public class TbLogicalCallableStatement extends TbLogicalPreparedStatement implements CallableStatement {
  public TbLogicalCallableStatement(TbLogicalConnection paramTbLogicalConnection, TbCallableStatement paramTbCallableStatement) throws SQLException {
    super(paramTbLogicalConnection, (TbPreparedStatement)paramTbCallableStatement);
  }
  
  public boolean execute() throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).execute();
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public int executeUpdate() throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).executeUpdate();
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Array getArray(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getArray(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Array getArray(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getArray(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public BigDecimal getBigDecimal(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBigDecimal(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBigDecimal(paramInt1, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public BigDecimal getBigDecimal(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBigDecimal(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Blob getBlob(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBlob(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Blob getBlob(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBlob(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public boolean getBoolean(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBoolean(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public boolean getBoolean(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBoolean(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public byte getByte(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getByte(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public byte getByte(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getByte(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public byte[] getBytes(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBytes(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public byte[] getBytes(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getBytes(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Reader getCharacterStream(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getCharacterStream(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Reader getCharacterStream(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getCharacterStream(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Clob getClob(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getClob(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Clob getClob(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getClob(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Date getDate(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getDate(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getDate(paramInt, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Date getDate(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getDate(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getDate(paramString, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public double getDouble(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getDouble(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public double getDouble(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getDouble(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public float getFloat(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getFloat(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public float getFloat(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getFloat(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public int getInt(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getInt(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public int getInt(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getInt(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public long getLong(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getLong(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public long getLong(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getLong(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Reader getNCharacterStream(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getNCharacterStream(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Reader getNCharacterStream(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getNCharacterStream(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public NClob getNClob(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getNClob(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public NClob getNClob(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getNClob(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public String getNString(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getNString(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public String getNString(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getNString(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Object getObject(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getObject(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Object getObject(int paramInt, Map<String, Class<?>> paramMap) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getObject(paramInt, paramMap);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Object getObject(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getObject(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Object getObject(String paramString, Map<String, Class<?>> paramMap) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getObject(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Ref getRef(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getRef(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Ref getRef(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getRef(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public RowId getRowId(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getRowId(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public RowId getRowId(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getRowId(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public short getShort(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getShort(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public short getShort(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getShort(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public SQLXML getSQLXML(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getSQLXML(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public SQLXML getSQLXML(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getSQLXML(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public String getString(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getString(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public String getString(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getString(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Time getTime(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTime(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTime(paramInt, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Time getTime(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTime(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTime(paramString, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Timestamp getTimestamp(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTimestamp(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTimestamp(paramInt, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Timestamp getTimestamp(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTimestamp(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getTimestamp(paramString, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public URL getURL(int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getURL(paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public URL getURL(String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).getURL(paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).registerOutParameter(paramInt1, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).registerOutParameter(paramInt1, paramInt2, paramInt3);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).registerOutParameter(paramInt1, paramInt2, paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void registerOutParameter(String paramString, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).registerOutParameter(paramString, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).registerOutParameter(paramString, paramInt1, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).registerOutParameter(paramString1, paramInt, paramString2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setAsciiStream(paramInt, paramInputStream);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setAsciiStream(paramInt1, paramInputStream, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setAsciiStream(paramInt, paramInputStream, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setAsciiStream(paramString, paramInputStream);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setAsciiStream(paramString, paramInputStream, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setAsciiStream(paramString, paramInputStream, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBigDecimal(paramInt, paramBigDecimal);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBigDecimal(paramString, paramBigDecimal);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBinaryStream(paramInt, paramInputStream);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBinaryStream(paramInt1, paramInputStream, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBinaryStream(paramInt, paramInputStream, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBinaryStream(paramString, paramInputStream);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBinaryStream(paramString, paramInputStream, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBinaryStream(paramString, paramInputStream, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBlob(paramInt, paramBlob);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBlob(paramInt, paramInputStream);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBlob(paramInt, paramInputStream, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBlob(String paramString, Blob paramBlob) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBlob(paramString, paramBlob);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBlob(paramString, paramInputStream);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBlob(paramString, paramInputStream, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBoolean(paramInt, paramBoolean);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBoolean(paramString, paramBoolean);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setByte(int paramInt, byte paramByte) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setByte(paramInt, paramByte);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setByte(String paramString, byte paramByte) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setByte(paramString, paramByte);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBytes(paramInt, paramArrayOfbyte);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setBytes(paramString, paramArrayOfbyte);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setCharacterStream(paramInt, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setCharacterStream(paramInt1, paramReader, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setCharacterStream(paramInt, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setCharacterStream(paramString, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setCharacterStream(paramString, paramReader, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setCharacterStream(paramString, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setClob(int paramInt, Clob paramClob) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setClob(paramInt, paramClob);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setClob(int paramInt, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setClob(paramInt, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setClob(paramInt, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setClob(String paramString, Clob paramClob) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setClob(paramString, paramClob);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setClob(String paramString, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setClob(paramString, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setClob(paramString, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setDate(int paramInt, Date paramDate) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setDate(paramInt, paramDate);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setDate(paramInt, paramDate, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setDate(String paramString, Date paramDate) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setDate(paramString, paramDate);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setDate(paramString, paramDate, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setDouble(int paramInt, double paramDouble) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setDouble(paramInt, paramDouble);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setDouble(String paramString, double paramDouble) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setDouble(paramString, paramDouble);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setFloat(int paramInt, float paramFloat) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setFloat(paramInt, paramFloat);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setFloat(String paramString, float paramFloat) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setFloat(paramString, paramFloat);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setInt(int paramInt1, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setInt(paramInt1, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setInt(String paramString, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setInt(paramString, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setLong(int paramInt, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setLong(paramInt, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setLong(String paramString, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setLong(paramString, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNCharacterStream(paramInt, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNCharacterStream(paramInt, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNCharacterStream(paramString, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNCharacterStream(paramString, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNClob(paramInt, paramNClob);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNClob(int paramInt, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNClob(paramInt, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNClob(paramInt, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNClob(String paramString, NClob paramNClob) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNClob(paramString, paramNClob);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNClob(String paramString, Reader paramReader) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNClob(paramString, paramReader);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNClob(paramString, paramReader, paramLong);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNString(int paramInt, String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNString(paramInt, paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNString(String paramString1, String paramString2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNString(paramString1, paramString2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNull(int paramInt1, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNull(paramInt1, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNull(paramInt1, paramInt2, paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNull(String paramString, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNull(paramString, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setNull(paramString1, paramInt, paramString2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setObject(int paramInt, Object paramObject) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setObject(paramInt, paramObject);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setObject(paramInt1, paramObject, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setObject(paramInt1, paramObject, paramInt2, paramInt3);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setObject(String paramString, Object paramObject) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setObject(paramString, paramObject);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setObject(paramString, paramObject, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setObject(paramString, paramObject, paramInt1, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setRef(int paramInt, Ref paramRef) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setRef(paramInt, paramRef);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setRowId(paramInt, paramRowId);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setRowId(String paramString, RowId paramRowId) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setRowId(paramString, paramRowId);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setShort(int paramInt, short paramShort) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setShort(paramInt, paramShort);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setShort(String paramString, short paramShort) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setShort(paramString, paramShort);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setSQLXML(paramInt, paramSQLXML);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setSQLXML(paramString, paramSQLXML);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setString(int paramInt, String paramString) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setString(paramInt, paramString);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setString(String paramString1, String paramString2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setString(paramString1, paramString2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTime(int paramInt, Time paramTime) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTime(paramInt, paramTime);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTime(paramInt, paramTime, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTime(String paramString, Time paramTime) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTime(paramString, paramTime);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTime(paramString, paramTime, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTimestamp(paramInt, paramTimestamp);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTimestamp(paramInt, paramTimestamp, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTimestamp(paramString, paramTimestamp);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setTimestamp(paramString, paramTimestamp, paramCalendar);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  @Deprecated
  public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setUnicodeStream(paramInt1, paramInputStream, paramInt2);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  @Deprecated
  public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setUnicodeStream(paramString, paramInputStream, paramInt);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setURL(int paramInt, URL paramURL) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setURL(paramInt, paramURL);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public void setURL(String paramString, URL paramURL) throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      ((TbCallableStatement)this.physicalStmt).setURL(paramString, paramURL);
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
  
  public boolean wasNull() throws SQLException {
    if (isClosed())
      throw TbError.newSQLException(-90659); 
    try {
      return ((TbCallableStatement)this.physicalStmt).wasNull();
    } catch (SQLException sQLException) {
      notifyExceptionEvent((PreparedStatement)this.physicalStmt, sQLException);
      throw sQLException;
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\ext\TbLogicalCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */