package com.tmax.tibero.jdbc.ext;

import java.sql.SQLException;

public interface TbConnectionEventHandler {
  void notifyExceptionEvent(SQLException paramSQLException);
  
  void notifyClosedEvent();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\ext\TbConnectionEventHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */