package com.tmax.tibero.jdbc;

import com.tmax.tibero.DriverConstants;
import com.tmax.tibero.jdbc.data.ConnectionInfo;
import com.tmax.tibero.jdbc.util.TbUrlParser;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.util.Properties;

public class TbDriver implements Driver {
  protected static Connection defaultConn = null;
  
  public boolean acceptsURL(String paramString) throws SQLException {
    try {
      if (TbUrlParser.parseUrl(paramString, null) != null)
        return true; 
    } catch (Exception exception) {}
    return false;
  }
  
  public Connection connect(ConnectionInfo paramConnectionInfo) throws SQLException {
    return connectInternal(paramConnectionInfo);
  }
  
  public Connection connect(String paramString, Properties paramProperties) throws SQLException {
    ConnectionInfo connectionInfo = null;
    if (TbUrlParser.isInternalUrl(paramString)) {
      connectionInfo = new ConnectionInfo();
      connectionInfo.setInternal(true);
    } else {
      if (!TbUrlParser.isTiberoUrl(paramString))
        return null; 
      connectionInfo = TbUrlParser.parseUrl(paramString, paramProperties);
    } 
    return connectInternal(connectionInfo);
  }
  
  private Connection connectInternal(ConnectionInfo paramConnectionInfo) throws SQLException {
    if (paramConnectionInfo == null)
      return null; 
    try {
      TbConnection tbConnection = new TbConnection();
      String str = paramConnectionInfo.getNewPassword();
      if (str != null && str.length() != 0) {
        try {
          tbConnection.openConnection(paramConnectionInfo);
        } catch (SQLException sQLException) {
          if (sQLException.getErrorCode() == 17002);
          tbConnection.openConnectionWithNewPassword(paramConnectionInfo);
        } 
      } else {
        tbConnection.openConnection(paramConnectionInfo);
      } 
      return tbConnection;
    } catch (SQLException sQLException) {
      throw sQLException;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public Connection defaultConnection() throws SQLException {
    synchronized (TbDriver.class) {
      if (defaultConn == null || defaultConn.isClosed())
        defaultConn = DriverManager.getConnection("jdbc:default:connection"); 
    } 
    return defaultConn;
  }
  
  public int getMajorVersion() {
    return Integer.parseInt(DriverConstants.JDBC_MAJOR);
  }
  
  public int getMinorVersion() {
    return Integer.parseInt(DriverConstants.JDBC_MINOR);
  }
  
  public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLException {
    return new DriverPropertyInfo[0];
  }
  
  public int getRevision() {
    return Integer.parseInt(DriverConstants.JDBC_REVISION);
  }
  
  public boolean jdbcCompliant() {
    return true;
  }
  
  static {
    try {
      DriverManager.registerDriver(new TbDriver());
    } catch (SQLException sQLException) {
      throw new RuntimeException("Failed to register TiberoDriver:" + sQLException.getMessage());
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbDriver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */