package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.Ref;
import java.sql.SQLException;
import java.util.Map;

public class TbRef implements Ref {
  public String getBaseTypeName() throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public Object getObject(Map paramMap) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public Object getObject() throws SQLException {
    throw TbError.newSQLException(-90201);
  }
  
  public void setObject(Object paramObject) throws SQLException {
    throw TbError.newSQLException(-90201);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */