package com.tmax.tibero.jdbc.data.binder;

import com.tmax.tibero.DriverConstants;
import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.TbPreparedStatement;
import com.tmax.tibero.jdbc.comm.TbStream;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

public class StreamBinder extends Binder {
  public void bind(TbConnection paramTbConnection, TbPreparedStatement paramTbPreparedStatement, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    paramTbStreamDataWriter.writeRpcolData(null, 0);
  }
  
  public void bindDFR(TbConnection paramTbConnection, TbPreparedStatement paramTbPreparedStatement, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2, long paramLong) throws SQLException {
    InputStream inputStream = paramTbPreparedStatement.getParamStream(paramInt1, paramInt2);
    TbStream tbStream = paramTbConnection.getTbComm().getStream();
    int i = 0;
    int j = 0;
    int k = paramTbStreamDataWriter.getBufferedDataSize();
    try {
      while (paramLong > 0L) {
        paramTbStreamDataWriter.setCurDataSize(k);
        if (paramLong < DriverConstants.MIN_DEFERRED_BYTE_SIZE) {
          j = (int)paramLong;
        } else {
          j = DriverConstants.MIN_DEFERRED_BYTE_SIZE;
        } 
        paramTbStreamDataWriter.makeBufferAvailable(j + 4);
        byte[] arrayOfByte = paramTbStreamDataWriter.getStreamBuf().getRawBytes();
        i = inputStream.read(arrayOfByte, k + 4, j);
        if (i == -1)
          break; 
        paramTbStreamDataWriter.writeInt(i, 4);
        paramTbStreamDataWriter.moveOffset(i);
        paramTbStreamDataWriter.writePadding(i);
        paramTbStreamDataWriter.reWriteInt(4, paramTbStreamDataWriter.getBufferedDataSize() - 16, 4);
        tbStream.flush();
        paramLong -= i;
      } 
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90202);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\binder\StreamBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */