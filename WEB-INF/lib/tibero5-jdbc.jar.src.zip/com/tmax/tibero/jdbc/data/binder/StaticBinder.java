package com.tmax.tibero.jdbc.data.binder;

public class StaticBinder {
  public static Binder nullBinder = new NullBinder();
  
  public static Binder stringBinder = new StringBinder();
  
  public static Binder readerBinder = new ReaderBinder();
  
  public static Binder intBinder = new IntBinder();
  
  public static Binder longBinder = new LongBinder();
  
  public static Binder floatBinder = new FloatBinder();
  
  public static Binder doubleBinder = new DoubleBinder();
  
  public static Binder bigDecimalBinder = new BigDecimalBinder();
  
  public static Binder dateBinder = new DateBinder();
  
  public static Binder timeBinder = new TimeBinder();
  
  public static Binder timestampBinder = new TimestampBinder();
  
  public static Binder timestampTZBinder = new TimestampTZBinder();
  
  public static Binder tbDateBinder = new TbDateBinder();
  
  public static Binder tbTimestampBinder = new TbTimestampBinder();
  
  public static Binder bytesBinder = new BytesBinder();
  
  public static Binder streamBinder = new StreamBinder();
  
  public static Binder nStringBinder = new NStringBinder();
  
  public static Binder nReaderBinder = new NReaderBinder();
  
  public static Binder structBinder;
  
  public static Binder arrayBinder;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\binder\StaticBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */