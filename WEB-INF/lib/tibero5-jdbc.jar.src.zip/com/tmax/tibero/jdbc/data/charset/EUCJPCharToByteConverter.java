package com.tmax.tibero.jdbc.data.charset;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public class EUCJPCharToByteConverter extends JIS0208CharToByteConverter {
  private JIS0201CharToByteConverter JIS0201cb = new JIS0201CharToByteConverter();
  
  private JIS0212CharToByteConverter JIS0212cb = new JIS0212CharToByteConverter();
  
  short[] JIS0208Index1 = getIndex1();
  
  String[] JIS0208Index2 = getIndex2();
  
  final int MAX_BYTE_SIZE = 3;
  
  public static final char MIN_HIGH = '?';
  
  public static final char MAX_HIGH = '?';
  
  public static final char MIN_LOW = '?';
  
  public static final char MAX_LOW = '?';
  
  public static final char MIN = '?';
  
  public static final char MAX = '?';
  
  public boolean canConvert(char paramChar) throws SQLException {
    byte[] arrayOfByte = new byte[3];
    return !(convSingleByte(paramChar, arrayOfByte) == 0 && convDoubleByte(paramChar) == 0);
  }
  
  protected int convDoubleByte(char paramChar) throws SQLException {
    if (paramChar == '〜' || paramChar == '～') {
      char c1 = '¡';
      char c2 = 'Á';
      return c1 << 8 | c2;
    } 
    try {
      int i = this.JIS0208Index1[(paramChar & 0xFF00) >> 8] << 8;
      char c = this.JIS0208Index2[i >> 12].charAt((i & 0xFFF) + (paramChar & 0xFF));
      if (c != '\000')
        return c + 32896; 
      int j = this.JIS0212cb.convDoubleByte(paramChar);
      return (j == 0) ? j : (j + 9404544);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw TbError.newSQLException(-590743, arrayIndexOutOfBoundsException.getMessage());
    } 
  }
  
  public int getMaxBytesPerChar() {
    return 3;
  }
  
  protected int convSingleByte(char paramChar, byte[] paramArrayOfbyte) {
    if (paramChar == '\000') {
      paramArrayOfbyte[0] = 0;
      return 1;
    } 
    byte b;
    if ((b = this.JIS0201cb.getNative(paramChar)) == 0)
      return 0; 
    if (b > 0 && b < 128) {
      paramArrayOfbyte[0] = b;
      return 1;
    } 
    paramArrayOfbyte[0] = -114;
    paramArrayOfbyte[1] = b;
    return 2;
  }
  
  public int convCharArr(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4) throws SQLException {
    int i = 0;
    int j = 0;
    byte[] arrayOfByte = new byte[3];
    j = paramInt3;
    for (i = paramInt1; i < paramInt2; i++) {
      char c = paramArrayOfchar[i];
      if (is(c)) {
        parse(c, paramArrayOfchar, i, paramInt2);
        return j - paramInt3;
      } 
      int k = convSingleByte(c, arrayOfByte);
      if (k == 0) {
        int m = convDoubleByte(c);
        if (m != 0) {
          if ((m & 0xFF0000) == 0) {
            arrayOfByte[0] = (byte)((m & 0xFF00) >> 8);
            arrayOfByte[1] = (byte)(m & 0xFF);
            k = 2;
          } else {
            arrayOfByte[0] = -113;
            arrayOfByte[1] = (byte)((m & 0xFF00) >> 8);
            arrayOfByte[2] = (byte)(m & 0xFF);
            k = 3;
          } 
        } else {
          throw TbError.newSQLException(-590714, "unknown character");
        } 
      } 
      if (paramInt4 - j < k)
        throw TbError.newSQLException(-590714, "Conversion buffer overflow"); 
      for (byte b = 0; b < k; b++)
        paramArrayOfbyte[j++] = arrayOfByte[b]; 
    } 
    return j - paramInt3;
  }
  
  private int parse(char paramChar, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
    if (isHigh(paramChar)) {
      if (paramInt2 - paramInt1 < 2)
        throw TbError.newSQLException(-590714, "Malformed input"); 
      char c = paramArrayOfchar[paramInt1 + 1];
      if (isLow(c))
        return toUCS4(paramChar, c); 
      throw TbError.newSQLException(-590714, "Malformed input");
    } 
    if (isLow(paramChar))
      throw TbError.newSQLException(-590714, "Malformed input"); 
    return paramChar;
  }
  
  private boolean isHigh(int paramInt) {
    return (55296 <= paramInt && paramInt <= 56319);
  }
  
  private boolean isLow(int paramInt) {
    return (56320 <= paramInt && paramInt <= 57343);
  }
  
  private boolean is(int paramInt) {
    return (55296 <= paramInt && paramInt <= 57343);
  }
  
  public int toUCS4(char paramChar1, char paramChar2) {
    return ((paramChar1 & 0x3FF) << 10 | paramChar2 & 0x3FF) + 65536;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\charset\EUCJPCharToByteConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */