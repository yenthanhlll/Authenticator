package com.tmax.tibero.jdbc.data.charset;

public class UTF16CharToByteConverter extends UnicodeCharToByteConverter {
  public UTF16CharToByteConverter() {
    super(1, false);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\charset\UTF16CharToByteConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */