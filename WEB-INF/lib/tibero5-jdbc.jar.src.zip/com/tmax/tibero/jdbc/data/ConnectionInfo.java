package com.tmax.tibero.jdbc.data;

import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.util.TbCommon;
import com.tmax.tibero.jdbc.util.TbRandom;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Vector;

public class ConnectionInfo implements Cloneable {
  public static final String DATABASENAME = "databaseName";
  
  public static final String DATASOURCENAME = "dataSourceName";
  
  public static final String DESCRIPTION = "description";
  
  public static final String DRIVERTYPE = "driverType";
  
  public static final String NETWORKPROTOCOL = "networkProtocol";
  
  public static final String PASSWORD = "password";
  
  public static final String PORTNUMBER = "portNumber";
  
  public static final String SERVERNAME = "serverName";
  
  public static final String USER = "user";
  
  public static final String TDU = "tdu";
  
  public static final String URL = "url";
  
  public static final String LOGIN_TIMEOUT = "login_timeout";
  
  public static final String READ_TIMEOUT = "read_timeout";
  
  public static final String LOAD_BALANCE = "load_balance";
  
  public static final String FAILOVER_RETRY_CNT = "failover_retry_count";
  
  public static final String FAILOVER = "failover";
  
  public static final String BACKUP_SERVER = "backup_server";
  
  public static final String BACKUP_PORT = "backup_port";
  
  public static final String CHARACTERSET = "characterset";
  
  public static final String PROGNAME = "program_name";
  
  public static final String STATEMENT_CACHE = "statement_cache";
  
  public static final String STATEMENT_CACHE_MAX_SIZE = "statement_cache_max_size";
  
  public static final String INCLUDE_SYNONYMS = "includeSynonyms";
  
  public static final String MAP_DATE_TO_TIMESTAMP = "mapDateToTimestamp";
  
  public static final String DEFAULT_NCHAR = "defaultNChar";
  
  private static final String NEW_PASSWORD = "new_password";
  
  private static final String DATABASE_PRODUCT_NAME = "databaseProductName";
  
  private static final String DATABASE_PRODUCT_VERSION = "databaseProductVersion";
  
  private static final String DRIVER_NAME = "driverName";
  
  private static final String DRIVER_VERSION = "driverVersion";
  
  private final int DEFAULT_RETRY_COUNT = 3;
  
  private final int DEFAULT_STMT_CACHE_MAX_SIZE = 5;
  
  private boolean failover = false;
  
  private boolean loadBalance = false;
  
  private boolean connectedToPrimary = false;
  
  private int curNodeIdx = 0;
  
  private int visitedNodeCount = 0;
  
  private boolean[] visitedNodes = null;
  
  private Vector nodeList = null;
  
  private int tryCount = 0;
  
  private int retryCount = 3;
  
  private String user = "";
  
  private String databaseName = "";
  
  private String datasourceName = "";
  
  private String description = "";
  
  private String driverType = "thin";
  
  private String protocol = "tcp";
  
  private String password = "";
  
  private String newPassword = "";
  
  private String url = "";
  
  private String databaseProductName = "";
  
  private String databaseProductVersion = "";
  
  private String driverName = "";
  
  private String driverVersion = "";
  
  private int tdu = 4096;
  
  private int loginTimeout = 0;
  
  private int readTimeout = 0;
  
  private String charset = null;
  
  private String progname = null;
  
  private boolean includeSynonyms = false;
  
  private int mapDateToTimestamp = 2;
  
  private boolean defaultNChar = false;
  
  public static final int MAP_DATE_TO_TIMESTAMP_FALSE = 0;
  
  public static final int MAP_DATE_TO_TIMESTAMP_TRUE = 1;
  
  public static final int MAP_DATE_TO_TIMESTAMP_OLD = 2;
  
  private boolean isXA = false;
  
  private boolean isInternal = false;
  
  private boolean stmtCache = false;
  
  private int stmtCacheMaxSize = 5;
  
  public ConnectionInfo() {}
  
  public ConnectionInfo(Properties paramProperties) {
    set(paramProperties);
  }
  
  public ConnectionInfo(String paramString1, String paramString2, String paramString3, int paramInt, String paramString4, Properties paramProperties) {
    paramString3 = TbCommon.getEmptyString(paramString3, "localhost");
    if (paramInt <= 0)
      paramInt = 8629; 
    NodeInfo nodeInfo = new NodeInfo(paramString3, paramInt);
    if (this.nodeList == null)
      this.nodeList = new Vector(); 
    this.nodeList.add(nodeInfo);
    this.user = getUserName(TbCommon.getEmptyString(paramString2, ""));
    this.databaseName = TbCommon.getEmptyString(paramString4, "");
    this.url = paramString1;
    if (paramProperties != null) {
      this.datasourceName = paramProperties.getProperty("dataSourceName", "");
      this.description = paramProperties.getProperty("description", "");
      this.driverType = paramProperties.getProperty("driverType", "thin");
      this.protocol = paramProperties.getProperty("networkProtocol", "tcp");
      this.password = paramProperties.getProperty("password", "");
      this.newPassword = paramProperties.getProperty("new_password", "");
      this.failover = paramProperties.getProperty("failover", "").equalsIgnoreCase("ON");
      this.loadBalance = paramProperties.getProperty("load_balance", "").equalsIgnoreCase("ON");
      try {
        this.retryCount = Integer.parseInt(paramProperties.getProperty("failover_retry_count"));
        if (this.retryCount < 1)
          this.retryCount = 3; 
      } catch (NumberFormatException numberFormatException) {
        this.retryCount = 3;
      } 
      try {
        this.loginTimeout = Integer.parseInt(paramProperties.getProperty("login_timeout"));
      } catch (NumberFormatException numberFormatException) {
        this.loginTimeout = 0;
      } 
      try {
        this.readTimeout = Integer.parseInt(paramProperties.getProperty("read_timeout"));
      } catch (NumberFormatException numberFormatException) {
        this.readTimeout = 0;
      } 
      try {
        this.tdu = Integer.parseInt(paramProperties.getProperty("tdu"));
      } catch (NumberFormatException numberFormatException) {
        this.tdu = 4096;
      } 
      this.progname = paramProperties.getProperty("program_name");
      this.charset = paramProperties.getProperty("characterset");
      this.stmtCache = paramProperties.getProperty("statement_cache", "OFF").equalsIgnoreCase("ON");
      try {
        this.stmtCacheMaxSize = Integer.parseInt(paramProperties.getProperty("statement_cache_max_size"));
      } catch (NumberFormatException numberFormatException) {
        this.stmtCacheMaxSize = 5;
      } 
      this.includeSynonyms = paramProperties.getProperty("includeSynonyms", "false").equalsIgnoreCase("true");
      String str = paramProperties.getProperty("mapDateToTimestamp", "");
      if (str.equals("")) {
        this.mapDateToTimestamp = 2;
      } else if (str.equalsIgnoreCase("false")) {
        this.mapDateToTimestamp = 0;
      } else {
        this.mapDateToTimestamp = 1;
      } 
      this.defaultNChar = paramProperties.getProperty("defaultNChar", "false").equalsIgnoreCase("true");
      this.databaseProductName = paramProperties.getProperty("databaseProductName", "");
      this.databaseProductVersion = paramProperties.getProperty("databaseProductVersion", "");
      this.driverName = paramProperties.getProperty("driverName", "");
      this.driverVersion = paramProperties.getProperty("driverVersion", "");
    } 
  }
  
  public Object clone() {
    try {
      return super.clone();
    } catch (Exception exception) {
      throw new RuntimeException("ConnectionInfo clone() failed:" + exception.getMessage());
    } 
  }
  
  public String getCharacterSet() {
    return this.charset;
  }
  
  public NodeInfo getClusterNode() throws SQLException {
    return this.connectedToPrimary ? getSecondaryNode() : getPrimaryNode();
  }
  
  public String getDatabaseName() {
    return this.databaseName;
  }
  
  public String getDataSourceName() {
    return this.datasourceName;
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public String getDriverType() {
    return this.driverType;
  }
  
  public boolean getIncludeSynonyms() {
    return this.includeSynonyms;
  }
  
  public int getMapDateToTimestamp() {
    return this.mapDateToTimestamp;
  }
  
  public boolean getDefaultNChar() {
    return this.defaultNChar;
  }
  
  public void setDefaultNChar(boolean paramBoolean) {
    this.defaultNChar = paramBoolean;
  }
  
  public int getLoginTimeout() {
    return this.loginTimeout;
  }
  
  public String getNetworkProtocol() {
    return this.protocol;
  }
  
  public Vector getNodeList() {
    return this.nodeList;
  }
  
  public String getPassword() {
    return this.password;
  }
  
  public String getNewPassword() {
    return this.newPassword;
  }
  
  public boolean isStmtCache() {
    return this.stmtCache;
  }
  
  public void setStmtCache(boolean paramBoolean) {
    this.stmtCache = paramBoolean;
  }
  
  public int getStmtCacheMaxSize() {
    return this.stmtCacheMaxSize;
  }
  
  public void setStmtCacheMaxSize(int paramInt) {
    this.stmtCacheMaxSize = paramInt;
  }
  
  private synchronized NodeInfo getPrimaryNode() throws SQLException {
    NodeInfo nodeInfo = null;
    if (this.nodeList == null || this.nodeList.size() == 0)
      throw TbError.newSQLException(-90400, "Node list is empty"); 
    this.visitedNodes = new boolean[this.nodeList.size()];
    this.curNodeIdx = 0;
    if (this.loadBalance) {
      this.curNodeIdx = TbRandom.nextInt(this.nodeList.size());
    } else if (this.failover) {
      for (byte b = 0; b < this.nodeList.size(); b++) {
        nodeInfo = this.nodeList.get(b);
        if (nodeInfo.getNodeType() == 1) {
          this.curNodeIdx = b;
          break;
        } 
      } 
    } 
    this.visitedNodeCount = 1;
    this.visitedNodes[this.curNodeIdx] = true;
    this.connectedToPrimary = true;
    return this.nodeList.get(this.curNodeIdx);
  }
  
  public String getProgramName() {
    return this.progname;
  }
  
  public int getReadTimeout() {
    return this.readTimeout;
  }
  
  public synchronized NodeInfo getSecondaryNode() {
    byte b = 0;
    NodeInfo nodeInfo = null;
    if (this.nodeList == null || this.nodeList.size() <= 1 || !this.failover)
      return null; 
    if (this.visitedNodeCount == this.nodeList.size()) {
      if (++this.tryCount == this.retryCount)
        return null; 
      for (b = 0; b < this.nodeList.size(); b++)
        this.visitedNodes[b] = false; 
      this.visitedNodeCount = 0;
    } 
    for (b = 0; b < this.nodeList.size(); b++) {
      nodeInfo = this.nodeList.get(b);
      if (nodeInfo.getNodeType() == 2) {
        this.curNodeIdx = b;
        this.visitedNodeCount++;
        this.visitedNodes[this.curNodeIdx] = true;
        return nodeInfo;
      } 
    } 
    while (true) {
      this.curNodeIdx = (this.curNodeIdx + 1 >= this.nodeList.size()) ? 0 : (this.curNodeIdx + 1);
      if (!this.visitedNodes[this.curNodeIdx]) {
        this.visitedNodeCount++;
        this.visitedNodes[this.curNodeIdx] = true;
        return this.nodeList.get(this.curNodeIdx);
      } 
    } 
  }
  
  public int getTDU() {
    return this.tdu;
  }
  
  public String getURL() {
    return this.url;
  }
  
  public String getUser() {
    return this.user;
  }
  
  private String getUserName(String paramString) {
    return (paramString.length() >= 2 && paramString.startsWith("\"") && paramString.endsWith("\"")) ? paramString.substring(1, paramString.length() - 1) : paramString.toUpperCase();
  }
  
  public boolean isFailOver() {
    return this.failover;
  }
  
  public boolean isInternal() {
    return this.isInternal;
  }
  
  public boolean isLoadBalance() {
    return this.loadBalance;
  }
  
  public boolean isXA() {
    return this.isXA;
  }
  
  public void set(Properties paramProperties) {
    char c;
    if (paramProperties == null)
      return; 
    this.databaseName = paramProperties.getProperty("databaseName", "");
    this.datasourceName = paramProperties.getProperty("dataSourceName", "");
    this.description = paramProperties.getProperty("description", "");
    this.user = getUserName(paramProperties.getProperty("user", ""));
    this.password = paramProperties.getProperty("password", "");
    this.newPassword = paramProperties.getProperty("new_password", "");
    this.url = paramProperties.getProperty("url", "");
    this.driverType = paramProperties.getProperty("driverType", "thin");
    this.protocol = paramProperties.getProperty("networkProtocol", "tcp");
    String str1 = paramProperties.getProperty("serverName", "localhost");
    String str2 = paramProperties.getProperty("portNumber", "");
    try {
      c = Integer.parseInt(str2);
    } catch (Exception exception) {
      c = '↵';
    } 
    if (this.nodeList == null)
      this.nodeList = new Vector(); 
    NodeInfo nodeInfo = new NodeInfo(str1, c);
    this.nodeList.add(nodeInfo);
    this.failover = paramProperties.getProperty("failover", "").equalsIgnoreCase("ON");
    this.loadBalance = paramProperties.getProperty("load_balance", "").equalsIgnoreCase("ON");
    try {
      this.retryCount = Integer.parseInt(paramProperties.getProperty("failover_retry_count"));
      if (this.retryCount < 1)
        this.retryCount = 3; 
    } catch (NumberFormatException numberFormatException) {
      this.retryCount = 3;
    } 
    try {
      this.loginTimeout = Integer.parseInt(paramProperties.getProperty("login_timeout"));
    } catch (NumberFormatException numberFormatException) {
      this.loginTimeout = 0;
    } 
    try {
      this.readTimeout = Integer.parseInt(paramProperties.getProperty("read_timeout"));
    } catch (NumberFormatException numberFormatException) {
      this.readTimeout = 0;
    } 
    try {
      this.tdu = Integer.parseInt(paramProperties.getProperty("tdu"));
    } catch (Exception exception) {
      this.tdu = 4096;
    } 
    this.progname = paramProperties.getProperty("program_name");
    this.charset = paramProperties.getProperty("characterset");
    this.stmtCache = paramProperties.getProperty("statement_cache", "OFF").equalsIgnoreCase("ON");
    try {
      this.stmtCacheMaxSize = Integer.parseInt(paramProperties.getProperty("statement_cache_max_size"));
    } catch (NumberFormatException numberFormatException) {
      this.stmtCacheMaxSize = 5;
    } 
    this.includeSynonyms = paramProperties.getProperty("includeSynonyms", "false").equalsIgnoreCase("true");
    String str3 = paramProperties.getProperty("mapDateToTimestamp", "");
    if (str3.equals("")) {
      this.mapDateToTimestamp = 2;
    } else if (str3.equalsIgnoreCase("false")) {
      this.mapDateToTimestamp = 0;
    } else {
      this.mapDateToTimestamp = 1;
    } 
    this.defaultNChar = paramProperties.getProperty("defaultNChar", "false").equalsIgnoreCase("true");
    this.databaseProductName = paramProperties.getProperty("databaseProductName", "");
    this.databaseProductVersion = paramProperties.getProperty("databaseProductVersion", "");
    this.driverName = paramProperties.getProperty("driverName", "");
    this.driverVersion = paramProperties.getProperty("driverVersion", "");
  }
  
  public void setDatabaseName(String paramString) {
    this.databaseName = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDatabaseProductName(String paramString) {
    this.databaseProductName = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDatabaseProductVersion(String paramString) {
    this.databaseProductVersion = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDriverName(String paramString) {
    this.driverName = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDriverVersion(String paramString) {
    this.driverVersion = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDataSourceName(String paramString) {
    this.datasourceName = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDescription(String paramString) {
    this.description = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setDriverType(String paramString) {
    this.driverType = TbCommon.getEmptyString(paramString, "thin");
  }
  
  public void setFailOver(boolean paramBoolean) {
    this.failover = paramBoolean;
  }
  
  public void setIncludeSynonyms(boolean paramBoolean) {
    this.includeSynonyms = paramBoolean;
  }
  
  public void setMapDateToTimestamp(int paramInt) {
    this.mapDateToTimestamp = paramInt;
  }
  
  public void setInternal(boolean paramBoolean) {
    this.isInternal = paramBoolean;
  }
  
  public void setLoadBalance(boolean paramBoolean) {
    this.loadBalance = paramBoolean;
  }
  
  public void setLoginTimeout(int paramInt) {
    this.loginTimeout = paramInt;
  }
  
  public void setReadTimeout(int paramInt) {
    this.readTimeout = paramInt;
  }
  
  public void setCharacterSet(String paramString) {
    this.charset = paramString;
  }
  
  public void setProgramName(String paramString) {
    this.progname = TbCommon.getEmptyString(paramString, "");
  }
  
  public void setNetworkProtocol(String paramString) {
    this.protocol = TbCommon.getEmptyString(paramString, "tcp");
  }
  
  public void setNodeList(Vector paramVector) {
    this.nodeList = paramVector;
  }
  
  public void setPassword(String paramString) {
    this.password = TbCommon.getEmptyString(paramString, "");
  }
  
  public int getFailOverRetryCount() {
    return this.retryCount;
  }
  
  public void setFailOverRetryCount(int paramInt) {
    if (this.retryCount < 1) {
      this.retryCount = 3;
    } else {
      this.retryCount = paramInt;
    } 
  }
  
  public void setTDU(int paramInt) {
    this.tdu = (paramInt <= 0) ? 4096 : paramInt;
  }
  
  public void setURL(String paramString) {
    this.url = paramString;
  }
  
  public void setUser(String paramString) {
    this.user = getUserName(TbCommon.getEmptyString(paramString, ""));
  }
  
  public void setXA(boolean paramBoolean) {
    this.isXA = paramBoolean;
  }
  
  public String getDatabaseProductName() {
    return this.databaseProductName;
  }
  
  public String getDatabaseProductVersion() {
    return this.databaseProductVersion;
  }
  
  public String getDriverName() {
    return this.driverName;
  }
  
  public String getDriverVersion() {
    return this.driverVersion;
  }
  
  public String toString() {
    StringBuffer stringBuffer1 = new StringBuffer(64);
    stringBuffer1.append("ConnInfo[");
    stringBuffer1.append("User=").append(this.user);
    StringBuffer stringBuffer2 = new StringBuffer();
    if (this.password != null)
      for (byte b = 0; b < this.password.length(); b++)
        stringBuffer2.append("*");  
    stringBuffer1.append("/Password=").append(stringBuffer2.toString());
    stringBuffer1.append("/URL=").append(this.url);
    stringBuffer1.append("/DriverType=").append(this.driverType);
    stringBuffer1.append("/NetworkProtocol=").append(this.protocol);
    stringBuffer1.append("/TDU=").append(this.tdu);
    stringBuffer1.append("/DatabaseName=").append(this.databaseName);
    stringBuffer1.append("/DataSourceName=").append(this.datasourceName);
    stringBuffer1.append("/Description=").append(this.description);
    stringBuffer1.append("]");
    return stringBuffer1.toString();
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\ConnectionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */