package com.tmax.tibero.jdbc.data;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public class DataType {
  public static final int NONE = 0;
  
  public static final int NUMBER = 1;
  
  public static final int CHAR = 2;
  
  public static final int VARCHAR = 3;
  
  public static final int RAW = 4;
  
  public static final int DATE = 5;
  
  public static final int TIME = 6;
  
  public static final int TIMESTAMP = 7;
  
  public static final int TIMESTAMP_TZ = 21;
  
  public static final int TIMESTAMP_LTZ = 22;
  
  public static final int ITV_YTM = 8;
  
  public static final int ITV_DTS = 9;
  
  public static final int LONG = 10;
  
  public static final int LONGRAW = 11;
  
  public static final int BLOB = 12;
  
  public static final int CLOB = 13;
  
  public static final int BFILE = 14;
  
  public static final int ROWID = 15;
  
  public static final int CURSOR = 16;
  
  public static final int UNKNOWN = 17;
  
  public static final int NCHAR = 18;
  
  public static final int NVARCHAR = 19;
  
  public static final int NCLOB = 20;
  
  public static final int BIN_FLOAT = 23;
  
  public static final int BIN_DOUBLE = 24;
  
  public static final int BOOLEAN = 25;
  
  public static final int PLS_INT = 26;
  
  public static final int BIN_INT = 27;
  
  public static final int RECORD = 28;
  
  public static final int VARRAY = 29;
  
  public static final int TABLE = 30;
  
  public static final int IDX_BY_TBL = 31;
  
  public static final int LGEOMETRY = 1;
  
  public static final int LXML = 2;
  
  public static final int PIVOT = 3;
  
  public static void checkValidDataType(int paramInt) throws SQLException {
    switch (paramInt) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 28:
      case 29:
      case 30:
        return;
    } 
    throw TbError.newSQLException(-590703, Integer.toString(paramInt));
  }
  
  public static int getDataType(int paramInt) throws SQLException {
    switch (paramInt) {
      case -7:
      case 1:
        return 2;
      case -4:
      case -3:
      case -2:
        return 4;
      case -1:
      case 12:
        return 3;
      case -6:
      case -5:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
        return 1;
      case 91:
      case 92:
        return 5;
      case 93:
        return 7;
      case 2004:
        return 12;
      case 2005:
        return 13;
      case -17:
        return 16;
      case -15:
        return 18;
      case -9:
        return 19;
      case 2011:
        return 13;
      case 2009:
        return 13;
      case 0:
        return 3;
      case 2003:
        return 29;
      case 2002:
        return 28;
      case -2003:
        return 30;
    } 
    throw TbError.newSQLException(-590704, Integer.toString(paramInt));
  }
  
  public static String getDataTypeClassName(int paramInt) throws SQLException {
    switch (paramInt) {
      case 1:
        return "java.math.BigDecimal";
      case 2:
      case 3:
      case 10:
      case 18:
      case 19:
        return "java.lang.String";
      case 6:
        return "java.sql.Time";
      case 5:
      case 7:
      case 21:
      case 22:
        return "java.sql.Timestamp";
      case 4:
      case 11:
        return "byte[]";
      case 15:
        return "com.tmax.tibero.jdbc.TbRowId";
      case 12:
        return "java.sql.Blob";
      case 20:
        return "java.sql.NClob";
      case 13:
        return "java.sql.Clob";
      case 16:
        return "java.sql.ResultSet";
      case 9:
        return "com.tmax.tibero.jdbc.TbIntervalDts";
      case 8:
        return "com.tmax.tibero.jdbc.TbIntervalYtm";
      case 29:
        return "java.sql.Array";
      case 28:
        return "java.lang.Object";
      case 30:
        return "java.sql.Array";
    } 
    throw TbError.newSQLException(-590703, Integer.toString(paramInt));
  }
  
  public static String getDBTypeName(int paramInt) throws SQLException {
    return getDBTypeName(paramInt, 0);
  }
  
  public static String getDBTypeName(int paramInt1, int paramInt2) throws SQLException {
    switch (paramInt1) {
      case 2:
        return "CHAR";
      case 3:
        return "VARCHAR2";
      case 1:
        return "NUMBER";
      case 5:
        return "DATE";
      case 6:
        return "TIME";
      case 7:
      case 21:
      case 22:
        return "TIMESTAMP";
      case 8:
        return "INTERVAL YEAR TO MONTH";
      case 9:
        return "INTERVAL DAY TO SECOND";
      case 4:
        return "RAW";
      case 12:
        return (1 == paramInt2) ? "GEOMETRY" : "BLOB";
      case 13:
        return (2 == paramInt2) ? "XMLTYPE" : "CLOB";
      case 14:
        return "BFILE";
      case 10:
        return "LONG";
      case 11:
        return "LONG RAW";
      case 15:
        return "ROWID";
      case 18:
        return "NCHAR";
      case 19:
        return "NVARCHAR";
      case 20:
        return "NCLOB";
      case 16:
        return "CURSOR";
      case 29:
        return "VARRAY";
      case 28:
        return "STRUCT";
      case 30:
        return "TABLE";
    } 
    throw TbError.newSQLException(-590703, Integer.toString(paramInt1));
  }
  
  public static int getSqlType(int paramInt) throws SQLException {
    return getSqlType(paramInt, 0);
  }
  
  public static int getSqlType(int paramInt1, int paramInt2) throws SQLException {
    return getSqlType(paramInt1, 0, true);
  }
  
  public static int getSqlType(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLException {
    switch (paramInt1) {
      case 0:
        return 0;
      case 18:
        return -15;
      case 2:
        return 1;
      case 19:
        return -9;
      case 3:
        return 12;
      case 1:
        return 2;
      case 5:
        return paramBoolean ? 93 : 91;
      case 6:
        return 92;
      case 7:
      case 21:
      case 22:
        return 93;
      case 8:
      case 9:
        return 1111;
      case 15:
        return 1;
      case 4:
        return -3;
      case 12:
        return (1 == paramInt2) ? 26 : 2004;
      case 20:
        return 2011;
      case 13:
        return (2 == paramInt2) ? 2009 : 2005;
      case 10:
        return -1;
      case 11:
        return -4;
      case 16:
        return -17;
      case 29:
        return 2003;
      case 28:
        return 2002;
      case 30:
        return -2003;
    } 
    throw TbError.newSQLException(-590703, Integer.toString(paramInt1));
  }
  
  public static int getSqlType(Object paramObject) throws SQLException {
    return (paramObject == null) ? 1 : ((paramObject instanceof String) ? 12 : ((paramObject instanceof java.math.BigDecimal) ? 2 : ((paramObject instanceof Integer) ? 4 : ((paramObject instanceof Short) ? 5 : ((paramObject instanceof Long) ? -5 : ((paramObject instanceof Float) ? 7 : ((paramObject instanceof Double) ? 8 : ((paramObject instanceof byte[]) ? -3 : ((paramObject instanceof java.sql.Date || paramObject instanceof TbDate) ? 91 : ((paramObject instanceof java.sql.Time) ? 92 : ((paramObject instanceof java.sql.Timestamp || paramObject instanceof TbTimestamp) ? 93 : ((paramObject instanceof Boolean) ? -7 : ((paramObject instanceof java.sql.NClob) ? 2011 : ((paramObject instanceof java.sql.Clob) ? 2005 : ((paramObject instanceof java.sql.Blob) ? 2004 : ((paramObject instanceof java.sql.Array) ? 2003 : ((paramObject instanceof java.sql.Struct) ? 2002 : ((paramObject instanceof java.sql.Ref) ? 2006 : ((paramObject instanceof java.net.URL) ? 70 : ((paramObject instanceof java.sql.SQLXML) ? 2009 : ((paramObject instanceof java.sql.RowId) ? -8 : 2000)))))))))))))))))))));
  }
  
  public static boolean isCharacterCategory(int paramInt) {
    return (paramInt == 2 || paramInt == 3);
  }
  
  public static boolean isDateCategory(int paramInt) {
    return (paramInt == 5 || paramInt == 6 || paramInt == 7);
  }
  
  public static boolean isLobCategory(int paramInt) {
    return (paramInt == 13 || paramInt == 12 || paramInt == 20);
  }
  
  public static boolean isLocatorCategory(int paramInt) {
    return (paramInt == 13 || paramInt == 12 || paramInt == 20 || paramInt == 10 || paramInt == 11);
  }
  
  public static boolean isLongCategory(int paramInt) {
    return (paramInt == 10 || paramInt == 11);
  }
  
  public static boolean isNationalCategory(int paramInt) {
    return (paramInt == 18 || paramInt == 19);
  }
  
  public static boolean isNumberCategory(int paramInt) {
    return (paramInt == 1);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\DataType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */