package com.tmax.tibero.jdbc.data;

import com.tmax.tibero.jdbc.msg.TbColumnDesc;
import com.tmax.tibero.jdbc.util.TbCommon;
import java.sql.SQLException;

public class Column {
  private TbColumnDesc colMeta = null;
  
  private int colIdx = 0;
  
  private int sqlType = 0;
  
  private boolean isNullable = false;
  
  private int mapDateToTimestamp = 2;
  
  public Column() {}
  
  public Column(int paramInt) {}
  
  public final int getDataType() {
    return this.colMeta.dataType;
  }
  
  public final int getMaxLength() {
    return this.colMeta.maxSize;
  }
  
  public final String getName() {
    return (this.colMeta.name == null || this.colMeta.name.length() == 0) ? ("column" + this.colIdx) : this.colMeta.name;
  }
  
  public final int getPrecision() {
    return this.colMeta.precision;
  }
  
  public final int getScale() {
    return this.colMeta.scale;
  }
  
  public final int getSqlType() {
    return this.sqlType;
  }
  
  public final boolean isNullable() {
    return this.isNullable;
  }
  
  public void reset() {
    this.colMeta = null;
  }
  
  public void set(int paramInt, TbColumnDesc paramTbColumnDesc) throws SQLException {
    this.colMeta = paramTbColumnDesc;
    this.colIdx = paramInt;
    if (paramTbColumnDesc.dataType == 16) {
      this.sqlType = -1;
    } else {
      switch (this.mapDateToTimestamp) {
        case 0:
          this.sqlType = DataType.getSqlType(paramTbColumnDesc.dataType, 0, false);
          break;
        default:
          this.sqlType = DataType.getSqlType(paramTbColumnDesc.dataType, 0, true);
          break;
      } 
    } 
    this.isNullable = TbCommon.getBitmapAt(0, paramTbColumnDesc.etcMeta);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\Column.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */