package com.tmax.tibero.jdbc.data;

import com.tmax.tibero.jdbc.msg.TbColumnDesc;
import java.sql.SQLException;

public class BindItem {
  private int paramMode = 0;
  
  private int sqlType = 0;
  
  private int length;
  
  private TbColumnDesc[] colMeta;
  
  public void clone(BindItem paramBindItem) {
    paramBindItem.paramMode = this.paramMode;
    paramBindItem.sqlType = this.sqlType;
    paramBindItem.length = this.length;
  }
  
  public TbColumnDesc[] getColMeta() {
    return this.colMeta;
  }
  
  public int getSQLType() {
    return this.sqlType;
  }
  
  public int getLength() {
    return this.length;
  }
  
  public int getParamMode() {
    return this.paramMode;
  }
  
  public boolean isDFRParameter() {
    return (this.paramMode == 8);
  }
  
  public boolean isINOUTParameter() {
    return (this.paramMode == 4);
  }
  
  public boolean isINParameter() {
    return (this.paramMode == 1 || this.paramMode == 4);
  }
  
  public boolean isOUTParameter() {
    return (this.paramMode == 2 || this.paramMode == 4);
  }
  
  public void reset() {
    if (this.colMeta != null) {
      for (byte b = 0; b < this.colMeta.length; b++)
        this.colMeta[b] = null; 
      this.colMeta = null;
    } 
  }
  
  public void reuse() {
    this.paramMode = 0;
    this.sqlType = 0;
    if (this.colMeta != null) {
      for (byte b = 0; b < this.colMeta.length; b++)
        this.colMeta[b] = null; 
      this.colMeta = null;
    } 
  }
  
  public void set(int paramInt1, int paramInt2) {
    setParamMode(paramInt1);
    this.sqlType = paramInt2;
  }
  
  public void set(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    setParamMode(paramInt1);
    this.sqlType = paramInt2;
    this.length = paramInt3;
  }
  
  public void set(int paramInt1, int paramInt2, TbColumnDesc[] paramArrayOfTbColumnDesc) throws SQLException {
    this.paramMode = 2;
    this.sqlType = paramInt1;
    this.length = paramInt2;
    this.colMeta = paramArrayOfTbColumnDesc;
  }
  
  private void setParamMode(int paramInt) {
    if ((this.paramMode == 1 && paramInt == 2) || (this.paramMode == 2 && paramInt == 1)) {
      this.paramMode = 4;
    } else {
      this.paramMode = paramInt;
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\BindItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */