package com.tmax.tibero.jdbc.data.charset;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public class EUCJPByteToCharConverter extends JIS0208ByteToCharConverter {
  private JIS0201ByteToCharConverter JIS0201bc = new JIS0201ByteToCharConverter();
  
  private JIS0212ByteToCharConverter JIS0212bc = new JIS0212ByteToCharConverter();
  
  short[] JIS0208Index1 = getIndex1();
  
  String[] JIS0208Index2 = getIndex2();
  
  protected char decode0212(int paramInt1, int paramInt2) throws SQLException {
    return (paramInt1 == -126 && paramInt2 == 55) ? '〜' : this.JIS0212bc.getUnicode(paramInt1, paramInt2);
  }
  
  protected char getUnicode(int paramInt1, int paramInt2) throws SQLException {
    if (paramInt1 == -126 && paramInt2 == 55)
      return '〜'; 
    if (paramInt1 == 142)
      return this.JIS0201bc.getUnicode(paramInt2 - 256); 
    if (paramInt1 < 0 || paramInt1 > (getIndex1()).length || paramInt2 < this.start || paramInt2 > this.end)
      return '�'; 
    try {
      int i = (this.JIS0208Index1[paramInt1 - 128] & 0xF) * (this.end - this.start + 1) + paramInt2 - this.start;
      return this.JIS0208Index2[this.JIS0208Index1[paramInt1 - 128] >> 4].charAt(i);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw TbError.newSQLException(-590743, arrayIndexOutOfBoundsException.getMessage());
    } 
  }
  
  public int convert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4) throws SQLException {
    int i = 0;
    int j = 0;
    boolean bool = false;
    i = paramInt3;
    char c = '�';
    for (j = paramInt1; j < paramInt2; j += b) {
      int k = paramArrayOfbyte[j] & 0xFF;
      byte b = 1;
      if ((k & 0x80) == 0) {
        c = (char)k;
      } else if ((k & 0xFF) == 143) {
        if (j + 3 > paramInt2)
          return i; 
        k = paramArrayOfbyte[j + 1] & 0xF;
        int m = paramArrayOfbyte[j + 2] & 0xFF;
        b += true;
        c = decode0212(k - 128, m - 128);
      } else {
        if (j + 2 > paramInt2)
          return i; 
        int m = paramArrayOfbyte[j + 1] & 0xFF;
        b++;
        c = getUnicode(k, m);
      } 
      if (c == '�')
        return i - paramInt3; 
      if (i + 1 > paramInt4)
        return i - paramInt3; 
      paramArrayOfchar[i++] = c;
    } 
    return i - paramInt3;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\charset\EUCJPByteToCharConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */