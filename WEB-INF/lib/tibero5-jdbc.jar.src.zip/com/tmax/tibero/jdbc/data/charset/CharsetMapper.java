package com.tmax.tibero.jdbc.data.charset;

import java.sql.SQLException;

public class CharsetMapper {
  private CharsetEncoder encoder = null;
  
  private CharsetDecoder decoder = null;
  
  public CharsetMapper(int paramInt) {
    switch (paramInt) {
      case 0:
        this.encoder = new ASCIIEncoder();
        this.decoder = new ASCIIDecoder();
        break;
      case 1:
        this.encoder = new EUCKREncoder();
        this.decoder = new EUCKRDecoder();
        break;
      case 2:
        this.encoder = new MS949Encoder();
        this.decoder = new MS949Decoder();
        break;
      case 3:
        this.encoder = new UTF8Encoder();
        this.decoder = new UTF8Decoder();
        break;
      case 4:
        this.encoder = new UTF16Encoder();
        this.decoder = new UTF16Decoder();
        break;
      case 5:
        this.encoder = new SJISEncoder();
        this.decoder = new SJISDecoder();
        break;
      case 6:
        this.encoder = new JA16SJISEncoder();
        this.decoder = new JA16SJISDecoder();
        break;
      case 7:
        this.encoder = new JA16SJISTILDEEncoder();
        this.decoder = new JA16SJISTILDEDecoder();
        break;
      case 8:
        this.encoder = new EUCJPEncoder();
        this.decoder = new EUCJPDecoder();
        break;
      case 9:
        this.encoder = new EUCJPTILDEEncoder();
        this.decoder = new EUCJPTILDEDecoder();
        break;
      case 10:
        this.encoder = new TCVN3Encoder();
        this.decoder = new TCVN3Decoder();
        break;
      case 11:
        this.encoder = new GBKEncoder();
        this.decoder = new GBKDecoder();
        break;
      case 12:
        this.encoder = new MS1252Encoder();
        this.decoder = new MS1252Decoder();
        break;
      case 13:
        this.encoder = new MS950Encoder();
        this.decoder = new MS950Decoder();
        break;
      case 14:
        this.encoder = new MS1251Encoder();
        this.decoder = new MS1251Decoder();
        break;
      case 15:
        this.encoder = new ISO8859P1Encoder();
        this.decoder = new ISO8859P1Decoder();
        break;
      case 16:
        this.encoder = new ISO8859P2Encoder();
        this.decoder = new ISO8859P2Decoder();
        break;
      case 17:
        this.encoder = new ISO8859P9Encoder();
        this.decoder = new ISO8859P9Decoder();
        break;
      case 18:
        this.encoder = new ISO8859P15Encoder();
        this.decoder = new ISO8859P15Decoder();
        break;
      case 19:
        this.encoder = new ISO88591Encoder();
        this.decoder = new ISO88591Decoder();
        break;
    } 
  }
  
  public CharsetMapper(String paramString) {
    if (paramString.equalsIgnoreCase("EUC-KR")) {
      this.encoder = new EUCKREncoder();
      this.decoder = new EUCKRDecoder();
    } else if (paramString.equalsIgnoreCase("MSWIN949")) {
      this.encoder = new MS949Encoder();
      this.decoder = new MS949Decoder();
    } else if (paramString.equalsIgnoreCase("UTF-8")) {
      this.encoder = new UTF8Encoder();
      this.decoder = new UTF8Decoder();
    } else if (paramString.equalsIgnoreCase("ASCII")) {
      this.encoder = new ASCIIEncoder();
      this.decoder = new ASCIIDecoder();
    } else if (paramString.equalsIgnoreCase("UTF-16")) {
      this.encoder = new UTF16Encoder();
      this.decoder = new UTF16Decoder();
    } else if (paramString.equalsIgnoreCase("SHIFT-JIS")) {
      this.encoder = new SJISEncoder();
      this.decoder = new SJISDecoder();
    } else if (paramString.equalsIgnoreCase("JA16SJIS")) {
      this.encoder = new JA16SJISEncoder();
      this.decoder = new JA16SJISDecoder();
    } else if (paramString.equalsIgnoreCase("JA16SJISTILDE")) {
      this.encoder = new JA16SJISTILDEEncoder();
      this.decoder = new JA16SJISTILDEDecoder();
    } else if (paramString.equalsIgnoreCase("JA16EUC")) {
      this.encoder = new EUCJPEncoder();
      this.decoder = new EUCJPDecoder();
    } else if (paramString.equalsIgnoreCase("JA16EUCTILDE")) {
      this.encoder = new EUCJPTILDEEncoder();
      this.decoder = new EUCJPTILDEDecoder();
    } else if (paramString.equalsIgnoreCase("EUC-CN")) {
      this.encoder = new EUCCNEncoder();
      this.decoder = new EUCCNDecoder();
    } else if (paramString.equalsIgnoreCase("VN8VN3")) {
      this.encoder = new TCVN3Encoder();
      this.decoder = new TCVN3Decoder();
    } else if (paramString.equalsIgnoreCase("GBK")) {
      this.encoder = new GBKEncoder();
      this.decoder = new GBKDecoder();
    } else if (paramString.equalsIgnoreCase("WE8MSWIN1252") || paramString.equalsIgnoreCase("MSWIN1252")) {
      this.encoder = new MS1252Encoder();
      this.decoder = new MS1252Decoder();
    } else if (paramString.equalsIgnoreCase("ZHT16HKSCS") || paramString.equalsIgnoreCase("MSWIN950")) {
      this.encoder = new MS950Encoder();
      this.decoder = new MS950Decoder();
    } else if (paramString.equalsIgnoreCase("CL8MSWIN1251") || paramString.equalsIgnoreCase("MSWIN1251")) {
      this.encoder = new MS1251Encoder();
      this.decoder = new MS1251Decoder();
    } else if (paramString.equalsIgnoreCase("WE8ISO8859P1") || paramString.equalsIgnoreCase("ISO8859P1")) {
      this.encoder = new ISO8859P1Encoder();
      this.decoder = new ISO8859P1Decoder();
    } else if (paramString.equalsIgnoreCase("EE8ISO8859P2") || paramString.equalsIgnoreCase("ISO8859P2")) {
      this.encoder = new ISO8859P2Encoder();
      this.decoder = new ISO8859P2Decoder();
    } else if (paramString.equalsIgnoreCase("WE8ISO8859P9") || paramString.equalsIgnoreCase("ISO8859P9")) {
      this.encoder = new ISO8859P9Encoder();
      this.decoder = new ISO8859P9Decoder();
    } else if (paramString.equalsIgnoreCase("WE8ISO8859P15") || paramString.equalsIgnoreCase("ISO8859P15")) {
      this.encoder = new ISO8859P15Encoder();
      this.decoder = new ISO8859P15Decoder();
    } else if (paramString.equalsIgnoreCase("8859_1")) {
      this.encoder = new ISO88591Encoder();
      this.decoder = new ISO88591Decoder();
    } 
  }
  
  public int bytesToChars(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4, boolean paramBoolean) throws SQLException {
    return paramBoolean ? this.decoder.fixedBytesToChars(paramArrayOfbyte, paramInt1, paramInt2, paramArrayOfchar, paramInt3, paramInt4) : this.decoder.bytesToChars(paramArrayOfbyte, paramInt1, paramInt2, paramArrayOfchar, paramInt3, paramInt4);
  }
  
  public String bytesToString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLException {
    return paramBoolean ? this.decoder.fixedBytesToString(paramArrayOfbyte, paramInt1, paramInt2) : this.decoder.bytesToString(paramArrayOfbyte, paramInt1, paramInt2);
  }
  
  public int charsToBytes(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, boolean paramBoolean) throws SQLException {
    return paramBoolean ? this.encoder.charsToFixedBytes(paramArrayOfchar, paramInt1, paramInt2, paramArrayOfbyte, paramInt3, paramInt4) : this.encoder.charsToBytes(paramArrayOfchar, paramInt1, paramInt2, paramArrayOfbyte, paramInt3, paramInt4);
  }
  
  public int getEndingBytePos(byte[] paramArrayOfbyte, int paramInt) {
    return this.encoder.getEndingBytePos(paramArrayOfbyte, paramInt);
  }
  
  public int getLeadingBytePos(byte[] paramArrayOfbyte, int paramInt) {
    return this.encoder.getLeadingBytePos(paramArrayOfbyte, paramInt);
  }
  
  public int getMaxBytesPerChar() {
    return this.encoder.getMaxBytesPerChar();
  }
  
  public byte[] stringToBytes(String paramString) throws SQLException {
    return this.encoder.stringToBytes(paramString);
  }
  
  public int stringToBytes(byte[] paramArrayOfbyte, int paramInt, String paramString) throws SQLException {
    return this.encoder.stringToBytes(paramArrayOfbyte, paramInt, paramString);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\charset\CharsetMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */