package com.tmax.tibero.jdbc.data.binder;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.TbPreparedStatement;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import java.sql.SQLException;

public class IntBinder extends Binder {
  public void bind(TbConnection paramTbConnection, TbPreparedStatement paramTbPreparedStatement, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    DataTypeConverter dataTypeConverter = paramTbConnection.getTypeConverter();
    int i = paramTbPreparedStatement.getParamInt(paramInt1, paramInt2);
    int j = paramTbStreamDataWriter.getBufferedDataSize();
    int k = 0;
    paramTbStreamDataWriter.makeBufferAvailable(23);
    byte[] arrayOfByte = paramTbStreamDataWriter.getStreamBuf().getRawBytes();
    k = dataTypeConverter.fromInt(arrayOfByte, j + 1, i);
    arrayOfByte[j] = (byte)k;
    paramTbStreamDataWriter.moveOffset(k + 1);
    paramTbStreamDataWriter.writePadding(k + 1);
  }
  
  public void bindDFR(TbConnection paramTbConnection, TbPreparedStatement paramTbPreparedStatement, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2, long paramLong) throws SQLException {}
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\binder\IntBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */