package com.tmax.tibero.jdbc.data.charset;

import com.tmax.tibero.jdbc.err.TbError;
import java.sql.SQLException;

public class Charset {
  public static final int ASCII = 0;
  
  public static final int EUC_KR = 1;
  
  public static final int MSWIN949 = 2;
  
  public static final int UTF_8 = 3;
  
  public static final int UTF_16 = 4;
  
  public static final int SJIS = 5;
  
  public static final int JA16SJIS = 6;
  
  public static final int JA16SJIS_TILDE = 7;
  
  public static final int EUC_JP = 8;
  
  public static final int EUC_JP_TILDE = 9;
  
  public static final int VN8VN3 = 10;
  
  public static final int GBK = 11;
  
  public static final int MSWIN1252 = 12;
  
  public static final int MSWIN950 = 13;
  
  public static final int MSWIN1251 = 14;
  
  public static final int ISO8859P1 = 15;
  
  public static final int ISO8859P2 = 16;
  
  public static final int ISO8859P9 = 17;
  
  public static final int ISO8859P15 = 18;
  
  public static final int ISO_8859_1 = 19;
  
  public static final int MAX_CHAR_SET = 20;
  
  public static final String[] name = new String[] { 
      "ASCII", "EUC-KR", "MSWIN949", "UTF-8", "UTF-16", "SHIFT-JIS", "JA16SJIS", "JA16SJISTILDE", "JA16EUC", "JA16EUCTILDE", 
      "VN8VN3", "GBK", "WE8MSWIN1252", "ZHT16HKSCS", "CL8MSWIN1251", "WE8ISO8859P1", "EE8ISO8859P2", "WE8ISO8859P9", "WE8ISO8859P15", "ISO-8859-1" };
  
  public static final String[] alias = new String[] { 
      "ASCII", "EUCKR", "MSWIN949", "UTF8", "UTF16", "SJIS", "JA16SJIS", "JA16SJISTILDE", "JA16EUC", "JA16EUCTILDE", 
      "VN8VN3", "GBK", "MSWIN1252", "MSWIN950", "MSWIN1251", "ISO8859P1", "ISO8859P2", "ISO8859P9", "ISO8859P15", "8859_1" };
  
  public static int getCharset(String paramString) {
    if (paramString == null)
      return -1; 
    byte b;
    for (b = 0; b < name.length; b++) {
      if (name[b].equalsIgnoreCase(paramString))
        return b; 
    } 
    for (b = 0; b < alias.length; b++) {
      if (alias[b].equalsIgnoreCase(paramString))
        return b; 
    } 
    return -1;
  }
  
  public static String getName(int paramInt) throws SQLException {
    if (paramInt < 0 || paramInt >= 20)
      throw TbError.newSQLException(-590718); 
    return name[paramInt];
  }
  
  public static void verify(int paramInt) throws SQLException {
    if (paramInt < 0 || paramInt >= 20)
      throw TbError.newSQLException(-590718); 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\charset\Charset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */