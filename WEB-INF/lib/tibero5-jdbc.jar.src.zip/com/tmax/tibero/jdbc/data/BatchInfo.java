package com.tmax.tibero.jdbc.data;

public class BatchInfo {
  private int currentRowIndex = 0;
  
  private BindData deferredRow;
  
  public BatchInfo() {}
  
  public BatchInfo(BindData paramBindData, int paramInt) {
    this.deferredRow = paramBindData;
    this.currentRowIndex = paramInt;
  }
  
  public int getCurrentRowIndex() {
    return this.currentRowIndex;
  }
  
  public BindData getDeferredRow() {
    return this.deferredRow;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\data\BatchInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */