package com.tmax.tibero.jdbc.dpl.binder;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.TbDatabaseMetaData;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.data.StreamBuffer;
import com.tmax.tibero.jdbc.dpl.TbDirPathStream;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

public class DPLLongStreamBinder extends DPLBinder {
  public void bind(TbConnection paramTbConnection, TbDirPathStream paramTbDirPathStream, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2) throws SQLException {
    InputStream inputStream = paramTbDirPathStream.getParamStream(paramInt1);
    StreamBuffer streamBuffer = paramTbStreamDataWriter.getStreamBuf();
    String str1 = paramTbDirPathStream.getDPLMetaData().getClientCharSet();
    String str2 = ((TbDatabaseMetaData)paramTbConnection.getMetaData()).getServerCharSet();
    byte[] arrayOfByte = new byte[16384];
    int i = 0;
    boolean bool = false;
    int j = 0;
    int k = 0;
    int m = 0;
    int n = 0;
    try {
      if (streamBuffer.getRemained() <= 4)
        paramTbDirPathStream.dirPathLoadStream(paramTbStreamDataWriter, 0); 
      paramTbStreamDataWriter.writeInt(0, 4);
      while (paramInt2 >= 0) {
        bool = (paramInt2 > 16384) ? true : paramInt2;
        i = inputStream.read(arrayOfByte, 0, bool);
        if (i <= 0) {
          if (j) {
            paramTbStreamDataWriter.reWriteInt(streamBuffer.getCurDataSize() - j - 4, j, 4);
            paramTbStreamDataWriter.writePaddingDPL(j);
          } 
          return;
        } 
        String str = new String(arrayOfByte, 0, i, str1);
        byte[] arrayOfByte1 = str.getBytes(str2);
        k = 0;
        while (true) {
          m = streamBuffer.getRemained();
          n = arrayOfByte1.length - k;
          if (n > m) {
            paramTbStreamDataWriter.writeBytes(arrayOfByte1, k, m);
            j += m;
            k += m;
            paramTbStreamDataWriter.reWriteInt(streamBuffer.getCurDataSize() - j - 4, j, 4);
            paramTbStreamDataWriter.writePaddingDPL(j);
            paramTbDirPathStream.dirPathLoadStream(paramTbStreamDataWriter, 1);
            j = 0;
            paramTbStreamDataWriter.writeInt(0, 4);
            continue;
          } 
          paramTbStreamDataWriter.writeBytes(arrayOfByte1, k, n);
          j += n;
          k += n;
          break;
        } 
        paramInt2 -= i;
      } 
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90202, iOException.getMessage());
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\dpl\binder\DPLLongStreamBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */