package com.tmax.tibero.jdbc.dpl.binder;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import com.tmax.tibero.jdbc.data.StreamBuffer;
import com.tmax.tibero.jdbc.dpl.TbDirPathStream;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;

public class DPLReaderBinder extends DPLBinder {
  private final int EXTRA_DATA_LENGTH = 12;
  
  public void bind(TbConnection paramTbConnection, TbDirPathStream paramTbDirPathStream, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2) throws SQLException {
    DataTypeConverter dataTypeConverter = paramTbConnection.getTypeConverter();
    Reader reader = paramTbDirPathStream.getParamReader(paramInt1);
    StreamBuffer streamBuffer = paramTbStreamDataWriter.getStreamBuf();
    int i = paramTbDirPathStream.getDPLMetaData().getDataType(paramInt1 + 1);
    char[] arrayOfChar = new char[4096];
    byte[] arrayOfByte = new byte[16384];
    boolean bool = false;
    int j = 0;
    int k = 0;
    int m = 0;
    try {
      if (streamBuffer.getRemained() <= 4)
        paramTbDirPathStream.dirPathLoadStream(paramTbStreamDataWriter, 0); 
      paramTbStreamDataWriter.writeInt(0, 4);
      while (paramInt2 >= 0) {
        bool = (paramInt2 > 4096) ? true : paramInt2;
        j = reader.read(arrayOfChar, 0, bool);
        if (j <= 0) {
          if (m) {
            paramTbStreamDataWriter.reWriteInt(streamBuffer.getCurDataSize() - m - 4, m, 4);
            paramTbStreamDataWriter.writePaddingDPL(m);
          } 
          return;
        } 
        if (i == 13 || i == 20) {
          k = dataTypeConverter.charsToFixedBytes(arrayOfChar, 0, j, arrayOfByte, 0, arrayOfByte.length);
        } else {
          k = dataTypeConverter.charsToBytes(arrayOfChar, 0, j, arrayOfByte, 0, arrayOfByte.length);
        } 
        int n = 0;
        int i1 = 0;
        int i2 = 0;
        while (true) {
          i1 = streamBuffer.getRemained();
          i2 = k - n;
          if (i2 > i1 - 12 && i1 > 12) {
            i1 -= 12;
            paramTbStreamDataWriter.writeBytes(arrayOfByte, n, i1);
            m += i1;
            n += i1;
            paramTbStreamDataWriter.reWriteInt(streamBuffer.getCurDataSize() - m - 4, m, 4);
            paramTbStreamDataWriter.writePaddingDPL(m);
            paramTbDirPathStream.dirPathLoadStream(paramTbStreamDataWriter, 1);
            m = 0;
            paramTbStreamDataWriter.writeInt(0, 4);
            continue;
          } 
          break;
        } 
        paramTbStreamDataWriter.writeBytes(arrayOfByte, n, i2);
        m += i2;
        n += i2;
        paramInt2 -= j;
      } 
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90202, iOException.getMessage());
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\dpl\binder\DPLReaderBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */