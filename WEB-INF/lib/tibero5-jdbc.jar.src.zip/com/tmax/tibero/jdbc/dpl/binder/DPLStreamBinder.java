package com.tmax.tibero.jdbc.dpl.binder;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.data.StreamBuffer;
import com.tmax.tibero.jdbc.dpl.TbDirPathStream;
import com.tmax.tibero.jdbc.err.TbError;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

public class DPLStreamBinder extends DPLBinder {
  public void bind(TbConnection paramTbConnection, TbDirPathStream paramTbDirPathStream, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2) throws SQLException {
    InputStream inputStream = paramTbDirPathStream.getParamStream(paramInt1);
    StreamBuffer streamBuffer = paramTbStreamDataWriter.getStreamBuf();
    int i = 0;
    int j = 0;
    int k = 0;
    try {
      if (streamBuffer.getRemained() <= 4)
        paramTbDirPathStream.dirPathLoadStream(paramTbStreamDataWriter, 0); 
      while (paramInt2 >= 0) {
        paramTbStreamDataWriter.writeInt(0, 4);
        j = streamBuffer.getRemained();
        k = (paramInt2 > j) ? j : paramInt2;
        i = inputStream.read(streamBuffer.getRawBytes(), streamBuffer.getCurDataSize(), k);
        if (i == -1)
          i = 0; 
        paramTbStreamDataWriter.setCurDataSize(streamBuffer.getCurDataSize() + i);
        paramTbStreamDataWriter.reWriteInt(streamBuffer.getCurDataSize() - i - 4, i, 4);
        paramTbStreamDataWriter.writePaddingDPL(i);
        if (i == j) {
          paramTbDirPathStream.dirPathLoadStream(paramTbStreamDataWriter, 1);
        } else {
          return;
        } 
        paramInt2 -= i;
      } 
    } catch (IOException iOException) {
      throw TbError.newSQLException(-90202, iOException.getMessage());
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\dpl\binder\DPLStreamBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */