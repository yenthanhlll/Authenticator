package com.tmax.tibero.jdbc.dpl.binder;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.data.DataTypeConverter;
import com.tmax.tibero.jdbc.dpl.TbDirPathStream;
import java.sql.SQLException;

public class DPLStringBinder extends DPLBinder {
  public void bind(TbConnection paramTbConnection, TbDirPathStream paramTbDirPathStream, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2) throws SQLException {
    DataTypeConverter dataTypeConverter = paramTbConnection.getTypeConverter();
    int i = paramTbDirPathStream.getDPLMetaData().getDataType(paramInt1 + 1);
    String str = paramTbDirPathStream.getParamString(paramInt1);
    int j = str.length() * dataTypeConverter.getMaxBytesPerChar();
    paramTbStreamDataWriter.makeBufferAvailable(j + 4);
    byte[] arrayOfByte = paramTbStreamDataWriter.getStreamBuf().getRawBytes();
    int m = paramTbStreamDataWriter.getBufferedDataSize();
    paramTbStreamDataWriter.writeInt(0, 4);
    int n = paramTbStreamDataWriter.getBufferedDataSize();
    int k = dataTypeConverter.castFromString(arrayOfByte, n, str, i);
    paramTbStreamDataWriter.moveOffset(k);
    paramTbStreamDataWriter.writePaddingDPL(k);
    paramTbStreamDataWriter.reWriteInt(m, k, 4);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\dpl\binder\DPLStringBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */