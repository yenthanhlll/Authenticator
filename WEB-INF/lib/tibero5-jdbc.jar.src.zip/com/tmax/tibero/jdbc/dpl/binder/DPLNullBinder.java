package com.tmax.tibero.jdbc.dpl.binder;

import com.tmax.tibero.jdbc.TbConnection;
import com.tmax.tibero.jdbc.comm.TbStreamDataWriter;
import com.tmax.tibero.jdbc.dpl.TbDirPathStream;
import java.sql.SQLException;

public class DPLNullBinder extends DPLBinder {
  public void bind(TbConnection paramTbConnection, TbDirPathStream paramTbDirPathStream, TbStreamDataWriter paramTbStreamDataWriter, int paramInt1, int paramInt2) throws SQLException {
    paramTbStreamDataWriter.writeInt(0, 4);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\dpl\binder\DPLNullBinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */