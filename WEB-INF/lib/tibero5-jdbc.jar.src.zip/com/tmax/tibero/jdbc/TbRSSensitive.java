package com.tmax.tibero.jdbc;

import com.tmax.tibero.jdbc.data.Row;
import com.tmax.tibero.jdbc.err.TbError;
import com.tmax.tibero.jdbc.util.TbSQLParser;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.util.ArrayList;
import java.util.List;

public class TbRSSensitive extends TbRSScrollable {
  protected TbPreparedStatement refetchStmt = null;
  
  private int[] rowIndices = null;
  
  private List<byte[]> refetchRowids = null;
  
  private int lastRowIdParamCnt = 0;
  
  private int startRowIndex = -1;
  
  private int stopRowIndex = -1;
  
  private static final int REFRESH_FETCH_SIZE = 1;
  
  protected TbRSSensitive(TbStatement paramTbStatement, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    super(paramTbStatement, paramInt1, paramInt2, paramInt3);
    this.rowIndices = new int[paramTbStatement.getFetchSize()];
    this.refetchRowids = (List)new ArrayList<byte>(paramTbStatement.getFetchSize());
  }
  
  public synchronized boolean absolute(int paramInt) throws SQLException {
    if (super.absolute(paramInt)) {
      refreshRow();
      return true;
    } 
    return false;
  }
  
  private void buildRefetchStatement(int paramInt) throws SQLException {
    if (this.lastRowIdParamCnt != paramInt) {
      if (this.refetchStmt != null)
        try {
          this.refetchStmt.close();
        } catch (SQLException sQLException) {
          addWarning(new SQLWarning(TbError.getMsg(-590708), null, -590708, sQLException));
        } finally {
          this.refetchStmt = null;
        }  
      String str = TbSQLParser.getRowIdAddedRefetchSql(this.stmt.getSqlWithRowId(), paramInt);
      this.refetchStmt = new TbPreparedStatement(this.stmt.conn, str);
      this.lastRowIdParamCnt = paramInt;
      if (this.stmt instanceof TbPreparedStatement)
        this.refetchStmt.copyBindParamInfo((TbPreparedStatement)this.stmt); 
    } 
    int i = this.refetchStmt.getParameterCnt();
    int j = i - this.lastRowIdParamCnt;
    for (byte b = 0; b < this.lastRowIdParamCnt; b++)
      this.refetchStmt.setBytes(j + b + 1, 15, this.refetchRowids.get(b)); 
  }
  
  public synchronized void close() throws SQLException {
    try {
      super.close();
    } finally {
      if (this.refetchStmt != null)
        try {
          this.refetchStmt.close();
        } catch (Exception exception) {
        
        } finally {
          this.refetchStmt = null;
        }  
    } 
  }
  
  protected void fetchRowsChunk() throws SQLException {
    super.fetchRowsChunk();
    if (this.currentFetchCount > 0) {
      this.stopRowIndex = this.rowsFetchedCnt - 1;
      this.startRowIndex = this.rowsFetchedCnt - this.currentFetchCount;
    } 
  }
  
  private int fillRowIndexForRefetch(int paramInt) throws SQLException {
    byte b = 0;
    if (this.fetchDirection == 1001) {
      int i = Math.max(this.currentRowIndex - paramInt, 0);
      int j = this.currentRowIndex;
      while (j > i) {
        this.rowIndices[b] = j;
        this.refetchRowids.add(b, getRowAt(j).getRawBytes(1));
        j--;
        b++;
      } 
    } else {
      int i = Math.min(this.currentRowIndex + paramInt, this.rowsFetchedCnt);
      int j = this.currentRowIndex;
      while (j < i) {
        this.rowIndices[b] = j;
        this.refetchRowids.add(b, getRowAt(j).getRawBytes(1));
        j++;
        b++;
      } 
    } 
    return b;
  }
  
  public synchronized boolean first() throws SQLException {
    if (super.first()) {
      refreshRow();
      return true;
    } 
    return false;
  }
  
  private boolean isByteArrayEqual(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    if (paramArrayOfbyte1.length != paramArrayOfbyte2.length)
      return false; 
    for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
      if (paramArrayOfbyte1[b] != paramArrayOfbyte2[b])
        return false; 
    } 
    return true;
  }
  
  public synchronized boolean last() throws SQLException {
    if (super.last()) {
      refreshRow();
      return true;
    } 
    return false;
  }
  
  public synchronized boolean next() throws SQLException {
    if (super.next()) {
      refreshRow();
      return true;
    } 
    return false;
  }
  
  public synchronized boolean previous() throws SQLException {
    if (super.previous()) {
      refreshRow();
      return true;
    } 
    return false;
  }
  
  private void refreshCachedRows(int paramInt) throws SQLException {
    this.refetchStmt.setFetchSize(paramInt);
    TbRSFwOnly tbRSFwOnly = (TbRSFwOnly)this.refetchStmt.executeQuery();
    while (tbRSFwOnly.next()) {
      byte[] arrayOfByte = tbRSFwOnly.getBytes(1);
      for (byte b = 0; b < paramInt; b++) {
        if (isByteArrayEqual(arrayOfByte, this.refetchRowids.get(b))) {
          Row row1 = tbRSFwOnly.getCurrentRow();
          Row row2 = new Row();
          row2.duplicate(row1);
          setRowAt(this.rowIndices[b], row2);
          break;
        } 
      } 
    } 
    try {
      tbRSFwOnly.close();
    } catch (SQLException sQLException) {
      addWarning(new SQLWarning(TbError.getMsg(-590708), null, -590708, sQLException));
    } 
  }
  
  protected boolean isCurrentWindow(int paramInt) {
    return (paramInt >= this.startRowIndex && paramInt <= this.stopRowIndex);
  }
  
  public synchronized void refreshRow() throws SQLException {
    int i = refreshRowForced(this.fetchSize);
    if (this.fetchDirection == 1000) {
      this.startRowIndex = this.currentRowIndex;
      this.stopRowIndex = this.currentRowIndex + i - 1;
    } else {
      this.startRowIndex = this.currentRowIndex - i + 1;
      this.stopRowIndex = this.currentRowIndex;
    } 
  }
  
  protected int refreshRowForced(int paramInt) throws SQLException {
    if (!this.rsetType.useRowId())
      throw TbError.newSQLException(-590724); 
    try {
      int i = fillRowIndexForRefetch(1);
      buildRefetchStatement(i);
      refreshCachedRows(i);
      return i;
    } catch (SQLException sQLException) {
      throw TbError.newSQLException(-90626, TbError.trimVendorHeader(sQLException.getMessage()));
    } 
  }
  
  public synchronized boolean relative(int paramInt) throws SQLException {
    if (super.relative(paramInt)) {
      refreshRow();
      return true;
    } 
    return false;
  }
  
  protected void removeCurrentRow() throws SQLException {
    checkRowIndex(this.currentRowIndex);
    this.rows.remove(this.currentRowIndex);
    if (this.currentRowIndex < this.startRowIndex)
      this.startRowIndex--; 
    if (this.currentRowIndex < this.stopRowIndex)
      this.stopRowIndex--; 
    this.currentRowIndex--;
    this.rowsFetchedCnt--;
  }
  
  public void reset() {
    super.reset();
    this.refetchStmt = null;
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\tibero5-jdbc.jar!\com\tmax\tibero\jdbc\TbRSSensitive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */