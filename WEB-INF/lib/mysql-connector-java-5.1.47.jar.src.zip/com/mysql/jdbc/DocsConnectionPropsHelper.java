/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocsConnectionPropsHelper
/*    */   extends ConnectionPropertiesImpl
/*    */ {
/*    */   static final long serialVersionUID = -1580779062220390294L;
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 31 */     System.out.println((new DocsConnectionPropsHelper()).exposeAsXml());
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\DocsConnectionPropsHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */