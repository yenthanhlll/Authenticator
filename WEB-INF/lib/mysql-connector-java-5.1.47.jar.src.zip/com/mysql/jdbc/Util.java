/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.charset.Charset;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   class RandStructcture
/*     */   {
/*     */     long maxValue;
/*     */     double maxValueDbl;
/*     */     long seed1;
/*     */     long seed2;
/*     */   }
/*  61 */   private static Util enclosingInstance = new Util();
/*     */   
/*     */   private static boolean isJdbc4;
/*     */   
/*     */   private static boolean isJdbc42;
/*     */   
/*  67 */   private static int jvmVersion = -1;
/*     */   
/*  69 */   private static int jvmUpdateNumber = -1;
/*     */   
/*     */   private static boolean isColdFusion = false;
/*     */   
/*     */   static {
/*     */     try {
/*  75 */       Class.forName("java.sql.NClob");
/*  76 */       isJdbc4 = true;
/*  77 */     } catch (ClassNotFoundException e) {
/*  78 */       isJdbc4 = false;
/*     */     } 
/*     */     
/*     */     try {
/*  82 */       Class.forName("java.sql.JDBCType");
/*  83 */       isJdbc42 = true;
/*  84 */     } catch (Throwable t) {
/*  85 */       isJdbc42 = false;
/*     */     } 
/*     */     
/*  88 */     String jvmVersionString = System.getProperty("java.version");
/*  89 */     int startPos = jvmVersionString.indexOf('.');
/*  90 */     int endPos = startPos + 1;
/*  91 */     if (startPos != -1) {
/*  92 */       while (Character.isDigit(jvmVersionString.charAt(endPos)) && ++endPos < jvmVersionString.length());
/*     */     }
/*     */ 
/*     */     
/*  96 */     startPos++;
/*  97 */     if (endPos > startPos) {
/*  98 */       jvmVersion = Integer.parseInt(jvmVersionString.substring(startPos, endPos));
/*     */     } else {
/*     */       
/* 101 */       jvmVersion = isJdbc42 ? 8 : (isJdbc4 ? 6 : 5);
/*     */     } 
/* 103 */     startPos = jvmVersionString.indexOf("_");
/* 104 */     endPos = startPos + 1;
/* 105 */     if (startPos != -1) {
/* 106 */       while (Character.isDigit(jvmVersionString.charAt(endPos)) && ++endPos < jvmVersionString.length());
/*     */     }
/*     */ 
/*     */     
/* 110 */     startPos++;
/* 111 */     if (endPos > startPos) {
/* 112 */       jvmUpdateNumber = Integer.parseInt(jvmVersionString.substring(startPos, endPos));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     String loadedFrom = stackTraceToString(new Throwable());
/*     */     
/* 123 */     if (loadedFrom != null) {
/* 124 */       isColdFusion = (loadedFrom.indexOf("coldfusion") != -1);
/*     */     } else {
/* 126 */       isColdFusion = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isJdbc4() {
/* 131 */     return isJdbc4;
/*     */   }
/*     */   
/*     */   public static boolean isJdbc42() {
/* 135 */     return isJdbc42;
/*     */   }
/*     */   
/*     */   public static int getJVMVersion() {
/* 139 */     return jvmVersion;
/*     */   }
/*     */   
/*     */   public static boolean jvmMeetsMinimum(int version, int updateNumber) {
/* 143 */     return (getJVMVersion() > version || (getJVMVersion() == version && getJVMUpdateNumber() >= updateNumber));
/*     */   }
/*     */   
/*     */   public static int getJVMUpdateNumber() {
/* 147 */     return jvmUpdateNumber;
/*     */   }
/*     */   
/*     */   public static boolean isColdFusion() {
/* 151 */     return isColdFusion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCommunityEdition(String serverVersion) {
/* 158 */     return !isEnterpriseEdition(serverVersion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnterpriseEdition(String serverVersion) {
/* 165 */     return (serverVersion.contains("enterprise") || serverVersion.contains("commercial") || serverVersion.contains("advanced"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String newCrypt(String password, String seed, String encoding) {
/* 173 */     if (password == null || password.length() == 0) {
/* 174 */       return password;
/*     */     }
/*     */     
/* 177 */     long[] pw = newHash(seed.getBytes());
/* 178 */     long[] msg = hashPre41Password(password, encoding);
/* 179 */     long max = 1073741823L;
/* 180 */     long seed1 = (pw[0] ^ msg[0]) % max;
/* 181 */     long seed2 = (pw[1] ^ msg[1]) % max;
/* 182 */     char[] chars = new char[seed.length()];
/*     */     int i;
/* 184 */     for (i = 0; i < seed.length(); i++) {
/* 185 */       seed1 = (seed1 * 3L + seed2) % max;
/* 186 */       seed2 = (seed1 + seed2 + 33L) % max;
/* 187 */       double d1 = seed1 / max;
/* 188 */       byte b1 = (byte)(int)Math.floor(d1 * 31.0D + 64.0D);
/* 189 */       chars[i] = (char)b1;
/*     */     } 
/*     */     
/* 192 */     seed1 = (seed1 * 3L + seed2) % max;
/* 193 */     seed2 = (seed1 + seed2 + 33L) % max;
/* 194 */     double d = seed1 / max;
/* 195 */     byte b = (byte)(int)Math.floor(d * 31.0D);
/*     */     
/* 197 */     for (i = 0; i < seed.length(); i++) {
/* 198 */       chars[i] = (char)(chars[i] ^ (char)b);
/*     */     }
/*     */     
/* 201 */     return new String(chars);
/*     */   }
/*     */ 
/*     */   
/*     */   public static long[] hashPre41Password(String password, String encoding) {
/*     */     try {
/* 207 */       return newHash(password.replaceAll("\\s", "").getBytes(encoding));
/* 208 */     } catch (UnsupportedEncodingException e) {
/* 209 */       return new long[0];
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long[] hashPre41Password(String password) {
/* 214 */     return hashPre41Password(password, Charset.defaultCharset().name());
/*     */   }
/*     */   
/*     */   static long[] newHash(byte[] password) {
/* 218 */     long nr = 1345345333L;
/* 219 */     long add = 7L;
/* 220 */     long nr2 = 305419889L;
/*     */ 
/*     */     
/* 223 */     for (byte b : password) {
/* 224 */       long tmp = (0xFF & b);
/* 225 */       nr ^= ((nr & 0x3FL) + add) * tmp + (nr << 8L);
/* 226 */       nr2 += nr2 << 8L ^ nr;
/* 227 */       add += tmp;
/*     */     } 
/*     */     
/* 230 */     long[] result = new long[2];
/* 231 */     result[0] = nr & 0x7FFFFFFFL;
/* 232 */     result[1] = nr2 & 0x7FFFFFFFL;
/*     */     
/* 234 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String oldCrypt(String password, String seed) {
/* 242 */     long max = 33554431L;
/*     */ 
/*     */ 
/*     */     
/* 246 */     if (password == null || password.length() == 0) {
/* 247 */       return password;
/*     */     }
/*     */     
/* 250 */     long hp = oldHash(seed);
/* 251 */     long hm = oldHash(password);
/*     */     
/* 253 */     long nr = hp ^ hm;
/* 254 */     nr %= max;
/* 255 */     long s1 = nr;
/* 256 */     long s2 = nr / 2L;
/*     */     
/* 258 */     char[] chars = new char[seed.length()];
/*     */     
/* 260 */     for (int i = 0; i < seed.length(); i++) {
/* 261 */       s1 = (s1 * 3L + s2) % max;
/* 262 */       s2 = (s1 + s2 + 33L) % max;
/* 263 */       double d = s1 / max;
/* 264 */       byte b = (byte)(int)Math.floor(d * 31.0D + 64.0D);
/* 265 */       chars[i] = (char)b;
/*     */     } 
/*     */     
/* 268 */     return new String(chars);
/*     */   }
/*     */   
/*     */   static long oldHash(String password) {
/* 272 */     long nr = 1345345333L;
/* 273 */     long nr2 = 7L;
/*     */ 
/*     */     
/* 276 */     for (int i = 0; i < password.length(); i++) {
/* 277 */       if (password.charAt(i) != ' ' && password.charAt(i) != '\t') {
/*     */ 
/*     */ 
/*     */         
/* 281 */         long tmp = password.charAt(i);
/* 282 */         nr ^= ((nr & 0x3FL) + nr2) * tmp + (nr << 8L);
/* 283 */         nr2 += tmp;
/*     */       } 
/*     */     } 
/* 286 */     return nr & 0x7FFFFFFFL;
/*     */   }
/*     */   
/*     */   private static RandStructcture randomInit(long seed1, long seed2) {
/* 290 */     enclosingInstance.getClass(); RandStructcture randStruct = new RandStructcture();
/*     */     
/* 292 */     randStruct.maxValue = 1073741823L;
/* 293 */     randStruct.maxValueDbl = randStruct.maxValue;
/* 294 */     randStruct.seed1 = seed1 % randStruct.maxValue;
/* 295 */     randStruct.seed2 = seed2 % randStruct.maxValue;
/*     */     
/* 297 */     return randStruct;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object readObject(ResultSet resultSet, int index) throws Exception {
/* 314 */     ObjectInputStream objIn = new ObjectInputStream(resultSet.getBinaryStream(index));
/* 315 */     Object obj = objIn.readObject();
/* 316 */     objIn.close();
/*     */     
/* 318 */     return obj;
/*     */   }
/*     */   
/*     */   private static double rnd(RandStructcture randStruct) {
/* 322 */     randStruct.seed1 = (randStruct.seed1 * 3L + randStruct.seed2) % randStruct.maxValue;
/* 323 */     randStruct.seed2 = (randStruct.seed1 + randStruct.seed2 + 33L) % randStruct.maxValue;
/*     */     
/* 325 */     return randStruct.seed1 / randStruct.maxValueDbl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String scramble(String message, String password) {
/* 335 */     byte[] to = new byte[8];
/* 336 */     String val = "";
/*     */     
/* 338 */     message = message.substring(0, 8);
/*     */     
/* 340 */     if (password != null && password.length() > 0) {
/* 341 */       long[] hashPass = hashPre41Password(password);
/* 342 */       long[] hashMessage = newHash(message.getBytes());
/*     */       
/* 344 */       RandStructcture randStruct = randomInit(hashPass[0] ^ hashMessage[0], hashPass[1] ^ hashMessage[1]);
/*     */       
/* 346 */       int msgPos = 0;
/* 347 */       int msgLength = message.length();
/* 348 */       int toPos = 0;
/*     */       
/* 350 */       while (msgPos++ < msgLength) {
/* 351 */         to[toPos++] = (byte)(int)(Math.floor(rnd(randStruct) * 31.0D) + 64.0D);
/*     */       }
/*     */ 
/*     */       
/* 355 */       byte extra = (byte)(int)Math.floor(rnd(randStruct) * 31.0D);
/*     */       
/* 357 */       for (int i = 0; i < to.length; i++) {
/* 358 */         to[i] = (byte)(to[i] ^ extra);
/*     */       }
/*     */       
/* 361 */       val = StringUtils.toString(to);
/*     */     } 
/*     */     
/* 364 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stackTraceToString(Throwable ex) {
/* 377 */     StringBuilder traceBuf = new StringBuilder();
/* 378 */     traceBuf.append(Messages.getString("Util.1"));
/*     */     
/* 380 */     if (ex != null) {
/* 381 */       traceBuf.append(ex.getClass().getName());
/*     */       
/* 383 */       String message = ex.getMessage();
/*     */       
/* 385 */       if (message != null) {
/* 386 */         traceBuf.append(Messages.getString("Util.2"));
/* 387 */         traceBuf.append(message);
/*     */       } 
/*     */       
/* 390 */       StringWriter out = new StringWriter();
/*     */       
/* 392 */       PrintWriter printOut = new PrintWriter(out);
/*     */       
/* 394 */       ex.printStackTrace(printOut);
/*     */       
/* 396 */       traceBuf.append(Messages.getString("Util.3"));
/* 397 */       traceBuf.append(out.toString());
/*     */     } 
/*     */     
/* 400 */     traceBuf.append(Messages.getString("Util.4"));
/*     */     
/* 402 */     return traceBuf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getInstance(String className, Class<?>[] argTypes, Object[] args, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*     */     try {
/* 408 */       return handleNewInstance(Class.forName(className).getConstructor(argTypes), args, exceptionInterceptor);
/* 409 */     } catch (SecurityException e) {
/* 410 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/* 411 */     } catch (NoSuchMethodException e) {
/* 412 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/* 413 */     } catch (ClassNotFoundException e) {
/* 414 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object handleNewInstance(Constructor<?> ctor, Object[] args, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*     */     try {
/* 425 */       return ctor.newInstance(args);
/* 426 */     } catch (IllegalArgumentException e) {
/* 427 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/* 428 */     } catch (InstantiationException e) {
/* 429 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/* 430 */     } catch (IllegalAccessException e) {
/* 431 */       throw SQLError.createSQLException("Can't instantiate required class", "S1000", e, exceptionInterceptor);
/* 432 */     } catch (InvocationTargetException e) {
/* 433 */       Throwable target = e.getTargetException();
/*     */       
/* 435 */       if (target instanceof SQLException) {
/* 436 */         throw (SQLException)target;
/*     */       }
/*     */       
/* 439 */       if (target instanceof ExceptionInInitializerError) {
/* 440 */         target = ((ExceptionInInitializerError)target).getException();
/*     */       }
/*     */       
/* 443 */       throw SQLError.createSQLException(target.toString(), "S1000", target, exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean interfaceExists(String hostname) {
/*     */     try {
/* 457 */       Class<?> networkInterfaceClass = Class.forName("java.net.NetworkInterface"); return 
/* 458 */         (networkInterfaceClass.getMethod("getByName", (Class[])null).invoke(networkInterfaceClass, new Object[] { hostname }) != null);
/* 459 */     } catch (Throwable t) {
/* 460 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void resultSetToMap(Map<Object, Object> mappedValues, ResultSet rs) throws SQLException {
/* 466 */     while (rs.next()) {
/* 467 */       mappedValues.put(rs.getObject(1), rs.getObject(2));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void resultSetToMap(Map<Object, Object> mappedValues, ResultSet rs, int key, int value) throws SQLException {
/* 473 */     while (rs.next()) {
/* 474 */       mappedValues.put(rs.getObject(key), rs.getObject(value));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void resultSetToMap(Map<Object, Object> mappedValues, ResultSet rs, String key, String value) throws SQLException {
/* 480 */     while (rs.next()) {
/* 481 */       mappedValues.put(rs.getObject(key), rs.getObject(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public static Map<Object, Object> calculateDifferences(Map<?, ?> map1, Map<?, ?> map2) {
/* 486 */     Map<Object, Object> diffMap = new HashMap<Object, Object>();
/*     */     
/* 488 */     for (Map.Entry<?, ?> entry : map1.entrySet()) {
/* 489 */       Object key = entry.getKey();
/*     */       
/* 491 */       Number value1 = null;
/* 492 */       Number value2 = null;
/*     */       
/* 494 */       if (entry.getValue() instanceof Number) {
/*     */         
/* 496 */         value1 = (Number)entry.getValue();
/* 497 */         value2 = (Number)map2.get(key);
/*     */       } else {
/*     */         try {
/* 500 */           value1 = new Double(entry.getValue().toString());
/* 501 */           value2 = new Double(map2.get(key).toString());
/* 502 */         } catch (NumberFormatException nfe) {
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 507 */       if (value1.equals(value2)) {
/*     */         continue;
/*     */       }
/*     */       
/* 511 */       if (value1 instanceof Byte) {
/* 512 */         diffMap.put(key, Byte.valueOf((byte)(((Byte)value2).byteValue() - ((Byte)value1).byteValue()))); continue;
/* 513 */       }  if (value1 instanceof Short) {
/* 514 */         diffMap.put(key, Short.valueOf((short)(((Short)value2).shortValue() - ((Short)value1).shortValue()))); continue;
/* 515 */       }  if (value1 instanceof Integer) {
/* 516 */         diffMap.put(key, Integer.valueOf(((Integer)value2).intValue() - ((Integer)value1).intValue())); continue;
/* 517 */       }  if (value1 instanceof Long) {
/* 518 */         diffMap.put(key, Long.valueOf(((Long)value2).longValue() - ((Long)value1).longValue())); continue;
/* 519 */       }  if (value1 instanceof Float) {
/* 520 */         diffMap.put(key, Float.valueOf(((Float)value2).floatValue() - ((Float)value1).floatValue())); continue;
/* 521 */       }  if (value1 instanceof Double) {
/* 522 */         diffMap.put(key, Double.valueOf((((Double)value2).shortValue() - ((Double)value1).shortValue()))); continue;
/* 523 */       }  if (value1 instanceof BigDecimal) {
/* 524 */         diffMap.put(key, ((BigDecimal)value2).subtract((BigDecimal)value1)); continue;
/* 525 */       }  if (value1 instanceof BigInteger) {
/* 526 */         diffMap.put(key, ((BigInteger)value2).subtract((BigInteger)value1));
/*     */       }
/*     */     } 
/*     */     
/* 530 */     return diffMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Extension> loadExtensions(Connection conn, Properties props, String extensionClassNames, String errorMessageKey, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/* 546 */     List<Extension> extensionList = new LinkedList<Extension>();
/*     */     
/* 548 */     List<String> interceptorsToCreate = StringUtils.split(extensionClassNames, ",", true);
/*     */     
/* 550 */     String className = null;
/*     */     
/*     */     try {
/* 553 */       for (int i = 0, s = interceptorsToCreate.size(); i < s; i++) {
/* 554 */         className = interceptorsToCreate.get(i);
/* 555 */         Extension extensionInstance = (Extension)Class.forName(className).newInstance();
/* 556 */         extensionInstance.init(conn, props);
/*     */         
/* 558 */         extensionList.add(extensionInstance);
/*     */       } 
/* 560 */     } catch (Throwable t) {
/* 561 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString(errorMessageKey, new Object[] { className }), exceptionInterceptor);
/* 562 */       sqlEx.initCause(t);
/*     */       
/* 564 */       throw sqlEx;
/*     */     } 
/*     */     
/* 567 */     return extensionList;
/*     */   }
/*     */ 
/*     */   
/* 571 */   private static final ConcurrentMap<Class<?>, Boolean> isJdbcInterfaceCache = new ConcurrentHashMap<Class<?>, Boolean>();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String MYSQL_JDBC_PACKAGE_ROOT;
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJdbcInterface(Class<?> clazz) {
/* 580 */     if (isJdbcInterfaceCache.containsKey(clazz)) {
/* 581 */       return ((Boolean)isJdbcInterfaceCache.get(clazz)).booleanValue();
/*     */     }
/*     */     
/* 584 */     if (clazz.isInterface()) {
/*     */       try {
/* 586 */         if (isJdbcPackage(getPackageName(clazz))) {
/* 587 */           isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 588 */           return true;
/*     */         } 
/* 590 */       } catch (Exception ex) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 598 */     for (Class<?> iface : clazz.getInterfaces()) {
/* 599 */       if (isJdbcInterface(iface)) {
/* 600 */         isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 601 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 605 */     if (clazz.getSuperclass() != null && isJdbcInterface(clazz.getSuperclass())) {
/* 606 */       isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 607 */       return true;
/*     */     } 
/*     */     
/* 610 */     isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(false));
/* 611 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 618 */     String packageName = getPackageName(MultiHostConnectionProxy.class);
/*     */     
/* 620 */     MYSQL_JDBC_PACKAGE_ROOT = packageName.substring(0, packageName.indexOf("jdbc") + 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJdbcPackage(String packageName) {
/* 630 */     return (packageName != null && (packageName.startsWith("java.sql") || packageName.startsWith("javax.sql") || packageName.startsWith(MYSQL_JDBC_PACKAGE_ROOT)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 635 */   private static final ConcurrentMap<Class<?>, Class<?>[]> implementedInterfacesCache = (ConcurrentMap)new ConcurrentHashMap<Class<?>, Class<?>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] getImplementedInterfaces(Class<?> clazz) {
/* 647 */     Class<?>[] implementedInterfaces = implementedInterfacesCache.get(clazz);
/* 648 */     if (implementedInterfaces != null) {
/* 649 */       return implementedInterfaces;
/*     */     }
/*     */     
/* 652 */     Set<Class<?>> interfaces = new LinkedHashSet<Class<?>>();
/* 653 */     Class<?> superClass = clazz;
/*     */     do {
/* 655 */       Collections.addAll(interfaces, superClass.getInterfaces());
/* 656 */     } while ((superClass = superClass.getSuperclass()) != null);
/*     */     
/* 658 */     implementedInterfaces = (Class[])interfaces.<Class<?>[]>toArray((Class<?>[][])new Class[interfaces.size()]);
/* 659 */     Class<?>[] oldValue = implementedInterfacesCache.putIfAbsent(clazz, implementedInterfaces);
/* 660 */     if (oldValue != null) {
/* 661 */       implementedInterfaces = oldValue;
/*     */     }
/* 663 */     return implementedInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long secondsSinceMillis(long timeInMillis) {
/* 675 */     return (System.currentTimeMillis() - timeInMillis) / 1000L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int truncateAndConvertToInt(long longValue) {
/* 685 */     return (longValue > 2147483647L) ? Integer.MAX_VALUE : ((longValue < -2147483648L) ? Integer.MIN_VALUE : (int)longValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] truncateAndConvertToInt(long[] longArray) {
/* 695 */     int[] intArray = new int[longArray.length];
/*     */     
/* 697 */     for (int i = 0; i < longArray.length; i++) {
/* 698 */       intArray[i] = (longArray[i] > 2147483647L) ? Integer.MAX_VALUE : ((longArray[i] < -2147483648L) ? Integer.MIN_VALUE : (int)longArray[i]);
/*     */     }
/* 700 */     return intArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Class<?> clazz) {
/* 712 */     String fqcn = clazz.getName();
/* 713 */     int classNameStartsAt = fqcn.lastIndexOf('.');
/* 714 */     if (classNameStartsAt > 0) {
/* 715 */       return fqcn.substring(0, classNameStartsAt);
/*     */     }
/* 717 */     return "";
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */