/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotImplemented
/*    */   extends SQLException
/*    */ {
/*    */   static final long serialVersionUID = 7768433826547599990L;
/*    */   
/*    */   public NotImplemented() {
/* 37 */     super(Messages.getString("NotImplemented.0"), "S1C00");
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\NotImplemented.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */