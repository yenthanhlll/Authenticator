/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbandonedConnectionCleanupThread
/*     */   implements Runnable
/*     */ {
/*     */   private static final ExecutorService cleanupThreadExcecutorService;
/*  39 */   static Thread threadRef = null;
/*     */   
/*     */   static {
/*  42 */     cleanupThreadExcecutorService = Executors.newSingleThreadExecutor(new ThreadFactory() {
/*     */           public Thread newThread(Runnable r) {
/*  44 */             Thread t = new Thread(r, "Abandoned connection cleanup thread");
/*  45 */             t.setDaemon(true);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  50 */             t.setContextClassLoader(AbandonedConnectionCleanupThread.class.getClassLoader());
/*  51 */             return AbandonedConnectionCleanupThread.threadRef = t;
/*     */           }
/*     */         });
/*  54 */     cleanupThreadExcecutorService.execute(new AbandonedConnectionCleanupThread());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/*  63 */         checkContextClassLoaders();
/*  64 */         Reference<? extends ConnectionImpl> ref = NonRegisteringDriver.refQueue.remove(5000L);
/*  65 */         if (ref != null) {
/*     */           try {
/*  67 */             ((NonRegisteringDriver.ConnectionPhantomReference)ref).cleanup();
/*     */           } finally {
/*  69 */             NonRegisteringDriver.connectionPhantomRefs.remove(ref);
/*     */           }
/*     */         
/*     */         }
/*  73 */       } catch (InterruptedException e) {
/*  74 */         threadRef = null;
/*     */         
/*     */         return;
/*  77 */       } catch (Exception ex) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkContextClassLoaders() {
/*     */     try {
/*  90 */       threadRef.getContextClassLoader().getResource("");
/*  91 */     } catch (Throwable e) {
/*     */       
/*  93 */       uncheckedShutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean consistentClassLoaders() {
/* 103 */     ClassLoader callerCtxClassLoader = Thread.currentThread().getContextClassLoader();
/* 104 */     ClassLoader threadCtxClassLoader = threadRef.getContextClassLoader();
/* 105 */     return (callerCtxClassLoader != null && threadCtxClassLoader != null && callerCtxClassLoader == threadCtxClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkedShutdown() {
/* 113 */     shutdown(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void uncheckedShutdown() {
/* 120 */     shutdown(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void shutdown(boolean checked) {
/* 130 */     if (checked && !consistentClassLoaders()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 135 */     cleanupThreadExcecutorService.shutdownNow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void shutdown() {
/* 145 */     checkedShutdown();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\AbandonedConnectionCleanupThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */