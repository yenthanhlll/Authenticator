/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BestResponseTimeBalanceStrategy
/*     */   implements BalanceStrategy
/*     */ {
/*     */   public void destroy() {}
/*     */   
/*     */   public void init(Connection conn, Properties props) throws SQLException {}
/*     */   
/*     */   public ConnectionImpl pickConnection(LoadBalancedConnectionProxy proxy, List<String> configuredHosts, Map<String, ConnectionImpl> liveConnections, long[] responseTimes, int numRetries) throws SQLException {
/*  47 */     Map<String, Long> blackList = proxy.getGlobalBlacklist();
/*     */     
/*  49 */     SQLException ex = null;
/*     */     
/*  51 */     for (int attempts = 0; attempts < numRetries; ) {
/*  52 */       long minResponseTime = Long.MAX_VALUE;
/*     */       
/*  54 */       int bestHostIndex = 0;
/*     */ 
/*     */       
/*  57 */       if (blackList.size() == configuredHosts.size()) {
/*  58 */         blackList = proxy.getGlobalBlacklist();
/*     */       }
/*     */       
/*  61 */       for (int i = 0; i < responseTimes.length; i++) {
/*  62 */         long candidateResponseTime = responseTimes[i];
/*     */         
/*  64 */         if (candidateResponseTime < minResponseTime && !blackList.containsKey(configuredHosts.get(i))) {
/*  65 */           if (candidateResponseTime == 0L) {
/*  66 */             bestHostIndex = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/*  71 */           bestHostIndex = i;
/*  72 */           minResponseTime = candidateResponseTime;
/*     */         } 
/*     */       } 
/*     */       
/*  76 */       String bestHost = configuredHosts.get(bestHostIndex);
/*     */       
/*  78 */       ConnectionImpl conn = liveConnections.get(bestHost);
/*     */       
/*  80 */       if (conn == null) {
/*     */         try {
/*  82 */           conn = proxy.createConnectionForHost(bestHost);
/*  83 */         } catch (SQLException sqlEx) {
/*  84 */           ex = sqlEx;
/*     */           
/*  86 */           if (proxy.shouldExceptionTriggerConnectionSwitch(sqlEx)) {
/*  87 */             proxy.addToGlobalBlacklist(bestHost);
/*  88 */             blackList.put(bestHost, null);
/*     */             
/*  90 */             if (blackList.size() == configuredHosts.size()) {
/*  91 */               attempts++;
/*     */               try {
/*  93 */                 Thread.sleep(250L);
/*  94 */               } catch (InterruptedException e) {}
/*     */               
/*  96 */               blackList = proxy.getGlobalBlacklist();
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 102 */           throw sqlEx;
/*     */         } 
/*     */       }
/*     */       
/* 106 */       return conn;
/*     */     } 
/*     */     
/* 109 */     if (ex != null) {
/* 110 */       throw ex;
/*     */     }
/*     */     
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\BestResponseTimeBalanceStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */