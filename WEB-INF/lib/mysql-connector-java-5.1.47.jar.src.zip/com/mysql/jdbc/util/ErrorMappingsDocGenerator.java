/*    */ package com.mysql.jdbc.util;
/*    */ 
/*    */ import com.mysql.jdbc.SQLError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorMappingsDocGenerator
/*    */ {
/*    */   public static void main(String[] args) throws Exception {
/* 34 */     SQLError.dumpSqlStatesMappingsAsXml();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdb\\util\ErrorMappingsDocGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */