/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Field
/*     */ {
/*     */   private static final int AUTO_INCREMENT_FLAG = 512;
/*     */   private static final int NO_CHARSET_INFO = -1;
/*     */   private byte[] buffer;
/*  42 */   private int collationIndex = 0;
/*     */   
/*  44 */   private String encoding = null;
/*     */   
/*     */   private int colDecimals;
/*     */   
/*     */   private short colFlag;
/*     */   
/*  50 */   private String collationName = null;
/*     */   
/*  52 */   private MySQLConnection connection = null;
/*     */   
/*  54 */   private String databaseName = null;
/*     */   
/*  56 */   private int databaseNameLength = -1;
/*     */ 
/*     */   
/*  59 */   private int databaseNameStart = -1;
/*     */   
/*  61 */   protected int defaultValueLength = -1;
/*     */ 
/*     */   
/*  64 */   protected int defaultValueStart = -1;
/*     */   
/*  66 */   private String fullName = null;
/*     */   
/*  68 */   private String fullOriginalName = null;
/*     */   
/*     */   private boolean isImplicitTempTable = false;
/*     */   
/*     */   private long length;
/*     */   
/*  74 */   private int mysqlType = -1;
/*     */   
/*     */   private String name;
/*     */   
/*     */   private int nameLength;
/*     */   
/*     */   private int nameStart;
/*     */   
/*  82 */   private String originalColumnName = null;
/*     */   
/*  84 */   private int originalColumnNameLength = -1;
/*     */ 
/*     */   
/*  87 */   private int originalColumnNameStart = -1;
/*     */   
/*  89 */   private String originalTableName = null;
/*     */   
/*  91 */   private int originalTableNameLength = -1;
/*     */ 
/*     */   
/*  94 */   private int originalTableNameStart = -1;
/*     */   
/*  96 */   private int precisionAdjustFactor = 0;
/*     */   
/*  98 */   private int sqlType = -1;
/*     */ 
/*     */   
/*     */   private String tableName;
/*     */ 
/*     */   
/*     */   private int tableNameLength;
/*     */ 
/*     */   
/*     */   private int tableNameStart;
/*     */ 
/*     */   
/*     */   private boolean useOldNameMetadata = false;
/*     */   
/*     */   private boolean isSingleBit;
/*     */   
/*     */   private int maxBytesPerChar;
/*     */   
/*     */   private final boolean valueNeedsQuoting;
/*     */ 
/*     */   
/*     */   Field(MySQLConnection conn, byte[] buffer, int databaseNameStart, int databaseNameLength, int tableNameStart, int tableNameLength, int originalTableNameStart, int originalTableNameLength, int nameStart, int nameLength, int originalColumnNameStart, int originalColumnNameLength, long length, int mysqlType, short colFlag, int colDecimals, int defaultValueStart, int defaultValueLength, int charsetIndex) throws SQLException {
/* 120 */     this.connection = conn;
/* 121 */     this.buffer = buffer;
/* 122 */     this.nameStart = nameStart;
/* 123 */     this.nameLength = nameLength;
/* 124 */     this.tableNameStart = tableNameStart;
/* 125 */     this.tableNameLength = tableNameLength;
/* 126 */     this.length = length;
/* 127 */     this.colFlag = colFlag;
/* 128 */     this.colDecimals = colDecimals;
/* 129 */     this.mysqlType = mysqlType;
/*     */ 
/*     */     
/* 132 */     this.databaseNameStart = databaseNameStart;
/* 133 */     this.databaseNameLength = databaseNameLength;
/*     */     
/* 135 */     this.originalTableNameStart = originalTableNameStart;
/* 136 */     this.originalTableNameLength = originalTableNameLength;
/*     */     
/* 138 */     this.originalColumnNameStart = originalColumnNameStart;
/* 139 */     this.originalColumnNameLength = originalColumnNameLength;
/*     */     
/* 141 */     this.defaultValueStart = defaultValueStart;
/* 142 */     this.defaultValueLength = defaultValueLength;
/*     */ 
/*     */     
/* 145 */     this.collationIndex = charsetIndex;
/*     */ 
/*     */     
/* 148 */     this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*     */     
/* 150 */     checkForImplicitTemporaryTable();
/*     */     
/* 152 */     boolean isFromFunction = (this.originalTableNameLength == 0);
/*     */     
/* 154 */     if (this.mysqlType == 252) {
/* 155 */       if (this.connection.getBlobsAreStrings() || (this.connection.getFunctionsNeverReturnBlobs() && isFromFunction)) {
/* 156 */         this.sqlType = 12;
/* 157 */         this.mysqlType = 15;
/* 158 */       } else if (this.collationIndex == 63 || !this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 159 */         if (this.connection.getUseBlobToStoreUTF8OutsideBMP() && shouldSetupForUtf8StringInBlob()) {
/* 160 */           setupForUtf8StringInBlob();
/*     */         } else {
/* 162 */           setBlobTypeBasedOnLength();
/* 163 */           this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*     */         } 
/*     */       } else {
/*     */         
/* 167 */         this.mysqlType = 253;
/* 168 */         this.sqlType = -1;
/*     */       } 
/*     */     }
/*     */     
/* 172 */     if (this.sqlType == -6 && this.length == 1L && this.connection.getTinyInt1isBit())
/*     */     {
/* 174 */       if (conn.getTinyInt1isBit()) {
/* 175 */         if (conn.getTransformedBitIsBoolean()) {
/* 176 */           this.sqlType = 16;
/*     */         } else {
/* 178 */           this.sqlType = -7;
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 184 */     if (!isNativeNumericType() && !isNativeDateTimeType()) {
/* 185 */       this.encoding = this.connection.getEncodingForIndex(this.collationIndex);
/*     */ 
/*     */ 
/*     */       
/* 189 */       if ("UnicodeBig".equals(this.encoding)) {
/* 190 */         this.encoding = "UTF-16";
/*     */       }
/*     */ 
/*     */       
/* 194 */       if (this.mysqlType == 245) {
/* 195 */         this.encoding = "UTF-8";
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 200 */       boolean isBinary = isBinary();
/*     */       
/* 202 */       if (this.connection.versionMeetsMinimum(4, 1, 0) && this.mysqlType == 253 && isBinary && this.collationIndex == 63)
/*     */       {
/* 204 */         if (this.connection.getFunctionsNeverReturnBlobs() && isFromFunction) {
/* 205 */           this.sqlType = 12;
/* 206 */           this.mysqlType = 15;
/* 207 */         } else if (isOpaqueBinary()) {
/* 208 */           this.sqlType = -3;
/*     */         } 
/*     */       }
/*     */       
/* 212 */       if (this.connection.versionMeetsMinimum(4, 1, 0) && this.mysqlType == 254 && isBinary && this.collationIndex == 63)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 219 */         if (isOpaqueBinary() && !this.connection.getBlobsAreStrings()) {
/* 220 */           this.sqlType = -2;
/*     */         }
/*     */       }
/*     */       
/* 224 */       if (this.mysqlType == 16) {
/* 225 */         this.isSingleBit = (this.length == 0L || (this.length == 1L && (this.connection.versionMeetsMinimum(5, 0, 21) || this.connection.versionMeetsMinimum(5, 1, 10))));
/*     */ 
/*     */         
/* 228 */         if (!this.isSingleBit) {
/* 229 */           this.colFlag = (short)(this.colFlag | 0x80);
/* 230 */           this.colFlag = (short)(this.colFlag | 0x10);
/* 231 */           isBinary = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 238 */       if (this.sqlType == -4 && !isBinary) {
/* 239 */         this.sqlType = -1;
/* 240 */       } else if (this.sqlType == -3 && !isBinary) {
/* 241 */         this.sqlType = 12;
/*     */       } 
/*     */     } else {
/* 244 */       this.encoding = "US-ASCII";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     if (!isUnsigned()) {
/* 251 */       switch (this.mysqlType) {
/*     */         case 0:
/*     */         case 246:
/* 254 */           this.precisionAdjustFactor = -1;
/*     */           break;
/*     */         
/*     */         case 4:
/*     */         case 5:
/* 259 */           this.precisionAdjustFactor = 1;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } else {
/* 264 */       switch (this.mysqlType) {
/*     */         case 4:
/*     */         case 5:
/* 267 */           this.precisionAdjustFactor = 1;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 272 */     this.valueNeedsQuoting = determineNeedsQuoting();
/*     */   }
/*     */   
/*     */   private boolean shouldSetupForUtf8StringInBlob() throws SQLException {
/* 276 */     String includePattern = this.connection.getUtf8OutsideBmpIncludedColumnNamePattern();
/* 277 */     String excludePattern = this.connection.getUtf8OutsideBmpExcludedColumnNamePattern();
/*     */     
/* 279 */     if (excludePattern != null && !StringUtils.isEmptyOrWhitespaceOnly(excludePattern)) {
/*     */       try {
/* 281 */         if (getOriginalName().matches(excludePattern)) {
/* 282 */           if (includePattern != null && !StringUtils.isEmptyOrWhitespaceOnly(includePattern)) {
/*     */             try {
/* 284 */               if (getOriginalName().matches(includePattern)) {
/* 285 */                 return true;
/*     */               }
/* 287 */             } catch (PatternSyntaxException pse) {
/* 288 */               SQLException sqlEx = SQLError.createSQLException("Illegal regex specified for \"utf8OutsideBmpIncludedColumnNamePattern\"", "S1009", this.connection.getExceptionInterceptor());
/*     */ 
/*     */               
/* 291 */               if (!this.connection.getParanoid()) {
/* 292 */                 sqlEx.initCause(pse);
/*     */               }
/*     */               
/* 295 */               throw sqlEx;
/*     */             } 
/*     */           }
/*     */           
/* 299 */           return false;
/*     */         } 
/* 301 */       } catch (PatternSyntaxException pse) {
/* 302 */         SQLException sqlEx = SQLError.createSQLException("Illegal regex specified for \"utf8OutsideBmpExcludedColumnNamePattern\"", "S1009", this.connection.getExceptionInterceptor());
/*     */ 
/*     */         
/* 305 */         if (!this.connection.getParanoid()) {
/* 306 */           sqlEx.initCause(pse);
/*     */         }
/*     */         
/* 309 */         throw sqlEx;
/*     */       } 
/*     */     }
/*     */     
/* 313 */     return true;
/*     */   }
/*     */   
/*     */   private void setupForUtf8StringInBlob() {
/* 317 */     if (this.length == 255L || this.length == 65535L) {
/* 318 */       this.mysqlType = 15;
/* 319 */       this.sqlType = 12;
/*     */     } else {
/* 321 */       this.mysqlType = 253;
/* 322 */       this.sqlType = -1;
/*     */     } 
/*     */     
/* 325 */     this.collationIndex = 33;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Field(MySQLConnection conn, byte[] buffer, int nameStart, int nameLength, int tableNameStart, int tableNameLength, int length, int mysqlType, short colFlag, int colDecimals) throws SQLException {
/* 333 */     this(conn, buffer, -1, -1, tableNameStart, tableNameLength, -1, -1, nameStart, nameLength, -1, -1, length, mysqlType, colFlag, colDecimals, -1, -1, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Field(String tableName, String columnName, int jdbcType, int length) {
/* 341 */     this.tableName = tableName;
/* 342 */     this.name = columnName;
/* 343 */     this.length = length;
/* 344 */     this.sqlType = jdbcType;
/* 345 */     this.colFlag = 0;
/* 346 */     this.colDecimals = 0;
/* 347 */     this.valueNeedsQuoting = determineNeedsQuoting();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Field(String tableName, String columnName, int charsetIndex, int jdbcType, int length) {
/* 367 */     this.tableName = tableName;
/* 368 */     this.name = columnName;
/* 369 */     this.length = length;
/* 370 */     this.sqlType = jdbcType;
/* 371 */     this.colFlag = 0;
/* 372 */     this.colDecimals = 0;
/* 373 */     this.collationIndex = charsetIndex;
/* 374 */     this.valueNeedsQuoting = determineNeedsQuoting();
/*     */     
/* 376 */     switch (this.sqlType) {
/*     */       case -3:
/*     */       case -2:
/* 379 */         this.colFlag = (short)(this.colFlag | 0x80);
/* 380 */         this.colFlag = (short)(this.colFlag | 0x10);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkForImplicitTemporaryTable() {
/* 386 */     this.isImplicitTempTable = (this.tableNameLength > 5 && this.buffer[this.tableNameStart] == 35 && this.buffer[this.tableNameStart + 1] == 115 && this.buffer[this.tableNameStart + 2] == 113 && this.buffer[this.tableNameStart + 3] == 108 && this.buffer[this.tableNameStart + 4] == 95);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() throws SQLException {
/* 397 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(String javaEncodingName, Connection conn) throws SQLException {
/* 401 */     this.encoding = javaEncodingName;
/*     */     try {
/* 403 */       this.collationIndex = CharsetMapping.getCollationIndexForJavaEncoding(javaEncodingName, conn);
/* 404 */     } catch (RuntimeException ex) {
/* 405 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 406 */       sqlEx.initCause(ex);
/* 407 */       throw sqlEx;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized String getCollation() throws SQLException {
/* 412 */     if (this.collationName == null && 
/* 413 */       this.connection != null && 
/* 414 */       this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 415 */       if (this.connection.getUseDynamicCharsetInfo()) {
/* 416 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*     */         
/* 418 */         String quotedIdStr = dbmd.getIdentifierQuoteString();
/*     */         
/* 420 */         if (" ".equals(quotedIdStr)) {
/* 421 */           quotedIdStr = "";
/*     */         }
/*     */         
/* 424 */         String csCatalogName = getDatabaseName();
/* 425 */         String csTableName = getOriginalTableName();
/* 426 */         String csColumnName = getOriginalName();
/*     */         
/* 428 */         if (csCatalogName != null && csCatalogName.length() != 0 && csTableName != null && csTableName.length() != 0 && csColumnName != null && csColumnName.length() != 0) {
/*     */           
/* 430 */           StringBuilder queryBuf = new StringBuilder(csCatalogName.length() + csTableName.length() + 28);
/* 431 */           queryBuf.append("SHOW FULL COLUMNS FROM ");
/* 432 */           queryBuf.append(quotedIdStr);
/* 433 */           queryBuf.append(csCatalogName);
/* 434 */           queryBuf.append(quotedIdStr);
/* 435 */           queryBuf.append(".");
/* 436 */           queryBuf.append(quotedIdStr);
/* 437 */           queryBuf.append(csTableName);
/* 438 */           queryBuf.append(quotedIdStr);
/*     */           
/* 440 */           Statement collationStmt = null;
/* 441 */           ResultSet collationRs = null;
/*     */           
/*     */           try {
/* 444 */             collationStmt = this.connection.createStatement();
/*     */             
/* 446 */             collationRs = collationStmt.executeQuery(queryBuf.toString());
/*     */             
/* 448 */             while (collationRs.next()) {
/* 449 */               if (csColumnName.equals(collationRs.getString("Field"))) {
/* 450 */                 this.collationName = collationRs.getString("Collation");
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } finally {
/* 456 */             if (collationRs != null) {
/* 457 */               collationRs.close();
/* 458 */               collationRs = null;
/*     */             } 
/*     */             
/* 461 */             if (collationStmt != null) {
/* 462 */               collationStmt.close();
/* 463 */               collationStmt = null;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         try {
/* 469 */           this.collationName = CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[this.collationIndex];
/* 470 */         } catch (RuntimeException ex) {
/* 471 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", (ExceptionInterceptor)null);
/* 472 */           sqlEx.initCause(ex);
/* 473 */           throw sqlEx;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 480 */     return this.collationName;
/*     */   }
/*     */   
/*     */   public String getColumnLabel() throws SQLException {
/* 484 */     return getName();
/*     */   }
/*     */   
/*     */   public String getDatabaseName() throws SQLException {
/* 488 */     if (this.databaseName == null && this.databaseNameStart != -1 && this.databaseNameLength != -1) {
/* 489 */       this.databaseName = getStringFromBytes(this.databaseNameStart, this.databaseNameLength);
/*     */     }
/*     */     
/* 492 */     return this.databaseName;
/*     */   }
/*     */   
/*     */   int getDecimals() {
/* 496 */     return this.colDecimals;
/*     */   }
/*     */   
/*     */   public String getFullName() throws SQLException {
/* 500 */     if (this.fullName == null) {
/* 501 */       StringBuilder fullNameBuf = new StringBuilder(getTableName().length() + 1 + getName().length());
/* 502 */       fullNameBuf.append(this.tableName);
/*     */ 
/*     */       
/* 505 */       fullNameBuf.append('.');
/* 506 */       fullNameBuf.append(this.name);
/* 507 */       this.fullName = fullNameBuf.toString();
/* 508 */       fullNameBuf = null;
/*     */     } 
/*     */     
/* 511 */     return this.fullName;
/*     */   }
/*     */   
/*     */   public String getFullOriginalName() throws SQLException {
/* 515 */     getOriginalName();
/*     */     
/* 517 */     if (this.originalColumnName == null) {
/* 518 */       return null;
/*     */     }
/*     */     
/* 521 */     if (this.fullName == null) {
/* 522 */       StringBuilder fullOriginalNameBuf = new StringBuilder(getOriginalTableName().length() + 1 + getOriginalName().length());
/* 523 */       fullOriginalNameBuf.append(this.originalTableName);
/*     */ 
/*     */       
/* 526 */       fullOriginalNameBuf.append('.');
/* 527 */       fullOriginalNameBuf.append(this.originalColumnName);
/* 528 */       this.fullOriginalName = fullOriginalNameBuf.toString();
/* 529 */       fullOriginalNameBuf = null;
/*     */     } 
/*     */     
/* 532 */     return this.fullOriginalName;
/*     */   }
/*     */   
/*     */   public long getLength() {
/* 536 */     return this.length;
/*     */   }
/*     */   
/*     */   public synchronized int getMaxBytesPerCharacter() throws SQLException {
/* 540 */     if (this.maxBytesPerChar == 0) {
/* 541 */       this.maxBytesPerChar = this.connection.getMaxBytesPerChar(Integer.valueOf(this.collationIndex), getEncoding());
/*     */     }
/* 543 */     return this.maxBytesPerChar;
/*     */   }
/*     */   
/*     */   public int getMysqlType() {
/* 547 */     return this.mysqlType;
/*     */   }
/*     */   
/*     */   public String getName() throws SQLException {
/* 551 */     if (this.name == null) {
/* 552 */       this.name = getStringFromBytes(this.nameStart, this.nameLength);
/*     */     }
/*     */     
/* 555 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getNameNoAliases() throws SQLException {
/* 559 */     if (this.useOldNameMetadata) {
/* 560 */       return getName();
/*     */     }
/*     */     
/* 563 */     if (this.connection != null && this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 564 */       return getOriginalName();
/*     */     }
/*     */     
/* 567 */     return getName();
/*     */   }
/*     */   
/*     */   public String getOriginalName() throws SQLException {
/* 571 */     if (this.originalColumnName == null && this.originalColumnNameStart != -1 && this.originalColumnNameLength != -1) {
/* 572 */       this.originalColumnName = getStringFromBytes(this.originalColumnNameStart, this.originalColumnNameLength);
/*     */     }
/*     */     
/* 575 */     return this.originalColumnName;
/*     */   }
/*     */   
/*     */   public String getOriginalTableName() throws SQLException {
/* 579 */     if (this.originalTableName == null && this.originalTableNameStart != -1 && this.originalTableNameLength != -1) {
/* 580 */       this.originalTableName = getStringFromBytes(this.originalTableNameStart, this.originalTableNameLength);
/*     */     }
/*     */     
/* 583 */     return this.originalTableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecisionAdjustFactor() {
/* 595 */     return this.precisionAdjustFactor;
/*     */   }
/*     */   
/*     */   public int getSQLType() {
/* 599 */     return this.sqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getStringFromBytes(int stringStart, int stringLength) throws SQLException {
/* 607 */     if (stringStart == -1 || stringLength == -1) {
/* 608 */       return null;
/*     */     }
/*     */     
/* 611 */     if (stringLength == 0) {
/* 612 */       return "";
/*     */     }
/*     */     
/* 615 */     String stringVal = null;
/*     */     
/* 617 */     if (this.connection != null) {
/* 618 */       if (this.connection.getUseUnicode()) {
/* 619 */         String javaEncoding = this.connection.getCharacterSetMetadata();
/*     */         
/* 621 */         if (javaEncoding == null) {
/* 622 */           javaEncoding = this.connection.getEncoding();
/*     */         }
/*     */         
/* 625 */         if (javaEncoding != null) {
/* 626 */           SingleByteCharsetConverter converter = null;
/*     */           
/* 628 */           if (this.connection != null) {
/* 629 */             converter = this.connection.getCharsetConverter(javaEncoding);
/*     */           }
/*     */           
/* 632 */           if (converter != null) {
/* 633 */             stringVal = converter.toString(this.buffer, stringStart, stringLength);
/*     */           } else {
/*     */             
/*     */             try {
/* 637 */               stringVal = StringUtils.toString(this.buffer, stringStart, stringLength, javaEncoding);
/* 638 */             } catch (UnsupportedEncodingException ue) {
/* 639 */               throw new RuntimeException(Messages.getString("Field.12") + javaEncoding + Messages.getString("Field.13"));
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 644 */           stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*     */         } 
/*     */       } else {
/*     */         
/* 648 */         stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*     */       } 
/*     */     } else {
/*     */       
/* 652 */       stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*     */     } 
/*     */     
/* 655 */     return stringVal;
/*     */   }
/*     */   
/*     */   public String getTable() throws SQLException {
/* 659 */     return getTableName();
/*     */   }
/*     */   
/*     */   public String getTableName() throws SQLException {
/* 663 */     if (this.tableName == null) {
/* 664 */       this.tableName = getStringFromBytes(this.tableNameStart, this.tableNameLength);
/*     */     }
/*     */     
/* 667 */     return this.tableName;
/*     */   }
/*     */   
/*     */   public String getTableNameNoAliases() throws SQLException {
/* 671 */     if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 672 */       return getOriginalTableName();
/*     */     }
/*     */     
/* 675 */     return getTableName();
/*     */   }
/*     */   
/*     */   public boolean isAutoIncrement() {
/* 679 */     return ((this.colFlag & 0x200) > 0);
/*     */   }
/*     */   
/*     */   public boolean isBinary() {
/* 683 */     return ((this.colFlag & 0x80) > 0);
/*     */   }
/*     */   
/*     */   public boolean isBlob() {
/* 687 */     return ((this.colFlag & 0x10) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isImplicitTemporaryTable() {
/* 694 */     return this.isImplicitTempTable;
/*     */   }
/*     */   
/*     */   public boolean isMultipleKey() {
/* 698 */     return ((this.colFlag & 0x8) > 0);
/*     */   }
/*     */   
/*     */   boolean isNotNull() {
/* 702 */     return ((this.colFlag & 0x1) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpaqueBinary() throws SQLException {
/* 711 */     if (this.collationIndex == 63 && isBinary() && (getMysqlType() == 254 || getMysqlType() == 253)) {
/*     */ 
/*     */       
/* 714 */       if (this.originalTableNameLength == 0 && this.connection != null && !this.connection.versionMeetsMinimum(5, 0, 25)) {
/* 715 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 720 */       return !isImplicitTemporaryTable();
/*     */     } 
/*     */     
/* 723 */     return (this.connection.versionMeetsMinimum(4, 1, 0) && "binary".equalsIgnoreCase(getEncoding()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimaryKey() {
/* 728 */     return ((this.colFlag & 0x2) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isReadOnly() throws SQLException {
/* 738 */     if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 739 */       String orgColumnName = getOriginalName();
/* 740 */       String orgTableName = getOriginalTableName();
/*     */       
/* 742 */       return (orgColumnName == null || orgColumnName.length() <= 0 || orgTableName == null || orgTableName.length() <= 0);
/*     */     } 
/*     */     
/* 745 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isUniqueKey() {
/* 749 */     return ((this.colFlag & 0x4) > 0);
/*     */   }
/*     */   
/*     */   public boolean isUnsigned() {
/* 753 */     return ((this.colFlag & 0x20) > 0);
/*     */   }
/*     */   
/*     */   public void setUnsigned() {
/* 757 */     this.colFlag = (short)(this.colFlag | 0x20);
/*     */   }
/*     */   
/*     */   public boolean isZeroFill() {
/* 761 */     return ((this.colFlag & 0x40) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setBlobTypeBasedOnLength() {
/* 769 */     if (this.length == 255L) {
/* 770 */       this.mysqlType = 249;
/* 771 */     } else if (this.length == 65535L) {
/* 772 */       this.mysqlType = 252;
/* 773 */     } else if (this.length == 16777215L) {
/* 774 */       this.mysqlType = 250;
/* 775 */     } else if (this.length == 4294967295L) {
/* 776 */       this.mysqlType = 251;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNativeNumericType() {
/* 781 */     return ((this.mysqlType >= 1 && this.mysqlType <= 5) || this.mysqlType == 8 || this.mysqlType == 13);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isNativeDateTimeType() {
/* 786 */     return (this.mysqlType == 10 || this.mysqlType == 14 || this.mysqlType == 12 || this.mysqlType == 11 || this.mysqlType == 7);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCharsetApplicableType() {
/* 791 */     return (this.mysqlType == 247 || this.mysqlType == 245 || this.mysqlType == 248 || this.mysqlType == 254 || this.mysqlType == 253 || this.mysqlType == 15);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnection(MySQLConnection conn) {
/* 797 */     this.connection = conn;
/*     */     
/* 799 */     if (this.encoding == null || this.collationIndex == 0) {
/* 800 */       this.encoding = this.connection.getEncoding();
/*     */     }
/*     */   }
/*     */   
/*     */   void setMysqlType(int type) {
/* 805 */     this.mysqlType = type;
/* 806 */     this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*     */   }
/*     */   
/*     */   protected void setUseOldNameMetadata(boolean useOldNameMetadata) {
/* 810 */     this.useOldNameMetadata = useOldNameMetadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     try {
/* 816 */       StringBuilder asString = new StringBuilder();
/* 817 */       asString.append(super.toString());
/* 818 */       asString.append("[");
/* 819 */       asString.append("catalog=");
/* 820 */       asString.append(getDatabaseName());
/* 821 */       asString.append(",tableName=");
/* 822 */       asString.append(getTableName());
/* 823 */       asString.append(",originalTableName=");
/* 824 */       asString.append(getOriginalTableName());
/* 825 */       asString.append(",columnName=");
/* 826 */       asString.append(getName());
/* 827 */       asString.append(",originalColumnName=");
/* 828 */       asString.append(getOriginalName());
/* 829 */       asString.append(",mysqlType=");
/* 830 */       asString.append(getMysqlType());
/* 831 */       asString.append("(");
/* 832 */       asString.append(MysqlDefs.typeToName(getMysqlType()));
/* 833 */       asString.append(")");
/* 834 */       asString.append(",flags=");
/*     */       
/* 836 */       if (isAutoIncrement()) {
/* 837 */         asString.append(" AUTO_INCREMENT");
/*     */       }
/*     */       
/* 840 */       if (isPrimaryKey()) {
/* 841 */         asString.append(" PRIMARY_KEY");
/*     */       }
/*     */       
/* 844 */       if (isUniqueKey()) {
/* 845 */         asString.append(" UNIQUE_KEY");
/*     */       }
/*     */       
/* 848 */       if (isBinary()) {
/* 849 */         asString.append(" BINARY");
/*     */       }
/*     */       
/* 852 */       if (isBlob()) {
/* 853 */         asString.append(" BLOB");
/*     */       }
/*     */       
/* 856 */       if (isMultipleKey()) {
/* 857 */         asString.append(" MULTI_KEY");
/*     */       }
/*     */       
/* 860 */       if (isUnsigned()) {
/* 861 */         asString.append(" UNSIGNED");
/*     */       }
/*     */       
/* 864 */       if (isZeroFill()) {
/* 865 */         asString.append(" ZEROFILL");
/*     */       }
/*     */       
/* 868 */       asString.append(", charsetIndex=");
/* 869 */       asString.append(this.collationIndex);
/* 870 */       asString.append(", charsetName=");
/* 871 */       asString.append(this.encoding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 879 */       asString.append("]");
/*     */       
/* 881 */       return asString.toString();
/* 882 */     } catch (Throwable t) {
/* 883 */       return super.toString();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean isSingleBit() {
/* 888 */     return this.isSingleBit;
/*     */   }
/*     */   
/*     */   protected boolean getvalueNeedsQuoting() {
/* 892 */     return this.valueNeedsQuoting;
/*     */   }
/*     */   
/*     */   private boolean determineNeedsQuoting() {
/* 896 */     boolean retVal = false;
/*     */     
/* 898 */     switch (this.sqlType)
/*     */     { case -7:
/*     */       case -6:
/*     */       case -5:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/* 909 */         retVal = false;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 914 */         return retVal; }  retVal = true; return retVal;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\Field.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */