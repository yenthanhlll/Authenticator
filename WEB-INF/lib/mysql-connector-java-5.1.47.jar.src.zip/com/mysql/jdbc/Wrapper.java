package com.mysql.jdbc;

import java.sql.SQLException;

public interface Wrapper {
  <T> T unwrap(Class<T> paramClass) throws SQLException;
  
  boolean isWrapperFor(Class<?> paramClass) throws SQLException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\Wrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */