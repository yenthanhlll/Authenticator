package com.mysql.jdbc.exceptions;

public interface DeadlockTimeoutRollbackMarker {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\exceptions\DeadlockTimeoutRollbackMarker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */