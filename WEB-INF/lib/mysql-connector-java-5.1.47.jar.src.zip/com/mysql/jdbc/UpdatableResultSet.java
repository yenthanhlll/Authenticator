/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UpdatableResultSet
/*      */   extends ResultSetImpl
/*      */ {
/*   42 */   static final byte[] STREAM_DATA_MARKER = StringUtils.getBytes("** STREAM DATA **");
/*      */ 
/*      */   
/*      */   protected SingleByteCharsetConverter charConverter;
/*      */ 
/*      */   
/*      */   private String charEncoding;
/*      */   
/*      */   private byte[][] defaultColumnValue;
/*      */   
/*   52 */   private PreparedStatement deleter = null;
/*      */   
/*   54 */   private String deleteSQL = null;
/*      */ 
/*      */   
/*      */   private boolean initializedCharConverter = false;
/*      */   
/*   59 */   protected PreparedStatement inserter = null;
/*      */   
/*   61 */   private String insertSQL = null;
/*      */ 
/*      */   
/*      */   private boolean isUpdatable = false;
/*      */ 
/*      */   
/*   67 */   private String notUpdatableReason = null;
/*      */ 
/*      */   
/*   70 */   private List<Integer> primaryKeyIndicies = null;
/*      */   
/*      */   private String qualifiedAndQuotedTableName;
/*      */   
/*   74 */   private String quotedIdChar = null;
/*      */ 
/*      */   
/*      */   private PreparedStatement refresher;
/*      */   
/*   79 */   private String refreshSQL = null;
/*      */ 
/*      */   
/*      */   private ResultSetRow savedCurrentRow;
/*      */ 
/*      */   
/*   85 */   protected PreparedStatement updater = null;
/*      */ 
/*      */   
/*   88 */   private String updateSQL = null;
/*      */   
/*      */   private boolean populateInserterWithDefaultValues = false;
/*      */   
/*   92 */   private Map<String, Map<String, Map<String, Integer>>> databasesUsedToTablesUsed = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected UpdatableResultSet(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt) throws SQLException {
/*  110 */     super(catalog, fields, tuples, conn, creatorStmt);
/*  111 */     checkUpdatability();
/*  112 */     this.populateInserterWithDefaultValues = this.connection.getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int row) throws SQLException {
/*  149 */     return super.absolute(row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*  165 */     super.afterLast();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*  181 */     super.beforeFirst();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/*  196 */     synchronized (checkClosed().getConnectionMutex()) {
/*  197 */       if (this.doingUpdates) {
/*  198 */         this.doingUpdates = false;
/*  199 */         this.updater.clearParameters();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkRowPos() throws SQLException {
/*  211 */     synchronized (checkClosed().getConnectionMutex()) {
/*  212 */       if (!this.onInsertRow) {
/*  213 */         super.checkRowPos();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkUpdatability() throws SQLException {
/*      */     try {
/*  225 */       if (this.fields == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  232 */       String singleTableName = null;
/*  233 */       String catalogName = null;
/*      */       
/*  235 */       int primaryKeyCount = 0;
/*      */ 
/*      */ 
/*      */       
/*  239 */       if (this.catalog == null || this.catalog.length() == 0) {
/*  240 */         this.catalog = this.fields[0].getDatabaseName();
/*      */         
/*  242 */         if (this.catalog == null || this.catalog.length() == 0) {
/*  243 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  248 */       if (this.fields.length > 0) {
/*  249 */         singleTableName = this.fields[0].getOriginalTableName();
/*  250 */         catalogName = this.fields[0].getDatabaseName();
/*      */         
/*  252 */         if (singleTableName == null) {
/*  253 */           singleTableName = this.fields[0].getTableName();
/*  254 */           catalogName = this.catalog;
/*      */         } 
/*      */         
/*  257 */         if (singleTableName != null && singleTableName.length() == 0) {
/*  258 */           this.isUpdatable = false;
/*  259 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  264 */         if (this.fields[0].isPrimaryKey()) {
/*  265 */           primaryKeyCount++;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  271 */         for (int i = 1; i < this.fields.length; i++) {
/*  272 */           String otherTableName = this.fields[i].getOriginalTableName();
/*  273 */           String otherCatalogName = this.fields[i].getDatabaseName();
/*      */           
/*  275 */           if (otherTableName == null) {
/*  276 */             otherTableName = this.fields[i].getTableName();
/*  277 */             otherCatalogName = this.catalog;
/*      */           } 
/*      */           
/*  280 */           if (otherTableName != null && otherTableName.length() == 0) {
/*  281 */             this.isUpdatable = false;
/*  282 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  287 */           if (singleTableName == null || !otherTableName.equals(singleTableName)) {
/*  288 */             this.isUpdatable = false;
/*  289 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.0");
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  295 */           if (catalogName == null || !otherCatalogName.equals(catalogName)) {
/*  296 */             this.isUpdatable = false;
/*  297 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.1");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  302 */           if (this.fields[i].isPrimaryKey()) {
/*  303 */             primaryKeyCount++;
/*      */           }
/*      */         } 
/*      */         
/*  307 */         if (singleTableName == null || singleTableName.length() == 0) {
/*  308 */           this.isUpdatable = false;
/*  309 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.2");
/*      */           
/*      */           return;
/*      */         } 
/*      */       } else {
/*  314 */         this.isUpdatable = false;
/*  315 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  320 */       if (this.connection.getStrictUpdates()) {
/*  321 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*  323 */         ResultSet rs = null;
/*  324 */         HashMap<String, String> primaryKeyNames = new HashMap<String, String>();
/*      */         
/*      */         try {
/*  327 */           rs = dbmd.getPrimaryKeys(catalogName, null, singleTableName);
/*      */           
/*  329 */           while (rs.next()) {
/*  330 */             String keyName = rs.getString(4);
/*  331 */             keyName = keyName.toUpperCase();
/*  332 */             primaryKeyNames.put(keyName, keyName);
/*      */           } 
/*      */         } finally {
/*  335 */           if (rs != null) {
/*      */             try {
/*  337 */               rs.close();
/*  338 */             } catch (Exception ex) {
/*  339 */               AssertionFailedException.shouldNotHappen(ex);
/*      */             } 
/*      */             
/*  342 */             rs = null;
/*      */           } 
/*      */         } 
/*      */         
/*  346 */         int existingPrimaryKeysCount = primaryKeyNames.size();
/*      */         
/*  348 */         if (existingPrimaryKeysCount == 0) {
/*  349 */           this.isUpdatable = false;
/*  350 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.5");
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */         
/*  358 */         for (int i = 0; i < this.fields.length; i++) {
/*  359 */           if (this.fields[i].isPrimaryKey()) {
/*  360 */             String columnNameUC = this.fields[i].getName().toUpperCase();
/*      */             
/*  362 */             if (primaryKeyNames.remove(columnNameUC) == null) {
/*      */               
/*  364 */               String originalName = this.fields[i].getOriginalName();
/*      */               
/*  366 */               if (originalName != null && 
/*  367 */                 primaryKeyNames.remove(originalName.toUpperCase()) == null) {
/*      */                 
/*  369 */                 this.isUpdatable = false;
/*  370 */                 this.notUpdatableReason = Messages.getString("NotUpdatableReason.6", new Object[] { originalName });
/*      */ 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  379 */         this.isUpdatable = primaryKeyNames.isEmpty();
/*      */         
/*  381 */         if (!this.isUpdatable) {
/*  382 */           if (existingPrimaryKeysCount > 1) {
/*  383 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.7");
/*      */           } else {
/*  385 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  395 */       if (primaryKeyCount == 0) {
/*  396 */         this.isUpdatable = false;
/*  397 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  402 */       this.isUpdatable = true;
/*  403 */       this.notUpdatableReason = null;
/*      */       
/*      */       return;
/*  406 */     } catch (SQLException sqlEx) {
/*  407 */       this.isUpdatable = false;
/*  408 */       this.notUpdatableReason = sqlEx.getMessage();
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/*  424 */     synchronized (checkClosed().getConnectionMutex()) {
/*  425 */       if (!this.isUpdatable) {
/*  426 */         throw new NotUpdatable(this.notUpdatableReason);
/*      */       }
/*      */       
/*  429 */       if (this.onInsertRow)
/*  430 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"), getExceptionInterceptor()); 
/*  431 */       if (this.rowData.size() == 0)
/*  432 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"), getExceptionInterceptor()); 
/*  433 */       if (isBeforeFirst())
/*  434 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"), getExceptionInterceptor()); 
/*  435 */       if (isAfterLast()) {
/*  436 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"), getExceptionInterceptor());
/*      */       }
/*      */       
/*  439 */       if (this.deleter == null) {
/*  440 */         if (this.deleteSQL == null) {
/*  441 */           generateStatements();
/*      */         }
/*      */         
/*  444 */         this.deleter = (PreparedStatement)this.connection.clientPrepareStatement(this.deleteSQL);
/*      */       } 
/*      */       
/*  447 */       this.deleter.clearParameters();
/*      */       
/*  449 */       int numKeys = this.primaryKeyIndicies.size();
/*  450 */       for (int i = 0; i < numKeys; i++) {
/*  451 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*  452 */         setParamValue(this.deleter, i + 1, this.thisRow, index, this.fields[index]);
/*      */       } 
/*      */       
/*  455 */       this.deleter.executeUpdate();
/*  456 */       this.rowData.removeRow(this.rowData.getCurrentRowNumber());
/*      */ 
/*      */       
/*  459 */       previous();
/*      */     } 
/*      */   } private void setParamValue(PreparedStatement ps, int psIdx, ResultSetRow row, int rsIdx, Field field) throws SQLException {
/*      */     Field f;
/*      */     boolean useGmtMillis, useJdbcCompliantTimezoneShift;
/*  464 */     byte[] val = row.getColumnValue(rsIdx);
/*  465 */     if (val == null) {
/*  466 */       ps.setNull(psIdx, 0);
/*      */       return;
/*      */     } 
/*  469 */     switch (field.getSQLType()) {
/*      */       case 0:
/*  471 */         ps.setNull(psIdx, 0);
/*      */         return;
/*      */       case -6:
/*      */       case 4:
/*      */       case 5:
/*  476 */         ps.setInt(psIdx, row.getInt(rsIdx));
/*      */         return;
/*      */       case -5:
/*  479 */         ps.setLong(psIdx, row.getLong(rsIdx));
/*      */         return;
/*      */       case -1:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 12:
/*  486 */         f = this.fields[rsIdx];
/*  487 */         ps.setString(psIdx, row.getString(rsIdx, f.getEncoding(), this.connection));
/*      */         return;
/*      */       case 91:
/*  490 */         ps.setDate(psIdx, row.getDateFast(rsIdx, this.connection, this, this.fastDefaultCal), this.fastDefaultCal);
/*      */         return;
/*      */       case 93:
/*  493 */         useGmtMillis = false;
/*  494 */         useJdbcCompliantTimezoneShift = false;
/*  495 */         ps.setTimestampInternal(psIdx, row.getTimestampFast(rsIdx, this.fastDefaultCal, this.connection.getServerTimezoneTZ(), false, this.connection, this, useGmtMillis, useJdbcCompliantTimezoneShift), (Calendar)null, this.connection.getDefaultTimeZone(), false, field.getDecimals(), false);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 92:
/*  500 */         ps.setTime(psIdx, row.getTimeFast(rsIdx, this.fastDefaultCal, this.connection.getServerTimezoneTZ(), false, this.connection, this));
/*      */         return;
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 16:
/*  506 */         ps.setBytesNoEscapeNoQuotes(psIdx, val);
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  514 */     ps.setBytes(psIdx, val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void extractDefaultValues() throws SQLException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield connection : Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: invokeinterface getMetaData : ()Ljava/sql/DatabaseMetaData;
/*      */     //   9: astore_1
/*      */     //   10: aload_0
/*      */     //   11: aload_0
/*      */     //   12: getfield fields : [Lcom/mysql/jdbc/Field;
/*      */     //   15: arraylength
/*      */     //   16: anewarray [B
/*      */     //   19: putfield defaultColumnValue : [[B
/*      */     //   22: aconst_null
/*      */     //   23: astore_2
/*      */     //   24: aload_0
/*      */     //   25: getfield databasesUsedToTablesUsed : Ljava/util/Map;
/*      */     //   28: invokeinterface entrySet : ()Ljava/util/Set;
/*      */     //   33: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   38: astore_3
/*      */     //   39: aload_3
/*      */     //   40: invokeinterface hasNext : ()Z
/*      */     //   45: ifeq -> 249
/*      */     //   48: aload_3
/*      */     //   49: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   54: checkcast java/util/Map$Entry
/*      */     //   57: astore #4
/*      */     //   59: aload #4
/*      */     //   61: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   66: checkcast java/util/Map
/*      */     //   69: invokeinterface entrySet : ()Ljava/util/Set;
/*      */     //   74: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   79: astore #5
/*      */     //   81: aload #5
/*      */     //   83: invokeinterface hasNext : ()Z
/*      */     //   88: ifeq -> 246
/*      */     //   91: aload #5
/*      */     //   93: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   98: checkcast java/util/Map$Entry
/*      */     //   101: astore #6
/*      */     //   103: aload #6
/*      */     //   105: invokeinterface getKey : ()Ljava/lang/Object;
/*      */     //   110: checkcast java/lang/String
/*      */     //   113: astore #7
/*      */     //   115: aload #6
/*      */     //   117: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   122: checkcast java/util/Map
/*      */     //   125: astore #8
/*      */     //   127: aload_1
/*      */     //   128: aload_0
/*      */     //   129: getfield catalog : Ljava/lang/String;
/*      */     //   132: aconst_null
/*      */     //   133: aload #7
/*      */     //   135: ldc '%'
/*      */     //   137: invokeinterface getColumns : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */     //   142: astore_2
/*      */     //   143: aload_2
/*      */     //   144: invokeinterface next : ()Z
/*      */     //   149: ifeq -> 213
/*      */     //   152: aload_2
/*      */     //   153: ldc 'COLUMN_NAME'
/*      */     //   155: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   160: astore #9
/*      */     //   162: aload_2
/*      */     //   163: ldc 'COLUMN_DEF'
/*      */     //   165: invokeinterface getBytes : (Ljava/lang/String;)[B
/*      */     //   170: astore #10
/*      */     //   172: aload #8
/*      */     //   174: aload #9
/*      */     //   176: invokeinterface containsKey : (Ljava/lang/Object;)Z
/*      */     //   181: ifeq -> 210
/*      */     //   184: aload #8
/*      */     //   186: aload #9
/*      */     //   188: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   193: checkcast java/lang/Integer
/*      */     //   196: invokevirtual intValue : ()I
/*      */     //   199: istore #11
/*      */     //   201: aload_0
/*      */     //   202: getfield defaultColumnValue : [[B
/*      */     //   205: iload #11
/*      */     //   207: aload #10
/*      */     //   209: aastore
/*      */     //   210: goto -> 143
/*      */     //   213: jsr -> 227
/*      */     //   216: goto -> 243
/*      */     //   219: astore #12
/*      */     //   221: jsr -> 227
/*      */     //   224: aload #12
/*      */     //   226: athrow
/*      */     //   227: astore #13
/*      */     //   229: aload_2
/*      */     //   230: ifnull -> 241
/*      */     //   233: aload_2
/*      */     //   234: invokeinterface close : ()V
/*      */     //   239: aconst_null
/*      */     //   240: astore_2
/*      */     //   241: ret #13
/*      */     //   243: goto -> 81
/*      */     //   246: goto -> 39
/*      */     //   249: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #521	-> 0
/*      */     //   #522	-> 10
/*      */     //   #524	-> 22
/*      */     //   #526	-> 24
/*      */     //   #528	-> 59
/*      */     //   #529	-> 103
/*      */     //   #530	-> 115
/*      */     //   #533	-> 127
/*      */     //   #535	-> 143
/*      */     //   #536	-> 152
/*      */     //   #537	-> 162
/*      */     //   #539	-> 172
/*      */     //   #540	-> 184
/*      */     //   #542	-> 201
/*      */     //   #544	-> 210
/*      */     //   #545	-> 213
/*      */     //   #551	-> 216
/*      */     //   #546	-> 219
/*      */     //   #547	-> 233
/*      */     //   #549	-> 239
/*      */     //   #552	-> 243
/*      */     //   #554	-> 249
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   201	9	11	localColumnIndex	I
/*      */     //   162	48	9	columnName	Ljava/lang/String;
/*      */     //   172	38	10	defaultValue	[B
/*      */     //   115	128	7	tableName	Ljava/lang/String;
/*      */     //   127	116	8	columnNamesToIndices	Ljava/util/Map;
/*      */     //   103	140	6	tableEntry	Ljava/util/Map$Entry;
/*      */     //   81	165	5	i$	Ljava/util/Iterator;
/*      */     //   59	187	4	dbEntry	Ljava/util/Map$Entry;
/*      */     //   39	210	3	i$	Ljava/util/Iterator;
/*      */     //   0	250	0	this	Lcom/mysql/jdbc/UpdatableResultSet;
/*      */     //   10	240	1	dbmd	Ljava/sql/DatabaseMetaData;
/*      */     //   24	226	2	columnsResultSet	Ljava/sql/ResultSet;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   127	116	8	columnNamesToIndices	Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;
/*      */     //   103	140	6	tableEntry	Ljava/util/Map$Entry<Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;
/*      */     //   59	187	4	dbEntry	Ljava/util/Map$Entry<Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;>;>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   127	216	219	finally
/*      */     //   219	224	219	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/*  571 */     return super.first();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateStatements() throws SQLException {
/*  582 */     if (!this.isUpdatable) {
/*  583 */       this.doingUpdates = false;
/*  584 */       this.onInsertRow = false;
/*      */       
/*  586 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     } 
/*      */     
/*  589 */     String quotedId = getQuotedIdChar();
/*      */     
/*  591 */     Map<String, String> tableNamesSoFar = null;
/*      */     
/*  593 */     if (this.connection.lowerCaseTableNames()) {
/*  594 */       tableNamesSoFar = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
/*  595 */       this.databasesUsedToTablesUsed = new TreeMap<String, Map<String, Map<String, Integer>>>(String.CASE_INSENSITIVE_ORDER);
/*      */     } else {
/*  597 */       tableNamesSoFar = new TreeMap<String, String>();
/*  598 */       this.databasesUsedToTablesUsed = new TreeMap<String, Map<String, Map<String, Integer>>>();
/*      */     } 
/*      */     
/*  601 */     this.primaryKeyIndicies = new ArrayList<Integer>();
/*      */     
/*  603 */     StringBuilder fieldValues = new StringBuilder();
/*  604 */     StringBuilder keyValues = new StringBuilder();
/*  605 */     StringBuilder columnNames = new StringBuilder();
/*  606 */     StringBuilder insertPlaceHolders = new StringBuilder();
/*  607 */     StringBuilder allTablesBuf = new StringBuilder();
/*  608 */     Map<Integer, String> columnIndicesToTable = new HashMap<Integer, String>();
/*      */     
/*  610 */     boolean firstTime = true;
/*  611 */     boolean keysFirstTime = true;
/*      */     
/*  613 */     String equalsStr = this.connection.versionMeetsMinimum(3, 23, 0) ? "<=>" : "=";
/*      */     
/*  615 */     for (int i = 0; i < this.fields.length; i++) {
/*  616 */       StringBuilder tableNameBuffer = new StringBuilder();
/*  617 */       Map<String, Integer> updColumnNameToIndex = null;
/*      */ 
/*      */       
/*  620 */       if (this.fields[i].getOriginalTableName() != null) {
/*      */         
/*  622 */         String str1 = this.fields[i].getDatabaseName();
/*      */         
/*  624 */         if (str1 != null && str1.length() > 0) {
/*  625 */           tableNameBuffer.append(quotedId);
/*  626 */           tableNameBuffer.append(str1);
/*  627 */           tableNameBuffer.append(quotedId);
/*  628 */           tableNameBuffer.append('.');
/*      */         } 
/*      */         
/*  631 */         String tableOnlyName = this.fields[i].getOriginalTableName();
/*      */         
/*  633 */         tableNameBuffer.append(quotedId);
/*  634 */         tableNameBuffer.append(tableOnlyName);
/*  635 */         tableNameBuffer.append(quotedId);
/*      */         
/*  637 */         String fqTableName = tableNameBuffer.toString();
/*      */         
/*  639 */         if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  640 */           if (!tableNamesSoFar.isEmpty()) {
/*  641 */             allTablesBuf.append(',');
/*      */           }
/*      */           
/*  644 */           allTablesBuf.append(fqTableName);
/*  645 */           tableNamesSoFar.put(fqTableName, fqTableName);
/*      */         } 
/*      */         
/*  648 */         columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */         
/*  650 */         updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(str1, tableOnlyName);
/*      */       } else {
/*  652 */         String tableOnlyName = this.fields[i].getTableName();
/*      */         
/*  654 */         if (tableOnlyName != null) {
/*  655 */           tableNameBuffer.append(quotedId);
/*  656 */           tableNameBuffer.append(tableOnlyName);
/*  657 */           tableNameBuffer.append(quotedId);
/*      */           
/*  659 */           String fqTableName = tableNameBuffer.toString();
/*      */           
/*  661 */           if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  662 */             if (!tableNamesSoFar.isEmpty()) {
/*  663 */               allTablesBuf.append(',');
/*      */             }
/*      */             
/*  666 */             allTablesBuf.append(fqTableName);
/*  667 */             tableNamesSoFar.put(fqTableName, fqTableName);
/*      */           } 
/*      */           
/*  670 */           columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */           
/*  672 */           updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(this.catalog, tableOnlyName);
/*      */         } 
/*      */       } 
/*      */       
/*  676 */       String originalColumnName = this.fields[i].getOriginalName();
/*  677 */       String columnName = null;
/*      */       
/*  679 */       if (this.connection.getIO().hasLongColumnInfo() && originalColumnName != null && originalColumnName.length() > 0) {
/*  680 */         columnName = originalColumnName;
/*      */       } else {
/*  682 */         columnName = this.fields[i].getName();
/*      */       } 
/*      */       
/*  685 */       if (updColumnNameToIndex != null && columnName != null) {
/*  686 */         updColumnNameToIndex.put(columnName, Integer.valueOf(i));
/*      */       }
/*      */       
/*  689 */       String originalTableName = this.fields[i].getOriginalTableName();
/*  690 */       String tableName = null;
/*      */       
/*  692 */       if (this.connection.getIO().hasLongColumnInfo() && originalTableName != null && originalTableName.length() > 0) {
/*  693 */         tableName = originalTableName;
/*      */       } else {
/*  695 */         tableName = this.fields[i].getTableName();
/*      */       } 
/*      */       
/*  698 */       StringBuilder fqcnBuf = new StringBuilder();
/*  699 */       String databaseName = this.fields[i].getDatabaseName();
/*      */       
/*  701 */       if (databaseName != null && databaseName.length() > 0) {
/*  702 */         fqcnBuf.append(quotedId);
/*  703 */         fqcnBuf.append(databaseName);
/*  704 */         fqcnBuf.append(quotedId);
/*  705 */         fqcnBuf.append('.');
/*      */       } 
/*      */       
/*  708 */       fqcnBuf.append(quotedId);
/*  709 */       fqcnBuf.append(tableName);
/*  710 */       fqcnBuf.append(quotedId);
/*  711 */       fqcnBuf.append('.');
/*  712 */       fqcnBuf.append(quotedId);
/*  713 */       fqcnBuf.append(columnName);
/*  714 */       fqcnBuf.append(quotedId);
/*      */       
/*  716 */       String qualifiedColumnName = fqcnBuf.toString();
/*      */       
/*  718 */       if (this.fields[i].isPrimaryKey()) {
/*  719 */         this.primaryKeyIndicies.add(Integer.valueOf(i));
/*      */         
/*  721 */         if (!keysFirstTime) {
/*  722 */           keyValues.append(" AND ");
/*      */         } else {
/*  724 */           keysFirstTime = false;
/*      */         } 
/*      */         
/*  727 */         keyValues.append(qualifiedColumnName);
/*  728 */         keyValues.append(equalsStr);
/*  729 */         keyValues.append("?");
/*      */       } 
/*      */       
/*  732 */       if (firstTime) {
/*  733 */         firstTime = false;
/*  734 */         fieldValues.append("SET ");
/*      */       } else {
/*  736 */         fieldValues.append(",");
/*  737 */         columnNames.append(",");
/*  738 */         insertPlaceHolders.append(",");
/*      */       } 
/*      */       
/*  741 */       insertPlaceHolders.append("?");
/*      */       
/*  743 */       columnNames.append(qualifiedColumnName);
/*      */       
/*  745 */       fieldValues.append(qualifiedColumnName);
/*  746 */       fieldValues.append("=?");
/*      */     } 
/*      */     
/*  749 */     this.qualifiedAndQuotedTableName = allTablesBuf.toString();
/*      */     
/*  751 */     this.updateSQL = "UPDATE " + this.qualifiedAndQuotedTableName + " " + fieldValues.toString() + " WHERE " + keyValues.toString();
/*  752 */     this.insertSQL = "INSERT INTO " + this.qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")";
/*  753 */     this.refreshSQL = "SELECT " + columnNames.toString() + " FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString();
/*  754 */     this.deleteSQL = "DELETE FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private Map<String, Integer> getColumnsToIndexMapForTableAndDB(String databaseName, String tableName) {
/*  759 */     Map<String, Map<String, Integer>> tablesUsedToColumnsMap = this.databasesUsedToTablesUsed.get(databaseName);
/*      */     
/*  761 */     if (tablesUsedToColumnsMap == null) {
/*  762 */       if (this.connection.lowerCaseTableNames()) {
/*  763 */         tablesUsedToColumnsMap = new TreeMap<String, Map<String, Integer>>(String.CASE_INSENSITIVE_ORDER);
/*      */       } else {
/*  765 */         tablesUsedToColumnsMap = new TreeMap<String, Map<String, Integer>>();
/*      */       } 
/*      */       
/*  768 */       this.databasesUsedToTablesUsed.put(databaseName, tablesUsedToColumnsMap);
/*      */     } 
/*      */     
/*  771 */     Map<String, Integer> nameToIndex = tablesUsedToColumnsMap.get(tableName);
/*      */     
/*  773 */     if (nameToIndex == null) {
/*  774 */       nameToIndex = new HashMap<String, Integer>();
/*  775 */       tablesUsedToColumnsMap.put(tableName, nameToIndex);
/*      */     } 
/*      */     
/*  778 */     return nameToIndex;
/*      */   }
/*      */   
/*      */   private SingleByteCharsetConverter getCharConverter() throws SQLException {
/*  782 */     if (!this.initializedCharConverter) {
/*  783 */       this.initializedCharConverter = true;
/*      */       
/*  785 */       if (this.connection.getUseUnicode()) {
/*  786 */         this.charEncoding = this.connection.getEncoding();
/*  787 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       } 
/*      */     } 
/*      */     
/*  791 */     return this.charConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/*  805 */     synchronized (checkClosed().getConnectionMutex()) {
/*  806 */       return this.isUpdatable ? 1008 : 1007;
/*      */     } 
/*      */   }
/*      */   
/*      */   private String getQuotedIdChar() throws SQLException {
/*  811 */     if (this.quotedIdChar == null) {
/*  812 */       boolean useQuotedIdentifiers = this.connection.supportsQuotedIdentifiers();
/*      */       
/*  814 */       if (useQuotedIdentifiers) {
/*  815 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*  816 */         this.quotedIdChar = dbmd.getIdentifierQuoteString();
/*      */       } else {
/*  818 */         this.quotedIdChar = "";
/*      */       } 
/*      */     } 
/*      */     
/*  822 */     return this.quotedIdChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/*  836 */     synchronized (checkClosed().getConnectionMutex()) {
/*  837 */       if (!this.onInsertRow) {
/*  838 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"), getExceptionInterceptor());
/*      */       }
/*      */       
/*  841 */       this.inserter.executeUpdate();
/*      */       
/*  843 */       long autoIncrementId = this.inserter.getLastInsertID();
/*  844 */       int numFields = this.fields.length;
/*  845 */       byte[][] newRow = new byte[numFields][];
/*      */       
/*  847 */       for (int i = 0; i < numFields; i++) {
/*  848 */         if (this.inserter.isNull(i)) {
/*  849 */           newRow[i] = null;
/*      */         } else {
/*  851 */           newRow[i] = this.inserter.getBytesRepresentation(i);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  857 */         if (this.fields[i].isAutoIncrement() && autoIncrementId > 0L) {
/*  858 */           newRow[i] = StringUtils.getBytes(String.valueOf(autoIncrementId));
/*  859 */           this.inserter.setBytesNoEscapeNoQuotes(i + 1, newRow[i]);
/*      */         } 
/*      */       } 
/*      */       
/*  863 */       ResultSetRow resultSetRow = new ByteArrayRow(newRow, getExceptionInterceptor());
/*      */       
/*  865 */       refreshRow(this.inserter, resultSetRow);
/*      */       
/*  867 */       this.rowData.addRow(resultSetRow);
/*  868 */       resetInserter();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/*  887 */     return super.isAfterLast();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/*  905 */     return super.isBeforeFirst();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/*  922 */     return super.isFirst();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/*  940 */     return super.isLast();
/*      */   }
/*      */   
/*      */   boolean isUpdatable() {
/*  944 */     return this.isUpdatable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/*  962 */     return super.last();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/*  977 */     synchronized (checkClosed().getConnectionMutex()) {
/*  978 */       if (!this.isUpdatable) {
/*  979 */         throw new NotUpdatable(this.notUpdatableReason);
/*      */       }
/*      */       
/*  982 */       if (this.onInsertRow) {
/*  983 */         this.onInsertRow = false;
/*  984 */         this.thisRow = this.savedCurrentRow;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/* 1007 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1008 */       if (!this.isUpdatable) {
/* 1009 */         throw new NotUpdatable(this.notUpdatableReason);
/*      */       }
/*      */       
/* 1012 */       if (this.inserter == null) {
/* 1013 */         if (this.insertSQL == null) {
/* 1014 */           generateStatements();
/*      */         }
/*      */         
/* 1017 */         this.inserter = (PreparedStatement)this.connection.clientPrepareStatement(this.insertSQL);
/* 1018 */         this.inserter.parameterMetaData = new MysqlParameterMetadata(this.fields, this.fields.length, getExceptionInterceptor());
/*      */         
/* 1020 */         if (this.populateInserterWithDefaultValues) {
/* 1021 */           extractDefaultValues();
/*      */         }
/*      */         
/* 1024 */         resetInserter();
/*      */       } else {
/* 1026 */         resetInserter();
/*      */       } 
/*      */       
/* 1029 */       int numFields = this.fields.length;
/*      */       
/* 1031 */       this.onInsertRow = true;
/* 1032 */       this.doingUpdates = false;
/* 1033 */       this.savedCurrentRow = this.thisRow;
/* 1034 */       byte[][] newRowData = new byte[numFields][];
/* 1035 */       this.thisRow = new ByteArrayRow(newRowData, getExceptionInterceptor());
/* 1036 */       this.thisRow.setMetadata(this.fields);
/*      */       
/* 1038 */       for (int i = 0; i < numFields; i++) {
/* 1039 */         if (!this.populateInserterWithDefaultValues) {
/* 1040 */           this.inserter.setBytesNoEscapeNoQuotes(i + 1, StringUtils.getBytes("DEFAULT"));
/* 1041 */           newRowData = (byte[][])null;
/*      */         }
/* 1043 */         else if (this.defaultColumnValue[i] != null) {
/* 1044 */           Field f = this.fields[i];
/*      */           
/* 1046 */           switch (f.getMysqlType()) {
/*      */             
/*      */             case 7:
/*      */             case 10:
/*      */             case 11:
/*      */             case 12:
/*      */             case 14:
/* 1053 */               if ((this.defaultColumnValue[i]).length > 7 && this.defaultColumnValue[i][0] == 67 && this.defaultColumnValue[i][1] == 85 && this.defaultColumnValue[i][2] == 82 && this.defaultColumnValue[i][3] == 82 && this.defaultColumnValue[i][4] == 69 && this.defaultColumnValue[i][5] == 78 && this.defaultColumnValue[i][6] == 84 && this.defaultColumnValue[i][7] == 95) {
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1058 */                 this.inserter.setBytesNoEscapeNoQuotes(i + 1, this.defaultColumnValue[i]);
/*      */                 
/*      */                 break;
/*      */               } 
/* 1062 */               this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false, false);
/*      */               break;
/*      */             
/*      */             default:
/* 1066 */               this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false, false);
/*      */               break;
/*      */           } 
/*      */           
/* 1070 */           byte[] defaultValueCopy = new byte[(this.defaultColumnValue[i]).length];
/* 1071 */           System.arraycopy(this.defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
/* 1072 */           newRowData[i] = defaultValueCopy;
/*      */         } else {
/* 1074 */           this.inserter.setNull(i + 1, 0);
/* 1075 */           newRowData[i] = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/* 1102 */     return super.next();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean prev() throws SQLException {
/* 1121 */     return super.prev();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/* 1143 */     return super.previous();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void realClose(boolean calledExplicitly) throws SQLException {
/* 1158 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1160 */     if (locallyScopedConn == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1164 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1165 */       SQLException sqlEx = null;
/*      */       
/* 1167 */       if (this.useUsageAdvisor && 
/* 1168 */         this.deleter == null && this.inserter == null && this.refresher == null && this.updater == null) {
/* 1169 */         this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 1171 */         String message = Messages.getString("UpdatableResultSet.34");
/*      */         
/* 1173 */         this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1181 */         if (this.deleter != null) {
/* 1182 */           this.deleter.close();
/*      */         }
/* 1184 */       } catch (SQLException ex) {
/* 1185 */         sqlEx = ex;
/*      */       } 
/*      */       
/*      */       try {
/* 1189 */         if (this.inserter != null) {
/* 1190 */           this.inserter.close();
/*      */         }
/* 1192 */       } catch (SQLException ex) {
/* 1193 */         sqlEx = ex;
/*      */       } 
/*      */       
/*      */       try {
/* 1197 */         if (this.refresher != null) {
/* 1198 */           this.refresher.close();
/*      */         }
/* 1200 */       } catch (SQLException ex) {
/* 1201 */         sqlEx = ex;
/*      */       } 
/*      */       
/*      */       try {
/* 1205 */         if (this.updater != null) {
/* 1206 */           this.updater.close();
/*      */         }
/* 1208 */       } catch (SQLException ex) {
/* 1209 */         sqlEx = ex;
/*      */       } 
/*      */       
/* 1212 */       super.realClose(calledExplicitly);
/*      */       
/* 1214 */       if (sqlEx != null) {
/* 1215 */         throw sqlEx;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 1241 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1242 */       if (!this.isUpdatable) {
/* 1243 */         throw new NotUpdatable();
/*      */       }
/*      */       
/* 1246 */       if (this.onInsertRow)
/* 1247 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"), getExceptionInterceptor()); 
/* 1248 */       if (this.rowData.size() == 0)
/* 1249 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"), getExceptionInterceptor()); 
/* 1250 */       if (isBeforeFirst())
/* 1251 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"), getExceptionInterceptor()); 
/* 1252 */       if (isAfterLast()) {
/* 1253 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"), getExceptionInterceptor());
/*      */       }
/*      */       
/* 1256 */       refreshRow(this.updater, this.thisRow);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void refreshRow(PreparedStatement updateInsertStmt, ResultSetRow rowToRefresh) throws SQLException {
/* 1261 */     if (this.refresher == null) {
/* 1262 */       if (this.refreshSQL == null) {
/* 1263 */         generateStatements();
/*      */       }
/*      */       
/* 1266 */       this.refresher = (PreparedStatement)this.connection.clientPrepareStatement(this.refreshSQL);
/* 1267 */       this.refresher.parameterMetaData = new MysqlParameterMetadata(this.fields, this.fields.length, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1270 */     this.refresher.clearParameters();
/*      */     
/* 1272 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1274 */     if (numKeys == 1) {
/* 1275 */       byte[] dataFrom = null;
/* 1276 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */       
/* 1278 */       if (!this.doingUpdates && !this.onInsertRow) {
/* 1279 */         dataFrom = rowToRefresh.getColumnValue(index);
/*      */       } else {
/* 1281 */         dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */ 
/*      */         
/* 1284 */         if (updateInsertStmt.isNull(index) || dataFrom.length == 0) {
/* 1285 */           dataFrom = rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1287 */           dataFrom = stripBinaryPrefix(dataFrom);
/*      */         } 
/*      */       } 
/*      */       
/* 1291 */       if (this.fields[index].getvalueNeedsQuoting()) {
/* 1292 */         this.refresher.setBytesNoEscape(1, dataFrom);
/*      */       } else {
/* 1294 */         this.refresher.setBytesNoEscapeNoQuotes(1, dataFrom);
/*      */       } 
/*      */     } else {
/*      */       
/* 1298 */       for (int i = 0; i < numKeys; i++) {
/* 1299 */         byte[] dataFrom = null;
/* 1300 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */         
/* 1302 */         if (!this.doingUpdates && !this.onInsertRow) {
/* 1303 */           dataFrom = rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1305 */           dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */ 
/*      */           
/* 1308 */           if (updateInsertStmt.isNull(index) || dataFrom.length == 0) {
/* 1309 */             dataFrom = rowToRefresh.getColumnValue(index);
/*      */           } else {
/* 1311 */             dataFrom = stripBinaryPrefix(dataFrom);
/*      */           } 
/*      */         } 
/*      */         
/* 1315 */         this.refresher.setBytesNoEscape(i + 1, dataFrom);
/*      */       } 
/*      */     } 
/*      */     
/* 1319 */     ResultSet rs = null;
/*      */     
/*      */     try {
/* 1322 */       rs = this.refresher.executeQuery();
/*      */       
/* 1324 */       int numCols = rs.getMetaData().getColumnCount();
/*      */       
/* 1326 */       if (rs.next()) {
/* 1327 */         for (int i = 0; i < numCols; i++) {
/* 1328 */           byte[] val = rs.getBytes(i + 1);
/*      */           
/* 1330 */           if (val == null || rs.wasNull()) {
/* 1331 */             rowToRefresh.setColumnValue(i, null);
/*      */           } else {
/* 1333 */             rowToRefresh.setColumnValue(i, rs.getBytes(i + 1));
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1337 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000", getExceptionInterceptor());
/*      */       } 
/*      */     } finally {
/* 1340 */       if (rs != null) {
/*      */         try {
/* 1342 */           rs.close();
/* 1343 */         } catch (SQLException ex) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int rows) throws SQLException {
/* 1373 */     return super.relative(rows);
/*      */   }
/*      */   
/*      */   private void resetInserter() throws SQLException {
/* 1377 */     this.inserter.clearParameters();
/*      */     
/* 1379 */     for (int i = 0; i < this.fields.length; i++) {
/* 1380 */       this.inserter.setNull(i + 1, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/* 1400 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/* 1418 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/* 1436 */     throw SQLError.createSQLFeatureNotSupportedException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setResultSetConcurrency(int concurrencyFlag) {
/* 1447 */     super.setResultSetConcurrency(concurrencyFlag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] stripBinaryPrefix(byte[] dataFrom) {
/* 1461 */     return StringUtils.stripEnclosure(dataFrom, "_binary'", "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void syncUpdate() throws SQLException {
/* 1471 */     if (this.updater == null) {
/* 1472 */       if (this.updateSQL == null) {
/* 1473 */         generateStatements();
/*      */       }
/*      */       
/* 1476 */       this.updater = (PreparedStatement)this.connection.clientPrepareStatement(this.updateSQL);
/* 1477 */       this.updater.parameterMetaData = new MysqlParameterMetadata(this.fields, this.fields.length, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1480 */     int numFields = this.fields.length;
/* 1481 */     this.updater.clearParameters();
/*      */     
/* 1483 */     for (int i = 0; i < numFields; i++) {
/* 1484 */       if (this.thisRow.getColumnValue(i) != null) {
/*      */         
/* 1486 */         if (this.fields[i].getvalueNeedsQuoting()) {
/* 1487 */           if (this.fields[i].isCharsetApplicableType() && !this.fields[i].getEncoding().equals(this.connection.getEncoding())) {
/* 1488 */             this.updater.setString(i + 1, this.thisRow.getString(i, this.fields[i].getEncoding(), this.connection));
/*      */           } else {
/* 1490 */             this.updater.setBytes(i + 1, this.thisRow.getColumnValue(i), this.fields[i].isBinary(), false);
/*      */           } 
/*      */         } else {
/* 1493 */           this.updater.setBytesNoEscapeNoQuotes(i + 1, this.thisRow.getColumnValue(i));
/*      */         } 
/*      */       } else {
/* 1496 */         this.updater.setNull(i + 1, 0);
/*      */       } 
/*      */     } 
/*      */     
/* 1500 */     int numKeys = this.primaryKeyIndicies.size();
/* 1501 */     for (int j = 0; j < numKeys; j++) {
/* 1502 */       int idx = ((Integer)this.primaryKeyIndicies.get(j)).intValue();
/* 1503 */       setParamValue(this.updater, numFields + j + 1, this.thisRow, idx, this.fields[idx]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
/* 1526 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1527 */       if (!this.onInsertRow) {
/* 1528 */         if (!this.doingUpdates) {
/* 1529 */           this.doingUpdates = true;
/* 1530 */           syncUpdate();
/*      */         } 
/*      */         
/* 1533 */         this.updater.setAsciiStream(columnIndex, x, length);
/*      */       } else {
/* 1535 */         this.inserter.setAsciiStream(columnIndex, x, length);
/* 1536 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException {
/* 1560 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
/* 1579 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1580 */       if (!this.onInsertRow) {
/* 1581 */         if (!this.doingUpdates) {
/* 1582 */           this.doingUpdates = true;
/* 1583 */           syncUpdate();
/*      */         } 
/*      */         
/* 1586 */         this.updater.setBigDecimal(columnIndex, x);
/*      */       } else {
/* 1588 */         this.inserter.setBigDecimal(columnIndex, x);
/*      */         
/* 1590 */         if (x == null) {
/* 1591 */           this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */         } else {
/* 1593 */           this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x.toString()));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
/* 1615 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
/* 1637 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1638 */       if (!this.onInsertRow) {
/* 1639 */         if (!this.doingUpdates) {
/* 1640 */           this.doingUpdates = true;
/* 1641 */           syncUpdate();
/*      */         } 
/*      */         
/* 1644 */         this.updater.setBinaryStream(columnIndex, x, length);
/*      */       } else {
/* 1646 */         this.inserter.setBinaryStream(columnIndex, x, length);
/*      */         
/* 1648 */         if (x == null) {
/* 1649 */           this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */         } else {
/* 1651 */           this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException {
/* 1676 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int columnIndex, Blob blob) throws SQLException {
/* 1684 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1685 */       if (!this.onInsertRow) {
/* 1686 */         if (!this.doingUpdates) {
/* 1687 */           this.doingUpdates = true;
/* 1688 */           syncUpdate();
/*      */         } 
/*      */         
/* 1691 */         this.updater.setBlob(columnIndex, blob);
/*      */       } else {
/* 1693 */         this.inserter.setBlob(columnIndex, blob);
/*      */         
/* 1695 */         if (blob == null) {
/* 1696 */           this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */         } else {
/* 1698 */           this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(String columnName, Blob blob) throws SQLException {
/* 1709 */     updateBlob(findColumn(columnName), blob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(int columnIndex, boolean x) throws SQLException {
/* 1728 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1729 */       if (!this.onInsertRow) {
/* 1730 */         if (!this.doingUpdates) {
/* 1731 */           this.doingUpdates = true;
/* 1732 */           syncUpdate();
/*      */         } 
/*      */         
/* 1735 */         this.updater.setBoolean(columnIndex, x);
/*      */       } else {
/* 1737 */         this.inserter.setBoolean(columnIndex, x);
/*      */         
/* 1739 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(String columnName, boolean x) throws SQLException {
/* 1760 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(int columnIndex, byte x) throws SQLException {
/* 1779 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1780 */       if (!this.onInsertRow) {
/* 1781 */         if (!this.doingUpdates) {
/* 1782 */           this.doingUpdates = true;
/* 1783 */           syncUpdate();
/*      */         } 
/*      */         
/* 1786 */         this.updater.setByte(columnIndex, x);
/*      */       } else {
/* 1788 */         this.inserter.setByte(columnIndex, x);
/*      */         
/* 1790 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(String columnName, byte x) throws SQLException {
/* 1811 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(int columnIndex, byte[] x) throws SQLException {
/* 1830 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1831 */       if (!this.onInsertRow) {
/* 1832 */         if (!this.doingUpdates) {
/* 1833 */           this.doingUpdates = true;
/* 1834 */           syncUpdate();
/*      */         } 
/*      */         
/* 1837 */         this.updater.setBytes(columnIndex, x);
/*      */       } else {
/* 1839 */         this.inserter.setBytes(columnIndex, x);
/*      */         
/* 1841 */         this.thisRow.setColumnValue(columnIndex - 1, x);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(String columnName, byte[] x) throws SQLException {
/* 1862 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
/* 1884 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1885 */       if (!this.onInsertRow) {
/* 1886 */         if (!this.doingUpdates) {
/* 1887 */           this.doingUpdates = true;
/* 1888 */           syncUpdate();
/*      */         } 
/*      */         
/* 1891 */         this.updater.setCharacterStream(columnIndex, x, length);
/*      */       } else {
/* 1893 */         this.inserter.setCharacterStream(columnIndex, x, length);
/*      */         
/* 1895 */         if (x == null) {
/* 1896 */           this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */         } else {
/* 1898 */           this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException {
/* 1923 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int columnIndex, Clob clob) throws SQLException {
/* 1931 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1932 */       if (clob == null) {
/* 1933 */         updateNull(columnIndex);
/*      */       } else {
/* 1935 */         updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int columnIndex, Date x) throws SQLException {
/* 1956 */     synchronized (checkClosed().getConnectionMutex()) {
/* 1957 */       if (!this.onInsertRow) {
/* 1958 */         if (!this.doingUpdates) {
/* 1959 */           this.doingUpdates = true;
/* 1960 */           syncUpdate();
/*      */         } 
/*      */         
/* 1963 */         this.updater.setDate(columnIndex, x);
/*      */       } else {
/* 1965 */         this.inserter.setDate(columnIndex, x);
/*      */         
/* 1967 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(String columnName, Date x) throws SQLException {
/* 1988 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(int columnIndex, double x) throws SQLException {
/* 2007 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2008 */       if (!this.onInsertRow) {
/* 2009 */         if (!this.doingUpdates) {
/* 2010 */           this.doingUpdates = true;
/* 2011 */           syncUpdate();
/*      */         } 
/*      */         
/* 2014 */         this.updater.setDouble(columnIndex, x);
/*      */       } else {
/* 2016 */         this.inserter.setDouble(columnIndex, x);
/*      */         
/* 2018 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(String columnName, double x) throws SQLException {
/* 2039 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(int columnIndex, float x) throws SQLException {
/* 2058 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2059 */       if (!this.onInsertRow) {
/* 2060 */         if (!this.doingUpdates) {
/* 2061 */           this.doingUpdates = true;
/* 2062 */           syncUpdate();
/*      */         } 
/*      */         
/* 2065 */         this.updater.setFloat(columnIndex, x);
/*      */       } else {
/* 2067 */         this.inserter.setFloat(columnIndex, x);
/*      */         
/* 2069 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(String columnName, float x) throws SQLException {
/* 2090 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(int columnIndex, int x) throws SQLException {
/* 2109 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2110 */       if (!this.onInsertRow) {
/* 2111 */         if (!this.doingUpdates) {
/* 2112 */           this.doingUpdates = true;
/* 2113 */           syncUpdate();
/*      */         } 
/*      */         
/* 2116 */         this.updater.setInt(columnIndex, x);
/*      */       } else {
/* 2118 */         this.inserter.setInt(columnIndex, x);
/*      */         
/* 2120 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(String columnName, int x) throws SQLException {
/* 2141 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(int columnIndex, long x) throws SQLException {
/* 2160 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2161 */       if (!this.onInsertRow) {
/* 2162 */         if (!this.doingUpdates) {
/* 2163 */           this.doingUpdates = true;
/* 2164 */           syncUpdate();
/*      */         } 
/*      */         
/* 2167 */         this.updater.setLong(columnIndex, x);
/*      */       } else {
/* 2169 */         this.inserter.setLong(columnIndex, x);
/*      */         
/* 2171 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(String columnName, long x) throws SQLException {
/* 2192 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int columnIndex) throws SQLException {
/* 2209 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2210 */       if (!this.onInsertRow) {
/* 2211 */         if (!this.doingUpdates) {
/* 2212 */           this.doingUpdates = true;
/* 2213 */           syncUpdate();
/*      */         } 
/*      */         
/* 2216 */         this.updater.setNull(columnIndex, 0);
/*      */       } else {
/* 2218 */         this.inserter.setNull(columnIndex, 0);
/*      */         
/* 2220 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String columnName) throws SQLException {
/* 2239 */     updateNull(findColumn(columnName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int columnIndex, Object x) throws SQLException {
/* 2258 */     updateObjectInternal(columnIndex, x, (Integer)null, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
/* 2281 */     updateObjectInternal(columnIndex, x, (Integer)null, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateObjectInternal(int columnIndex, Object x, Integer targetType, int scaleOrLength) throws SQLException {
/* 2295 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2296 */       if (!this.onInsertRow) {
/* 2297 */         if (!this.doingUpdates) {
/* 2298 */           this.doingUpdates = true;
/* 2299 */           syncUpdate();
/*      */         } 
/*      */         
/* 2302 */         if (targetType == null) {
/* 2303 */           this.updater.setObject(columnIndex, x);
/*      */         } else {
/* 2305 */           this.updater.setObject(columnIndex, x, targetType.intValue());
/*      */         } 
/*      */       } else {
/* 2308 */         if (targetType == null) {
/* 2309 */           this.inserter.setObject(columnIndex, x);
/*      */         } else {
/* 2311 */           this.inserter.setObject(columnIndex, x, targetType.intValue());
/*      */         } 
/*      */         
/* 2314 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x) throws SQLException {
/* 2335 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x, int scale) throws SQLException {
/* 2358 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/* 2372 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2373 */       if (!this.isUpdatable) {
/* 2374 */         throw new NotUpdatable(this.notUpdatableReason);
/*      */       }
/*      */       
/* 2377 */       if (this.doingUpdates) {
/* 2378 */         this.updater.executeUpdate();
/* 2379 */         refreshRow();
/* 2380 */         this.doingUpdates = false;
/* 2381 */       } else if (this.onInsertRow) {
/* 2382 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.44"), getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2388 */       syncUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(int columnIndex, short x) throws SQLException {
/* 2408 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2409 */       if (!this.onInsertRow) {
/* 2410 */         if (!this.doingUpdates) {
/* 2411 */           this.doingUpdates = true;
/* 2412 */           syncUpdate();
/*      */         } 
/*      */         
/* 2415 */         this.updater.setShort(columnIndex, x);
/*      */       } else {
/* 2417 */         this.inserter.setShort(columnIndex, x);
/*      */         
/* 2419 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(String columnName, short x) throws SQLException {
/* 2440 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(int columnIndex, String x) throws SQLException {
/* 2459 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2460 */       if (!this.onInsertRow) {
/* 2461 */         if (!this.doingUpdates) {
/* 2462 */           this.doingUpdates = true;
/* 2463 */           syncUpdate();
/*      */         } 
/*      */         
/* 2466 */         this.updater.setString(columnIndex, x);
/*      */       } else {
/* 2468 */         this.inserter.setString(columnIndex, x);
/*      */         
/* 2470 */         if (x == null) {
/* 2471 */           this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */         }
/* 2473 */         else if (getCharConverter() != null) {
/* 2474 */           this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharset(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */         } else {
/*      */           
/* 2477 */           this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(String columnName, String x) throws SQLException {
/* 2500 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int columnIndex, Time x) throws SQLException {
/* 2519 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2520 */       if (!this.onInsertRow) {
/* 2521 */         if (!this.doingUpdates) {
/* 2522 */           this.doingUpdates = true;
/* 2523 */           syncUpdate();
/*      */         } 
/*      */         
/* 2526 */         this.updater.setTime(columnIndex, x);
/*      */       } else {
/* 2528 */         this.inserter.setTime(columnIndex, x);
/*      */         
/* 2530 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(String columnName, Time x) throws SQLException {
/* 2551 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
/* 2570 */     synchronized (checkClosed().getConnectionMutex()) {
/* 2571 */       if (!this.onInsertRow) {
/* 2572 */         if (!this.doingUpdates) {
/* 2573 */           this.doingUpdates = true;
/* 2574 */           syncUpdate();
/*      */         } 
/*      */         
/* 2577 */         this.updater.setTimestamp(columnIndex, x);
/*      */       } else {
/* 2579 */         this.inserter.setTimestamp(columnIndex, x);
/*      */         
/* 2581 */         this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String columnName, Timestamp x) throws SQLException {
/* 2602 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\UpdatableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */