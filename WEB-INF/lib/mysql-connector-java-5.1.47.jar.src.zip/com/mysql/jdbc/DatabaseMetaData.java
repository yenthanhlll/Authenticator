/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DatabaseMetaData
/*      */   implements DatabaseMetaData
/*      */ {
/*      */   protected static final int MAX_IDENTIFIER_LENGTH = 64;
/*      */   private static final int DEFERRABILITY = 13;
/*      */   private static final int DELETE_RULE = 10;
/*      */   private static final int FK_NAME = 11;
/*      */   private static final int FKCOLUMN_NAME = 7;
/*      */   private static final int FKTABLE_CAT = 4;
/*      */   private static final int FKTABLE_NAME = 6;
/*      */   private static final int FKTABLE_SCHEM = 5;
/*      */   private static final int KEY_SEQ = 8;
/*      */   private static final int PK_NAME = 12;
/*      */   private static final int PKCOLUMN_NAME = 3;
/*      */   private static final int PKTABLE_CAT = 0;
/*      */   private static final int PKTABLE_NAME = 2;
/*      */   private static final int PKTABLE_SCHEM = 1;
/*      */   private static final String SUPPORTS_FK = "SUPPORTS_FK";
/*      */   
/*      */   protected abstract class IteratorWithCleanup<T>
/*      */   {
/*      */     abstract void close() throws SQLException;
/*      */     
/*      */     abstract boolean hasNext() throws SQLException;
/*      */     
/*      */     abstract T next() throws SQLException;
/*      */   }
/*      */   
/*      */   class LocalAndReferencedColumns
/*      */   {
/*      */     String constraintName;
/*      */     List<String> localColumnsList;
/*      */     String referencedCatalog;
/*      */     List<String> referencedColumnsList;
/*      */     String referencedTable;
/*      */     
/*      */     LocalAndReferencedColumns(List<String> localColumns, List<String> refColumns, String constName, String refCatalog, String refTable) {
/*   86 */       this.localColumnsList = localColumns;
/*   87 */       this.referencedColumnsList = refColumns;
/*   88 */       this.constraintName = constName;
/*   89 */       this.referencedTable = refTable;
/*   90 */       this.referencedCatalog = refCatalog;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class ResultSetIterator
/*      */     extends IteratorWithCleanup<String> {
/*      */     int colIndex;
/*      */     ResultSet resultSet;
/*      */     
/*      */     ResultSetIterator(ResultSet rs, int index) {
/*  100 */       this.resultSet = rs;
/*  101 */       this.colIndex = index;
/*      */     }
/*      */ 
/*      */     
/*      */     void close() throws SQLException {
/*  106 */       this.resultSet.close();
/*      */     }
/*      */ 
/*      */     
/*      */     boolean hasNext() throws SQLException {
/*  111 */       return this.resultSet.next();
/*      */     }
/*      */ 
/*      */     
/*      */     String next() throws SQLException {
/*  116 */       return this.resultSet.getObject(this.colIndex).toString();
/*      */     }
/*      */   }
/*      */   
/*      */   protected class SingleStringIterator
/*      */     extends IteratorWithCleanup<String> {
/*      */     boolean onFirst = true;
/*      */     String value;
/*      */     
/*      */     SingleStringIterator(String s) {
/*  126 */       this.value = s;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void close() throws SQLException {}
/*      */ 
/*      */ 
/*      */     
/*      */     boolean hasNext() throws SQLException {
/*  137 */       return this.onFirst;
/*      */     }
/*      */ 
/*      */     
/*      */     String next() throws SQLException {
/*  142 */       this.onFirst = false;
/*  143 */       return this.value;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class TypeDescriptor
/*      */   {
/*      */     int bufferLength;
/*      */ 
/*      */     
/*      */     int charOctetLength;
/*      */     
/*      */     Integer columnSize;
/*      */     
/*      */     short dataType;
/*      */     
/*      */     Integer decimalDigits;
/*      */     
/*      */     String isNullable;
/*      */     
/*      */     int nullability;
/*      */     
/*  166 */     int numPrecRadix = 10;
/*      */     
/*      */     String typeName;
/*      */     
/*      */     TypeDescriptor(String typeInfo, String nullabilityInfo) throws SQLException {
/*  171 */       if (typeInfo == null) {
/*  172 */         throw SQLError.createSQLException("NULL typeinfo not supported.", "S1009", DatabaseMetaData.this.getExceptionInterceptor());
/*      */       }
/*      */       
/*  175 */       String mysqlType = "";
/*  176 */       String fullMysqlType = null;
/*      */       
/*  178 */       if (typeInfo.indexOf("(") != -1) {
/*  179 */         mysqlType = typeInfo.substring(0, typeInfo.indexOf("(")).trim();
/*      */       } else {
/*  181 */         mysqlType = typeInfo;
/*      */       } 
/*      */       
/*  184 */       int indexOfUnsignedInMysqlType = StringUtils.indexOfIgnoreCase(mysqlType, "unsigned");
/*      */       
/*  186 */       if (indexOfUnsignedInMysqlType != -1) {
/*  187 */         mysqlType = mysqlType.substring(0, indexOfUnsignedInMysqlType - 1);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  192 */       boolean isUnsigned = false;
/*      */       
/*  194 */       if (StringUtils.indexOfIgnoreCase(typeInfo, "unsigned") != -1 && StringUtils.indexOfIgnoreCase(typeInfo, "set") != 0 && StringUtils.indexOfIgnoreCase(typeInfo, "enum") != 0) {
/*      */         
/*  196 */         fullMysqlType = mysqlType + " unsigned";
/*  197 */         isUnsigned = true;
/*      */       } else {
/*  199 */         fullMysqlType = mysqlType;
/*      */       } 
/*      */       
/*  202 */       if (DatabaseMetaData.this.conn.getCapitalizeTypeNames()) {
/*  203 */         fullMysqlType = fullMysqlType.toUpperCase(Locale.ENGLISH);
/*      */       }
/*      */       
/*  206 */       this.dataType = (short)MysqlDefs.mysqlToJavaType(mysqlType);
/*      */       
/*  208 */       this.typeName = fullMysqlType;
/*      */ 
/*      */ 
/*      */       
/*  212 */       if (StringUtils.startsWithIgnoreCase(typeInfo, "enum")) {
/*  213 */         String temp = typeInfo.substring(typeInfo.indexOf("("), typeInfo.lastIndexOf(")"));
/*  214 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*  215 */         int maxLength = 0;
/*      */         
/*  217 */         while (tokenizer.hasMoreTokens()) {
/*  218 */           maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */         }
/*      */         
/*  221 */         this.columnSize = Integer.valueOf(maxLength);
/*  222 */         this.decimalDigits = null;
/*  223 */       } else if (StringUtils.startsWithIgnoreCase(typeInfo, "set")) {
/*  224 */         String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
/*  225 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*  226 */         int maxLength = 0;
/*      */         
/*  228 */         int numElements = tokenizer.countTokens();
/*      */         
/*  230 */         if (numElements > 0) {
/*  231 */           maxLength += numElements - 1;
/*      */         }
/*      */         
/*  234 */         while (tokenizer.hasMoreTokens()) {
/*  235 */           String setMember = tokenizer.nextToken().trim();
/*      */           
/*  237 */           if (setMember.startsWith("'") && setMember.endsWith("'")) {
/*  238 */             maxLength += setMember.length() - 2; continue;
/*      */           } 
/*  240 */           maxLength += setMember.length();
/*      */         } 
/*      */ 
/*      */         
/*  244 */         this.columnSize = Integer.valueOf(maxLength);
/*  245 */         this.decimalDigits = null;
/*  246 */       } else if (typeInfo.indexOf(",") != -1) {
/*      */         
/*  248 */         this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
/*  249 */         this.decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim());
/*      */       } else {
/*  251 */         this.columnSize = null;
/*  252 */         this.decimalDigits = null;
/*      */ 
/*      */         
/*  255 */         if ((StringUtils.indexOfIgnoreCase(typeInfo, "char") != -1 || StringUtils.indexOfIgnoreCase(typeInfo, "text") != -1 || StringUtils.indexOfIgnoreCase(typeInfo, "blob") != -1 || StringUtils.indexOfIgnoreCase(typeInfo, "binary") != -1 || StringUtils.indexOfIgnoreCase(typeInfo, "bit") != -1) && typeInfo.indexOf("(") != -1) {
/*      */ 
/*      */           
/*  258 */           int endParenIndex = typeInfo.indexOf(")");
/*      */           
/*  260 */           if (endParenIndex == -1) {
/*  261 */             endParenIndex = typeInfo.length();
/*      */           }
/*      */           
/*  264 */           this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex).trim());
/*      */ 
/*      */           
/*  267 */           if (DatabaseMetaData.this.conn.getTinyInt1isBit() && this.columnSize.intValue() == 1 && StringUtils.startsWithIgnoreCase(typeInfo, 0, "tinyint"))
/*      */           {
/*  269 */             if (DatabaseMetaData.this.conn.getTransformedBitIsBoolean()) {
/*  270 */               this.dataType = 16;
/*  271 */               this.typeName = "BOOLEAN";
/*      */             } else {
/*  273 */               this.dataType = -7;
/*  274 */               this.typeName = "BIT";
/*      */             } 
/*      */           }
/*  277 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinyint")) {
/*  278 */           if (DatabaseMetaData.this.conn.getTinyInt1isBit() && typeInfo.indexOf("(1)") != -1) {
/*  279 */             if (DatabaseMetaData.this.conn.getTransformedBitIsBoolean()) {
/*  280 */               this.dataType = 16;
/*  281 */               this.typeName = "BOOLEAN";
/*      */             } else {
/*  283 */               this.dataType = -7;
/*  284 */               this.typeName = "BIT";
/*      */             } 
/*      */           } else {
/*  287 */             this.columnSize = Integer.valueOf(3);
/*  288 */             this.decimalDigits = Integer.valueOf(0);
/*      */           } 
/*  290 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "smallint")) {
/*  291 */           this.columnSize = Integer.valueOf(5);
/*  292 */           this.decimalDigits = Integer.valueOf(0);
/*  293 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumint")) {
/*  294 */           this.columnSize = Integer.valueOf(isUnsigned ? 8 : 7);
/*  295 */           this.decimalDigits = Integer.valueOf(0);
/*  296 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "int")) {
/*  297 */           this.columnSize = Integer.valueOf(10);
/*  298 */           this.decimalDigits = Integer.valueOf(0);
/*  299 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "integer")) {
/*  300 */           this.columnSize = Integer.valueOf(10);
/*  301 */           this.decimalDigits = Integer.valueOf(0);
/*  302 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "bigint")) {
/*  303 */           this.columnSize = Integer.valueOf(isUnsigned ? 20 : 19);
/*  304 */           this.decimalDigits = Integer.valueOf(0);
/*  305 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "int24")) {
/*  306 */           this.columnSize = Integer.valueOf(19);
/*  307 */           this.decimalDigits = Integer.valueOf(0);
/*  308 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "real")) {
/*  309 */           this.columnSize = Integer.valueOf(12);
/*  310 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "float")) {
/*  311 */           this.columnSize = Integer.valueOf(12);
/*  312 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "decimal")) {
/*  313 */           this.columnSize = Integer.valueOf(12);
/*  314 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "numeric")) {
/*  315 */           this.columnSize = Integer.valueOf(12);
/*  316 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "double")) {
/*  317 */           this.columnSize = Integer.valueOf(22);
/*  318 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "char")) {
/*  319 */           this.columnSize = Integer.valueOf(1);
/*  320 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "varchar")) {
/*  321 */           this.columnSize = Integer.valueOf(255);
/*  322 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "timestamp")) {
/*  323 */           this.columnSize = Integer.valueOf(19);
/*  324 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "datetime")) {
/*  325 */           this.columnSize = Integer.valueOf(19);
/*  326 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "date")) {
/*  327 */           this.columnSize = Integer.valueOf(10);
/*  328 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "time")) {
/*  329 */           this.columnSize = Integer.valueOf(8);
/*      */         }
/*  331 */         else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinyblob")) {
/*  332 */           this.columnSize = Integer.valueOf(255);
/*  333 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "blob")) {
/*  334 */           this.columnSize = Integer.valueOf(65535);
/*  335 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumblob")) {
/*  336 */           this.columnSize = Integer.valueOf(16777215);
/*  337 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "longblob")) {
/*  338 */           this.columnSize = Integer.valueOf(2147483647);
/*  339 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinytext")) {
/*  340 */           this.columnSize = Integer.valueOf(255);
/*  341 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "text")) {
/*  342 */           this.columnSize = Integer.valueOf(65535);
/*  343 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumtext")) {
/*  344 */           this.columnSize = Integer.valueOf(16777215);
/*  345 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "longtext")) {
/*  346 */           this.columnSize = Integer.valueOf(2147483647);
/*  347 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "enum")) {
/*  348 */           this.columnSize = Integer.valueOf(255);
/*  349 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "set")) {
/*  350 */           this.columnSize = Integer.valueOf(255);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  356 */       this.bufferLength = MysqlIO.getMaxBuf();
/*      */ 
/*      */       
/*  359 */       this.numPrecRadix = 10;
/*      */ 
/*      */       
/*  362 */       if (nullabilityInfo != null) {
/*  363 */         if (nullabilityInfo.equals("YES")) {
/*  364 */           this.nullability = 1;
/*  365 */           this.isNullable = "YES";
/*      */         }
/*  367 */         else if (nullabilityInfo.equals("UNKNOWN")) {
/*  368 */           this.nullability = 2;
/*  369 */           this.isNullable = "";
/*      */         }
/*      */         else {
/*      */           
/*  373 */           this.nullability = 0;
/*  374 */           this.isNullable = "NO";
/*      */         } 
/*      */       } else {
/*  377 */         this.nullability = 0;
/*  378 */         this.isNullable = "NO";
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected class IndexMetaDataKey
/*      */     implements Comparable<IndexMetaDataKey>
/*      */   {
/*      */     Boolean columnNonUnique;
/*      */     Short columnType;
/*      */     String columnIndexName;
/*      */     Short columnOrdinalPosition;
/*      */     
/*      */     IndexMetaDataKey(boolean columnNonUnique, short columnType, String columnIndexName, short columnOrdinalPosition) {
/*  393 */       this.columnNonUnique = Boolean.valueOf(columnNonUnique);
/*  394 */       this.columnType = Short.valueOf(columnType);
/*  395 */       this.columnIndexName = columnIndexName;
/*  396 */       this.columnOrdinalPosition = Short.valueOf(columnOrdinalPosition);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(IndexMetaDataKey indexInfoKey) {
/*      */       int compareResult;
/*  402 */       if ((compareResult = this.columnNonUnique.compareTo(indexInfoKey.columnNonUnique)) != 0) {
/*  403 */         return compareResult;
/*      */       }
/*  405 */       if ((compareResult = this.columnType.compareTo(indexInfoKey.columnType)) != 0) {
/*  406 */         return compareResult;
/*      */       }
/*  408 */       if ((compareResult = this.columnIndexName.compareTo(indexInfoKey.columnIndexName)) != 0) {
/*  409 */         return compareResult;
/*      */       }
/*  411 */       return this.columnOrdinalPosition.compareTo(indexInfoKey.columnOrdinalPosition);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  416 */       if (obj == null) {
/*  417 */         return false;
/*      */       }
/*      */       
/*  420 */       if (obj == this) {
/*  421 */         return true;
/*      */       }
/*      */       
/*  424 */       if (!(obj instanceof IndexMetaDataKey)) {
/*  425 */         return false;
/*      */       }
/*  427 */       return (compareTo((IndexMetaDataKey)obj) == 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  432 */       assert false : "hashCode not designed";
/*  433 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected class TableMetaDataKey
/*      */     implements Comparable<TableMetaDataKey>
/*      */   {
/*      */     String tableType;
/*      */     String tableCat;
/*      */     String tableSchem;
/*      */     String tableName;
/*      */     
/*      */     TableMetaDataKey(String tableType, String tableCat, String tableSchem, String tableName) {
/*  447 */       this.tableType = (tableType == null) ? "" : tableType;
/*  448 */       this.tableCat = (tableCat == null) ? "" : tableCat;
/*  449 */       this.tableSchem = (tableSchem == null) ? "" : tableSchem;
/*  450 */       this.tableName = (tableName == null) ? "" : tableName;
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(TableMetaDataKey tablesKey) {
/*      */       int compareResult;
/*  456 */       if ((compareResult = this.tableType.compareTo(tablesKey.tableType)) != 0) {
/*  457 */         return compareResult;
/*      */       }
/*  459 */       if ((compareResult = this.tableCat.compareTo(tablesKey.tableCat)) != 0) {
/*  460 */         return compareResult;
/*      */       }
/*  462 */       if ((compareResult = this.tableSchem.compareTo(tablesKey.tableSchem)) != 0) {
/*  463 */         return compareResult;
/*      */       }
/*  465 */       return this.tableName.compareTo(tablesKey.tableName);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  470 */       if (obj == null) {
/*  471 */         return false;
/*      */       }
/*      */       
/*  474 */       if (obj == this) {
/*  475 */         return true;
/*      */       }
/*      */       
/*  478 */       if (!(obj instanceof TableMetaDataKey)) {
/*  479 */         return false;
/*      */       }
/*  481 */       return (compareTo((TableMetaDataKey)obj) == 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  486 */       assert false : "hashCode not designed";
/*  487 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected class ComparableWrapper<K extends Comparable<? super K>, V>
/*      */     implements Comparable<ComparableWrapper<K, V>>
/*      */   {
/*      */     K key;
/*      */     V value;
/*      */     
/*      */     public ComparableWrapper(K key, V value) {
/*  499 */       this.key = key;
/*  500 */       this.value = value;
/*      */     }
/*      */     
/*      */     public K getKey() {
/*  504 */       return this.key;
/*      */     }
/*      */     
/*      */     public V getValue() {
/*  508 */       return this.value;
/*      */     }
/*      */     
/*      */     public int compareTo(ComparableWrapper<K, V> other) {
/*  512 */       return ((Comparable)getKey()).compareTo(other.getKey());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  517 */       if (obj == null) {
/*  518 */         return false;
/*      */       }
/*      */       
/*  521 */       if (obj == this) {
/*  522 */         return true;
/*      */       }
/*      */       
/*  525 */       if (!(obj instanceof ComparableWrapper)) {
/*  526 */         return false;
/*      */       }
/*      */       
/*  529 */       Object otherKey = ((ComparableWrapper)obj).getKey();
/*  530 */       return this.key.equals(otherKey);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  535 */       assert false : "hashCode not designed";
/*  536 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  541 */       return "{KEY:" + this.key + "; VALUE:" + this.value + "}";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected enum TableType
/*      */   {
/*  549 */     LOCAL_TEMPORARY("LOCAL TEMPORARY"), SYSTEM_TABLE("SYSTEM TABLE"), SYSTEM_VIEW("SYSTEM VIEW"), TABLE("TABLE", new String[] { "BASE TABLE" }),
/*  550 */     VIEW("VIEW"), UNKNOWN("UNKNOWN");
/*      */ 
/*      */     
/*      */     private String name;
/*      */     
/*      */     private byte[] nameAsBytes;
/*      */     
/*      */     private String[] synonyms;
/*      */ 
/*      */     
/*      */     TableType(String tableTypeName, String[] tableTypeSynonyms) {
/*  561 */       this.name = tableTypeName;
/*  562 */       this.nameAsBytes = tableTypeName.getBytes();
/*  563 */       this.synonyms = tableTypeSynonyms;
/*      */     }
/*      */     
/*      */     String getName() {
/*  567 */       return this.name;
/*      */     }
/*      */     
/*      */     byte[] asBytes() {
/*  571 */       return this.nameAsBytes;
/*      */     }
/*      */     
/*      */     boolean equalsTo(String tableTypeName) {
/*  575 */       return this.name.equalsIgnoreCase(tableTypeName);
/*      */     }
/*      */     
/*      */     static TableType getTableTypeEqualTo(String tableTypeName) {
/*  579 */       for (TableType tableType : values()) {
/*  580 */         if (tableType.equalsTo(tableTypeName)) {
/*  581 */           return tableType;
/*      */         }
/*      */       } 
/*  584 */       return UNKNOWN;
/*      */     }
/*      */     
/*      */     boolean compliesWith(String tableTypeName) {
/*  588 */       if (equalsTo(tableTypeName)) {
/*  589 */         return true;
/*      */       }
/*  591 */       if (this.synonyms != null) {
/*  592 */         for (String synonym : this.synonyms) {
/*  593 */           if (synonym.equalsIgnoreCase(tableTypeName)) {
/*  594 */             return true;
/*      */           }
/*      */         } 
/*      */       }
/*  598 */       return false;
/*      */     }
/*      */     
/*      */     static TableType getTableTypeCompliantWith(String tableTypeName) {
/*  602 */       for (TableType tableType : values()) {
/*  603 */         if (tableType.compliesWith(tableTypeName)) {
/*  604 */           return tableType;
/*      */         }
/*      */       } 
/*  607 */       return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected enum ProcedureType
/*      */   {
/*  615 */     PROCEDURE, FUNCTION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  652 */   protected static final byte[] TABLE_AS_BYTES = "TABLE".getBytes();
/*      */   
/*  654 */   protected static final byte[] SYSTEM_TABLE_AS_BYTES = "SYSTEM TABLE".getBytes();
/*      */   
/*      */   private static final int UPDATE_RULE = 9;
/*      */   
/*  658 */   protected static final byte[] VIEW_AS_BYTES = "VIEW".getBytes();
/*      */   
/*      */   private static final Constructor<?> JDBC_4_DBMD_SHOW_CTOR;
/*      */   
/*      */   private static final Constructor<?> JDBC_4_DBMD_IS_CTOR;
/*      */   
/*      */   static {
/*  665 */     if (Util.isJdbc4()) {
/*      */       try {
/*  667 */         JDBC_4_DBMD_SHOW_CTOR = Class.forName("com.mysql.jdbc.JDBC4DatabaseMetaData").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */         
/*  669 */         JDBC_4_DBMD_IS_CTOR = Class.forName("com.mysql.jdbc.JDBC4DatabaseMetaDataUsingInfoSchema").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */       }
/*  671 */       catch (SecurityException e) {
/*  672 */         throw new RuntimeException(e);
/*  673 */       } catch (NoSuchMethodException e) {
/*  674 */         throw new RuntimeException(e);
/*  675 */       } catch (ClassNotFoundException e) {
/*  676 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*  679 */       JDBC_4_DBMD_IS_CTOR = null;
/*  680 */       JDBC_4_DBMD_SHOW_CTOR = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  685 */   private static final String[] MYSQL_KEYWORDS = new String[] { "ACCESSIBLE", "ADD", "ALL", "ALTER", "ANALYZE", "AND", "AS", "ASC", "ASENSITIVE", "BEFORE", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOTH", "BY", "CALL", "CASCADE", "CASE", "CHANGE", "CHAR", "CHARACTER", "CHECK", "COLLATE", "COLUMN", "CONDITION", "CONSTRAINT", "CONTINUE", "CONVERT", "CREATE", "CROSS", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATABASE", "DATABASES", "DAY_HOUR", "DAY_MICROSECOND", "DAY_MINUTE", "DAY_SECOND", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELAYED", "DELETE", "DESC", "DESCRIBE", "DETERMINISTIC", "DISTINCT", "DISTINCTROW", "DIV", "DOUBLE", "DROP", "DUAL", "EACH", "ELSE", "ELSEIF", "ENCLOSED", "ESCAPED", "EXISTS", "EXIT", "EXPLAIN", "FALSE", "FETCH", "FLOAT", "FLOAT4", "FLOAT8", "FOR", "FORCE", "FOREIGN", "FROM", "FULLTEXT", "GENERATED", "GET", "GRANT", "GROUP", "HAVING", "HIGH_PRIORITY", "HOUR_MICROSECOND", "HOUR_MINUTE", "HOUR_SECOND", "IF", "IGNORE", "IN", "INDEX", "INFILE", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INT1", "INT2", "INT3", "INT4", "INT8", "INTEGER", "INTERVAL", "INTO", "IO_AFTER_GTIDS", "IO_BEFORE_GTIDS", "IS", "ITERATE", "JOIN", "KEY", "KEYS", "KILL", "LEADING", "LEAVE", "LEFT", "LIKE", "LIMIT", "LINEAR", "LINES", "LOAD", "LOCALTIME", "LOCALTIMESTAMP", "LOCK", "LONG", "LONGBLOB", "LONGTEXT", "LOOP", "LOW_PRIORITY", "MASTER_BIND", "MASTER_SSL_VERIFY_SERVER_CERT", "MATCH", "MAXVALUE", "MEDIUMBLOB", "MEDIUMINT", "MEDIUMTEXT", "MIDDLEINT", "MINUTE_MICROSECOND", "MINUTE_SECOND", "MOD", "MODIFIES", "NATURAL", "NOT", "NO_WRITE_TO_BINLOG", "NULL", "NUMERIC", "ON", "OPTIMIZE", "OPTIMIZER_COSTS", "OPTION", "OPTIONALLY", "OR", "ORDER", "OUT", "OUTER", "OUTFILE", "PARTITION", "PRECISION", "PRIMARY", "PROCEDURE", "PURGE", "RANGE", "READ", "READS", "READ_WRITE", "REAL", "REFERENCES", "REGEXP", "RELEASE", "RENAME", "REPEAT", "REPLACE", "REQUIRE", "RESIGNAL", "RESTRICT", "RETURN", "REVOKE", "RIGHT", "RLIKE", "SCHEMA", "SCHEMAS", "SECOND_MICROSECOND", "SELECT", "SENSITIVE", "SEPARATOR", "SET", "SHOW", "SIGNAL", "SMALLINT", "SPATIAL", "SPECIFIC", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQL_BIG_RESULT", "SQL_CALC_FOUND_ROWS", "SQL_SMALL_RESULT", "SSL", "STARTING", "STORED", "STRAIGHT_JOIN", "TABLE", "TERMINATED", "THEN", "TINYBLOB", "TINYINT", "TINYTEXT", "TO", "TRAILING", "TRIGGER", "TRUE", "UNDO", "UNION", "UNIQUE", "UNLOCK", "UNSIGNED", "UPDATE", "USAGE", "USE", "USING", "UTC_DATE", "UTC_TIME", "UTC_TIMESTAMP", "VALUES", "VARBINARY", "VARCHAR", "VARCHARACTER", "VARYING", "VIRTUAL", "WHEN", "WHERE", "WHILE", "WITH", "WRITE", "XOR", "YEAR_MONTH", "ZEROFILL" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  706 */   private static final String[] SQL92_KEYWORDS = new String[] { "ABSOLUTE", "ACTION", "ADD", "ALL", "ALLOCATE", "ALTER", "AND", "ANY", "ARE", "AS", "ASC", "ASSERTION", "AT", "AUTHORIZATION", "AVG", "BEGIN", "BETWEEN", "BIT", "BIT_LENGTH", "BOTH", "BY", "CASCADE", "CASCADED", "CASE", "CAST", "CATALOG", "CHAR", "CHARACTER", "CHARACTER_LENGTH", "CHAR_LENGTH", "CHECK", "CLOSE", "COALESCE", "COLLATE", "COLLATION", "COLUMN", "COMMIT", "CONNECT", "CONNECTION", "CONSTRAINT", "CONSTRAINTS", "CONTINUE", "CONVERT", "CORRESPONDING", "COUNT", "CREATE", "CROSS", "CURRENT", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATE", "DAY", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DEFERRABLE", "DEFERRED", "DELETE", "DESC", "DESCRIBE", "DESCRIPTOR", "DIAGNOSTICS", "DISCONNECT", "DISTINCT", "DOMAIN", "DOUBLE", "DROP", "ELSE", "END", "END-EXEC", "ESCAPE", "EXCEPT", "EXCEPTION", "EXEC", "EXECUTE", "EXISTS", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FIRST", "FLOAT", "FOR", "FOREIGN", "FOUND", "FROM", "FULL", "GET", "GLOBAL", "GO", "GOTO", "GRANT", "GROUP", "HAVING", "HOUR", "IDENTITY", "IMMEDIATE", "IN", "INDICATOR", "INITIALLY", "INNER", "INPUT", "INSENSITIVE", "INSERT", "INT", "INTEGER", "INTERSECT", "INTERVAL", "INTO", "IS", "ISOLATION", "JOIN", "KEY", "LANGUAGE", "LAST", "LEADING", "LEFT", "LEVEL", "LIKE", "LOCAL", "LOWER", "MATCH", "MAX", "MIN", "MINUTE", "MODULE", "MONTH", "NAMES", "NATIONAL", "NATURAL", "NCHAR", "NEXT", "NO", "NOT", "NULL", "NULLIF", "NUMERIC", "OCTET_LENGTH", "OF", "ON", "ONLY", "OPEN", "OPTION", "OR", "ORDER", "OUTER", "OUTPUT", "OVERLAPS", "PAD", "PARTIAL", "POSITION", "PRECISION", "PREPARE", "PRESERVE", "PRIMARY", "PRIOR", "PRIVILEGES", "PROCEDURE", "PUBLIC", "READ", "REAL", "REFERENCES", "RELATIVE", "RESTRICT", "REVOKE", "RIGHT", "ROLLBACK", "ROWS", "SCHEMA", "SCROLL", "SECOND", "SECTION", "SELECT", "SESSION", "SESSION_USER", "SET", "SIZE", "SMALLINT", "SOME", "SPACE", "SQL", "SQLCODE", "SQLERROR", "SQLSTATE", "SUBSTRING", "SUM", "SYSTEM_USER", "TABLE", "TEMPORARY", "THEN", "TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TRANSACTION", "TRANSLATE", "TRANSLATION", "TRIM", "TRUE", "UNION", "UNIQUE", "UNKNOWN", "UPDATE", "UPPER", "USAGE", "USER", "USING", "VALUE", "VALUES", "VARCHAR", "VARYING", "VIEW", "WHEN", "WHENEVER", "WHERE", "WITH", "WORK", "WRITE", "YEAR", "ZONE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  725 */   private static final String[] SQL2003_KEYWORDS = new String[] { "ABS", "ALL", "ALLOCATE", "ALTER", "AND", "ANY", "ARE", "ARRAY", "AS", "ASENSITIVE", "ASYMMETRIC", "AT", "ATOMIC", "AUTHORIZATION", "AVG", "BEGIN", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOOLEAN", "BOTH", "BY", "CALL", "CALLED", "CARDINALITY", "CASCADED", "CASE", "CAST", "CEIL", "CEILING", "CHAR", "CHARACTER", "CHARACTER_LENGTH", "CHAR_LENGTH", "CHECK", "CLOB", "CLOSE", "COALESCE", "COLLATE", "COLLECT", "COLUMN", "COMMIT", "CONDITION", "CONNECT", "CONSTRAINT", "CONVERT", "CORR", "CORRESPONDING", "COUNT", "COVAR_POP", "COVAR_SAMP", "CREATE", "CROSS", "CUBE", "CUME_DIST", "CURRENT", "CURRENT_DATE", "CURRENT_DEFAULT_TRANSFORM_GROUP", "CURRENT_PATH", "CURRENT_ROLE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_TRANSFORM_GROUP_FOR_TYPE", "CURRENT_USER", "CURSOR", "CYCLE", "DATE", "DAY", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELETE", "DENSE_RANK", "DEREF", "DESCRIBE", "DETERMINISTIC", "DISCONNECT", "DISTINCT", "DOUBLE", "DROP", "DYNAMIC", "EACH", "ELEMENT", "ELSE", "END", "END-EXEC", "ESCAPE", "EVERY", "EXCEPT", "EXEC", "EXECUTE", "EXISTS", "EXP", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FILTER", "FLOAT", "FLOOR", "FOR", "FOREIGN", "FREE", "FROM", "FULL", "FUNCTION", "FUSION", "GET", "GLOBAL", "GRANT", "GROUP", "GROUPING", "HAVING", "HOLD", "HOUR", "IDENTITY", "IN", "INDICATOR", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INTEGER", "INTERSECT", "INTERSECTION", "INTERVAL", "INTO", "IS", "JOIN", "LANGUAGE", "LARGE", "LATERAL", "LEADING", "LEFT", "LIKE", "LN", "LOCAL", "LOCALTIME", "LOCALTIMESTAMP", "LOWER", "MATCH", "MAX", "MEMBER", "MERGE", "METHOD", "MIN", "MINUTE", "MOD", "MODIFIES", "MODULE", "MONTH", "MULTISET", "NATIONAL", "NATURAL", "NCHAR", "NCLOB", "NEW", "NO", "NONE", "NORMALIZE", "NOT", "NULL", "NULLIF", "NUMERIC", "OCTET_LENGTH", "OF", "OLD", "ON", "ONLY", "OPEN", "OR", "ORDER", "OUT", "OUTER", "OVER", "OVERLAPS", "OVERLAY", "PARAMETER", "PARTITION", "PERCENTILE_CONT", "PERCENTILE_DISC", "PERCENT_RANK", "POSITION", "POWER", "PRECISION", "PREPARE", "PRIMARY", "PROCEDURE", "RANGE", "RANK", "READS", "REAL", "RECURSIVE", "REF", "REFERENCES", "REFERENCING", "REGR_AVGX", "REGR_AVGY", "REGR_COUNT", "REGR_INTERCEPT", "REGR_R2", "REGR_SLOPE", "REGR_SXX", "REGR_SXY", "REGR_SYY", "RELEASE", "RESULT", "RETURN", "RETURNS", "REVOKE", "RIGHT", "ROLLBACK", "ROLLUP", "ROW", "ROWS", "ROW_NUMBER", "SAVEPOINT", "SCOPE", "SCROLL", "SEARCH", "SECOND", "SELECT", "SENSITIVE", "SESSION_USER", "SET", "SIMILAR", "SMALLINT", "SOME", "SPECIFIC", "SPECIFICTYPE", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQRT", "START", "STATIC", "STDDEV_POP", "STDDEV_SAMP", "SUBMULTISET", "SUBSTRING", "SUM", "SYMMETRIC", "SYSTEM", "SYSTEM_USER", "TABLE", "TABLESAMPLE", "THEN", "TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TRANSLATE", "TRANSLATION", "TREAT", "TRIGGER", "TRIM", "TRUE", "UESCAPE", "UNION", "UNIQUE", "UNKNOWN", "UNNEST", "UPDATE", "UPPER", "USER", "USING", "VALUE", "VALUES", "VARCHAR", "VARYING", "VAR_POP", "VAR_SAMP", "WHEN", "WHENEVER", "WHERE", "WIDTH_BUCKET", "WINDOW", "WITH", "WITHIN", "WITHOUT", "YEAR" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  749 */   private static volatile String mysqlKeywords = null;
/*      */ 
/*      */   
/*      */   protected MySQLConnection conn;
/*      */ 
/*      */   
/*  755 */   protected String database = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String quotedId;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static DatabaseMetaData getInstance(MySQLConnection connToSet, String databaseToSet, boolean checkForInfoSchema) throws SQLException {
/*  772 */     if (!Util.isJdbc4()) {
/*  773 */       if (checkForInfoSchema && connToSet.getUseInformationSchema() && connToSet.versionMeetsMinimum(5, 0, 7)) {
/*  774 */         return new DatabaseMetaDataUsingInfoSchema(connToSet, databaseToSet);
/*      */       }
/*      */       
/*  777 */       return new DatabaseMetaData(connToSet, databaseToSet);
/*      */     } 
/*      */     
/*  780 */     if (checkForInfoSchema && connToSet.getUseInformationSchema() && connToSet.versionMeetsMinimum(5, 0, 7))
/*      */     {
/*  782 */       return (DatabaseMetaData)Util.handleNewInstance(JDBC_4_DBMD_IS_CTOR, new Object[] { connToSet, databaseToSet }, connToSet.getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/*  786 */     return (DatabaseMetaData)Util.handleNewInstance(JDBC_4_DBMD_SHOW_CTOR, new Object[] { connToSet, databaseToSet }, connToSet.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DatabaseMetaData(MySQLConnection connToSet, String databaseToSet) {
/*  796 */     this.conn = connToSet;
/*  797 */     this.database = databaseToSet;
/*  798 */     this.exceptionInterceptor = this.conn.getExceptionInterceptor();
/*      */     
/*  800 */     String identifierQuote = null;
/*      */     try {
/*  802 */       identifierQuote = getIdentifierQuoteString();
/*  803 */     } catch (SQLException sqlEx) {
/*      */       
/*  805 */       AssertionFailedException.shouldNotHappen(sqlEx);
/*      */     } finally {
/*  807 */       this.quotedId = identifierQuote;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean allProceduresAreCallable() throws SQLException {
/*  819 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean allTablesAreSelectable() throws SQLException {
/*  829 */     return false;
/*      */   }
/*      */   
/*      */   private ResultSet buildResultSet(Field[] fields, ArrayList<ResultSetRow> rows) throws SQLException {
/*  833 */     return buildResultSet(fields, rows, this.conn);
/*      */   }
/*      */   
/*      */   static ResultSet buildResultSet(Field[] fields, ArrayList<ResultSetRow> rows, MySQLConnection c) throws SQLException {
/*  837 */     int fieldsLength = fields.length;
/*      */     
/*  839 */     for (int i = 0; i < fieldsLength; i++) {
/*  840 */       int jdbcType = fields[i].getSQLType();
/*      */       
/*  842 */       switch (jdbcType) {
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/*  846 */           fields[i].setEncoding(c.getCharacterSetMetadata(), c);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  852 */       fields[i].setConnection(c);
/*  853 */       fields[i].setUseOldNameMetadata(true);
/*      */     } 
/*      */     
/*  856 */     return ResultSetImpl.getInstance(c.getCatalog(), fields, new RowDataStatic(rows), c, null, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertToJdbcFunctionList(String catalog, ResultSet proceduresRs, boolean needsClientFiltering, String db, List<ComparableWrapper<String, ResultSetRow>> procedureRows, int nameIndex, Field[] fields) throws SQLException {
/*  861 */     while (proceduresRs.next()) {
/*  862 */       boolean shouldAdd = true;
/*      */       
/*  864 */       if (needsClientFiltering) {
/*  865 */         shouldAdd = false;
/*      */         
/*  867 */         String procDb = proceduresRs.getString(1);
/*      */         
/*  869 */         if (db == null && procDb == null) {
/*  870 */           shouldAdd = true;
/*  871 */         } else if (db != null && db.equals(procDb)) {
/*  872 */           shouldAdd = true;
/*      */         } 
/*      */       } 
/*      */       
/*  876 */       if (shouldAdd) {
/*  877 */         String functionName = proceduresRs.getString(nameIndex);
/*      */         
/*  879 */         byte[][] rowData = (byte[][])null;
/*      */         
/*  881 */         if (fields != null && fields.length == 9) {
/*      */           
/*  883 */           rowData = new byte[9][];
/*  884 */           rowData[0] = (catalog == null) ? null : s2b(catalog);
/*  885 */           rowData[1] = null;
/*  886 */           rowData[2] = s2b(functionName);
/*  887 */           rowData[3] = null;
/*  888 */           rowData[4] = null;
/*  889 */           rowData[5] = null;
/*  890 */           rowData[6] = s2b(proceduresRs.getString("comment"));
/*  891 */           rowData[7] = s2b(Integer.toString(2));
/*  892 */           rowData[8] = s2b(functionName);
/*      */         } else {
/*      */           
/*  895 */           rowData = new byte[6][];
/*      */           
/*  897 */           rowData[0] = (catalog == null) ? null : s2b(catalog);
/*  898 */           rowData[1] = null;
/*  899 */           rowData[2] = s2b(functionName);
/*  900 */           rowData[3] = s2b(proceduresRs.getString("comment"));
/*  901 */           rowData[4] = s2b(Integer.toString(getJDBC4FunctionNoTableConstant()));
/*  902 */           rowData[5] = s2b(functionName);
/*      */         } 
/*      */         
/*  905 */         procedureRows.add(new ComparableWrapper<String, ResultSetRow>(getFullyQualifiedName(catalog, functionName), new ByteArrayRow(rowData, getExceptionInterceptor())));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFullyQualifiedName(String catalog, String entity) {
/*  915 */     StringBuilder fullyQualifiedName = new StringBuilder(StringUtils.quoteIdentifier((catalog == null) ? "" : catalog, this.quotedId, this.conn.getPedantic()));
/*      */     
/*  917 */     fullyQualifiedName.append('.');
/*  918 */     fullyQualifiedName.append(StringUtils.quoteIdentifier(entity, this.quotedId, this.conn.getPedantic()));
/*  919 */     return fullyQualifiedName.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getJDBC4FunctionNoTableConstant() {
/*  929 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertToJdbcProcedureList(boolean fromSelect, String catalog, ResultSet proceduresRs, boolean needsClientFiltering, String db, List<ComparableWrapper<String, ResultSetRow>> procedureRows, int nameIndex) throws SQLException {
/*  934 */     while (proceduresRs.next()) {
/*  935 */       boolean shouldAdd = true;
/*      */       
/*  937 */       if (needsClientFiltering) {
/*  938 */         shouldAdd = false;
/*      */         
/*  940 */         String procDb = proceduresRs.getString(1);
/*      */         
/*  942 */         if (db == null && procDb == null) {
/*  943 */           shouldAdd = true;
/*  944 */         } else if (db != null && db.equals(procDb)) {
/*  945 */           shouldAdd = true;
/*      */         } 
/*      */       } 
/*      */       
/*  949 */       if (shouldAdd) {
/*  950 */         String procedureName = proceduresRs.getString(nameIndex);
/*  951 */         byte[][] rowData = new byte[9][];
/*  952 */         rowData[0] = (catalog == null) ? null : s2b(catalog);
/*  953 */         rowData[1] = null;
/*  954 */         rowData[2] = s2b(procedureName);
/*  955 */         rowData[3] = null;
/*  956 */         rowData[4] = null;
/*  957 */         rowData[5] = null;
/*  958 */         rowData[6] = s2b(proceduresRs.getString("comment"));
/*      */         
/*  960 */         boolean isFunction = fromSelect ? "FUNCTION".equalsIgnoreCase(proceduresRs.getString("type")) : false;
/*  961 */         rowData[7] = s2b(isFunction ? Integer.toString(2) : Integer.toString(1));
/*      */         
/*  963 */         rowData[8] = s2b(procedureName);
/*      */         
/*  965 */         procedureRows.add(new ComparableWrapper<String, ResultSetRow>(getFullyQualifiedName(catalog, procedureName), new ByteArrayRow(rowData, getExceptionInterceptor())));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetRow convertTypeDescriptorToProcedureRow(byte[] procNameAsBytes, byte[] procCatAsBytes, String paramName, boolean isOutParam, boolean isInParam, boolean isReturnParam, TypeDescriptor typeDesc, boolean forGetFunctionColumns, int ordinal) throws SQLException {
/*  973 */     byte[][] row = forGetFunctionColumns ? new byte[17][] : new byte[20][];
/*  974 */     row[0] = procCatAsBytes;
/*  975 */     row[1] = null;
/*  976 */     row[2] = procNameAsBytes;
/*  977 */     row[3] = s2b(paramName);
/*  978 */     row[4] = s2b(String.valueOf(getColumnType(isOutParam, isInParam, isReturnParam, forGetFunctionColumns)));
/*  979 */     row[5] = s2b(Short.toString(typeDesc.dataType));
/*  980 */     row[6] = s2b(typeDesc.typeName);
/*  981 */     row[7] = (typeDesc.columnSize == null) ? null : s2b(typeDesc.columnSize.toString());
/*  982 */     row[8] = row[7];
/*  983 */     row[9] = (typeDesc.decimalDigits == null) ? null : s2b(typeDesc.decimalDigits.toString());
/*  984 */     row[10] = s2b(Integer.toString(typeDesc.numPrecRadix));
/*      */     
/*  986 */     switch (typeDesc.nullability) {
/*      */       case 0:
/*  988 */         row[11] = s2b(String.valueOf(0));
/*      */         break;
/*      */       
/*      */       case 1:
/*  992 */         row[11] = s2b(String.valueOf(1));
/*      */         break;
/*      */       
/*      */       case 2:
/*  996 */         row[11] = s2b(String.valueOf(2));
/*      */         break;
/*      */       
/*      */       default:
/* 1000 */         throw SQLError.createSQLException("Internal error while parsing callable statement metadata (unknown nullability value fount)", "S1000", getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/* 1004 */     row[12] = null;
/*      */     
/* 1006 */     if (forGetFunctionColumns) {
/*      */       
/* 1008 */       row[13] = null;
/*      */ 
/*      */       
/* 1011 */       row[14] = s2b(String.valueOf(ordinal));
/*      */ 
/*      */       
/* 1014 */       row[15] = s2b(typeDesc.isNullable);
/*      */ 
/*      */       
/* 1017 */       row[16] = procNameAsBytes;
/*      */     } else {
/*      */       
/* 1020 */       row[13] = null;
/*      */ 
/*      */       
/* 1023 */       row[14] = null;
/*      */ 
/*      */       
/* 1026 */       row[15] = null;
/*      */ 
/*      */       
/* 1029 */       row[16] = null;
/*      */ 
/*      */       
/* 1032 */       row[17] = s2b(String.valueOf(ordinal));
/*      */ 
/*      */       
/* 1035 */       row[18] = s2b(typeDesc.isNullable);
/*      */ 
/*      */       
/* 1038 */       row[19] = procNameAsBytes;
/*      */     } 
/*      */     
/* 1041 */     return new ByteArrayRow(row, getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getColumnType(boolean isOutParam, boolean isInParam, boolean isReturnParam, boolean forGetFunctionColumns) {
/* 1060 */     if (isInParam && isOutParam)
/* 1061 */       return 2; 
/* 1062 */     if (isInParam)
/* 1063 */       return 1; 
/* 1064 */     if (isOutParam)
/* 1065 */       return 4; 
/* 1066 */     if (isReturnParam) {
/* 1067 */       return 5;
/*      */     }
/* 1069 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 1076 */     return this.exceptionInterceptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dataDefinitionCausesTransactionCommit() throws SQLException {
/* 1087 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dataDefinitionIgnoredInTransactions() throws SQLException {
/* 1097 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deletesAreDetected(int type) throws SQLException {
/* 1112 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean doesMaxRowSizeIncludeBlobs() throws SQLException {
/* 1124 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<ResultSetRow> extractForeignKeyForTable(ArrayList<ResultSetRow> rows, ResultSet rs, String catalog) throws SQLException {
/* 1141 */     byte[][] row = new byte[3][];
/* 1142 */     row[0] = rs.getBytes(1);
/* 1143 */     row[1] = s2b("SUPPORTS_FK");
/*      */     
/* 1145 */     String createTableString = rs.getString(2);
/* 1146 */     StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
/* 1147 */     StringBuilder commentBuf = new StringBuilder("comment; ");
/* 1148 */     boolean firstTime = true;
/*      */     
/* 1150 */     while (lineTokenizer.hasMoreTokens()) {
/* 1151 */       String line = lineTokenizer.nextToken().trim();
/*      */       
/* 1153 */       String constraintName = null;
/*      */       
/* 1155 */       if (StringUtils.startsWithIgnoreCase(line, "CONSTRAINT")) {
/* 1156 */         boolean usingBackTicks = true;
/* 1157 */         int beginPos = StringUtils.indexOfQuoteDoubleAware(line, this.quotedId, 0);
/*      */         
/* 1159 */         if (beginPos == -1) {
/* 1160 */           beginPos = line.indexOf("\"");
/* 1161 */           usingBackTicks = false;
/*      */         } 
/*      */         
/* 1164 */         if (beginPos != -1) {
/* 1165 */           int endPos = -1;
/*      */           
/* 1167 */           if (usingBackTicks) {
/* 1168 */             endPos = StringUtils.indexOfQuoteDoubleAware(line, this.quotedId, beginPos + 1);
/*      */           } else {
/* 1170 */             endPos = StringUtils.indexOfQuoteDoubleAware(line, "\"", beginPos + 1);
/*      */           } 
/*      */           
/* 1173 */           if (endPos != -1) {
/* 1174 */             constraintName = line.substring(beginPos + 1, endPos);
/* 1175 */             line = line.substring(endPos + 1, line.length()).trim();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1180 */       if (line.startsWith("FOREIGN KEY")) {
/* 1181 */         if (line.endsWith(",")) {
/* 1182 */           line = line.substring(0, line.length() - 1);
/*      */         }
/*      */         
/* 1185 */         int indexOfFK = line.indexOf("FOREIGN KEY");
/*      */         
/* 1187 */         String localColumnName = null;
/* 1188 */         String referencedCatalogName = StringUtils.quoteIdentifier(catalog, this.quotedId, this.conn.getPedantic());
/* 1189 */         String referencedTableName = null;
/* 1190 */         String referencedColumnName = null;
/*      */         
/* 1192 */         if (indexOfFK != -1) {
/* 1193 */           int afterFk = indexOfFK + "FOREIGN KEY".length();
/*      */           
/* 1195 */           int indexOfRef = StringUtils.indexOfIgnoreCase(afterFk, line, "REFERENCES", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */           
/* 1197 */           if (indexOfRef != -1) {
/*      */             
/* 1199 */             int indexOfParenOpen = line.indexOf('(', afterFk);
/* 1200 */             int indexOfParenClose = StringUtils.indexOfIgnoreCase(indexOfParenOpen, line, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */             
/* 1203 */             if (indexOfParenOpen == -1 || indexOfParenClose == -1);
/*      */ 
/*      */ 
/*      */             
/* 1207 */             localColumnName = line.substring(indexOfParenOpen + 1, indexOfParenClose);
/*      */             
/* 1209 */             int afterRef = indexOfRef + "REFERENCES".length();
/*      */             
/* 1211 */             int referencedColumnBegin = StringUtils.indexOfIgnoreCase(afterRef, line, "(", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */             
/* 1214 */             if (referencedColumnBegin != -1) {
/* 1215 */               referencedTableName = line.substring(afterRef, referencedColumnBegin);
/*      */               
/* 1217 */               int referencedColumnEnd = StringUtils.indexOfIgnoreCase(referencedColumnBegin + 1, line, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */               
/* 1220 */               if (referencedColumnEnd != -1) {
/* 1221 */                 referencedColumnName = line.substring(referencedColumnBegin + 1, referencedColumnEnd);
/*      */               }
/*      */               
/* 1224 */               int indexOfCatalogSep = StringUtils.indexOfIgnoreCase(0, referencedTableName, ".", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */               
/* 1227 */               if (indexOfCatalogSep != -1) {
/* 1228 */                 referencedCatalogName = referencedTableName.substring(0, indexOfCatalogSep);
/* 1229 */                 referencedTableName = referencedTableName.substring(indexOfCatalogSep + 1);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 1235 */         if (!firstTime) {
/* 1236 */           commentBuf.append("; ");
/*      */         } else {
/* 1238 */           firstTime = false;
/*      */         } 
/*      */         
/* 1241 */         if (constraintName != null) {
/* 1242 */           commentBuf.append(constraintName);
/*      */         } else {
/* 1244 */           commentBuf.append("not_available");
/*      */         } 
/*      */         
/* 1247 */         commentBuf.append("(");
/* 1248 */         commentBuf.append(localColumnName);
/* 1249 */         commentBuf.append(") REFER ");
/* 1250 */         commentBuf.append(referencedCatalogName);
/* 1251 */         commentBuf.append("/");
/* 1252 */         commentBuf.append(referencedTableName);
/* 1253 */         commentBuf.append("(");
/* 1254 */         commentBuf.append(referencedColumnName);
/* 1255 */         commentBuf.append(")");
/*      */         
/* 1257 */         int lastParenIndex = line.lastIndexOf(")");
/*      */         
/* 1259 */         if (lastParenIndex != line.length() - 1) {
/* 1260 */           String cascadeOptions = line.substring(lastParenIndex + 1);
/* 1261 */           commentBuf.append(" ");
/* 1262 */           commentBuf.append(cascadeOptions);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1267 */     row[2] = s2b(commentBuf.toString());
/* 1268 */     rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */     
/* 1270 */     return rows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet extractForeignKeyFromCreateTable(String catalog, String tableName) throws SQLException {
/* 1290 */     ArrayList<String> tableList = new ArrayList<String>();
/* 1291 */     ResultSet rs = null;
/* 1292 */     Statement stmt = null;
/*      */     
/* 1294 */     if (tableName != null) {
/* 1295 */       tableList.add(tableName);
/*      */     } else {
/*      */       try {
/* 1298 */         rs = getTables(catalog, "", "%", new String[] { "TABLE" });
/*      */         
/* 1300 */         while (rs.next()) {
/* 1301 */           tableList.add(rs.getString("TABLE_NAME"));
/*      */         }
/*      */       } finally {
/* 1304 */         if (rs != null) {
/* 1305 */           rs.close();
/*      */         }
/*      */         
/* 1308 */         rs = null;
/*      */       } 
/*      */     } 
/*      */     
/* 1312 */     ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/* 1313 */     Field[] fields = new Field[3];
/* 1314 */     fields[0] = new Field("", "Name", 1, 2147483647);
/* 1315 */     fields[1] = new Field("", "Type", 1, 255);
/* 1316 */     fields[2] = new Field("", "Comment", 1, 2147483647);
/*      */     
/* 1318 */     int numTables = tableList.size();
/* 1319 */     stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try {
/* 1322 */       for (int i = 0; i < numTables; i++) {
/* 1323 */         String tableToExtract = tableList.get(i);
/*      */         
/* 1325 */         String query = "SHOW CREATE TABLE " + getFullyQualifiedName(catalog, tableToExtract);
/*      */         
/*      */         try {
/* 1328 */           rs = stmt.executeQuery(query);
/* 1329 */         } catch (SQLException sqlEx) {
/*      */           
/* 1331 */           String sqlState = sqlEx.getSQLState();
/*      */           
/* 1333 */           if (!"42S02".equals(sqlState) && sqlEx.getErrorCode() != 1146) {
/* 1334 */             throw sqlEx;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1340 */         while (rs.next()) {
/* 1341 */           extractForeignKeyForTable(rows, rs, catalog);
/*      */         }
/*      */       } 
/*      */     } finally {
/* 1345 */       if (rs != null) {
/* 1346 */         rs.close();
/*      */       }
/*      */       
/* 1349 */       rs = null;
/*      */       
/* 1351 */       if (stmt != null) {
/* 1352 */         stmt.close();
/*      */       }
/*      */       
/* 1355 */       stmt = null;
/*      */     } 
/*      */     
/* 1358 */     return buildResultSet(fields, rows);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3) throws SQLException {
/* 1365 */     Field[] fields = new Field[21];
/* 1366 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/* 1367 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/* 1368 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 1369 */     fields[3] = new Field("", "ATTR_NAME", 1, 32);
/* 1370 */     fields[4] = new Field("", "DATA_TYPE", 5, 32);
/* 1371 */     fields[5] = new Field("", "ATTR_TYPE_NAME", 1, 32);
/* 1372 */     fields[6] = new Field("", "ATTR_SIZE", 4, 32);
/* 1373 */     fields[7] = new Field("", "DECIMAL_DIGITS", 4, 32);
/* 1374 */     fields[8] = new Field("", "NUM_PREC_RADIX", 4, 32);
/* 1375 */     fields[9] = new Field("", "NULLABLE ", 4, 32);
/* 1376 */     fields[10] = new Field("", "REMARKS", 1, 32);
/* 1377 */     fields[11] = new Field("", "ATTR_DEF", 1, 32);
/* 1378 */     fields[12] = new Field("", "SQL_DATA_TYPE", 4, 32);
/* 1379 */     fields[13] = new Field("", "SQL_DATETIME_SUB", 4, 32);
/* 1380 */     fields[14] = new Field("", "CHAR_OCTET_LENGTH", 4, 32);
/* 1381 */     fields[15] = new Field("", "ORDINAL_POSITION", 4, 32);
/* 1382 */     fields[16] = new Field("", "IS_NULLABLE", 1, 32);
/* 1383 */     fields[17] = new Field("", "SCOPE_CATALOG", 1, 32);
/* 1384 */     fields[18] = new Field("", "SCOPE_SCHEMA", 1, 32);
/* 1385 */     fields[19] = new Field("", "SCOPE_TABLE", 1, 32);
/* 1386 */     fields[20] = new Field("", "SOURCE_DATA_TYPE", 5, 32);
/*      */     
/* 1388 */     return buildResultSet(fields, new ArrayList<ResultSetRow>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getBestRowIdentifier(String catalog, String schema, final String table, int scope, boolean nullable) throws SQLException {
/* 1434 */     if (table == null) {
/* 1435 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1438 */     Field[] fields = new Field[8];
/* 1439 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 1440 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 1441 */     fields[2] = new Field("", "DATA_TYPE", 4, 32);
/* 1442 */     fields[3] = new Field("", "TYPE_NAME", 1, 32);
/* 1443 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 10);
/* 1444 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 1445 */     fields[6] = new Field("", "DECIMAL_DIGITS", 5, 10);
/* 1446 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */     
/* 1448 */     final ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/* 1449 */     final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */     
/*      */     try {
/* 1453 */       (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException {
/* 1456 */             ResultSet results = null;
/*      */             
/*      */             try {
/* 1459 */               StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
/* 1460 */               queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 1461 */               queryBuf.append(" FROM ");
/* 1462 */               queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */               
/* 1464 */               results = stmt.executeQuery(queryBuf.toString());
/*      */               
/* 1466 */               while (results.next()) {
/* 1467 */                 String keyType = results.getString("Key");
/*      */                 
/* 1469 */                 if (keyType != null && 
/* 1470 */                   StringUtils.startsWithIgnoreCase(keyType, "PRI")) {
/* 1471 */                   byte[][] rowVal = new byte[8][];
/* 1472 */                   rowVal[0] = Integer.toString(2).getBytes();
/* 1473 */                   rowVal[1] = results.getBytes("Field");
/*      */                   
/* 1475 */                   String type = results.getString("Type");
/* 1476 */                   int size = MysqlIO.getMaxBuf();
/* 1477 */                   int decimals = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1482 */                   if (type.indexOf("enum") != -1) {
/* 1483 */                     String temp = type.substring(type.indexOf("("), type.indexOf(")"));
/* 1484 */                     StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/* 1485 */                     int maxLength = 0;
/*      */                     
/* 1487 */                     while (tokenizer.hasMoreTokens()) {
/* 1488 */                       maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */                     }
/*      */                     
/* 1491 */                     size = maxLength;
/* 1492 */                     decimals = 0;
/* 1493 */                     type = "enum";
/* 1494 */                   } else if (type.indexOf("(") != -1) {
/* 1495 */                     if (type.indexOf(",") != -1) {
/* 1496 */                       size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(",")));
/* 1497 */                       decimals = Integer.parseInt(type.substring(type.indexOf(",") + 1, type.indexOf(")")));
/*      */                     } else {
/* 1499 */                       size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(")")));
/*      */                     } 
/*      */                     
/* 1502 */                     type = type.substring(0, type.indexOf("("));
/*      */                   } 
/*      */                   
/* 1505 */                   rowVal[2] = DatabaseMetaData.this.s2b(String.valueOf(MysqlDefs.mysqlToJavaType(type)));
/* 1506 */                   rowVal[3] = DatabaseMetaData.this.s2b(type);
/* 1507 */                   rowVal[4] = Integer.toString(size + decimals).getBytes();
/* 1508 */                   rowVal[5] = Integer.toString(size + decimals).getBytes();
/* 1509 */                   rowVal[6] = Integer.toString(decimals).getBytes();
/* 1510 */                   rowVal[7] = Integer.toString(1).getBytes();
/*      */                   
/* 1512 */                   rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                 }
/*      */               
/*      */               } 
/* 1516 */             } catch (SQLException sqlEx) {
/* 1517 */               if (!"42S02".equals(sqlEx.getSQLState())) {
/* 1518 */                 throw sqlEx;
/*      */               }
/*      */             } finally {
/* 1521 */               if (results != null) {
/*      */                 try {
/* 1523 */                   results.close();
/* 1524 */                 } catch (Exception ex) {}
/*      */ 
/*      */                 
/* 1527 */                 results = null;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         }).doForAll();
/*      */     } finally {
/* 1533 */       if (stmt != null) {
/* 1534 */         stmt.close();
/*      */       }
/*      */     } 
/*      */     
/* 1538 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 1540 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getCallStmtParameterTypes(String catalog, String quotedProcName, ProcedureType procType, String parameterNamePattern, List<ResultSetRow> resultRows, boolean forGetFunctionColumns) throws SQLException {
/* 1552 */     Statement paramRetrievalStmt = null;
/* 1553 */     ResultSet paramRetrievalRs = null;
/*      */     
/* 1555 */     if (parameterNamePattern == null) {
/* 1556 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1557 */         parameterNamePattern = "%";
/*      */       } else {
/* 1559 */         throw SQLError.createSQLException("Parameter/Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1564 */     String parameterDef = null;
/*      */     
/* 1566 */     byte[] procNameAsBytes = null;
/* 1567 */     byte[] procCatAsBytes = null;
/*      */     
/* 1569 */     boolean isProcedureInAnsiMode = false;
/* 1570 */     String storageDefnDelims = null;
/* 1571 */     String storageDefnClosures = null;
/*      */     
/*      */     try {
/* 1574 */       paramRetrievalStmt = this.conn.getMetadataSafeStatement();
/*      */       
/* 1576 */       String oldCatalog = this.conn.getCatalog();
/* 1577 */       if (this.conn.lowerCaseTableNames() && catalog != null && catalog.length() != 0 && oldCatalog != null && oldCatalog.length() != 0) {
/*      */ 
/*      */         
/* 1580 */         ResultSet rs = null;
/*      */         
/*      */         try {
/* 1583 */           this.conn.setCatalog(StringUtils.unQuoteIdentifier(catalog, this.quotedId));
/* 1584 */           rs = paramRetrievalStmt.executeQuery("SELECT DATABASE()");
/* 1585 */           rs.next();
/*      */           
/* 1587 */           catalog = rs.getString(1);
/*      */         }
/*      */         finally {
/*      */           
/* 1591 */           this.conn.setCatalog(oldCatalog);
/*      */           
/* 1593 */           if (rs != null) {
/* 1594 */             rs.close();
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1599 */       if (paramRetrievalStmt.getMaxRows() != 0) {
/* 1600 */         paramRetrievalStmt.setMaxRows(0);
/*      */       }
/*      */       
/* 1603 */       int dotIndex = -1;
/*      */       
/* 1605 */       if (!" ".equals(this.quotedId)) {
/* 1606 */         dotIndex = StringUtils.indexOfIgnoreCase(0, quotedProcName, ".", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */       } else {
/*      */         
/* 1609 */         dotIndex = quotedProcName.indexOf(".");
/*      */       } 
/*      */       
/* 1612 */       String dbName = null;
/*      */       
/* 1614 */       if (dotIndex != -1 && dotIndex + 1 < quotedProcName.length()) {
/* 1615 */         dbName = quotedProcName.substring(0, dotIndex);
/* 1616 */         quotedProcName = quotedProcName.substring(dotIndex + 1);
/*      */       } else {
/* 1618 */         dbName = StringUtils.quoteIdentifier(catalog, this.quotedId, this.conn.getPedantic());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1623 */       String tmpProcName = StringUtils.unQuoteIdentifier(quotedProcName, this.quotedId);
/*      */       try {
/* 1625 */         procNameAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
/* 1626 */       } catch (UnsupportedEncodingException ueEx) {
/* 1627 */         procNameAsBytes = s2b(tmpProcName);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1632 */       tmpProcName = StringUtils.unQuoteIdentifier(dbName, this.quotedId);
/*      */       try {
/* 1634 */         procCatAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
/* 1635 */       } catch (UnsupportedEncodingException ueEx) {
/* 1636 */         procCatAsBytes = s2b(tmpProcName);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1642 */       StringBuilder procNameBuf = new StringBuilder();
/* 1643 */       procNameBuf.append(dbName);
/* 1644 */       procNameBuf.append('.');
/* 1645 */       procNameBuf.append(quotedProcName);
/*      */       
/* 1647 */       String fieldName = null;
/* 1648 */       if (procType == ProcedureType.PROCEDURE) {
/* 1649 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE PROCEDURE " + procNameBuf.toString());
/* 1650 */         fieldName = "Create Procedure";
/*      */       } else {
/* 1652 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE FUNCTION " + procNameBuf.toString());
/* 1653 */         fieldName = "Create Function";
/*      */       } 
/*      */       
/* 1656 */       if (paramRetrievalRs.next()) {
/* 1657 */         String procedureDef = paramRetrievalRs.getString(fieldName);
/*      */         
/* 1659 */         if (!this.conn.getNoAccessToProcedureBodies() && (procedureDef == null || procedureDef.length() == 0)) {
/* 1660 */           throw SQLError.createSQLException("User does not have access to metadata required to determine stored procedure parameter types. If rights can not be granted, configure connection with \"noAccessToProcedureBodies=true\" to have driver generate parameters that represent INOUT strings irregardless of actual parameter types.", "S1000", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1668 */           String sqlMode = paramRetrievalRs.getString("sql_mode");
/*      */           
/* 1670 */           if (StringUtils.indexOfIgnoreCase(sqlMode, "ANSI") != -1) {
/* 1671 */             isProcedureInAnsiMode = true;
/*      */           }
/* 1673 */         } catch (SQLException sqlEx) {}
/*      */ 
/*      */ 
/*      */         
/* 1677 */         String identifierMarkers = isProcedureInAnsiMode ? "`\"" : "`";
/* 1678 */         String identifierAndStringMarkers = "'" + identifierMarkers;
/* 1679 */         storageDefnDelims = "(" + identifierMarkers;
/* 1680 */         storageDefnClosures = ")" + identifierMarkers;
/*      */         
/* 1682 */         if (procedureDef != null && procedureDef.length() != 0) {
/*      */           
/* 1684 */           procedureDef = StringUtils.stripComments(procedureDef, identifierAndStringMarkers, identifierAndStringMarkers, true, false, true, true);
/*      */           
/* 1686 */           int openParenIndex = StringUtils.indexOfIgnoreCase(0, procedureDef, "(", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */           
/* 1688 */           int endOfParamDeclarationIndex = 0;
/*      */           
/* 1690 */           endOfParamDeclarationIndex = endPositionOfParameterDeclaration(openParenIndex, procedureDef, this.quotedId);
/*      */           
/* 1692 */           if (procType == ProcedureType.FUNCTION) {
/*      */ 
/*      */ 
/*      */             
/* 1696 */             int returnsIndex = StringUtils.indexOfIgnoreCase(0, procedureDef, " RETURNS ", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */             
/* 1699 */             int endReturnsDef = findEndOfReturnsClause(procedureDef, returnsIndex);
/*      */ 
/*      */ 
/*      */             
/* 1703 */             int declarationStart = returnsIndex + "RETURNS ".length();
/*      */             
/* 1705 */             while (declarationStart < procedureDef.length() && 
/* 1706 */               Character.isWhitespace(procedureDef.charAt(declarationStart))) {
/* 1707 */               declarationStart++;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1713 */             String returnsDefn = procedureDef.substring(declarationStart, endReturnsDef).trim();
/* 1714 */             TypeDescriptor returnDescriptor = new TypeDescriptor(returnsDefn, "YES");
/*      */             
/* 1716 */             resultRows.add(convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, "", false, false, true, returnDescriptor, forGetFunctionColumns, 0));
/*      */           } 
/*      */ 
/*      */           
/* 1720 */           if (openParenIndex == -1 || endOfParamDeclarationIndex == -1)
/*      */           {
/* 1722 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */           
/* 1726 */           parameterDef = procedureDef.substring(openParenIndex + 1, endOfParamDeclarationIndex);
/*      */         } 
/*      */       } 
/*      */     } finally {
/*      */       
/* 1731 */       SQLException sqlExRethrow = null;
/*      */       
/* 1733 */       if (paramRetrievalRs != null) {
/*      */         try {
/* 1735 */           paramRetrievalRs.close();
/* 1736 */         } catch (SQLException sqlEx) {
/* 1737 */           sqlExRethrow = sqlEx;
/*      */         } 
/*      */         
/* 1740 */         paramRetrievalRs = null;
/*      */       } 
/*      */       
/* 1743 */       if (paramRetrievalStmt != null) {
/*      */         try {
/* 1745 */           paramRetrievalStmt.close();
/* 1746 */         } catch (SQLException sqlEx) {
/* 1747 */           sqlExRethrow = sqlEx;
/*      */         } 
/*      */         
/* 1750 */         paramRetrievalStmt = null;
/*      */       } 
/*      */       
/* 1753 */       if (sqlExRethrow != null) {
/* 1754 */         throw sqlExRethrow;
/*      */       }
/*      */     } 
/*      */     
/* 1758 */     if (parameterDef != null) {
/* 1759 */       int ordinal = 1;
/*      */       
/* 1761 */       List<String> parseList = StringUtils.split(parameterDef, ",", storageDefnDelims, storageDefnClosures, true);
/*      */       
/* 1763 */       int parseListLen = parseList.size();
/*      */       
/* 1765 */       for (int i = 0; i < parseListLen; i++) {
/* 1766 */         String declaration = parseList.get(i);
/*      */         
/* 1768 */         if (declaration.trim().length() == 0) {
/*      */           break;
/*      */         }
/*      */ 
/*      */         
/* 1773 */         declaration = declaration.replaceAll("[\\t\\n\\x0B\\f\\r]", " ");
/* 1774 */         StringTokenizer declarationTok = new StringTokenizer(declaration, " \t");
/*      */         
/* 1776 */         String paramName = null;
/* 1777 */         boolean isOutParam = false;
/* 1778 */         boolean isInParam = false;
/*      */         
/* 1780 */         if (declarationTok.hasMoreTokens()) {
/* 1781 */           String possibleParamName = declarationTok.nextToken();
/*      */           
/* 1783 */           if (possibleParamName.equalsIgnoreCase("OUT")) {
/* 1784 */             isOutParam = true;
/*      */             
/* 1786 */             if (declarationTok.hasMoreTokens()) {
/* 1787 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1789 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           
/* 1792 */           } else if (possibleParamName.equalsIgnoreCase("INOUT")) {
/* 1793 */             isOutParam = true;
/* 1794 */             isInParam = true;
/*      */             
/* 1796 */             if (declarationTok.hasMoreTokens()) {
/* 1797 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1799 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           
/* 1802 */           } else if (possibleParamName.equalsIgnoreCase("IN")) {
/* 1803 */             isOutParam = false;
/* 1804 */             isInParam = true;
/*      */             
/* 1806 */             if (declarationTok.hasMoreTokens()) {
/* 1807 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1809 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             } 
/*      */           } else {
/*      */             
/* 1813 */             isOutParam = false;
/* 1814 */             isInParam = true;
/*      */             
/* 1816 */             paramName = possibleParamName;
/*      */           } 
/*      */           
/* 1819 */           TypeDescriptor typeDesc = null;
/*      */           
/* 1821 */           if (declarationTok.hasMoreTokens()) {
/* 1822 */             StringBuilder typeInfoBuf = new StringBuilder(declarationTok.nextToken());
/*      */             
/* 1824 */             while (declarationTok.hasMoreTokens()) {
/* 1825 */               typeInfoBuf.append(" ");
/* 1826 */               typeInfoBuf.append(declarationTok.nextToken());
/*      */             } 
/*      */             
/* 1829 */             String typeInfo = typeInfoBuf.toString();
/*      */             
/* 1831 */             typeDesc = new TypeDescriptor(typeInfo, "YES");
/*      */           } else {
/* 1833 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter type)", "S1000", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */           
/* 1837 */           if ((paramName.startsWith("`") && paramName.endsWith("`")) || (isProcedureInAnsiMode && paramName.startsWith("\"") && paramName.endsWith("\"")))
/*      */           {
/* 1839 */             paramName = paramName.substring(1, paramName.length() - 1);
/*      */           }
/*      */           
/* 1842 */           if (StringUtils.wildCompareIgnoreCase(paramName, parameterNamePattern)) {
/* 1843 */             ResultSetRow row = convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, paramName, isOutParam, isInParam, false, typeDesc, forGetFunctionColumns, ordinal++);
/*      */ 
/*      */             
/* 1846 */             resultRows.add(row);
/*      */           } 
/*      */         } else {
/* 1849 */           throw SQLError.createSQLException("Internal error when parsing callable statement metadata (unknown output from 'SHOW CREATE PROCEDURE')", "S1000", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int endPositionOfParameterDeclaration(int beginIndex, String procedureDef, String quoteChar) throws SQLException {
/* 1875 */     int currentPos = beginIndex + 1;
/* 1876 */     int parenDepth = 1;
/*      */     
/* 1878 */     while (parenDepth > 0 && currentPos < procedureDef.length()) {
/* 1879 */       int closedParenIndex = StringUtils.indexOfIgnoreCase(currentPos, procedureDef, ")", quoteChar, quoteChar, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */       
/* 1882 */       if (closedParenIndex != -1) {
/* 1883 */         int nextOpenParenIndex = StringUtils.indexOfIgnoreCase(currentPos, procedureDef, "(", quoteChar, quoteChar, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */         
/* 1886 */         if (nextOpenParenIndex != -1 && nextOpenParenIndex < closedParenIndex) {
/* 1887 */           parenDepth++;
/* 1888 */           currentPos = closedParenIndex + 1; continue;
/*      */         } 
/* 1890 */         parenDepth--;
/* 1891 */         currentPos = closedParenIndex;
/*      */         
/*      */         continue;
/*      */       } 
/* 1895 */       throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1900 */     return currentPos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int findEndOfReturnsClause(String procedureDefn, int positionOfReturnKeyword) throws SQLException {
/* 1923 */     String openingMarkers = this.quotedId + "(";
/* 1924 */     String closingMarkers = this.quotedId + ")";
/*      */     
/* 1926 */     String[] tokens = { "LANGUAGE", "NOT", "DETERMINISTIC", "CONTAINS", "NO", "READ", "MODIFIES", "SQL", "COMMENT", "BEGIN", "RETURN" };
/*      */     
/* 1928 */     int startLookingAt = positionOfReturnKeyword + "RETURNS".length() + 1;
/*      */     
/* 1930 */     int endOfReturn = -1;
/*      */     int i;
/* 1932 */     for (i = 0; i < tokens.length; i++) {
/* 1933 */       int nextEndOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, tokens[i], openingMarkers, closingMarkers, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */       
/* 1936 */       if (nextEndOfReturn != -1 && (
/* 1937 */         endOfReturn == -1 || nextEndOfReturn < endOfReturn)) {
/* 1938 */         endOfReturn = nextEndOfReturn;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1943 */     if (endOfReturn != -1) {
/* 1944 */       return endOfReturn;
/*      */     }
/*      */ 
/*      */     
/* 1948 */     endOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, ":", openingMarkers, closingMarkers, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */     
/* 1951 */     if (endOfReturn != -1)
/*      */     {
/* 1953 */       for (i = endOfReturn; i > 0; i--) {
/* 1954 */         if (Character.isWhitespace(procedureDefn.charAt(i))) {
/* 1955 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1962 */     throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getCascadeDeleteOption(String cascadeOptions) {
/* 1975 */     int onDeletePos = cascadeOptions.indexOf("ON DELETE");
/*      */     
/* 1977 */     if (onDeletePos != -1) {
/* 1978 */       String deleteOptions = cascadeOptions.substring(onDeletePos, cascadeOptions.length());
/*      */       
/* 1980 */       if (deleteOptions.startsWith("ON DELETE CASCADE"))
/* 1981 */         return 0; 
/* 1982 */       if (deleteOptions.startsWith("ON DELETE SET NULL"))
/* 1983 */         return 2; 
/* 1984 */       if (deleteOptions.startsWith("ON DELETE RESTRICT"))
/* 1985 */         return 1; 
/* 1986 */       if (deleteOptions.startsWith("ON DELETE NO ACTION")) {
/* 1987 */         return 3;
/*      */       }
/*      */     } 
/*      */     
/* 1991 */     return 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getCascadeUpdateOption(String cascadeOptions) {
/* 2003 */     int onUpdatePos = cascadeOptions.indexOf("ON UPDATE");
/*      */     
/* 2005 */     if (onUpdatePos != -1) {
/* 2006 */       String updateOptions = cascadeOptions.substring(onUpdatePos, cascadeOptions.length());
/*      */       
/* 2008 */       if (updateOptions.startsWith("ON UPDATE CASCADE"))
/* 2009 */         return 0; 
/* 2010 */       if (updateOptions.startsWith("ON UPDATE SET NULL"))
/* 2011 */         return 2; 
/* 2012 */       if (updateOptions.startsWith("ON UPDATE RESTRICT"))
/* 2013 */         return 1; 
/* 2014 */       if (updateOptions.startsWith("ON UPDATE NO ACTION")) {
/* 2015 */         return 3;
/*      */       }
/*      */     } 
/*      */     
/* 2019 */     return 3;
/*      */   }
/*      */   
/*      */   protected IteratorWithCleanup<String> getCatalogIterator(String catalogSpec) throws SQLException {
/*      */     IteratorWithCleanup<String> allCatalogsIter;
/* 2024 */     if (catalogSpec != null) {
/* 2025 */       if (!catalogSpec.equals("")) {
/* 2026 */         if (this.conn.getPedantic()) {
/* 2027 */           allCatalogsIter = new SingleStringIterator(catalogSpec);
/*      */         } else {
/* 2029 */           allCatalogsIter = new SingleStringIterator(StringUtils.unQuoteIdentifier(catalogSpec, this.quotedId));
/*      */         } 
/*      */       } else {
/*      */         
/* 2033 */         allCatalogsIter = new SingleStringIterator(this.database);
/*      */       } 
/* 2035 */     } else if (this.conn.getNullCatalogMeansCurrent()) {
/*      */       
/* 2037 */       allCatalogsIter = new SingleStringIterator(this.database);
/*      */     } else {
/* 2039 */       allCatalogsIter = new ResultSetIterator(getCatalogs(), 1);
/*      */     } 
/*      */     
/* 2042 */     return allCatalogsIter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCatalogs() throws SQLException {
/* 2060 */     ResultSet results = null;
/* 2061 */     Statement stmt = null;
/*      */     
/*      */     try {
/* 2064 */       stmt = this.conn.getMetadataSafeStatement();
/* 2065 */       results = stmt.executeQuery("SHOW DATABASES");
/*      */       
/* 2067 */       int catalogsCount = 0;
/* 2068 */       if (results.last()) {
/* 2069 */         catalogsCount = results.getRow();
/* 2070 */         results.beforeFirst();
/*      */       } 
/*      */       
/* 2073 */       List<String> resultsAsList = new ArrayList<String>(catalogsCount);
/* 2074 */       while (results.next()) {
/* 2075 */         resultsAsList.add(results.getString(1));
/*      */       }
/* 2077 */       Collections.sort(resultsAsList);
/*      */       
/* 2079 */       Field[] fields = new Field[1];
/* 2080 */       fields[0] = new Field("", "TABLE_CAT", 12, results.getMetaData().getColumnDisplaySize(1));
/*      */       
/* 2082 */       ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>(catalogsCount);
/* 2083 */       for (String cat : resultsAsList) {
/* 2084 */         byte[][] rowVal = new byte[1][];
/* 2085 */         rowVal[0] = s2b(cat);
/* 2086 */         tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */       } 
/*      */       
/* 2089 */       return buildResultSet(fields, tuples);
/*      */     } finally {
/* 2091 */       if (results != null) {
/*      */         try {
/* 2093 */           results.close();
/* 2094 */         } catch (SQLException sqlEx) {
/* 2095 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         } 
/*      */         
/* 2098 */         results = null;
/*      */       } 
/*      */       
/* 2101 */       if (stmt != null) {
/*      */         try {
/* 2103 */           stmt.close();
/* 2104 */         } catch (SQLException sqlEx) {
/* 2105 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         } 
/*      */         
/* 2108 */         stmt = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalogSeparator() throws SQLException {
/* 2120 */     return ".";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalogTerm() throws SQLException {
/* 2133 */     return "database";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern) throws SQLException {
/* 2169 */     Field[] fields = new Field[8];
/* 2170 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 2171 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 2172 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 2173 */     fields[3] = new Field("", "COLUMN_NAME", 1, 64);
/* 2174 */     fields[4] = new Field("", "GRANTOR", 1, 77);
/* 2175 */     fields[5] = new Field("", "GRANTEE", 1, 77);
/* 2176 */     fields[6] = new Field("", "PRIVILEGE", 1, 64);
/* 2177 */     fields[7] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */     
/* 2179 */     String grantQuery = "SELECT c.host, c.db, t.grantor, c.user, c.table_name, c.column_name, c.column_priv FROM mysql.columns_priv c, mysql.tables_priv t WHERE c.host = t.host AND c.db = t.db AND c.table_name = t.table_name AND c.db LIKE ? AND c.table_name = ? AND c.column_name LIKE ?";
/*      */ 
/*      */ 
/*      */     
/* 2183 */     PreparedStatement pStmt = null;
/* 2184 */     ResultSet results = null;
/* 2185 */     ArrayList<ResultSetRow> grantRows = new ArrayList<ResultSetRow>();
/*      */     
/*      */     try {
/* 2188 */       pStmt = prepareMetaDataSafeStatement(grantQuery);
/*      */       
/* 2190 */       pStmt.setString(1, (catalog != null && catalog.length() != 0) ? catalog : "%");
/* 2191 */       pStmt.setString(2, table);
/* 2192 */       pStmt.setString(3, columnNamePattern);
/*      */       
/* 2194 */       results = pStmt.executeQuery();
/*      */       
/* 2196 */       while (results.next()) {
/* 2197 */         String host = results.getString(1);
/* 2198 */         String db = results.getString(2);
/* 2199 */         String grantor = results.getString(3);
/* 2200 */         String user = results.getString(4);
/*      */         
/* 2202 */         if (user == null || user.length() == 0) {
/* 2203 */           user = "%";
/*      */         }
/*      */         
/* 2206 */         StringBuilder fullUser = new StringBuilder(user);
/*      */         
/* 2208 */         if (host != null && this.conn.getUseHostsInPrivileges()) {
/* 2209 */           fullUser.append("@");
/* 2210 */           fullUser.append(host);
/*      */         } 
/*      */         
/* 2213 */         String columnName = results.getString(6);
/* 2214 */         String allPrivileges = results.getString(7);
/*      */         
/* 2216 */         if (allPrivileges != null) {
/* 2217 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */           
/* 2219 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */           
/* 2221 */           while (st.hasMoreTokens()) {
/* 2222 */             String privilege = st.nextToken().trim();
/* 2223 */             byte[][] tuple = new byte[8][];
/* 2224 */             tuple[0] = s2b(db);
/* 2225 */             tuple[1] = null;
/* 2226 */             tuple[2] = s2b(table);
/* 2227 */             tuple[3] = s2b(columnName);
/*      */             
/* 2229 */             if (grantor != null) {
/* 2230 */               tuple[4] = s2b(grantor);
/*      */             } else {
/* 2232 */               tuple[4] = null;
/*      */             } 
/*      */             
/* 2235 */             tuple[5] = s2b(fullUser.toString());
/* 2236 */             tuple[6] = s2b(privilege);
/* 2237 */             tuple[7] = null;
/* 2238 */             grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } finally {
/* 2243 */       if (results != null) {
/*      */         try {
/* 2245 */           results.close();
/* 2246 */         } catch (Exception ex) {}
/*      */ 
/*      */         
/* 2249 */         results = null;
/*      */       } 
/*      */       
/* 2252 */       if (pStmt != null) {
/*      */         try {
/* 2254 */           pStmt.close();
/* 2255 */         } catch (Exception ex) {}
/*      */ 
/*      */         
/* 2258 */         pStmt = null;
/*      */       } 
/*      */     } 
/*      */     
/* 2262 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getColumns(String catalog, final String schemaPattern, final String tableNamePattern, String columnNamePattern) throws SQLException {
/* 2319 */     if (columnNamePattern == null) {
/* 2320 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 2321 */         columnNamePattern = "%";
/*      */       } else {
/* 2323 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2328 */     final String colPattern = columnNamePattern;
/*      */     
/* 2330 */     Field[] fields = createColumnsFields();
/*      */     
/* 2332 */     final ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/* 2333 */     final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */     
/*      */     try {
/* 2337 */       (new IterateBlock<String>(getCatalogIterator(catalog)) { void forEach(String catalogStr) throws SQLException { // Byte code:
/*      */             //   0: new java/util/ArrayList
/*      */             //   3: dup
/*      */             //   4: invokespecial <init> : ()V
/*      */             //   7: astore_2
/*      */             //   8: aload_0
/*      */             //   9: getfield val$tableNamePattern : Ljava/lang/String;
/*      */             //   12: ifnonnull -> 108
/*      */             //   15: aconst_null
/*      */             //   16: astore_3
/*      */             //   17: aload_0
/*      */             //   18: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   21: aload_1
/*      */             //   22: aload_0
/*      */             //   23: getfield val$schemaPattern : Ljava/lang/String;
/*      */             //   26: ldc '%'
/*      */             //   28: iconst_0
/*      */             //   29: anewarray java/lang/String
/*      */             //   32: invokevirtual getTables : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */             //   35: astore_3
/*      */             //   36: aload_3
/*      */             //   37: invokeinterface next : ()Z
/*      */             //   42: ifeq -> 65
/*      */             //   45: aload_3
/*      */             //   46: ldc 'TABLE_NAME'
/*      */             //   48: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   53: astore #4
/*      */             //   55: aload_2
/*      */             //   56: aload #4
/*      */             //   58: invokevirtual add : (Ljava/lang/Object;)Z
/*      */             //   61: pop
/*      */             //   62: goto -> 36
/*      */             //   65: jsr -> 79
/*      */             //   68: goto -> 105
/*      */             //   71: astore #5
/*      */             //   73: jsr -> 79
/*      */             //   76: aload #5
/*      */             //   78: athrow
/*      */             //   79: astore #6
/*      */             //   81: aload_3
/*      */             //   82: ifnull -> 103
/*      */             //   85: aload_3
/*      */             //   86: invokeinterface close : ()V
/*      */             //   91: goto -> 101
/*      */             //   94: astore #7
/*      */             //   96: aload #7
/*      */             //   98: invokestatic shouldNotHappen : (Ljava/lang/Exception;)V
/*      */             //   101: aconst_null
/*      */             //   102: astore_3
/*      */             //   103: ret #6
/*      */             //   105: goto -> 200
/*      */             //   108: aconst_null
/*      */             //   109: astore_3
/*      */             //   110: aload_0
/*      */             //   111: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   114: aload_1
/*      */             //   115: aload_0
/*      */             //   116: getfield val$schemaPattern : Ljava/lang/String;
/*      */             //   119: aload_0
/*      */             //   120: getfield val$tableNamePattern : Ljava/lang/String;
/*      */             //   123: iconst_0
/*      */             //   124: anewarray java/lang/String
/*      */             //   127: invokevirtual getTables : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */             //   130: astore_3
/*      */             //   131: aload_3
/*      */             //   132: invokeinterface next : ()Z
/*      */             //   137: ifeq -> 160
/*      */             //   140: aload_3
/*      */             //   141: ldc 'TABLE_NAME'
/*      */             //   143: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   148: astore #4
/*      */             //   150: aload_2
/*      */             //   151: aload #4
/*      */             //   153: invokevirtual add : (Ljava/lang/Object;)Z
/*      */             //   156: pop
/*      */             //   157: goto -> 131
/*      */             //   160: jsr -> 174
/*      */             //   163: goto -> 200
/*      */             //   166: astore #8
/*      */             //   168: jsr -> 174
/*      */             //   171: aload #8
/*      */             //   173: athrow
/*      */             //   174: astore #9
/*      */             //   176: aload_3
/*      */             //   177: ifnull -> 198
/*      */             //   180: aload_3
/*      */             //   181: invokeinterface close : ()V
/*      */             //   186: goto -> 196
/*      */             //   189: astore #10
/*      */             //   191: aload #10
/*      */             //   193: invokestatic shouldNotHappen : (Ljava/lang/Exception;)V
/*      */             //   196: aconst_null
/*      */             //   197: astore_3
/*      */             //   198: ret #9
/*      */             //   200: aload_2
/*      */             //   201: invokevirtual iterator : ()Ljava/util/Iterator;
/*      */             //   204: astore_3
/*      */             //   205: aload_3
/*      */             //   206: invokeinterface hasNext : ()Z
/*      */             //   211: ifeq -> 1431
/*      */             //   214: aload_3
/*      */             //   215: invokeinterface next : ()Ljava/lang/Object;
/*      */             //   220: checkcast java/lang/String
/*      */             //   223: astore #4
/*      */             //   225: aconst_null
/*      */             //   226: astore #5
/*      */             //   228: new java/lang/StringBuilder
/*      */             //   231: dup
/*      */             //   232: ldc 'SHOW '
/*      */             //   234: invokespecial <init> : (Ljava/lang/String;)V
/*      */             //   237: astore #6
/*      */             //   239: aload_0
/*      */             //   240: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   243: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   246: iconst_4
/*      */             //   247: iconst_1
/*      */             //   248: iconst_0
/*      */             //   249: invokeinterface versionMeetsMinimum : (III)Z
/*      */             //   254: ifeq -> 265
/*      */             //   257: aload #6
/*      */             //   259: ldc 'FULL '
/*      */             //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   264: pop
/*      */             //   265: aload #6
/*      */             //   267: ldc 'COLUMNS FROM '
/*      */             //   269: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   272: pop
/*      */             //   273: aload #6
/*      */             //   275: aload #4
/*      */             //   277: aload_0
/*      */             //   278: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   281: getfield quotedId : Ljava/lang/String;
/*      */             //   284: aload_0
/*      */             //   285: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   288: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   291: invokeinterface getPedantic : ()Z
/*      */             //   296: invokestatic quoteIdentifier : (Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
/*      */             //   299: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   302: pop
/*      */             //   303: aload #6
/*      */             //   305: ldc ' FROM '
/*      */             //   307: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   310: pop
/*      */             //   311: aload #6
/*      */             //   313: aload_1
/*      */             //   314: aload_0
/*      */             //   315: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   318: getfield quotedId : Ljava/lang/String;
/*      */             //   321: aload_0
/*      */             //   322: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   325: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   328: invokeinterface getPedantic : ()Z
/*      */             //   333: invokestatic quoteIdentifier : (Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
/*      */             //   336: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   339: pop
/*      */             //   340: aload #6
/*      */             //   342: ldc ' LIKE '
/*      */             //   344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   347: pop
/*      */             //   348: aload #6
/*      */             //   350: aload_0
/*      */             //   351: getfield val$colPattern : Ljava/lang/String;
/*      */             //   354: ldc '''
/*      */             //   356: iconst_1
/*      */             //   357: invokestatic quoteIdentifier : (Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
/*      */             //   360: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   363: pop
/*      */             //   364: iconst_0
/*      */             //   365: istore #7
/*      */             //   367: aconst_null
/*      */             //   368: astore #8
/*      */             //   370: aload_0
/*      */             //   371: getfield val$colPattern : Ljava/lang/String;
/*      */             //   374: ldc '%'
/*      */             //   376: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */             //   379: ifne -> 567
/*      */             //   382: iconst_1
/*      */             //   383: istore #7
/*      */             //   385: new java/lang/StringBuilder
/*      */             //   388: dup
/*      */             //   389: ldc 'SHOW '
/*      */             //   391: invokespecial <init> : (Ljava/lang/String;)V
/*      */             //   394: astore #9
/*      */             //   396: aload_0
/*      */             //   397: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   400: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   403: iconst_4
/*      */             //   404: iconst_1
/*      */             //   405: iconst_0
/*      */             //   406: invokeinterface versionMeetsMinimum : (III)Z
/*      */             //   411: ifeq -> 422
/*      */             //   414: aload #9
/*      */             //   416: ldc 'FULL '
/*      */             //   418: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   421: pop
/*      */             //   422: aload #9
/*      */             //   424: ldc 'COLUMNS FROM '
/*      */             //   426: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   429: pop
/*      */             //   430: aload #9
/*      */             //   432: aload #4
/*      */             //   434: aload_0
/*      */             //   435: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   438: getfield quotedId : Ljava/lang/String;
/*      */             //   441: aload_0
/*      */             //   442: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   445: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   448: invokeinterface getPedantic : ()Z
/*      */             //   453: invokestatic quoteIdentifier : (Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
/*      */             //   456: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   459: pop
/*      */             //   460: aload #9
/*      */             //   462: ldc ' FROM '
/*      */             //   464: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   467: pop
/*      */             //   468: aload #9
/*      */             //   470: aload_1
/*      */             //   471: aload_0
/*      */             //   472: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   475: getfield quotedId : Ljava/lang/String;
/*      */             //   478: aload_0
/*      */             //   479: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   482: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   485: invokeinterface getPedantic : ()Z
/*      */             //   490: invokestatic quoteIdentifier : (Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;
/*      */             //   493: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */             //   496: pop
/*      */             //   497: aload_0
/*      */             //   498: getfield val$stmt : Ljava/sql/Statement;
/*      */             //   501: aload #9
/*      */             //   503: invokevirtual toString : ()Ljava/lang/String;
/*      */             //   506: invokeinterface executeQuery : (Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */             //   511: astore #5
/*      */             //   513: new java/util/HashMap
/*      */             //   516: dup
/*      */             //   517: invokespecial <init> : ()V
/*      */             //   520: astore #8
/*      */             //   522: iconst_1
/*      */             //   523: istore #10
/*      */             //   525: aload #5
/*      */             //   527: invokeinterface next : ()Z
/*      */             //   532: ifeq -> 567
/*      */             //   535: aload #5
/*      */             //   537: ldc 'Field'
/*      */             //   539: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   544: astore #11
/*      */             //   546: aload #8
/*      */             //   548: aload #11
/*      */             //   550: iload #10
/*      */             //   552: iinc #10, 1
/*      */             //   555: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */             //   558: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */             //   563: pop
/*      */             //   564: goto -> 525
/*      */             //   567: aload_0
/*      */             //   568: getfield val$stmt : Ljava/sql/Statement;
/*      */             //   571: aload #6
/*      */             //   573: invokevirtual toString : ()Ljava/lang/String;
/*      */             //   576: invokeinterface executeQuery : (Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */             //   581: astore #5
/*      */             //   583: iconst_1
/*      */             //   584: istore #9
/*      */             //   586: aload #5
/*      */             //   588: invokeinterface next : ()Z
/*      */             //   593: ifeq -> 1390
/*      */             //   596: bipush #24
/*      */             //   598: anewarray [B
/*      */             //   601: astore #10
/*      */             //   603: aload #10
/*      */             //   605: iconst_0
/*      */             //   606: aload_0
/*      */             //   607: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   610: aload_1
/*      */             //   611: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   614: aastore
/*      */             //   615: aload #10
/*      */             //   617: iconst_1
/*      */             //   618: aconst_null
/*      */             //   619: aastore
/*      */             //   620: aload #10
/*      */             //   622: iconst_2
/*      */             //   623: aload_0
/*      */             //   624: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   627: aload #4
/*      */             //   629: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   632: aastore
/*      */             //   633: aload #10
/*      */             //   635: iconst_3
/*      */             //   636: aload #5
/*      */             //   638: ldc 'Field'
/*      */             //   640: invokeinterface getBytes : (Ljava/lang/String;)[B
/*      */             //   645: aastore
/*      */             //   646: new com/mysql/jdbc/DatabaseMetaData$TypeDescriptor
/*      */             //   649: dup
/*      */             //   650: aload_0
/*      */             //   651: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   654: aload #5
/*      */             //   656: ldc 'Type'
/*      */             //   658: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   663: aload #5
/*      */             //   665: ldc 'Null'
/*      */             //   667: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   672: invokespecial <init> : (Lcom/mysql/jdbc/DatabaseMetaData;Ljava/lang/String;Ljava/lang/String;)V
/*      */             //   675: astore #11
/*      */             //   677: aload #10
/*      */             //   679: iconst_4
/*      */             //   680: aload #11
/*      */             //   682: getfield dataType : S
/*      */             //   685: invokestatic toString : (S)Ljava/lang/String;
/*      */             //   688: invokevirtual getBytes : ()[B
/*      */             //   691: aastore
/*      */             //   692: aload #10
/*      */             //   694: iconst_5
/*      */             //   695: aload_0
/*      */             //   696: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   699: aload #11
/*      */             //   701: getfield typeName : Ljava/lang/String;
/*      */             //   704: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   707: aastore
/*      */             //   708: aload #11
/*      */             //   710: getfield columnSize : Ljava/lang/Integer;
/*      */             //   713: ifnonnull -> 725
/*      */             //   716: aload #10
/*      */             //   718: bipush #6
/*      */             //   720: aconst_null
/*      */             //   721: aastore
/*      */             //   722: goto -> 878
/*      */             //   725: aload #5
/*      */             //   727: ldc 'Collation'
/*      */             //   729: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   734: astore #12
/*      */             //   736: iconst_1
/*      */             //   737: istore #13
/*      */             //   739: aload #12
/*      */             //   741: ifnull -> 825
/*      */             //   744: ldc 'TEXT'
/*      */             //   746: aload #11
/*      */             //   748: getfield typeName : Ljava/lang/String;
/*      */             //   751: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */             //   754: ifne -> 783
/*      */             //   757: ldc 'TINYTEXT'
/*      */             //   759: aload #11
/*      */             //   761: getfield typeName : Ljava/lang/String;
/*      */             //   764: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */             //   767: ifne -> 783
/*      */             //   770: ldc 'MEDIUMTEXT'
/*      */             //   772: aload #11
/*      */             //   774: getfield typeName : Ljava/lang/String;
/*      */             //   777: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */             //   780: ifeq -> 825
/*      */             //   783: aload #12
/*      */             //   785: ldc 'ucs2'
/*      */             //   787: invokevirtual indexOf : (Ljava/lang/String;)I
/*      */             //   790: iconst_m1
/*      */             //   791: if_icmpgt -> 805
/*      */             //   794: aload #12
/*      */             //   796: ldc 'utf16'
/*      */             //   798: invokevirtual indexOf : (Ljava/lang/String;)I
/*      */             //   801: iconst_m1
/*      */             //   802: if_icmple -> 811
/*      */             //   805: iconst_2
/*      */             //   806: istore #13
/*      */             //   808: goto -> 825
/*      */             //   811: aload #12
/*      */             //   813: ldc 'utf32'
/*      */             //   815: invokevirtual indexOf : (Ljava/lang/String;)I
/*      */             //   818: iconst_m1
/*      */             //   819: if_icmple -> 825
/*      */             //   822: iconst_4
/*      */             //   823: istore #13
/*      */             //   825: aload #10
/*      */             //   827: bipush #6
/*      */             //   829: iload #13
/*      */             //   831: iconst_1
/*      */             //   832: if_icmpne -> 853
/*      */             //   835: aload_0
/*      */             //   836: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   839: aload #11
/*      */             //   841: getfield columnSize : Ljava/lang/Integer;
/*      */             //   844: invokevirtual toString : ()Ljava/lang/String;
/*      */             //   847: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   850: goto -> 877
/*      */             //   853: aload_0
/*      */             //   854: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   857: aload #11
/*      */             //   859: getfield columnSize : Ljava/lang/Integer;
/*      */             //   862: invokevirtual intValue : ()I
/*      */             //   865: iload #13
/*      */             //   867: idiv
/*      */             //   868: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */             //   871: invokevirtual toString : ()Ljava/lang/String;
/*      */             //   874: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   877: aastore
/*      */             //   878: aload #10
/*      */             //   880: bipush #7
/*      */             //   882: aload_0
/*      */             //   883: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   886: aload #11
/*      */             //   888: getfield bufferLength : I
/*      */             //   891: invokestatic toString : (I)Ljava/lang/String;
/*      */             //   894: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   897: aastore
/*      */             //   898: aload #10
/*      */             //   900: bipush #8
/*      */             //   902: aload #11
/*      */             //   904: getfield decimalDigits : Ljava/lang/Integer;
/*      */             //   907: ifnonnull -> 914
/*      */             //   910: aconst_null
/*      */             //   911: goto -> 929
/*      */             //   914: aload_0
/*      */             //   915: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   918: aload #11
/*      */             //   920: getfield decimalDigits : Ljava/lang/Integer;
/*      */             //   923: invokevirtual toString : ()Ljava/lang/String;
/*      */             //   926: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   929: aastore
/*      */             //   930: aload #10
/*      */             //   932: bipush #9
/*      */             //   934: aload_0
/*      */             //   935: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   938: aload #11
/*      */             //   940: getfield numPrecRadix : I
/*      */             //   943: invokestatic toString : (I)Ljava/lang/String;
/*      */             //   946: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   949: aastore
/*      */             //   950: aload #10
/*      */             //   952: bipush #10
/*      */             //   954: aload_0
/*      */             //   955: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   958: aload #11
/*      */             //   960: getfield nullability : I
/*      */             //   963: invokestatic toString : (I)Ljava/lang/String;
/*      */             //   966: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   969: aastore
/*      */             //   970: aload_0
/*      */             //   971: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   974: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */             //   977: iconst_4
/*      */             //   978: iconst_1
/*      */             //   979: iconst_0
/*      */             //   980: invokeinterface versionMeetsMinimum : (III)Z
/*      */             //   985: ifeq -> 1005
/*      */             //   988: aload #10
/*      */             //   990: bipush #11
/*      */             //   992: aload #5
/*      */             //   994: ldc 'Comment'
/*      */             //   996: invokeinterface getBytes : (Ljava/lang/String;)[B
/*      */             //   1001: aastore
/*      */             //   1002: goto -> 1019
/*      */             //   1005: aload #10
/*      */             //   1007: bipush #11
/*      */             //   1009: aload #5
/*      */             //   1011: ldc 'Extra'
/*      */             //   1013: invokeinterface getBytes : (Ljava/lang/String;)[B
/*      */             //   1018: aastore
/*      */             //   1019: goto -> 1032
/*      */             //   1022: astore #12
/*      */             //   1024: aload #10
/*      */             //   1026: bipush #11
/*      */             //   1028: iconst_0
/*      */             //   1029: newarray byte
/*      */             //   1031: aastore
/*      */             //   1032: aload #10
/*      */             //   1034: bipush #12
/*      */             //   1036: aload #5
/*      */             //   1038: ldc 'Default'
/*      */             //   1040: invokeinterface getBytes : (Ljava/lang/String;)[B
/*      */             //   1045: aastore
/*      */             //   1046: aload #10
/*      */             //   1048: bipush #13
/*      */             //   1050: iconst_1
/*      */             //   1051: newarray byte
/*      */             //   1053: dup
/*      */             //   1054: iconst_0
/*      */             //   1055: bipush #48
/*      */             //   1057: bastore
/*      */             //   1058: aastore
/*      */             //   1059: aload #10
/*      */             //   1061: bipush #14
/*      */             //   1063: iconst_1
/*      */             //   1064: newarray byte
/*      */             //   1066: dup
/*      */             //   1067: iconst_0
/*      */             //   1068: bipush #48
/*      */             //   1070: bastore
/*      */             //   1071: aastore
/*      */             //   1072: aload #11
/*      */             //   1074: getfield typeName : Ljava/lang/String;
/*      */             //   1077: ldc 'CHAR'
/*      */             //   1079: invokestatic indexOfIgnoreCase : (Ljava/lang/String;Ljava/lang/String;)I
/*      */             //   1082: iconst_m1
/*      */             //   1083: if_icmpne -> 1128
/*      */             //   1086: aload #11
/*      */             //   1088: getfield typeName : Ljava/lang/String;
/*      */             //   1091: ldc 'BLOB'
/*      */             //   1093: invokestatic indexOfIgnoreCase : (Ljava/lang/String;Ljava/lang/String;)I
/*      */             //   1096: iconst_m1
/*      */             //   1097: if_icmpne -> 1128
/*      */             //   1100: aload #11
/*      */             //   1102: getfield typeName : Ljava/lang/String;
/*      */             //   1105: ldc 'TEXT'
/*      */             //   1107: invokestatic indexOfIgnoreCase : (Ljava/lang/String;Ljava/lang/String;)I
/*      */             //   1110: iconst_m1
/*      */             //   1111: if_icmpne -> 1128
/*      */             //   1114: aload #11
/*      */             //   1116: getfield typeName : Ljava/lang/String;
/*      */             //   1119: ldc 'BINARY'
/*      */             //   1121: invokestatic indexOfIgnoreCase : (Ljava/lang/String;Ljava/lang/String;)I
/*      */             //   1124: iconst_m1
/*      */             //   1125: if_icmpeq -> 1141
/*      */             //   1128: aload #10
/*      */             //   1130: bipush #15
/*      */             //   1132: aload #10
/*      */             //   1134: bipush #6
/*      */             //   1136: aaload
/*      */             //   1137: aastore
/*      */             //   1138: goto -> 1147
/*      */             //   1141: aload #10
/*      */             //   1143: bipush #15
/*      */             //   1145: aconst_null
/*      */             //   1146: aastore
/*      */             //   1147: iload #7
/*      */             //   1149: ifne -> 1171
/*      */             //   1152: aload #10
/*      */             //   1154: bipush #16
/*      */             //   1156: iload #9
/*      */             //   1158: iinc #9, 1
/*      */             //   1161: invokestatic toString : (I)Ljava/lang/String;
/*      */             //   1164: invokevirtual getBytes : ()[B
/*      */             //   1167: aastore
/*      */             //   1168: goto -> 1232
/*      */             //   1171: aload #5
/*      */             //   1173: ldc 'Field'
/*      */             //   1175: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   1180: astore #12
/*      */             //   1182: aload #8
/*      */             //   1184: aload #12
/*      */             //   1186: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */             //   1191: checkcast java/lang/Integer
/*      */             //   1194: astore #13
/*      */             //   1196: aload #13
/*      */             //   1198: ifnull -> 1217
/*      */             //   1201: aload #10
/*      */             //   1203: bipush #16
/*      */             //   1205: aload #13
/*      */             //   1207: invokevirtual toString : ()Ljava/lang/String;
/*      */             //   1210: invokevirtual getBytes : ()[B
/*      */             //   1213: aastore
/*      */             //   1214: goto -> 1232
/*      */             //   1217: ldc 'Can not find column in full column list to determine true ordinal position.'
/*      */             //   1219: ldc 'S1000'
/*      */             //   1221: aload_0
/*      */             //   1222: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   1225: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */             //   1228: invokestatic createSQLException : (Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */             //   1231: athrow
/*      */             //   1232: aload #10
/*      */             //   1234: bipush #17
/*      */             //   1236: aload_0
/*      */             //   1237: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   1240: aload #11
/*      */             //   1242: getfield isNullable : Ljava/lang/String;
/*      */             //   1245: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   1248: aastore
/*      */             //   1249: aload #10
/*      */             //   1251: bipush #18
/*      */             //   1253: aconst_null
/*      */             //   1254: aastore
/*      */             //   1255: aload #10
/*      */             //   1257: bipush #19
/*      */             //   1259: aconst_null
/*      */             //   1260: aastore
/*      */             //   1261: aload #10
/*      */             //   1263: bipush #20
/*      */             //   1265: aconst_null
/*      */             //   1266: aastore
/*      */             //   1267: aload #10
/*      */             //   1269: bipush #21
/*      */             //   1271: aconst_null
/*      */             //   1272: aastore
/*      */             //   1273: aload #10
/*      */             //   1275: bipush #22
/*      */             //   1277: aload_0
/*      */             //   1278: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   1281: ldc ''
/*      */             //   1283: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   1286: aastore
/*      */             //   1287: aload #5
/*      */             //   1289: ldc 'Extra'
/*      */             //   1291: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */             //   1296: astore #12
/*      */             //   1298: aload #12
/*      */             //   1300: ifnull -> 1363
/*      */             //   1303: aload #10
/*      */             //   1305: bipush #22
/*      */             //   1307: aload_0
/*      */             //   1308: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   1311: aload #12
/*      */             //   1313: ldc 'auto_increment'
/*      */             //   1315: invokestatic indexOfIgnoreCase : (Ljava/lang/String;Ljava/lang/String;)I
/*      */             //   1318: iconst_m1
/*      */             //   1319: if_icmpeq -> 1327
/*      */             //   1322: ldc 'YES'
/*      */             //   1324: goto -> 1329
/*      */             //   1327: ldc 'NO'
/*      */             //   1329: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   1332: aastore
/*      */             //   1333: aload #10
/*      */             //   1335: bipush #23
/*      */             //   1337: aload_0
/*      */             //   1338: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   1341: aload #12
/*      */             //   1343: ldc 'generated'
/*      */             //   1345: invokestatic indexOfIgnoreCase : (Ljava/lang/String;Ljava/lang/String;)I
/*      */             //   1348: iconst_m1
/*      */             //   1349: if_icmpeq -> 1357
/*      */             //   1352: ldc 'YES'
/*      */             //   1354: goto -> 1359
/*      */             //   1357: ldc 'NO'
/*      */             //   1359: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */             //   1362: aastore
/*      */             //   1363: aload_0
/*      */             //   1364: getfield val$rows : Ljava/util/ArrayList;
/*      */             //   1367: new com/mysql/jdbc/ByteArrayRow
/*      */             //   1370: dup
/*      */             //   1371: aload #10
/*      */             //   1373: aload_0
/*      */             //   1374: getfield this$0 : Lcom/mysql/jdbc/DatabaseMetaData;
/*      */             //   1377: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */             //   1380: invokespecial <init> : ([[BLcom/mysql/jdbc/ExceptionInterceptor;)V
/*      */             //   1383: invokevirtual add : (Ljava/lang/Object;)Z
/*      */             //   1386: pop
/*      */             //   1387: goto -> 586
/*      */             //   1390: jsr -> 1404
/*      */             //   1393: goto -> 1428
/*      */             //   1396: astore #14
/*      */             //   1398: jsr -> 1404
/*      */             //   1401: aload #14
/*      */             //   1403: athrow
/*      */             //   1404: astore #15
/*      */             //   1406: aload #5
/*      */             //   1408: ifnull -> 1426
/*      */             //   1411: aload #5
/*      */             //   1413: invokeinterface close : ()V
/*      */             //   1418: goto -> 1423
/*      */             //   1421: astore #16
/*      */             //   1423: aconst_null
/*      */             //   1424: astore #5
/*      */             //   1426: ret #15
/*      */             //   1428: goto -> 205
/*      */             //   1431: return
/*      */             // Line number table:
/*      */             //   Java source line number -> byte code offset
/*      */             //   #2341	-> 0
/*      */             //   #2343	-> 8
/*      */             //   #2345	-> 15
/*      */             //   #2348	-> 17
/*      */             //   #2350	-> 36
/*      */             //   #2351	-> 45
/*      */             //   #2352	-> 55
/*      */             //   #2353	-> 62
/*      */             //   #2354	-> 65
/*      */             //   #2364	-> 68
/*      */             //   #2355	-> 71
/*      */             //   #2357	-> 85
/*      */             //   #2360	-> 91
/*      */             //   #2358	-> 94
/*      */             //   #2359	-> 96
/*      */             //   #2362	-> 101
/*      */             //   #2365	-> 105
/*      */             //   #2366	-> 108
/*      */             //   #2369	-> 110
/*      */             //   #2371	-> 131
/*      */             //   #2372	-> 140
/*      */             //   #2373	-> 150
/*      */             //   #2374	-> 157
/*      */             //   #2375	-> 160
/*      */             //   #2385	-> 163
/*      */             //   #2376	-> 166
/*      */             //   #2378	-> 180
/*      */             //   #2381	-> 186
/*      */             //   #2379	-> 189
/*      */             //   #2380	-> 191
/*      */             //   #2383	-> 196
/*      */             //   #2388	-> 200
/*      */             //   #2390	-> 225
/*      */             //   #2393	-> 228
/*      */             //   #2395	-> 239
/*      */             //   #2396	-> 257
/*      */             //   #2399	-> 265
/*      */             //   #2400	-> 273
/*      */             //   #2401	-> 303
/*      */             //   #2402	-> 311
/*      */             //   #2403	-> 340
/*      */             //   #2404	-> 348
/*      */             //   #2409	-> 364
/*      */             //   #2410	-> 367
/*      */             //   #2412	-> 370
/*      */             //   #2413	-> 382
/*      */             //   #2415	-> 385
/*      */             //   #2417	-> 396
/*      */             //   #2418	-> 414
/*      */             //   #2421	-> 422
/*      */             //   #2422	-> 430
/*      */             //   #2424	-> 460
/*      */             //   #2425	-> 468
/*      */             //   #2428	-> 497
/*      */             //   #2430	-> 513
/*      */             //   #2432	-> 522
/*      */             //   #2434	-> 525
/*      */             //   #2435	-> 535
/*      */             //   #2437	-> 546
/*      */             //   #2438	-> 564
/*      */             //   #2441	-> 567
/*      */             //   #2443	-> 583
/*      */             //   #2445	-> 586
/*      */             //   #2446	-> 596
/*      */             //   #2447	-> 603
/*      */             //   #2448	-> 615
/*      */             //   #2451	-> 620
/*      */             //   #2452	-> 633
/*      */             //   #2454	-> 646
/*      */             //   #2456	-> 677
/*      */             //   #2459	-> 692
/*      */             //   #2461	-> 708
/*      */             //   #2462	-> 716
/*      */             //   #2464	-> 725
/*      */             //   #2465	-> 736
/*      */             //   #2466	-> 739
/*      */             //   #2468	-> 783
/*      */             //   #2469	-> 805
/*      */             //   #2470	-> 811
/*      */             //   #2471	-> 822
/*      */             //   #2474	-> 825
/*      */             //   #2477	-> 878
/*      */             //   #2478	-> 898
/*      */             //   #2479	-> 930
/*      */             //   #2480	-> 950
/*      */             //   #2489	-> 970
/*      */             //   #2490	-> 988
/*      */             //   #2492	-> 1005
/*      */             //   #2496	-> 1019
/*      */             //   #2494	-> 1022
/*      */             //   #2495	-> 1024
/*      */             //   #2499	-> 1032
/*      */             //   #2501	-> 1046
/*      */             //   #2502	-> 1059
/*      */             //   #2504	-> 1072
/*      */             //   #2508	-> 1128
/*      */             //   #2510	-> 1141
/*      */             //   #2514	-> 1147
/*      */             //   #2515	-> 1152
/*      */             //   #2517	-> 1171
/*      */             //   #2518	-> 1182
/*      */             //   #2520	-> 1196
/*      */             //   #2521	-> 1201
/*      */             //   #2523	-> 1217
/*      */             //   #2528	-> 1232
/*      */             //   #2531	-> 1249
/*      */             //   #2532	-> 1255
/*      */             //   #2533	-> 1261
/*      */             //   #2534	-> 1267
/*      */             //   #2536	-> 1273
/*      */             //   #2538	-> 1287
/*      */             //   #2540	-> 1298
/*      */             //   #2541	-> 1303
/*      */             //   #2542	-> 1333
/*      */             //   #2545	-> 1363
/*      */             //   #2546	-> 1387
/*      */             //   #2547	-> 1390
/*      */             //   #2556	-> 1393
/*      */             //   #2548	-> 1396
/*      */             //   #2550	-> 1411
/*      */             //   #2552	-> 1418
/*      */             //   #2551	-> 1421
/*      */             //   #2554	-> 1423
/*      */             //   #2557	-> 1428
/*      */             //   #2558	-> 1431
/*      */             // Local variable table:
/*      */             //   start	length	slot	name	descriptor
/*      */             //   55	7	4	tableNameFromList	Ljava/lang/String;
/*      */             //   96	5	7	sqlEx	Ljava/lang/Exception;
/*      */             //   17	88	3	tables	Ljava/sql/ResultSet;
/*      */             //   150	7	4	tableNameFromList	Ljava/lang/String;
/*      */             //   191	5	10	sqlEx	Ljava/sql/SQLException;
/*      */             //   110	90	3	tables	Ljava/sql/ResultSet;
/*      */             //   546	18	11	fullOrdColName	Ljava/lang/String;
/*      */             //   396	171	9	fullColumnQueryBuf	Ljava/lang/StringBuilder;
/*      */             //   525	42	10	fullOrdinalPos	I
/*      */             //   736	142	12	collation	Ljava/lang/String;
/*      */             //   739	139	13	mbminlen	I
/*      */             //   1024	8	12	E	Ljava/lang/Exception;
/*      */             //   1182	50	12	origColName	Ljava/lang/String;
/*      */             //   1196	36	13	realOrdinal	Ljava/lang/Integer;
/*      */             //   603	784	10	rowVal	[[B
/*      */             //   677	710	11	typeDesc	Lcom/mysql/jdbc/DatabaseMetaData$TypeDescriptor;
/*      */             //   1298	89	12	extra	Ljava/lang/String;
/*      */             //   239	1151	6	queryBuf	Ljava/lang/StringBuilder;
/*      */             //   367	1023	7	fixUpOrdinalsRequired	Z
/*      */             //   370	1020	8	ordinalFixUpMap	Ljava/util/Map;
/*      */             //   586	804	9	ordPos	I
/*      */             //   1423	0	16	ex	Ljava/lang/Exception;
/*      */             //   228	1200	5	results	Ljava/sql/ResultSet;
/*      */             //   225	1203	4	tableName	Ljava/lang/String;
/*      */             //   205	1226	3	i$	Ljava/util/Iterator;
/*      */             //   0	1432	0	this	Lcom/mysql/jdbc/DatabaseMetaData$2;
/*      */             //   0	1432	1	catalogStr	Ljava/lang/String;
/*      */             //   8	1424	2	tableNameList	Ljava/util/ArrayList;
/*      */             // Local variable type table:
/*      */             //   start	length	slot	name	signature
/*      */             //   370	1020	8	ordinalFixUpMap	Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;
/*      */             //   8	1424	2	tableNameList	Ljava/util/ArrayList<Ljava/lang/String;>;
/*      */             // Exception table:
/*      */             //   from	to	target	type
/*      */             //   17	68	71	finally
/*      */             //   71	76	71	finally
/*      */             //   85	91	94	java/lang/Exception
/*      */             //   110	163	166	finally
/*      */             //   166	171	166	finally
/*      */             //   180	186	189	java/sql/SQLException
/*      */             //   228	1393	1396	finally
/*      */             //   970	1019	1022	java/lang/Exception
/*      */             //   1396	1401	1396	finally
/* 2337 */             //   1411	1418	1421	java/lang/Exception } }).doForAll();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2561 */       if (stmt != null) {
/* 2562 */         stmt.close();
/*      */       }
/*      */     } 
/*      */     
/* 2566 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 2568 */     return results;
/*      */   }
/*      */   
/*      */   protected Field[] createColumnsFields() {
/* 2572 */     Field[] fields = new Field[24];
/* 2573 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 2574 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 2575 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 2576 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 2577 */     fields[4] = new Field("", "DATA_TYPE", 4, 5);
/* 2578 */     fields[5] = new Field("", "TYPE_NAME", 1, 16);
/* 2579 */     fields[6] = new Field("", "COLUMN_SIZE", 4, Integer.toString(2147483647).length());
/* 2580 */     fields[7] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 2581 */     fields[8] = new Field("", "DECIMAL_DIGITS", 4, 10);
/* 2582 */     fields[9] = new Field("", "NUM_PREC_RADIX", 4, 10);
/* 2583 */     fields[10] = new Field("", "NULLABLE", 4, 10);
/* 2584 */     fields[11] = new Field("", "REMARKS", 1, 0);
/* 2585 */     fields[12] = new Field("", "COLUMN_DEF", 1, 0);
/* 2586 */     fields[13] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 2587 */     fields[14] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 2588 */     fields[15] = new Field("", "CHAR_OCTET_LENGTH", 4, Integer.toString(2147483647).length());
/* 2589 */     fields[16] = new Field("", "ORDINAL_POSITION", 4, 10);
/* 2590 */     fields[17] = new Field("", "IS_NULLABLE", 1, 3);
/* 2591 */     fields[18] = new Field("", "SCOPE_CATALOG", 1, 255);
/* 2592 */     fields[19] = new Field("", "SCOPE_SCHEMA", 1, 255);
/* 2593 */     fields[20] = new Field("", "SCOPE_TABLE", 1, 255);
/* 2594 */     fields[21] = new Field("", "SOURCE_DATA_TYPE", 5, 10);
/* 2595 */     fields[22] = new Field("", "IS_AUTOINCREMENT", 1, 3);
/* 2596 */     fields[23] = new Field("", "IS_GENERATEDCOLUMN", 1, 3);
/* 2597 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/* 2608 */     return this.conn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCrossReference(final String primaryCatalog, final String primarySchema, final String primaryTable, final String foreignCatalog, final String foreignSchema, final String foreignTable) throws SQLException {
/* 2667 */     if (primaryTable == null) {
/* 2668 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2671 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 2673 */     final ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>();
/*      */     
/* 2675 */     if (this.conn.versionMeetsMinimum(3, 23, 0)) {
/*      */       
/* 2677 */       final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */       
/*      */       try {
/* 2681 */         (new IterateBlock<String>(getCatalogIterator(foreignCatalog))
/*      */           {
/*      */             void forEach(String catalogStr) throws SQLException
/*      */             {
/* 2685 */               ResultSet fkresults = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/* 2692 */                 if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50)) {
/* 2693 */                   fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr, null);
/*      */                 } else {
/* 2695 */                   StringBuilder queryBuf = new StringBuilder("SHOW TABLE STATUS FROM ");
/* 2696 */                   queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */ 
/*      */                   
/* 2699 */                   fkresults = stmt.executeQuery(queryBuf.toString());
/*      */                 } 
/*      */                 
/* 2702 */                 String foreignTableWithCase = DatabaseMetaData.this.getTableNameWithCase(foreignTable);
/* 2703 */                 String primaryTableWithCase = DatabaseMetaData.this.getTableNameWithCase(primaryTable);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2711 */                 while (fkresults.next()) {
/* 2712 */                   String tableType = fkresults.getString("Type");
/*      */                   
/* 2714 */                   if (tableType != null && (tableType.equalsIgnoreCase("innodb") || tableType.equalsIgnoreCase("SUPPORTS_FK"))) {
/* 2715 */                     String comment = fkresults.getString("Comment").trim();
/*      */                     
/* 2717 */                     if (comment != null) {
/* 2718 */                       StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                       
/* 2720 */                       if (commentTokens.hasMoreTokens()) {
/* 2721 */                         String str = commentTokens.nextToken();
/*      */                       }
/*      */ 
/*      */ 
/*      */                       
/* 2726 */                       while (commentTokens.hasMoreTokens()) {
/* 2727 */                         String keys = commentTokens.nextToken();
/* 2728 */                         DatabaseMetaData.LocalAndReferencedColumns parsedInfo = DatabaseMetaData.this.parseTableStatusIntoLocalAndReferencedColumns(keys);
/*      */                         
/* 2730 */                         int keySeq = 0;
/*      */                         
/* 2732 */                         Iterator<String> referencingColumns = parsedInfo.localColumnsList.iterator();
/* 2733 */                         Iterator<String> referencedColumns = parsedInfo.referencedColumnsList.iterator();
/*      */                         
/* 2735 */                         while (referencingColumns.hasNext()) {
/* 2736 */                           String referencingColumn = StringUtils.unQuoteIdentifier(referencingColumns.next(), DatabaseMetaData.this.quotedId);
/*      */ 
/*      */ 
/*      */                           
/* 2740 */                           byte[][] tuple = new byte[14][];
/* 2741 */                           tuple[4] = (foreignCatalog == null) ? null : DatabaseMetaData.this.s2b(foreignCatalog);
/* 2742 */                           tuple[5] = (foreignSchema == null) ? null : DatabaseMetaData.this.s2b(foreignSchema);
/* 2743 */                           String dummy = fkresults.getString("Name");
/*      */                           
/* 2745 */                           if (dummy.compareTo(foreignTableWithCase) != 0) {
/*      */                             continue;
/*      */                           }
/*      */                           
/* 2749 */                           tuple[6] = DatabaseMetaData.this.s2b(dummy);
/*      */                           
/* 2751 */                           tuple[7] = DatabaseMetaData.this.s2b(referencingColumn);
/* 2752 */                           tuple[0] = (primaryCatalog == null) ? null : DatabaseMetaData.this.s2b(primaryCatalog);
/* 2753 */                           tuple[1] = (primarySchema == null) ? null : DatabaseMetaData.this.s2b(primarySchema);
/*      */ 
/*      */                           
/* 2756 */                           if (parsedInfo.referencedTable.compareTo(primaryTableWithCase) != 0) {
/*      */                             continue;
/*      */                           }
/*      */                           
/* 2760 */                           tuple[2] = DatabaseMetaData.this.s2b(parsedInfo.referencedTable);
/* 2761 */                           tuple[3] = DatabaseMetaData.this.s2b(StringUtils.unQuoteIdentifier(referencedColumns.next(), DatabaseMetaData.this.quotedId));
/* 2762 */                           tuple[8] = Integer.toString(keySeq).getBytes();
/*      */                           
/* 2764 */                           int[] actions = DatabaseMetaData.this.getForeignKeyActions(keys);
/*      */                           
/* 2766 */                           tuple[9] = Integer.toString(actions[1]).getBytes();
/* 2767 */                           tuple[10] = Integer.toString(actions[0]).getBytes();
/* 2768 */                           tuple[11] = null;
/* 2769 */                           tuple[12] = null;
/* 2770 */                           tuple[13] = Integer.toString(7).getBytes();
/* 2771 */                           tuples.add(new ByteArrayRow(tuple, DatabaseMetaData.this.getExceptionInterceptor()));
/* 2772 */                           keySeq++;
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } finally {
/*      */                 
/* 2780 */                 if (fkresults != null) {
/*      */                   try {
/* 2782 */                     fkresults.close();
/* 2783 */                   } catch (Exception sqlEx) {
/* 2784 */                     AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                   } 
/*      */                   
/* 2787 */                   fkresults = null;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           }).doForAll();
/*      */       } finally {
/* 2793 */         if (stmt != null) {
/* 2794 */           stmt.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2799 */     ResultSet results = buildResultSet(fields, tuples);
/*      */     
/* 2801 */     return results;
/*      */   }
/*      */   
/*      */   protected Field[] createFkMetadataFields() {
/* 2805 */     Field[] fields = new Field[14];
/* 2806 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/* 2807 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/* 2808 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/* 2809 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/* 2810 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/* 2811 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/* 2812 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/* 2813 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/* 2814 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/* 2815 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/* 2816 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/* 2817 */     fields[11] = new Field("", "FK_NAME", 1, 0);
/* 2818 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/* 2819 */     fields[13] = new Field("", "DEFERRABILITY", 5, 2);
/* 2820 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDatabaseMajorVersion() throws SQLException {
/* 2827 */     return this.conn.getServerMajorVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDatabaseMinorVersion() throws SQLException {
/* 2834 */     return this.conn.getServerMinorVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDatabaseProductName() throws SQLException {
/* 2844 */     return "MySQL";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDatabaseProductVersion() throws SQLException {
/* 2854 */     return this.conn.getServerVersion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDefaultTransactionIsolation() throws SQLException {
/* 2867 */     if (this.conn.supportsIsolationLevel()) {
/* 2868 */       return 2;
/*      */     }
/*      */     
/* 2871 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDriverMajorVersion() {
/* 2880 */     return NonRegisteringDriver.getMajorVersionInternal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDriverMinorVersion() {
/* 2889 */     return NonRegisteringDriver.getMinorVersionInternal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDriverName() throws SQLException {
/* 2899 */     return "MySQL Connector Java";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDriverVersion() throws SQLException {
/* 2909 */     return "mysql-connector-java-5.1.47 ( Revision: fe1903b1ecb4a96a917f7ed3190d80c049b1de29 )";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getExportedKeys(String catalog, String schema, final String table) throws SQLException {
/* 2959 */     if (table == null) {
/* 2960 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 2963 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 2965 */     final ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/*      */     
/* 2967 */     if (this.conn.versionMeetsMinimum(3, 23, 0)) {
/*      */       
/* 2969 */       final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */       
/*      */       try {
/* 2973 */         (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */           {
/*      */             void forEach(String catalogStr) throws SQLException {
/* 2976 */               ResultSet fkresults = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/* 2983 */                 if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50)) {
/*      */ 
/*      */                   
/* 2986 */                   fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr, null);
/*      */                 } else {
/* 2988 */                   StringBuilder queryBuf = new StringBuilder("SHOW TABLE STATUS FROM ");
/* 2989 */                   queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */ 
/*      */                   
/* 2992 */                   fkresults = stmt.executeQuery(queryBuf.toString());
/*      */                 } 
/*      */ 
/*      */                 
/* 2996 */                 String tableNameWithCase = DatabaseMetaData.this.getTableNameWithCase(table);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 3002 */                 while (fkresults.next()) {
/* 3003 */                   String tableType = fkresults.getString("Type");
/*      */                   
/* 3005 */                   if (tableType != null && (tableType.equalsIgnoreCase("innodb") || tableType.equalsIgnoreCase("SUPPORTS_FK"))) {
/* 3006 */                     String comment = fkresults.getString("Comment").trim();
/*      */                     
/* 3008 */                     if (comment != null) {
/* 3009 */                       StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                       
/* 3011 */                       if (commentTokens.hasMoreTokens()) {
/* 3012 */                         commentTokens.nextToken();
/*      */ 
/*      */ 
/*      */                         
/* 3016 */                         while (commentTokens.hasMoreTokens()) {
/* 3017 */                           String keys = commentTokens.nextToken();
/* 3018 */                           DatabaseMetaData.this.getExportKeyResults(catalogStr, tableNameWithCase, keys, rows, fkresults.getString("Name"));
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } finally {
/*      */                 
/* 3026 */                 if (fkresults != null) {
/*      */                   try {
/* 3028 */                     fkresults.close();
/* 3029 */                   } catch (SQLException sqlEx) {
/* 3030 */                     AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                   } 
/*      */                   
/* 3033 */                   fkresults = null;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           }).doForAll();
/*      */       } finally {
/* 3039 */         if (stmt != null) {
/* 3040 */           stmt.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3045 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3047 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void getExportKeyResults(String catalog, String exportingTable, String keysComment, List<ResultSetRow> tuples, String fkTableName) throws SQLException {
/* 3070 */     getResultsImpl(catalog, exportingTable, keysComment, tuples, fkTableName, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getExtraNameCharacters() throws SQLException {
/* 3081 */     return "#@";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] getForeignKeyActions(String commentString) {
/* 3094 */     int[] actions = { 3, 3 };
/*      */     
/* 3096 */     int lastParenIndex = commentString.lastIndexOf(")");
/*      */     
/* 3098 */     if (lastParenIndex != commentString.length() - 1) {
/* 3099 */       String cascadeOptions = commentString.substring(lastParenIndex + 1).trim().toUpperCase(Locale.ENGLISH);
/*      */       
/* 3101 */       actions[0] = getCascadeDeleteOption(cascadeOptions);
/* 3102 */       actions[1] = getCascadeUpdateOption(cascadeOptions);
/*      */     } 
/*      */     
/* 3105 */     return actions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getIdentifierQuoteString() throws SQLException {
/* 3117 */     if (this.conn.supportsQuotedIdentifiers()) {
/* 3118 */       return this.conn.useAnsiQuotedIdentifiers() ? "\"" : "`";
/*      */     }
/*      */ 
/*      */     
/* 3122 */     return " ";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getImportedKeys(String catalog, String schema, final String table) throws SQLException {
/* 3172 */     if (table == null) {
/* 3173 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 3176 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 3178 */     final ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/*      */     
/* 3180 */     if (this.conn.versionMeetsMinimum(3, 23, 0)) {
/*      */       
/* 3182 */       final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */       
/*      */       try {
/* 3186 */         (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */           {
/*      */             void forEach(String catalogStr) throws SQLException {
/* 3189 */               ResultSet fkresults = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/* 3196 */                 if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50)) {
/*      */ 
/*      */                   
/* 3199 */                   fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr, table);
/*      */                 } else {
/* 3201 */                   StringBuilder queryBuf = new StringBuilder("SHOW TABLE STATUS ");
/* 3202 */                   queryBuf.append(" FROM ");
/* 3203 */                   queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */                   
/* 3205 */                   queryBuf.append(" LIKE ");
/* 3206 */                   queryBuf.append(StringUtils.quoteIdentifier(table, "'", true));
/*      */                   
/* 3208 */                   fkresults = stmt.executeQuery(queryBuf.toString());
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 3215 */                 while (fkresults.next()) {
/* 3216 */                   String tableType = fkresults.getString("Type");
/*      */                   
/* 3218 */                   if (tableType != null && (tableType.equalsIgnoreCase("innodb") || tableType.equalsIgnoreCase("SUPPORTS_FK"))) {
/* 3219 */                     String comment = fkresults.getString("Comment").trim();
/*      */                     
/* 3221 */                     if (comment != null) {
/* 3222 */                       StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                       
/* 3224 */                       if (commentTokens.hasMoreTokens()) {
/* 3225 */                         commentTokens.nextToken();
/*      */                         
/* 3227 */                         while (commentTokens.hasMoreTokens()) {
/* 3228 */                           String keys = commentTokens.nextToken();
/* 3229 */                           DatabaseMetaData.this.getImportKeyResults(catalogStr, table, keys, rows);
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } finally {
/* 3236 */                 if (fkresults != null) {
/*      */                   try {
/* 3238 */                     fkresults.close();
/* 3239 */                   } catch (SQLException sqlEx) {
/* 3240 */                     AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                   } 
/*      */                   
/* 3243 */                   fkresults = null;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           }).doForAll();
/*      */       } finally {
/* 3249 */         if (stmt != null) {
/* 3250 */           stmt.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3255 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3257 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void getImportKeyResults(String catalog, String importingTable, String keysComment, List<ResultSetRow> tuples) throws SQLException {
/* 3278 */     getResultsImpl(catalog, importingTable, keysComment, tuples, null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getIndexInfo(String catalog, String schema, final String table, final boolean unique, boolean approximate) throws SQLException {
/* 3333 */     Field[] fields = createIndexInfoFields();
/*      */     
/* 3335 */     final SortedMap<IndexMetaDataKey, ResultSetRow> sortedRows = new TreeMap<IndexMetaDataKey, ResultSetRow>();
/* 3336 */     ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/* 3337 */     final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */     
/*      */     try {
/* 3341 */       (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException
/*      */           {
/* 3345 */             ResultSet results = null;
/*      */             
/*      */             try {
/* 3348 */               StringBuilder queryBuf = new StringBuilder("SHOW INDEX FROM ");
/* 3349 */               queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 3350 */               queryBuf.append(" FROM ");
/* 3351 */               queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */               
/*      */               try {
/* 3354 */                 results = stmt.executeQuery(queryBuf.toString());
/* 3355 */               } catch (SQLException sqlEx) {
/* 3356 */                 int errorCode = sqlEx.getErrorCode();
/*      */ 
/*      */                 
/* 3359 */                 if (!"42S02".equals(sqlEx.getSQLState()))
/*      */                 {
/* 3361 */                   if (errorCode != 1146) {
/* 3362 */                     throw sqlEx;
/*      */                   }
/*      */                 }
/*      */               } 
/*      */               
/* 3367 */               while (results != null && results.next()) {
/* 3368 */                 byte[][] row = new byte[14][];
/* 3369 */                 row[0] = (catalogStr == null) ? new byte[0] : DatabaseMetaData.this.s2b(catalogStr);
/* 3370 */                 row[1] = null;
/* 3371 */                 row[2] = results.getBytes("Table");
/*      */                 
/* 3373 */                 boolean indexIsUnique = (results.getInt("Non_unique") == 0);
/*      */                 
/* 3375 */                 row[3] = !indexIsUnique ? DatabaseMetaData.this.s2b("true") : DatabaseMetaData.this.s2b("false");
/* 3376 */                 row[4] = new byte[0];
/* 3377 */                 row[5] = results.getBytes("Key_name");
/* 3378 */                 short indexType = 3;
/* 3379 */                 row[6] = Integer.toString(indexType).getBytes();
/* 3380 */                 row[7] = results.getBytes("Seq_in_index");
/* 3381 */                 row[8] = results.getBytes("Column_name");
/* 3382 */                 row[9] = results.getBytes("Collation");
/*      */                 
/* 3384 */                 long cardinality = results.getLong("Cardinality");
/*      */ 
/*      */                 
/* 3387 */                 if (!Util.isJdbc42() && cardinality > 2147483647L) {
/* 3388 */                   cardinality = 2147483647L;
/*      */                 }
/*      */                 
/* 3391 */                 row[10] = DatabaseMetaData.this.s2b(String.valueOf(cardinality));
/* 3392 */                 row[11] = DatabaseMetaData.this.s2b("0");
/* 3393 */                 row[12] = null;
/*      */                 
/* 3395 */                 DatabaseMetaData.IndexMetaDataKey indexInfoKey = new DatabaseMetaData.IndexMetaDataKey(!indexIsUnique, indexType, results.getString("Key_name").toLowerCase(), results.getShort("Seq_in_index"));
/*      */ 
/*      */                 
/* 3398 */                 if (unique) {
/* 3399 */                   if (indexIsUnique) {
/* 3400 */                     sortedRows.put(indexInfoKey, new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   }
/*      */                   continue;
/*      */                 } 
/* 3404 */                 sortedRows.put(indexInfoKey, new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               } 
/*      */             } finally {
/*      */               
/* 3408 */               if (results != null) {
/*      */                 try {
/* 3410 */                   results.close();
/* 3411 */                 } catch (Exception ex) {}
/*      */ 
/*      */                 
/* 3414 */                 results = null;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         }).doForAll();
/*      */       
/* 3420 */       Iterator<ResultSetRow> sortedRowsIterator = sortedRows.values().iterator();
/* 3421 */       while (sortedRowsIterator.hasNext()) {
/* 3422 */         rows.add(sortedRowsIterator.next());
/*      */       }
/*      */       
/* 3425 */       ResultSet indexInfo = buildResultSet(fields, rows);
/*      */       
/* 3427 */       return indexInfo;
/*      */     } finally {
/* 3429 */       if (stmt != null) {
/* 3430 */         stmt.close();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Field[] createIndexInfoFields() {
/* 3436 */     Field[] fields = new Field[13];
/* 3437 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3438 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3439 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3440 */     fields[3] = new Field("", "NON_UNIQUE", 16, 4);
/* 3441 */     fields[4] = new Field("", "INDEX_QUALIFIER", 1, 1);
/* 3442 */     fields[5] = new Field("", "INDEX_NAME", 1, 32);
/* 3443 */     fields[6] = new Field("", "TYPE", 5, 32);
/* 3444 */     fields[7] = new Field("", "ORDINAL_POSITION", 5, 5);
/* 3445 */     fields[8] = new Field("", "COLUMN_NAME", 1, 32);
/* 3446 */     fields[9] = new Field("", "ASC_OR_DESC", 1, 1);
/* 3447 */     if (Util.isJdbc42()) {
/* 3448 */       fields[10] = new Field("", "CARDINALITY", -5, 20);
/* 3449 */       fields[11] = new Field("", "PAGES", -5, 20);
/*      */     } else {
/* 3451 */       fields[10] = new Field("", "CARDINALITY", 4, 20);
/* 3452 */       fields[11] = new Field("", "PAGES", 4, 10);
/*      */     } 
/* 3454 */     fields[12] = new Field("", "FILTER_CONDITION", 1, 32);
/* 3455 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getJDBCMajorVersion() throws SQLException {
/* 3462 */     return 4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getJDBCMinorVersion() throws SQLException {
/* 3469 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxBinaryLiteralLength() throws SQLException {
/* 3479 */     return 16777208;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCatalogNameLength() throws SQLException {
/* 3489 */     return 32;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCharLiteralLength() throws SQLException {
/* 3499 */     return 16777208;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxColumnNameLength() throws SQLException {
/* 3509 */     return 64;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInGroupBy() throws SQLException {
/* 3519 */     return 64;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInIndex() throws SQLException {
/* 3529 */     return 16;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInOrderBy() throws SQLException {
/* 3539 */     return 64;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInSelect() throws SQLException {
/* 3549 */     return 256;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInTable() throws SQLException {
/* 3559 */     return 512;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxConnections() throws SQLException {
/* 3569 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCursorNameLength() throws SQLException {
/* 3579 */     return 64;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxIndexLength() throws SQLException {
/* 3589 */     return 256;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxProcedureNameLength() throws SQLException {
/* 3599 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRowSize() throws SQLException {
/* 3609 */     return 2147483639;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxSchemaNameLength() throws SQLException {
/* 3619 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxStatementLength() throws SQLException {
/* 3629 */     return MysqlIO.getMaxBuf() - 4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxStatements() throws SQLException {
/* 3639 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxTableNameLength() throws SQLException {
/* 3649 */     return 64;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxTablesInSelect() throws SQLException {
/* 3659 */     return 256;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxUserNameLength() throws SQLException {
/* 3669 */     return 16;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNumericFunctions() throws SQLException {
/* 3679 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,BIT_COUNT,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MAX,MIN,MOD,PI,POW,POWER,RADIANS,RAND,ROUND,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getPrimaryKeys(String catalog, String schema, final String table) throws SQLException {
/* 3708 */     Field[] fields = new Field[6];
/* 3709 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3710 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3711 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3712 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 3713 */     fields[4] = new Field("", "KEY_SEQ", 5, 5);
/* 3714 */     fields[5] = new Field("", "PK_NAME", 1, 32);
/*      */     
/* 3716 */     if (table == null) {
/* 3717 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 3720 */     final ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/* 3721 */     final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */     
/*      */     try {
/* 3725 */       (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException {
/* 3728 */             ResultSet rs = null;
/*      */ 
/*      */             
/*      */             try {
/* 3732 */               StringBuilder queryBuf = new StringBuilder("SHOW KEYS FROM ");
/* 3733 */               queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 3734 */               queryBuf.append(" FROM ");
/* 3735 */               queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/*      */               
/* 3737 */               rs = stmt.executeQuery(queryBuf.toString());
/*      */               
/* 3739 */               TreeMap<String, byte[][]> sortMap = (TreeMap)new TreeMap<String, byte>();
/*      */               
/* 3741 */               while (rs.next()) {
/* 3742 */                 String keyType = rs.getString("Key_name");
/*      */                 
/* 3744 */                 if (keyType != null && (
/* 3745 */                   keyType.equalsIgnoreCase("PRIMARY") || keyType.equalsIgnoreCase("PRI"))) {
/* 3746 */                   byte[][] tuple = new byte[6][];
/* 3747 */                   tuple[0] = (catalogStr == null) ? new byte[0] : DatabaseMetaData.this.s2b(catalogStr);
/* 3748 */                   tuple[1] = null;
/* 3749 */                   tuple[2] = DatabaseMetaData.this.s2b(table);
/*      */                   
/* 3751 */                   String columnName = rs.getString("Column_name");
/* 3752 */                   tuple[3] = DatabaseMetaData.this.s2b(columnName);
/* 3753 */                   tuple[4] = DatabaseMetaData.this.s2b(rs.getString("Seq_in_index"));
/* 3754 */                   tuple[5] = DatabaseMetaData.this.s2b(keyType);
/* 3755 */                   sortMap.put(columnName, tuple);
/*      */                 } 
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 3761 */               Iterator<byte[][]> sortedIterator = (Iterator)sortMap.values().iterator();
/*      */               
/* 3763 */               while (sortedIterator.hasNext()) {
/* 3764 */                 rows.add(new ByteArrayRow(sortedIterator.next(), DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             } finally {
/*      */               
/* 3768 */               if (rs != null) {
/*      */                 try {
/* 3770 */                   rs.close();
/* 3771 */                 } catch (Exception ex) {}
/*      */ 
/*      */                 
/* 3774 */                 rs = null;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         }).doForAll();
/*      */     } finally {
/* 3780 */       if (stmt != null) {
/* 3781 */         stmt.close();
/*      */       }
/*      */     } 
/*      */     
/* 3785 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3787 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern) throws SQLException {
/* 3864 */     Field[] fields = createProcedureColumnsFields();
/*      */     
/* 3866 */     return getProcedureOrFunctionColumns(fields, catalog, schemaPattern, procedureNamePattern, columnNamePattern, true, true);
/*      */   }
/*      */   
/*      */   protected Field[] createProcedureColumnsFields() {
/* 3870 */     Field[] fields = new Field[20];
/*      */     
/* 3872 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 512);
/* 3873 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 512);
/* 3874 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 512);
/* 3875 */     fields[3] = new Field("", "COLUMN_NAME", 1, 512);
/* 3876 */     fields[4] = new Field("", "COLUMN_TYPE", 1, 64);
/* 3877 */     fields[5] = new Field("", "DATA_TYPE", 5, 6);
/* 3878 */     fields[6] = new Field("", "TYPE_NAME", 1, 64);
/* 3879 */     fields[7] = new Field("", "PRECISION", 4, 12);
/* 3880 */     fields[8] = new Field("", "LENGTH", 4, 12);
/* 3881 */     fields[9] = new Field("", "SCALE", 5, 12);
/* 3882 */     fields[10] = new Field("", "RADIX", 5, 6);
/* 3883 */     fields[11] = new Field("", "NULLABLE", 5, 6);
/* 3884 */     fields[12] = new Field("", "REMARKS", 1, 512);
/* 3885 */     fields[13] = new Field("", "COLUMN_DEF", 1, 512);
/* 3886 */     fields[14] = new Field("", "SQL_DATA_TYPE", 4, 12);
/* 3887 */     fields[15] = new Field("", "SQL_DATETIME_SUB", 4, 12);
/* 3888 */     fields[16] = new Field("", "CHAR_OCTET_LENGTH", 4, 12);
/* 3889 */     fields[17] = new Field("", "ORDINAL_POSITION", 4, 12);
/* 3890 */     fields[18] = new Field("", "IS_NULLABLE", 1, 512);
/* 3891 */     fields[19] = new Field("", "SPECIFIC_NAME", 1, 512);
/* 3892 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSet getProcedureOrFunctionColumns(Field[] fields, String catalog, String schemaPattern, String procedureOrFunctionNamePattern, String columnNamePattern, boolean returnProcedures, boolean returnFunctions) throws SQLException {
/* 3898 */     List<ComparableWrapper<String, ProcedureType>> procsOrFuncsToExtractList = new ArrayList<ComparableWrapper<String, ProcedureType>>();
/*      */     
/* 3900 */     ResultSet procsAndOrFuncsRs = null;
/*      */     
/* 3902 */     if (supportsStoredProcedures()) {
/*      */       
/*      */       try {
/* 3905 */         String tmpProcedureOrFunctionNamePattern = null;
/*      */         
/* 3907 */         if (procedureOrFunctionNamePattern != null && !procedureOrFunctionNamePattern.equals("%")) {
/* 3908 */           tmpProcedureOrFunctionNamePattern = StringUtils.sanitizeProcOrFuncName(procedureOrFunctionNamePattern);
/*      */         }
/*      */ 
/*      */         
/* 3912 */         if (tmpProcedureOrFunctionNamePattern == null) {
/* 3913 */           tmpProcedureOrFunctionNamePattern = procedureOrFunctionNamePattern;
/*      */         }
/*      */         else {
/*      */           
/* 3917 */           String tmpCatalog = catalog;
/* 3918 */           List<String> parseList = StringUtils.splitDBdotName(tmpProcedureOrFunctionNamePattern, tmpCatalog, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */ 
/*      */ 
/*      */           
/* 3922 */           if (parseList.size() == 2) {
/* 3923 */             tmpCatalog = parseList.get(0);
/* 3924 */             tmpProcedureOrFunctionNamePattern = parseList.get(1);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 3930 */         procsAndOrFuncsRs = getProceduresAndOrFunctions(createFieldMetadataForGetProcedures(), catalog, schemaPattern, tmpProcedureOrFunctionNamePattern, returnProcedures, returnFunctions);
/*      */ 
/*      */         
/* 3933 */         boolean hasResults = false;
/* 3934 */         while (procsAndOrFuncsRs.next()) {
/* 3935 */           procsOrFuncsToExtractList.add(new ComparableWrapper<String, ProcedureType>(getFullyQualifiedName(procsAndOrFuncsRs.getString(1), procsAndOrFuncsRs.getString(3)), (procsAndOrFuncsRs.getShort(8) == 1) ? ProcedureType.PROCEDURE : ProcedureType.FUNCTION));
/*      */ 
/*      */           
/* 3938 */           hasResults = true;
/*      */         } 
/*      */ 
/*      */         
/* 3942 */         if (hasResults)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3949 */           Collections.sort(procsOrFuncsToExtractList);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/* 3956 */         SQLException rethrowSqlEx = null;
/*      */         
/* 3958 */         if (procsAndOrFuncsRs != null) {
/*      */           try {
/* 3960 */             procsAndOrFuncsRs.close();
/* 3961 */           } catch (SQLException sqlEx) {
/* 3962 */             rethrowSqlEx = sqlEx;
/*      */           } 
/*      */         }
/*      */         
/* 3966 */         if (rethrowSqlEx != null) {
/* 3967 */           throw rethrowSqlEx;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 3972 */     ArrayList<ResultSetRow> resultRows = new ArrayList<ResultSetRow>();
/* 3973 */     int idx = 0;
/* 3974 */     String procNameToCall = "";
/*      */     
/* 3976 */     for (ComparableWrapper<String, ProcedureType> procOrFunc : procsOrFuncsToExtractList) {
/* 3977 */       String procName = procOrFunc.getKey();
/* 3978 */       ProcedureType procType = procOrFunc.getValue();
/*      */ 
/*      */       
/* 3981 */       if (!" ".equals(this.quotedId)) {
/* 3982 */         idx = StringUtils.indexOfIgnoreCase(0, procName, ".", this.quotedId, this.quotedId, this.conn.isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
/*      */       } else {
/*      */         
/* 3985 */         idx = procName.indexOf(".");
/*      */       } 
/*      */       
/* 3988 */       if (idx > 0) {
/* 3989 */         catalog = StringUtils.unQuoteIdentifier(procName.substring(0, idx), this.quotedId);
/* 3990 */         procNameToCall = procName;
/*      */       } else {
/*      */         
/* 3993 */         procNameToCall = procName;
/*      */       } 
/* 3995 */       getCallStmtParameterTypes(catalog, procNameToCall, procType, columnNamePattern, resultRows, (fields.length == 17));
/*      */     } 
/*      */     
/* 3998 */     return buildResultSet(fields, resultRows);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern) throws SQLException {
/* 4038 */     Field[] fields = createFieldMetadataForGetProcedures();
/*      */     
/* 4040 */     return getProceduresAndOrFunctions(fields, catalog, schemaPattern, procedureNamePattern, true, true);
/*      */   }
/*      */   
/*      */   protected Field[] createFieldMetadataForGetProcedures() {
/* 4044 */     Field[] fields = new Field[9];
/* 4045 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 255);
/* 4046 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 255);
/* 4047 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 255);
/* 4048 */     fields[3] = new Field("", "reserved1", 1, 0);
/* 4049 */     fields[4] = new Field("", "reserved2", 1, 0);
/* 4050 */     fields[5] = new Field("", "reserved3", 1, 0);
/* 4051 */     fields[6] = new Field("", "REMARKS", 1, 255);
/* 4052 */     fields[7] = new Field("", "PROCEDURE_TYPE", 5, 6);
/* 4053 */     fields[8] = new Field("", "SPECIFIC_NAME", 1, 255);
/*      */     
/* 4055 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSet getProceduresAndOrFunctions(final Field[] fields, String catalog, String schemaPattern, String procedureNamePattern, final boolean returnProcedures, final boolean returnFunctions) throws SQLException {
/* 4069 */     if (procedureNamePattern == null || procedureNamePattern.length() == 0) {
/* 4070 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4071 */         procedureNamePattern = "%";
/*      */       } else {
/* 4073 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 4078 */     ArrayList<ResultSetRow> procedureRows = new ArrayList<ResultSetRow>();
/*      */     
/* 4080 */     if (supportsStoredProcedures()) {
/* 4081 */       final String procNamePattern = procedureNamePattern;
/*      */       
/* 4083 */       final List<ComparableWrapper<String, ResultSetRow>> procedureRowsToSort = new ArrayList<ComparableWrapper<String, ResultSetRow>>();
/*      */       
/* 4085 */       (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException {
/* 4088 */             String db = catalogStr;
/*      */             
/* 4090 */             ResultSet proceduresRs = null;
/* 4091 */             boolean needsClientFiltering = true;
/*      */             
/* 4093 */             StringBuilder selectFromMySQLProcSQL = new StringBuilder();
/*      */             
/* 4095 */             selectFromMySQLProcSQL.append("SELECT name, type, comment FROM mysql.proc WHERE ");
/* 4096 */             if (returnProcedures && !returnFunctions) {
/* 4097 */               selectFromMySQLProcSQL.append("type = 'PROCEDURE' AND ");
/* 4098 */             } else if (!returnProcedures && returnFunctions) {
/* 4099 */               selectFromMySQLProcSQL.append("type = 'FUNCTION' AND ");
/*      */             } 
/* 4101 */             selectFromMySQLProcSQL.append("name LIKE ? AND db <=> ? ORDER BY name, type");
/*      */             
/* 4103 */             PreparedStatement proceduresStmt = DatabaseMetaData.this.prepareMetaDataSafeStatement(selectFromMySQLProcSQL.toString());
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/* 4109 */               if (db != null) {
/* 4110 */                 if (DatabaseMetaData.this.conn.lowerCaseTableNames()) {
/* 4111 */                   db = db.toLowerCase();
/*      */                 }
/* 4113 */                 proceduresStmt.setString(2, db);
/*      */               } else {
/* 4115 */                 proceduresStmt.setNull(2, 12);
/*      */               } 
/*      */               
/* 4118 */               int nameIndex = 1;
/*      */               
/* 4120 */               proceduresStmt.setString(1, procNamePattern);
/*      */               
/*      */               try {
/* 4123 */                 proceduresRs = proceduresStmt.executeQuery();
/* 4124 */                 needsClientFiltering = false;
/*      */                 
/* 4126 */                 if (returnProcedures) {
/* 4127 */                   DatabaseMetaData.this.convertToJdbcProcedureList(true, db, proceduresRs, needsClientFiltering, db, procedureRowsToSort, nameIndex);
/*      */                 }
/*      */                 
/* 4130 */                 if (returnFunctions) {
/* 4131 */                   DatabaseMetaData.this.convertToJdbcFunctionList(db, proceduresRs, needsClientFiltering, db, procedureRowsToSort, nameIndex, fields);
/*      */                 }
/*      */               }
/* 4134 */               catch (SQLException sqlEx) {
/* 4135 */                 nameIndex = DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 1) ? 2 : 1;
/*      */ 
/*      */ 
/*      */                 
/* 4139 */                 if (returnFunctions) {
/* 4140 */                   proceduresStmt.close();
/*      */                   
/* 4142 */                   proceduresStmt = DatabaseMetaData.this.prepareMetaDataSafeStatement("SHOW FUNCTION STATUS LIKE ?");
/* 4143 */                   proceduresStmt.setString(1, procNamePattern);
/* 4144 */                   proceduresRs = proceduresStmt.executeQuery();
/*      */                   
/* 4146 */                   DatabaseMetaData.this.convertToJdbcFunctionList(db, proceduresRs, needsClientFiltering, db, procedureRowsToSort, nameIndex, fields);
/*      */                 } 
/*      */ 
/*      */                 
/* 4150 */                 if (returnProcedures) {
/* 4151 */                   proceduresStmt.close();
/*      */                   
/* 4153 */                   proceduresStmt = DatabaseMetaData.this.prepareMetaDataSafeStatement("SHOW PROCEDURE STATUS LIKE ?");
/* 4154 */                   proceduresStmt.setString(1, procNamePattern);
/* 4155 */                   proceduresRs = proceduresStmt.executeQuery();
/*      */                   
/* 4157 */                   DatabaseMetaData.this.convertToJdbcProcedureList(false, db, proceduresRs, needsClientFiltering, db, procedureRowsToSort, nameIndex);
/*      */                 } 
/*      */               } 
/*      */             } finally {
/*      */               
/* 4162 */               SQLException rethrowSqlEx = null;
/*      */               
/* 4164 */               if (proceduresRs != null) {
/*      */                 try {
/* 4166 */                   proceduresRs.close();
/* 4167 */                 } catch (SQLException sqlEx) {
/* 4168 */                   rethrowSqlEx = sqlEx;
/*      */                 } 
/*      */               }
/*      */               
/* 4172 */               if (proceduresStmt != null) {
/*      */                 try {
/* 4174 */                   proceduresStmt.close();
/* 4175 */                 } catch (SQLException sqlEx) {
/* 4176 */                   rethrowSqlEx = sqlEx;
/*      */                 } 
/*      */               }
/*      */               
/* 4180 */               if (rethrowSqlEx != null) {
/* 4181 */                 throw rethrowSqlEx;
/*      */               }
/*      */             } 
/*      */           }
/*      */         }).doForAll();
/*      */       
/* 4187 */       Collections.sort(procedureRowsToSort);
/* 4188 */       for (ComparableWrapper<String, ResultSetRow> procRow : procedureRowsToSort) {
/* 4189 */         procedureRows.add(procRow.getValue());
/*      */       }
/*      */     } 
/*      */     
/* 4193 */     return buildResultSet(fields, procedureRows);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProcedureTerm() throws SQLException {
/* 4204 */     return "PROCEDURE";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetHoldability() throws SQLException {
/* 4211 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void getResultsImpl(String catalog, String table, String keysComment, List<ResultSetRow> tuples, String fkTableName, boolean isExport) throws SQLException {
/* 4217 */     LocalAndReferencedColumns parsedInfo = parseTableStatusIntoLocalAndReferencedColumns(keysComment);
/*      */     
/* 4219 */     if (isExport && !parsedInfo.referencedTable.equals(table)) {
/*      */       return;
/*      */     }
/*      */     
/* 4223 */     if (parsedInfo.localColumnsList.size() != parsedInfo.referencedColumnsList.size()) {
/* 4224 */       throw SQLError.createSQLException("Error parsing foreign keys definition, number of local and referenced columns is not the same.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 4228 */     Iterator<String> localColumnNames = parsedInfo.localColumnsList.iterator();
/* 4229 */     Iterator<String> referColumnNames = parsedInfo.referencedColumnsList.iterator();
/*      */     
/* 4231 */     int keySeqIndex = 1;
/*      */     
/* 4233 */     while (localColumnNames.hasNext()) {
/* 4234 */       byte[][] tuple = new byte[14][];
/* 4235 */       String lColumnName = StringUtils.unQuoteIdentifier(localColumnNames.next(), this.quotedId);
/* 4236 */       String rColumnName = StringUtils.unQuoteIdentifier(referColumnNames.next(), this.quotedId);
/* 4237 */       tuple[4] = (catalog == null) ? new byte[0] : s2b(catalog);
/* 4238 */       tuple[5] = null;
/* 4239 */       tuple[6] = s2b(isExport ? fkTableName : table);
/* 4240 */       tuple[7] = s2b(lColumnName);
/* 4241 */       tuple[0] = s2b(parsedInfo.referencedCatalog);
/* 4242 */       tuple[1] = null;
/* 4243 */       tuple[2] = s2b(isExport ? table : parsedInfo.referencedTable);
/* 4244 */       tuple[3] = s2b(rColumnName);
/* 4245 */       tuple[8] = s2b(Integer.toString(keySeqIndex++));
/*      */       
/* 4247 */       int[] actions = getForeignKeyActions(keysComment);
/*      */       
/* 4249 */       tuple[9] = s2b(Integer.toString(actions[1]));
/* 4250 */       tuple[10] = s2b(Integer.toString(actions[0]));
/* 4251 */       tuple[11] = s2b(parsedInfo.constraintName);
/* 4252 */       tuple[12] = null;
/* 4253 */       tuple[13] = s2b(Integer.toString(7));
/* 4254 */       tuples.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSchemas() throws SQLException {
/* 4273 */     Field[] fields = new Field[2];
/* 4274 */     fields[0] = new Field("", "TABLE_SCHEM", 1, 0);
/* 4275 */     fields[1] = new Field("", "TABLE_CATALOG", 1, 0);
/*      */     
/* 4277 */     ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>();
/* 4278 */     ResultSet results = buildResultSet(fields, tuples);
/*      */     
/* 4280 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchemaTerm() throws SQLException {
/* 4290 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSearchStringEscape() throws SQLException {
/* 4307 */     return "\\";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSQLKeywords() throws SQLException {
/* 4317 */     if (mysqlKeywords != null) {
/* 4318 */       return mysqlKeywords;
/*      */     }
/*      */     
/* 4321 */     synchronized (DatabaseMetaData.class) {
/*      */       
/* 4323 */       if (mysqlKeywords != null) {
/* 4324 */         return mysqlKeywords;
/*      */       }
/*      */       
/* 4327 */       Set<String> mysqlKeywordSet = new TreeSet<String>();
/* 4328 */       StringBuilder mysqlKeywordsBuffer = new StringBuilder();
/*      */       
/* 4330 */       Collections.addAll(mysqlKeywordSet, MYSQL_KEYWORDS);
/* 4331 */       mysqlKeywordSet.removeAll(Arrays.asList(Util.isJdbc4() ? (Object[])SQL2003_KEYWORDS : (Object[])SQL92_KEYWORDS));
/*      */       
/* 4333 */       for (String keyword : mysqlKeywordSet) {
/* 4334 */         mysqlKeywordsBuffer.append(",").append(keyword);
/*      */       }
/*      */       
/* 4337 */       mysqlKeywords = mysqlKeywordsBuffer.substring(1);
/* 4338 */       return mysqlKeywords;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSQLStateType() throws SQLException {
/* 4346 */     if (this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 4347 */       return 2;
/*      */     }
/*      */     
/* 4350 */     if (this.conn.getUseSqlStateCodes()) {
/* 4351 */       return 2;
/*      */     }
/*      */     
/* 4354 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringFunctions() throws SQLException {
/* 4364 */     return "ASCII,BIN,BIT_LENGTH,CHAR,CHARACTER_LENGTH,CHAR_LENGTH,CONCAT,CONCAT_WS,CONV,ELT,EXPORT_SET,FIELD,FIND_IN_SET,HEX,INSERT,INSTR,LCASE,LEFT,LENGTH,LOAD_FILE,LOCATE,LOCATE,LOWER,LPAD,LTRIM,MAKE_SET,MATCH,MID,OCT,OCTET_LENGTH,ORD,POSITION,QUOTE,REPEAT,REPLACE,REVERSE,RIGHT,RPAD,RTRIM,SOUNDEX,SPACE,STRCMP,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING_INDEX,TRIM,UCASE,UPPER";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSuperTables(String arg0, String arg1, String arg2) throws SQLException {
/* 4374 */     Field[] fields = new Field[4];
/* 4375 */     fields[0] = new Field("", "TABLE_CAT", 1, 32);
/* 4376 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 32);
/* 4377 */     fields[2] = new Field("", "TABLE_NAME", 1, 32);
/* 4378 */     fields[3] = new Field("", "SUPERTABLE_NAME", 1, 32);
/*      */     
/* 4380 */     return buildResultSet(fields, new ArrayList<ResultSetRow>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSuperTypes(String arg0, String arg1, String arg2) throws SQLException {
/* 4387 */     Field[] fields = new Field[6];
/* 4388 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/* 4389 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/* 4390 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 4391 */     fields[3] = new Field("", "SUPERTYPE_CAT", 1, 32);
/* 4392 */     fields[4] = new Field("", "SUPERTYPE_SCHEM", 1, 32);
/* 4393 */     fields[5] = new Field("", "SUPERTYPE_NAME", 1, 32);
/*      */     
/* 4395 */     return buildResultSet(fields, new ArrayList<ResultSetRow>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSystemFunctions() throws SQLException {
/* 4405 */     return "DATABASE,USER,SYSTEM_USER,SESSION_USER,PASSWORD,ENCRYPT,LAST_INSERT_ID,VERSION";
/*      */   }
/*      */   
/*      */   protected String getTableNameWithCase(String table) {
/* 4409 */     String tableNameWithCase = this.conn.lowerCaseTableNames() ? table.toLowerCase() : table;
/*      */     
/* 4411 */     return tableNameWithCase;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
/*      */     // Byte code:
/*      */     //   0: aload_3
/*      */     //   1: ifnonnull -> 35
/*      */     //   4: aload_0
/*      */     //   5: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   8: invokeinterface getNullNamePatternMatchesAll : ()Z
/*      */     //   13: ifeq -> 22
/*      */     //   16: ldc '%'
/*      */     //   18: astore_3
/*      */     //   19: goto -> 35
/*      */     //   22: ldc_w 'Table name pattern can not be NULL or empty.'
/*      */     //   25: ldc 'S1009'
/*      */     //   27: aload_0
/*      */     //   28: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   31: invokestatic createSQLException : (Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   34: athrow
/*      */     //   35: bipush #7
/*      */     //   37: anewarray com/mysql/jdbc/Field
/*      */     //   40: astore #4
/*      */     //   42: aload #4
/*      */     //   44: iconst_0
/*      */     //   45: new com/mysql/jdbc/Field
/*      */     //   48: dup
/*      */     //   49: ldc ''
/*      */     //   51: ldc 'TABLE_CAT'
/*      */     //   53: iconst_1
/*      */     //   54: bipush #64
/*      */     //   56: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   59: aastore
/*      */     //   60: aload #4
/*      */     //   62: iconst_1
/*      */     //   63: new com/mysql/jdbc/Field
/*      */     //   66: dup
/*      */     //   67: ldc ''
/*      */     //   69: ldc_w 'TABLE_SCHEM'
/*      */     //   72: iconst_1
/*      */     //   73: iconst_1
/*      */     //   74: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   77: aastore
/*      */     //   78: aload #4
/*      */     //   80: iconst_2
/*      */     //   81: new com/mysql/jdbc/Field
/*      */     //   84: dup
/*      */     //   85: ldc ''
/*      */     //   87: ldc 'TABLE_NAME'
/*      */     //   89: iconst_1
/*      */     //   90: bipush #64
/*      */     //   92: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   95: aastore
/*      */     //   96: aload #4
/*      */     //   98: iconst_3
/*      */     //   99: new com/mysql/jdbc/Field
/*      */     //   102: dup
/*      */     //   103: ldc ''
/*      */     //   105: ldc_w 'GRANTOR'
/*      */     //   108: iconst_1
/*      */     //   109: bipush #77
/*      */     //   111: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   114: aastore
/*      */     //   115: aload #4
/*      */     //   117: iconst_4
/*      */     //   118: new com/mysql/jdbc/Field
/*      */     //   121: dup
/*      */     //   122: ldc ''
/*      */     //   124: ldc_w 'GRANTEE'
/*      */     //   127: iconst_1
/*      */     //   128: bipush #77
/*      */     //   130: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   133: aastore
/*      */     //   134: aload #4
/*      */     //   136: iconst_5
/*      */     //   137: new com/mysql/jdbc/Field
/*      */     //   140: dup
/*      */     //   141: ldc ''
/*      */     //   143: ldc_w 'PRIVILEGE'
/*      */     //   146: iconst_1
/*      */     //   147: bipush #64
/*      */     //   149: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   152: aastore
/*      */     //   153: aload #4
/*      */     //   155: bipush #6
/*      */     //   157: new com/mysql/jdbc/Field
/*      */     //   160: dup
/*      */     //   161: ldc ''
/*      */     //   163: ldc_w 'IS_GRANTABLE'
/*      */     //   166: iconst_1
/*      */     //   167: iconst_3
/*      */     //   168: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   171: aastore
/*      */     //   172: ldc_w 'SELECT host,db,table_name,grantor,user,table_priv FROM mysql.tables_priv WHERE db LIKE ? AND table_name LIKE ?'
/*      */     //   175: astore #5
/*      */     //   177: aconst_null
/*      */     //   178: astore #6
/*      */     //   180: new java/util/ArrayList
/*      */     //   183: dup
/*      */     //   184: invokespecial <init> : ()V
/*      */     //   187: astore #7
/*      */     //   189: aconst_null
/*      */     //   190: astore #8
/*      */     //   192: aload_0
/*      */     //   193: aload #5
/*      */     //   195: invokevirtual prepareMetaDataSafeStatement : (Ljava/lang/String;)Ljava/sql/PreparedStatement;
/*      */     //   198: astore #8
/*      */     //   200: aload #8
/*      */     //   202: iconst_1
/*      */     //   203: aload_1
/*      */     //   204: ifnull -> 218
/*      */     //   207: aload_1
/*      */     //   208: invokevirtual length : ()I
/*      */     //   211: ifeq -> 218
/*      */     //   214: aload_1
/*      */     //   215: goto -> 220
/*      */     //   218: ldc '%'
/*      */     //   220: invokeinterface setString : (ILjava/lang/String;)V
/*      */     //   225: aload #8
/*      */     //   227: iconst_2
/*      */     //   228: aload_3
/*      */     //   229: invokeinterface setString : (ILjava/lang/String;)V
/*      */     //   234: aload #8
/*      */     //   236: invokeinterface executeQuery : ()Ljava/sql/ResultSet;
/*      */     //   241: astore #6
/*      */     //   243: aload #6
/*      */     //   245: invokeinterface next : ()Z
/*      */     //   250: ifeq -> 594
/*      */     //   253: aload #6
/*      */     //   255: iconst_1
/*      */     //   256: invokeinterface getString : (I)Ljava/lang/String;
/*      */     //   261: astore #9
/*      */     //   263: aload #6
/*      */     //   265: iconst_2
/*      */     //   266: invokeinterface getString : (I)Ljava/lang/String;
/*      */     //   271: astore #10
/*      */     //   273: aload #6
/*      */     //   275: iconst_3
/*      */     //   276: invokeinterface getString : (I)Ljava/lang/String;
/*      */     //   281: astore #11
/*      */     //   283: aload #6
/*      */     //   285: iconst_4
/*      */     //   286: invokeinterface getString : (I)Ljava/lang/String;
/*      */     //   291: astore #12
/*      */     //   293: aload #6
/*      */     //   295: iconst_5
/*      */     //   296: invokeinterface getString : (I)Ljava/lang/String;
/*      */     //   301: astore #13
/*      */     //   303: aload #13
/*      */     //   305: ifnull -> 316
/*      */     //   308: aload #13
/*      */     //   310: invokevirtual length : ()I
/*      */     //   313: ifne -> 320
/*      */     //   316: ldc '%'
/*      */     //   318: astore #13
/*      */     //   320: new java/lang/StringBuilder
/*      */     //   323: dup
/*      */     //   324: aload #13
/*      */     //   326: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   329: astore #14
/*      */     //   331: aload #9
/*      */     //   333: ifnull -> 365
/*      */     //   336: aload_0
/*      */     //   337: getfield conn : Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   340: invokeinterface getUseHostsInPrivileges : ()Z
/*      */     //   345: ifeq -> 365
/*      */     //   348: aload #14
/*      */     //   350: ldc_w '@'
/*      */     //   353: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   356: pop
/*      */     //   357: aload #14
/*      */     //   359: aload #9
/*      */     //   361: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   364: pop
/*      */     //   365: aload #6
/*      */     //   367: bipush #6
/*      */     //   369: invokeinterface getString : (I)Ljava/lang/String;
/*      */     //   374: astore #15
/*      */     //   376: aload #15
/*      */     //   378: ifnull -> 591
/*      */     //   381: aload #15
/*      */     //   383: getstatic java/util/Locale.ENGLISH : Ljava/util/Locale;
/*      */     //   386: invokevirtual toUpperCase : (Ljava/util/Locale;)Ljava/lang/String;
/*      */     //   389: astore #15
/*      */     //   391: new java/util/StringTokenizer
/*      */     //   394: dup
/*      */     //   395: aload #15
/*      */     //   397: ldc ','
/*      */     //   399: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   402: astore #16
/*      */     //   404: aload #16
/*      */     //   406: invokevirtual hasMoreTokens : ()Z
/*      */     //   409: ifeq -> 591
/*      */     //   412: aload #16
/*      */     //   414: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   417: invokevirtual trim : ()Ljava/lang/String;
/*      */     //   420: astore #17
/*      */     //   422: aconst_null
/*      */     //   423: astore #18
/*      */     //   425: aload_0
/*      */     //   426: aload_1
/*      */     //   427: aload_2
/*      */     //   428: aload #11
/*      */     //   430: ldc '%'
/*      */     //   432: invokevirtual getColumns : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */     //   435: astore #18
/*      */     //   437: aload #18
/*      */     //   439: invokeinterface next : ()Z
/*      */     //   444: ifeq -> 553
/*      */     //   447: bipush #8
/*      */     //   449: anewarray [B
/*      */     //   452: astore #19
/*      */     //   454: aload #19
/*      */     //   456: iconst_0
/*      */     //   457: aload_0
/*      */     //   458: aload #10
/*      */     //   460: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */     //   463: aastore
/*      */     //   464: aload #19
/*      */     //   466: iconst_1
/*      */     //   467: aconst_null
/*      */     //   468: aastore
/*      */     //   469: aload #19
/*      */     //   471: iconst_2
/*      */     //   472: aload_0
/*      */     //   473: aload #11
/*      */     //   475: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */     //   478: aastore
/*      */     //   479: aload #12
/*      */     //   481: ifnull -> 497
/*      */     //   484: aload #19
/*      */     //   486: iconst_3
/*      */     //   487: aload_0
/*      */     //   488: aload #12
/*      */     //   490: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */     //   493: aastore
/*      */     //   494: goto -> 502
/*      */     //   497: aload #19
/*      */     //   499: iconst_3
/*      */     //   500: aconst_null
/*      */     //   501: aastore
/*      */     //   502: aload #19
/*      */     //   504: iconst_4
/*      */     //   505: aload_0
/*      */     //   506: aload #14
/*      */     //   508: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   511: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */     //   514: aastore
/*      */     //   515: aload #19
/*      */     //   517: iconst_5
/*      */     //   518: aload_0
/*      */     //   519: aload #17
/*      */     //   521: invokevirtual s2b : (Ljava/lang/String;)[B
/*      */     //   524: aastore
/*      */     //   525: aload #19
/*      */     //   527: bipush #6
/*      */     //   529: aconst_null
/*      */     //   530: aastore
/*      */     //   531: aload #7
/*      */     //   533: new com/mysql/jdbc/ByteArrayRow
/*      */     //   536: dup
/*      */     //   537: aload #19
/*      */     //   539: aload_0
/*      */     //   540: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   543: invokespecial <init> : ([[BLcom/mysql/jdbc/ExceptionInterceptor;)V
/*      */     //   546: invokevirtual add : (Ljava/lang/Object;)Z
/*      */     //   549: pop
/*      */     //   550: goto -> 437
/*      */     //   553: jsr -> 567
/*      */     //   556: goto -> 588
/*      */     //   559: astore #20
/*      */     //   561: jsr -> 567
/*      */     //   564: aload #20
/*      */     //   566: athrow
/*      */     //   567: astore #21
/*      */     //   569: aload #18
/*      */     //   571: ifnull -> 586
/*      */     //   574: aload #18
/*      */     //   576: invokeinterface close : ()V
/*      */     //   581: goto -> 586
/*      */     //   584: astore #22
/*      */     //   586: ret #21
/*      */     //   588: goto -> 404
/*      */     //   591: goto -> 243
/*      */     //   594: jsr -> 608
/*      */     //   597: goto -> 652
/*      */     //   600: astore #23
/*      */     //   602: jsr -> 608
/*      */     //   605: aload #23
/*      */     //   607: athrow
/*      */     //   608: astore #24
/*      */     //   610: aload #6
/*      */     //   612: ifnull -> 630
/*      */     //   615: aload #6
/*      */     //   617: invokeinterface close : ()V
/*      */     //   622: goto -> 627
/*      */     //   625: astore #25
/*      */     //   627: aconst_null
/*      */     //   628: astore #6
/*      */     //   630: aload #8
/*      */     //   632: ifnull -> 650
/*      */     //   635: aload #8
/*      */     //   637: invokeinterface close : ()V
/*      */     //   642: goto -> 647
/*      */     //   645: astore #25
/*      */     //   647: aconst_null
/*      */     //   648: astore #8
/*      */     //   650: ret #24
/*      */     //   652: aload_0
/*      */     //   653: aload #4
/*      */     //   655: aload #7
/*      */     //   657: invokespecial buildResultSet : ([Lcom/mysql/jdbc/Field;Ljava/util/ArrayList;)Ljava/sql/ResultSet;
/*      */     //   660: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #4447	-> 0
/*      */     //   #4448	-> 4
/*      */     //   #4449	-> 16
/*      */     //   #4451	-> 22
/*      */     //   #4456	-> 35
/*      */     //   #4457	-> 42
/*      */     //   #4458	-> 60
/*      */     //   #4459	-> 78
/*      */     //   #4460	-> 96
/*      */     //   #4461	-> 115
/*      */     //   #4462	-> 134
/*      */     //   #4463	-> 153
/*      */     //   #4465	-> 172
/*      */     //   #4467	-> 177
/*      */     //   #4468	-> 180
/*      */     //   #4469	-> 189
/*      */     //   #4472	-> 192
/*      */     //   #4474	-> 200
/*      */     //   #4475	-> 225
/*      */     //   #4477	-> 234
/*      */     //   #4479	-> 243
/*      */     //   #4480	-> 253
/*      */     //   #4481	-> 263
/*      */     //   #4482	-> 273
/*      */     //   #4483	-> 283
/*      */     //   #4484	-> 293
/*      */     //   #4486	-> 303
/*      */     //   #4487	-> 316
/*      */     //   #4490	-> 320
/*      */     //   #4492	-> 331
/*      */     //   #4493	-> 348
/*      */     //   #4494	-> 357
/*      */     //   #4497	-> 365
/*      */     //   #4499	-> 376
/*      */     //   #4500	-> 381
/*      */     //   #4502	-> 391
/*      */     //   #4504	-> 404
/*      */     //   #4505	-> 412
/*      */     //   #4508	-> 422
/*      */     //   #4511	-> 425
/*      */     //   #4513	-> 437
/*      */     //   #4514	-> 447
/*      */     //   #4515	-> 454
/*      */     //   #4516	-> 464
/*      */     //   #4517	-> 469
/*      */     //   #4519	-> 479
/*      */     //   #4520	-> 484
/*      */     //   #4522	-> 497
/*      */     //   #4525	-> 502
/*      */     //   #4526	-> 515
/*      */     //   #4527	-> 525
/*      */     //   #4528	-> 531
/*      */     //   #4529	-> 550
/*      */     //   #4530	-> 553
/*      */     //   #4537	-> 556
/*      */     //   #4531	-> 559
/*      */     //   #4533	-> 574
/*      */     //   #4535	-> 581
/*      */     //   #4534	-> 584
/*      */     //   #4535	-> 586
/*      */     //   #4538	-> 588
/*      */     //   #4540	-> 591
/*      */     //   #4541	-> 594
/*      */     //   #4559	-> 597
/*      */     //   #4542	-> 600
/*      */     //   #4544	-> 615
/*      */     //   #4546	-> 622
/*      */     //   #4545	-> 625
/*      */     //   #4548	-> 627
/*      */     //   #4551	-> 630
/*      */     //   #4553	-> 635
/*      */     //   #4555	-> 642
/*      */     //   #4554	-> 645
/*      */     //   #4557	-> 647
/*      */     //   #4561	-> 652
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   454	96	19	tuple	[[B
/*      */     //   586	0	22	ex	Ljava/lang/Exception;
/*      */     //   422	166	17	privilege	Ljava/lang/String;
/*      */     //   425	163	18	columnResults	Ljava/sql/ResultSet;
/*      */     //   404	187	16	st	Ljava/util/StringTokenizer;
/*      */     //   263	328	9	host	Ljava/lang/String;
/*      */     //   273	318	10	db	Ljava/lang/String;
/*      */     //   283	308	11	table	Ljava/lang/String;
/*      */     //   293	298	12	grantor	Ljava/lang/String;
/*      */     //   303	288	13	user	Ljava/lang/String;
/*      */     //   331	260	14	fullUser	Ljava/lang/StringBuilder;
/*      */     //   376	215	15	allPrivileges	Ljava/lang/String;
/*      */     //   627	0	25	ex	Ljava/lang/Exception;
/*      */     //   647	0	25	ex	Ljava/lang/Exception;
/*      */     //   0	661	0	this	Lcom/mysql/jdbc/DatabaseMetaData;
/*      */     //   0	661	1	catalog	Ljava/lang/String;
/*      */     //   0	661	2	schemaPattern	Ljava/lang/String;
/*      */     //   0	661	3	tableNamePattern	Ljava/lang/String;
/*      */     //   42	619	4	fields	[Lcom/mysql/jdbc/Field;
/*      */     //   177	484	5	grantQuery	Ljava/lang/String;
/*      */     //   180	481	6	results	Ljava/sql/ResultSet;
/*      */     //   189	472	7	grantRows	Ljava/util/ArrayList;
/*      */     //   192	469	8	pStmt	Ljava/sql/PreparedStatement;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   189	472	7	grantRows	Ljava/util/ArrayList<Lcom/mysql/jdbc/ResultSetRow;>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   192	597	600	finally
/*      */     //   425	556	559	finally
/*      */     //   559	564	559	finally
/*      */     //   574	581	584	java/lang/Exception
/*      */     //   600	605	600	finally
/*      */     //   615	622	625	java/lang/Exception
/*      */     //   635	642	645	java/lang/Exception
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, final String[] types) throws SQLException {
/*      */     final String tableNamePat;
/* 4599 */     if (tableNamePattern == null) {
/* 4600 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4601 */         tableNamePattern = "%";
/*      */       } else {
/* 4603 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 4608 */     final SortedMap<TableMetaDataKey, ResultSetRow> sortedRows = new TreeMap<TableMetaDataKey, ResultSetRow>();
/* 4609 */     ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>();
/*      */     
/* 4611 */     final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */     
/* 4614 */     String tmpCat = "";
/*      */     
/* 4616 */     if (catalog == null || catalog.length() == 0) {
/* 4617 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 4618 */         tmpCat = this.database;
/*      */       }
/*      */     } else {
/* 4621 */       tmpCat = catalog;
/*      */     } 
/*      */     
/* 4624 */     List<String> parseList = StringUtils.splitDBdotName(tableNamePattern, tmpCat, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */     
/* 4626 */     if (parseList.size() == 2) {
/* 4627 */       tableNamePat = parseList.get(1);
/*      */     } else {
/* 4629 */       tableNamePat = tableNamePattern;
/*      */     } 
/*      */     
/*      */     try {
/* 4633 */       (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException {
/* 4636 */             boolean operatingOnSystemDB = ("information_schema".equalsIgnoreCase(catalogStr) || "mysql".equalsIgnoreCase(catalogStr) || "performance_schema".equalsIgnoreCase(catalogStr));
/*      */ 
/*      */             
/* 4639 */             ResultSet results = null;
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/* 4644 */               results = stmt.executeQuery((!DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 2) ? "SHOW TABLES FROM " : "SHOW FULL TABLES FROM ") + StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()) + " LIKE " + StringUtils.quoteIdentifier(tableNamePat, "'", true));
/*      */ 
/*      */             
/*      */             }
/* 4648 */             catch (SQLException sqlEx) {
/* 4649 */               if ("08S01".equals(sqlEx.getSQLState())) {
/* 4650 */                 throw sqlEx;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               return;
/*      */             } finally {
/* 4795 */               if (results != null) {
/*      */                 try {
/* 4797 */                   results.close();
/* 4798 */                 } catch (Exception ex) {}
/*      */ 
/*      */                 
/* 4801 */                 results = null;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         }).doForAll();
/*      */     } finally {
/* 4807 */       if (stmt != null) {
/* 4808 */         stmt.close();
/*      */       }
/*      */     } 
/*      */     
/* 4812 */     tuples.addAll(sortedRows.values());
/* 4813 */     ResultSet tables = buildResultSet(createTablesFields(), tuples);
/*      */     
/* 4815 */     return tables;
/*      */   }
/*      */   
/*      */   protected Field[] createTablesFields() {
/* 4819 */     Field[] fields = new Field[10];
/* 4820 */     fields[0] = new Field("", "TABLE_CAT", 12, 255);
/* 4821 */     fields[1] = new Field("", "TABLE_SCHEM", 12, 0);
/* 4822 */     fields[2] = new Field("", "TABLE_NAME", 12, 255);
/* 4823 */     fields[3] = new Field("", "TABLE_TYPE", 12, 5);
/* 4824 */     fields[4] = new Field("", "REMARKS", 12, 0);
/* 4825 */     fields[5] = new Field("", "TYPE_CAT", 12, 0);
/* 4826 */     fields[6] = new Field("", "TYPE_SCHEM", 12, 0);
/* 4827 */     fields[7] = new Field("", "TYPE_NAME", 12, 0);
/* 4828 */     fields[8] = new Field("", "SELF_REFERENCING_COL_NAME", 12, 0);
/* 4829 */     fields[9] = new Field("", "REF_GENERATION", 12, 0);
/* 4830 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTableTypes() throws SQLException {
/* 4849 */     ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>();
/* 4850 */     Field[] fields = { new Field("", "TABLE_TYPE", 12, 256) };
/*      */     
/* 4852 */     boolean minVersion5_0_1 = this.conn.versionMeetsMinimum(5, 0, 1);
/*      */     
/* 4854 */     tuples.add(new ByteArrayRow(new byte[][] { TableType.LOCAL_TEMPORARY.asBytes() }, getExceptionInterceptor()));
/* 4855 */     tuples.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_TABLE.asBytes() }, getExceptionInterceptor()));
/* 4856 */     if (minVersion5_0_1) {
/* 4857 */       tuples.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_VIEW.asBytes() }, getExceptionInterceptor()));
/*      */     }
/* 4859 */     tuples.add(new ByteArrayRow(new byte[][] { TableType.TABLE.asBytes() }, getExceptionInterceptor()));
/* 4860 */     if (minVersion5_0_1) {
/* 4861 */       tuples.add(new ByteArrayRow(new byte[][] { TableType.VIEW.asBytes() }, getExceptionInterceptor()));
/*      */     }
/*      */     
/* 4864 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTimeDateFunctions() throws SQLException {
/* 4874 */     return "DAYOFWEEK,WEEKDAY,DAYOFMONTH,DAYOFYEAR,MONTH,DAYNAME,MONTHNAME,QUARTER,WEEK,YEAR,HOUR,MINUTE,SECOND,PERIOD_ADD,PERIOD_DIFF,TO_DAYS,FROM_DAYS,DATE_FORMAT,TIME_FORMAT,CURDATE,CURRENT_DATE,CURTIME,CURRENT_TIME,NOW,SYSDATE,CURRENT_TIMESTAMP,UNIX_TIMESTAMP,FROM_UNIXTIME,SEC_TO_TIME,TIME_TO_SEC";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTypeInfo() throws SQLException {
/* 4968 */     Field[] fields = new Field[18];
/* 4969 */     fields[0] = new Field("", "TYPE_NAME", 1, 32);
/* 4970 */     fields[1] = new Field("", "DATA_TYPE", 4, 5);
/* 4971 */     fields[2] = new Field("", "PRECISION", 4, 10);
/* 4972 */     fields[3] = new Field("", "LITERAL_PREFIX", 1, 4);
/* 4973 */     fields[4] = new Field("", "LITERAL_SUFFIX", 1, 4);
/* 4974 */     fields[5] = new Field("", "CREATE_PARAMS", 1, 32);
/* 4975 */     fields[6] = new Field("", "NULLABLE", 5, 5);
/* 4976 */     fields[7] = new Field("", "CASE_SENSITIVE", 16, 3);
/* 4977 */     fields[8] = new Field("", "SEARCHABLE", 5, 3);
/* 4978 */     fields[9] = new Field("", "UNSIGNED_ATTRIBUTE", 16, 3);
/* 4979 */     fields[10] = new Field("", "FIXED_PREC_SCALE", 16, 3);
/* 4980 */     fields[11] = new Field("", "AUTO_INCREMENT", 16, 3);
/* 4981 */     fields[12] = new Field("", "LOCAL_TYPE_NAME", 1, 32);
/* 4982 */     fields[13] = new Field("", "MINIMUM_SCALE", 5, 5);
/* 4983 */     fields[14] = new Field("", "MAXIMUM_SCALE", 5, 5);
/* 4984 */     fields[15] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 4985 */     fields[16] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 4986 */     fields[17] = new Field("", "NUM_PREC_RADIX", 4, 10);
/*      */     
/* 4988 */     byte[][] rowVal = (byte[][])null;
/* 4989 */     ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4997 */     rowVal = new byte[18][];
/* 4998 */     rowVal[0] = s2b("BIT");
/* 4999 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */ 
/*      */     
/* 5002 */     rowVal[2] = s2b("1");
/* 5003 */     rowVal[3] = s2b("");
/* 5004 */     rowVal[4] = s2b("");
/* 5005 */     rowVal[5] = s2b("");
/* 5006 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5009 */     rowVal[7] = s2b("true");
/* 5010 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5013 */     rowVal[9] = s2b("false");
/* 5014 */     rowVal[10] = s2b("false");
/* 5015 */     rowVal[11] = s2b("false");
/* 5016 */     rowVal[12] = s2b("BIT");
/* 5017 */     rowVal[13] = s2b("0");
/* 5018 */     rowVal[14] = s2b("0");
/* 5019 */     rowVal[15] = s2b("0");
/* 5020 */     rowVal[16] = s2b("0");
/* 5021 */     rowVal[17] = s2b("10");
/* 5022 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5027 */     rowVal = new byte[18][];
/* 5028 */     rowVal[0] = s2b("BOOL");
/* 5029 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */ 
/*      */     
/* 5032 */     rowVal[2] = s2b("1");
/* 5033 */     rowVal[3] = s2b("");
/* 5034 */     rowVal[4] = s2b("");
/* 5035 */     rowVal[5] = s2b("");
/* 5036 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5039 */     rowVal[7] = s2b("true");
/* 5040 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5043 */     rowVal[9] = s2b("false");
/* 5044 */     rowVal[10] = s2b("false");
/* 5045 */     rowVal[11] = s2b("false");
/* 5046 */     rowVal[12] = s2b("BOOL");
/* 5047 */     rowVal[13] = s2b("0");
/* 5048 */     rowVal[14] = s2b("0");
/* 5049 */     rowVal[15] = s2b("0");
/* 5050 */     rowVal[16] = s2b("0");
/* 5051 */     rowVal[17] = s2b("10");
/* 5052 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5057 */     rowVal = new byte[18][];
/* 5058 */     rowVal[0] = s2b("TINYINT");
/* 5059 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */ 
/*      */     
/* 5062 */     rowVal[2] = s2b("3");
/* 5063 */     rowVal[3] = s2b("");
/* 5064 */     rowVal[4] = s2b("");
/* 5065 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5066 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5069 */     rowVal[7] = s2b("false");
/* 5070 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5073 */     rowVal[9] = s2b("true");
/* 5074 */     rowVal[10] = s2b("false");
/* 5075 */     rowVal[11] = s2b("true");
/* 5076 */     rowVal[12] = s2b("TINYINT");
/* 5077 */     rowVal[13] = s2b("0");
/* 5078 */     rowVal[14] = s2b("0");
/* 5079 */     rowVal[15] = s2b("0");
/* 5080 */     rowVal[16] = s2b("0");
/* 5081 */     rowVal[17] = s2b("10");
/* 5082 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5084 */     rowVal = new byte[18][];
/* 5085 */     rowVal[0] = s2b("TINYINT UNSIGNED");
/* 5086 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */ 
/*      */     
/* 5089 */     rowVal[2] = s2b("3");
/* 5090 */     rowVal[3] = s2b("");
/* 5091 */     rowVal[4] = s2b("");
/* 5092 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5093 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5096 */     rowVal[7] = s2b("false");
/* 5097 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5100 */     rowVal[9] = s2b("true");
/* 5101 */     rowVal[10] = s2b("false");
/* 5102 */     rowVal[11] = s2b("true");
/* 5103 */     rowVal[12] = s2b("TINYINT UNSIGNED");
/* 5104 */     rowVal[13] = s2b("0");
/* 5105 */     rowVal[14] = s2b("0");
/* 5106 */     rowVal[15] = s2b("0");
/* 5107 */     rowVal[16] = s2b("0");
/* 5108 */     rowVal[17] = s2b("10");
/* 5109 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5114 */     rowVal = new byte[18][];
/* 5115 */     rowVal[0] = s2b("BIGINT");
/* 5116 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */ 
/*      */     
/* 5119 */     rowVal[2] = s2b("19");
/* 5120 */     rowVal[3] = s2b("");
/* 5121 */     rowVal[4] = s2b("");
/* 5122 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5123 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5126 */     rowVal[7] = s2b("false");
/* 5127 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5130 */     rowVal[9] = s2b("true");
/* 5131 */     rowVal[10] = s2b("false");
/* 5132 */     rowVal[11] = s2b("true");
/* 5133 */     rowVal[12] = s2b("BIGINT");
/* 5134 */     rowVal[13] = s2b("0");
/* 5135 */     rowVal[14] = s2b("0");
/* 5136 */     rowVal[15] = s2b("0");
/* 5137 */     rowVal[16] = s2b("0");
/* 5138 */     rowVal[17] = s2b("10");
/* 5139 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5141 */     rowVal = new byte[18][];
/* 5142 */     rowVal[0] = s2b("BIGINT UNSIGNED");
/* 5143 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */ 
/*      */     
/* 5146 */     rowVal[2] = s2b("20");
/* 5147 */     rowVal[3] = s2b("");
/* 5148 */     rowVal[4] = s2b("");
/* 5149 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5150 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5153 */     rowVal[7] = s2b("false");
/* 5154 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5157 */     rowVal[9] = s2b("true");
/* 5158 */     rowVal[10] = s2b("false");
/* 5159 */     rowVal[11] = s2b("true");
/* 5160 */     rowVal[12] = s2b("BIGINT UNSIGNED");
/* 5161 */     rowVal[13] = s2b("0");
/* 5162 */     rowVal[14] = s2b("0");
/* 5163 */     rowVal[15] = s2b("0");
/* 5164 */     rowVal[16] = s2b("0");
/* 5165 */     rowVal[17] = s2b("10");
/* 5166 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5171 */     rowVal = new byte[18][];
/* 5172 */     rowVal[0] = s2b("LONG VARBINARY");
/* 5173 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/*      */     
/* 5176 */     rowVal[2] = s2b("16777215");
/* 5177 */     rowVal[3] = s2b("'");
/* 5178 */     rowVal[4] = s2b("'");
/* 5179 */     rowVal[5] = s2b("");
/* 5180 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5183 */     rowVal[7] = s2b("true");
/* 5184 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5187 */     rowVal[9] = s2b("false");
/* 5188 */     rowVal[10] = s2b("false");
/* 5189 */     rowVal[11] = s2b("false");
/* 5190 */     rowVal[12] = s2b("LONG VARBINARY");
/* 5191 */     rowVal[13] = s2b("0");
/* 5192 */     rowVal[14] = s2b("0");
/* 5193 */     rowVal[15] = s2b("0");
/* 5194 */     rowVal[16] = s2b("0");
/* 5195 */     rowVal[17] = s2b("10");
/* 5196 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5201 */     rowVal = new byte[18][];
/* 5202 */     rowVal[0] = s2b("MEDIUMBLOB");
/* 5203 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/*      */     
/* 5206 */     rowVal[2] = s2b("16777215");
/* 5207 */     rowVal[3] = s2b("'");
/* 5208 */     rowVal[4] = s2b("'");
/* 5209 */     rowVal[5] = s2b("");
/* 5210 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5213 */     rowVal[7] = s2b("true");
/* 5214 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5217 */     rowVal[9] = s2b("false");
/* 5218 */     rowVal[10] = s2b("false");
/* 5219 */     rowVal[11] = s2b("false");
/* 5220 */     rowVal[12] = s2b("MEDIUMBLOB");
/* 5221 */     rowVal[13] = s2b("0");
/* 5222 */     rowVal[14] = s2b("0");
/* 5223 */     rowVal[15] = s2b("0");
/* 5224 */     rowVal[16] = s2b("0");
/* 5225 */     rowVal[17] = s2b("10");
/* 5226 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5231 */     rowVal = new byte[18][];
/* 5232 */     rowVal[0] = s2b("LONGBLOB");
/* 5233 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/*      */     
/* 5236 */     rowVal[2] = Integer.toString(2147483647).getBytes();
/*      */ 
/*      */     
/* 5239 */     rowVal[3] = s2b("'");
/* 5240 */     rowVal[4] = s2b("'");
/* 5241 */     rowVal[5] = s2b("");
/* 5242 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5245 */     rowVal[7] = s2b("true");
/* 5246 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5249 */     rowVal[9] = s2b("false");
/* 5250 */     rowVal[10] = s2b("false");
/* 5251 */     rowVal[11] = s2b("false");
/* 5252 */     rowVal[12] = s2b("LONGBLOB");
/* 5253 */     rowVal[13] = s2b("0");
/* 5254 */     rowVal[14] = s2b("0");
/* 5255 */     rowVal[15] = s2b("0");
/* 5256 */     rowVal[16] = s2b("0");
/* 5257 */     rowVal[17] = s2b("10");
/* 5258 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5263 */     rowVal = new byte[18][];
/* 5264 */     rowVal[0] = s2b("BLOB");
/* 5265 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/*      */     
/* 5268 */     rowVal[2] = s2b("65535");
/* 5269 */     rowVal[3] = s2b("'");
/* 5270 */     rowVal[4] = s2b("'");
/* 5271 */     rowVal[5] = s2b("");
/* 5272 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5275 */     rowVal[7] = s2b("true");
/* 5276 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5279 */     rowVal[9] = s2b("false");
/* 5280 */     rowVal[10] = s2b("false");
/* 5281 */     rowVal[11] = s2b("false");
/* 5282 */     rowVal[12] = s2b("BLOB");
/* 5283 */     rowVal[13] = s2b("0");
/* 5284 */     rowVal[14] = s2b("0");
/* 5285 */     rowVal[15] = s2b("0");
/* 5286 */     rowVal[16] = s2b("0");
/* 5287 */     rowVal[17] = s2b("10");
/* 5288 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5293 */     rowVal = new byte[18][];
/* 5294 */     rowVal[0] = s2b("TINYBLOB");
/* 5295 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/*      */     
/* 5298 */     rowVal[2] = s2b("255");
/* 5299 */     rowVal[3] = s2b("'");
/* 5300 */     rowVal[4] = s2b("'");
/* 5301 */     rowVal[5] = s2b("");
/* 5302 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5305 */     rowVal[7] = s2b("true");
/* 5306 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5309 */     rowVal[9] = s2b("false");
/* 5310 */     rowVal[10] = s2b("false");
/* 5311 */     rowVal[11] = s2b("false");
/* 5312 */     rowVal[12] = s2b("TINYBLOB");
/* 5313 */     rowVal[13] = s2b("0");
/* 5314 */     rowVal[14] = s2b("0");
/* 5315 */     rowVal[15] = s2b("0");
/* 5316 */     rowVal[16] = s2b("0");
/* 5317 */     rowVal[17] = s2b("10");
/* 5318 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5324 */     rowVal = new byte[18][];
/* 5325 */     rowVal[0] = s2b("VARBINARY");
/* 5326 */     rowVal[1] = Integer.toString(-3).getBytes();
/*      */ 
/*      */     
/* 5329 */     rowVal[2] = s2b(this.conn.versionMeetsMinimum(5, 0, 3) ? "65535" : "255");
/* 5330 */     rowVal[3] = s2b("'");
/* 5331 */     rowVal[4] = s2b("'");
/* 5332 */     rowVal[5] = s2b("(M)");
/* 5333 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5336 */     rowVal[7] = s2b("true");
/* 5337 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5340 */     rowVal[9] = s2b("false");
/* 5341 */     rowVal[10] = s2b("false");
/* 5342 */     rowVal[11] = s2b("false");
/* 5343 */     rowVal[12] = s2b("VARBINARY");
/* 5344 */     rowVal[13] = s2b("0");
/* 5345 */     rowVal[14] = s2b("0");
/* 5346 */     rowVal[15] = s2b("0");
/* 5347 */     rowVal[16] = s2b("0");
/* 5348 */     rowVal[17] = s2b("10");
/* 5349 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5355 */     rowVal = new byte[18][];
/* 5356 */     rowVal[0] = s2b("BINARY");
/* 5357 */     rowVal[1] = Integer.toString(-2).getBytes();
/*      */ 
/*      */     
/* 5360 */     rowVal[2] = s2b("255");
/* 5361 */     rowVal[3] = s2b("'");
/* 5362 */     rowVal[4] = s2b("'");
/* 5363 */     rowVal[5] = s2b("(M)");
/* 5364 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5367 */     rowVal[7] = s2b("true");
/* 5368 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5371 */     rowVal[9] = s2b("false");
/* 5372 */     rowVal[10] = s2b("false");
/* 5373 */     rowVal[11] = s2b("false");
/* 5374 */     rowVal[12] = s2b("BINARY");
/* 5375 */     rowVal[13] = s2b("0");
/* 5376 */     rowVal[14] = s2b("0");
/* 5377 */     rowVal[15] = s2b("0");
/* 5378 */     rowVal[16] = s2b("0");
/* 5379 */     rowVal[17] = s2b("10");
/* 5380 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5385 */     rowVal = new byte[18][];
/* 5386 */     rowVal[0] = s2b("LONG VARCHAR");
/* 5387 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/*      */     
/* 5390 */     rowVal[2] = s2b("16777215");
/* 5391 */     rowVal[3] = s2b("'");
/* 5392 */     rowVal[4] = s2b("'");
/* 5393 */     rowVal[5] = s2b("");
/* 5394 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5397 */     rowVal[7] = s2b("false");
/* 5398 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5401 */     rowVal[9] = s2b("false");
/* 5402 */     rowVal[10] = s2b("false");
/* 5403 */     rowVal[11] = s2b("false");
/* 5404 */     rowVal[12] = s2b("LONG VARCHAR");
/* 5405 */     rowVal[13] = s2b("0");
/* 5406 */     rowVal[14] = s2b("0");
/* 5407 */     rowVal[15] = s2b("0");
/* 5408 */     rowVal[16] = s2b("0");
/* 5409 */     rowVal[17] = s2b("10");
/* 5410 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5415 */     rowVal = new byte[18][];
/* 5416 */     rowVal[0] = s2b("MEDIUMTEXT");
/* 5417 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/*      */     
/* 5420 */     rowVal[2] = s2b("16777215");
/* 5421 */     rowVal[3] = s2b("'");
/* 5422 */     rowVal[4] = s2b("'");
/* 5423 */     rowVal[5] = s2b("");
/* 5424 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5427 */     rowVal[7] = s2b("false");
/* 5428 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5431 */     rowVal[9] = s2b("false");
/* 5432 */     rowVal[10] = s2b("false");
/* 5433 */     rowVal[11] = s2b("false");
/* 5434 */     rowVal[12] = s2b("MEDIUMTEXT");
/* 5435 */     rowVal[13] = s2b("0");
/* 5436 */     rowVal[14] = s2b("0");
/* 5437 */     rowVal[15] = s2b("0");
/* 5438 */     rowVal[16] = s2b("0");
/* 5439 */     rowVal[17] = s2b("10");
/* 5440 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5445 */     rowVal = new byte[18][];
/* 5446 */     rowVal[0] = s2b("LONGTEXT");
/* 5447 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/*      */     
/* 5450 */     rowVal[2] = Integer.toString(2147483647).getBytes();
/*      */ 
/*      */     
/* 5453 */     rowVal[3] = s2b("'");
/* 5454 */     rowVal[4] = s2b("'");
/* 5455 */     rowVal[5] = s2b("");
/* 5456 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5459 */     rowVal[7] = s2b("false");
/* 5460 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5463 */     rowVal[9] = s2b("false");
/* 5464 */     rowVal[10] = s2b("false");
/* 5465 */     rowVal[11] = s2b("false");
/* 5466 */     rowVal[12] = s2b("LONGTEXT");
/* 5467 */     rowVal[13] = s2b("0");
/* 5468 */     rowVal[14] = s2b("0");
/* 5469 */     rowVal[15] = s2b("0");
/* 5470 */     rowVal[16] = s2b("0");
/* 5471 */     rowVal[17] = s2b("10");
/* 5472 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5477 */     rowVal = new byte[18][];
/* 5478 */     rowVal[0] = s2b("TEXT");
/* 5479 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/*      */     
/* 5482 */     rowVal[2] = s2b("65535");
/* 5483 */     rowVal[3] = s2b("'");
/* 5484 */     rowVal[4] = s2b("'");
/* 5485 */     rowVal[5] = s2b("");
/* 5486 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5489 */     rowVal[7] = s2b("false");
/* 5490 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5493 */     rowVal[9] = s2b("false");
/* 5494 */     rowVal[10] = s2b("false");
/* 5495 */     rowVal[11] = s2b("false");
/* 5496 */     rowVal[12] = s2b("TEXT");
/* 5497 */     rowVal[13] = s2b("0");
/* 5498 */     rowVal[14] = s2b("0");
/* 5499 */     rowVal[15] = s2b("0");
/* 5500 */     rowVal[16] = s2b("0");
/* 5501 */     rowVal[17] = s2b("10");
/* 5502 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5507 */     rowVal = new byte[18][];
/* 5508 */     rowVal[0] = s2b("TINYTEXT");
/* 5509 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/*      */     
/* 5512 */     rowVal[2] = s2b("255");
/* 5513 */     rowVal[3] = s2b("'");
/* 5514 */     rowVal[4] = s2b("'");
/* 5515 */     rowVal[5] = s2b("");
/* 5516 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5519 */     rowVal[7] = s2b("false");
/* 5520 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5523 */     rowVal[9] = s2b("false");
/* 5524 */     rowVal[10] = s2b("false");
/* 5525 */     rowVal[11] = s2b("false");
/* 5526 */     rowVal[12] = s2b("TINYTEXT");
/* 5527 */     rowVal[13] = s2b("0");
/* 5528 */     rowVal[14] = s2b("0");
/* 5529 */     rowVal[15] = s2b("0");
/* 5530 */     rowVal[16] = s2b("0");
/* 5531 */     rowVal[17] = s2b("10");
/* 5532 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5537 */     rowVal = new byte[18][];
/* 5538 */     rowVal[0] = s2b("CHAR");
/* 5539 */     rowVal[1] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5542 */     rowVal[2] = s2b("255");
/* 5543 */     rowVal[3] = s2b("'");
/* 5544 */     rowVal[4] = s2b("'");
/* 5545 */     rowVal[5] = s2b("(M)");
/* 5546 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5549 */     rowVal[7] = s2b("false");
/* 5550 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5553 */     rowVal[9] = s2b("false");
/* 5554 */     rowVal[10] = s2b("false");
/* 5555 */     rowVal[11] = s2b("false");
/* 5556 */     rowVal[12] = s2b("CHAR");
/* 5557 */     rowVal[13] = s2b("0");
/* 5558 */     rowVal[14] = s2b("0");
/* 5559 */     rowVal[15] = s2b("0");
/* 5560 */     rowVal[16] = s2b("0");
/* 5561 */     rowVal[17] = s2b("10");
/* 5562 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */     
/* 5566 */     int decimalPrecision = 254;
/*      */     
/* 5568 */     if (this.conn.versionMeetsMinimum(5, 0, 3)) {
/* 5569 */       if (this.conn.versionMeetsMinimum(5, 0, 6)) {
/* 5570 */         decimalPrecision = 65;
/*      */       } else {
/* 5572 */         decimalPrecision = 64;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5579 */     rowVal = new byte[18][];
/* 5580 */     rowVal[0] = s2b("NUMERIC");
/* 5581 */     rowVal[1] = Integer.toString(2).getBytes();
/*      */ 
/*      */     
/* 5584 */     rowVal[2] = s2b(String.valueOf(decimalPrecision));
/* 5585 */     rowVal[3] = s2b("");
/* 5586 */     rowVal[4] = s2b("");
/* 5587 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 5588 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5591 */     rowVal[7] = s2b("false");
/* 5592 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5595 */     rowVal[9] = s2b("false");
/* 5596 */     rowVal[10] = s2b("false");
/* 5597 */     rowVal[11] = s2b("true");
/* 5598 */     rowVal[12] = s2b("NUMERIC");
/* 5599 */     rowVal[13] = s2b("-308");
/* 5600 */     rowVal[14] = s2b("308");
/* 5601 */     rowVal[15] = s2b("0");
/* 5602 */     rowVal[16] = s2b("0");
/* 5603 */     rowVal[17] = s2b("10");
/* 5604 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5609 */     rowVal = new byte[18][];
/* 5610 */     rowVal[0] = s2b("DECIMAL");
/* 5611 */     rowVal[1] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5614 */     rowVal[2] = s2b(String.valueOf(decimalPrecision));
/* 5615 */     rowVal[3] = s2b("");
/* 5616 */     rowVal[4] = s2b("");
/* 5617 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 5618 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5621 */     rowVal[7] = s2b("false");
/* 5622 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5625 */     rowVal[9] = s2b("false");
/* 5626 */     rowVal[10] = s2b("false");
/* 5627 */     rowVal[11] = s2b("true");
/* 5628 */     rowVal[12] = s2b("DECIMAL");
/* 5629 */     rowVal[13] = s2b("-308");
/* 5630 */     rowVal[14] = s2b("308");
/* 5631 */     rowVal[15] = s2b("0");
/* 5632 */     rowVal[16] = s2b("0");
/* 5633 */     rowVal[17] = s2b("10");
/* 5634 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5639 */     rowVal = new byte[18][];
/* 5640 */     rowVal[0] = s2b("INTEGER");
/* 5641 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/*      */     
/* 5644 */     rowVal[2] = s2b("10");
/* 5645 */     rowVal[3] = s2b("");
/* 5646 */     rowVal[4] = s2b("");
/* 5647 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5648 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5651 */     rowVal[7] = s2b("false");
/* 5652 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5655 */     rowVal[9] = s2b("true");
/* 5656 */     rowVal[10] = s2b("false");
/* 5657 */     rowVal[11] = s2b("true");
/* 5658 */     rowVal[12] = s2b("INTEGER");
/* 5659 */     rowVal[13] = s2b("0");
/* 5660 */     rowVal[14] = s2b("0");
/* 5661 */     rowVal[15] = s2b("0");
/* 5662 */     rowVal[16] = s2b("0");
/* 5663 */     rowVal[17] = s2b("10");
/* 5664 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5666 */     rowVal = new byte[18][];
/* 5667 */     rowVal[0] = s2b("INTEGER UNSIGNED");
/* 5668 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/*      */     
/* 5671 */     rowVal[2] = s2b("10");
/* 5672 */     rowVal[3] = s2b("");
/* 5673 */     rowVal[4] = s2b("");
/* 5674 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5675 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5678 */     rowVal[7] = s2b("false");
/* 5679 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5682 */     rowVal[9] = s2b("true");
/* 5683 */     rowVal[10] = s2b("false");
/* 5684 */     rowVal[11] = s2b("true");
/* 5685 */     rowVal[12] = s2b("INTEGER UNSIGNED");
/* 5686 */     rowVal[13] = s2b("0");
/* 5687 */     rowVal[14] = s2b("0");
/* 5688 */     rowVal[15] = s2b("0");
/* 5689 */     rowVal[16] = s2b("0");
/* 5690 */     rowVal[17] = s2b("10");
/* 5691 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5696 */     rowVal = new byte[18][];
/* 5697 */     rowVal[0] = s2b("INT");
/* 5698 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/*      */     
/* 5701 */     rowVal[2] = s2b("10");
/* 5702 */     rowVal[3] = s2b("");
/* 5703 */     rowVal[4] = s2b("");
/* 5704 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5705 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5708 */     rowVal[7] = s2b("false");
/* 5709 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5712 */     rowVal[9] = s2b("true");
/* 5713 */     rowVal[10] = s2b("false");
/* 5714 */     rowVal[11] = s2b("true");
/* 5715 */     rowVal[12] = s2b("INT");
/* 5716 */     rowVal[13] = s2b("0");
/* 5717 */     rowVal[14] = s2b("0");
/* 5718 */     rowVal[15] = s2b("0");
/* 5719 */     rowVal[16] = s2b("0");
/* 5720 */     rowVal[17] = s2b("10");
/* 5721 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5723 */     rowVal = new byte[18][];
/* 5724 */     rowVal[0] = s2b("INT UNSIGNED");
/* 5725 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/*      */     
/* 5728 */     rowVal[2] = s2b("10");
/* 5729 */     rowVal[3] = s2b("");
/* 5730 */     rowVal[4] = s2b("");
/* 5731 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5732 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5735 */     rowVal[7] = s2b("false");
/* 5736 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5739 */     rowVal[9] = s2b("true");
/* 5740 */     rowVal[10] = s2b("false");
/* 5741 */     rowVal[11] = s2b("true");
/* 5742 */     rowVal[12] = s2b("INT UNSIGNED");
/* 5743 */     rowVal[13] = s2b("0");
/* 5744 */     rowVal[14] = s2b("0");
/* 5745 */     rowVal[15] = s2b("0");
/* 5746 */     rowVal[16] = s2b("0");
/* 5747 */     rowVal[17] = s2b("10");
/* 5748 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5753 */     rowVal = new byte[18][];
/* 5754 */     rowVal[0] = s2b("MEDIUMINT");
/* 5755 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/*      */     
/* 5758 */     rowVal[2] = s2b("7");
/* 5759 */     rowVal[3] = s2b("");
/* 5760 */     rowVal[4] = s2b("");
/* 5761 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5762 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5765 */     rowVal[7] = s2b("false");
/* 5766 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5769 */     rowVal[9] = s2b("true");
/* 5770 */     rowVal[10] = s2b("false");
/* 5771 */     rowVal[11] = s2b("true");
/* 5772 */     rowVal[12] = s2b("MEDIUMINT");
/* 5773 */     rowVal[13] = s2b("0");
/* 5774 */     rowVal[14] = s2b("0");
/* 5775 */     rowVal[15] = s2b("0");
/* 5776 */     rowVal[16] = s2b("0");
/* 5777 */     rowVal[17] = s2b("10");
/* 5778 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5780 */     rowVal = new byte[18][];
/* 5781 */     rowVal[0] = s2b("MEDIUMINT UNSIGNED");
/* 5782 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/*      */     
/* 5785 */     rowVal[2] = s2b("8");
/* 5786 */     rowVal[3] = s2b("");
/* 5787 */     rowVal[4] = s2b("");
/* 5788 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5789 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5792 */     rowVal[7] = s2b("false");
/* 5793 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5796 */     rowVal[9] = s2b("true");
/* 5797 */     rowVal[10] = s2b("false");
/* 5798 */     rowVal[11] = s2b("true");
/* 5799 */     rowVal[12] = s2b("MEDIUMINT UNSIGNED");
/* 5800 */     rowVal[13] = s2b("0");
/* 5801 */     rowVal[14] = s2b("0");
/* 5802 */     rowVal[15] = s2b("0");
/* 5803 */     rowVal[16] = s2b("0");
/* 5804 */     rowVal[17] = s2b("10");
/* 5805 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5810 */     rowVal = new byte[18][];
/* 5811 */     rowVal[0] = s2b("SMALLINT");
/* 5812 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */ 
/*      */     
/* 5815 */     rowVal[2] = s2b("5");
/* 5816 */     rowVal[3] = s2b("");
/* 5817 */     rowVal[4] = s2b("");
/* 5818 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5819 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5822 */     rowVal[7] = s2b("false");
/* 5823 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5826 */     rowVal[9] = s2b("true");
/* 5827 */     rowVal[10] = s2b("false");
/* 5828 */     rowVal[11] = s2b("true");
/* 5829 */     rowVal[12] = s2b("SMALLINT");
/* 5830 */     rowVal[13] = s2b("0");
/* 5831 */     rowVal[14] = s2b("0");
/* 5832 */     rowVal[15] = s2b("0");
/* 5833 */     rowVal[16] = s2b("0");
/* 5834 */     rowVal[17] = s2b("10");
/* 5835 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5837 */     rowVal = new byte[18][];
/* 5838 */     rowVal[0] = s2b("SMALLINT UNSIGNED");
/* 5839 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */ 
/*      */     
/* 5842 */     rowVal[2] = s2b("5");
/* 5843 */     rowVal[3] = s2b("");
/* 5844 */     rowVal[4] = s2b("");
/* 5845 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5846 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5849 */     rowVal[7] = s2b("false");
/* 5850 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5853 */     rowVal[9] = s2b("true");
/* 5854 */     rowVal[10] = s2b("false");
/* 5855 */     rowVal[11] = s2b("true");
/* 5856 */     rowVal[12] = s2b("SMALLINT UNSIGNED");
/* 5857 */     rowVal[13] = s2b("0");
/* 5858 */     rowVal[14] = s2b("0");
/* 5859 */     rowVal[15] = s2b("0");
/* 5860 */     rowVal[16] = s2b("0");
/* 5861 */     rowVal[17] = s2b("10");
/* 5862 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5868 */     rowVal = new byte[18][];
/* 5869 */     rowVal[0] = s2b("FLOAT");
/* 5870 */     rowVal[1] = Integer.toString(7).getBytes();
/*      */ 
/*      */     
/* 5873 */     rowVal[2] = s2b("10");
/* 5874 */     rowVal[3] = s2b("");
/* 5875 */     rowVal[4] = s2b("");
/* 5876 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5877 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5880 */     rowVal[7] = s2b("false");
/* 5881 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5884 */     rowVal[9] = s2b("false");
/* 5885 */     rowVal[10] = s2b("false");
/* 5886 */     rowVal[11] = s2b("true");
/* 5887 */     rowVal[12] = s2b("FLOAT");
/* 5888 */     rowVal[13] = s2b("-38");
/* 5889 */     rowVal[14] = s2b("38");
/* 5890 */     rowVal[15] = s2b("0");
/* 5891 */     rowVal[16] = s2b("0");
/* 5892 */     rowVal[17] = s2b("10");
/* 5893 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5898 */     rowVal = new byte[18][];
/* 5899 */     rowVal[0] = s2b("DOUBLE");
/* 5900 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */ 
/*      */     
/* 5903 */     rowVal[2] = s2b("17");
/* 5904 */     rowVal[3] = s2b("");
/* 5905 */     rowVal[4] = s2b("");
/* 5906 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5907 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5910 */     rowVal[7] = s2b("false");
/* 5911 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5914 */     rowVal[9] = s2b("false");
/* 5915 */     rowVal[10] = s2b("false");
/* 5916 */     rowVal[11] = s2b("true");
/* 5917 */     rowVal[12] = s2b("DOUBLE");
/* 5918 */     rowVal[13] = s2b("-308");
/* 5919 */     rowVal[14] = s2b("308");
/* 5920 */     rowVal[15] = s2b("0");
/* 5921 */     rowVal[16] = s2b("0");
/* 5922 */     rowVal[17] = s2b("10");
/* 5923 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5928 */     rowVal = new byte[18][];
/* 5929 */     rowVal[0] = s2b("DOUBLE PRECISION");
/* 5930 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */ 
/*      */     
/* 5933 */     rowVal[2] = s2b("17");
/* 5934 */     rowVal[3] = s2b("");
/* 5935 */     rowVal[4] = s2b("");
/* 5936 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5937 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5940 */     rowVal[7] = s2b("false");
/* 5941 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5944 */     rowVal[9] = s2b("false");
/* 5945 */     rowVal[10] = s2b("false");
/* 5946 */     rowVal[11] = s2b("true");
/* 5947 */     rowVal[12] = s2b("DOUBLE PRECISION");
/* 5948 */     rowVal[13] = s2b("-308");
/* 5949 */     rowVal[14] = s2b("308");
/* 5950 */     rowVal[15] = s2b("0");
/* 5951 */     rowVal[16] = s2b("0");
/* 5952 */     rowVal[17] = s2b("10");
/* 5953 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5958 */     rowVal = new byte[18][];
/* 5959 */     rowVal[0] = s2b("REAL");
/* 5960 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */ 
/*      */     
/* 5963 */     rowVal[2] = s2b("17");
/* 5964 */     rowVal[3] = s2b("");
/* 5965 */     rowVal[4] = s2b("");
/* 5966 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5967 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 5970 */     rowVal[7] = s2b("false");
/* 5971 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 5974 */     rowVal[9] = s2b("false");
/* 5975 */     rowVal[10] = s2b("false");
/* 5976 */     rowVal[11] = s2b("true");
/* 5977 */     rowVal[12] = s2b("REAL");
/* 5978 */     rowVal[13] = s2b("-308");
/* 5979 */     rowVal[14] = s2b("308");
/* 5980 */     rowVal[15] = s2b("0");
/* 5981 */     rowVal[16] = s2b("0");
/* 5982 */     rowVal[17] = s2b("10");
/* 5983 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5988 */     rowVal = new byte[18][];
/* 5989 */     rowVal[0] = s2b("VARCHAR");
/* 5990 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */ 
/*      */     
/* 5993 */     rowVal[2] = s2b(this.conn.versionMeetsMinimum(5, 0, 3) ? "65535" : "255");
/* 5994 */     rowVal[3] = s2b("'");
/* 5995 */     rowVal[4] = s2b("'");
/* 5996 */     rowVal[5] = s2b("(M)");
/* 5997 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6000 */     rowVal[7] = s2b("false");
/* 6001 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6004 */     rowVal[9] = s2b("false");
/* 6005 */     rowVal[10] = s2b("false");
/* 6006 */     rowVal[11] = s2b("false");
/* 6007 */     rowVal[12] = s2b("VARCHAR");
/* 6008 */     rowVal[13] = s2b("0");
/* 6009 */     rowVal[14] = s2b("0");
/* 6010 */     rowVal[15] = s2b("0");
/* 6011 */     rowVal[16] = s2b("0");
/* 6012 */     rowVal[17] = s2b("10");
/* 6013 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6018 */     rowVal = new byte[18][];
/* 6019 */     rowVal[0] = s2b("ENUM");
/* 6020 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */ 
/*      */     
/* 6023 */     rowVal[2] = s2b("65535");
/* 6024 */     rowVal[3] = s2b("'");
/* 6025 */     rowVal[4] = s2b("'");
/* 6026 */     rowVal[5] = s2b("");
/* 6027 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6030 */     rowVal[7] = s2b("false");
/* 6031 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6034 */     rowVal[9] = s2b("false");
/* 6035 */     rowVal[10] = s2b("false");
/* 6036 */     rowVal[11] = s2b("false");
/* 6037 */     rowVal[12] = s2b("ENUM");
/* 6038 */     rowVal[13] = s2b("0");
/* 6039 */     rowVal[14] = s2b("0");
/* 6040 */     rowVal[15] = s2b("0");
/* 6041 */     rowVal[16] = s2b("0");
/* 6042 */     rowVal[17] = s2b("10");
/* 6043 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6048 */     rowVal = new byte[18][];
/* 6049 */     rowVal[0] = s2b("SET");
/* 6050 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */ 
/*      */     
/* 6053 */     rowVal[2] = s2b("64");
/* 6054 */     rowVal[3] = s2b("'");
/* 6055 */     rowVal[4] = s2b("'");
/* 6056 */     rowVal[5] = s2b("");
/* 6057 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6060 */     rowVal[7] = s2b("false");
/* 6061 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6064 */     rowVal[9] = s2b("false");
/* 6065 */     rowVal[10] = s2b("false");
/* 6066 */     rowVal[11] = s2b("false");
/* 6067 */     rowVal[12] = s2b("SET");
/* 6068 */     rowVal[13] = s2b("0");
/* 6069 */     rowVal[14] = s2b("0");
/* 6070 */     rowVal[15] = s2b("0");
/* 6071 */     rowVal[16] = s2b("0");
/* 6072 */     rowVal[17] = s2b("10");
/* 6073 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6078 */     rowVal = new byte[18][];
/* 6079 */     rowVal[0] = s2b("DATE");
/* 6080 */     rowVal[1] = Integer.toString(91).getBytes();
/*      */ 
/*      */     
/* 6083 */     rowVal[2] = s2b("0");
/* 6084 */     rowVal[3] = s2b("'");
/* 6085 */     rowVal[4] = s2b("'");
/* 6086 */     rowVal[5] = s2b("");
/* 6087 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6090 */     rowVal[7] = s2b("false");
/* 6091 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6094 */     rowVal[9] = s2b("false");
/* 6095 */     rowVal[10] = s2b("false");
/* 6096 */     rowVal[11] = s2b("false");
/* 6097 */     rowVal[12] = s2b("DATE");
/* 6098 */     rowVal[13] = s2b("0");
/* 6099 */     rowVal[14] = s2b("0");
/* 6100 */     rowVal[15] = s2b("0");
/* 6101 */     rowVal[16] = s2b("0");
/* 6102 */     rowVal[17] = s2b("10");
/* 6103 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6108 */     rowVal = new byte[18][];
/* 6109 */     rowVal[0] = s2b("TIME");
/* 6110 */     rowVal[1] = Integer.toString(92).getBytes();
/*      */ 
/*      */     
/* 6113 */     rowVal[2] = s2b("0");
/* 6114 */     rowVal[3] = s2b("'");
/* 6115 */     rowVal[4] = s2b("'");
/* 6116 */     rowVal[5] = s2b("");
/* 6117 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6120 */     rowVal[7] = s2b("false");
/* 6121 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6124 */     rowVal[9] = s2b("false");
/* 6125 */     rowVal[10] = s2b("false");
/* 6126 */     rowVal[11] = s2b("false");
/* 6127 */     rowVal[12] = s2b("TIME");
/* 6128 */     rowVal[13] = s2b("0");
/* 6129 */     rowVal[14] = s2b("0");
/* 6130 */     rowVal[15] = s2b("0");
/* 6131 */     rowVal[16] = s2b("0");
/* 6132 */     rowVal[17] = s2b("10");
/* 6133 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6138 */     rowVal = new byte[18][];
/* 6139 */     rowVal[0] = s2b("DATETIME");
/* 6140 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */ 
/*      */     
/* 6143 */     rowVal[2] = s2b("0");
/* 6144 */     rowVal[3] = s2b("'");
/* 6145 */     rowVal[4] = s2b("'");
/* 6146 */     rowVal[5] = s2b("");
/* 6147 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6150 */     rowVal[7] = s2b("false");
/* 6151 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6154 */     rowVal[9] = s2b("false");
/* 6155 */     rowVal[10] = s2b("false");
/* 6156 */     rowVal[11] = s2b("false");
/* 6157 */     rowVal[12] = s2b("DATETIME");
/* 6158 */     rowVal[13] = s2b("0");
/* 6159 */     rowVal[14] = s2b("0");
/* 6160 */     rowVal[15] = s2b("0");
/* 6161 */     rowVal[16] = s2b("0");
/* 6162 */     rowVal[17] = s2b("10");
/* 6163 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6168 */     rowVal = new byte[18][];
/* 6169 */     rowVal[0] = s2b("TIMESTAMP");
/* 6170 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */ 
/*      */     
/* 6173 */     rowVal[2] = s2b("0");
/* 6174 */     rowVal[3] = s2b("'");
/* 6175 */     rowVal[4] = s2b("'");
/* 6176 */     rowVal[5] = s2b("[(M)]");
/* 6177 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/*      */     
/* 6180 */     rowVal[7] = s2b("false");
/* 6181 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/*      */     
/* 6184 */     rowVal[9] = s2b("false");
/* 6185 */     rowVal[10] = s2b("false");
/* 6186 */     rowVal[11] = s2b("false");
/* 6187 */     rowVal[12] = s2b("TIMESTAMP");
/* 6188 */     rowVal[13] = s2b("0");
/* 6189 */     rowVal[14] = s2b("0");
/* 6190 */     rowVal[15] = s2b("0");
/* 6191 */     rowVal[16] = s2b("0");
/* 6192 */     rowVal[17] = s2b("10");
/* 6193 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6195 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types) throws SQLException {
/* 6236 */     Field[] fields = new Field[7];
/* 6237 */     fields[0] = new Field("", "TYPE_CAT", 12, 32);
/* 6238 */     fields[1] = new Field("", "TYPE_SCHEM", 12, 32);
/* 6239 */     fields[2] = new Field("", "TYPE_NAME", 12, 32);
/* 6240 */     fields[3] = new Field("", "CLASS_NAME", 12, 32);
/* 6241 */     fields[4] = new Field("", "DATA_TYPE", 4, 10);
/* 6242 */     fields[5] = new Field("", "REMARKS", 12, 32);
/* 6243 */     fields[6] = new Field("", "BASE_TYPE", 5, 10);
/*      */     
/* 6245 */     ArrayList<ResultSetRow> tuples = new ArrayList<ResultSetRow>();
/*      */     
/* 6247 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getURL() throws SQLException {
/* 6257 */     return this.conn.getURL();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUserName() throws SQLException {
/* 6267 */     if (this.conn.getUseHostsInPrivileges()) {
/* 6268 */       Statement stmt = null;
/* 6269 */       ResultSet rs = null;
/*      */       
/*      */       try {
/* 6272 */         stmt = this.conn.getMetadataSafeStatement();
/*      */         
/* 6274 */         rs = stmt.executeQuery("SELECT USER()");
/* 6275 */         rs.next();
/*      */         
/* 6277 */         return rs.getString(1);
/*      */       } finally {
/* 6279 */         if (rs != null) {
/*      */           try {
/* 6281 */             rs.close();
/* 6282 */           } catch (Exception ex) {
/* 6283 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           } 
/*      */           
/* 6286 */           rs = null;
/*      */         } 
/*      */         
/* 6289 */         if (stmt != null) {
/*      */           try {
/* 6291 */             stmt.close();
/* 6292 */           } catch (Exception ex) {
/* 6293 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           } 
/*      */           
/* 6296 */           stmt = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 6301 */     return this.conn.getUser();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getVersionColumns(String catalog, String schema, final String table) throws SQLException {
/* 6338 */     if (table == null) {
/* 6339 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 6342 */     Field[] fields = new Field[8];
/* 6343 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 6344 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 6345 */     fields[2] = new Field("", "DATA_TYPE", 4, 5);
/* 6346 */     fields[3] = new Field("", "TYPE_NAME", 1, 16);
/* 6347 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 16);
/* 6348 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 16);
/* 6349 */     fields[6] = new Field("", "DECIMAL_DIGITS", 5, 16);
/* 6350 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */     
/* 6352 */     final ArrayList<ResultSetRow> rows = new ArrayList<ResultSetRow>();
/*      */     
/* 6354 */     final Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*      */     
/*      */     try {
/* 6358 */       (new IterateBlock<String>(getCatalogIterator(catalog))
/*      */         {
/*      */           void forEach(String catalogStr) throws SQLException
/*      */           {
/* 6362 */             ResultSet results = null;
/* 6363 */             boolean with_where = DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 0);
/*      */             
/*      */             try {
/* 6366 */               StringBuilder whereBuf = new StringBuilder(" Extra LIKE '%on update CURRENT_TIMESTAMP%'");
/* 6367 */               List<String> rsFields = new ArrayList<String>();
/*      */ 
/*      */ 
/*      */               
/* 6371 */               if (!DatabaseMetaData.this.conn.versionMeetsMinimum(5, 1, 23)) {
/*      */                 
/* 6373 */                 whereBuf = new StringBuilder();
/* 6374 */                 boolean firstTime = true;
/*      */                 
/* 6376 */                 String query = "SHOW CREATE TABLE " + DatabaseMetaData.this.getFullyQualifiedName(catalogStr, table);
/*      */                 
/* 6378 */                 results = stmt.executeQuery(query);
/* 6379 */                 while (results.next()) {
/* 6380 */                   String createTableString = results.getString(2);
/* 6381 */                   StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
/*      */                   
/* 6383 */                   while (lineTokenizer.hasMoreTokens()) {
/* 6384 */                     String line = lineTokenizer.nextToken().trim();
/* 6385 */                     if (StringUtils.indexOfIgnoreCase(line, "on update CURRENT_TIMESTAMP") > -1) {
/* 6386 */                       boolean usingBackTicks = true;
/* 6387 */                       int beginPos = line.indexOf(DatabaseMetaData.this.quotedId);
/*      */                       
/* 6389 */                       if (beginPos == -1) {
/* 6390 */                         beginPos = line.indexOf("\"");
/* 6391 */                         usingBackTicks = false;
/*      */                       } 
/*      */                       
/* 6394 */                       if (beginPos != -1) {
/* 6395 */                         int endPos = -1;
/*      */                         
/* 6397 */                         if (usingBackTicks) {
/* 6398 */                           endPos = line.indexOf(DatabaseMetaData.this.quotedId, beginPos + 1);
/*      */                         } else {
/* 6400 */                           endPos = line.indexOf("\"", beginPos + 1);
/*      */                         } 
/*      */                         
/* 6403 */                         if (endPos != -1) {
/* 6404 */                           if (with_where) {
/* 6405 */                             if (!firstTime) {
/* 6406 */                               whereBuf.append(" or");
/*      */                             } else {
/* 6408 */                               firstTime = false;
/*      */                             } 
/* 6410 */                             whereBuf.append(" Field='");
/* 6411 */                             whereBuf.append(line.substring(beginPos + 1, endPos));
/* 6412 */                             whereBuf.append("'"); continue;
/*      */                           } 
/* 6414 */                           rsFields.add(line.substring(beginPos + 1, endPos));
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */ 
/*      */               
/* 6423 */               if (whereBuf.length() > 0 || rsFields.size() > 0) {
/* 6424 */                 StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
/* 6425 */                 queryBuf.append(StringUtils.quoteIdentifier(table, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 6426 */                 queryBuf.append(" FROM ");
/* 6427 */                 queryBuf.append(StringUtils.quoteIdentifier(catalogStr, DatabaseMetaData.this.quotedId, DatabaseMetaData.this.conn.getPedantic()));
/* 6428 */                 if (with_where) {
/* 6429 */                   queryBuf.append(" WHERE");
/* 6430 */                   queryBuf.append(whereBuf.toString());
/*      */                 } 
/*      */                 
/* 6433 */                 results = stmt.executeQuery(queryBuf.toString());
/*      */                 
/* 6435 */                 while (results.next()) {
/* 6436 */                   if (with_where || rsFields.contains(results.getString("Field"))) {
/* 6437 */                     DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(results.getString("Type"), results.getString("Null"));
/* 6438 */                     byte[][] rowVal = new byte[8][];
/*      */                     
/* 6440 */                     rowVal[0] = null;
/*      */                     
/* 6442 */                     rowVal[1] = results.getBytes("Field");
/*      */                     
/* 6444 */                     rowVal[2] = Short.toString(typeDesc.dataType).getBytes();
/*      */                     
/* 6446 */                     rowVal[3] = DatabaseMetaData.this.s2b(typeDesc.typeName);
/*      */                     
/* 6448 */                     rowVal[4] = (typeDesc.columnSize == null) ? null : DatabaseMetaData.this.s2b(typeDesc.columnSize.toString());
/*      */                     
/* 6450 */                     rowVal[5] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.bufferLength));
/*      */                     
/* 6452 */                     rowVal[6] = (typeDesc.decimalDigits == null) ? null : DatabaseMetaData.this.s2b(typeDesc.decimalDigits.toString());
/*      */                     
/* 6454 */                     rowVal[7] = Integer.toString(1).getBytes();
/*      */                     
/* 6456 */                     rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                   } 
/*      */                 } 
/*      */               } 
/* 6460 */             } catch (SQLException sqlEx) {
/* 6461 */               if (!"42S02".equals(sqlEx.getSQLState())) {
/* 6462 */                 throw sqlEx;
/*      */               }
/*      */             } finally {
/* 6465 */               if (results != null) {
/*      */                 try {
/* 6467 */                   results.close();
/* 6468 */                 } catch (Exception ex) {}
/*      */ 
/*      */                 
/* 6471 */                 results = null;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         }).doForAll();
/*      */     } finally {
/*      */       
/* 6478 */       if (stmt != null) {
/* 6479 */         stmt.close();
/*      */       }
/*      */     } 
/*      */     
/* 6483 */     return buildResultSet(fields, rows);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean insertsAreDetected(int type) throws SQLException {
/* 6497 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCatalogAtStart() throws SQLException {
/* 6508 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/* 6518 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean locatorsUpdateCopy() throws SQLException {
/* 6525 */     return !this.conn.getEmulateLocators();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nullPlusNonNullIsNull() throws SQLException {
/* 6536 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedAtEnd() throws SQLException {
/* 6546 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedAtStart() throws SQLException {
/* 6556 */     return (this.conn.versionMeetsMinimum(4, 0, 2) && !this.conn.versionMeetsMinimum(4, 0, 11));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedHigh() throws SQLException {
/* 6566 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedLow() throws SQLException {
/* 6576 */     return !nullsAreSortedHigh();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean othersDeletesAreVisible(int type) throws SQLException {
/* 6584 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean othersInsertsAreVisible(int type) throws SQLException {
/* 6592 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean othersUpdatesAreVisible(int type) throws SQLException {
/* 6605 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ownDeletesAreVisible(int type) throws SQLException {
/* 6613 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ownInsertsAreVisible(int type) throws SQLException {
/* 6621 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ownUpdatesAreVisible(int type) throws SQLException {
/* 6634 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LocalAndReferencedColumns parseTableStatusIntoLocalAndReferencedColumns(String keysComment) throws SQLException {
/* 6649 */     String columnsDelimitter = ",";
/*      */     
/* 6651 */     int indexOfOpenParenLocalColumns = StringUtils.indexOfIgnoreCase(0, keysComment, "(", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */     
/* 6653 */     if (indexOfOpenParenLocalColumns == -1) {
/* 6654 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of local columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 6658 */     String constraintName = StringUtils.unQuoteIdentifier(keysComment.substring(0, indexOfOpenParenLocalColumns).trim(), this.quotedId);
/* 6659 */     keysComment = keysComment.substring(indexOfOpenParenLocalColumns, keysComment.length());
/*      */     
/* 6661 */     String keysCommentTrimmed = keysComment.trim();
/*      */     
/* 6663 */     int indexOfCloseParenLocalColumns = StringUtils.indexOfIgnoreCase(0, keysCommentTrimmed, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */     
/* 6666 */     if (indexOfCloseParenLocalColumns == -1) {
/* 6667 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of local columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 6671 */     String localColumnNamesString = keysCommentTrimmed.substring(1, indexOfCloseParenLocalColumns);
/*      */     
/* 6673 */     int indexOfRefer = StringUtils.indexOfIgnoreCase(0, keysCommentTrimmed, "REFER ", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */     
/* 6675 */     if (indexOfRefer == -1) {
/* 6676 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced tables list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 6680 */     int indexOfOpenParenReferCol = StringUtils.indexOfIgnoreCase(indexOfRefer, keysCommentTrimmed, "(", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */ 
/*      */     
/* 6683 */     if (indexOfOpenParenReferCol == -1) {
/* 6684 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 6688 */     String referCatalogTableString = keysCommentTrimmed.substring(indexOfRefer + "REFER ".length(), indexOfOpenParenReferCol);
/*      */     
/* 6690 */     int indexOfSlash = StringUtils.indexOfIgnoreCase(0, referCatalogTableString, "/", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__MRK_COM_WS);
/*      */     
/* 6692 */     if (indexOfSlash == -1) {
/* 6693 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find name of referenced catalog.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 6697 */     String referCatalog = StringUtils.unQuoteIdentifier(referCatalogTableString.substring(0, indexOfSlash), this.quotedId);
/* 6698 */     String referTable = StringUtils.unQuoteIdentifier(referCatalogTableString.substring(indexOfSlash + 1).trim(), this.quotedId);
/*      */     
/* 6700 */     int indexOfCloseParenRefer = StringUtils.indexOfIgnoreCase(indexOfOpenParenReferCol, keysCommentTrimmed, ")", this.quotedId, this.quotedId, StringUtils.SEARCH_MODE__ALL);
/*      */ 
/*      */     
/* 6703 */     if (indexOfCloseParenRefer == -1) {
/* 6704 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of referenced columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 6708 */     String referColumnNamesString = keysCommentTrimmed.substring(indexOfOpenParenReferCol + 1, indexOfCloseParenRefer);
/*      */     
/* 6710 */     List<String> referColumnsList = StringUtils.split(referColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/* 6711 */     List<String> localColumnsList = StringUtils.split(localColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/*      */     
/* 6713 */     return new LocalAndReferencedColumns(localColumnsList, referColumnsList, constraintName, referCatalog, referTable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] s2b(String s) throws SQLException {
/* 6723 */     if (s == null) {
/* 6724 */       return null;
/*      */     }
/*      */     
/* 6727 */     return StringUtils.getBytes(s, this.conn.getCharacterSetMetadata(), this.conn.getServerCharset(), this.conn.parserKnowsUnicode(), this.conn, getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseIdentifiers() throws SQLException {
/* 6739 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseQuotedIdentifiers() throws SQLException {
/* 6750 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean storesMixedCaseIdentifiers() throws SQLException {
/* 6761 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean storesMixedCaseQuotedIdentifiers() throws SQLException {
/* 6772 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean storesUpperCaseIdentifiers() throws SQLException {
/* 6783 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean storesUpperCaseQuotedIdentifiers() throws SQLException {
/* 6794 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsAlterTableWithAddColumn() throws SQLException {
/* 6804 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsAlterTableWithDropColumn() throws SQLException {
/* 6814 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92EntryLevelSQL() throws SQLException {
/* 6825 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92FullSQL() throws SQLException {
/* 6835 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92IntermediateSQL() throws SQLException {
/* 6845 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsBatchUpdates() throws SQLException {
/* 6855 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInDataManipulation() throws SQLException {
/* 6866 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInIndexDefinitions() throws SQLException {
/* 6877 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException {
/* 6888 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInProcedureCalls() throws SQLException {
/* 6899 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInTableDefinitions() throws SQLException {
/* 6910 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsColumnAliasing() throws SQLException {
/* 6924 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsConvert() throws SQLException {
/* 6934 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsConvert(int fromType, int toType) throws SQLException {
/* 6950 */     switch (fromType) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 6961 */         switch (toType) {
/*      */           case -6:
/*      */           case -5:
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case -1:
/*      */           case 1:
/*      */           case 2:
/*      */           case 3:
/*      */           case 4:
/*      */           case 5:
/*      */           case 6:
/*      */           case 7:
/*      */           case 8:
/*      */           case 12:
/*      */           case 91:
/*      */           case 92:
/*      */           case 93:
/*      */           case 1111:
/* 6981 */             return true;
/*      */         } 
/*      */         
/* 6984 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -7:
/* 6991 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/* 7006 */         switch (toType) {
/*      */           case -6:
/*      */           case -5:
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case -1:
/*      */           case 1:
/*      */           case 2:
/*      */           case 3:
/*      */           case 4:
/*      */           case 5:
/*      */           case 6:
/*      */           case 7:
/*      */           case 8:
/*      */           case 12:
/* 7022 */             return true;
/*      */         } 
/*      */         
/* 7025 */         return false;
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/* 7030 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1111:
/* 7037 */         switch (toType) {
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case -1:
/*      */           case 1:
/*      */           case 12:
/* 7044 */             return true;
/*      */         } 
/*      */         
/* 7047 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 91:
/* 7053 */         switch (toType) {
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case -1:
/*      */           case 1:
/*      */           case 12:
/* 7060 */             return true;
/*      */         } 
/*      */         
/* 7063 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/* 7069 */         switch (toType) {
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case -1:
/*      */           case 1:
/*      */           case 12:
/* 7076 */             return true;
/*      */         } 
/*      */         
/* 7079 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 7087 */         switch (toType) {
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case -1:
/*      */           case 1:
/*      */           case 12:
/*      */           case 91:
/*      */           case 92:
/* 7096 */             return true;
/*      */         } 
/*      */         
/* 7099 */         return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 7104 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCoreSQLGrammar() throws SQLException {
/* 7115 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsCorrelatedSubqueries() throws SQLException {
/* 7126 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLException {
/* 7137 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsDataManipulationTransactionsOnly() throws SQLException {
/* 7147 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsDifferentTableCorrelationNames() throws SQLException {
/* 7159 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsExpressionsInOrderBy() throws SQLException {
/* 7169 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsExtendedSQLGrammar() throws SQLException {
/* 7179 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsFullOuterJoins() throws SQLException {
/* 7189 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsGetGeneratedKeys() {
/* 7196 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsGroupBy() throws SQLException {
/* 7206 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsGroupByBeyondSelect() throws SQLException {
/* 7217 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsGroupByUnrelated() throws SQLException {
/* 7227 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsIntegrityEnhancementFacility() throws SQLException {
/* 7237 */     if (!this.conn.getOverrideSupportsIntegrityEnhancementFacility()) {
/* 7238 */       return false;
/*      */     }
/*      */     
/* 7241 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsLikeEscapeClause() throws SQLException {
/* 7252 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsLimitedOuterJoins() throws SQLException {
/* 7263 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsMinimumSQLGrammar() throws SQLException {
/* 7274 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsMixedCaseIdentifiers() throws SQLException {
/* 7284 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException {
/* 7295 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleOpenResults() throws SQLException {
/* 7302 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleResultSets() throws SQLException {
/* 7312 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleTransactions() throws SQLException {
/* 7323 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsNamedParameters() throws SQLException {
/* 7330 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsNonNullableColumns() throws SQLException {
/* 7341 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossCommit() throws SQLException {
/* 7353 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossRollback() throws SQLException {
/* 7365 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossCommit() throws SQLException {
/* 7377 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossRollback() throws SQLException {
/* 7389 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsOrderByUnrelated() throws SQLException {
/* 7399 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsOuterJoins() throws SQLException {
/* 7409 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsPositionedDelete() throws SQLException {
/* 7419 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsPositionedUpdate() throws SQLException {
/* 7429 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetConcurrency(int type, int concurrency) throws SQLException {
/* 7446 */     switch (type) {
/*      */       case 1004:
/* 7448 */         if (concurrency == 1007 || concurrency == 1008) {
/* 7449 */           return true;
/*      */         }
/* 7451 */         throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */ 
/*      */       
/*      */       case 1003:
/* 7455 */         if (concurrency == 1007 || concurrency == 1008) {
/* 7456 */           return true;
/*      */         }
/* 7458 */         throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */ 
/*      */       
/*      */       case 1005:
/* 7462 */         return false;
/*      */     } 
/* 7464 */     throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetHoldability(int holdability) throws SQLException {
/* 7474 */     return (holdability == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetType(int type) throws SQLException {
/* 7488 */     return (type == 1004);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSavepoints() throws SQLException {
/* 7496 */     return (this.conn.versionMeetsMinimum(4, 0, 14) || this.conn.versionMeetsMinimum(4, 1, 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInDataManipulation() throws SQLException {
/* 7506 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInIndexDefinitions() throws SQLException {
/* 7516 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException {
/* 7526 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInProcedureCalls() throws SQLException {
/* 7536 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInTableDefinitions() throws SQLException {
/* 7546 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSelectForUpdate() throws SQLException {
/* 7556 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsStatementPooling() throws SQLException {
/* 7563 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsStoredProcedures() throws SQLException {
/* 7574 */     return this.conn.versionMeetsMinimum(5, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInComparisons() throws SQLException {
/* 7585 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInExists() throws SQLException {
/* 7596 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInIns() throws SQLException {
/* 7607 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInQuantifieds() throws SQLException {
/* 7618 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsTableCorrelationNames() throws SQLException {
/* 7629 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsTransactionIsolationLevel(int level) throws SQLException {
/* 7643 */     if (this.conn.supportsIsolationLevel()) {
/* 7644 */       switch (level) {
/*      */         case 1:
/*      */         case 2:
/*      */         case 4:
/*      */         case 8:
/* 7649 */           return true;
/*      */       } 
/*      */       
/* 7652 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 7656 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsTransactions() throws SQLException {
/* 7667 */     return this.conn.supportsTransactions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsUnion() throws SQLException {
/* 7677 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsUnionAll() throws SQLException {
/* 7687 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean updatesAreDetected(int type) throws SQLException {
/* 7701 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean usesLocalFilePerTable() throws SQLException {
/* 7711 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean usesLocalFiles() throws SQLException {
/* 7721 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getClientInfoProperties() throws SQLException {
/* 7753 */     Field[] fields = new Field[4];
/* 7754 */     fields[0] = new Field("", "NAME", 12, 255);
/* 7755 */     fields[1] = new Field("", "MAX_LEN", 4, 10);
/* 7756 */     fields[2] = new Field("", "DEFAULT_VALUE", 12, 255);
/* 7757 */     fields[3] = new Field("", "DESCRIPTION", 12, 255);
/*      */     
/* 7759 */     return buildResultSet(fields, new ArrayList<ResultSetRow>(), this.conn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern) throws SQLException {
/* 7770 */     Field[] fields = createFunctionColumnsFields();
/*      */     
/* 7772 */     return getProcedureOrFunctionColumns(fields, catalog, schemaPattern, functionNamePattern, columnNamePattern, false, true);
/*      */   }
/*      */   
/*      */   protected Field[] createFunctionColumnsFields() {
/* 7776 */     Field[] fields = { new Field("", "FUNCTION_CAT", 12, 512), new Field("", "FUNCTION_SCHEM", 12, 512), new Field("", "FUNCTION_NAME", 12, 512), new Field("", "COLUMN_NAME", 12, 512), new Field("", "COLUMN_TYPE", 12, 64), new Field("", "DATA_TYPE", 5, 6), new Field("", "TYPE_NAME", 12, 64), new Field("", "PRECISION", 4, 12), new Field("", "LENGTH", 4, 12), new Field("", "SCALE", 5, 12), new Field("", "RADIX", 5, 6), new Field("", "NULLABLE", 5, 6), new Field("", "REMARKS", 12, 512), new Field("", "CHAR_OCTET_LENGTH", 4, 32), new Field("", "ORDINAL_POSITION", 4, 32), new Field("", "IS_NULLABLE", 12, 12), new Field("", "SPECIFIC_NAME", 12, 64) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7783 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern) throws SQLException {
/* 7831 */     Field[] fields = new Field[6];
/*      */     
/* 7833 */     fields[0] = new Field("", "FUNCTION_CAT", 1, 255);
/* 7834 */     fields[1] = new Field("", "FUNCTION_SCHEM", 1, 255);
/* 7835 */     fields[2] = new Field("", "FUNCTION_NAME", 1, 255);
/* 7836 */     fields[3] = new Field("", "REMARKS", 1, 255);
/* 7837 */     fields[4] = new Field("", "FUNCTION_TYPE", 5, 6);
/* 7838 */     fields[5] = new Field("", "SPECIFIC_NAME", 1, 255);
/*      */     
/* 7840 */     return getProceduresAndOrFunctions(fields, catalog, schemaPattern, functionNamePattern, false, true);
/*      */   }
/*      */   
/*      */   public boolean providesQueryObjectGenerator() throws SQLException {
/* 7844 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException {
/* 7853 */     Field[] fields = { new Field("", "TABLE_SCHEM", 12, 255), new Field("", "TABLE_CATALOG", 12, 255) };
/*      */     
/* 7855 */     return buildResultSet(fields, new ArrayList<ResultSetRow>());
/*      */   }
/*      */   
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
/* 7859 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PreparedStatement prepareMetaDataSafeStatement(String sql) throws SQLException {
/* 7870 */     PreparedStatement pStmt = this.conn.clientPrepareStatement(sql);
/*      */     
/* 7872 */     if (pStmt.getMaxRows() != 0) {
/* 7873 */       pStmt.setMaxRows(0);
/*      */     }
/*      */     
/* 7876 */     ((Statement)pStmt).setHoldResultsOpenOverClose(true);
/*      */     
/* 7878 */     return pStmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/* 7891 */     Field[] fields = { new Field("", "TABLE_CAT", 12, 512), new Field("", "TABLE_SCHEM", 12, 512), new Field("", "TABLE_NAME", 12, 512), new Field("", "COLUMN_NAME", 12, 512), new Field("", "DATA_TYPE", 4, 12), new Field("", "COLUMN_SIZE", 4, 12), new Field("", "DECIMAL_DIGITS", 4, 12), new Field("", "NUM_PREC_RADIX", 4, 12), new Field("", "COLUMN_USAGE", 12, 512), new Field("", "REMARKS", 12, 512), new Field("", "CHAR_OCTET_LENGTH", 4, 12), new Field("", "IS_NULLABLE", 12, 512) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7898 */     return buildResultSet(fields, new ArrayList<ResultSetRow>());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean generatedKeyAlwaysReturned() throws SQLException {
/* 7903 */     return true;
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\jdbc\DatabaseMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */