/*    */ package com.mysql.fabric;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FabricCommunicationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public FabricCommunicationException(Throwable cause) {
/* 34 */     super(cause);
/*    */   }
/*    */   
/*    */   public FabricCommunicationException(String message) {
/* 38 */     super(message);
/*    */   }
/*    */   
/*    */   public FabricCommunicationException(String message, Throwable cause) {
/* 42 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mysql-connector-java-5.1.47.jar!\com\mysql\fabric\FabricCommunicationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */