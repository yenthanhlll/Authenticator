package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.main.STTextFontSize;

public class STTextFontSizeImpl extends JavaIntHolderEx implements STTextFontSize {
  public STTextFontSizeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STTextFontSizeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\STTextFontSizeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */