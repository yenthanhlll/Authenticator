package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.poi.POIXMLTypeLoader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextBody;
import org.w3c.dom.Node;

public interface CTDateAx extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTDateAx.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sF1327CCA741569E70F9CA8C9AF9B44B2").resolveHandle("ctdateaxbdd7type");
  
  CTUnsignedInt getAxId();
  
  void setAxId(CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt addNewAxId();
  
  CTScaling getScaling();
  
  void setScaling(CTScaling paramCTScaling);
  
  CTScaling addNewScaling();
  
  CTBoolean getDelete();
  
  boolean isSetDelete();
  
  void setDelete(CTBoolean paramCTBoolean);
  
  CTBoolean addNewDelete();
  
  void unsetDelete();
  
  CTAxPos getAxPos();
  
  void setAxPos(CTAxPos paramCTAxPos);
  
  CTAxPos addNewAxPos();
  
  CTChartLines getMajorGridlines();
  
  boolean isSetMajorGridlines();
  
  void setMajorGridlines(CTChartLines paramCTChartLines);
  
  CTChartLines addNewMajorGridlines();
  
  void unsetMajorGridlines();
  
  CTChartLines getMinorGridlines();
  
  boolean isSetMinorGridlines();
  
  void setMinorGridlines(CTChartLines paramCTChartLines);
  
  CTChartLines addNewMinorGridlines();
  
  void unsetMinorGridlines();
  
  CTTitle getTitle();
  
  boolean isSetTitle();
  
  void setTitle(CTTitle paramCTTitle);
  
  CTTitle addNewTitle();
  
  void unsetTitle();
  
  CTNumFmt getNumFmt();
  
  boolean isSetNumFmt();
  
  void setNumFmt(CTNumFmt paramCTNumFmt);
  
  CTNumFmt addNewNumFmt();
  
  void unsetNumFmt();
  
  CTTickMark getMajorTickMark();
  
  boolean isSetMajorTickMark();
  
  void setMajorTickMark(CTTickMark paramCTTickMark);
  
  CTTickMark addNewMajorTickMark();
  
  void unsetMajorTickMark();
  
  CTTickMark getMinorTickMark();
  
  boolean isSetMinorTickMark();
  
  void setMinorTickMark(CTTickMark paramCTTickMark);
  
  CTTickMark addNewMinorTickMark();
  
  void unsetMinorTickMark();
  
  CTTickLblPos getTickLblPos();
  
  boolean isSetTickLblPos();
  
  void setTickLblPos(CTTickLblPos paramCTTickLblPos);
  
  CTTickLblPos addNewTickLblPos();
  
  void unsetTickLblPos();
  
  CTShapeProperties getSpPr();
  
  boolean isSetSpPr();
  
  void setSpPr(CTShapeProperties paramCTShapeProperties);
  
  CTShapeProperties addNewSpPr();
  
  void unsetSpPr();
  
  CTTextBody getTxPr();
  
  boolean isSetTxPr();
  
  void setTxPr(CTTextBody paramCTTextBody);
  
  CTTextBody addNewTxPr();
  
  void unsetTxPr();
  
  CTUnsignedInt getCrossAx();
  
  void setCrossAx(CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt addNewCrossAx();
  
  CTCrosses getCrosses();
  
  boolean isSetCrosses();
  
  void setCrosses(CTCrosses paramCTCrosses);
  
  CTCrosses addNewCrosses();
  
  void unsetCrosses();
  
  CTDouble getCrossesAt();
  
  boolean isSetCrossesAt();
  
  void setCrossesAt(CTDouble paramCTDouble);
  
  CTDouble addNewCrossesAt();
  
  void unsetCrossesAt();
  
  CTBoolean getAuto();
  
  boolean isSetAuto();
  
  void setAuto(CTBoolean paramCTBoolean);
  
  CTBoolean addNewAuto();
  
  void unsetAuto();
  
  CTLblOffset getLblOffset();
  
  boolean isSetLblOffset();
  
  void setLblOffset(CTLblOffset paramCTLblOffset);
  
  CTLblOffset addNewLblOffset();
  
  void unsetLblOffset();
  
  CTTimeUnit getBaseTimeUnit();
  
  boolean isSetBaseTimeUnit();
  
  void setBaseTimeUnit(CTTimeUnit paramCTTimeUnit);
  
  CTTimeUnit addNewBaseTimeUnit();
  
  void unsetBaseTimeUnit();
  
  CTAxisUnit getMajorUnit();
  
  boolean isSetMajorUnit();
  
  void setMajorUnit(CTAxisUnit paramCTAxisUnit);
  
  CTAxisUnit addNewMajorUnit();
  
  void unsetMajorUnit();
  
  CTTimeUnit getMajorTimeUnit();
  
  boolean isSetMajorTimeUnit();
  
  void setMajorTimeUnit(CTTimeUnit paramCTTimeUnit);
  
  CTTimeUnit addNewMajorTimeUnit();
  
  void unsetMajorTimeUnit();
  
  CTAxisUnit getMinorUnit();
  
  boolean isSetMinorUnit();
  
  void setMinorUnit(CTAxisUnit paramCTAxisUnit);
  
  CTAxisUnit addNewMinorUnit();
  
  void unsetMinorUnit();
  
  CTTimeUnit getMinorTimeUnit();
  
  boolean isSetMinorTimeUnit();
  
  void setMinorTimeUnit(CTTimeUnit paramCTTimeUnit);
  
  CTTimeUnit addNewMinorTimeUnit();
  
  void unsetMinorTimeUnit();
  
  CTExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTExtensionList paramCTExtensionList);
  
  CTExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    public static CTDateAx newInstance() {
      return (CTDateAx)POIXMLTypeLoader.newInstance(CTDateAx.type, null);
    }
    
    public static CTDateAx newInstance(XmlOptions param1XmlOptions) {
      return (CTDateAx)POIXMLTypeLoader.newInstance(CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(String param1String) throws XmlException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1String, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1String, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(File param1File) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1File, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1File, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(URL param1URL) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1URL, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1URL, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1InputStream, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1InputStream, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(Reader param1Reader) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1Reader, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1Reader, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1XMLStreamReader, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1XMLStreamReader, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(Node param1Node) throws XmlException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1Node, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1Node, CTDateAx.type, param1XmlOptions);
    }
    
    public static CTDateAx parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1XMLInputStream, CTDateAx.type, null);
    }
    
    public static CTDateAx parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTDateAx)POIXMLTypeLoader.parse(param1XMLInputStream, CTDateAx.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return POIXMLTypeLoader.newValidatingXMLInputStream(param1XMLInputStream, CTDateAx.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return POIXMLTypeLoader.newValidatingXMLInputStream(param1XMLInputStream, CTDateAx.type, param1XmlOptions);
    }
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTDateAx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */