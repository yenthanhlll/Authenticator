package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextNoBullet;

public class CTTextNoBulletImpl extends XmlComplexContentImpl implements CTTextNoBullet {
  public CTTextNoBulletImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTTextNoBulletImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */