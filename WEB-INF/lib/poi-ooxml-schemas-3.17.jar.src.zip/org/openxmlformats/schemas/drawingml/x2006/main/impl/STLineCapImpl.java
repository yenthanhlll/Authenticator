package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.main.STLineCap;

public class STLineCapImpl extends JavaStringEnumerationHolderEx implements STLineCap {
  public STLineCapImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STLineCapImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\STLineCapImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */