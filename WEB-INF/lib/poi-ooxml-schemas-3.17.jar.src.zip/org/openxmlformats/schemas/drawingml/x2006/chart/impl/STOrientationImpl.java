package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.chart.STOrientation;

public class STOrientationImpl extends JavaStringEnumerationHolderEx implements STOrientation {
  public STOrientationImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STOrientationImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\STOrientationImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */