package org.etsi.uri.x01903.v13.impl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.AnyType;
import org.etsi.uri.x01903.v13.EncapsulatedPKIDataType;
import org.etsi.uri.x01903.v13.GenericTimeStampType;
import org.etsi.uri.x01903.v13.IncludeType;
import org.etsi.uri.x01903.v13.ReferenceInfoType;
import org.w3.x2000.x09.xmldsig.CanonicalizationMethodType;

public class GenericTimeStampTypeImpl extends XmlComplexContentImpl implements GenericTimeStampType {
  private static final QName INCLUDE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "Include");
  
  private static final QName REFERENCEINFO$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ReferenceInfo");
  
  private static final QName CANONICALIZATIONMETHOD$4 = new QName("http://www.w3.org/2000/09/xmldsig#", "CanonicalizationMethod");
  
  private static final QName ENCAPSULATEDTIMESTAMP$6 = new QName("http://uri.etsi.org/01903/v1.3.2#", "EncapsulatedTimeStamp");
  
  private static final QName XMLTIMESTAMP$8 = new QName("http://uri.etsi.org/01903/v1.3.2#", "XMLTimeStamp");
  
  private static final QName ID$10 = new QName("", "Id");
  
  public GenericTimeStampTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<IncludeType> getIncludeList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<IncludeType>)new IncludeList(this);
    } 
  }
  
  public IncludeType[] getIncludeArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(INCLUDE$0, arrayList);
      IncludeType[] arrayOfIncludeType = new IncludeType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfIncludeType);
      return arrayOfIncludeType;
    } 
  }
  
  public IncludeType getIncludeArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().find_element_user(INCLUDE$0, paramInt);
      if (includeType == null)
        throw new IndexOutOfBoundsException(); 
      return includeType;
    } 
  }
  
  public int sizeOfIncludeArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(INCLUDE$0);
    } 
  }
  
  public void setIncludeArray(IncludeType[] paramArrayOfIncludeType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfIncludeType, INCLUDE$0);
    } 
  }
  
  public void setIncludeArray(int paramInt, IncludeType paramIncludeType) {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().find_element_user(INCLUDE$0, paramInt);
      if (includeType == null)
        throw new IndexOutOfBoundsException(); 
      includeType.set((XmlObject)paramIncludeType);
    } 
  }
  
  public IncludeType insertNewInclude(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().insert_element_user(INCLUDE$0, paramInt);
      return includeType;
    } 
  }
  
  public IncludeType addNewInclude() {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().add_element_user(INCLUDE$0);
      return includeType;
    } 
  }
  
  public void removeInclude(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(INCLUDE$0, paramInt);
    } 
  }
  
  public List<ReferenceInfoType> getReferenceInfoList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<ReferenceInfoType>)new ReferenceInfoList(this);
    } 
  }
  
  public ReferenceInfoType[] getReferenceInfoArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REFERENCEINFO$2, arrayList);
      ReferenceInfoType[] arrayOfReferenceInfoType = new ReferenceInfoType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfReferenceInfoType);
      return arrayOfReferenceInfoType;
    } 
  }
  
  public ReferenceInfoType getReferenceInfoArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().find_element_user(REFERENCEINFO$2, paramInt);
      if (referenceInfoType == null)
        throw new IndexOutOfBoundsException(); 
      return referenceInfoType;
    } 
  }
  
  public int sizeOfReferenceInfoArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REFERENCEINFO$2);
    } 
  }
  
  public void setReferenceInfoArray(ReferenceInfoType[] paramArrayOfReferenceInfoType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfReferenceInfoType, REFERENCEINFO$2);
    } 
  }
  
  public void setReferenceInfoArray(int paramInt, ReferenceInfoType paramReferenceInfoType) {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().find_element_user(REFERENCEINFO$2, paramInt);
      if (referenceInfoType == null)
        throw new IndexOutOfBoundsException(); 
      referenceInfoType.set((XmlObject)paramReferenceInfoType);
    } 
  }
  
  public ReferenceInfoType insertNewReferenceInfo(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().insert_element_user(REFERENCEINFO$2, paramInt);
      return referenceInfoType;
    } 
  }
  
  public ReferenceInfoType addNewReferenceInfo() {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().add_element_user(REFERENCEINFO$2);
      return referenceInfoType;
    } 
  }
  
  public void removeReferenceInfo(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REFERENCEINFO$2, paramInt);
    } 
  }
  
  public CanonicalizationMethodType getCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      CanonicalizationMethodType canonicalizationMethodType = null;
      canonicalizationMethodType = (CanonicalizationMethodType)get_store().find_element_user(CANONICALIZATIONMETHOD$4, 0);
      if (canonicalizationMethodType == null)
        return null; 
      return canonicalizationMethodType;
    } 
  }
  
  public boolean isSetCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CANONICALIZATIONMETHOD$4) != 0);
    } 
  }
  
  public void setCanonicalizationMethod(CanonicalizationMethodType paramCanonicalizationMethodType) {
    synchronized (monitor()) {
      check_orphaned();
      CanonicalizationMethodType canonicalizationMethodType = null;
      canonicalizationMethodType = (CanonicalizationMethodType)get_store().find_element_user(CANONICALIZATIONMETHOD$4, 0);
      if (canonicalizationMethodType == null)
        canonicalizationMethodType = (CanonicalizationMethodType)get_store().add_element_user(CANONICALIZATIONMETHOD$4); 
      canonicalizationMethodType.set((XmlObject)paramCanonicalizationMethodType);
    } 
  }
  
  public CanonicalizationMethodType addNewCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      CanonicalizationMethodType canonicalizationMethodType = null;
      canonicalizationMethodType = (CanonicalizationMethodType)get_store().add_element_user(CANONICALIZATIONMETHOD$4);
      return canonicalizationMethodType;
    } 
  }
  
  public void unsetCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CANONICALIZATIONMETHOD$4, 0);
    } 
  }
  
  public List<EncapsulatedPKIDataType> getEncapsulatedTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<EncapsulatedPKIDataType>)new EncapsulatedTimeStampList(this);
    } 
  }
  
  public EncapsulatedPKIDataType[] getEncapsulatedTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ENCAPSULATEDTIMESTAMP$6, arrayList);
      EncapsulatedPKIDataType[] arrayOfEncapsulatedPKIDataType = new EncapsulatedPKIDataType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfEncapsulatedPKIDataType);
      return arrayOfEncapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType getEncapsulatedTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDTIMESTAMP$6, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      return encapsulatedPKIDataType;
    } 
  }
  
  public int sizeOfEncapsulatedTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ENCAPSULATEDTIMESTAMP$6);
    } 
  }
  
  public void setEncapsulatedTimeStampArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfEncapsulatedPKIDataType, ENCAPSULATEDTIMESTAMP$6);
    } 
  }
  
  public void setEncapsulatedTimeStampArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDTIMESTAMP$6, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      encapsulatedPKIDataType.set((XmlObject)paramEncapsulatedPKIDataType);
    } 
  }
  
  public EncapsulatedPKIDataType insertNewEncapsulatedTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().insert_element_user(ENCAPSULATEDTIMESTAMP$6, paramInt);
      return encapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType addNewEncapsulatedTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().add_element_user(ENCAPSULATEDTIMESTAMP$6);
      return encapsulatedPKIDataType;
    } 
  }
  
  public void removeEncapsulatedTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ENCAPSULATEDTIMESTAMP$6, paramInt);
    } 
  }
  
  public List<AnyType> getXMLTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<AnyType>)new XMLTimeStampList(this);
    } 
  }
  
  public AnyType[] getXMLTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(XMLTIMESTAMP$8, arrayList);
      AnyType[] arrayOfAnyType = new AnyType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfAnyType);
      return arrayOfAnyType;
    } 
  }
  
  public AnyType getXMLTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().find_element_user(XMLTIMESTAMP$8, paramInt);
      if (anyType == null)
        throw new IndexOutOfBoundsException(); 
      return anyType;
    } 
  }
  
  public int sizeOfXMLTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(XMLTIMESTAMP$8);
    } 
  }
  
  public void setXMLTimeStampArray(AnyType[] paramArrayOfAnyType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfAnyType, XMLTIMESTAMP$8);
    } 
  }
  
  public void setXMLTimeStampArray(int paramInt, AnyType paramAnyType) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().find_element_user(XMLTIMESTAMP$8, paramInt);
      if (anyType == null)
        throw new IndexOutOfBoundsException(); 
      anyType.set((XmlObject)paramAnyType);
    } 
  }
  
  public AnyType insertNewXMLTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().insert_element_user(XMLTIMESTAMP$8, paramInt);
      return anyType;
    } 
  }
  
  public AnyType addNewXMLTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().add_element_user(XMLTIMESTAMP$8);
      return anyType;
    } 
  }
  
  public void removeXMLTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(XMLTIMESTAMP$8, paramInt);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$10);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$10);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$10) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$10);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$10); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$10);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$10); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$10);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\GenericTimeStampTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */