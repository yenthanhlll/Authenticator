package org.etsi.uri.x01903.v13.impl;

import java.util.Calendar;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlDateTime;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertIDListType;
import org.etsi.uri.x01903.v13.SignaturePolicyIdentifierType;
import org.etsi.uri.x01903.v13.SignatureProductionPlaceType;
import org.etsi.uri.x01903.v13.SignedSignaturePropertiesType;
import org.etsi.uri.x01903.v13.SignerRoleType;

public class SignedSignaturePropertiesTypeImpl extends XmlComplexContentImpl implements SignedSignaturePropertiesType {
  private static final QName SIGNINGTIME$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SigningTime");
  
  private static final QName SIGNINGCERTIFICATE$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SigningCertificate");
  
  private static final QName SIGNATUREPOLICYIDENTIFIER$4 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignaturePolicyIdentifier");
  
  private static final QName SIGNATUREPRODUCTIONPLACE$6 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignatureProductionPlace");
  
  private static final QName SIGNERROLE$8 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignerRole");
  
  private static final QName ID$10 = new QName("", "Id");
  
  public SignedSignaturePropertiesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public Calendar getSigningTime() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(SIGNINGTIME$0, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getCalendarValue();
    } 
  }
  
  public XmlDateTime xgetSigningTime() {
    synchronized (monitor()) {
      check_orphaned();
      XmlDateTime xmlDateTime = null;
      xmlDateTime = (XmlDateTime)get_store().find_element_user(SIGNINGTIME$0, 0);
      return xmlDateTime;
    } 
  }
  
  public boolean isSetSigningTime() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNINGTIME$0) != 0);
    } 
  }
  
  public void setSigningTime(Calendar paramCalendar) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(SIGNINGTIME$0, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(SIGNINGTIME$0); 
      simpleValue.setCalendarValue(paramCalendar);
    } 
  }
  
  public void xsetSigningTime(XmlDateTime paramXmlDateTime) {
    synchronized (monitor()) {
      check_orphaned();
      XmlDateTime xmlDateTime = null;
      xmlDateTime = (XmlDateTime)get_store().find_element_user(SIGNINGTIME$0, 0);
      if (xmlDateTime == null)
        xmlDateTime = (XmlDateTime)get_store().add_element_user(SIGNINGTIME$0); 
      xmlDateTime.set((XmlObject)paramXmlDateTime);
    } 
  }
  
  public void unsetSigningTime() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNINGTIME$0, 0);
    } 
  }
  
  public CertIDListType getSigningCertificate() {
    synchronized (monitor()) {
      check_orphaned();
      CertIDListType certIDListType = null;
      certIDListType = (CertIDListType)get_store().find_element_user(SIGNINGCERTIFICATE$2, 0);
      if (certIDListType == null)
        return null; 
      return certIDListType;
    } 
  }
  
  public boolean isSetSigningCertificate() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNINGCERTIFICATE$2) != 0);
    } 
  }
  
  public void setSigningCertificate(CertIDListType paramCertIDListType) {
    synchronized (monitor()) {
      check_orphaned();
      CertIDListType certIDListType = null;
      certIDListType = (CertIDListType)get_store().find_element_user(SIGNINGCERTIFICATE$2, 0);
      if (certIDListType == null)
        certIDListType = (CertIDListType)get_store().add_element_user(SIGNINGCERTIFICATE$2); 
      certIDListType.set((XmlObject)paramCertIDListType);
    } 
  }
  
  public CertIDListType addNewSigningCertificate() {
    synchronized (monitor()) {
      check_orphaned();
      CertIDListType certIDListType = null;
      certIDListType = (CertIDListType)get_store().add_element_user(SIGNINGCERTIFICATE$2);
      return certIDListType;
    } 
  }
  
  public void unsetSigningCertificate() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNINGCERTIFICATE$2, 0);
    } 
  }
  
  public SignaturePolicyIdentifierType getSignaturePolicyIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      SignaturePolicyIdentifierType signaturePolicyIdentifierType = null;
      signaturePolicyIdentifierType = (SignaturePolicyIdentifierType)get_store().find_element_user(SIGNATUREPOLICYIDENTIFIER$4, 0);
      if (signaturePolicyIdentifierType == null)
        return null; 
      return signaturePolicyIdentifierType;
    } 
  }
  
  public boolean isSetSignaturePolicyIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNATUREPOLICYIDENTIFIER$4) != 0);
    } 
  }
  
  public void setSignaturePolicyIdentifier(SignaturePolicyIdentifierType paramSignaturePolicyIdentifierType) {
    synchronized (monitor()) {
      check_orphaned();
      SignaturePolicyIdentifierType signaturePolicyIdentifierType = null;
      signaturePolicyIdentifierType = (SignaturePolicyIdentifierType)get_store().find_element_user(SIGNATUREPOLICYIDENTIFIER$4, 0);
      if (signaturePolicyIdentifierType == null)
        signaturePolicyIdentifierType = (SignaturePolicyIdentifierType)get_store().add_element_user(SIGNATUREPOLICYIDENTIFIER$4); 
      signaturePolicyIdentifierType.set((XmlObject)paramSignaturePolicyIdentifierType);
    } 
  }
  
  public SignaturePolicyIdentifierType addNewSignaturePolicyIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      SignaturePolicyIdentifierType signaturePolicyIdentifierType = null;
      signaturePolicyIdentifierType = (SignaturePolicyIdentifierType)get_store().add_element_user(SIGNATUREPOLICYIDENTIFIER$4);
      return signaturePolicyIdentifierType;
    } 
  }
  
  public void unsetSignaturePolicyIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNATUREPOLICYIDENTIFIER$4, 0);
    } 
  }
  
  public SignatureProductionPlaceType getSignatureProductionPlace() {
    synchronized (monitor()) {
      check_orphaned();
      SignatureProductionPlaceType signatureProductionPlaceType = null;
      signatureProductionPlaceType = (SignatureProductionPlaceType)get_store().find_element_user(SIGNATUREPRODUCTIONPLACE$6, 0);
      if (signatureProductionPlaceType == null)
        return null; 
      return signatureProductionPlaceType;
    } 
  }
  
  public boolean isSetSignatureProductionPlace() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNATUREPRODUCTIONPLACE$6) != 0);
    } 
  }
  
  public void setSignatureProductionPlace(SignatureProductionPlaceType paramSignatureProductionPlaceType) {
    synchronized (monitor()) {
      check_orphaned();
      SignatureProductionPlaceType signatureProductionPlaceType = null;
      signatureProductionPlaceType = (SignatureProductionPlaceType)get_store().find_element_user(SIGNATUREPRODUCTIONPLACE$6, 0);
      if (signatureProductionPlaceType == null)
        signatureProductionPlaceType = (SignatureProductionPlaceType)get_store().add_element_user(SIGNATUREPRODUCTIONPLACE$6); 
      signatureProductionPlaceType.set((XmlObject)paramSignatureProductionPlaceType);
    } 
  }
  
  public SignatureProductionPlaceType addNewSignatureProductionPlace() {
    synchronized (monitor()) {
      check_orphaned();
      SignatureProductionPlaceType signatureProductionPlaceType = null;
      signatureProductionPlaceType = (SignatureProductionPlaceType)get_store().add_element_user(SIGNATUREPRODUCTIONPLACE$6);
      return signatureProductionPlaceType;
    } 
  }
  
  public void unsetSignatureProductionPlace() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNATUREPRODUCTIONPLACE$6, 0);
    } 
  }
  
  public SignerRoleType getSignerRole() {
    synchronized (monitor()) {
      check_orphaned();
      SignerRoleType signerRoleType = null;
      signerRoleType = (SignerRoleType)get_store().find_element_user(SIGNERROLE$8, 0);
      if (signerRoleType == null)
        return null; 
      return signerRoleType;
    } 
  }
  
  public boolean isSetSignerRole() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SIGNERROLE$8) != 0);
    } 
  }
  
  public void setSignerRole(SignerRoleType paramSignerRoleType) {
    synchronized (monitor()) {
      check_orphaned();
      SignerRoleType signerRoleType = null;
      signerRoleType = (SignerRoleType)get_store().find_element_user(SIGNERROLE$8, 0);
      if (signerRoleType == null)
        signerRoleType = (SignerRoleType)get_store().add_element_user(SIGNERROLE$8); 
      signerRoleType.set((XmlObject)paramSignerRoleType);
    } 
  }
  
  public SignerRoleType addNewSignerRole() {
    synchronized (monitor()) {
      check_orphaned();
      SignerRoleType signerRoleType = null;
      signerRoleType = (SignerRoleType)get_store().add_element_user(SIGNERROLE$8);
      return signerRoleType;
    } 
  }
  
  public void unsetSignerRole() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNERROLE$8, 0);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$10);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$10);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$10) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$10);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$10); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$10);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$10); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$10);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\SignedSignaturePropertiesTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */