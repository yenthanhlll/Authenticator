package org.etsi.uri.x01903.v13.impl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLRefType;
import org.etsi.uri.x01903.v13.CRLRefsType;

public class CRLRefsTypeImpl extends XmlComplexContentImpl implements CRLRefsType {
  private static final QName CRLREF$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CRLRef");
  
  public CRLRefsTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CRLRefType> getCRLRefList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CRLRefType>)new CRLRefList(this);
    } 
  }
  
  public CRLRefType[] getCRLRefArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CRLREF$0, arrayList);
      CRLRefType[] arrayOfCRLRefType = new CRLRefType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCRLRefType);
      return arrayOfCRLRefType;
    } 
  }
  
  public CRLRefType getCRLRefArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().find_element_user(CRLREF$0, paramInt);
      if (cRLRefType == null)
        throw new IndexOutOfBoundsException(); 
      return cRLRefType;
    } 
  }
  
  public int sizeOfCRLRefArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CRLREF$0);
    } 
  }
  
  public void setCRLRefArray(CRLRefType[] paramArrayOfCRLRefType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCRLRefType, CRLREF$0);
    } 
  }
  
  public void setCRLRefArray(int paramInt, CRLRefType paramCRLRefType) {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().find_element_user(CRLREF$0, paramInt);
      if (cRLRefType == null)
        throw new IndexOutOfBoundsException(); 
      cRLRefType.set((XmlObject)paramCRLRefType);
    } 
  }
  
  public CRLRefType insertNewCRLRef(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().insert_element_user(CRLREF$0, paramInt);
      return cRLRefType;
    } 
  }
  
  public CRLRefType addNewCRLRef() {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().add_element_user(CRLREF$0);
      return cRLRefType;
    } 
  }
  
  public void removeCRLRef(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CRLREF$0, paramInt);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\CRLRefsTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */