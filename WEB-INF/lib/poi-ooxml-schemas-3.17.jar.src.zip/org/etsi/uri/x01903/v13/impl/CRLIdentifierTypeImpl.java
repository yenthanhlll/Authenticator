package org.etsi.uri.x01903.v13.impl;

import java.math.BigInteger;
import java.util.Calendar;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlAnyURI;
import org.apache.xmlbeans.XmlDateTime;
import org.apache.xmlbeans.XmlInteger;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLIdentifierType;

public class CRLIdentifierTypeImpl extends XmlComplexContentImpl implements CRLIdentifierType {
  private static final QName ISSUER$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "Issuer");
  
  private static final QName ISSUETIME$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "IssueTime");
  
  private static final QName NUMBER$4 = new QName("http://uri.etsi.org/01903/v1.3.2#", "Number");
  
  private static final QName URI$6 = new QName("", "URI");
  
  public CRLIdentifierTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public String getIssuer() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(ISSUER$0, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlString xgetIssuer() {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_element_user(ISSUER$0, 0);
      return xmlString;
    } 
  }
  
  public void setIssuer(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(ISSUER$0, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(ISSUER$0); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetIssuer(XmlString paramXmlString) {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_element_user(ISSUER$0, 0);
      if (xmlString == null)
        xmlString = (XmlString)get_store().add_element_user(ISSUER$0); 
      xmlString.set((XmlObject)paramXmlString);
    } 
  }
  
  public Calendar getIssueTime() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(ISSUETIME$2, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getCalendarValue();
    } 
  }
  
  public XmlDateTime xgetIssueTime() {
    synchronized (monitor()) {
      check_orphaned();
      XmlDateTime xmlDateTime = null;
      xmlDateTime = (XmlDateTime)get_store().find_element_user(ISSUETIME$2, 0);
      return xmlDateTime;
    } 
  }
  
  public void setIssueTime(Calendar paramCalendar) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(ISSUETIME$2, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(ISSUETIME$2); 
      simpleValue.setCalendarValue(paramCalendar);
    } 
  }
  
  public void xsetIssueTime(XmlDateTime paramXmlDateTime) {
    synchronized (monitor()) {
      check_orphaned();
      XmlDateTime xmlDateTime = null;
      xmlDateTime = (XmlDateTime)get_store().find_element_user(ISSUETIME$2, 0);
      if (xmlDateTime == null)
        xmlDateTime = (XmlDateTime)get_store().add_element_user(ISSUETIME$2); 
      xmlDateTime.set((XmlObject)paramXmlDateTime);
    } 
  }
  
  public BigInteger getNumber() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(NUMBER$4, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getBigIntegerValue();
    } 
  }
  
  public XmlInteger xgetNumber() {
    synchronized (monitor()) {
      check_orphaned();
      XmlInteger xmlInteger = null;
      xmlInteger = (XmlInteger)get_store().find_element_user(NUMBER$4, 0);
      return xmlInteger;
    } 
  }
  
  public boolean isSetNumber() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(NUMBER$4) != 0);
    } 
  }
  
  public void setNumber(BigInteger paramBigInteger) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(NUMBER$4, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(NUMBER$4); 
      simpleValue.setBigIntegerValue(paramBigInteger);
    } 
  }
  
  public void xsetNumber(XmlInteger paramXmlInteger) {
    synchronized (monitor()) {
      check_orphaned();
      XmlInteger xmlInteger = null;
      xmlInteger = (XmlInteger)get_store().find_element_user(NUMBER$4, 0);
      if (xmlInteger == null)
        xmlInteger = (XmlInteger)get_store().add_element_user(NUMBER$4); 
      xmlInteger.set((XmlObject)paramXmlInteger);
    } 
  }
  
  public void unsetNumber() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(NUMBER$4, 0);
    } 
  }
  
  public String getURI() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$6);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlAnyURI xgetURI() {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(URI$6);
      return xmlAnyURI;
    } 
  }
  
  public boolean isSetURI() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(URI$6) != null);
    } 
  }
  
  public void setURI(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(URI$6); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetURI(XmlAnyURI paramXmlAnyURI) {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(URI$6);
      if (xmlAnyURI == null)
        xmlAnyURI = (XmlAnyURI)get_store().add_attribute_user(URI$6); 
      xmlAnyURI.set((XmlObject)paramXmlAnyURI);
    } 
  }
  
  public void unsetURI() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(URI$6);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\CRLIdentifierTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */