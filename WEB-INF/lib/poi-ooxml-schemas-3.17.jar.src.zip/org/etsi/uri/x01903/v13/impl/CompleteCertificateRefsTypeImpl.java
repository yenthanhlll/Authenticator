package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertIDListType;
import org.etsi.uri.x01903.v13.CompleteCertificateRefsType;

public class CompleteCertificateRefsTypeImpl extends XmlComplexContentImpl implements CompleteCertificateRefsType {
  private static final QName CERTREFS$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CertRefs");
  
  private static final QName ID$2 = new QName("", "Id");
  
  public CompleteCertificateRefsTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CertIDListType getCertRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CertIDListType certIDListType = null;
      certIDListType = (CertIDListType)get_store().find_element_user(CERTREFS$0, 0);
      if (certIDListType == null)
        return null; 
      return certIDListType;
    } 
  }
  
  public void setCertRefs(CertIDListType paramCertIDListType) {
    synchronized (monitor()) {
      check_orphaned();
      CertIDListType certIDListType = null;
      certIDListType = (CertIDListType)get_store().find_element_user(CERTREFS$0, 0);
      if (certIDListType == null)
        certIDListType = (CertIDListType)get_store().add_element_user(CERTREFS$0); 
      certIDListType.set((XmlObject)paramCertIDListType);
    } 
  }
  
  public CertIDListType addNewCertRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CertIDListType certIDListType = null;
      certIDListType = (CertIDListType)get_store().add_element_user(CERTREFS$0);
      return certIDListType;
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$2);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$2);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$2) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$2);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$2); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$2);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$2); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$2);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\CompleteCertificateRefsTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */