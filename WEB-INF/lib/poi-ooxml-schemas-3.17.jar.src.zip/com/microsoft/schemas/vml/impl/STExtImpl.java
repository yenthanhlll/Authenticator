package com.microsoft.schemas.vml.impl;

import com.microsoft.schemas.vml.STExt;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STExtImpl extends JavaStringEnumerationHolderEx implements STExt {
  public STExtImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STExtImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\vml\impl\STExtImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */