package com.microsoft.schemas.vml.impl;

import com.microsoft.schemas.vml.STStrokeJoinStyle;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STStrokeJoinStyleImpl extends JavaStringEnumerationHolderEx implements STStrokeJoinStyle {
  public STStrokeJoinStyleImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STStrokeJoinStyleImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\vml\impl\STStrokeJoinStyleImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */