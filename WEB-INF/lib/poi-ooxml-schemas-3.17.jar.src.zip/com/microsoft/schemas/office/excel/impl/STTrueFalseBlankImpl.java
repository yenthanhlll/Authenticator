package com.microsoft.schemas.office.excel.impl;

import com.microsoft.schemas.office.excel.STTrueFalseBlank;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STTrueFalseBlankImpl extends JavaStringEnumerationHolderEx implements STTrueFalseBlank {
  public STTrueFalseBlankImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STTrueFalseBlankImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\office\excel\impl\STTrueFalseBlankImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */