package com.microsoft.schemas.office.visio.x2012.main.impl;

import com.microsoft.schemas.office.visio.x2012.main.ConnectType;
import com.microsoft.schemas.office.visio.x2012.main.ConnectsType;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class ConnectsTypeImpl extends XmlComplexContentImpl implements ConnectsType {
  private static final QName CONNECT$0 = new QName("http://schemas.microsoft.com/office/visio/2012/main", "Connect");
  
  public ConnectsTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<ConnectType> getConnectList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<ConnectType>)new ConnectList(this);
    } 
  }
  
  public ConnectType[] getConnectArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CONNECT$0, arrayList);
      ConnectType[] arrayOfConnectType = new ConnectType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfConnectType);
      return arrayOfConnectType;
    } 
  }
  
  public ConnectType getConnectArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      ConnectType connectType = null;
      connectType = (ConnectType)get_store().find_element_user(CONNECT$0, paramInt);
      if (connectType == null)
        throw new IndexOutOfBoundsException(); 
      return connectType;
    } 
  }
  
  public int sizeOfConnectArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CONNECT$0);
    } 
  }
  
  public void setConnectArray(ConnectType[] paramArrayOfConnectType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfConnectType, CONNECT$0);
    } 
  }
  
  public void setConnectArray(int paramInt, ConnectType paramConnectType) {
    synchronized (monitor()) {
      check_orphaned();
      ConnectType connectType = null;
      connectType = (ConnectType)get_store().find_element_user(CONNECT$0, paramInt);
      if (connectType == null)
        throw new IndexOutOfBoundsException(); 
      connectType.set((XmlObject)paramConnectType);
    } 
  }
  
  public ConnectType insertNewConnect(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      ConnectType connectType = null;
      connectType = (ConnectType)get_store().insert_element_user(CONNECT$0, paramInt);
      return connectType;
    } 
  }
  
  public ConnectType addNewConnect() {
    synchronized (monitor()) {
      check_orphaned();
      ConnectType connectType = null;
      connectType = (ConnectType)get_store().add_element_user(CONNECT$0);
      return connectType;
    } 
  }
  
  public void removeConnect(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CONNECT$0, paramInt);
    } 
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\office\visio\x2012\main\impl\ConnectsTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */