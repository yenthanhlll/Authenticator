package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STCipherChaining;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STCipherChainingImpl extends JavaStringEnumerationHolderEx implements STCipherChaining {
  public STCipherChainingImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STCipherChainingImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\office\x2006\encryption\impl\STCipherChainingImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */