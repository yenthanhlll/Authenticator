package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STSaltSize;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;

public class STSaltSizeImpl extends JavaIntHolderEx implements STSaltSize {
  public STSaltSizeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STSaltSizeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\office\x2006\encryption\impl\STSaltSizeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */