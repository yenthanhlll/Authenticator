package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STKeyBits;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaLongHolderEx;

public class STKeyBitsImpl extends JavaLongHolderEx implements STKeyBits {
  public STKeyBitsImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STKeyBitsImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\office\x2006\encryption\impl\STKeyBitsImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */