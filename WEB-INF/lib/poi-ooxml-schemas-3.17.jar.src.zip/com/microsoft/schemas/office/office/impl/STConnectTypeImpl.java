package com.microsoft.schemas.office.office.impl;

import com.microsoft.schemas.office.office.STConnectType;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STConnectTypeImpl extends JavaStringEnumerationHolderEx implements STConnectType {
  public STConnectTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STConnectTypeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\office\office\impl\STConnectTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */