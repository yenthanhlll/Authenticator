/*     */ package org.apache.taglibs.standard.functions;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Functions
/*     */ {
/*     */   public static String toUpperCase(String input) {
/*  55 */     return input.toUpperCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toLowerCase(String input) {
/*  62 */     return input.toLowerCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int indexOf(String input, String substring) {
/*  69 */     if (input == null) input = ""; 
/*  70 */     if (substring == null) substring = ""; 
/*  71 */     return input.indexOf(substring);
/*     */   }
/*     */   
/*     */   public static boolean contains(String input, String substring) {
/*  75 */     return (indexOf(input, substring) != -1);
/*     */   }
/*     */   
/*     */   public static boolean containsIgnoreCase(String input, String substring) {
/*  79 */     if (input == null) input = ""; 
/*  80 */     if (substring == null) substring = ""; 
/*  81 */     String inputUC = input.toUpperCase();
/*  82 */     String substringUC = substring.toUpperCase();
/*  83 */     return (indexOf(inputUC, substringUC) != -1);
/*     */   }
/*     */   
/*     */   public static boolean startsWith(String input, String substring) {
/*  87 */     if (input == null) input = ""; 
/*  88 */     if (substring == null) substring = ""; 
/*  89 */     return input.startsWith(substring);
/*     */   }
/*     */   
/*     */   public static boolean endsWith(String input, String substring) {
/*  93 */     if (input == null) input = ""; 
/*  94 */     if (substring == null) substring = ""; 
/*  95 */     int index = input.indexOf(substring);
/*  96 */     if (index == -1) return false; 
/*  97 */     if (index == 0 && substring.length() == 0) return true; 
/*  98 */     return (index == input.length() - substring.length());
/*     */   }
/*     */   
/*     */   public static String substring(String input, int beginIndex, int endIndex) {
/* 102 */     if (input == null) input = ""; 
/* 103 */     if (beginIndex >= input.length()) return ""; 
/* 104 */     if (beginIndex < 0) beginIndex = 0; 
/* 105 */     if (endIndex < 0 || endIndex > input.length()) endIndex = input.length(); 
/* 106 */     if (endIndex < beginIndex) return ""; 
/* 107 */     return input.substring(beginIndex, endIndex);
/*     */   }
/*     */   
/*     */   public static String substringAfter(String input, String substring) {
/* 111 */     if (input == null) input = ""; 
/* 112 */     if (input.length() == 0) return ""; 
/* 113 */     if (substring == null) substring = ""; 
/* 114 */     if (substring.length() == 0) return input;
/*     */     
/* 116 */     int index = input.indexOf(substring);
/* 117 */     if (index == -1) {
/* 118 */       return "";
/*     */     }
/* 120 */     return input.substring(index + substring.length());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String substringBefore(String input, String substring) {
/* 125 */     if (input == null) input = ""; 
/* 126 */     if (input.length() == 0) return ""; 
/* 127 */     if (substring == null) substring = ""; 
/* 128 */     if (substring.length() == 0) return "";
/*     */     
/* 130 */     int index = input.indexOf(substring);
/* 131 */     if (index == -1) {
/* 132 */       return "";
/*     */     }
/* 134 */     return input.substring(0, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeXml(String input) {
/* 142 */     if (input == null) return ""; 
/* 143 */     return Util.escapeXml(input);
/*     */   }
/*     */   
/*     */   public static String trim(String input) {
/* 147 */     if (input == null) return ""; 
/* 148 */     return input.trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replace(String input, String substringBefore, String substringAfter) {
/* 156 */     if (input == null) input = ""; 
/* 157 */     if (input.length() == 0) return ""; 
/* 158 */     if (substringBefore == null) substringBefore = ""; 
/* 159 */     if (substringBefore.length() == 0) return input;
/*     */     
/* 161 */     StringBuffer buf = new StringBuffer(input.length());
/* 162 */     int startIndex = 0;
/*     */     int index;
/* 164 */     while ((index = input.indexOf(substringBefore, startIndex)) != -1) {
/* 165 */       buf.append(input.substring(startIndex, index)).append(substringAfter);
/* 166 */       startIndex = index + substringBefore.length();
/*     */     } 
/* 168 */     return buf.append(input.substring(startIndex)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] split(String input, String delimiters) {
/* 176 */     if (input == null) input = ""; 
/* 177 */     if (input.length() == 0) {
/* 178 */       String[] arrayOfString = new String[1];
/* 179 */       arrayOfString[0] = "";
/* 180 */       return arrayOfString;
/*     */     } 
/*     */     
/* 183 */     if (delimiters == null) delimiters = "";
/*     */     
/* 185 */     StringTokenizer tok = new StringTokenizer(input, delimiters);
/* 186 */     int count = tok.countTokens();
/* 187 */     String[] array = new String[count];
/* 188 */     int i = 0;
/* 189 */     while (tok.hasMoreTokens()) {
/* 190 */       array[i++] = tok.nextToken();
/*     */     }
/* 192 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int length(Object obj) throws JspTagException {
/* 199 */     if (obj == null) return 0;
/*     */     
/* 201 */     if (obj instanceof String) return ((String)obj).length(); 
/* 202 */     if (obj instanceof Collection) return ((Collection)obj).size(); 
/* 203 */     if (obj instanceof Map) return ((Map)obj).size();
/*     */     
/* 205 */     int count = 0;
/* 206 */     if (obj instanceof Iterator) {
/* 207 */       Iterator iter = (Iterator)obj;
/* 208 */       count = 0;
/* 209 */       while (iter.hasNext()) {
/* 210 */         count++;
/* 211 */         iter.next();
/*     */       } 
/* 213 */       return count;
/*     */     } 
/* 215 */     if (obj instanceof Enumeration) {
/* 216 */       Enumeration enum_ = (Enumeration)obj;
/* 217 */       count = 0;
/* 218 */       while (enum_.hasMoreElements()) {
/* 219 */         count++;
/* 220 */         enum_.nextElement();
/*     */       } 
/* 222 */       return count;
/*     */     } 
/*     */     try {
/* 225 */       count = Array.getLength(obj);
/* 226 */       return count;
/* 227 */     } catch (IllegalArgumentException ex) {
/* 228 */       throw new JspTagException(Resources.getMessage("FOREACH_BAD_ITEMS"));
/*     */     } 
/*     */   }
/*     */   public static String join(String[] array, String separator) {
/* 232 */     if (array == null) return ""; 
/* 233 */     if (separator == null) separator = "";
/*     */     
/* 235 */     StringBuffer buf = new StringBuffer();
/* 236 */     for (int i = 0; i < array.length; i++) {
/* 237 */       buf.append(array[i]);
/* 238 */       if (i < array.length - 1) buf.append(separator);
/*     */     
/*     */     } 
/* 241 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\functions\Functions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */