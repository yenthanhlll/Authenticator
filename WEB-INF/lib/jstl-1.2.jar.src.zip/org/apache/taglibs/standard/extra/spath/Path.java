package org.apache.taglibs.standard.extra.spath;

import java.util.List;

public abstract class Path {
  public abstract List getSteps();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\Path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */