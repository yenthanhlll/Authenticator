/*     */ package org.apache.taglibs.standard.extra.spath;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.XMLFilterImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPathFilter
/*     */   extends XMLFilterImpl
/*     */ {
/*     */   protected List steps;
/*     */   private int depth;
/*     */   private Stack acceptedDepths;
/*     */   private int excludedDepth;
/*     */   private static final boolean DEBUG = false;
/*     */   
/*     */   public SPathFilter(Path path) {
/* 106 */     init();
/* 107 */     this.steps = path.getSteps();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/* 112 */     this.depth = 0;
/* 113 */     this.excludedDepth = -1;
/* 114 */     this.acceptedDepths = new Stack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes a) throws SAXException {
/* 129 */     this.depth++;
/*     */ 
/*     */     
/* 132 */     if (isAccepted()) {
/* 133 */       getContentHandler().startElement(uri, localName, qName, a);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 138 */     if (isExcluded()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 144 */     Step currentStep = this.steps.get(this.acceptedDepths.size());
/*     */     
/* 146 */     if (nodeMatchesStep(currentStep, uri, localName, qName, a)) {
/*     */ 
/*     */ 
/*     */       
/* 150 */       this.acceptedDepths.push(new Integer(this.depth - 1));
/*     */ 
/*     */       
/* 153 */       if (isAccepted())
/* 154 */         getContentHandler().startElement(uri, localName, qName, a); 
/* 155 */     } else if (!currentStep.isDepthUnlimited()) {
/*     */ 
/*     */       
/* 158 */       this.excludedDepth = this.depth - 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 169 */     this.depth--;
/*     */     
/* 171 */     if (isExcluded()) {
/*     */       
/* 173 */       if (this.excludedDepth == this.depth) {
/* 174 */         this.excludedDepth = -1;
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 181 */     if (isAccepted()) {
/* 182 */       getContentHandler().endElement(uri, localName, qName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     if (this.acceptedDepths.size() > 0 && ((Integer)this.acceptedDepths.peek()).intValue() == this.depth)
/*     */     {
/* 194 */       this.acceptedDepths.pop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 205 */     if (isAccepted()) {
/* 206 */       getContentHandler().ignorableWhitespace(ch, start, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 212 */     if (isAccepted()) {
/* 213 */       getContentHandler().characters(ch, start, length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 219 */     if (isAccepted()) {
/* 220 */       getContentHandler().startPrefixMapping(prefix, uri);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {
/* 226 */     if (isAccepted()) {
/* 227 */       getContentHandler().endPrefixMapping(prefix);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {
/* 233 */     if (isAccepted()) {
/* 234 */       getContentHandler().processingInstruction(target, data);
/*     */     }
/*     */   }
/*     */   
/*     */   public void skippedEntity(String name) throws SAXException {
/* 239 */     if (isAccepted()) {
/* 240 */       getContentHandler().skippedEntity(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() {
/* 246 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean nodeMatchesStep(Step s, String uri, String localName, String qName, Attributes a) {
/* 258 */     if (!s.isMatchingName(uri, localName)) {
/* 259 */       return false;
/*     */     }
/*     */     
/* 262 */     List<Predicate> l = s.getPredicates();
/* 263 */     for (int i = 0; l != null && i < l.size(); i++) {
/* 264 */       Predicate p = l.get(i);
/* 265 */       if (!(p instanceof AttributePredicate)) {
/* 266 */         throw new UnsupportedOperationException("only attribute predicates are supported by filter");
/*     */       }
/* 268 */       if (!((AttributePredicate)p).isMatchingAttribute(a)) {
/* 269 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 273 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isAccepted() {
/* 278 */     return (this.acceptedDepths.size() >= this.steps.size());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isExcluded() {
/* 283 */     return (this.excludedDepth != -1);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\SPathFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */