/*     */ package org.apache.taglibs.standard.extra.spath;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ASCII_CharStream
/*     */ {
/*     */   public static final boolean staticFlag = false;
/*     */   int bufsize;
/*     */   int available;
/*     */   int tokenBegin;
/*  36 */   public int bufpos = -1;
/*     */   
/*     */   private int[] bufline;
/*     */   private int[] bufcolumn;
/*  40 */   private int column = 0;
/*  41 */   private int line = 1;
/*     */   
/*     */   private boolean prevCharIsCR = false;
/*     */   
/*     */   private boolean prevCharIsLF = false;
/*     */   
/*     */   private Reader inputStream;
/*     */   private char[] buffer;
/*  49 */   private int maxNextCharInd = 0;
/*  50 */   private int inBuf = 0;
/*     */ 
/*     */   
/*     */   private final void ExpandBuff(boolean wrapAround) {
/*  54 */     char[] newbuffer = new char[this.bufsize + 2048];
/*  55 */     int[] newbufline = new int[this.bufsize + 2048];
/*  56 */     int[] newbufcolumn = new int[this.bufsize + 2048];
/*     */ 
/*     */     
/*     */     try {
/*  60 */       if (wrapAround)
/*     */       {
/*  62 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  63 */         System.arraycopy(this.buffer, 0, newbuffer, this.bufsize - this.tokenBegin, this.bufpos);
/*     */         
/*  65 */         this.buffer = newbuffer;
/*     */         
/*  67 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  68 */         System.arraycopy(this.bufline, 0, newbufline, this.bufsize - this.tokenBegin, this.bufpos);
/*  69 */         this.bufline = newbufline;
/*     */         
/*  71 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  72 */         System.arraycopy(this.bufcolumn, 0, newbufcolumn, this.bufsize - this.tokenBegin, this.bufpos);
/*  73 */         this.bufcolumn = newbufcolumn;
/*     */         
/*  75 */         this.maxNextCharInd = this.bufpos += this.bufsize - this.tokenBegin;
/*     */       }
/*     */       else
/*     */       {
/*  79 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  80 */         this.buffer = newbuffer;
/*     */         
/*  82 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  83 */         this.bufline = newbufline;
/*     */         
/*  85 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  86 */         this.bufcolumn = newbufcolumn;
/*     */         
/*  88 */         this.maxNextCharInd = this.bufpos -= this.tokenBegin;
/*     */       }
/*     */     
/*  91 */     } catch (Throwable t) {
/*     */       
/*  93 */       throw new Error(t.getMessage());
/*     */     } 
/*     */ 
/*     */     
/*  97 */     this.bufsize += 2048;
/*  98 */     this.available = this.bufsize;
/*  99 */     this.tokenBegin = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private final void FillBuff() throws IOException {
/* 104 */     if (this.maxNextCharInd == this.available)
/*     */     {
/* 106 */       if (this.available == this.bufsize) {
/*     */         
/* 108 */         if (this.tokenBegin > 2048) {
/*     */           
/* 110 */           this.bufpos = this.maxNextCharInd = 0;
/* 111 */           this.available = this.tokenBegin;
/*     */         }
/* 113 */         else if (this.tokenBegin < 0) {
/* 114 */           this.bufpos = this.maxNextCharInd = 0;
/*     */         } else {
/* 116 */           ExpandBuff(false);
/*     */         } 
/* 118 */       } else if (this.available > this.tokenBegin) {
/* 119 */         this.available = this.bufsize;
/* 120 */       } else if (this.tokenBegin - this.available < 2048) {
/* 121 */         ExpandBuff(true);
/*     */       } else {
/* 123 */         this.available = this.tokenBegin;
/*     */       } 
/*     */     }
/*     */     try {
/*     */       int i;
/* 128 */       if ((i = this.inputStream.read(this.buffer, this.maxNextCharInd, this.available - this.maxNextCharInd)) == -1) {
/*     */ 
/*     */         
/* 131 */         this.inputStream.close();
/* 132 */         throw new IOException();
/*     */       } 
/*     */       
/* 135 */       this.maxNextCharInd += i;
/*     */       
/*     */       return;
/* 138 */     } catch (IOException e) {
/* 139 */       this.bufpos--;
/* 140 */       backup(0);
/* 141 */       if (this.tokenBegin == -1)
/* 142 */         this.tokenBegin = this.bufpos; 
/* 143 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final char BeginToken() throws IOException {
/* 149 */     this.tokenBegin = -1;
/* 150 */     char c = readChar();
/* 151 */     this.tokenBegin = this.bufpos;
/*     */     
/* 153 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   private final void UpdateLineColumn(char c) {
/* 158 */     this.column++;
/*     */     
/* 160 */     if (this.prevCharIsLF) {
/*     */       
/* 162 */       this.prevCharIsLF = false;
/* 163 */       this.line += this.column = 1;
/*     */     }
/* 165 */     else if (this.prevCharIsCR) {
/*     */       
/* 167 */       this.prevCharIsCR = false;
/* 168 */       if (c == '\n') {
/*     */         
/* 170 */         this.prevCharIsLF = true;
/*     */       } else {
/*     */         
/* 173 */         this.line += this.column = 1;
/*     */       } 
/*     */     } 
/* 176 */     switch (c) {
/*     */       
/*     */       case '\r':
/* 179 */         this.prevCharIsCR = true;
/*     */         break;
/*     */       case '\n':
/* 182 */         this.prevCharIsLF = true;
/*     */         break;
/*     */       case '\t':
/* 185 */         this.column--;
/* 186 */         this.column += 8 - (this.column & 0x7);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 192 */     this.bufline[this.bufpos] = this.line;
/* 193 */     this.bufcolumn[this.bufpos] = this.column;
/*     */   }
/*     */ 
/*     */   
/*     */   public final char readChar() throws IOException {
/* 198 */     if (this.inBuf > 0) {
/*     */       
/* 200 */       this.inBuf--;
/* 201 */       return (char)(0xFF & this.buffer[(this.bufpos == this.bufsize - 1) ? (this.bufpos = 0) : ++this.bufpos]);
/*     */     } 
/*     */     
/* 204 */     if (++this.bufpos >= this.maxNextCharInd) {
/* 205 */       FillBuff();
/*     */     }
/* 207 */     char c = (char)(0xFF & this.buffer[this.bufpos]);
/*     */     
/* 209 */     UpdateLineColumn(c);
/* 210 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getColumn() {
/* 219 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLine() {
/* 228 */     return this.bufline[this.bufpos];
/*     */   }
/*     */   
/*     */   public final int getEndColumn() {
/* 232 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */   
/*     */   public final int getEndLine() {
/* 236 */     return this.bufline[this.bufpos];
/*     */   }
/*     */   
/*     */   public final int getBeginColumn() {
/* 240 */     return this.bufcolumn[this.tokenBegin];
/*     */   }
/*     */   
/*     */   public final int getBeginLine() {
/* 244 */     return this.bufline[this.tokenBegin];
/*     */   }
/*     */ 
/*     */   
/*     */   public final void backup(int amount) {
/* 249 */     this.inBuf += amount;
/* 250 */     if ((this.bufpos -= amount) < 0) {
/* 251 */       this.bufpos += this.bufsize;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ASCII_CharStream(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 257 */     this.inputStream = dstream;
/* 258 */     this.line = startline;
/* 259 */     this.column = startcolumn - 1;
/*     */     
/* 261 */     this.available = this.bufsize = buffersize;
/* 262 */     this.buffer = new char[buffersize];
/* 263 */     this.bufline = new int[buffersize];
/* 264 */     this.bufcolumn = new int[buffersize];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ASCII_CharStream(Reader dstream, int startline, int startcolumn) {
/* 270 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 275 */     this.inputStream = dstream;
/* 276 */     this.line = startline;
/* 277 */     this.column = startcolumn - 1;
/*     */     
/* 279 */     if (this.buffer == null || buffersize != this.buffer.length) {
/*     */       
/* 281 */       this.available = this.bufsize = buffersize;
/* 282 */       this.buffer = new char[buffersize];
/* 283 */       this.bufline = new int[buffersize];
/* 284 */       this.bufcolumn = new int[buffersize];
/*     */     } 
/* 286 */     this.prevCharIsLF = this.prevCharIsCR = false;
/* 287 */     this.tokenBegin = this.inBuf = this.maxNextCharInd = 0;
/* 288 */     this.bufpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn) {
/* 294 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASCII_CharStream(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 299 */     this(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ASCII_CharStream(InputStream dstream, int startline, int startcolumn) {
/* 305 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 311 */     ReInit(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn) {
/* 316 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */   
/*     */   public final String GetImage() {
/* 320 */     if (this.bufpos >= this.tokenBegin) {
/* 321 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/*     */     }
/* 323 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final char[] GetSuffix(int len) {
/* 329 */     char[] ret = new char[len];
/*     */     
/* 331 */     if (this.bufpos + 1 >= len) {
/* 332 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/*     */     } else {
/*     */       
/* 335 */       System.arraycopy(this.buffer, this.bufsize - len - this.bufpos - 1, ret, 0, len - this.bufpos - 1);
/*     */       
/* 337 */       System.arraycopy(this.buffer, 0, ret, len - this.bufpos - 1, this.bufpos + 1);
/*     */     } 
/*     */     
/* 340 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void Done() {
/* 345 */     this.buffer = null;
/* 346 */     this.bufline = null;
/* 347 */     this.bufcolumn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustBeginLineColumn(int newLine, int newCol) {
/* 355 */     int len, start = this.tokenBegin;
/*     */ 
/*     */     
/* 358 */     if (this.bufpos >= this.tokenBegin) {
/*     */       
/* 360 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/*     */     }
/*     */     else {
/*     */       
/* 364 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/*     */     } 
/*     */     
/* 367 */     int i = 0, j = 0, k = 0;
/* 368 */     int nextColDiff = 0, columnDiff = 0;
/*     */ 
/*     */     
/* 371 */     while (i < len && this.bufline[j = start % this.bufsize] == this.bufline[k = ++start % this.bufsize]) {
/*     */       
/* 373 */       this.bufline[j] = newLine;
/* 374 */       nextColDiff = columnDiff + this.bufcolumn[k] - this.bufcolumn[j];
/* 375 */       this.bufcolumn[j] = newCol + columnDiff;
/* 376 */       columnDiff = nextColDiff;
/* 377 */       i++;
/*     */     } 
/*     */     
/* 380 */     if (i < len) {
/*     */       
/* 382 */       this.bufline[j] = newLine++;
/* 383 */       this.bufcolumn[j] = newCol + columnDiff;
/*     */       
/* 385 */       while (i++ < len) {
/*     */         
/* 387 */         if (this.bufline[j = start % this.bufsize] != this.bufline[++start % this.bufsize]) {
/* 388 */           this.bufline[j] = newLine++; continue;
/*     */         } 
/* 390 */         this.bufline[j] = newLine;
/*     */       } 
/*     */     } 
/*     */     
/* 394 */     this.line = this.bufline[j];
/* 395 */     this.column = this.bufcolumn[j];
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\ASCII_CharStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */