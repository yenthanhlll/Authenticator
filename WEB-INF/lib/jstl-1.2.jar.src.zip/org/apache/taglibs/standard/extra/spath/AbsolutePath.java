/*    */ package org.apache.taglibs.standard.extra.spath;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbsolutePath
/*    */   extends Path
/*    */ {
/*    */   private boolean all;
/*    */   private RelativePath base;
/*    */   
/*    */   public AbsolutePath(RelativePath base) {
/* 48 */     if (base == null)
/* 49 */       throw new IllegalArgumentException("non-null base required"); 
/* 50 */     this.base = base;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List getSteps() {
/* 56 */     return this.base.getSteps();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\AbsolutePath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */