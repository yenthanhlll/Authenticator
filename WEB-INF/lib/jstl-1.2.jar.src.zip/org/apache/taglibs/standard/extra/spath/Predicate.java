package org.apache.taglibs.standard.extra.spath;

public abstract class Predicate {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\Predicate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */