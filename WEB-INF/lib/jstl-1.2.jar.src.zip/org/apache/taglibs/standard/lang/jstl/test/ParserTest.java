/*     */ package org.apache.taglibs.standard.lang.jstl.test;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.apache.taglibs.standard.lang.jstl.Evaluator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserTest
/*     */ {
/*     */   public static void runTests(DataInput pIn, PrintStream pOut) throws IOException {
/*     */     while (true) {
/*  89 */       String str = pIn.readLine();
/*  90 */       if (str == null)
/*  91 */         break;  if (str.startsWith("#") || "".equals(str.trim())) {
/*     */         
/*  93 */         pOut.println(str);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*  98 */       if ("@@non-ascii".equals(str)) {
/*  99 */         str = "ᄑ";
/*     */       }
/*     */       
/* 102 */       pOut.println("Attribute value: " + str);
/*     */       try {
/* 104 */         String result = Evaluator.parseAndRender(str);
/* 105 */         pOut.println("Parses to: " + result);
/*     */       }
/* 107 */       catch (JspException exc) {
/* 108 */         pOut.println("Causes an error: " + exc.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runTests(File pInputFile, File pOutputFile) throws IOException {
/* 125 */     FileInputStream fin = null;
/* 126 */     FileOutputStream fout = null;
/*     */     try {
/* 128 */       fin = new FileInputStream(pInputFile);
/* 129 */       BufferedInputStream bin = new BufferedInputStream(fin);
/* 130 */       DataInputStream din = new DataInputStream(bin);
/*     */       
/*     */       try {
/* 133 */         fout = new FileOutputStream(pOutputFile);
/* 134 */         BufferedOutputStream bout = new BufferedOutputStream(fout);
/* 135 */         PrintStream pout = new PrintStream(bout);
/*     */         
/* 137 */         runTests(din, pout);
/*     */         
/* 139 */         pout.flush();
/*     */       } finally {
/*     */         
/* 142 */         if (fout != null) {
/* 143 */           fout.close();
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 148 */       if (fin != null) {
/* 149 */         fin.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDifferentFiles(DataInput pIn1, DataInput pIn2) throws IOException {
/*     */     while (true) {
/* 165 */       String str1 = pIn1.readLine();
/* 166 */       String str2 = pIn2.readLine();
/* 167 */       if (str1 == null && str2 == null)
/*     */       {
/* 169 */         return false;
/*     */       }
/* 171 */       if (str1 == null || str2 == null)
/*     */       {
/* 173 */         return true;
/*     */       }
/*     */       
/* 176 */       if (!str1.equals(str2)) {
/* 177 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDifferentFiles(File pFile1, File pFile2) throws IOException {
/* 193 */     FileInputStream fin1 = null;
/*     */     try {
/* 195 */       fin1 = new FileInputStream(pFile1);
/* 196 */       BufferedInputStream bin1 = new BufferedInputStream(fin1);
/* 197 */       DataInputStream din1 = new DataInputStream(bin1);
/*     */       
/* 199 */       FileInputStream fin2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 214 */       if (fin1 != null) {
/* 215 */         fin1.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] pArgs) throws IOException {
/* 230 */     if (pArgs.length != 2 && pArgs.length != 3) {
/*     */       
/* 232 */       usage();
/* 233 */       System.exit(1);
/*     */     } 
/*     */     
/* 236 */     File in = new File(pArgs[0]);
/* 237 */     File out = new File(pArgs[1]);
/*     */     
/* 239 */     runTests(in, out);
/*     */     
/* 241 */     if (pArgs.length > 2) {
/* 242 */       File compare = new File(pArgs[2]);
/* 243 */       if (isDifferentFiles(out, compare)) {
/* 244 */         System.out.println("Test failure - output file " + out + " differs from expected output file " + compare);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 250 */         System.out.println("tests passed");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void usage() {
/* 258 */     System.err.println("usage: java org.apache.taglibs.standard.lang.jstl.test.ParserTest {input file} {output file} [{compare file}]");
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\ParserTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */