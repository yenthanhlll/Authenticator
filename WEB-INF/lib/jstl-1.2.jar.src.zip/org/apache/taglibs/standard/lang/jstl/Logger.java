/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logger
/*     */ {
/*     */   PrintStream mOut;
/*     */   
/*     */   public Logger(PrintStream pOut) {
/*  63 */     this.mOut = pOut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLoggingWarning() {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pMessage, Throwable pRootCause) throws ELException {
/*  86 */     if (isLoggingWarning()) {
/*  87 */       if (pMessage == null) {
/*  88 */         System.out.println(pRootCause);
/*     */       }
/*  90 */       else if (pRootCause == null) {
/*  91 */         System.out.println(pMessage);
/*     */       } else {
/*     */         
/*  94 */         System.out.println(pMessage + ": " + pRootCause);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate) throws ELException {
/* 107 */     if (isLoggingWarning()) {
/* 108 */       logWarning(pTemplate, (Throwable)null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(Throwable pRootCause) throws ELException {
/* 120 */     if (isLoggingWarning()) {
/* 121 */       logWarning((String)null, pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Object pArg0) throws ELException {
/* 134 */     if (isLoggingWarning()) {
/* 135 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Throwable pRootCause, Object pArg0) throws ELException {
/* 154 */     if (isLoggingWarning()) {
/* 155 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Object pArg0, Object pArg1) throws ELException {
/* 175 */     if (isLoggingWarning()) {
/* 176 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1) throws ELException {
/* 197 */     if (isLoggingWarning()) {
/* 198 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Object pArg0, Object pArg1, Object pArg2) throws ELException {
/* 220 */     if (isLoggingWarning()) {
/* 221 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2) throws ELException {
/* 244 */     if (isLoggingWarning()) {
/* 245 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Object pArg0, Object pArg1, Object pArg2, Object pArg3) throws ELException {
/* 269 */     if (isLoggingWarning()) {
/* 270 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2, Object pArg3) throws ELException {
/* 295 */     if (isLoggingWarning()) {
/* 296 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4) throws ELException {
/* 322 */     if (isLoggingWarning()) {
/* 323 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4) throws ELException {
/* 350 */     if (isLoggingWarning()) {
/* 351 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4, Object pArg5) throws ELException {
/* 379 */     if (isLoggingWarning()) {
/* 380 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4, "" + pArg5 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarning(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4, Object pArg5) throws ELException {
/* 409 */     if (isLoggingWarning()) {
/* 410 */       logWarning(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4, "" + pArg5 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLoggingError() {
/* 433 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pMessage, Throwable pRootCause) throws ELException {
/* 445 */     if (isLoggingError()) {
/* 446 */       if (pMessage == null) {
/* 447 */         throw new ELException(pRootCause);
/*     */       }
/* 449 */       if (pRootCause == null) {
/* 450 */         throw new ELException(pMessage);
/*     */       }
/*     */       
/* 453 */       throw new ELException(pMessage, pRootCause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate) throws ELException {
/* 466 */     if (isLoggingError()) {
/* 467 */       logError(pTemplate, (Throwable)null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(Throwable pRootCause) throws ELException {
/* 479 */     if (isLoggingError()) {
/* 480 */       logError((String)null, pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Object pArg0) throws ELException {
/* 493 */     if (isLoggingError()) {
/* 494 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Throwable pRootCause, Object pArg0) throws ELException {
/* 513 */     if (isLoggingError()) {
/* 514 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Object pArg0, Object pArg1) throws ELException {
/* 534 */     if (isLoggingError()) {
/* 535 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1) throws ELException {
/* 556 */     if (isLoggingError()) {
/* 557 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Object pArg0, Object pArg1, Object pArg2) throws ELException {
/* 579 */     if (isLoggingError()) {
/* 580 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2) throws ELException {
/* 603 */     if (isLoggingError()) {
/* 604 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Object pArg0, Object pArg1, Object pArg2, Object pArg3) throws ELException {
/* 628 */     if (isLoggingError()) {
/* 629 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2, Object pArg3) throws ELException {
/* 654 */     if (isLoggingError()) {
/* 655 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4) throws ELException {
/* 681 */     if (isLoggingError()) {
/* 682 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4) throws ELException {
/* 709 */     if (isLoggingError()) {
/* 710 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4 }), pRootCause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4, Object pArg5) throws ELException {
/* 738 */     if (isLoggingError()) {
/* 739 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4, "" + pArg5 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String pTemplate, Throwable pRootCause, Object pArg0, Object pArg1, Object pArg2, Object pArg3, Object pArg4, Object pArg5) throws ELException {
/* 768 */     if (isLoggingError())
/* 769 */       logError(MessageFormat.format(pTemplate, new Object[] { "" + pArg0, "" + pArg1, "" + pArg2, "" + pArg3, "" + pArg4, "" + pArg5 }), pRootCause); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\Logger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */