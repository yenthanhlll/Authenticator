package org.apache.taglibs.standard.lang.jstl.test.beans;

public class PublicBean1b extends PrivateBean1a {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PublicBean1b.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */