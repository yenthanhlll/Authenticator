package org.apache.taglibs.standard.lang.jstl.test.beans;

public interface PublicInterface2 {
  Object getValue();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PublicInterface2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */