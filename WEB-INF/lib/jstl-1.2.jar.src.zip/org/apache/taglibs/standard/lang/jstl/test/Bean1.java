/*     */ package org.apache.taglibs.standard.lang.jstl.test;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bean1
/*     */ {
/*     */   boolean mBoolean1;
/*     */   byte mByte1;
/*     */   char mChar1;
/*     */   short mShort1;
/*     */   int mInt1;
/*     */   long mLong1;
/*     */   float mFloat1;
/*     */   double mDouble1;
/*     */   Boolean mBoolean2;
/*     */   Byte mByte2;
/*     */   Character mChar2;
/*     */   Short mShort2;
/*     */   Integer mInt2;
/*     */   Long mLong2;
/*     */   Float mFloat2;
/*     */   Double mDouble2;
/*     */   String mString1;
/*     */   String mString2;
/*     */   Bean1 mBean1;
/*     */   Bean1 mBean2;
/*     */   String mNoGetter;
/*     */   String mErrorInGetter;
/*     */   String[] mStringArray1;
/*     */   List mList1;
/*     */   Map mMap1;
/*     */   
/*     */   public boolean getBoolean1() {
/*  48 */     return this.mBoolean1;
/*     */   } public void setBoolean1(boolean pBoolean1) {
/*  50 */     this.mBoolean1 = pBoolean1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte1() {
/*  57 */     return this.mByte1;
/*     */   } public void setByte1(byte pByte1) {
/*  59 */     this.mByte1 = pByte1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getChar1() {
/*  66 */     return this.mChar1;
/*     */   } public void setChar1(char pChar1) {
/*  68 */     this.mChar1 = pChar1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getShort1() {
/*  75 */     return this.mShort1;
/*     */   } public void setShort1(short pShort1) {
/*  77 */     this.mShort1 = pShort1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt1() {
/*  84 */     return this.mInt1;
/*     */   } public void setInt1(int pInt1) {
/*  86 */     this.mInt1 = pInt1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong1() {
/*  93 */     return this.mLong1;
/*     */   } public void setLong1(long pLong1) {
/*  95 */     this.mLong1 = pLong1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloat1() {
/* 102 */     return this.mFloat1;
/*     */   } public void setFloat1(float pFloat1) {
/* 104 */     this.mFloat1 = pFloat1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble1() {
/* 111 */     return this.mDouble1;
/*     */   } public void setDouble1(double pDouble1) {
/* 113 */     this.mDouble1 = pDouble1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getBoolean2() {
/* 120 */     return this.mBoolean2;
/*     */   } public void setBoolean2(Boolean pBoolean2) {
/* 122 */     this.mBoolean2 = pBoolean2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Byte getByte2() {
/* 129 */     return this.mByte2;
/*     */   } public void setByte2(Byte pByte2) {
/* 131 */     this.mByte2 = pByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Character getChar2() {
/* 138 */     return this.mChar2;
/*     */   } public void setChar2(Character pChar2) {
/* 140 */     this.mChar2 = pChar2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Short getShort2() {
/* 147 */     return this.mShort2;
/*     */   } public void setShort2(Short pShort2) {
/* 149 */     this.mShort2 = pShort2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getInt2() {
/* 156 */     return this.mInt2;
/*     */   } public void setInt2(Integer pInt2) {
/* 158 */     this.mInt2 = pInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getLong2() {
/* 165 */     return this.mLong2;
/*     */   } public void setLong2(Long pLong2) {
/* 167 */     this.mLong2 = pLong2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Float getFloat2() {
/* 174 */     return this.mFloat2;
/*     */   } public void setFloat2(Float pFloat2) {
/* 176 */     this.mFloat2 = pFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getDouble2() {
/* 183 */     return this.mDouble2;
/*     */   } public void setDouble2(Double pDouble2) {
/* 185 */     this.mDouble2 = pDouble2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString1() {
/* 192 */     return this.mString1;
/*     */   } public void setString1(String pString1) {
/* 194 */     this.mString1 = pString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString2() {
/* 201 */     return this.mString2;
/*     */   } public void setString2(String pString2) {
/* 203 */     this.mString2 = pString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean1 getBean1() {
/* 210 */     return this.mBean1;
/*     */   } public void setBean1(Bean1 pBean1) {
/* 212 */     this.mBean1 = pBean1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bean1 getBean2() {
/* 219 */     return this.mBean2;
/*     */   } public void setBean2(Bean1 pBean2) {
/* 221 */     this.mBean2 = pBean2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoGetter(String pNoGetter) {
/* 228 */     this.mNoGetter = pNoGetter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorInGetter() {
/* 235 */     throw new NullPointerException("Error!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getStringArray1() {
/* 242 */     return this.mStringArray1;
/*     */   } public void setStringArray1(String[] pStringArray1) {
/* 244 */     this.mStringArray1 = pStringArray1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getList1() {
/* 251 */     return this.mList1;
/*     */   } public void setList1(List pList1) {
/* 253 */     this.mList1 = pList1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getMap1() {
/* 260 */     return this.mMap1;
/*     */   } public void setMap1(Map pMap1) {
/* 262 */     this.mMap1 = pMap1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndexed1(int pIndex) {
/* 268 */     return this.mStringArray1[pIndex];
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\Bean1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */