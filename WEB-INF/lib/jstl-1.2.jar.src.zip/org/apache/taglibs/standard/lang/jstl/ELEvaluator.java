/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.taglibs.standard.lang.jstl.parser.ELParser;
/*     */ import org.apache.taglibs.standard.lang.jstl.parser.ParseException;
/*     */ import org.apache.taglibs.standard.lang.jstl.parser.Token;
/*     */ import org.apache.taglibs.standard.lang.jstl.parser.TokenMgrError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ELEvaluator
/*     */ {
/* 103 */   static Map sCachedExpressionStrings = Collections.synchronizedMap(new HashMap<Object, Object>());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   static Map sCachedExpectedTypes = new HashMap<Object, Object>();
/*     */ 
/*     */   
/* 111 */   static Logger sLogger = new Logger(System.out);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   VariableResolver mResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean mBypassCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ELEvaluator(VariableResolver pResolver) {
/* 130 */     this.mResolver = pResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ELEvaluator(VariableResolver pResolver, boolean pBypassCache) {
/* 148 */     this.mResolver = pResolver;
/* 149 */     this.mBypassCache = pBypassCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(String pExpressionString, Object pContext, Class pExpectedType, Map functions, String defaultPrefix) throws ELException {
/* 172 */     return evaluate(pExpressionString, pContext, pExpectedType, functions, defaultPrefix, sLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object evaluate(String pExpressionString, Object pContext, Class pExpectedType, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 194 */     if (pExpressionString == null) {
/* 195 */       throw new ELException(Constants.NULL_EXPRESSION_STRING);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 200 */     Object parsedValue = parseExpressionString(pExpressionString);
/*     */ 
/*     */     
/* 203 */     if (parsedValue instanceof String) {
/*     */       
/* 205 */       String strValue = (String)parsedValue;
/* 206 */       return convertStaticValueToExpectedType(strValue, pExpectedType, pLogger);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (parsedValue instanceof Expression) {
/*     */       
/* 213 */       Object value = ((Expression)parsedValue).evaluate(pContext, this.mResolver, functions, defaultPrefix, pLogger);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       return convertToExpectedType(value, pExpectedType, pLogger);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (parsedValue instanceof ExpressionString) {
/*     */       
/* 226 */       String strValue = ((ExpressionString)parsedValue).evaluate(pContext, this.mResolver, functions, defaultPrefix, pLogger);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 232 */       return convertToExpectedType(strValue, pExpectedType, pLogger);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object parseExpressionString(String pExpressionString) throws ELException {
/* 255 */     if (pExpressionString.length() == 0) {
/* 256 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 260 */     Object ret = this.mBypassCache ? null : sCachedExpressionStrings.get(pExpressionString);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     if (ret == null) {
/*     */       
/* 267 */       Reader r = new StringReader(pExpressionString);
/* 268 */       ELParser parser = new ELParser(r);
/*     */       try {
/* 270 */         ret = parser.ExpressionString();
/* 271 */         sCachedExpressionStrings.put(pExpressionString, ret);
/*     */       }
/* 273 */       catch (ParseException exc) {
/* 274 */         throw new ELException(formatParseException(pExpressionString, exc));
/*     */ 
/*     */       
/*     */       }
/* 278 */       catch (TokenMgrError exc) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 283 */         throw new ELException(exc.getMessage());
/*     */       } 
/*     */     } 
/* 286 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object convertToExpectedType(Object pValue, Class pExpectedType, Logger pLogger) throws ELException {
/* 299 */     return Coercions.coerce(pValue, pExpectedType, pLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object convertStaticValueToExpectedType(String pValue, Class<String> pExpectedType, Logger pLogger) throws ELException {
/* 316 */     if (pExpectedType == String.class || pExpectedType == Object.class)
/*     */     {
/* 318 */       return pValue;
/*     */     }
/*     */ 
/*     */     
/* 322 */     Map<String, Object> valueByString = getOrCreateExpectedTypeMap(pExpectedType);
/* 323 */     if (!this.mBypassCache && valueByString.containsKey(pValue))
/*     */     {
/* 325 */       return valueByString.get(pValue);
/*     */     }
/*     */ 
/*     */     
/* 329 */     Object ret = Coercions.coerce(pValue, pExpectedType, pLogger);
/* 330 */     valueByString.put(pValue, ret);
/* 331 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Map getOrCreateExpectedTypeMap(Class<?> pExpectedType) {
/* 343 */     synchronized (sCachedExpectedTypes) {
/* 344 */       Map<?, ?> ret = (Map)sCachedExpectedTypes.get(pExpectedType);
/* 345 */       if (ret == null) {
/* 346 */         ret = Collections.synchronizedMap(new HashMap<Object, Object>());
/* 347 */         sCachedExpectedTypes.put(pExpectedType, ret);
/*     */       } 
/* 349 */       return ret;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String formatParseException(String pExpressionString, ParseException pExc) {
/* 365 */     StringBuffer expectedBuf = new StringBuffer();
/* 366 */     int maxSize = 0;
/* 367 */     boolean printedOne = false;
/*     */     
/* 369 */     if (pExc.expectedTokenSequences == null) {
/* 370 */       return pExc.toString();
/*     */     }
/* 372 */     for (int i = 0; i < pExc.expectedTokenSequences.length; i++) {
/* 373 */       if (maxSize < (pExc.expectedTokenSequences[i]).length) {
/* 374 */         maxSize = (pExc.expectedTokenSequences[i]).length;
/*     */       }
/* 376 */       for (int k = 0; k < (pExc.expectedTokenSequences[i]).length; k++) {
/* 377 */         if (printedOne) {
/* 378 */           expectedBuf.append(", ");
/*     */         }
/* 380 */         expectedBuf.append(pExc.tokenImage[pExc.expectedTokenSequences[i][k]]);
/*     */         
/* 382 */         printedOne = true;
/*     */       } 
/*     */     } 
/* 385 */     String expected = expectedBuf.toString();
/*     */ 
/*     */     
/* 388 */     StringBuffer encounteredBuf = new StringBuffer();
/* 389 */     Token tok = pExc.currentToken.next;
/* 390 */     for (int j = 0; j < maxSize; j++) {
/* 391 */       if (j != 0) encounteredBuf.append(" "); 
/* 392 */       if (tok.kind == 0) {
/* 393 */         encounteredBuf.append(pExc.tokenImage[0]);
/*     */         break;
/*     */       } 
/* 396 */       encounteredBuf.append(addEscapes(tok.image));
/* 397 */       tok = tok.next;
/*     */     } 
/* 399 */     String encountered = encounteredBuf.toString();
/*     */ 
/*     */     
/* 402 */     return MessageFormat.format(Constants.PARSE_EXCEPTION, new Object[] { expected, encountered });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String addEscapes(String str) {
/* 419 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 421 */     for (int i = 0; i < str.length(); i++) {
/* 422 */       char ch; switch (str.charAt(i)) {
/*     */         case '\000':
/*     */           break;
/*     */         case '\b':
/* 426 */           retval.append("\\b");
/*     */           break;
/*     */         case '\t':
/* 429 */           retval.append("\\t");
/*     */           break;
/*     */         case '\n':
/* 432 */           retval.append("\\n");
/*     */           break;
/*     */         case '\f':
/* 435 */           retval.append("\\f");
/*     */           break;
/*     */         case '\r':
/* 438 */           retval.append("\\r");
/*     */           break;
/*     */         default:
/* 441 */           if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/* 442 */             String s = "0000" + Integer.toString(ch, 16);
/* 443 */             retval.append("\\u" + s.substring(s.length() - 4, s.length()));
/*     */             break;
/*     */           } 
/* 446 */           retval.append(ch);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 451 */     return retval.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String parseAndRender(String pExpressionString) throws ELException {
/* 465 */     Object val = parseExpressionString(pExpressionString);
/* 466 */     if (val instanceof String) {
/* 467 */       return (String)val;
/*     */     }
/* 469 */     if (val instanceof Expression) {
/* 470 */       return "${" + ((Expression)val).getExpressionString() + "}";
/*     */     }
/* 472 */     if (val instanceof ExpressionString) {
/* 473 */       return ((ExpressionString)val).getExpressionString();
/*     */     }
/*     */     
/* 476 */     return "";
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ELEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */