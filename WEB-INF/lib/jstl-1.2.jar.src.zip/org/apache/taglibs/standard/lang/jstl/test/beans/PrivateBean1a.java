package org.apache.taglibs.standard.lang.jstl.test.beans;

class PrivateBean1a extends PublicBean1 {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PrivateBean1a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */