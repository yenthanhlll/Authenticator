package org.apache.taglibs.standard.lang.jstl;

public interface VariableResolver {
  Object resolveVariable(String paramString, Object paramObject) throws ELException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\VariableResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */