/*      */ package org.apache.taglibs.standard.lang.jstl.parser;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Enumeration;
/*      */ import java.util.List;
/*      */ import java.util.Vector;
/*      */ import org.apache.taglibs.standard.lang.jstl.AndOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.ArraySuffix;
/*      */ import org.apache.taglibs.standard.lang.jstl.BinaryOperatorExpression;
/*      */ import org.apache.taglibs.standard.lang.jstl.BooleanLiteral;
/*      */ import org.apache.taglibs.standard.lang.jstl.ComplexValue;
/*      */ import org.apache.taglibs.standard.lang.jstl.DivideOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.EmptyOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.EqualsOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.Expression;
/*      */ import org.apache.taglibs.standard.lang.jstl.ExpressionString;
/*      */ import org.apache.taglibs.standard.lang.jstl.FloatingPointLiteral;
/*      */ import org.apache.taglibs.standard.lang.jstl.FunctionInvocation;
/*      */ import org.apache.taglibs.standard.lang.jstl.GreaterThanOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.GreaterThanOrEqualsOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.IntegerLiteral;
/*      */ import org.apache.taglibs.standard.lang.jstl.LessThanOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.LessThanOrEqualsOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.Literal;
/*      */ import org.apache.taglibs.standard.lang.jstl.MinusOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.ModulusOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.MultiplyOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.NamedValue;
/*      */ import org.apache.taglibs.standard.lang.jstl.NotEqualsOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.NotOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.NullLiteral;
/*      */ import org.apache.taglibs.standard.lang.jstl.OrOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.PlusOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.PropertySuffix;
/*      */ import org.apache.taglibs.standard.lang.jstl.StringLiteral;
/*      */ import org.apache.taglibs.standard.lang.jstl.UnaryMinusOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.UnaryOperator;
/*      */ import org.apache.taglibs.standard.lang.jstl.UnaryOperatorExpression;
/*      */ import org.apache.taglibs.standard.lang.jstl.ValueSuffix;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ELParser
/*      */   implements ELParserConstants
/*      */ {
/*      */   public ELParserTokenManager token_source;
/*      */   SimpleCharStream jj_input_stream;
/*      */   public Token token;
/*      */   public Token jj_nt;
/*      */   private int jj_ntk;
/*      */   private Token jj_scanpos;
/*      */   private Token jj_lastpos;
/*      */   private int jj_la;
/*      */   
/*      */   public static void main(String[] args) throws ParseException {
/*   75 */     ELParser parser = new ELParser(System.in);
/*   76 */     parser.ExpressionString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object ExpressionString() throws ParseException {
/*   90 */     Object ret = "";
/*   91 */     List<Object> elems = null;
/*      */     
/*   93 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 1:
/*   95 */         ret = AttrValueString();
/*      */         break;
/*      */       case 2:
/*   98 */         ret = AttrValueExpression();
/*      */         break;
/*      */       default:
/*  101 */         this.jj_la1[0] = this.jj_gen;
/*  102 */         jj_consume_token(-1);
/*  103 */         throw new ParseException();
/*      */     } 
/*      */     while (true) {
/*      */       Object elem;
/*  107 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 1:
/*      */         case 2:
/*      */           break;
/*      */         
/*      */         default:
/*  113 */           this.jj_la1[1] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  116 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 1:
/*  118 */           elem = AttrValueString();
/*      */           break;
/*      */         case 2:
/*  121 */           elem = AttrValueExpression();
/*      */           break;
/*      */         default:
/*  124 */           this.jj_la1[2] = this.jj_gen;
/*  125 */           jj_consume_token(-1);
/*  126 */           throw new ParseException();
/*      */       } 
/*  128 */       if (elems == null) {
/*  129 */         elems = new ArrayList();
/*  130 */         elems.add(ret);
/*      */       } 
/*  132 */       elems.add(elem);
/*      */     } 
/*  134 */     if (elems != null) {
/*  135 */       ret = new ExpressionString(elems.toArray());
/*      */     }
/*  137 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String AttrValueString() throws ParseException {
/*  143 */     Token t = jj_consume_token(1);
/*  144 */     return t.image;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression AttrValueExpression() throws ParseException {
/*  150 */     jj_consume_token(2);
/*  151 */     Expression exp = Expression();
/*  152 */     jj_consume_token(15);
/*  153 */     return exp;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression Expression() throws ParseException {
/*  159 */     Expression ret = OrExpression();
/*  160 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression OrExpression() throws ParseException {
/*  168 */     List<OrOperator> operators = null;
/*  169 */     List<Expression> expressions = null;
/*  170 */     Expression startExpression = AndExpression();
/*      */     
/*      */     while (true) {
/*  173 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 46:
/*      */         case 47:
/*      */           break;
/*      */         
/*      */         default:
/*  179 */           this.jj_la1[3] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  182 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 46:
/*  184 */           jj_consume_token(46);
/*      */           break;
/*      */         case 47:
/*  187 */           jj_consume_token(47);
/*      */           break;
/*      */         default:
/*  190 */           this.jj_la1[4] = this.jj_gen;
/*  191 */           jj_consume_token(-1);
/*  192 */           throw new ParseException();
/*      */       } 
/*  194 */       OrOperator orOperator = OrOperator.SINGLETON;
/*  195 */       Expression expression = AndExpression();
/*  196 */       if (operators == null) {
/*  197 */         operators = new ArrayList();
/*  198 */         expressions = new ArrayList();
/*      */       } 
/*  200 */       operators.add(orOperator);
/*  201 */       expressions.add(expression);
/*      */     } 
/*  203 */     if (operators != null) {
/*  204 */       return (Expression)new BinaryOperatorExpression(startExpression, operators, expressions);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  209 */     return startExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression AndExpression() throws ParseException {
/*  218 */     List<AndOperator> operators = null;
/*  219 */     List<Expression> expressions = null;
/*  220 */     Expression startExpression = EqualityExpression();
/*      */     
/*      */     while (true) {
/*  223 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 44:
/*      */         case 45:
/*      */           break;
/*      */         
/*      */         default:
/*  229 */           this.jj_la1[5] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  232 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 44:
/*  234 */           jj_consume_token(44);
/*      */           break;
/*      */         case 45:
/*  237 */           jj_consume_token(45);
/*      */           break;
/*      */         default:
/*  240 */           this.jj_la1[6] = this.jj_gen;
/*  241 */           jj_consume_token(-1);
/*  242 */           throw new ParseException();
/*      */       } 
/*  244 */       AndOperator andOperator = AndOperator.SINGLETON;
/*  245 */       Expression expression = EqualityExpression();
/*  246 */       if (operators == null) {
/*  247 */         operators = new ArrayList();
/*  248 */         expressions = new ArrayList();
/*      */       } 
/*  250 */       operators.add(andOperator);
/*  251 */       expressions.add(expression);
/*      */     } 
/*  253 */     if (operators != null) {
/*  254 */       return (Expression)new BinaryOperatorExpression(startExpression, operators, expressions);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  259 */     return startExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression EqualityExpression() throws ParseException {
/*  268 */     List<NotEqualsOperator> operators = null;
/*  269 */     List<Expression> expressions = null;
/*  270 */     Expression startExpression = RelationalExpression(); while (true) {
/*      */       EqualsOperator equalsOperator;
/*      */       NotEqualsOperator notEqualsOperator;
/*  273 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 21:
/*      */         case 22:
/*      */         case 27:
/*      */         case 28:
/*      */           break;
/*      */         
/*      */         default:
/*  281 */           this.jj_la1[7] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  284 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 21:
/*      */         case 22:
/*  287 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 21:
/*  289 */               jj_consume_token(21);
/*      */               break;
/*      */             case 22:
/*  292 */               jj_consume_token(22);
/*      */               break;
/*      */             default:
/*  295 */               this.jj_la1[8] = this.jj_gen;
/*  296 */               jj_consume_token(-1);
/*  297 */               throw new ParseException();
/*      */           } 
/*  299 */           equalsOperator = EqualsOperator.SINGLETON;
/*      */           break;
/*      */         case 27:
/*      */         case 28:
/*  303 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 27:
/*  305 */               jj_consume_token(27);
/*      */               break;
/*      */             case 28:
/*  308 */               jj_consume_token(28);
/*      */               break;
/*      */             default:
/*  311 */               this.jj_la1[9] = this.jj_gen;
/*  312 */               jj_consume_token(-1);
/*  313 */               throw new ParseException();
/*      */           } 
/*  315 */           notEqualsOperator = NotEqualsOperator.SINGLETON;
/*      */           break;
/*      */         default:
/*  318 */           this.jj_la1[10] = this.jj_gen;
/*  319 */           jj_consume_token(-1);
/*  320 */           throw new ParseException();
/*      */       } 
/*  322 */       Expression expression = RelationalExpression();
/*  323 */       if (operators == null) {
/*  324 */         operators = new ArrayList();
/*  325 */         expressions = new ArrayList();
/*      */       } 
/*  327 */       operators.add(notEqualsOperator);
/*  328 */       expressions.add(expression);
/*      */     } 
/*  330 */     if (operators != null) {
/*  331 */       return (Expression)new BinaryOperatorExpression(startExpression, operators, expressions);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  336 */     return startExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression RelationalExpression() throws ParseException {
/*  345 */     List<LessThanOrEqualsOperator> operators = null;
/*  346 */     List<Expression> expressions = null;
/*  347 */     Expression startExpression = AddExpression(); while (true) {
/*      */       LessThanOperator lessThanOperator; GreaterThanOperator greaterThanOperator; GreaterThanOrEqualsOperator greaterThanOrEqualsOperator;
/*      */       LessThanOrEqualsOperator lessThanOrEqualsOperator;
/*  350 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 17:
/*      */         case 18:
/*      */         case 19:
/*      */         case 20:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */           break;
/*      */         
/*      */         default:
/*  362 */           this.jj_la1[11] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  365 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 19:
/*      */         case 20:
/*  368 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 19:
/*  370 */               jj_consume_token(19);
/*      */               break;
/*      */             case 20:
/*  373 */               jj_consume_token(20);
/*      */               break;
/*      */             default:
/*  376 */               this.jj_la1[12] = this.jj_gen;
/*  377 */               jj_consume_token(-1);
/*  378 */               throw new ParseException();
/*      */           } 
/*  380 */           lessThanOperator = LessThanOperator.SINGLETON;
/*      */           break;
/*      */         case 17:
/*      */         case 18:
/*  384 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 17:
/*  386 */               jj_consume_token(17);
/*      */               break;
/*      */             case 18:
/*  389 */               jj_consume_token(18);
/*      */               break;
/*      */             default:
/*  392 */               this.jj_la1[13] = this.jj_gen;
/*  393 */               jj_consume_token(-1);
/*  394 */               throw new ParseException();
/*      */           } 
/*  396 */           greaterThanOperator = GreaterThanOperator.SINGLETON;
/*      */           break;
/*      */         case 25:
/*      */         case 26:
/*  400 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 25:
/*  402 */               jj_consume_token(25);
/*      */               break;
/*      */             case 26:
/*  405 */               jj_consume_token(26);
/*      */               break;
/*      */             default:
/*  408 */               this.jj_la1[14] = this.jj_gen;
/*  409 */               jj_consume_token(-1);
/*  410 */               throw new ParseException();
/*      */           } 
/*  412 */           greaterThanOrEqualsOperator = GreaterThanOrEqualsOperator.SINGLETON;
/*      */           break;
/*      */         case 23:
/*      */         case 24:
/*  416 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 23:
/*  418 */               jj_consume_token(23);
/*      */               break;
/*      */             case 24:
/*  421 */               jj_consume_token(24);
/*      */               break;
/*      */             default:
/*  424 */               this.jj_la1[15] = this.jj_gen;
/*  425 */               jj_consume_token(-1);
/*  426 */               throw new ParseException();
/*      */           } 
/*  428 */           lessThanOrEqualsOperator = LessThanOrEqualsOperator.SINGLETON;
/*      */           break;
/*      */         default:
/*  431 */           this.jj_la1[16] = this.jj_gen;
/*  432 */           jj_consume_token(-1);
/*  433 */           throw new ParseException();
/*      */       } 
/*  435 */       Expression expression = AddExpression();
/*  436 */       if (operators == null) {
/*  437 */         operators = new ArrayList();
/*  438 */         expressions = new ArrayList();
/*      */       } 
/*  440 */       operators.add(lessThanOrEqualsOperator);
/*  441 */       expressions.add(expression);
/*      */     } 
/*  443 */     if (operators != null) {
/*  444 */       return (Expression)new BinaryOperatorExpression(startExpression, operators, expressions);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  449 */     return startExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression AddExpression() throws ParseException {
/*  458 */     List<MinusOperator> operators = null;
/*  459 */     List<Expression> expressions = null;
/*  460 */     Expression startExpression = MultiplyExpression(); while (true) {
/*      */       PlusOperator plusOperator;
/*      */       MinusOperator minusOperator;
/*  463 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 35:
/*      */         case 36:
/*      */           break;
/*      */         
/*      */         default:
/*  469 */           this.jj_la1[17] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  472 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 35:
/*  474 */           jj_consume_token(35);
/*  475 */           plusOperator = PlusOperator.SINGLETON;
/*      */           break;
/*      */         case 36:
/*  478 */           jj_consume_token(36);
/*  479 */           minusOperator = MinusOperator.SINGLETON;
/*      */           break;
/*      */         default:
/*  482 */           this.jj_la1[18] = this.jj_gen;
/*  483 */           jj_consume_token(-1);
/*  484 */           throw new ParseException();
/*      */       } 
/*  486 */       Expression expression = MultiplyExpression();
/*  487 */       if (operators == null) {
/*  488 */         operators = new ArrayList();
/*  489 */         expressions = new ArrayList();
/*      */       } 
/*  491 */       operators.add(minusOperator);
/*  492 */       expressions.add(expression);
/*      */     } 
/*  494 */     if (operators != null) {
/*  495 */       return (Expression)new BinaryOperatorExpression(startExpression, operators, expressions);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  500 */     return startExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression MultiplyExpression() throws ParseException {
/*  509 */     List<ModulusOperator> operators = null;
/*  510 */     List<Expression> expressions = null;
/*  511 */     Expression startExpression = UnaryExpression(); while (true) {
/*      */       MultiplyOperator multiplyOperator; DivideOperator divideOperator;
/*      */       ModulusOperator modulusOperator;
/*  514 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */         case 40:
/*      */         case 41:
/*      */           break;
/*      */         
/*      */         default:
/*  523 */           this.jj_la1[19] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  526 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 37:
/*  528 */           jj_consume_token(37);
/*  529 */           multiplyOperator = MultiplyOperator.SINGLETON;
/*      */           break;
/*      */         case 38:
/*      */         case 39:
/*  533 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 38:
/*  535 */               jj_consume_token(38);
/*      */               break;
/*      */             case 39:
/*  538 */               jj_consume_token(39);
/*      */               break;
/*      */             default:
/*  541 */               this.jj_la1[20] = this.jj_gen;
/*  542 */               jj_consume_token(-1);
/*  543 */               throw new ParseException();
/*      */           } 
/*  545 */           divideOperator = DivideOperator.SINGLETON;
/*      */           break;
/*      */         case 40:
/*      */         case 41:
/*  549 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 40:
/*  551 */               jj_consume_token(40);
/*      */               break;
/*      */             case 41:
/*  554 */               jj_consume_token(41);
/*      */               break;
/*      */             default:
/*  557 */               this.jj_la1[21] = this.jj_gen;
/*  558 */               jj_consume_token(-1);
/*  559 */               throw new ParseException();
/*      */           } 
/*  561 */           modulusOperator = ModulusOperator.SINGLETON;
/*      */           break;
/*      */         default:
/*  564 */           this.jj_la1[22] = this.jj_gen;
/*  565 */           jj_consume_token(-1);
/*  566 */           throw new ParseException();
/*      */       } 
/*  568 */       Expression expression = UnaryExpression();
/*  569 */       if (operators == null) {
/*  570 */         operators = new ArrayList();
/*  571 */         expressions = new ArrayList();
/*      */       } 
/*  573 */       operators.add(modulusOperator);
/*  574 */       expressions.add(expression);
/*      */     } 
/*  576 */     if (operators != null) {
/*  577 */       return (Expression)new BinaryOperatorExpression(startExpression, operators, expressions);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  582 */     return startExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression UnaryExpression() throws ParseException {
/*      */     EmptyOperator emptyOperator;
/*  589 */     UnaryOperator singleOperator = null;
/*      */     
/*  591 */     List<EmptyOperator> operators = null; while (true) {
/*      */       NotOperator notOperator; UnaryMinusOperator unaryMinusOperator;
/*      */       EmptyOperator emptyOperator1;
/*  594 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 36:
/*      */         case 42:
/*      */         case 43:
/*      */         case 48:
/*      */           break;
/*      */         
/*      */         default:
/*  602 */           this.jj_la1[23] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  605 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 42:
/*      */         case 43:
/*  608 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 42:
/*  610 */               jj_consume_token(42);
/*      */               break;
/*      */             case 43:
/*  613 */               jj_consume_token(43);
/*      */               break;
/*      */             default:
/*  616 */               this.jj_la1[24] = this.jj_gen;
/*  617 */               jj_consume_token(-1);
/*  618 */               throw new ParseException();
/*      */           } 
/*  620 */           notOperator = NotOperator.SINGLETON;
/*      */           break;
/*      */         case 36:
/*  623 */           jj_consume_token(36);
/*  624 */           unaryMinusOperator = UnaryMinusOperator.SINGLETON;
/*      */           break;
/*      */         case 48:
/*  627 */           jj_consume_token(48);
/*  628 */           emptyOperator1 = EmptyOperator.SINGLETON;
/*      */           break;
/*      */         default:
/*  631 */           this.jj_la1[25] = this.jj_gen;
/*  632 */           jj_consume_token(-1);
/*  633 */           throw new ParseException();
/*      */       } 
/*  635 */       if (singleOperator == null) {
/*  636 */         emptyOperator = emptyOperator1; continue;
/*      */       } 
/*  638 */       if (operators == null) {
/*  639 */         operators = new ArrayList();
/*  640 */         operators.add(emptyOperator);
/*  641 */         operators.add(emptyOperator1);
/*      */         continue;
/*      */       } 
/*  644 */       operators.add(emptyOperator1);
/*      */     } 
/*      */     
/*  647 */     Expression expression = Value();
/*  648 */     if (operators != null) {
/*  649 */       return (Expression)new UnaryOperatorExpression(null, operators, expression);
/*      */     }
/*  651 */     if (emptyOperator != null) {
/*  652 */       return (Expression)new UnaryOperatorExpression((UnaryOperator)emptyOperator, null, expression);
/*      */     }
/*      */     
/*  655 */     return expression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression Value() throws ParseException {
/*  663 */     List<ValueSuffix> suffixes = null;
/*  664 */     Expression prefix = ValuePrefix();
/*      */     
/*      */     while (true) {
/*  667 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 16:
/*      */         case 33:
/*      */           break;
/*      */         
/*      */         default:
/*  673 */           this.jj_la1[26] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  676 */       ValueSuffix suffix = ValueSuffix();
/*  677 */       if (suffixes == null) {
/*  678 */         suffixes = new ArrayList();
/*      */       }
/*  680 */       suffixes.add(suffix);
/*      */     } 
/*  682 */     if (suffixes == null) {
/*  683 */       return prefix;
/*      */     }
/*      */     
/*  686 */     return (Expression)new ComplexValue(prefix, suffixes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Expression ValuePrefix() throws ParseException {
/*      */     Literal literal;
/*      */     Expression expression;
/*      */     NamedValue namedValue;
/*  696 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk)
/*      */     { case 7:
/*      */       case 8:
/*      */       case 10:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*  703 */         return (Expression)Literal();
/*      */       
/*      */       case 29:
/*  706 */         jj_consume_token(29);
/*  707 */         expression = Expression();
/*  708 */         jj_consume_token(30);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  726 */         return expression; }  this.jj_la1[27] = this.jj_gen; if (jj_2_1(2147483647)) { FunctionInvocation functionInvocation = FunctionInvocation(); } else { switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) { case 49: namedValue = NamedValue(); return (Expression)namedValue; }  this.jj_la1[28] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); }  return (Expression)namedValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final NamedValue NamedValue() throws ParseException {
/*  732 */     Token t = jj_consume_token(49);
/*  733 */     return new NamedValue(t.image);
/*      */   }
/*      */ 
/*      */   
/*      */   public final FunctionInvocation FunctionInvocation() throws ParseException {
/*      */     Expression exp;
/*  739 */     List<Expression> argumentList = new ArrayList();
/*      */     
/*  741 */     String qualifiedName = QualifiedName();
/*  742 */     jj_consume_token(29);
/*  743 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 7:
/*      */       case 8:
/*      */       case 10:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 29:
/*      */       case 36:
/*      */       case 42:
/*      */       case 43:
/*      */       case 48:
/*      */       case 49:
/*  756 */         exp = Expression();
/*  757 */         argumentList.add(exp);
/*      */         
/*      */         while (true) {
/*  760 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 31:
/*      */               break;
/*      */             
/*      */             default:
/*  765 */               this.jj_la1[29] = this.jj_gen;
/*      */               break;
/*      */           } 
/*  768 */           jj_consume_token(31);
/*  769 */           exp = Expression();
/*  770 */           argumentList.add(exp);
/*      */         } 
/*      */         break;
/*      */       default:
/*  774 */         this.jj_la1[30] = this.jj_gen;
/*      */         break;
/*      */     } 
/*  777 */     jj_consume_token(30);
/*  778 */     String allowed = System.getProperty("javax.servlet.jsp.functions.allowed");
/*  779 */     if (allowed == null || !allowed.equalsIgnoreCase("true"))
/*  780 */       throw new ParseException("EL functions are not supported."); 
/*  781 */     return new FunctionInvocation(qualifiedName, argumentList);
/*      */   }
/*      */ 
/*      */   
/*      */   public final ValueSuffix ValueSuffix() throws ParseException {
/*      */     PropertySuffix propertySuffix;
/*  787 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 16:
/*  789 */         return (ValueSuffix)PropertySuffix();
/*      */       
/*      */       case 33:
/*  792 */         return (ValueSuffix)ArraySuffix();
/*      */     } 
/*      */     
/*  795 */     this.jj_la1[31] = this.jj_gen;
/*  796 */     jj_consume_token(-1);
/*  797 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PropertySuffix PropertySuffix() throws ParseException {
/*  806 */     jj_consume_token(16);
/*  807 */     String property = Identifier();
/*  808 */     return new PropertySuffix(property);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final ArraySuffix ArraySuffix() throws ParseException {
/*  814 */     jj_consume_token(33);
/*  815 */     Expression index = Expression();
/*  816 */     jj_consume_token(34);
/*  817 */     return new ArraySuffix(index);
/*      */   } public final Literal Literal() throws ParseException {
/*      */     BooleanLiteral booleanLiteral;
/*      */     IntegerLiteral integerLiteral;
/*      */     FloatingPointLiteral floatingPointLiteral;
/*      */     StringLiteral stringLiteral;
/*  823 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 12:
/*      */       case 13:
/*  826 */         return (Literal)BooleanLiteral();
/*      */       
/*      */       case 7:
/*  829 */         return (Literal)IntegerLiteral();
/*      */       
/*      */       case 8:
/*  832 */         return (Literal)FloatingPointLiteral();
/*      */       
/*      */       case 10:
/*  835 */         return (Literal)StringLiteral();
/*      */       
/*      */       case 14:
/*  838 */         return (Literal)NullLiteral();
/*      */     } 
/*      */     
/*  841 */     this.jj_la1[32] = this.jj_gen;
/*  842 */     jj_consume_token(-1);
/*  843 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BooleanLiteral BooleanLiteral() throws ParseException {
/*  850 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 12:
/*  852 */         jj_consume_token(12);
/*  853 */         return BooleanLiteral.TRUE;
/*      */       
/*      */       case 13:
/*  856 */         jj_consume_token(13);
/*  857 */         return BooleanLiteral.FALSE;
/*      */     } 
/*      */     
/*  860 */     this.jj_la1[33] = this.jj_gen;
/*  861 */     jj_consume_token(-1);
/*  862 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final StringLiteral StringLiteral() throws ParseException {
/*  869 */     Token t = jj_consume_token(10);
/*  870 */     return StringLiteral.fromToken(t.image);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final IntegerLiteral IntegerLiteral() throws ParseException {
/*  876 */     Token t = jj_consume_token(7);
/*  877 */     return new IntegerLiteral(t.image);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final FloatingPointLiteral FloatingPointLiteral() throws ParseException {
/*  883 */     Token t = jj_consume_token(8);
/*  884 */     return new FloatingPointLiteral(t.image);
/*      */   }
/*      */ 
/*      */   
/*      */   public final NullLiteral NullLiteral() throws ParseException {
/*  889 */     jj_consume_token(14);
/*  890 */     return NullLiteral.SINGLETON;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String Identifier() throws ParseException {
/*  896 */     Token t = jj_consume_token(49);
/*  897 */     return t.image;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String QualifiedName() throws ParseException {
/*  902 */     String prefix = null, localPart = null;
/*  903 */     if (jj_2_2(2147483647)) {
/*  904 */       prefix = Identifier();
/*  905 */       jj_consume_token(32);
/*      */     } 
/*      */ 
/*      */     
/*  909 */     localPart = Identifier();
/*  910 */     if (prefix == null) {
/*  911 */       return localPart;
/*      */     }
/*  913 */     return prefix + ":" + localPart;
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean jj_2_1(int xla) {
/*  918 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token;
/*  919 */     boolean retval = !jj_3_1();
/*  920 */     jj_save(0, xla);
/*  921 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_2(int xla) {
/*  925 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token;
/*  926 */     boolean retval = !jj_3_2();
/*  927 */     jj_save(1, xla);
/*  928 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_13() {
/*  932 */     if (jj_3R_12()) return true; 
/*  933 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  934 */     if (jj_scan_token(32)) return true; 
/*  935 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  936 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_2() {
/*  940 */     if (jj_3R_12()) return true; 
/*  941 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  942 */     if (jj_scan_token(32)) return true; 
/*  943 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  944 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_1() {
/*  948 */     if (jj_3R_11()) return true; 
/*  949 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  950 */     if (jj_scan_token(29)) return true; 
/*  951 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  952 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_12() {
/*  956 */     if (jj_scan_token(49)) return true; 
/*  957 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  958 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean jj_3R_11() {
/*  963 */     Token xsp = this.jj_scanpos;
/*  964 */     if (jj_3R_13()) { this.jj_scanpos = xsp; }
/*  965 */     else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) { return false; }
/*  966 */      if (jj_3R_12()) return true; 
/*  967 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*  968 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lookingAhead = false;
/*      */ 
/*      */   
/*      */   private boolean jj_semLA;
/*      */   
/*      */   private int jj_gen;
/*      */   
/*  980 */   private final int[] jj_la1 = new int[34];
/*  981 */   private final int[] jj_la1_0 = new int[] { 6, 6, 6, 0, 0, 0, 0, 408944640, 6291456, 402653184, 408944640, 127795200, 1572864, 393216, 100663296, 25165824, 127795200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65536, 536900992, 0, Integer.MIN_VALUE, 536900992, 65536, 30080, 12288 };
/*  982 */   private final int[] jj_la1_1 = new int[] { 0, 0, 0, 49152, 49152, 12288, 12288, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 24, 992, 192, 768, 992, 68624, 3072, 68624, 2, 0, 131072, 0, 199696, 2, 0, 0 };
/*  983 */   private final JJCalls[] jj_2_rtns = new JJCalls[2];
/*      */   private boolean jj_rescan = false;
/*  985 */   private int jj_gc = 0;
/*      */   
/*      */   private Vector jj_expentries;
/*      */   
/*      */   private int[] jj_expentry;
/*      */   
/*      */   private int jj_kind;
/*      */   
/*      */   private int[] jj_lasttokens;
/*      */   
/*      */   private int jj_endpos;
/*      */   
/*      */   public void ReInit(InputStream stream) {
/*  998 */     this.jj_input_stream.ReInit(stream, 1, 1);
/*  999 */     this.token_source.ReInit(this.jj_input_stream);
/* 1000 */     this.token = new Token();
/* 1001 */     this.jj_ntk = -1;
/* 1002 */     this.jj_gen = 0; int i;
/* 1003 */     for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }
/* 1004 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(Reader stream) {
/* 1018 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 1019 */     this.token_source.ReInit(this.jj_input_stream);
/* 1020 */     this.token = new Token();
/* 1021 */     this.jj_ntk = -1;
/* 1022 */     this.jj_gen = 0; int i;
/* 1023 */     for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }
/* 1024 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(ELParserTokenManager tm) {
/* 1037 */     this.token_source = tm;
/* 1038 */     this.token = new Token();
/* 1039 */     this.jj_ntk = -1;
/* 1040 */     this.jj_gen = 0; int i;
/* 1041 */     for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }
/* 1042 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */   private final Token jj_consume_token(int kind) throws ParseException {
/*      */     Token oldToken;
/* 1047 */     if ((oldToken = this.token).next != null) { this.token = this.token.next; }
/* 1048 */     else { this.token = this.token.next = this.token_source.getNextToken(); }
/* 1049 */      this.jj_ntk = -1;
/* 1050 */     if (this.token.kind == kind) {
/* 1051 */       this.jj_gen++;
/* 1052 */       if (++this.jj_gc > 100) {
/* 1053 */         this.jj_gc = 0;
/* 1054 */         for (int i = 0; i < this.jj_2_rtns.length; i++) {
/* 1055 */           JJCalls c = this.jj_2_rtns[i];
/* 1056 */           while (c != null) {
/* 1057 */             if (c.gen < this.jj_gen) c.first = null; 
/* 1058 */             c = c.next;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1062 */       return this.token;
/*      */     } 
/* 1064 */     this.token = oldToken;
/* 1065 */     this.jj_kind = kind;
/* 1066 */     throw generateParseException();
/*      */   }
/*      */   
/*      */   private final boolean jj_scan_token(int kind) {
/* 1070 */     if (this.jj_scanpos == this.jj_lastpos) {
/* 1071 */       this.jj_la--;
/* 1072 */       if (this.jj_scanpos.next == null) {
/* 1073 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
/*      */       } else {
/* 1075 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
/*      */       } 
/*      */     } else {
/* 1078 */       this.jj_scanpos = this.jj_scanpos.next;
/*      */     } 
/* 1080 */     if (this.jj_rescan) {
/* 1081 */       int i = 0; Token tok = this.token;
/* 1082 */       while (tok != null && tok != this.jj_scanpos) { i++; tok = tok.next; }
/* 1083 */        if (tok != null) jj_add_error_token(kind, i); 
/*      */     } 
/* 1085 */     return (this.jj_scanpos.kind != kind);
/*      */   }
/*      */   
/*      */   public final Token getNextToken() {
/* 1089 */     if (this.token.next != null) { this.token = this.token.next; }
/* 1090 */     else { this.token = this.token.next = this.token_source.getNextToken(); }
/* 1091 */      this.jj_ntk = -1;
/* 1092 */     this.jj_gen++;
/* 1093 */     return this.token;
/*      */   }
/*      */   
/*      */   public final Token getToken(int index) {
/* 1097 */     Token t = this.lookingAhead ? this.jj_scanpos : this.token;
/* 1098 */     for (int i = 0; i < index; i++) {
/* 1099 */       if (t.next != null) { t = t.next; }
/* 1100 */       else { t = t.next = this.token_source.getNextToken(); }
/*      */     
/* 1102 */     }  return t;
/*      */   }
/*      */   
/*      */   private final int jj_ntk() {
/* 1106 */     if ((this.jj_nt = this.token.next) == null) {
/* 1107 */       return this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind;
/*      */     }
/* 1109 */     return this.jj_ntk = this.jj_nt.kind;
/*      */   }
/*      */   
/* 1112 */   public ELParser(InputStream stream) { this.jj_expentries = new Vector();
/*      */     
/* 1114 */     this.jj_kind = -1;
/* 1115 */     this.jj_lasttokens = new int[100]; this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new ELParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public ELParser(Reader stream) { this.jj_expentries = new Vector(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new ELParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 34; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public ELParser(ELParserTokenManager tm) { this.jj_expentries = new Vector(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 34; ) {
/*      */       this.jj_la1[i] = -1; i++;
/*      */     }  for (i = 0; i < this.jj_2_rtns.length; ) {
/*      */       this.jj_2_rtns[i] = new JJCalls(); i++;
/* 1119 */     }  } private void jj_add_error_token(int kind, int pos) { if (pos >= 100)
/* 1120 */       return;  if (pos == this.jj_endpos + 1) {
/* 1121 */       this.jj_lasttokens[this.jj_endpos++] = kind;
/* 1122 */     } else if (this.jj_endpos != 0) {
/* 1123 */       this.jj_expentry = new int[this.jj_endpos];
/* 1124 */       for (int i = 0; i < this.jj_endpos; i++) {
/* 1125 */         this.jj_expentry[i] = this.jj_lasttokens[i];
/*      */       }
/* 1127 */       boolean exists = false;
/* 1128 */       for (Enumeration<int[]> enum_ = this.jj_expentries.elements(); enum_.hasMoreElements(); ) {
/* 1129 */         int[] oldentry = enum_.nextElement();
/* 1130 */         if (oldentry.length == this.jj_expentry.length) {
/* 1131 */           exists = true;
/* 1132 */           for (int j = 0; j < this.jj_expentry.length; j++) {
/* 1133 */             if (oldentry[j] != this.jj_expentry[j]) {
/* 1134 */               exists = false;
/*      */               break;
/*      */             } 
/*      */           } 
/* 1138 */           if (exists)
/*      */             break; 
/*      */         } 
/* 1141 */       }  if (!exists) this.jj_expentries.addElement(this.jj_expentry); 
/* 1142 */       if (pos != 0) this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind; 
/*      */     }  }
/*      */ 
/*      */   
/*      */   public final ParseException generateParseException() {
/* 1147 */     this.jj_expentries.removeAllElements();
/* 1148 */     boolean[] la1tokens = new boolean[54]; int i;
/* 1149 */     for (i = 0; i < 54; i++) {
/* 1150 */       la1tokens[i] = false;
/*      */     }
/* 1152 */     if (this.jj_kind >= 0) {
/* 1153 */       la1tokens[this.jj_kind] = true;
/* 1154 */       this.jj_kind = -1;
/*      */     } 
/* 1156 */     for (i = 0; i < 34; i++) {
/* 1157 */       if (this.jj_la1[i] == this.jj_gen) {
/* 1158 */         for (int k = 0; k < 32; k++) {
/* 1159 */           if ((this.jj_la1_0[i] & 1 << k) != 0) {
/* 1160 */             la1tokens[k] = true;
/*      */           }
/* 1162 */           if ((this.jj_la1_1[i] & 1 << k) != 0) {
/* 1163 */             la1tokens[32 + k] = true;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 1168 */     for (i = 0; i < 54; i++) {
/* 1169 */       if (la1tokens[i]) {
/* 1170 */         this.jj_expentry = new int[1];
/* 1171 */         this.jj_expentry[0] = i;
/* 1172 */         this.jj_expentries.addElement(this.jj_expentry);
/*      */       } 
/*      */     } 
/* 1175 */     this.jj_endpos = 0;
/* 1176 */     jj_rescan_token();
/* 1177 */     jj_add_error_token(0, 0);
/* 1178 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 1179 */     for (int j = 0; j < this.jj_expentries.size(); j++) {
/* 1180 */       exptokseq[j] = this.jj_expentries.elementAt(j);
/*      */     }
/* 1182 */     return new ParseException(this.token, exptokseq, tokenImage);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void enable_tracing() {}
/*      */ 
/*      */   
/*      */   public final void disable_tracing() {}
/*      */   
/*      */   private final void jj_rescan_token() {
/* 1192 */     this.jj_rescan = true;
/* 1193 */     for (int i = 0; i < 2; ) {
/* 1194 */       JJCalls p = this.jj_2_rtns[i];
/*      */       while (true)
/* 1196 */       { if (p.gen > this.jj_gen) {
/* 1197 */           this.jj_la = p.arg; this.jj_lastpos = this.jj_scanpos = p.first;
/* 1198 */           switch (i) { case 0:
/* 1199 */               jj_3_1(); break;
/* 1200 */             case 1: jj_3_2(); break; }
/*      */         
/*      */         } 
/* 1203 */         p = p.next;
/* 1204 */         if (p == null)
/*      */           i++;  } 
/* 1206 */     }  this.jj_rescan = false;
/*      */   }
/*      */   
/*      */   private final void jj_save(int index, int xla) {
/* 1210 */     JJCalls p = this.jj_2_rtns[index];
/* 1211 */     while (p.gen > this.jj_gen) {
/* 1212 */       if (p.next == null) { p = p.next = new JJCalls(); break; }
/* 1213 */        p = p.next;
/*      */     } 
/* 1215 */     p.gen = this.jj_gen + xla - this.jj_la; p.first = this.token; p.arg = xla;
/*      */   }
/*      */   
/*      */   static final class JJCalls {
/*      */     int gen;
/*      */     Token first;
/*      */     int arg;
/*      */     JJCalls next;
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\parser\ELParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */