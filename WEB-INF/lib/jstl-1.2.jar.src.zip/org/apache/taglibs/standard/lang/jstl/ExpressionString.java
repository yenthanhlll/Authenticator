/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionString
/*     */ {
/*     */   Object[] mElements;
/*     */   
/*     */   public Object[] getElements() {
/*  49 */     return this.mElements;
/*     */   } public void setElements(Object[] pElements) {
/*  51 */     this.mElements = pElements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionString(Object[] pElements) {
/*  60 */     this.mElements = pElements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/*  77 */     StringBuffer buf = new StringBuffer();
/*  78 */     for (int i = 0; i < this.mElements.length; i++) {
/*  79 */       Object elem = this.mElements[i];
/*  80 */       if (elem instanceof String) {
/*  81 */         buf.append((String)elem);
/*     */       }
/*  83 */       else if (elem instanceof Expression) {
/*  84 */         Object val = ((Expression)elem).evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  90 */         if (val != null) {
/*  91 */           buf.append(val.toString());
/*     */         }
/*     */       } 
/*     */     } 
/*  95 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 105 */     StringBuffer buf = new StringBuffer();
/* 106 */     for (int i = 0; i < this.mElements.length; i++) {
/* 107 */       Object elem = this.mElements[i];
/* 108 */       if (elem instanceof String) {
/* 109 */         buf.append((String)elem);
/*     */       }
/* 111 */       else if (elem instanceof Expression) {
/* 112 */         buf.append("${");
/* 113 */         buf.append(((Expression)elem).getExpressionString());
/* 114 */         buf.append("}");
/*     */       } 
/*     */     } 
/* 117 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ExpressionString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */