package org.apache.taglibs.standard.lang.support;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

public interface ExpressionEvaluator {
  String validate(String paramString1, String paramString2);
  
  Object evaluate(String paramString1, String paramString2, Class paramClass, Tag paramTag, PageContext paramPageContext) throws JspException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\support\ExpressionEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */