/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArraySuffix
/*     */   extends ValueSuffix
/*     */ {
/*  86 */   static Object[] sNoArgs = new Object[0];
/*     */ 
/*     */ 
/*     */   
/*     */   Expression mIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getIndex() {
/*  95 */     return this.mIndex;
/*     */   } public void setIndex(Expression pIndex) {
/*  97 */     this.mIndex = pIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArraySuffix(Expression pIndex) {
/* 106 */     this.mIndex = pIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object evaluateIndex(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 121 */     return this.mIndex.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getOperatorSymbol() {
/* 132 */     return "[]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 144 */     return "[" + this.mIndex.getExpressionString() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(Object pValue, Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 167 */     if (pValue == null) {
/* 168 */       if (pLogger.isLoggingWarning()) {
/* 169 */         pLogger.logWarning(Constants.CANT_GET_INDEXED_VALUE_OF_NULL, getOperatorSymbol());
/*     */       }
/*     */ 
/*     */       
/* 173 */       return null;
/*     */     } 
/*     */     
/*     */     Object indexVal;
/* 177 */     if ((indexVal = evaluateIndex(pContext, pResolver, functions, defaultPrefix, pLogger)) == null) {
/*     */ 
/*     */       
/* 180 */       if (pLogger.isLoggingWarning()) {
/* 181 */         pLogger.logWarning(Constants.CANT_GET_NULL_INDEX, getOperatorSymbol());
/*     */       }
/*     */ 
/*     */       
/* 185 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 189 */     if (pValue instanceof Map) {
/* 190 */       Map val = (Map)pValue;
/* 191 */       return val.get(indexVal);
/*     */     } 
/*     */ 
/*     */     
/* 195 */     if (pValue instanceof List || pValue.getClass().isArray()) {
/*     */       
/* 197 */       Integer indexObj = Coercions.coerceToInteger(indexVal, pLogger);
/* 198 */       if (indexObj == null) {
/* 199 */         if (pLogger.isLoggingError()) {
/* 200 */           pLogger.logError(Constants.BAD_INDEX_VALUE, getOperatorSymbol(), indexVal.getClass().getName());
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 205 */         return null;
/*     */       } 
/* 207 */       if (pValue instanceof List) {
/*     */         try {
/* 209 */           return ((List)pValue).get(indexObj.intValue());
/*     */         }
/* 211 */         catch (ArrayIndexOutOfBoundsException exc) {
/* 212 */           if (pLogger.isLoggingWarning()) {
/* 213 */             pLogger.logWarning(Constants.EXCEPTION_ACCESSING_LIST, exc, indexObj);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 218 */           return null;
/*     */         }
/* 220 */         catch (IndexOutOfBoundsException exc) {
/* 221 */           if (pLogger.isLoggingWarning()) {
/* 222 */             pLogger.logWarning(Constants.EXCEPTION_ACCESSING_LIST, exc, indexObj);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 227 */           return null;
/*     */         }
/* 229 */         catch (Exception exc) {
/* 230 */           if (pLogger.isLoggingError()) {
/* 231 */             pLogger.logError(Constants.EXCEPTION_ACCESSING_LIST, exc, indexObj);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 236 */           return null;
/*     */         } 
/*     */       }
/*     */       
/*     */       try {
/* 241 */         return Array.get(pValue, indexObj.intValue());
/*     */       }
/* 243 */       catch (ArrayIndexOutOfBoundsException exc) {
/* 244 */         if (pLogger.isLoggingWarning()) {
/* 245 */           pLogger.logWarning(Constants.EXCEPTION_ACCESSING_ARRAY, exc, indexObj);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 250 */         return null;
/*     */       }
/* 252 */       catch (IndexOutOfBoundsException exc) {
/* 253 */         if (pLogger.isLoggingWarning()) {
/* 254 */           pLogger.logWarning(Constants.EXCEPTION_ACCESSING_ARRAY, exc, indexObj);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 259 */         return null;
/*     */       }
/* 261 */       catch (Exception exc) {
/* 262 */         if (pLogger.isLoggingError()) {
/* 263 */           pLogger.logError(Constants.EXCEPTION_ACCESSING_ARRAY, exc, indexObj);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 268 */         return null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     String indexStr;
/*     */     
/* 275 */     if ((indexStr = Coercions.coerceToString(indexVal, pLogger)) == null)
/*     */     {
/* 277 */       return null;
/*     */     }
/*     */     
/*     */     BeanInfoProperty property;
/* 281 */     if ((property = BeanInfoManager.getBeanInfoProperty(pValue.getClass(), indexStr, pLogger)) != null && property.getReadMethod() != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/* 287 */         return property.getReadMethod().invoke(pValue, sNoArgs);
/*     */       }
/* 289 */       catch (InvocationTargetException exc) {
/* 290 */         if (pLogger.isLoggingError()) {
/* 291 */           pLogger.logError(Constants.ERROR_GETTING_PROPERTY, exc.getTargetException(), indexStr, pValue.getClass().getName());
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 297 */         return null;
/*     */       }
/* 299 */       catch (Exception exc) {
/* 300 */         if (pLogger.isLoggingError()) {
/* 301 */           pLogger.logError(Constants.ERROR_GETTING_PROPERTY, exc, indexStr, pValue.getClass().getName());
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 307 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 312 */     if (pLogger.isLoggingError()) {
/* 313 */       pLogger.logError(Constants.CANT_FIND_INDEX, indexVal, pValue.getClass().getName(), getOperatorSymbol());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ArraySuffix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */