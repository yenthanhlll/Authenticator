/*    */ package org.apache.taglibs.standard.lang.jstl.test;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bean2Editor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String pText) throws IllegalArgumentException {
/* 45 */     if ("badvalue".equals(pText)) {
/* 46 */       throw new IllegalArgumentException("Bad value " + pText);
/*    */     }
/*    */     
/* 49 */     setValue(new Bean2(pText));
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\Bean2Editor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */