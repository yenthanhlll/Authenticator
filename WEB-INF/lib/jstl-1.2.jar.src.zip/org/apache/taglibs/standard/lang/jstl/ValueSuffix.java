package org.apache.taglibs.standard.lang.jstl;

import java.util.Map;

public abstract class ValueSuffix {
  public abstract String getExpressionString();
  
  public abstract Object evaluate(Object paramObject1, Object paramObject2, VariableResolver paramVariableResolver, Map paramMap, String paramString, Logger paramLogger) throws ELException;
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ValueSuffix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */