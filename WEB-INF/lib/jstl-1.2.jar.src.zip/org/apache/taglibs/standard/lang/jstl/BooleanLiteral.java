/*    */ package org.apache.taglibs.standard.lang.jstl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanLiteral
/*    */   extends Literal
/*    */ {
/* 43 */   public static final BooleanLiteral TRUE = new BooleanLiteral("true");
/* 44 */   public static final BooleanLiteral FALSE = new BooleanLiteral("false");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BooleanLiteral(String pToken) {
/* 53 */     super(getValueFromToken(pToken));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Object getValueFromToken(String pToken) {
/* 63 */     return "true".equals(pToken) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getExpressionString() {
/* 78 */     return (getValue() == Boolean.TRUE) ? "true" : "false";
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\BooleanLiteral.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */