/*    */ package org.apache.taglibs.standard.lang.jstl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RelationalOperator
/*    */   extends BinaryOperator
/*    */ {
/*    */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/* 51 */     return Coercions.applyRelationalOperator(pLeft, pRight, this, pLogger);
/*    */   }
/*    */   
/*    */   public abstract boolean apply(double paramDouble1, double paramDouble2, Logger paramLogger);
/*    */   
/*    */   public abstract boolean apply(long paramLong1, long paramLong2, Logger paramLogger);
/*    */   
/*    */   public abstract boolean apply(String paramString1, String paramString2, Logger paramLogger);
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\RelationalOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */