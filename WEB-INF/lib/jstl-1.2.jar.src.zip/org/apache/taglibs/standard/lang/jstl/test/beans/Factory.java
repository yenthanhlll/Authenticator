/*    */ package org.apache.taglibs.standard.lang.jstl.test.beans;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Factory
/*    */ {
/*    */   public static PublicBean1 createBean1() {
/* 40 */     return new PublicBean1();
/*    */   }
/*    */ 
/*    */   
/*    */   public static PublicBean1 createBean2() {
/* 45 */     return new PrivateBean1a();
/*    */   }
/*    */ 
/*    */   
/*    */   public static PublicBean1 createBean3() {
/* 50 */     return new PublicBean1b();
/*    */   }
/*    */ 
/*    */   
/*    */   public static PublicInterface2 createBean4() {
/* 55 */     return new PublicBean2a();
/*    */   }
/*    */ 
/*    */   
/*    */   public static PublicInterface2 createBean5() {
/* 60 */     return new PrivateBean2b();
/*    */   }
/*    */ 
/*    */   
/*    */   public static PublicInterface2 createBean6() {
/* 65 */     return new PrivateBean2c();
/*    */   }
/*    */ 
/*    */   
/*    */   public static PublicInterface2 createBean7() {
/* 70 */     return new PrivateBean2d();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\Factory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */