package org.apache.taglibs.standard.lang.jstl.test.beans;

class PrivateBean2c extends PublicBean2a {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PrivateBean2c.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */