/*    */ package org.apache.taglibs.standard.lang.jstl;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanInfoProperty
/*    */ {
/*    */   Method mReadMethod;
/*    */   Method mWriteMethod;
/*    */   PropertyDescriptor mPropertyDescriptor;
/*    */   
/*    */   public Method getReadMethod() {
/* 55 */     return this.mReadMethod;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Method getWriteMethod() {
/* 62 */     return this.mWriteMethod;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PropertyDescriptor getPropertyDescriptor() {
/* 69 */     return this.mPropertyDescriptor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BeanInfoProperty(Method pReadMethod, Method pWriteMethod, PropertyDescriptor pPropertyDescriptor) {
/* 80 */     this.mReadMethod = pReadMethod;
/* 81 */     this.mWriteMethod = pWriteMethod;
/* 82 */     this.mPropertyDescriptor = pPropertyDescriptor;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\BeanInfoProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */