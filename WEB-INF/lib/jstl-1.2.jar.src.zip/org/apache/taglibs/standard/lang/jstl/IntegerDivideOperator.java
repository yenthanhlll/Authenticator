/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerDivideOperator
/*     */   extends BinaryOperator
/*     */ {
/*  43 */   public static final IntegerDivideOperator SINGLETON = new IntegerDivideOperator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperatorSymbol() {
/*  64 */     return "idiv";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/*  78 */     if (pLeft == null && pRight == null) {
/*     */       
/*  80 */       if (pLogger.isLoggingWarning()) {
/*  81 */         pLogger.logWarning(Constants.ARITH_OP_NULL, getOperatorSymbol());
/*     */       }
/*     */ 
/*     */       
/*  85 */       return PrimitiveObjects.getInteger(0);
/*     */     } 
/*     */     
/*  88 */     long left = Coercions.coerceToPrimitiveNumber(pLeft, Long.class, pLogger).longValue();
/*     */ 
/*     */     
/*  91 */     long right = Coercions.coerceToPrimitiveNumber(pRight, Long.class, pLogger).longValue();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  96 */       return PrimitiveObjects.getLong(left / right);
/*     */     }
/*  98 */     catch (Exception exc) {
/*  99 */       if (pLogger.isLoggingError()) {
/* 100 */         pLogger.logError(Constants.ARITH_ERROR, getOperatorSymbol(), "" + left, "" + right);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       return PrimitiveObjects.getInteger(0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\IntegerDivideOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */