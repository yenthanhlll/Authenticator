/*     */ package org.apache.taglibs.standard.tlv;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JstlFmtTLV
/*     */   extends JstlBaseTLV
/*     */ {
/*  82 */   private final String SETLOCALE = "setLocale";
/*  83 */   private final String SETBUNDLE = "setBundle";
/*  84 */   private final String SETTIMEZONE = "setTimeZone";
/*  85 */   private final String BUNDLE = "bundle";
/*  86 */   private final String MESSAGE = "message";
/*  87 */   private final String MESSAGE_PARAM = "param";
/*  88 */   private final String FORMAT_NUMBER = "formatNumber";
/*  89 */   private final String PARSE_NUMBER = "parseNumber";
/*  90 */   private final String PARSE_DATE = "parseDate";
/*     */   
/*  92 */   private final String JSP_TEXT = "jsp:text";
/*     */ 
/*     */   
/*  95 */   private final String EVAL = "evaluator";
/*  96 */   private final String MESSAGE_KEY = "key";
/*  97 */   private final String BUNDLE_PREFIX = "prefix";
/*  98 */   private final String VALUE = "value";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationMessage[] validate(String prefix, String uri, PageData page) {
/* 105 */     return validate(2, prefix, uri, page);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultHandler getHandler() {
/* 113 */     return new Handler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Handler
/*     */     extends DefaultHandler
/*     */   {
/* 124 */     private int depth = 0;
/* 125 */     private Stack messageDepths = new Stack();
/* 126 */     private String lastElementName = null;
/*     */ 
/*     */     
/*     */     private boolean bodyNecessary = false;
/*     */     
/*     */     private boolean bodyIllegal = false;
/*     */ 
/*     */     
/*     */     public void startElement(String ns, String ln, String qn, Attributes a) {
/* 135 */       if (ln == null) {
/* 136 */         ln = JstlFmtTLV.this.getLocalPart(qn);
/*     */       }
/*     */ 
/*     */       
/* 140 */       if (qn.equals("jsp:text")) {
/*     */         return;
/*     */       }
/*     */       
/* 144 */       if (this.bodyIllegal) {
/* 145 */         JstlFmtTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */       
/*     */       Set expAtts;
/*     */       
/* 150 */       if (qn.startsWith(JstlFmtTLV.this.prefix + ":") && (expAtts = (Set)JstlFmtTLV.this.config.get(ln)) != null)
/*     */       {
/* 152 */         for (int i = 0; i < a.getLength(); i++) {
/* 153 */           String attName = a.getLocalName(i);
/* 154 */           if (expAtts.contains(attName)) {
/* 155 */             String vMsg = JstlFmtTLV.this.validateExpression(ln, attName, a.getValue(i));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 160 */             if (vMsg != null) {
/* 161 */               JstlFmtTLV.this.fail(vMsg);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 167 */       if (qn.startsWith(JstlFmtTLV.this.prefix + ":") && !JstlFmtTLV.this.hasNoInvalidScope(a)) {
/* 168 */         JstlFmtTLV.this.fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
/*     */       }
/* 170 */       if (qn.startsWith(JstlFmtTLV.this.prefix + ":") && JstlFmtTLV.this.hasEmptyVar(a))
/* 171 */         JstlFmtTLV.this.fail(Resources.getMessage("TLV_EMPTY_VAR", qn)); 
/* 172 */       if (qn.startsWith(JstlFmtTLV.this.prefix + ":") && !JstlFmtTLV.this.isFmtTag(ns, ln, "setLocale") && !JstlFmtTLV.this.isFmtTag(ns, ln, "setBundle") && !JstlFmtTLV.this.isFmtTag(ns, ln, "setTimeZone") && JstlFmtTLV.this.hasDanglingScope(a))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 177 */         JstlFmtTLV.this.fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       if (JstlFmtTLV.this.isFmtTag(ns, ln, "param") && this.messageDepths.empty()) {
/* 191 */         JstlFmtTLV.this.fail(Resources.getMessage("PARAM_OUTSIDE_MESSAGE"));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       if (JstlFmtTLV.this.isFmtTag(ns, ln, "message")) {
/* 198 */         this.messageDepths.push(new Integer(this.depth));
/*     */       }
/*     */ 
/*     */       
/* 202 */       this.bodyIllegal = false;
/* 203 */       this.bodyNecessary = false;
/* 204 */       if (JstlFmtTLV.this.isFmtTag(ns, ln, "param") || JstlFmtTLV.this.isFmtTag(ns, ln, "formatNumber") || JstlFmtTLV.this.isFmtTag(ns, ln, "parseNumber") || JstlFmtTLV.this.isFmtTag(ns, ln, "parseDate")) {
/*     */ 
/*     */ 
/*     */         
/* 208 */         if (JstlFmtTLV.this.hasAttribute(a, "value"))
/* 209 */         { this.bodyIllegal = true; }
/*     */         else
/* 211 */         { this.bodyNecessary = true; } 
/* 212 */       } else if (JstlFmtTLV.this.isFmtTag(ns, ln, "message") && !JstlFmtTLV.this.hasAttribute(a, "key")) {
/*     */         
/* 214 */         this.bodyNecessary = true;
/* 215 */       } else if (JstlFmtTLV.this.isFmtTag(ns, ln, "bundle") && JstlFmtTLV.this.hasAttribute(a, "prefix")) {
/*     */         
/* 217 */         this.bodyNecessary = true;
/*     */       } 
/*     */ 
/*     */       
/* 221 */       this.lastElementName = qn;
/* 222 */       JstlFmtTLV.this.lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
/*     */ 
/*     */       
/* 225 */       this.depth++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void characters(char[] ch, int start, int length) {
/* 230 */       this.bodyNecessary = false;
/*     */ 
/*     */       
/* 233 */       String s = (new String(ch, start, length)).trim();
/* 234 */       if (s.equals("")) {
/*     */         return;
/*     */       }
/*     */       
/* 238 */       if (this.bodyIllegal) {
/* 239 */         JstlFmtTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void endElement(String ns, String ln, String qn) {
/* 246 */       if (qn.equals("jsp:text")) {
/*     */         return;
/*     */       }
/*     */       
/* 250 */       if (this.bodyNecessary) {
/* 251 */         JstlFmtTLV.this.fail(Resources.getMessage("TLV_MISSING_BODY", this.lastElementName));
/*     */       }
/* 253 */       this.bodyIllegal = false;
/*     */ 
/*     */       
/* 256 */       if (JstlFmtTLV.this.isFmtTag(ns, ln, "message")) {
/* 257 */         this.messageDepths.pop();
/*     */       }
/*     */ 
/*     */       
/* 261 */       this.depth--;
/*     */     }
/*     */     
/*     */     private Handler() {}
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tlv\JstlFmtTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */