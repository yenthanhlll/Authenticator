/*    */ package org.apache.taglibs.standard.tag.rt.sql;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import org.apache.taglibs.standard.tag.common.sql.TransactionTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionTag
/*    */   extends TransactionTagSupport
/*    */ {
/*    */   private String isolationRT;
/*    */   
/*    */   public void setDataSource(Object dataSource) {
/* 48 */     this.rawDataSource = dataSource;
/* 49 */     this.dataSourceSpecified = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIsolation(String isolation) {
/* 56 */     this.isolationRT = isolation;
/*    */   }
/*    */   
/*    */   public int doStartTag() throws JspException {
/* 60 */     if (this.isolationRT != null)
/* 61 */       super.setIsolation(this.isolationRT); 
/* 62 */     return super.doStartTag();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\sql\TransactionTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */