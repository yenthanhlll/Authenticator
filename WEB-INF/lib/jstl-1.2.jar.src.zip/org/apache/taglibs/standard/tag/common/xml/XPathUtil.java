/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import javax.xml.xpath.XPathFactory;
/*     */ import javax.xml.xpath.XPathFactoryConfigurationException;
/*     */ import javax.xml.xpath.XPathVariableResolver;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathUtil
/*     */ {
/*     */   private static final String PAGE_NS_URL = "http://java.sun.com/jstl/xpath/page";
/*     */   private static final String REQUEST_NS_URL = "http://java.sun.com/jstl/xpath/request";
/*     */   private static final String SESSION_NS_URL = "http://java.sun.com/jstl/xpath/session";
/*     */   private static final String APP_NS_URL = "http://java.sun.com/jstl/xpath/app";
/*     */   private static final String PARAM_NS_URL = "http://java.sun.com/jstl/xpath/param";
/*     */   private static final String INITPARAM_NS_URL = "http://java.sun.com/jstl/xpath/initParam";
/*     */   private static final String COOKIE_NS_URL = "http://java.sun.com/jstl/xpath/cookie";
/*     */   private static final String HEADER_NS_URL = "http://java.sun.com/jstl/xpath/header";
/*     */   private PageContext pageContext;
/*     */   private static HashMap exprCache;
/*     */   private static JSTLXPathNamespaceContext jstlXPathNamespaceContext = null;
/*     */   private static final String XPATH_FACTORY_CLASS_NAME = "org.apache.taglibs.standard.tag.common.xml.JSTLXPathFactory";
/*     */   private static XPathFactory XPATH_FACTORY;
/*     */   
/*     */   static {
/*     */     if (System.getSecurityManager() != null) {
/*     */       AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run() {
/*     */               System.setProperty("javax.xml.xpath.XPathFactory:http://java.sun.com/jaxp/xpath/dom", "org.apache.taglibs.standard.tag.common.xml.JSTLXPathFactory");
/*     */               return null;
/*     */             }
/*     */           });
/*     */     } else {
/*     */       System.setProperty("javax.xml.xpath.XPathFactory:http://java.sun.com/jaxp/xpath/dom", "org.apache.taglibs.standard.tag.common.xml.JSTLXPathFactory");
/*     */     } 
/*     */     try {
/*     */       XPATH_FACTORY = XPathFactory.newInstance("http://java.sun.com/jaxp/xpath/dom");
/*     */     } catch (XPathFactoryConfigurationException xpce) {
/*     */       xpce.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public XPathUtil(PageContext pc) {
/* 198 */     this.modifiedXPath = null;
/*     */     this.pageContext = pc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String valueOf(Node n, String xpathString) throws JspTagException {
/* 205 */     staticInit();
/* 206 */     XPathVariableResolver jxvr = new JSTLXPathVariableResolver(this.pageContext);
/* 207 */     Node contextNode = adaptParamsForXalan(n, xpathString.trim(), jxvr);
/*     */     
/* 209 */     XPath xpath = XPATH_FACTORY.newXPath();
/* 210 */     xpath.setNamespaceContext(jstlXPathNamespaceContext);
/* 211 */     xpath.setXPathVariableResolver(jxvr);
/*     */     try {
/* 213 */       return xpath.evaluate(xpathString, contextNode);
/* 214 */     } catch (XPathExpressionException ex) {
/* 215 */       throw new JspTagException(ex.toString(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean booleanValueOf(Node n, String xpathString) throws JspTagException {
/* 226 */     staticInit();
/* 227 */     XPathVariableResolver jxvr = new JSTLXPathVariableResolver(this.pageContext);
/* 228 */     Node contextNode = adaptParamsForXalan(n, xpathString.trim(), jxvr);
/* 229 */     xpathString = this.modifiedXPath;
/*     */     
/* 231 */     XPath xpath = XPATH_FACTORY.newXPath();
/* 232 */     xpath.setNamespaceContext(jstlXPathNamespaceContext);
/* 233 */     xpath.setXPathVariableResolver(jxvr);
/*     */     try {
/* 235 */       return ((Boolean)xpath.evaluate(xpathString, contextNode, XPathConstants.BOOLEAN)).booleanValue();
/*     */     }
/* 237 */     catch (XPathExpressionException ex) {
/* 238 */       throw new JspTagException(Resources.getMessage("XPATH_ERROR_XOBJECT", ex.toString()), ex);
/*     */     } 
/*     */   } private static synchronized void staticInit() { if (jstlXPathNamespaceContext == null) {
/*     */       jstlXPathNamespaceContext = new JSTLXPathNamespaceContext(); jstlXPathNamespaceContext.addNamespace("pageScope", "http://java.sun.com/jstl/xpath/page"); jstlXPathNamespaceContext.addNamespace("requestScope", "http://java.sun.com/jstl/xpath/request");
/*     */       jstlXPathNamespaceContext.addNamespace("sessionScope", "http://java.sun.com/jstl/xpath/session");
/*     */       jstlXPathNamespaceContext.addNamespace("applicationScope", "http://java.sun.com/jstl/xpath/app");
/*     */       jstlXPathNamespaceContext.addNamespace("param", "http://java.sun.com/jstl/xpath/param");
/*     */       jstlXPathNamespaceContext.addNamespace("initParam", "http://java.sun.com/jstl/xpath/initParam");
/*     */       jstlXPathNamespaceContext.addNamespace("header", "http://java.sun.com/jstl/xpath/header");
/*     */       jstlXPathNamespaceContext.addNamespace("cookie", "http://java.sun.com/jstl/xpath/cookie");
/*     */       exprCache = new HashMap<Object, Object>();
/* 249 */     }  } static DocumentBuilderFactory dbf = null; static DocumentBuilder db = null; static Document d = null; String modifiedXPath; public List selectNodes(Node n, String xpathString) throws JspTagException { staticInit();
/* 250 */     XPathVariableResolver jxvr = new JSTLXPathVariableResolver(this.pageContext);
/* 251 */     Node contextNode = adaptParamsForXalan(n, xpathString.trim(), jxvr);
/* 252 */     xpathString = this.modifiedXPath;
/*     */     
/*     */     try {
/* 255 */       XPath xpath = XPATH_FACTORY.newXPath();
/* 256 */       xpath.setNamespaceContext(jstlXPathNamespaceContext);
/* 257 */       xpath.setXPathVariableResolver(jxvr);
/* 258 */       Object nl = xpath.evaluate(xpathString, contextNode, JSTLXPathConstants.OBJECT);
/*     */       
/* 260 */       return new JSTLNodeList(nl);
/* 261 */     } catch (XPathExpressionException ex) {
/* 262 */       throw new JspTagException(ex.toString(), ex);
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node selectSingleNode(Node n, String xpathString) throws JspTagException {
/* 274 */     staticInit();
/* 275 */     XPathVariableResolver jxvr = new JSTLXPathVariableResolver(this.pageContext);
/* 276 */     Node contextNode = adaptParamsForXalan(n, xpathString.trim(), jxvr);
/* 277 */     xpathString = this.modifiedXPath;
/*     */     
/*     */     try {
/* 280 */       XPath xpath = XPATH_FACTORY.newXPath();
/* 281 */       xpath.setNamespaceContext(jstlXPathNamespaceContext);
/* 282 */       xpath.setXPathVariableResolver(jxvr);
/* 283 */       return (Node)xpath.evaluate(xpathString, contextNode, XPathConstants.NODE);
/*     */     }
/* 285 */     catch (XPathExpressionException ex) {
/* 286 */       throw new JspTagException(ex.toString(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Document getDummyDocument() {
/*     */     try {
/*     */       if (dbf == null) {
/*     */         dbf = DocumentBuilderFactory.newInstance();
/*     */         dbf.setNamespaceAware(true);
/*     */         dbf.setValidating(false);
/*     */       } 
/*     */       db = dbf.newDocumentBuilder();
/*     */       DOMImplementation dim = db.getDOMImplementation();
/*     */       d = dim.createDocument("http://java.sun.com/jstl", "dummyroot", null);
/*     */       return d;
/*     */     } catch (Exception e) {
/*     */       e.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Document getDummyDocumentWithoutRoot() {
/*     */     try {
/*     */       if (dbf == null) {
/*     */         dbf = DocumentBuilderFactory.newInstance();
/*     */         dbf.setNamespaceAware(true);
/*     */         dbf.setValidating(false);
/*     */       } 
/*     */       db = dbf.newDocumentBuilder();
/*     */       d = db.newDocument();
/*     */       return d;
/*     */     } catch (Exception e) {
/*     */       e.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node adaptParamsForXalan(Node n, String xpath, XPathVariableResolver jxvr) {
/* 331 */     Node boundDocument = null;
/*     */     
/* 333 */     this.modifiedXPath = xpath;
/* 334 */     String origXPath = xpath;
/* 335 */     boolean whetherOrigXPath = true;
/*     */ 
/*     */     
/* 338 */     if (n != null) {
/* 339 */       return n;
/*     */     }
/*     */     
/* 342 */     if (xpath.startsWith("$")) {
/*     */ 
/*     */       
/* 345 */       String varQName = xpath.substring(xpath.indexOf("$") + 1);
/* 346 */       if (varQName.indexOf("/") > 0) {
/* 347 */         varQName = varQName.substring(0, varQName.indexOf("/"));
/*     */       }
/* 349 */       String varPrefix = null;
/* 350 */       String varLocalName = varQName;
/* 351 */       if (varQName.indexOf(":") >= 0) {
/* 352 */         varPrefix = varQName.substring(0, varQName.indexOf(":"));
/* 353 */         varLocalName = varQName.substring(varQName.indexOf(":") + 1);
/*     */       } 
/*     */       
/* 356 */       if (xpath.indexOf("/") > 0) {
/* 357 */         xpath = xpath.substring(xpath.indexOf("/"));
/*     */       } else {
/* 359 */         xpath = "/*";
/* 360 */         whetherOrigXPath = false;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 365 */         Object varObject = ((JSTLXPathVariableResolver)jxvr).getVariableValue("", varPrefix, varLocalName);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 370 */         if (Class.forName("org.w3c.dom.Document").isInstance(varObject)) {
/*     */ 
/*     */           
/* 373 */           boundDocument = (Document)varObject;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 379 */         else if (Class.forName("org.apache.taglibs.standard.tag.common.xml.JSTLNodeList").isInstance(varObject)) {
/* 380 */           Document newDocument = getDummyDocument();
/*     */           
/* 382 */           JSTLNodeList jstlNodeList = (JSTLNodeList)varObject;
/* 383 */           if (jstlNodeList.getLength() == 1) {
/* 384 */             if (Class.forName("org.w3c.dom.Node").isInstance(jstlNodeList.elementAt(0)))
/*     */             {
/* 386 */               Node node = (Node)jstlNodeList.elementAt(0);
/* 387 */               Document doc = getDummyDocumentWithoutRoot();
/* 388 */               Node importedNode = doc.importNode(node, true);
/* 389 */               doc.appendChild(importedNode);
/* 390 */               boundDocument = doc;
/* 391 */               if (whetherOrigXPath) {
/* 392 */                 xpath = "/*" + xpath;
/*     */               
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 398 */               Object myObject = jstlNodeList.elementAt(0);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 403 */               xpath = myObject.toString();
/*     */ 
/*     */               
/* 406 */               boundDocument = newDocument;
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 411 */             Element dummyroot = newDocument.getDocumentElement();
/* 412 */             for (int i = 0; i < jstlNodeList.getLength(); i++) {
/* 413 */               Node currNode = jstlNodeList.item(i);
/*     */               
/* 415 */               Node importedNode = newDocument.importNode(currNode, true);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 420 */               dummyroot.appendChild(importedNode);
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 425 */             boundDocument = newDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 431 */             xpath = "/*" + xpath;
/*     */           } 
/* 433 */         } else if (Class.forName("org.w3c.dom.Node").isInstance(varObject)) {
/*     */           
/* 435 */           boundDocument = (Node)varObject;
/*     */         } else {
/* 437 */           boundDocument = getDummyDocument();
/* 438 */           xpath = origXPath;
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 443 */       catch (UnresolvableException ue) {
/*     */ 
/*     */         
/* 446 */         ue.printStackTrace();
/* 447 */       } catch (ClassNotFoundException cnf) {}
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 453 */       boundDocument = getDummyDocument();
/*     */     } 
/*     */     
/* 456 */     this.modifiedXPath = xpath;
/*     */ 
/*     */ 
/*     */     
/* 460 */     return boundDocument;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Node getContext(Tag t) throws JspTagException {
/* 472 */     ForEachTag xt = (ForEachTag)TagSupport.findAncestorWithClass(t, ForEachTag.class);
/*     */ 
/*     */     
/* 475 */     if (xt == null) {
/* 476 */       return null;
/*     */     }
/* 478 */     return xt.getContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void p(String s) {
/* 485 */     System.out.println("[XPathUtil] " + s);
/*     */   }
/*     */   
/*     */   public static void printDetails(Node n) {
/* 489 */     p("\n\nDetails of Node = > " + n);
/* 490 */     p("Name:Type:Node Value = > " + n.getNodeName() + ":" + n.getNodeType() + ":" + n.getNodeValue());
/*     */     
/* 492 */     p("Namespace URI : Prefix : localName = > " + n.getNamespaceURI() + ":" + n.getPrefix() + ":" + n.getLocalName());
/*     */     
/* 494 */     p("\n Node has children => " + n.hasChildNodes());
/* 495 */     if (n.hasChildNodes()) {
/* 496 */       NodeList nl = n.getChildNodes();
/* 497 */       p("Number of Children => " + nl.getLength());
/* 498 */       for (int i = 0; i < nl.getLength(); i++) {
/* 499 */         Node childNode = nl.item(i);
/* 500 */         printDetails(childNode);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\XPathUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */