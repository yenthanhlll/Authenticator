/*    */ package org.apache.taglibs.standard.tag.rt.xml;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.xml.ExprSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExprTag
/*    */   extends ExprSupport
/*    */ {
/*    */   public void setEscapeXml(boolean escapeXml) {
/* 44 */     this.escapeXml = escapeXml;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\xml\ExprTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */