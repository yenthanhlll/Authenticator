/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.ParseNumberSupport;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseNumberTag
/*    */   extends ParseNumberSupport
/*    */ {
/*    */   public void setValue(String value) throws JspTagException {
/* 49 */     this.value = value;
/* 50 */     this.valueSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(String type) throws JspTagException {
/* 55 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPattern(String pattern) throws JspTagException {
/* 60 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setParseLocale(Object loc) throws JspTagException {
/* 65 */     if (loc != null) {
/* 66 */       if (loc instanceof Locale) {
/* 67 */         this.parseLocale = (Locale)loc;
/*    */       }
/* 69 */       else if (!"".equals(loc)) {
/* 70 */         this.parseLocale = SetLocaleSupport.parseLocale((String)loc);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIntegerOnly(boolean isIntegerOnly) throws JspTagException {
/* 79 */     this.isIntegerOnly = isIntegerOnly;
/* 80 */     this.integerOnlySpecified = true;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\ParseNumberTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */