/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetDataSourceTagSupport
/*     */   extends TagSupport
/*     */ {
/*     */   protected Object dataSource;
/*     */   protected boolean dataSourceSpecified;
/*     */   protected String jdbcURL;
/*     */   protected String driverClassName;
/*     */   protected String userName;
/*     */   protected String password;
/*     */   private int scope;
/*     */   private String var;
/*     */   
/*     */   public SetDataSourceTagSupport() {
/*  64 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  68 */     this.dataSource = null;
/*  69 */     this.dataSourceSpecified = false;
/*  70 */     this.jdbcURL = this.driverClassName = this.userName = this.password = null;
/*  71 */     this.var = null;
/*  72 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/*  85 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */   
/*     */   public void setVar(String var) {
/*  89 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*     */     DataSource ds;
/*  99 */     if (this.dataSource != null) {
/* 100 */       ds = DataSourceUtil.getDataSource(this.dataSource, this.pageContext);
/*     */     } else {
/* 102 */       if (this.dataSourceSpecified) {
/* 103 */         throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
/*     */       }
/*     */ 
/*     */       
/* 107 */       DataSourceWrapper dsw = new DataSourceWrapper();
/*     */       
/*     */       try {
/* 110 */         if (this.driverClassName != null) {
/* 111 */           dsw.setDriverClassName(this.driverClassName);
/*     */         }
/*     */       }
/* 114 */       catch (Exception e) {
/* 115 */         throw new JspTagException(Resources.getMessage("DRIVER_INVALID_CLASS", e.toString()), e);
/*     */       } 
/*     */ 
/*     */       
/* 119 */       dsw.setJdbcURL(this.jdbcURL);
/* 120 */       dsw.setUserName(this.userName);
/* 121 */       dsw.setPassword(this.password);
/* 122 */       ds = dsw;
/*     */     } 
/*     */     
/* 125 */     if (this.var != null) {
/* 126 */       this.pageContext.setAttribute(this.var, ds, this.scope);
/*     */     } else {
/* 128 */       Config.set(this.pageContext, "javax.servlet.jsp.jstl.sql.dataSource", ds, this.scope);
/*     */     } 
/*     */     
/* 131 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 136 */     init();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\SetDataSourceTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */