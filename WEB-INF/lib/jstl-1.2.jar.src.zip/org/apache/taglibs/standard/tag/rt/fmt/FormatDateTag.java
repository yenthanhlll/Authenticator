/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.FormatDateSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatDateTag
/*    */   extends FormatDateSupport
/*    */ {
/*    */   public void setValue(Date value) throws JspTagException {
/* 48 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(String type) throws JspTagException {
/* 53 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDateStyle(String dateStyle) throws JspTagException {
/* 58 */     this.dateStyle = dateStyle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTimeStyle(String timeStyle) throws JspTagException {
/* 63 */     this.timeStyle = timeStyle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPattern(String pattern) throws JspTagException {
/* 68 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTimeZone(Object timeZone) throws JspTagException {
/* 73 */     this.timeZone = timeZone;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\FormatDateTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */