/*    */ package org.apache.taglibs.standard.tag.common.core;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CatchTag
/*    */   extends TagSupport
/*    */   implements TryCatchFinally
/*    */ {
/*    */   private String var;
/*    */   private boolean caught;
/*    */   
/*    */   public CatchTag() {
/* 54 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 59 */     super.release();
/* 60 */     init();
/*    */   }
/*    */   
/*    */   private void init() {
/* 64 */     this.var = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int doStartTag() {
/* 79 */     this.caught = false;
/* 80 */     return 1;
/*    */   }
/*    */   
/*    */   public void doCatch(Throwable t) {
/* 84 */     if (this.var != null)
/* 85 */       this.pageContext.setAttribute(this.var, t, 1); 
/* 86 */     this.caught = true;
/*    */   }
/*    */   
/*    */   public void doFinally() {
/* 90 */     if (this.var != null && !this.caught) {
/* 91 */       this.pageContext.removeAttribute(this.var, 1);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setVar(String var) {
/* 99 */     this.var = var;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\CatchTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */