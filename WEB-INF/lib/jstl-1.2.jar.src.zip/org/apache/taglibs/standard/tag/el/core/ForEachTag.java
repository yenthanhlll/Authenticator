/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.jstl.core.LoopTag;
/*     */ import javax.servlet.jsp.tagext.IterationTag;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.core.ForEachSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForEachTag
/*     */   extends ForEachSupport
/*     */   implements LoopTag, IterationTag
/*     */ {
/*     */   private String begin_;
/*     */   private String end_;
/*     */   private String step_;
/*     */   private String items_;
/*     */   
/*     */   public ForEachTag() {
/*  64 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  75 */     evaluateExpressions();
/*     */ 
/*     */     
/*  78 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  84 */     super.release();
/*  85 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBegin(String begin_) {
/*  94 */     this.begin_ = begin_;
/*  95 */     this.beginSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnd(String end_) {
/* 100 */     this.end_ = end_;
/* 101 */     this.endSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStep(String step_) {
/* 106 */     this.step_ = step_;
/* 107 */     this.stepSpecified = true;
/*     */   }
/*     */   
/*     */   public void setItems(String items_) {
/* 111 */     this.items_ = items_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 120 */     this.begin_ = null;
/* 121 */     this.end_ = null;
/* 122 */     this.step_ = null;
/* 123 */     this.items_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 136 */     if (this.begin_ != null) {
/* 137 */       Object r = ExpressionEvaluatorManager.evaluate("begin", this.begin_, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 139 */       if (r == null)
/* 140 */         throw new NullAttributeException("forEach", "begin"); 
/* 141 */       this.begin = ((Integer)r).intValue();
/* 142 */       validateBegin();
/*     */     } 
/*     */     
/* 145 */     if (this.end_ != null) {
/* 146 */       Object r = ExpressionEvaluatorManager.evaluate("end", this.end_, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 148 */       if (r == null)
/* 149 */         throw new NullAttributeException("forEach", "end"); 
/* 150 */       this.end = ((Integer)r).intValue();
/* 151 */       validateEnd();
/*     */     } 
/*     */     
/* 154 */     if (this.step_ != null) {
/* 155 */       Object r = ExpressionEvaluatorManager.evaluate("step", this.step_, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 157 */       if (r == null)
/* 158 */         throw new NullAttributeException("forEach", "step"); 
/* 159 */       this.step = ((Integer)r).intValue();
/* 160 */       validateStep();
/*     */     } 
/*     */     
/* 163 */     if (this.items_ != null) {
/* 164 */       this.rawItems = ExpressionEvaluatorManager.evaluate("items", this.items_, Object.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 167 */       if (this.rawItems == null)
/* 168 */         this.rawItems = new ArrayList(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\ForEachTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */