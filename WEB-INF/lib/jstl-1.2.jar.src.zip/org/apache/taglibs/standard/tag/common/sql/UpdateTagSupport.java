/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UpdateTagSupport
/*     */   extends BodyTagSupport
/*     */   implements TryCatchFinally, SQLExecutionTag
/*     */ {
/*     */   private String var;
/*     */   private int scope;
/*     */   protected Object rawDataSource;
/*     */   protected boolean dataSourceSpecified;
/*     */   protected String sql;
/*     */   private Connection conn;
/*     */   private List parameters;
/*     */   private boolean isPartOfTransaction;
/*     */   
/*     */   public UpdateTagSupport() {
/*  80 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  84 */     this.rawDataSource = null;
/*  85 */     this.sql = null;
/*  86 */     this.conn = null;
/*  87 */     this.parameters = null;
/*  88 */     this.isPartOfTransaction = this.dataSourceSpecified = false;
/*  89 */     this.scope = 1;
/*  90 */     this.var = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 102 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scopeName) {
/* 110 */     this.scope = Util.getScope(scopeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*     */     try {
/* 124 */       this.conn = getConnection();
/* 125 */     } catch (SQLException e) {
/* 126 */       throw new JspException(this.sql + ": " + e.getMessage(), e);
/*     */     } 
/*     */     
/* 129 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 150 */     String sqlStatement = null;
/* 151 */     if (this.sql != null) {
/* 152 */       sqlStatement = this.sql;
/*     */     }
/* 154 */     else if (this.bodyContent != null) {
/* 155 */       sqlStatement = this.bodyContent.getString();
/*     */     } 
/* 157 */     if (sqlStatement == null || sqlStatement.trim().length() == 0) {
/* 158 */       throw new JspTagException(Resources.getMessage("SQL_NO_STATEMENT"));
/*     */     }
/*     */ 
/*     */     
/* 162 */     int result = 0;
/*     */     try {
/* 164 */       PreparedStatement ps = this.conn.prepareStatement(sqlStatement);
/* 165 */       setParameters(ps, this.parameters);
/* 166 */       result = ps.executeUpdate();
/*     */     }
/* 168 */     catch (Throwable e) {
/* 169 */       throw new JspException(sqlStatement + ": " + e.getMessage(), e);
/*     */     } 
/* 171 */     if (this.var != null)
/* 172 */       this.pageContext.setAttribute(this.var, new Integer(result), this.scope); 
/* 173 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCatch(Throwable t) throws Throwable {
/* 180 */     throw t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFinally() {
/* 188 */     if (this.conn != null && !this.isPartOfTransaction) {
/*     */       try {
/* 190 */         this.conn.close();
/* 191 */       } catch (SQLException e) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 196 */     this.parameters = null;
/* 197 */     this.conn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSQLParameter(Object o) {
/* 209 */     if (this.parameters == null) {
/* 210 */       this.parameters = new ArrayList();
/*     */     }
/* 212 */     this.parameters.add(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Connection getConnection() throws JspException, SQLException {
/* 221 */     Connection conn = null;
/* 222 */     this.isPartOfTransaction = false;
/*     */     
/* 224 */     TransactionTagSupport parent = (TransactionTagSupport)findAncestorWithClass((Tag)this, TransactionTagSupport.class);
/*     */     
/* 226 */     if (parent != null) {
/* 227 */       if (this.dataSourceSpecified) {
/* 228 */         throw new JspTagException(Resources.getMessage("ERROR_NESTED_DATASOURCE"));
/*     */       }
/*     */       
/* 231 */       conn = parent.getSharedConnection();
/* 232 */       this.isPartOfTransaction = true;
/*     */     } else {
/* 234 */       if (this.rawDataSource == null && this.dataSourceSpecified) {
/* 235 */         throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
/*     */       }
/*     */       
/* 238 */       DataSource dataSource = DataSourceUtil.getDataSource(this.rawDataSource, this.pageContext);
/*     */       
/*     */       try {
/* 241 */         conn = dataSource.getConnection();
/* 242 */       } catch (Exception ex) {
/* 243 */         throw new JspException(Resources.getMessage("DATASOURCE_INVALID", ex.toString()));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 249 */     return conn;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setParameters(PreparedStatement ps, List parameters) throws SQLException {
/* 255 */     if (parameters != null)
/* 256 */       for (int i = 0; i < parameters.size(); i++)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 262 */         ps.setObject(i + 1, parameters.get(i));
/*     */       } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\UpdateTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */