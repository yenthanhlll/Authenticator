/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FormatDateSupport
/*     */   extends TagSupport
/*     */ {
/*     */   private static final String DATE = "date";
/*     */   private static final String TIME = "time";
/*     */   private static final String DATETIME = "both";
/*     */   protected Date value;
/*     */   protected String type;
/*     */   protected String pattern;
/*     */   protected Object timeZone;
/*     */   protected String dateStyle;
/*     */   protected String timeStyle;
/*     */   private String var;
/*     */   private int scope;
/*     */   
/*     */   public FormatDateSupport() {
/*  83 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  87 */     this.type = this.dateStyle = this.timeStyle = null;
/*  88 */     this.pattern = this.var = null;
/*  89 */     this.value = null;
/*  90 */     this.timeZone = null;
/*  91 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/*  99 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 103 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 115 */     String formatted = null;
/*     */     
/* 117 */     if (this.value == null) {
/* 118 */       if (this.var != null) {
/* 119 */         this.pageContext.removeAttribute(this.var, this.scope);
/*     */       }
/* 121 */       return 6;
/*     */     } 
/*     */ 
/*     */     
/* 125 */     Locale locale = SetLocaleSupport.getFormattingLocale(this.pageContext, (Tag)this, true, DateFormat.getAvailableLocales());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (locale != null) {
/* 132 */       DateFormat formatter = createFormatter(locale);
/*     */ 
/*     */       
/* 135 */       if (this.pattern != null) {
/*     */         try {
/* 137 */           ((SimpleDateFormat)formatter).applyPattern(this.pattern);
/* 138 */         } catch (ClassCastException cce) {
/* 139 */           formatter = new SimpleDateFormat(this.pattern, locale);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 144 */       TimeZone tz = null;
/* 145 */       if (this.timeZone instanceof String && ((String)this.timeZone).equals(""))
/*     */       {
/* 147 */         this.timeZone = null;
/*     */       }
/* 149 */       if (this.timeZone != null) {
/* 150 */         if (this.timeZone instanceof String) {
/* 151 */           tz = TimeZone.getTimeZone((String)this.timeZone);
/* 152 */         } else if (this.timeZone instanceof TimeZone) {
/* 153 */           tz = (TimeZone)this.timeZone;
/*     */         } else {
/* 155 */           throw new JspTagException(Resources.getMessage("FORMAT_DATE_BAD_TIMEZONE"));
/*     */         } 
/*     */       } else {
/*     */         
/* 159 */         tz = TimeZoneSupport.getTimeZone(this.pageContext, (Tag)this);
/*     */       } 
/* 161 */       if (tz != null) {
/* 162 */         formatter.setTimeZone(tz);
/*     */       }
/* 164 */       formatted = formatter.format(this.value);
/*     */     } else {
/*     */       
/* 167 */       formatted = this.value.toString();
/*     */     } 
/*     */     
/* 170 */     if (this.var != null) {
/* 171 */       this.pageContext.setAttribute(this.var, formatted, this.scope);
/*     */     } else {
/*     */       try {
/* 174 */         this.pageContext.getOut().print(formatted);
/* 175 */       } catch (IOException ioe) {
/* 176 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/*     */     } 
/*     */     
/* 180 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 185 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DateFormat createFormatter(Locale loc) throws JspException {
/* 193 */     DateFormat formatter = null;
/*     */     
/* 195 */     if (this.type == null || "date".equalsIgnoreCase(this.type)) {
/* 196 */       formatter = DateFormat.getDateInstance(Util.getStyle(this.dateStyle, "FORMAT_DATE_INVALID_DATE_STYLE"), loc);
/*     */     
/*     */     }
/* 199 */     else if ("time".equalsIgnoreCase(this.type)) {
/* 200 */       formatter = DateFormat.getTimeInstance(Util.getStyle(this.timeStyle, "FORMAT_DATE_INVALID_TIME_STYLE"), loc);
/*     */     
/*     */     }
/* 203 */     else if ("both".equalsIgnoreCase(this.type)) {
/* 204 */       formatter = DateFormat.getDateTimeInstance(Util.getStyle(this.dateStyle, "FORMAT_DATE_INVALID_DATE_STYLE"), Util.getStyle(this.timeStyle, "FORMAT_DATE_INVALID_TIME_STYLE"), loc);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 209 */       throw new JspException(Resources.getMessage("FORMAT_DATE_INVALID_TYPE", this.type));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 214 */     return formatter;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\FormatDateSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */