/*     */ package org.apache.taglibs.standard.tag.el.fmt;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.ParseNumberSupport;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseNumberTag
/*     */   extends ParseNumberSupport
/*     */ {
/*     */   private String value_;
/*     */   private String type_;
/*     */   private String pattern_;
/*     */   private String parseLocale_;
/*     */   private String integerOnly_;
/*     */   
/*     */   public ParseNumberTag() {
/*  65 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  76 */     evaluateExpressions();
/*     */ 
/*     */     
/*  79 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  84 */     super.release();
/*  85 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  94 */     this.value_ = value_;
/*  95 */     this.valueSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(String type_) {
/* 100 */     this.type_ = type_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern_) {
/* 105 */     this.pattern_ = pattern_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParseLocale(String parseLocale_) {
/* 110 */     this.parseLocale_ = parseLocale_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIntegerOnly(String integerOnly_) {
/* 115 */     this.integerOnly_ = integerOnly_;
/* 116 */     this.integerOnlySpecified = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 126 */     this.value_ = this.type_ = this.pattern_ = this.parseLocale_ = this.integerOnly_ = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 131 */     Object obj = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     if (this.value_ != null) {
/* 143 */       this.value = (String)ExpressionEvaluatorManager.evaluate("value", this.value_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 148 */     if (this.type_ != null) {
/* 149 */       this.type = (String)ExpressionEvaluatorManager.evaluate("type", this.type_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (this.pattern_ != null) {
/* 155 */       this.pattern = (String)ExpressionEvaluatorManager.evaluate("pattern", this.pattern_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (this.parseLocale_ != null) {
/* 161 */       obj = ExpressionEvaluatorManager.evaluate("parseLocale", this.parseLocale_, Object.class, (Tag)this, this.pageContext);
/*     */       
/* 163 */       if (obj != null) {
/* 164 */         if (obj instanceof Locale) {
/* 165 */           this.parseLocale = (Locale)obj;
/*     */         } else {
/* 167 */           String localeStr = (String)obj;
/* 168 */           if (!"".equals(localeStr)) {
/* 169 */             this.parseLocale = SetLocaleSupport.parseLocale(localeStr);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 176 */     if (this.integerOnly_ != null) {
/* 177 */       obj = ExpressionEvaluatorManager.evaluate("integerOnly", this.integerOnly_, Boolean.class, (Tag)this, this.pageContext);
/*     */       
/* 179 */       if (obj != null)
/* 180 */         this.isIntegerOnly = ((Boolean)obj).booleanValue(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\fmt\ParseNumberTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */