/*    */ package org.apache.taglibs.standard.tag.rt.xml;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.xml.ParseSupport;
/*    */ import org.xml.sax.XMLFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseTag
/*    */   extends ParseSupport
/*    */ {
/*    */   public void setXml(Object xml) throws JspTagException {
/* 48 */     this.xml = xml;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDoc(Object xml) throws JspTagException {
/* 53 */     this.xml = xml;
/*    */   }
/*    */   
/*    */   public void setSystemId(String systemId) throws JspTagException {
/* 57 */     this.systemId = systemId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setFilter(XMLFilter filter) throws JspTagException {
/* 62 */     this.filter = filter;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\xml\ParseTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */