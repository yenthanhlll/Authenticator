/*    */ package org.apache.taglibs.standard.tag.rt.xml;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.xml.transform.Result;
/*    */ import org.apache.taglibs.standard.tag.common.xml.TransformSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformTag
/*    */   extends TransformSupport
/*    */ {
/*    */   public void setXml(Object xml) throws JspTagException {
/* 48 */     this.xml = xml;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDoc(Object xml) throws JspTagException {
/* 53 */     this.xml = xml;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setXmlSystemId(String xmlSystemId) throws JspTagException {
/* 59 */     this.xmlSystemId = xmlSystemId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDocSystemId(String xmlSystemId) throws JspTagException {
/* 64 */     this.xmlSystemId = xmlSystemId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setXslt(Object xslt) throws JspTagException {
/* 69 */     this.xslt = xslt;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setXsltSystemId(String xsltSystemId) throws JspTagException {
/* 74 */     this.xsltSystemId = xsltSystemId;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setResult(Result result) throws JspTagException {
/* 79 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\xml\TransformTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */