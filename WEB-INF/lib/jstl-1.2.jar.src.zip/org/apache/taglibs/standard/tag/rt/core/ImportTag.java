/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.core.ImportSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportTag
/*    */   extends ImportSupport
/*    */ {
/*    */   public void setUrl(String url) throws JspTagException {
/* 46 */     this.url = url;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setContext(String context) throws JspTagException {
/* 51 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCharEncoding(String charEncoding) throws JspTagException {
/* 56 */     this.charEncoding = charEncoding;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\ImportTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */