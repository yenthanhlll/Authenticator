/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParseDateSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   private static final String DATE = "date";
/*     */   private static final String TIME = "time";
/*     */   private static final String DATETIME = "both";
/*     */   protected String value;
/*     */   protected boolean valueSpecified;
/*     */   protected String type;
/*     */   protected String pattern;
/*     */   protected Object timeZone;
/*     */   protected Locale parseLocale;
/*     */   protected String dateStyle;
/*     */   protected String timeStyle;
/*     */   private String var;
/*     */   private int scope;
/*     */   
/*     */   public ParseDateSupport() {
/*  86 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  90 */     this.type = this.dateStyle = this.timeStyle = null;
/*  91 */     this.value = this.pattern = this.var = null;
/*  92 */     this.valueSpecified = false;
/*  93 */     this.timeZone = null;
/*  94 */     this.scope = 1;
/*  95 */     this.parseLocale = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 103 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 107 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 116 */     String input = null;
/*     */ 
/*     */     
/* 119 */     if (this.valueSpecified) {
/*     */       
/* 121 */       input = this.value;
/*     */     
/*     */     }
/* 124 */     else if (this.bodyContent != null && this.bodyContent.getString() != null) {
/* 125 */       input = this.bodyContent.getString().trim();
/*     */     } 
/*     */     
/* 128 */     if (input == null || input.equals("")) {
/* 129 */       if (this.var != null) {
/* 130 */         this.pageContext.removeAttribute(this.var, this.scope);
/*     */       }
/* 132 */       return 6;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     Locale locale = this.parseLocale;
/* 140 */     if (locale == null) {
/* 141 */       locale = SetLocaleSupport.getFormattingLocale(this.pageContext, (Tag)this, false, DateFormat.getAvailableLocales());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 146 */     if (locale == null) {
/* 147 */       throw new JspException(Resources.getMessage("PARSE_DATE_NO_PARSE_LOCALE"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 152 */     DateFormat parser = createParser(locale);
/*     */ 
/*     */     
/* 155 */     if (this.pattern != null) {
/*     */       try {
/* 157 */         ((SimpleDateFormat)parser).applyPattern(this.pattern);
/* 158 */       } catch (ClassCastException cce) {
/* 159 */         parser = new SimpleDateFormat(this.pattern, locale);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 164 */     TimeZone tz = null;
/* 165 */     if (this.timeZone instanceof String && ((String)this.timeZone).equals("")) {
/* 166 */       this.timeZone = null;
/*     */     }
/* 168 */     if (this.timeZone != null) {
/* 169 */       if (this.timeZone instanceof String) {
/* 170 */         tz = TimeZone.getTimeZone((String)this.timeZone);
/* 171 */       } else if (this.timeZone instanceof TimeZone) {
/* 172 */         tz = (TimeZone)this.timeZone;
/*     */       } else {
/* 174 */         throw new JspException(Resources.getMessage("PARSE_DATE_BAD_TIMEZONE"));
/*     */       } 
/*     */     } else {
/*     */       
/* 178 */       tz = TimeZoneSupport.getTimeZone(this.pageContext, (Tag)this);
/*     */     } 
/* 180 */     if (tz != null) {
/* 181 */       parser.setTimeZone(tz);
/*     */     }
/*     */ 
/*     */     
/* 185 */     Date parsed = null;
/*     */     try {
/* 187 */       parsed = parser.parse(input);
/* 188 */     } catch (ParseException pe) {
/* 189 */       throw new JspException(Resources.getMessage("PARSE_DATE_PARSE_ERROR", input), pe);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 194 */     if (this.var != null) {
/* 195 */       this.pageContext.setAttribute(this.var, parsed, this.scope);
/*     */     } else {
/*     */       try {
/* 198 */         this.pageContext.getOut().print(parsed);
/* 199 */       } catch (IOException ioe) {
/* 200 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 209 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DateFormat createParser(Locale loc) throws JspException {
/* 217 */     DateFormat parser = null;
/*     */     
/* 219 */     if (this.type == null || "date".equalsIgnoreCase(this.type)) {
/* 220 */       parser = DateFormat.getDateInstance(Util.getStyle(this.dateStyle, "PARSE_DATE_INVALID_DATE_STYLE"), loc);
/*     */     
/*     */     }
/* 223 */     else if ("time".equalsIgnoreCase(this.type)) {
/* 224 */       parser = DateFormat.getTimeInstance(Util.getStyle(this.timeStyle, "PARSE_DATE_INVALID_TIME_STYLE"), loc);
/*     */     
/*     */     }
/* 227 */     else if ("both".equalsIgnoreCase(this.type)) {
/* 228 */       parser = DateFormat.getDateTimeInstance(Util.getStyle(this.dateStyle, "PARSE_DATE_INVALID_DATE_STYLE"), Util.getStyle(this.timeStyle, "PARSE_DATE_INVALID_TIME_STYLE"), loc);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 233 */       throw new JspException(Resources.getMessage("PARSE_DATE_INVALID_TYPE", this.type));
/*     */     } 
/*     */ 
/*     */     
/* 237 */     parser.setLenient(false);
/*     */     
/* 239 */     return parser;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\ParseDateSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */