/*    */ package org.apache.taglibs.standard.tag.common.xml;
/*    */ 
/*    */ import com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl;
/*    */ import javax.xml.xpath.XPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSTLXPathFactory
/*    */   extends XPathFactoryImpl
/*    */ {
/*    */   public XPath newXPath() {
/* 42 */     return new JSTLXPathImpl(null, null);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\JSTLXPathFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */