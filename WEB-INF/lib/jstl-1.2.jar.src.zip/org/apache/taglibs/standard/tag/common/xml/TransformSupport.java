/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.ImportSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransformSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected Object xml;
/*     */   protected String xmlSystemId;
/*     */   protected Object xslt;
/*     */   protected String xsltSystemId;
/*     */   protected Result result;
/*     */   private String var;
/*     */   private int scope;
/*     */   private Transformer t;
/*     */   private TransformerFactory tf;
/*     */   private DocumentBuilder db;
/*     */   private DocumentBuilderFactory dbf;
/*     */   
/*     */   public TransformSupport() {
/*  99 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/* 103 */     this.xml = this.xslt = null;
/* 104 */     this.xmlSystemId = this.xsltSystemId = null;
/* 105 */     this.var = null;
/* 106 */     this.result = null;
/* 107 */     this.tf = null;
/* 108 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*     */     try {
/*     */       Source s;
/* 127 */       if (this.dbf == null) {
/* 128 */         this.dbf = DocumentBuilderFactory.newInstance();
/* 129 */         this.dbf.setNamespaceAware(true);
/* 130 */         this.dbf.setValidating(false);
/*     */       } 
/* 132 */       if (this.db == null) {
/* 133 */         this.db = this.dbf.newDocumentBuilder();
/*     */       }
/*     */       
/* 136 */       if (this.tf == null) {
/* 137 */         this.tf = TransformerFactory.newInstance();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (this.xslt != null) {
/* 144 */         if (!(this.xslt instanceof String) && !(this.xslt instanceof Reader) && !(this.xslt instanceof Source))
/*     */         {
/* 146 */           throw new JspTagException(Resources.getMessage("TRANSFORM_XSLT_UNRECOGNIZED"));
/*     */         }
/* 148 */         s = getSource(this.xslt, this.xsltSystemId);
/*     */       } else {
/* 150 */         throw new JspTagException(Resources.getMessage("TRANSFORM_NO_TRANSFORMER"));
/*     */       } 
/*     */       
/* 153 */       this.tf.setURIResolver(new JstlUriResolver(this.pageContext));
/* 154 */       this.t = this.tf.newTransformer(s);
/*     */       
/* 156 */       return 2;
/*     */     }
/* 158 */     catch (SAXException ex) {
/* 159 */       Source s; throw new JspException(s);
/* 160 */     } catch (ParserConfigurationException ex) {
/* 161 */       throw new JspException(ex);
/* 162 */     } catch (IOException ex) {
/* 163 */       throw new JspException(ex);
/* 164 */     } catch (TransformerConfigurationException ex) {
/* 165 */       throw new JspException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/* 178 */       Object xml = this.xml;
/* 179 */       if (xml == null) {
/* 180 */         if (this.bodyContent != null && this.bodyContent.getString() != null) {
/* 181 */           xml = this.bodyContent.getString().trim();
/*     */         } else {
/* 183 */           xml = "";
/*     */         } 
/*     */       }
/* 186 */       Source source = getSource(xml, this.xmlSystemId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       if (this.result != null) {
/*     */         
/* 194 */         this.t.transform(source, this.result);
/* 195 */       } else if (this.var != null) {
/*     */         
/* 197 */         Document d = this.db.newDocument();
/* 198 */         Result doc = new DOMResult(d);
/* 199 */         this.t.transform(source, doc);
/* 200 */         this.pageContext.setAttribute(this.var, d, this.scope);
/*     */       } else {
/* 202 */         Result page = new StreamResult(new SafeWriter((Writer)this.pageContext.getOut()));
/*     */         
/* 204 */         this.t.transform(source, page);
/*     */       } 
/*     */       
/* 207 */       return 6;
/* 208 */     } catch (SAXException ex) {
/* 209 */       throw new JspException(ex);
/* 210 */     } catch (ParserConfigurationException ex) {
/* 211 */       throw new JspException(ex);
/* 212 */     } catch (IOException ex) {
/* 213 */       throw new JspException(ex);
/* 214 */     } catch (TransformerException ex) {
/* 215 */       throw new JspException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 221 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String name, Object value) {
/* 230 */     this.t.setParameter(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String wrapSystemId(String systemId) {
/* 243 */     if (systemId == null)
/* 244 */       return "jstl:"; 
/* 245 */     if (ImportSupport.isAbsoluteUrl(systemId)) {
/* 246 */       return systemId;
/*     */     }
/* 248 */     return "jstl:" + systemId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Source getSource(Object o, String systemId) throws SAXException, ParserConfigurationException, IOException {
/* 259 */     if (o == null)
/* 260 */       return null; 
/* 261 */     if (o instanceof Source)
/* 262 */       return (Source)o; 
/* 263 */     if (o instanceof String)
/*     */     {
/* 265 */       return getSource(new StringReader((String)o), systemId); } 
/* 266 */     if (o instanceof Reader) {
/*     */ 
/*     */       
/* 269 */       XMLReader xr = XMLReaderFactory.createXMLReader();
/* 270 */       xr.setEntityResolver(new ParseSupport.JstlEntityResolver(this.pageContext));
/*     */       
/* 272 */       InputSource s = new InputSource((Reader)o);
/* 273 */       s.setSystemId(wrapSystemId(systemId));
/* 274 */       Source result = new SAXSource(xr, s);
/* 275 */       result.setSystemId(wrapSystemId(systemId));
/* 276 */       return result;
/* 277 */     }  if (o instanceof Node)
/* 278 */       return new DOMSource((Node)o); 
/* 279 */     if (o instanceof List) {
/*     */       
/* 281 */       List l = (List)o;
/* 282 */       if (l.size() == 1) {
/* 283 */         return getSource(l.get(0), systemId);
/*     */       }
/* 285 */       throw new IllegalArgumentException(Resources.getMessage("TRANSFORM_SOURCE_INVALID_LIST"));
/*     */     } 
/*     */ 
/*     */     
/* 289 */     throw new IllegalArgumentException(Resources.getMessage("TRANSFORM_SOURCE_UNRECOGNIZED") + o.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 300 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 304 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SafeWriter
/*     */     extends Writer
/*     */   {
/*     */     private Writer w;
/*     */ 
/*     */ 
/*     */     
/*     */     public SafeWriter(Writer w) {
/* 318 */       this.w = w;
/*     */     }
/*     */     
/*     */     public void write(char[] cbuf, int off, int len) throws IOException {
/* 322 */       this.w.write(cbuf, off, len);
/*     */     }
/*     */     
/*     */     public void close() {}
/*     */     
/*     */     public void flush() {} }
/*     */   
/*     */   private static class JstlUriResolver implements URIResolver {
/*     */     private final PageContext ctx;
/*     */     
/*     */     public JstlUriResolver(PageContext ctx) {
/* 333 */       this.ctx = ctx;
/*     */     }
/*     */ 
/*     */     
/*     */     public Source resolve(String href, String base) throws TransformerException {
/*     */       InputStream s;
/* 339 */       if (href == null) {
/* 340 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       int index;
/*     */       
/* 346 */       if (base != null && (index = base.indexOf("jstl:")) != -1) {
/* 347 */         base = base.substring(index + 5);
/*     */       }
/*     */ 
/*     */       
/* 351 */       if (ImportSupport.isAbsoluteUrl(href) || (base != null && ImportSupport.isAbsoluteUrl(base)))
/*     */       {
/* 353 */         return null;
/*     */       }
/*     */       
/* 356 */       if (base == null || base.lastIndexOf("/") == -1) {
/* 357 */         base = "";
/*     */       } else {
/* 359 */         base = base.substring(0, base.lastIndexOf("/") + 1);
/*     */       } 
/*     */       
/* 362 */       String target = base + href;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 368 */       if (target.startsWith("/")) {
/* 369 */         s = this.ctx.getServletContext().getResourceAsStream(target);
/* 370 */         if (s == null) {
/* 371 */           throw new TransformerException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", href));
/*     */         }
/*     */       } else {
/*     */         
/* 375 */         String pagePath = ((HttpServletRequest)this.ctx.getRequest()).getServletPath();
/*     */         
/* 377 */         String basePath = pagePath.substring(0, pagePath.lastIndexOf("/"));
/*     */         
/* 379 */         s = this.ctx.getServletContext().getResourceAsStream(basePath + "/" + target);
/*     */         
/* 381 */         if (s == null) {
/* 382 */           throw new TransformerException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", href));
/*     */         }
/*     */       } 
/*     */       
/* 386 */       return new StreamSource(s);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\TransformSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */