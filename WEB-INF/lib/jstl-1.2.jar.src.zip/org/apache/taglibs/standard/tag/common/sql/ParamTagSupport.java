/*    */ package org.apache.taglibs.standard.tag.common.sql;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
/*    */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.resources.Resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ParamTagSupport
/*    */   extends BodyTagSupport
/*    */ {
/*    */   protected Object value;
/*    */   
/*    */   public int doEndTag() throws JspException {
/* 49 */     SQLExecutionTag parent = (SQLExecutionTag)findAncestorWithClass((Tag)this, SQLExecutionTag.class);
/*    */     
/* 51 */     if (parent == null) {
/* 52 */       throw new JspTagException(Resources.getMessage("SQL_PARAM_OUTSIDE_PARENT"));
/*    */     }
/*    */ 
/*    */     
/* 56 */     Object paramValue = null;
/* 57 */     if (this.value != null) {
/* 58 */       paramValue = this.value;
/*    */     }
/* 60 */     else if (this.bodyContent != null) {
/* 61 */       paramValue = this.bodyContent.getString().trim();
/* 62 */       if (((String)paramValue).trim().length() == 0) {
/* 63 */         paramValue = null;
/*    */       }
/*    */     } 
/*    */     
/* 67 */     parent.addSQLParameter(paramValue);
/* 68 */     return 6;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\ParamTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */