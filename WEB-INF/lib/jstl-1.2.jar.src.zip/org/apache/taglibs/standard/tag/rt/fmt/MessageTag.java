/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.MessageSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageTag
/*    */   extends MessageSupport
/*    */ {
/*    */   public void setKey(String key) throws JspTagException {
/* 47 */     this.keyAttrValue = key;
/* 48 */     this.keySpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBundle(LocalizationContext locCtxt) throws JspTagException {
/* 53 */     this.bundleAttrValue = locCtxt;
/* 54 */     this.bundleSpecified = true;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\MessageTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */