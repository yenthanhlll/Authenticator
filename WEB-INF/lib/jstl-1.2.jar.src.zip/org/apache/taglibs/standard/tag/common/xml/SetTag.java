/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetTag
/*     */   extends TagSupport
/*     */ {
/*     */   private String select;
/*     */   private String var;
/*     */   private int scope;
/*     */   
/*     */   public SetTag() {
/*  60 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/*  65 */     this.var = null;
/*  66 */     this.select = null;
/*  67 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  77 */     XPathUtil xu = new XPathUtil(this.pageContext);
/*  78 */     List result = xu.selectNodes(XPathUtil.getContext((Tag)this), this.select);
/*     */     
/*  80 */     Object ret = result;
/*     */ 
/*     */     
/*  83 */     if (result.size() == 1) {
/*  84 */       Object o = result.get(0);
/*  85 */       if (o instanceof String || o instanceof Boolean || o instanceof Number)
/*     */       {
/*  87 */         ret = o;
/*     */       }
/*     */     } 
/*     */     
/*  91 */     this.pageContext.setAttribute(this.var, ret, this.scope);
/*  92 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  97 */     super.release();
/*  98 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelect(String select) {
/* 106 */     this.select = select;
/*     */   }
/*     */   
/*     */   public void setVar(String var) {
/* 110 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 114 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\SetTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */