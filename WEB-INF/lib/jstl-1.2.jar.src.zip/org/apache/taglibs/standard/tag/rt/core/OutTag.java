/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.core.OutSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutTag
/*    */   extends OutSupport
/*    */ {
/*    */   public void setValue(Object value) {
/* 43 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDefault(String def) {
/* 48 */     this.def = def;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEscapeXml(boolean escapeXml) {
/* 53 */     this.escapeXml = escapeXml;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\OutTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */