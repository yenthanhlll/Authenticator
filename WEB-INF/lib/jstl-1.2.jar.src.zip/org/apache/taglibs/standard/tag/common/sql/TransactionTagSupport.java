/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransactionTagSupport
/*     */   extends TagSupport
/*     */   implements TryCatchFinally
/*     */ {
/*     */   private static final String TRANSACTION_READ_COMMITTED = "read_committed";
/*     */   private static final String TRANSACTION_READ_UNCOMMITTED = "read_uncommitted";
/*     */   private static final String TRANSACTION_REPEATABLE_READ = "repeatable_read";
/*     */   private static final String TRANSACTION_SERIALIZABLE = "serializable";
/*     */   protected Object rawDataSource;
/*     */   protected boolean dataSourceSpecified;
/*     */   private Connection conn;
/*     */   private int isolation;
/*     */   private int origIsolation;
/*     */   
/*     */   public TransactionTagSupport() {
/*  82 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  86 */     this.conn = null;
/*  87 */     this.dataSourceSpecified = false;
/*  88 */     this.rawDataSource = null;
/*  89 */     this.isolation = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 103 */     if (this.rawDataSource == null && this.dataSourceSpecified) {
/* 104 */       throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
/*     */     }
/*     */ 
/*     */     
/* 108 */     DataSource dataSource = DataSourceUtil.getDataSource(this.rawDataSource, this.pageContext);
/*     */ 
/*     */     
/*     */     try {
/* 112 */       this.conn = dataSource.getConnection();
/* 113 */       this.origIsolation = this.conn.getTransactionIsolation();
/* 114 */       if (this.origIsolation == 0) {
/* 115 */         throw new JspTagException(Resources.getMessage("TRANSACTION_NO_SUPPORT"));
/*     */       }
/*     */       
/* 118 */       if (this.isolation != 0 && this.isolation != this.origIsolation)
/*     */       {
/* 120 */         this.conn.setTransactionIsolation(this.isolation);
/*     */       }
/* 122 */       this.conn.setAutoCommit(false);
/* 123 */     } catch (SQLException e) {
/* 124 */       throw new JspTagException(Resources.getMessage("ERROR_GET_CONNECTION", e.toString()), e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/* 137 */       this.conn.commit();
/* 138 */     } catch (SQLException e) {
/* 139 */       throw new JspTagException(Resources.getMessage("TRANSACTION_COMMIT_ERROR", e.toString()), e);
/*     */     } 
/*     */ 
/*     */     
/* 143 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCatch(Throwable t) throws Throwable {
/* 150 */     if (this.conn != null) {
/*     */       try {
/* 152 */         this.conn.rollback();
/* 153 */       } catch (SQLException e) {}
/*     */     }
/*     */ 
/*     */     
/* 157 */     throw t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFinally() {
/* 165 */     if (this.conn != null) {
/*     */       try {
/* 167 */         if (this.isolation != 0 && this.isolation != this.origIsolation)
/*     */         {
/* 169 */           this.conn.setTransactionIsolation(this.origIsolation);
/*     */         }
/* 171 */         this.conn.setAutoCommit(true);
/* 172 */         this.conn.close();
/* 173 */       } catch (SQLException e) {}
/*     */     }
/*     */ 
/*     */     
/* 177 */     this.conn = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 182 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsolation(String iso) throws JspTagException {
/* 194 */     if ("read_committed".equals(iso)) {
/* 195 */       this.isolation = 2;
/* 196 */     } else if ("read_uncommitted".equals(iso)) {
/* 197 */       this.isolation = 1;
/* 198 */     } else if ("repeatable_read".equals(iso)) {
/* 199 */       this.isolation = 4;
/* 200 */     } else if ("serializable".equals(iso)) {
/* 201 */       this.isolation = 8;
/*     */     } else {
/* 203 */       throw new JspTagException(Resources.getMessage("TRANSACTION_INVALID_ISOLATION"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getSharedConnection() {
/* 213 */     return this.conn;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\TransactionTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */