/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceWrapper
/*     */   implements DataSource
/*     */ {
/*     */   private String driverClassName;
/*     */   private String jdbcURL;
/*     */   private String userName;
/*     */   private String password;
/*     */   
/*     */   public void setDriverClassName(String driverClassName) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
/*  54 */     this.driverClassName = driverClassName;
/*  55 */     Class.forName(driverClassName, true, Thread.currentThread().getContextClassLoader()).newInstance();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJdbcURL(String jdbcURL) {
/*  60 */     this.jdbcURL = jdbcURL;
/*     */   }
/*     */   
/*     */   public void setUserName(String userName) {
/*  64 */     this.userName = userName;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  68 */     this.password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*  76 */     Connection conn = null;
/*  77 */     if (this.userName != null) {
/*  78 */       conn = DriverManager.getConnection(this.jdbcURL, this.userName, this.password);
/*     */     } else {
/*     */       
/*  81 */       conn = DriverManager.getConnection(this.jdbcURL);
/*     */     } 
/*  83 */     return conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/*  92 */     throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLoginTimeout() throws SQLException {
/*  99 */     throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() throws SQLException {
/* 106 */     throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int seconds) throws SQLException {
/* 113 */     throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setLogWriter(PrintWriter out) throws SQLException {
/* 120 */     throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\DataSourceWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */