/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected Object value;
/*     */   protected String def;
/*     */   protected boolean escapeXml;
/*     */   private boolean needBody;
/*     */   
/*     */   public OutSupport() {
/*  70 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/*  75 */     this.value = this.def = null;
/*  76 */     this.escapeXml = true;
/*  77 */     this.needBody = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  82 */     super.release();
/*  83 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  93 */     this.needBody = false;
/*  94 */     this.bodyContent = null;
/*     */ 
/*     */     
/*     */     try {
/*  98 */       if (this.value != null) {
/*  99 */         out(this.pageContext, this.escapeXml, this.value);
/* 100 */         return 0;
/*     */       } 
/*     */       
/* 103 */       if (this.def == null) {
/* 104 */         this.needBody = true;
/* 105 */         return 2;
/*     */       } 
/*     */ 
/*     */       
/* 109 */       if (this.def != null)
/*     */       {
/* 111 */         out(this.pageContext, this.escapeXml, this.def);
/*     */       }
/* 113 */       return 0;
/*     */     }
/* 115 */     catch (IOException ex) {
/* 116 */       throw new JspException(ex.toString(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/* 123 */       if (!this.needBody) {
/* 124 */         return 6;
/*     */       }
/*     */       
/* 127 */       if (this.bodyContent != null && this.bodyContent.getString() != null)
/* 128 */         out(this.pageContext, this.escapeXml, this.bodyContent.getString().trim()); 
/* 129 */       return 6;
/* 130 */     } catch (IOException ex) {
/* 131 */       throw new JspException(ex.toString(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void out(PageContext pageContext, boolean escapeXml, Object obj) throws IOException {
/* 155 */     JspWriter w = pageContext.getOut();
/* 156 */     if (!escapeXml) {
/*     */       
/* 158 */       if (obj instanceof Reader) {
/* 159 */         Reader reader = (Reader)obj;
/* 160 */         char[] buf = new char[4096];
/*     */         int count;
/* 162 */         while ((count = reader.read(buf, 0, 4096)) != -1) {
/* 163 */           w.write(buf, 0, count);
/*     */         }
/*     */       } else {
/* 166 */         w.write(obj.toString());
/*     */       }
/*     */     
/*     */     }
/* 170 */     else if (obj instanceof Reader) {
/* 171 */       Reader reader = (Reader)obj;
/* 172 */       char[] buf = new char[4096];
/*     */       int count;
/* 174 */       while ((count = reader.read(buf, 0, 4096)) != -1) {
/* 175 */         writeEscapedXml(buf, count, w);
/*     */       }
/*     */     } else {
/* 178 */       String text = obj.toString();
/* 179 */       writeEscapedXml(text.toCharArray(), text.length(), w);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeEscapedXml(char[] buffer, int length, JspWriter w) throws IOException {
/* 191 */     int start = 0;
/*     */     
/* 193 */     for (int i = 0; i < length; i++) {
/* 194 */       char c = buffer[i];
/* 195 */       if (c <= '>') {
/* 196 */         char[] escaped = Util.specialCharactersRepresentation[c];
/* 197 */         if (escaped != null) {
/*     */           
/* 199 */           if (start < i) {
/* 200 */             w.write(buffer, start, i - start);
/*     */           }
/*     */           
/* 203 */           w.write(escaped);
/* 204 */           start = i + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     if (start < length)
/* 210 */       w.write(buffer, start, length - start); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\OutSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */