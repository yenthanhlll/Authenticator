/*    */ package org.apache.taglibs.standard.tag.common.xml;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ import org.apache.taglibs.standard.tag.common.core.OutSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ExprSupport
/*    */   extends TagSupport
/*    */ {
/*    */   private String select;
/*    */   protected boolean escapeXml;
/*    */   
/*    */   public ExprSupport() {
/* 56 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   private void init() {
/* 61 */     this.select = null;
/* 62 */     this.escapeXml = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int doStartTag() throws JspException {
/*    */     try {
/* 72 */       XPathUtil xu = new XPathUtil(this.pageContext);
/* 73 */       String result = xu.valueOf(XPathUtil.getContext((Tag)this), this.select);
/* 74 */       OutSupport.out(this.pageContext, this.escapeXml, result);
/*    */       
/* 76 */       return 0;
/* 77 */     } catch (IOException ex) {
/* 78 */       throw new JspTagException(ex.toString(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 84 */     super.release();
/* 85 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelect(String select) {
/* 93 */     this.select = select;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\ExprSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */