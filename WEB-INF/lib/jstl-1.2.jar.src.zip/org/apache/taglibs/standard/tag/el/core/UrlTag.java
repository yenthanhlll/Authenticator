/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.UrlSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlTag
/*     */   extends UrlSupport
/*     */ {
/*     */   private String value_;
/*     */   private String context_;
/*     */   
/*     */   public UrlTag() {
/*  58 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  69 */     evaluateExpressions();
/*     */ 
/*     */     
/*  72 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  78 */     super.release();
/*  79 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  87 */     this.value_ = value_;
/*     */   }
/*     */   
/*     */   public void setContext(String context_) {
/*  91 */     this.context_ = context_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 101 */     this.value_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 114 */     this.value = (String)ExpressionUtil.evalNotNull("url", "value", this.value_, String.class, (Tag)this, this.pageContext);
/*     */     
/* 116 */     this.context = (String)ExpressionUtil.evalNotNull("url", "context", this.context_, String.class, (Tag)this, this.pageContext);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\UrlTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */