/*    */ package org.apache.taglibs.standard.tag.el.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.core.ConditionalTagSupport;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfTag
/*    */   extends ConditionalTagSupport
/*    */ {
/*    */   private String test;
/*    */   
/*    */   public IfTag() {
/* 52 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 57 */     super.release();
/* 58 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean condition() throws JspTagException {
/*    */     try {
/* 67 */       Object r = ExpressionEvaluatorManager.evaluate("test", this.test, Boolean.class, (Tag)this, this.pageContext);
/*    */       
/* 69 */       if (r == null) {
/* 70 */         throw new NullAttributeException("if", "test");
/*    */       }
/* 72 */       return ((Boolean)r).booleanValue();
/* 73 */     } catch (JspException ex) {
/* 74 */       throw new JspTagException(ex.toString(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTest(String test) {
/* 90 */     this.test = test;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 99 */     this.test = null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\IfTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */