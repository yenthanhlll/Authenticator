/*    */ package org.apache.taglibs.standard.tag.el.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionUtil
/*    */ {
/*    */   public static Object evalNotNull(String tagName, String attributeName, String expression, Class expectedType, Tag tag, PageContext pageContext) throws JspException {
/* 56 */     if (expression != null) {
/* 57 */       Object r = ExpressionEvaluatorManager.evaluate(attributeName, expression, expectedType, tag, pageContext);
/*    */       
/* 59 */       if (r == null)
/* 60 */         throw new NullAttributeException(tagName, attributeName); 
/* 61 */       return r;
/*    */     } 
/* 63 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\ExpressionUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */