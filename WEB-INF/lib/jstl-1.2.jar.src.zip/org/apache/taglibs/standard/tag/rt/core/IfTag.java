/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import javax.servlet.jsp.jstl.core.ConditionalTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfTag
/*    */   extends ConditionalTagSupport
/*    */ {
/*    */   private boolean test;
/*    */   
/*    */   public IfTag() {
/* 47 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 52 */     super.release();
/* 53 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean condition() {
/* 61 */     return this.test;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTest(boolean test) {
/* 76 */     this.test = test;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 85 */     this.test = false;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\IfTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */