/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TimeZoneSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected Object value;
/*     */   private TimeZone timeZone;
/*     */   
/*     */   public TimeZoneSupport() {
/*  65 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  69 */     this.value = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/*  77 */     return this.timeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  86 */     if (this.value == null) {
/*  87 */       this.timeZone = TimeZone.getTimeZone("GMT");
/*  88 */     } else if (this.value instanceof String) {
/*  89 */       if (((String)this.value).trim().equals("")) {
/*  90 */         this.timeZone = TimeZone.getTimeZone("GMT");
/*     */       } else {
/*  92 */         this.timeZone = TimeZone.getTimeZone((String)this.value);
/*     */       } 
/*     */     } else {
/*  95 */       this.timeZone = (TimeZone)this.value;
/*     */     } 
/*     */     
/*  98 */     return 2;
/*     */   }
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/* 103 */       this.pageContext.getOut().print(this.bodyContent.getString());
/* 104 */     } catch (IOException ioe) {
/* 105 */       throw new JspTagException(ioe.toString(), ioe);
/*     */     } 
/*     */     
/* 108 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 113 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TimeZone getTimeZone(PageContext pc, Tag fromTag) {
/* 140 */     TimeZone tz = null;
/*     */     
/* 142 */     Tag t = findAncestorWithClass(fromTag, TimeZoneSupport.class);
/* 143 */     if (t != null) {
/*     */       
/* 145 */       TimeZoneSupport parent = (TimeZoneSupport)t;
/* 146 */       tz = parent.getTimeZone();
/*     */     } else {
/*     */       
/* 149 */       Object obj = Config.find(pc, "javax.servlet.jsp.jstl.fmt.timeZone");
/* 150 */       if (obj != null) {
/* 151 */         if (obj instanceof TimeZone) {
/* 152 */           tz = (TimeZone)obj;
/*     */         } else {
/* 154 */           tz = TimeZone.getTimeZone((String)obj);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 159 */     return tz;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\TimeZoneSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */