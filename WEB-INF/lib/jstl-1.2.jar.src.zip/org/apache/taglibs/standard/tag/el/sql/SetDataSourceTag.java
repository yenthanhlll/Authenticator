/*     */ package org.apache.taglibs.standard.tag.el.sql;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.sql.SetDataSourceTagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetDataSourceTag
/*     */   extends SetDataSourceTagSupport
/*     */ {
/*     */   private String dataSourceEL;
/*     */   private String driverClassNameEL;
/*     */   private String jdbcURLEL;
/*     */   private String userNameEL;
/*     */   private String passwordEL;
/*     */   
/*     */   public void setDataSource(String dataSourceEL) {
/*  50 */     this.dataSourceEL = dataSourceEL;
/*  51 */     this.dataSourceSpecified = true;
/*     */   }
/*     */   
/*     */   public void setDriver(String driverClassNameEL) {
/*  55 */     this.driverClassNameEL = driverClassNameEL;
/*     */   }
/*     */   
/*     */   public void setUrl(String jdbcURLEL) {
/*  59 */     this.jdbcURLEL = jdbcURLEL;
/*     */   }
/*     */   
/*     */   public void setUser(String userNameEL) {
/*  63 */     this.userNameEL = userNameEL;
/*     */   }
/*     */   
/*     */   public void setPassword(String passwordEL) {
/*  67 */     this.passwordEL = passwordEL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  74 */     evaluateExpressions();
/*     */     
/*  76 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/*  85 */     if (this.dataSourceEL != null) {
/*  86 */       this.dataSource = ExpressionEvaluatorManager.evaluate("dataSource", this.dataSourceEL, Object.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */     
/*  90 */     if (this.driverClassNameEL != null) {
/*  91 */       this.driverClassName = (String)ExpressionEvaluatorManager.evaluate("driver", this.driverClassNameEL, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */     
/*  95 */     if (this.jdbcURLEL != null) {
/*  96 */       this.jdbcURL = (String)ExpressionEvaluatorManager.evaluate("url", this.jdbcURLEL, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */     
/* 100 */     if (this.userNameEL != null) {
/* 101 */       this.userName = (String)ExpressionEvaluatorManager.evaluate("user", this.userNameEL, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */     
/* 105 */     if (this.passwordEL != null)
/* 106 */       this.password = (String)ExpressionEvaluatorManager.evaluate("password", this.passwordEL, String.class, (Tag)this, this.pageContext); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\sql\SetDataSourceTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */