/*    */ package org.apache.taglibs.standard.tag.common.xml;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.resources.Resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ParamSupport
/*    */   extends BodyTagSupport
/*    */ {
/*    */   protected String name;
/*    */   protected Object value;
/*    */   
/*    */   public ParamSupport() {
/* 56 */     init();
/*    */   }
/*    */   
/*    */   private void init() {
/* 60 */     this.name = null;
/* 61 */     this.value = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int doEndTag() throws JspException {
/* 70 */     Tag t = findAncestorWithClass((Tag)this, TransformSupport.class);
/* 71 */     if (t == null) {
/* 72 */       throw new JspTagException(Resources.getMessage("PARAM_OUTSIDE_TRANSFORM"));
/*    */     }
/* 74 */     TransformSupport parent = (TransformSupport)t;
/*    */     
/* 76 */     Object value = this.value;
/* 77 */     if (value == null)
/* 78 */       if (this.bodyContent == null || this.bodyContent.getString() == null) {
/* 79 */         value = "";
/*    */       } else {
/* 81 */         value = this.bodyContent.getString().trim();
/*    */       }  
/* 83 */     parent.addParameter(this.name, value);
/* 84 */     return 6;
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 89 */     init();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\ParamSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */