/*    */ package org.apache.taglibs.standard.tag.el.sql;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ import org.apache.taglibs.standard.tag.common.sql.DateParamTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateParamTag
/*    */   extends DateParamTagSupport
/*    */ {
/*    */   private String valueEL;
/*    */   private String typeEL;
/*    */   
/*    */   public void setValue(String valueEL) {
/* 45 */     this.valueEL = valueEL;
/*    */   }
/*    */   
/*    */   public void setType(String typeEL) {
/* 49 */     this.typeEL = typeEL;
/*    */   }
/*    */   
/*    */   public int doStartTag() throws JspException {
/* 53 */     evaluateExpressions();
/* 54 */     return super.doStartTag();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void evaluateExpressions() throws JspException {
/* 62 */     if (this.valueEL != null) {
/* 63 */       this.value = (Date)ExpressionEvaluatorManager.evaluate("value", this.valueEL, Date.class, (Tag)this, this.pageContext);
/*    */     }
/*    */ 
/*    */     
/* 67 */     if (this.typeEL != null)
/* 68 */       this.type = (String)ExpressionEvaluatorManager.evaluate("type", this.typeEL, String.class, (Tag)this, this.pageContext); 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\sql\DateParamTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */