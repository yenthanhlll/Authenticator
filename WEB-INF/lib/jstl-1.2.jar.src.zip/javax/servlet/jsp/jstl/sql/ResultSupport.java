/*    */ package javax.servlet.jsp.jstl.sql;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultSupport
/*    */ {
/*    */   public static Result toResult(ResultSet rs) {
/*    */     try {
/* 52 */       return new ResultImpl(rs, -1, -1);
/* 53 */     } catch (SQLException ex) {
/* 54 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Result toResult(ResultSet rs, int maxRows) {
/*    */     try {
/* 70 */       return new ResultImpl(rs, -1, maxRows);
/* 71 */     } catch (SQLException ex) {
/* 72 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\sql\ResultSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */