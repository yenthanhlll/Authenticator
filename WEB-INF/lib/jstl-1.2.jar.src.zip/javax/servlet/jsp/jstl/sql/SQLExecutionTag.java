package javax.servlet.jsp.jstl.sql;

public interface SQLExecutionTag {
  void addSQLParameter(Object paramObject);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\sql\SQLExecutionTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */