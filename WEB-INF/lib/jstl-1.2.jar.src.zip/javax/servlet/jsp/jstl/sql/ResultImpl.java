/*     */ package javax.servlet.jsp.jstl.sql;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResultImpl
/*     */   implements Result, Serializable
/*     */ {
/*  70 */   private List rowMap = new ArrayList();
/*  71 */   private List rowByIndex = new ArrayList();
/*     */   public ResultImpl(ResultSet rs, int startRow, int maxRows) throws SQLException {
/*  73 */     ResultSetMetaData rsmd = rs.getMetaData();
/*  74 */     int noOfColumns = rsmd.getColumnCount();
/*     */ 
/*     */     
/*  77 */     this.columnNames = new String[noOfColumns]; int i;
/*  78 */     for (i = 1; i <= noOfColumns; i++) {
/*  79 */       this.columnNames[i - 1] = rsmd.getColumnName(i);
/*     */     }
/*     */ 
/*     */     
/*  83 */     for (i = 0; i < startRow; i++) {
/*  84 */       rs.next();
/*     */     }
/*     */ 
/*     */     
/*  88 */     int processedRows = 0;
/*  89 */     while (rs.next()) {
/*  90 */       if (maxRows != -1 && processedRows == maxRows) {
/*  91 */         this.isLimited = true;
/*     */         break;
/*     */       } 
/*  94 */       Object[] columns = new Object[noOfColumns];
/*  95 */       SortedMap<String, Object> columnMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
/*     */ 
/*     */ 
/*     */       
/*  99 */       for (int j = 1; j <= noOfColumns; j++) {
/* 100 */         Object value = rs.getObject(j);
/* 101 */         if (rs.wasNull()) {
/* 102 */           value = null;
/*     */         }
/* 104 */         columns[j - 1] = value;
/* 105 */         columnMap.put(this.columnNames[j - 1], value);
/*     */       } 
/* 107 */       this.rowMap.add(columnMap);
/* 108 */       this.rowByIndex.add(columns);
/* 109 */       processedRows++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] columnNames;
/*     */ 
/*     */   
/*     */   private boolean isLimited;
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedMap[] getRows() {
/* 123 */     if (this.rowMap == null) {
/* 124 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 128 */     return (SortedMap[])this.rowMap.toArray((Object[])new SortedMap[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[][] getRowsByIndex() {
/* 140 */     if (this.rowByIndex == null) {
/* 141 */       return (Object[][])null;
/*     */     }
/*     */ 
/*     */     
/* 145 */     return (Object[][])this.rowByIndex.toArray((Object[])new Object[0][0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getColumnNames() {
/* 156 */     return this.columnNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowCount() {
/* 166 */     if (this.rowMap == null) {
/* 167 */       return -1;
/*     */     }
/* 169 */     return this.rowMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLimitedByMaxRows() {
/* 178 */     return this.isLimited;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\sql\ResultImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */