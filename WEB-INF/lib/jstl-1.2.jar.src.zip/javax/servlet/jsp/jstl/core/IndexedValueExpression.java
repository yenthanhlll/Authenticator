/*     */ package javax.servlet.jsp.jstl.core;
/*     */ 
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ValueExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IndexedValueExpression
/*     */   extends ValueExpression
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Integer i;
/*     */   protected final ValueExpression orig;
/*     */   
/*     */   public IndexedValueExpression(ValueExpression orig, int i) {
/*  46 */     this.i = new Integer(i);
/*  47 */     this.orig = orig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context) {
/*  56 */     Object base = this.orig.getValue(context);
/*  57 */     if (base != null) {
/*  58 */       context.setPropertyResolved(false);
/*  59 */       return context.getELResolver().getValue(context, base, this.i);
/*     */     } 
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object value) {
/*  71 */     Object base = this.orig.getValue(context);
/*  72 */     if (base != null) {
/*  73 */       context.setPropertyResolved(false);
/*  74 */       context.getELResolver().setValue(context, base, this.i, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context) {
/*  84 */     Object base = this.orig.getValue(context);
/*  85 */     if (base != null) {
/*  86 */       context.setPropertyResolved(false);
/*  87 */       return context.getELResolver().isReadOnly(context, base, this.i);
/*     */     } 
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getType(ELContext context) {
/*  98 */     Object base = this.orig.getValue(context);
/*  99 */     if (base != null) {
/* 100 */       context.setPropertyResolved(false);
/* 101 */       return context.getELResolver().getType(context, base, this.i);
/*     */     } 
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getExpectedType() {
/* 112 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 121 */     return this.orig.getExpressionString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 130 */     return this.orig.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 139 */     return this.orig.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLiteralText() {
/* 148 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\IndexedValueExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */