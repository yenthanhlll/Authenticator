/*     */ package javax.servlet.jsp.jstl.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ValueExpression;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IteratedExpression
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final ValueExpression orig;
/*     */   protected final String delims;
/*     */   private Object base;
/*     */   private int index;
/*     */   private Iterator iter;
/*     */   
/*     */   public IteratedExpression(ValueExpression orig, String delims) {
/*  55 */     this.orig = orig;
/*  56 */     this.delims = delims;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getItem(ELContext context, int i) {
/*  66 */     if (this.base == null) {
/*  67 */       this.base = this.orig.getValue(context);
/*  68 */       if (this.base == null) {
/*  69 */         return null;
/*     */       }
/*  71 */       this.iter = toIterator(this.base);
/*  72 */       this.index = 0;
/*     */     } 
/*  74 */     if (this.index > i) {
/*     */       
/*  76 */       this.iter = toIterator(this.base);
/*  77 */       this.index = 0;
/*     */     } 
/*  79 */     while (this.iter.hasNext()) {
/*  80 */       Object item = this.iter.next();
/*  81 */       if (this.index++ == i) {
/*  82 */         return item;
/*     */       }
/*     */     } 
/*  85 */     return null;
/*     */   }
/*     */   
/*     */   public ValueExpression getValueExpression() {
/*  89 */     return this.orig;
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterator toIterator(Object obj) {
/*     */     Iterator iter;
/*  95 */     if (obj instanceof String) {
/*  96 */       iter = toIterator(new StringTokenizer((String)obj, this.delims));
/*     */     }
/*  98 */     else if (obj instanceof Iterator) {
/*  99 */       iter = (Iterator)obj;
/*     */     }
/* 101 */     else if (obj instanceof Collection) {
/* 102 */       iter = toIterator(((Collection)obj).iterator());
/*     */     }
/* 104 */     else if (obj instanceof Enumeration) {
/* 105 */       iter = toIterator((Enumeration)obj);
/*     */     }
/* 107 */     else if (obj instanceof Map) {
/* 108 */       iter = ((Map)obj).entrySet().iterator();
/*     */     } else {
/* 110 */       throw new ELException(Resources.getMessage("FOREACH_BAD_ITEMS"));
/*     */     } 
/* 112 */     return iter;
/*     */   }
/*     */   
/*     */   private Iterator toIterator(final Enumeration obj) {
/* 116 */     return new Iterator() {
/*     */         public boolean hasNext() {
/* 118 */           return obj.hasMoreElements();
/*     */         }
/*     */         public Object next() {
/* 121 */           return obj.nextElement();
/*     */         }
/*     */         
/*     */         public void remove() {}
/*     */       };
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\IteratedExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */