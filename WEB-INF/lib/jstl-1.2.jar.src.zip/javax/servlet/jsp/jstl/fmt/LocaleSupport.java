/*     */ package javax.servlet.jsp.jstl.fmt;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.BundleSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocaleSupport
/*     */ {
/*     */   public static String getLocalizedMessage(PageContext pageContext, String key) {
/*  72 */     return getLocalizedMessage(pageContext, key, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalizedMessage(PageContext pageContext, String key, String basename) {
/*  95 */     return getLocalizedMessage(pageContext, key, null, basename);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalizedMessage(PageContext pageContext, String key, Object[] args) {
/* 119 */     return getLocalizedMessage(pageContext, key, args, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalizedMessage(PageContext pageContext, String key, Object[] args, String basename) {
/* 145 */     LocalizationContext locCtxt = null;
/* 146 */     String message = "???" + key + "???";
/*     */ 
/*     */     
/* 149 */     if (basename != null) {
/* 150 */       locCtxt = BundleSupport.getLocalizationContext(pageContext, basename);
/*     */     } else {
/* 152 */       locCtxt = BundleSupport.getLocalizationContext(pageContext);
/*     */     } 
/*     */     
/* 155 */     if (locCtxt != null) {
/* 156 */       ResourceBundle bundle = locCtxt.getResourceBundle();
/* 157 */       if (bundle != null) {
/*     */         try {
/* 159 */           message = bundle.getString(key);
/* 160 */           if (args != null) {
/* 161 */             MessageFormat formatter = new MessageFormat("");
/* 162 */             if (locCtxt.getLocale() != null) {
/* 163 */               formatter.setLocale(locCtxt.getLocale());
/*     */             }
/* 165 */             formatter.applyPattern(message);
/* 166 */             message = formatter.format(args);
/*     */           } 
/* 168 */         } catch (MissingResourceException mre) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 173 */     return message;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\fmt\LocaleSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */