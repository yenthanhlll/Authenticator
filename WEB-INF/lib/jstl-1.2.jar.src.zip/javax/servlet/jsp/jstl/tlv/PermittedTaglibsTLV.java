/*     */ package javax.servlet.jsp.jstl.tlv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.TagLibraryValidator;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PermittedTaglibsTLV
/*     */   extends TagLibraryValidator
/*     */ {
/*  64 */   private final String PERMITTED_TAGLIBS_PARAM = "permittedTaglibs";
/*     */ 
/*     */   
/*  67 */   private final String JSP_ROOT_URI = "http://java.sun.com/JSP/Page";
/*     */ 
/*     */   
/*  70 */   private final String JSP_ROOT_NAME = "root";
/*     */ 
/*     */   
/*  73 */   private final String JSP_ROOT_QN = "jsp:root";
/*     */ 
/*     */ 
/*     */   
/*     */   private Set permittedTaglibs;
/*     */ 
/*     */   
/*     */   private boolean failed;
/*     */ 
/*     */   
/*     */   private String uri;
/*     */ 
/*     */ 
/*     */   
/*     */   public PermittedTaglibsTLV() {
/*  88 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  92 */     this.permittedTaglibs = null;
/*     */   }
/*     */   
/*     */   public void release() {
/*  96 */     super.release();
/*  97 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ValidationMessage[] validate(String prefix, String uri, PageData page) {
/*     */     try {
/* 109 */       this.uri = uri;
/* 110 */       this.permittedTaglibs = readConfiguration();
/*     */ 
/*     */       
/* 113 */       DefaultHandler h = new PermittedTaglibsHandler();
/*     */ 
/*     */       
/* 116 */       SAXParserFactory f = SAXParserFactory.newInstance();
/* 117 */       f.setValidating(true);
/* 118 */       SAXParser p = f.newSAXParser();
/* 119 */       p.parse(page.getInputStream(), h);
/*     */       
/* 121 */       if (this.failed) {
/* 122 */         return vmFromString("taglib " + prefix + " (" + uri + ") allows only the " + "following taglibs to be imported: " + this.permittedTaglibs);
/*     */       }
/*     */ 
/*     */       
/* 126 */       return null;
/*     */     }
/* 128 */     catch (SAXException ex) {
/* 129 */       return vmFromString(ex.toString());
/* 130 */     } catch (ParserConfigurationException ex) {
/* 131 */       return vmFromString(ex.toString());
/* 132 */     } catch (IOException ex) {
/* 133 */       return vmFromString(ex.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set readConfiguration() {
/* 145 */     Set<String> s = new HashSet();
/*     */ 
/*     */     
/* 148 */     String uris = (String)getInitParameters().get("permittedTaglibs");
/*     */ 
/*     */     
/* 151 */     StringTokenizer st = new StringTokenizer(uris);
/* 152 */     while (st.hasMoreTokens()) {
/* 153 */       s.add(st.nextToken());
/*     */     }
/*     */     
/* 156 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidationMessage[] vmFromString(String message) {
/* 162 */     return new ValidationMessage[] { new ValidationMessage(null, message) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class PermittedTaglibsHandler
/*     */     extends DefaultHandler
/*     */   {
/*     */     private PermittedTaglibsHandler() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void startElement(String ns, String ln, String qn, Attributes a) {
/* 179 */       if (!qn.equals("jsp:root") && (!ns.equals("http://java.sun.com/JSP/Page") || !ln.equals("root"))) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 184 */       for (int i = 0; i < a.getLength(); i++) {
/* 185 */         String name = a.getQName(i);
/*     */ 
/*     */         
/* 188 */         if (name.startsWith("xmlns:") && !name.equals("xmlns:jsp")) {
/*     */ 
/*     */           
/* 191 */           String value = a.getValue(i);
/*     */           
/* 193 */           if (!value.equals(PermittedTaglibsTLV.this.uri))
/*     */           {
/*     */ 
/*     */             
/* 197 */             if (!PermittedTaglibsTLV.this.permittedTaglibs.contains(value))
/* 198 */               PermittedTaglibsTLV.this.failed = true; 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\tlv\PermittedTaglibsTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */