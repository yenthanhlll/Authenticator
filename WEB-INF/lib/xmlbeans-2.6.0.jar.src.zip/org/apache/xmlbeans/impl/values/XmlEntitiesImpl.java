/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlENTITIES;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlEntitiesImpl
/*    */   extends XmlListImpl
/*    */   implements XmlENTITIES
/*    */ {
/*    */   public XmlEntitiesImpl() {
/* 25 */     super(XmlENTITIES.type, false);
/*    */   } public XmlEntitiesImpl(SchemaType type, boolean complex) {
/* 27 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlEntitiesImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */