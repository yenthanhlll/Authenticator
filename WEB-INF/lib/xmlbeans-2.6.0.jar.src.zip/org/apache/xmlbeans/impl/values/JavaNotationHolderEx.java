/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaNotationHolderEx
/*     */   extends JavaNotationHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  34 */     return this._schemaType;
/*     */   }
/*     */   public JavaNotationHolderEx(SchemaType type, boolean complex) {
/*  37 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  41 */     return schemaType().getWhiteSpaceRule();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*  46 */     if (_validateOnSet()) {
/*     */       
/*  48 */       if (!check(s, this._schemaType)) {
/*  49 */         throw new XmlValueOutOfRangeException();
/*     */       }
/*  51 */       if (!this._schemaType.matchPatternFacet(s)) {
/*  52 */         throw new XmlValueOutOfRangeException();
/*     */       }
/*     */     } 
/*  55 */     super.set_text(s);
/*     */   }
/*     */   
/*     */   protected void set_notation(String v) {
/*  59 */     set_text(v);
/*     */   }
/*     */   
/*     */   protected void set_xmlanysimple(XmlAnySimpleType value) {
/*     */     QName v;
/*  64 */     if (_validateOnSet()) {
/*     */       
/*  66 */       v = validateLexical(value.getStringValue(), this._schemaType, _voorVc, NamespaceContext.getCurrent());
/*     */       
/*  68 */       if (v != null) {
/*  69 */         validateValue(v, this._schemaType, _voorVc);
/*     */       }
/*     */     } else {
/*  72 */       v = JavaNotationHolder.validateLexical(value.getStringValue(), _voorVc, NamespaceContext.getCurrent());
/*     */     } 
/*  74 */     set_QName(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static QName validateLexical(String v, SchemaType sType, ValidationContext context, PrefixResolver resolver) {
/*  79 */     QName name = JavaQNameHolder.validateLexical(v, context, resolver);
/*     */ 
/*     */     
/*  82 */     if (sType.hasPatternFacet())
/*     */     {
/*  84 */       if (!sType.matchPatternFacet(v))
/*     */       {
/*     */         
/*  87 */         context.invalid("cvc-datatype-valid.1.1", new Object[] { "NOTATION", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*  92 */     check(v, sType);
/*     */     
/*  94 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean check(String v, SchemaType sType) {
/* 100 */     XmlAnySimpleType xmlAnySimpleType1 = sType.getFacet(0);
/* 101 */     if (xmlAnySimpleType1 != null) {
/*     */       
/* 103 */       int m = ((XmlObjectBase)xmlAnySimpleType1).getBigIntegerValue().intValue();
/* 104 */       if (v.length() == m) {
/* 105 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 109 */     XmlAnySimpleType xmlAnySimpleType2 = sType.getFacet(1);
/* 110 */     if (xmlAnySimpleType2 != null) {
/*     */       
/* 112 */       int m = ((XmlObjectBase)xmlAnySimpleType2).getBigIntegerValue().intValue();
/* 113 */       if (v.length() < m) {
/* 114 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 118 */     XmlAnySimpleType xmlAnySimpleType3 = sType.getFacet(2);
/* 119 */     if (xmlAnySimpleType3 != null) {
/*     */       
/* 121 */       int m = ((XmlObjectBase)xmlAnySimpleType3).getBigIntegerValue().intValue();
/* 122 */       if (v.length() > m) {
/* 123 */         return false;
/*     */       }
/*     */     } 
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateValue(QName v, SchemaType sType, ValidationContext context) {
/* 131 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 132 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 134 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/* 135 */         if (v.equals(((XmlObjectBase)arrayOfXmlAnySimpleType[i]).getQNameValue()))
/*     */           return; 
/* 137 */       }  context.invalid("cvc-enumeration-valid", new Object[] { "NOTATION", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaNotationHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */