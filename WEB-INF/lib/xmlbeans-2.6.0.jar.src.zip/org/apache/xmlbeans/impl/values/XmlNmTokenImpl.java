/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlNMTOKEN;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ import org.apache.xmlbeans.impl.common.XMLChar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlNmTokenImpl
/*    */   extends JavaStringHolderEx
/*    */   implements XmlNMTOKEN
/*    */ {
/*    */   public XmlNmTokenImpl() {
/* 28 */     super(XmlNMTOKEN.type, false);
/*    */   } public XmlNmTokenImpl(SchemaType type, boolean complex) {
/* 30 */     super(type, complex);
/*    */   }
/*    */   
/*    */   public static void validateLexical(String v, ValidationContext context) {
/* 34 */     if (!XMLChar.isValidNmtoken(v)) {
/*    */       
/* 36 */       context.invalid("NMTOKEN", new Object[] { v });
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlNmTokenImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */