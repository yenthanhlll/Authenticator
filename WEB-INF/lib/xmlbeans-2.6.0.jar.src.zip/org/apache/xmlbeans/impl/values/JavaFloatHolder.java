/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaFloatHolder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   private float _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  31 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_FLOAT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  39 */     return serialize(this._value);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String serialize(float f) {
/*  44 */     if (f == Float.POSITIVE_INFINITY)
/*  45 */       return "INF"; 
/*  46 */     if (f == Float.NEGATIVE_INFINITY)
/*  47 */       return "-INF"; 
/*  48 */     if (f == Float.NaN) {
/*  49 */       return "NaN";
/*     */     }
/*  51 */     return Float.toString(f);
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*  55 */     set_float(validateLexical(s, _voorVc));
/*     */   }
/*     */ 
/*     */   
/*     */   public static float validateLexical(String v, ValidationContext context) {
/*     */     try {
/*  61 */       return XsTypeConverter.lexFloat(v);
/*     */     }
/*  63 */     catch (NumberFormatException e) {
/*     */       
/*  65 */       context.invalid("float", new Object[] { v });
/*     */       
/*  67 */       return Float.NaN;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void set_nil() {
/*  72 */     this._value = 0.0F;
/*     */   }
/*     */   
/*  75 */   public BigDecimal getBigDecimalValue() { check_dated(); return new BigDecimal(this._value); }
/*  76 */   public double getDoubleValue() { check_dated(); return this._value; } public float getFloatValue() {
/*  77 */     check_dated(); return this._value;
/*     */   }
/*     */   
/*  80 */   protected void set_double(double v) { set_float((float)v); }
/*  81 */   protected void set_float(float v) { this._value = v; }
/*  82 */   protected void set_long(long v) { set_float((float)v); }
/*  83 */   protected void set_BigDecimal(BigDecimal v) { set_float(v.floatValue()); } protected void set_BigInteger(BigInteger v) {
/*  84 */     set_float(v.floatValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int compare_to(XmlObject f) {
/*  89 */     return compare(this._value, ((XmlObjectBase)f).floatValue());
/*     */   }
/*     */ 
/*     */   
/*     */   static int compare(float thisValue, float thatValue) {
/*  94 */     if (thisValue < thatValue) return -1; 
/*  95 */     if (thisValue > thatValue) return 1;
/*     */     
/*  97 */     int thisBits = Float.floatToIntBits(thisValue);
/*  98 */     int thatBits = Float.floatToIntBits(thatValue);
/*     */     
/* 100 */     return (thisBits == thatBits) ? 0 : ((thisBits < thatBits) ? -1 : 1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject f) {
/* 105 */     return (compare(this._value, ((XmlObjectBase)f).floatValue()) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 110 */     return Float.floatToIntBits(this._value);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaFloatHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */