/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlByte;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlByteImpl
/*    */   extends JavaIntHolderEx
/*    */   implements XmlByte
/*    */ {
/*    */   public XmlByteImpl() {
/* 25 */     super(XmlByte.type, false);
/*    */   } public XmlByteImpl(SchemaType type, boolean complex) {
/* 27 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlByteImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */