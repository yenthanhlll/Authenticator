package org.apache.xmlbeans.impl.values;

public class XmlValueNotNillableException extends RuntimeException {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlValueNotNillableException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */