/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.XmlError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlValueOutOfRangeException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public XmlValueOutOfRangeException() {}
/*    */   
/*    */   public XmlValueOutOfRangeException(String message) {
/* 23 */     super(message); } public XmlValueOutOfRangeException(String code, Object[] args) {
/* 24 */     super(XmlError.formattedMessage(code, args));
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlValueOutOfRangeException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */