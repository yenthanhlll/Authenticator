/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlTime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlTimeImpl
/*    */   extends JavaGDateHolderEx
/*    */   implements XmlTime
/*    */ {
/*    */   public XmlTimeImpl() {
/* 25 */     super(XmlTime.type, false);
/*    */   } public XmlTimeImpl(SchemaType type, boolean complex) {
/* 27 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlTimeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */