/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaStringHolderEx
/*     */   extends JavaStringHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  30 */     return this._schemaType;
/*     */   }
/*     */   public JavaStringHolderEx(SchemaType type, boolean complex) {
/*  33 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  37 */     return schemaType().getWhiteSpaceRule();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*  42 */     if (_validateOnSet()) {
/*  43 */       validateLexical(s, this._schemaType, _voorVc);
/*     */     }
/*  45 */     super.set_text(s);
/*     */   }
/*     */   
/*     */   protected boolean is_defaultable_ws(String v) {
/*     */     try {
/*  50 */       validateLexical(v, this._schemaType, _voorVc);
/*  51 */       return false;
/*     */     }
/*  53 */     catch (XmlValueOutOfRangeException e) {
/*  54 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  61 */     if (!sType.matchPatternFacet(v)) {
/*     */       
/*  63 */       context.invalid("cvc-datatype-valid.1.1", new Object[] { "string", v, QNameHelper.readable(sType) });
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  68 */     XmlAnySimpleType xmlAnySimpleType1 = sType.getFacet(0);
/*  69 */     if (xmlAnySimpleType1 != null) {
/*     */       
/*  71 */       int m = ((XmlObjectBase)xmlAnySimpleType1).bigIntegerValue().intValue();
/*  72 */       if (v.length() != m) {
/*     */         
/*  74 */         context.invalid("cvc-length-valid.1.1", new Object[] { "string", new Integer(v.length()), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     XmlAnySimpleType xmlAnySimpleType2 = sType.getFacet(1);
/*  82 */     if (xmlAnySimpleType2 != null) {
/*     */       
/*  84 */       int m = ((XmlObjectBase)xmlAnySimpleType2).bigIntegerValue().intValue();
/*  85 */       if (v.length() < m) {
/*     */         
/*  87 */         context.invalid("cvc-minLength-valid.1.1", new Object[] { "string", new Integer(v.length()), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     XmlAnySimpleType xmlAnySimpleType3 = sType.getFacet(2);
/*  95 */     if (xmlAnySimpleType3 != null) {
/*     */       
/*  97 */       int m = ((XmlObjectBase)xmlAnySimpleType3).bigIntegerValue().intValue();
/*  98 */       if (v.length() > m) {
/*     */         
/* 100 */         context.invalid("cvc-maxLength-valid.1.1", new Object[] { "string", new Integer(v.length()), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 111 */     XmlAnySimpleType[] vals = sType.getEnumerationValues();
/* 112 */     if (vals != null) {
/*     */       
/* 114 */       for (int i = 0; i < vals.length; i++) {
/*     */         
/* 116 */         if (v.equals(vals[i].getStringValue()))
/*     */           return; 
/*     */       } 
/* 119 */       context.invalid("cvc-enumeration-valid", new Object[] { "string", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 126 */     validateLexical(stringValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaStringHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */