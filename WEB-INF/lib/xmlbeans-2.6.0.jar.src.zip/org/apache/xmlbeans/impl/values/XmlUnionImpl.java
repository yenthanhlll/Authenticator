/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.GDate;
/*     */ import org.apache.xmlbeans.GDateSpecification;
/*     */ import org.apache.xmlbeans.GDuration;
/*     */ import org.apache.xmlbeans.GDurationSpecification;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.schema.SchemaTypeImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlUnionImpl
/*     */   extends XmlObjectBase
/*     */   implements XmlAnySimpleType
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   private XmlAnySimpleType _value;
/*     */   private String _textvalue;
/*     */   private static final int JAVA_NUMBER = 47;
/*     */   private static final int JAVA_DATE = 48;
/*     */   private static final int JAVA_CALENDAR = 49;
/*     */   private static final int JAVA_BYTEARRAY = 50;
/*     */   private static final int JAVA_LIST = 51;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public SchemaType schemaType() {
/*     */     return this._schemaType;
/*     */   }
/*     */   
/*     */   public SchemaType instanceType() {
/*     */     check_dated();
/*     */     return (this._value == null) ? null : ((SimpleValue)this._value).instanceType();
/*     */   }
/*     */   
/*     */   public XmlUnionImpl(SchemaType type, boolean complex) {
/*  59 */     this._textvalue = "";
/*     */     this._schemaType = type;
/*     */     initComplexType(complex, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  68 */     return this._textvalue;
/*     */   }
/*     */   protected boolean is_defaultable_ws(String v) {
/*     */     try {
/*  72 */       XmlAnySimpleType savedValue = this._value;
/*  73 */       set_text(v);
/*     */ 
/*     */       
/*  76 */       this._value = savedValue;
/*     */       
/*  78 */       return false;
/*     */     }
/*  80 */     catch (XmlValueOutOfRangeException e) {
/*  81 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*  88 */     if (!this._schemaType.matchPatternFacet(s) && _validateOnSet()) {
/*  89 */       throw new XmlValueOutOfRangeException("cvc-datatype-valid.1.1", new Object[] { "string", s, QNameHelper.readable(this._schemaType) });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  94 */     String original = this._textvalue;
/*  95 */     this._textvalue = s;
/*     */ 
/*     */     
/*  98 */     SchemaType[] members = this._schemaType.getUnionConstituentTypes();
/*  99 */     assert members != null;
/*     */     
/* 101 */     boolean pushed = false;
/*     */     
/* 103 */     if (has_store()) {
/*     */       
/* 105 */       NamespaceContext.push(new NamespaceContext(get_store()));
/* 106 */       pushed = true;
/*     */     } 
/*     */     try {
/*     */       boolean validate;
/* 110 */       for (validate = true; validate || !_validateOnSet(); validate = false) {
/*     */         
/* 112 */         for (int i = 0; i < members.length; i++) {
/*     */ 
/*     */           
/*     */           try {
/*     */ 
/*     */ 
/*     */             
/* 119 */             XmlAnySimpleType newval = ((SchemaTypeImpl)members[i]).newValue(s, validate);
/*     */ 
/*     */             
/* 122 */             if (check((XmlObject)newval, this._schemaType)) {
/*     */ 
/*     */ 
/*     */               
/* 126 */               this._value = newval;
/*     */               return;
/*     */             } 
/* 129 */           } catch (XmlValueOutOfRangeException e) {
/*     */ 
/*     */           
/*     */           }
/* 133 */           catch (Exception e) {
/*     */             
/* 135 */             throw new RuntimeException("Troublesome union exception caused by unexpected " + e, e);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 140 */         if (!validate) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 146 */       if (pushed) {
/* 147 */         NamespaceContext.pop();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 153 */     this._textvalue = original;
/* 154 */     throw new XmlValueOutOfRangeException("cvc-datatype-valid.1.2.3", new Object[] { s, QNameHelper.readable(this._schemaType) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_nil() {
/* 160 */     this._value = null;
/* 161 */     this._textvalue = null;
/*     */   }
/*     */   protected int get_wscanon_rule() {
/* 164 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatValue() {
/* 169 */     check_dated(); return (this._value == null) ? 0.0F : ((SimpleValue)this._value).getFloatValue();
/*     */   }
/*     */   public double getDoubleValue() {
/* 172 */     check_dated(); return (this._value == null) ? 0.0D : ((SimpleValue)this._value).getDoubleValue();
/*     */   }
/*     */   public BigDecimal getBigDecimalValue() {
/* 175 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getBigDecimalValue();
/*     */   }
/*     */   public BigInteger getBigIntegerValue() {
/* 178 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getBigIntegerValue();
/*     */   }
/*     */   public byte getByteValue() {
/* 181 */     check_dated(); return (this._value == null) ? 0 : ((SimpleValue)this._value).getByteValue();
/*     */   }
/*     */   public short getShortValue() {
/* 184 */     check_dated(); return (this._value == null) ? 0 : ((SimpleValue)this._value).getShortValue();
/*     */   }
/*     */   public int getIntValue() {
/* 187 */     check_dated(); return (this._value == null) ? 0 : ((SimpleValue)this._value).getIntValue();
/*     */   }
/*     */   public long getLongValue() {
/* 190 */     check_dated(); return (this._value == null) ? 0L : ((SimpleValue)this._value).getLongValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getByteArrayValue() {
/* 195 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getByteArrayValue();
/*     */   }
/*     */   public boolean getBooleanValue() {
/* 198 */     check_dated(); return (this._value == null) ? false : ((SimpleValue)this._value).getBooleanValue();
/*     */   }
/*     */   public Calendar getCalendarValue() {
/* 201 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getCalendarValue();
/*     */   }
/*     */   public Date getDateValue() {
/* 204 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getDateValue();
/*     */   }
/*     */   public GDate getGDateValue() {
/* 207 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getGDateValue();
/*     */   }
/*     */   public GDuration getGDurationValue() {
/* 210 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getGDurationValue();
/*     */   }
/*     */   public QName getQNameValue() {
/* 213 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getQNameValue();
/*     */   }
/*     */   public List getListValue() {
/* 216 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getListValue();
/*     */   }
/*     */   public List xgetListValue() {
/* 219 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).xgetListValue();
/*     */   }
/*     */   public StringEnumAbstractBase getEnumValue() {
/* 222 */     check_dated(); return (this._value == null) ? null : ((SimpleValue)this._value).getEnumValue();
/*     */   }
/*     */   public String getStringValue() {
/* 225 */     check_dated(); return (this._value == null) ? null : this._value.getStringValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean lexical_overlap(int source, int target) {
/* 235 */     if (source == target) {
/* 236 */       return true;
/*     */     }
/*     */     
/* 239 */     if (source == 2 || target == 2 || source == 12 || target == 12 || source == 6 || target == 6)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 245 */       return true;
/*     */     }
/* 247 */     switch (source) {
/*     */       case 3:
/* 249 */         switch (target) {
/*     */           
/*     */           case 7:
/*     */           case 8:
/* 253 */             return true;
/*     */         } 
/* 255 */         return false;
/*     */       case 4:
/* 257 */         switch (target) {
/*     */           
/*     */           case 3:
/*     */           case 5:
/*     */           case 7:
/*     */           case 8:
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */           case 13:
/*     */           case 18:
/* 268 */             return true;
/*     */         } 
/* 270 */         return false;
/*     */       case 5:
/* 272 */         switch (target) {
/*     */           
/*     */           case 3:
/*     */           case 4:
/*     */           case 7:
/*     */           case 8:
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */           case 18:
/* 282 */             return true;
/*     */         } 
/* 284 */         return false;
/*     */       case 7:
/*     */       case 8:
/* 287 */         switch (target) {
/*     */           
/*     */           case 3:
/*     */           case 4:
/*     */           case 5:
/*     */           case 7:
/*     */           case 8:
/*     */           case 13:
/* 295 */             return true;
/*     */         } 
/* 297 */         return false;
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 18:
/* 302 */         switch (target) {
/*     */           
/*     */           case 4:
/*     */           case 5:
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */           case 18:
/* 310 */             return true;
/*     */         } 
/* 312 */         return false;
/*     */       case 13:
/* 314 */         switch (target) {
/*     */           
/*     */           case 4:
/*     */           case 7:
/*     */           case 8:
/* 319 */             return true;
/*     */         } 
/* 321 */         return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean logical_overlap(SchemaType type, int javacode) {
/* 349 */     assert type.getSimpleVariety() != 2;
/*     */     
/* 351 */     if (javacode <= 46) {
/*     */       
/* 353 */       if (type.getSimpleVariety() != 1) {
/* 354 */         return false;
/*     */       }
/* 356 */       return (type.getPrimitiveType().getBuiltinTypeCode() == javacode);
/*     */     } 
/*     */     
/* 359 */     switch (javacode) {
/*     */ 
/*     */       
/*     */       case 47:
/* 363 */         if (type.getSimpleVariety() != 1) {
/* 364 */           return false;
/*     */         }
/* 366 */         switch (type.getPrimitiveType().getBuiltinTypeCode()) {
/*     */           
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */           case 18:
/*     */           case 20:
/*     */           case 21:
/* 374 */             return true;
/*     */         } 
/* 376 */         return false;
/*     */ 
/*     */       
/*     */       case 48:
/* 380 */         if (type.getSimpleVariety() != 1) {
/* 381 */           return false;
/*     */         }
/* 383 */         switch (type.getPrimitiveType().getBuiltinTypeCode()) {
/*     */           
/*     */           case 14:
/*     */           case 16:
/* 387 */             return true;
/*     */         } 
/* 389 */         return false;
/*     */ 
/*     */       
/*     */       case 49:
/* 393 */         if (type.getSimpleVariety() != 1) {
/* 394 */           return false;
/*     */         }
/* 396 */         switch (type.getPrimitiveType().getBuiltinTypeCode()) {
/*     */           
/*     */           case 14:
/*     */           case 15:
/*     */           case 16:
/*     */           case 17:
/*     */           case 18:
/*     */           case 19:
/*     */           case 20:
/*     */           case 21:
/* 406 */             return true;
/*     */         } 
/* 408 */         return false;
/*     */ 
/*     */ 
/*     */       
/*     */       case 50:
/* 413 */         if (type.getSimpleVariety() != 1) {
/* 414 */           return false;
/*     */         }
/* 416 */         switch (type.getPrimitiveType().getBuiltinTypeCode()) {
/*     */           
/*     */           case 4:
/*     */           case 5:
/* 420 */             return true;
/*     */         } 
/* 422 */         return false;
/*     */ 
/*     */       
/*     */       case 51:
/* 426 */         return (type.getSimpleVariety() == 3);
/*     */     } 
/*     */ 
/*     */     
/* 430 */     assert false : "missing case";
/* 431 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void set_primitive(int typecode, Object val) {
/* 440 */     SchemaType[] members = this._schemaType.getUnionConstituentTypes();
/* 441 */     assert members != null;
/*     */     
/* 443 */     boolean pushed = false;
/* 444 */     if (has_store()) {
/*     */       
/* 446 */       NamespaceContext.push(new NamespaceContext(get_store()));
/* 447 */       pushed = true;
/*     */     } 
/*     */     try {
/*     */       boolean validate;
/* 451 */       for (validate = true; validate || !_validateOnSet(); validate = false) {
/*     */         
/* 453 */         for (int i = 0; i < members.length; i++) {
/*     */ 
/*     */           
/* 456 */           if (logical_overlap(members[i], typecode)) {
/*     */             XmlAnySimpleType newval;
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 462 */               newval = ((SchemaTypeImpl)members[i]).newValue(val, validate);
/*     */             }
/* 464 */             catch (XmlValueOutOfRangeException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 470 */             catch (Exception e) {
/*     */               
/* 472 */               assert false : "Unexpected " + e;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 517 */             this._value = newval;
/* 518 */             this._textvalue = this._value.stringValue();
/*     */             return;
/*     */           } 
/*     */         } 
/* 522 */         if (!validate) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 528 */       if (pushed) {
/* 529 */         NamespaceContext.pop();
/*     */       }
/*     */     } 
/*     */     
/* 533 */     throw new XmlValueOutOfRangeException("cvc-datatype-valid.1.2.3", new Object[] { val.toString(), QNameHelper.readable(this._schemaType) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_boolean(boolean v) {
/* 540 */     set_primitive(3, new Boolean(v));
/*     */   }
/*     */   protected void set_byte(byte v) {
/* 543 */     set_primitive(47, new Byte(v));
/*     */   } protected void set_short(short v) {
/* 545 */     set_primitive(47, new Short(v));
/*     */   } protected void set_int(int v) {
/* 547 */     set_primitive(47, new Integer(v));
/*     */   } protected void set_long(long v) {
/* 549 */     set_primitive(47, new Long(v));
/*     */   } protected void set_float(float v) {
/* 551 */     set_primitive(47, new Float(v));
/*     */   } protected void set_double(double v) {
/* 553 */     set_primitive(47, new Double(v));
/*     */   }
/*     */   protected void set_ByteArray(byte[] b) {
/* 556 */     set_primitive(50, b);
/*     */   } protected void set_hex(byte[] b) {
/* 558 */     set_primitive(50, b);
/*     */   } protected void set_b64(byte[] b) {
/* 560 */     set_primitive(50, b);
/*     */   } protected void set_BigInteger(BigInteger v) {
/* 562 */     set_primitive(47, v);
/*     */   } protected void set_BigDecimal(BigDecimal v) {
/* 564 */     set_primitive(47, v);
/*     */   } protected void set_QName(QName v) {
/* 566 */     set_primitive(7, v);
/*     */   }
/*     */   protected void set_Calendar(Calendar c) {
/* 569 */     set_primitive(49, c);
/*     */   } protected void set_Date(Date d) {
/* 571 */     set_primitive(48, d);
/*     */   }
/*     */   protected void set_GDate(GDateSpecification d) {
/* 574 */     int btc = d.getBuiltinTypeCode();
/* 575 */     if (btc <= 0)
/* 576 */       throw new XmlValueOutOfRangeException(); 
/* 577 */     set_primitive(btc, d);
/*     */   }
/*     */   
/*     */   protected void set_GDuration(GDurationSpecification d) {
/* 581 */     set_primitive(13, d);
/*     */   }
/*     */   protected void set_enum(StringEnumAbstractBase e) {
/* 584 */     set_primitive(12, e);
/*     */   }
/*     */   protected void set_list(List v) {
/* 587 */     set_primitive(51, v);
/*     */   }
/*     */   
/*     */   protected void set_xmlfloat(XmlObject v) {
/* 591 */     set_primitive(9, v);
/*     */   } protected void set_xmldouble(XmlObject v) {
/* 593 */     set_primitive(10, v);
/*     */   } protected void set_xmldecimal(XmlObject v) {
/* 595 */     set_primitive(11, v);
/*     */   } protected void set_xmlduration(XmlObject v) {
/* 597 */     set_primitive(13, v);
/*     */   } protected void set_xmldatetime(XmlObject v) {
/* 599 */     set_primitive(14, v);
/*     */   } protected void set_xmltime(XmlObject v) {
/* 601 */     set_primitive(15, v);
/*     */   } protected void set_xmldate(XmlObject v) {
/* 603 */     set_primitive(16, v);
/*     */   } protected void set_xmlgyearmonth(XmlObject v) {
/* 605 */     set_primitive(17, v);
/*     */   } protected void set_xmlgyear(XmlObject v) {
/* 607 */     set_primitive(18, v);
/*     */   } protected void set_xmlgmonthday(XmlObject v) {
/* 609 */     set_primitive(19, v);
/*     */   } protected void set_xmlgday(XmlObject v) {
/* 611 */     set_primitive(20, v);
/*     */   } protected void set_xmlgmonth(XmlObject v) {
/* 613 */     set_primitive(21, v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean check(XmlObject v, SchemaType sType) {
/* 619 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 620 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 622 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/*     */         
/* 624 */         if (arrayOfXmlAnySimpleType[i].valueEquals(v))
/* 625 */           return true; 
/*     */       } 
/* 627 */       return false;
/*     */     } 
/*     */     
/* 630 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject xmlobj) {
/* 635 */     return this._value.valueEquals(xmlobj);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 640 */     return this._value.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/*     */     try {
/* 647 */       check_dated();
/*     */     }
/* 649 */     catch (Exception e) {
/*     */       
/* 651 */       ctx.invalid("union", new Object[] { "'" + lexical + "' does not match any of the member types for " + QNameHelper.readable(schemaType()) });
/*     */       return;
/*     */     } 
/* 654 */     if (this._value == null) {
/*     */       
/* 656 */       ctx.invalid("union", new Object[] { "'" + lexical + "' does not match any of the member types for " + QNameHelper.readable(schemaType()) });
/*     */       
/*     */       return;
/*     */     } 
/* 660 */     ((XmlObjectBase)this._value).validate_simpleval(lexical, ctx);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlUnionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */