/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecimalHolder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   private BigDecimal _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  31 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_DECIMAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  38 */     return XsTypeConverter.printDecimal(this._value);
/*     */   }
/*     */   protected void set_text(String s) {
/*  41 */     if (_validateOnSet()) {
/*  42 */       validateLexical(s, _voorVc);
/*     */     }
/*     */     try {
/*  45 */       set_BigDecimal(new BigDecimal(s));
/*     */     }
/*  47 */     catch (NumberFormatException e) {
/*     */       
/*  49 */       _voorVc.invalid("decimal", new Object[] { s });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void set_nil() {
/*  54 */     this._value = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateLexical(String v, ValidationContext context) {
/*  66 */     int l = v.length();
/*  67 */     int i = 0;
/*     */     
/*  69 */     if (i < l) {
/*     */       
/*  71 */       int ch = v.charAt(i);
/*     */       
/*  73 */       if (ch == 43 || ch == 45) {
/*  74 */         i++;
/*     */       }
/*     */     } 
/*  77 */     boolean sawDot = false;
/*  78 */     boolean sawDigit = false;
/*     */     
/*  80 */     for (; i < l; i++) {
/*     */       
/*  82 */       int ch = v.charAt(i);
/*     */       
/*  84 */       if (ch == 46) {
/*     */         
/*  86 */         if (sawDot) {
/*     */           
/*  88 */           context.invalid("decimal", new Object[] { "saw '.' more than once: " + v });
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/*  93 */         sawDot = true;
/*     */       }
/*  95 */       else if (ch >= 48 && ch <= 57) {
/*     */         
/*  97 */         sawDigit = true;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 102 */         context.invalid("decimal", new Object[] { "unexpected char '" + ch + "'" });
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     if (!sawDigit) {
/*     */       
/* 110 */       context.invalid("decimal", new Object[] { "expected at least one digit" });
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BigDecimal getBigDecimalValue() {
/* 117 */     check_dated(); return this._value;
/*     */   }
/*     */   protected void set_BigDecimal(BigDecimal v) {
/* 120 */     this._value = v;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int compare_to(XmlObject decimal) {
/* 125 */     return this._value.compareTo(((XmlObjectBase)decimal).bigDecimalValue());
/*     */   }
/*     */   
/*     */   protected boolean equal_to(XmlObject decimal) {
/* 129 */     return (this._value.compareTo(((XmlObjectBase)decimal).bigDecimalValue()) == 0);
/*     */   }
/*     */   
/* 132 */   private static BigInteger _maxlong = BigInteger.valueOf(Long.MAX_VALUE);
/* 133 */   private static BigInteger _minlong = BigInteger.valueOf(Long.MIN_VALUE);
/*     */ 
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 141 */     if (this._value.scale() > 0)
/*     */     {
/* 143 */       if (this._value.setScale(0, 1).compareTo(this._value) != 0) {
/* 144 */         return decimalHashCode();
/*     */       }
/*     */     }
/* 147 */     BigInteger intval = this._value.toBigInteger();
/*     */     
/* 149 */     if (intval.compareTo(_maxlong) > 0 || intval.compareTo(_minlong) < 0)
/*     */     {
/* 151 */       return intval.hashCode();
/*     */     }
/* 153 */     long longval = intval.longValue();
/*     */     
/* 155 */     return (int)((longval >> 32L) * 19L + longval);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int decimalHashCode() {
/* 164 */     assert this._value.scale() > 0;
/*     */ 
/*     */     
/* 167 */     String strValue = this._value.toString();
/*     */     int i;
/* 169 */     for (i = strValue.length() - 1; i >= 0 && 
/* 170 */       strValue.charAt(i) == '0'; i--);
/*     */     
/* 172 */     assert strValue.indexOf('.') < i;
/*     */ 
/*     */     
/* 175 */     return strValue.substring(0, i + 1).hashCode();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaDecimalHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */