/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaDecimalHolderEx
/*     */   extends JavaDecimalHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  32 */     return this._schemaType;
/*     */   }
/*     */   public JavaDecimalHolderEx(SchemaType type, boolean complex) {
/*  35 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*  39 */     if (_validateOnSet()) {
/*  40 */       validateLexical(s, this._schemaType, _voorVc);
/*     */     }
/*  42 */     BigDecimal v = null;
/*     */     try {
/*  44 */       v = new BigDecimal(s);
/*     */     }
/*  46 */     catch (NumberFormatException e) {
/*     */       
/*  48 */       _voorVc.invalid("decimal", new Object[] { s });
/*     */     } 
/*     */     
/*  51 */     if (_validateOnSet()) {
/*  52 */       validateValue(v, this._schemaType, _voorVc);
/*     */     }
/*  54 */     super.set_BigDecimal(v);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_BigDecimal(BigDecimal v) {
/*  59 */     if (_validateOnSet())
/*  60 */       validateValue(v, this._schemaType, _voorVc); 
/*  61 */     super.set_BigDecimal(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  66 */     JavaDecimalHolder.validateLexical(v, context);
/*     */ 
/*     */     
/*  69 */     if (sType.hasPatternFacet())
/*     */     {
/*  71 */       if (!sType.matchPatternFacet(v))
/*     */       {
/*     */         
/*  74 */         context.invalid("cvc-datatype-valid.1.1", new Object[] { "decimal", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateValue(BigDecimal v, SchemaType sType, ValidationContext context) {
/*  87 */     XmlAnySimpleType xmlAnySimpleType1 = sType.getFacet(8);
/*  88 */     if (xmlAnySimpleType1 != null) {
/*     */       
/*  90 */       int scale = ((XmlObjectBase)xmlAnySimpleType1).getBigIntegerValue().intValue();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  95 */         v.setScale(scale);
/*     */       }
/*  97 */       catch (ArithmeticException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 102 */         context.invalid("cvc-fractionDigits-valid", new Object[] { new Integer(v.scale()), v.toString(), new Integer(scale), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     XmlAnySimpleType xmlAnySimpleType2 = sType.getFacet(7);
/* 110 */     if (xmlAnySimpleType2 != null) {
/*     */       
/* 112 */       String temp = v.unscaledValue().toString();
/* 113 */       int tdf = ((XmlObjectBase)xmlAnySimpleType2).getBigIntegerValue().intValue();
/* 114 */       int origLen = temp.length();
/* 115 */       int len = origLen;
/* 116 */       if (origLen > 0) {
/*     */ 
/*     */         
/* 119 */         if (temp.charAt(0) == '-')
/*     */         {
/* 121 */           len--;
/*     */         }
/*     */ 
/*     */         
/* 125 */         int insignificantTrailingZeros = 0;
/* 126 */         int vScale = v.scale();
/* 127 */         int j = origLen - 1;
/* 128 */         for (; temp.charAt(j) == '0' && j > 0 && insignificantTrailingZeros < vScale; 
/* 129 */           j--)
/*     */         {
/* 131 */           insignificantTrailingZeros++;
/*     */         }
/*     */         
/* 134 */         len -= insignificantTrailingZeros;
/*     */       } 
/*     */       
/* 137 */       if (len > tdf) {
/*     */         
/* 139 */         context.invalid("cvc-totalDigits-valid", new Object[] { new Integer(len), v.toString(), new Integer(tdf), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 146 */     XmlAnySimpleType xmlAnySimpleType3 = sType.getFacet(3);
/* 147 */     if (xmlAnySimpleType3 != null) {
/*     */       
/* 149 */       BigDecimal m = ((XmlObjectBase)xmlAnySimpleType3).getBigDecimalValue();
/* 150 */       if (v.compareTo(m) <= 0) {
/*     */         
/* 152 */         context.invalid("cvc-minExclusive-valid", new Object[] { "decimal", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     XmlAnySimpleType xmlAnySimpleType4 = sType.getFacet(4);
/* 160 */     if (xmlAnySimpleType4 != null) {
/*     */       
/* 162 */       BigDecimal m = ((XmlObjectBase)xmlAnySimpleType4).getBigDecimalValue();
/* 163 */       if (v.compareTo(m) < 0) {
/*     */         
/* 165 */         context.invalid("cvc-minInclusive-valid", new Object[] { "decimal", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 172 */     XmlAnySimpleType xmlAnySimpleType5 = sType.getFacet(5);
/* 173 */     if (xmlAnySimpleType5 != null) {
/*     */       
/* 175 */       BigDecimal m = ((XmlObjectBase)xmlAnySimpleType5).getBigDecimalValue();
/* 176 */       if (v.compareTo(m) > 0) {
/*     */         
/* 178 */         context.invalid("cvc-maxInclusive-valid", new Object[] { "decimal", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 185 */     XmlAnySimpleType xmlAnySimpleType6 = sType.getFacet(6);
/* 186 */     if (xmlAnySimpleType6 != null) {
/*     */       
/* 188 */       BigDecimal m = ((XmlObjectBase)xmlAnySimpleType6).getBigDecimalValue();
/* 189 */       if (v.compareTo(m) >= 0) {
/*     */         
/* 191 */         context.invalid("cvc-maxExclusive-valid", new Object[] { "decimal", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 199 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 201 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/* 202 */         if (v.equals(((XmlObjectBase)arrayOfXmlAnySimpleType[i]).getBigDecimalValue()))
/*     */           return; 
/* 204 */       }  context.invalid("cvc-enumeration-valid", new Object[] { "decimal", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 211 */     validateLexical(lexical, schemaType(), ctx);
/* 212 */     validateValue(getBigDecimalValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaDecimalHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */