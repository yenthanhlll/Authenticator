/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlSimpleList;
/*     */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.common.XMLChar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlListImpl
/*     */   extends XmlObjectBase
/*     */   implements XmlAnySimpleType
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   private XmlSimpleList _value;
/*     */   private XmlSimpleList _jvalue;
/*     */   
/*     */   public XmlListImpl(SchemaType type, boolean complex) {
/*  36 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   public SchemaType schemaType() {
/*  39 */     return this._schemaType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String nullAsEmpty(String s) {
/*  52 */     if (s == null)
/*  53 */       return ""; 
/*  54 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String compute_list_text(List xList) {
/*  59 */     if (xList.size() == 0) {
/*  60 */       return "";
/*     */     }
/*  62 */     StringBuffer sb = new StringBuffer();
/*  63 */     sb.append(nullAsEmpty(((SimpleValue)xList.get(0)).getStringValue()));
/*     */     
/*  65 */     for (int i = 1; i < xList.size(); i++) {
/*     */       
/*  67 */       sb.append(' ');
/*  68 */       sb.append(nullAsEmpty(((SimpleValue)xList.get(i)).getStringValue()));
/*     */     } 
/*     */     
/*  71 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  76 */     return compute_list_text((List)this._value);
/*     */   }
/*     */   
/*     */   protected boolean is_defaultable_ws(String v) {
/*     */     try {
/*  81 */       XmlSimpleList savedValue = this._value;
/*  82 */       set_text(v);
/*     */ 
/*     */       
/*  85 */       this._value = savedValue;
/*     */       
/*  87 */       return false;
/*     */     }
/*  89 */     catch (XmlValueOutOfRangeException e) {
/*  90 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*  97 */     if (_validateOnSet() && !this._schemaType.matchPatternFacet(s)) {
/*  98 */       throw new XmlValueOutOfRangeException("cvc-datatype-valid.1.1", new Object[] { "list", s, QNameHelper.readable(this._schemaType) });
/*     */     }
/*     */     
/* 101 */     SchemaType itemType = this._schemaType.getListItemType();
/*     */     
/* 103 */     XmlSimpleList newval = lex(s, itemType, _voorVc, has_store() ? get_store() : null);
/*     */ 
/*     */     
/* 106 */     if (_validateOnSet()) {
/* 107 */       validateValue(newval, this._schemaType, _voorVc);
/*     */     }
/*     */     
/* 110 */     this._value = newval;
/* 111 */     this._jvalue = null;
/*     */   }
/*     */   
/* 114 */   private static final String[] EMPTY_STRINGARRAY = new String[0];
/*     */ 
/*     */   
/*     */   public static String[] split_list(String s) {
/* 118 */     if (s.length() == 0) {
/* 119 */       return EMPTY_STRINGARRAY;
/*     */     }
/* 121 */     List result = new ArrayList();
/* 122 */     int i = 0;
/* 123 */     int start = 0;
/*     */     
/*     */     while (true) {
/* 126 */       if (i < s.length() && XMLChar.isSpace(s.charAt(i))) {
/* 127 */         i++; continue;
/* 128 */       }  if (i >= s.length())
/* 129 */         return (String[])result.toArray((Object[])EMPTY_STRINGARRAY); 
/* 130 */       start = i;
/* 131 */       while (i < s.length() && !XMLChar.isSpace(s.charAt(i)))
/* 132 */         i++; 
/* 133 */       result.add(s.substring(start, i));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static XmlSimpleList lex(String s, SchemaType itemType, ValidationContext ctx, PrefixResolver resolver) {
/* 139 */     String[] parts = split_list(s);
/*     */     
/* 141 */     XmlAnySimpleType[] newArray = new XmlAnySimpleType[parts.length];
/* 142 */     boolean pushed = false;
/* 143 */     if (resolver != null) {
/*     */       
/* 145 */       NamespaceContext.push(new NamespaceContext(resolver));
/* 146 */       pushed = true;
/*     */     } 
/* 148 */     int i = 0;
/*     */     
/*     */     try {
/* 151 */       for (i = 0; i < parts.length; i++) {
/*     */         
/*     */         try
/*     */         {
/* 155 */           newArray[i] = itemType.newValue(parts[i]);
/*     */         }
/* 157 */         catch (XmlValueOutOfRangeException e)
/*     */         {
/* 159 */           ctx.invalid("list", new Object[] { "item '" + parts[i] + "' is not a valid value of " + QNameHelper.readable(itemType) });
/*     */         }
/*     */       
/*     */       } 
/*     */     } finally {
/*     */       
/* 165 */       if (pushed)
/* 166 */         NamespaceContext.pop(); 
/*     */     } 
/* 168 */     return new XmlSimpleList(Arrays.asList(newArray));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_nil() {
/* 173 */     this._value = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List xgetListValue() {
/* 178 */     check_dated();
/* 179 */     return (List)this._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public List getListValue() {
/* 184 */     check_dated();
/* 185 */     if (this._value == null)
/* 186 */       return null; 
/* 187 */     if (this._jvalue != null)
/* 188 */       return (List)this._jvalue; 
/* 189 */     List javaResult = new ArrayList();
/* 190 */     for (int i = 0; i < this._value.size(); i++)
/* 191 */       javaResult.add(java_value((XmlObject)this._value.get(i))); 
/* 192 */     this._jvalue = new XmlSimpleList(javaResult);
/* 193 */     return (List)this._jvalue;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean permits_inner_space(XmlObject obj) {
/* 198 */     switch (((SimpleValue)obj).instanceType().getPrimitiveType().getBuiltinTypeCode()) {
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 6:
/*     */       case 12:
/* 204 */         return true;
/*     */     } 
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean contains_white_space(String s) {
/* 212 */     return (s.indexOf(' ') >= 0 || s.indexOf('\t') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set_list(List list) {
/*     */     XmlSimpleList xList;
/* 220 */     SchemaType itemType = this._schemaType.getListItemType();
/*     */ 
/*     */     
/* 223 */     boolean pushed = false;
/* 224 */     if (has_store()) {
/*     */       
/* 226 */       NamespaceContext.push(new NamespaceContext(get_store()));
/* 227 */       pushed = true;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 232 */       XmlAnySimpleType[] newval = new XmlAnySimpleType[list.size()];
/* 233 */       for (int i = 0; i < list.size(); i++) {
/*     */         
/* 235 */         Object entry = list.get(i);
/* 236 */         if (entry instanceof XmlObject && permits_inner_space(list.get(i))) {
/*     */           
/* 238 */           String stringrep = list.get(i).toString();
/* 239 */           if (contains_white_space(stringrep))
/* 240 */             throw new XmlValueOutOfRangeException(); 
/*     */         } 
/* 242 */         newval[i] = itemType.newValue(entry);
/*     */       } 
/* 244 */       xList = new XmlSimpleList(Arrays.asList(newval));
/*     */     }
/*     */     finally {
/*     */       
/* 248 */       if (pushed) {
/* 249 */         NamespaceContext.pop();
/*     */       }
/*     */     } 
/* 252 */     if (_validateOnSet())
/*     */     {
/*     */       
/* 255 */       validateValue(xList, this._schemaType, _voorVc);
/*     */     }
/*     */     
/* 258 */     this._value = xList;
/* 259 */     this._jvalue = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateValue(XmlSimpleList items, SchemaType sType, ValidationContext context) {
/* 264 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 265 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 267 */       int i = 0; while (true) { if (i < arrayOfXmlAnySimpleType.length) {
/*     */           
/* 269 */           if (equal_xmlLists((List)items, ((XmlObjectBase)arrayOfXmlAnySimpleType[i]).xlistValue()))
/*     */             break;  i++; continue;
/*     */         } 
/* 272 */         context.invalid("cvc-enumeration-valid", new Object[] { "list", items, QNameHelper.readable(sType) });
/*     */         
/*     */         break; }
/*     */     
/*     */     } 
/*     */     
/*     */     XmlAnySimpleType xmlAnySimpleType;
/* 279 */     if ((xmlAnySimpleType = sType.getFacet(0)) != null) {
/*     */       int i;
/* 281 */       if ((i = ((SimpleValue)xmlAnySimpleType).getIntValue()) != items.size())
/*     */       {
/* 283 */         context.invalid("cvc-length-valid.2", new Object[] { items, new Integer(items.size()), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 288 */     if ((xmlAnySimpleType = sType.getFacet(1)) != null) {
/*     */       int i;
/* 290 */       if ((i = ((SimpleValue)xmlAnySimpleType).getIntValue()) > items.size())
/*     */       {
/* 292 */         context.invalid("cvc-minLength-valid.2", new Object[] { items, new Integer(items.size()), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 297 */     if ((xmlAnySimpleType = sType.getFacet(2)) != null) {
/*     */       int i;
/* 299 */       if ((i = ((SimpleValue)xmlAnySimpleType).getIntValue()) < items.size())
/*     */       {
/* 301 */         context.invalid("cvc-maxLength-valid.2", new Object[] { items, new Integer(items.size()), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject obj) {
/* 312 */     return equal_xmlLists((List)this._value, ((XmlObjectBase)obj).xlistValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equal_xmlLists(List a, List b) {
/* 318 */     if (a.size() != b.size())
/* 319 */       return false; 
/* 320 */     for (int i = 0; i < a.size(); i++) {
/*     */       
/* 322 */       if (!a.get(i).equals(b.get(i)))
/* 323 */         return false; 
/*     */     } 
/* 325 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 330 */     if (this._value == null) {
/* 331 */       return 0;
/*     */     }
/*     */     
/* 334 */     int hash = this._value.size();
/* 335 */     int incr = this._value.size() / 9;
/* 336 */     if (incr < 1) {
/* 337 */       incr = 1;
/*     */     }
/*     */     int i;
/* 340 */     for (i = 0; i < this._value.size(); i += incr) {
/*     */       
/* 342 */       hash *= 19;
/* 343 */       hash += this._value.get(i).hashCode();
/*     */     } 
/*     */     
/* 346 */     if (i < this._value.size()) {
/*     */       
/* 348 */       hash *= 19;
/* 349 */       hash += this._value.get(i).hashCode();
/*     */     } 
/*     */     
/* 352 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 357 */     validateValue((XmlSimpleList)xlistValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlListImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */