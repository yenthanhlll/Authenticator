/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlBoolean;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaBooleanHolder
/*    */   extends XmlObjectBase
/*    */ {
/*    */   private boolean _value;
/*    */   
/*    */   public SchemaType schemaType() {
/* 28 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_BOOLEAN;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String compute_text(NamespaceManager nsm) {
/* 35 */     return this._value ? "true" : "false";
/*    */   }
/*    */   protected void set_text(String s) {
/* 38 */     this._value = validateLexical(s, _voorVc);
/*    */   }
/*    */   
/*    */   public static boolean validateLexical(String v, ValidationContext context) {
/* 42 */     if (v.equals("true") || v.equals("1")) {
/* 43 */       return true;
/*    */     }
/* 45 */     if (v.equals("false") || v.equals("0")) {
/* 46 */       return false;
/*    */     }
/* 48 */     context.invalid("boolean", new Object[] { v });
/*    */     
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   protected void set_nil() {
/* 54 */     this._value = false;
/*    */   }
/*    */   public boolean getBooleanValue() {
/* 57 */     check_dated(); return this._value;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void set_boolean(boolean f) {
/* 62 */     this._value = f;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int compare_to(XmlObject i) {
/* 69 */     return (this._value == ((XmlBoolean)i).getBooleanValue()) ? 0 : 2;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equal_to(XmlObject i) {
/* 74 */     return (this._value == ((XmlBoolean)i).getBooleanValue());
/*    */   }
/*    */ 
/*    */   
/*    */   protected int value_hash_code() {
/* 79 */     return this._value ? 957379554 : 676335975;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaBooleanHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */