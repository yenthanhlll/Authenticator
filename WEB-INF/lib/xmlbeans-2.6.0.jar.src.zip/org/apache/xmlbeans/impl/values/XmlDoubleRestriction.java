/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlDouble;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlDoubleRestriction
/*    */   extends JavaDoubleHolderEx
/*    */   implements XmlDouble
/*    */ {
/*    */   public XmlDoubleRestriction(SchemaType type, boolean complex) {
/* 24 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlDoubleRestriction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */