/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlAnyURI;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaUriHolder
/*    */   extends XmlObjectBase
/*    */ {
/*    */   private String _value;
/*    */   
/*    */   public SchemaType schemaType() {
/* 31 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_ANY_URI;
/*    */   }
/*    */   
/*    */   public String compute_text(NamespaceManager nsm) {
/* 35 */     return (this._value == null) ? "" : this._value;
/*    */   }
/*    */   protected void set_text(String s) {
/* 38 */     if (_validateOnSet())
/* 39 */       validateLexical(s, _voorVc); 
/* 40 */     this._value = s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void validateLexical(String v, ValidationContext context) {
/* 47 */     if (v.startsWith("##"))
/* 48 */       context.invalid("anyURI", new Object[] { v }); 
/*    */   }
/*    */   
/*    */   protected void set_nil() {
/* 52 */     this._value = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean equal_to(XmlObject obj) {
/* 59 */     return this._value.equals(((XmlAnyURI)obj).getStringValue());
/*    */   }
/*    */ 
/*    */   
/*    */   protected int value_hash_code() {
/* 64 */     return this._value.hashCode();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaUriHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */