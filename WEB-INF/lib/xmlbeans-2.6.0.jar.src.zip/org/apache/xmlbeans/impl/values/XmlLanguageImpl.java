/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlLanguage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlLanguageImpl
/*    */   extends JavaStringHolderEx
/*    */   implements XmlLanguage
/*    */ {
/*    */   public XmlLanguageImpl() {
/* 24 */     super(XmlLanguage.type, false);
/*    */   } public XmlLanguageImpl(SchemaType type, boolean complex) {
/* 26 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlLanguageImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */