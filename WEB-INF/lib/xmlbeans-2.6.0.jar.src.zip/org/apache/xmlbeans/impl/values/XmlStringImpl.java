package org.apache.xmlbeans.impl.values;

import org.apache.xmlbeans.XmlString;

public class XmlStringImpl extends JavaStringHolder implements XmlString {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlStringImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */