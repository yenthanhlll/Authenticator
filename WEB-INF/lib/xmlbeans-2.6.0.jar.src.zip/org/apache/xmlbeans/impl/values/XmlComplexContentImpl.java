/*      */ package org.apache.xmlbeans.impl.values;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.GDate;
/*      */ import org.apache.xmlbeans.GDateSpecification;
/*      */ import org.apache.xmlbeans.GDuration;
/*      */ import org.apache.xmlbeans.GDurationSpecification;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.SchemaProperty;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SimpleValue;
/*      */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeImpl;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeVisitorImpl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XmlComplexContentImpl
/*      */   extends XmlObjectBase
/*      */ {
/*      */   private SchemaTypeImpl _schemaType;
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   public XmlComplexContentImpl(SchemaType type) {
/*   35 */     this._schemaType = (SchemaTypeImpl)type;
/*   36 */     initComplexType(true, true);
/*      */   }
/*      */   
/*      */   public SchemaType schemaType() {
/*   40 */     return (SchemaType)this._schemaType;
/*      */   }
/*      */ 
/*      */   
/*      */   public String compute_text(NamespaceManager nsm) {
/*   45 */     return null;
/*      */   }
/*      */   
/*      */   protected final void set_String(String v) {
/*   49 */     assert this._schemaType.getContentType() != 2;
/*      */     
/*   51 */     if (this._schemaType.getContentType() != 4 && !this._schemaType.isNoType())
/*      */     {
/*      */       
/*   54 */       throw new IllegalArgumentException("Type does not allow for textual content: " + this._schemaType);
/*      */     }
/*      */ 
/*      */     
/*   58 */     super.set_String(v);
/*      */   }
/*      */ 
/*      */   
/*      */   public void set_text(String str) {
/*   63 */     assert this._schemaType.getContentType() == 4 || this._schemaType.isNoType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void update_from_complex_content() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set_nil() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equal_to(XmlObject complexObject) {
/*   79 */     if (!this._schemaType.equals(complexObject.schemaType())) {
/*   80 */       return false;
/*      */     }
/*      */     
/*   83 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int value_hash_code() {
/*   89 */     throw new IllegalStateException("Complex types cannot be used as hash keys");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeStoreVisitor new_visitor() {
/*   95 */     return (TypeStoreVisitor)new SchemaTypeVisitorImpl(this._schemaType.getContentModel());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean is_child_element_order_sensitive() {
/*  101 */     return schemaType().isOrderSensitive();
/*      */   }
/*      */ 
/*      */   
/*      */   public int get_elementflags(QName eltName) {
/*  106 */     SchemaProperty prop = schemaType().getElementProperty(eltName);
/*  107 */     if (prop == null)
/*  108 */       return 0; 
/*  109 */     if (prop.hasDefault() == 1 || prop.hasFixed() == 1 || prop.hasNillable() == 1)
/*      */     {
/*      */       
/*  112 */       return -1; } 
/*  113 */     return ((prop.hasDefault() == 0) ? 0 : 2) | ((prop.hasFixed() == 0) ? 0 : 4) | ((prop.hasNillable() == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String get_default_attribute_text(QName attrName) {
/*  122 */     return super.get_default_attribute_text(attrName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String get_default_element_text(QName eltName) {
/*  128 */     SchemaProperty prop = schemaType().getElementProperty(eltName);
/*  129 */     if (prop == null)
/*  130 */       return ""; 
/*  131 */     return prop.getDefaultText();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void unionArraySetterHelper(Object[] sources, QName elemName) {
/*  142 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  144 */     TypeStore store = get_store();
/*      */     
/*  146 */     int m = store.count_elements(elemName);
/*      */     
/*  148 */     for (; m > n; m--) {
/*  149 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  151 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  155 */       if (i >= m) {
/*  156 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  158 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  160 */       ((XmlObjectBase)user).objectSet(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected SimpleValue[] arraySetterHelper(int sourcesLength, QName elemName) {
/*  166 */     SimpleValue[] dests = new SimpleValue[sourcesLength];
/*      */     
/*  168 */     TypeStore store = get_store();
/*      */     
/*  170 */     int m = store.count_elements(elemName);
/*      */     
/*  172 */     for (; m > sourcesLength; m--) {
/*  173 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  175 */     for (int i = 0; i < sourcesLength; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  179 */       if (i >= m) {
/*  180 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  182 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  184 */       dests[i] = (SimpleValue)user;
/*      */     } 
/*      */     
/*  187 */     return dests;
/*      */   }
/*      */ 
/*      */   
/*      */   protected SimpleValue[] arraySetterHelper(int sourcesLength, QName elemName, QNameSet set) {
/*  192 */     SimpleValue[] dests = new SimpleValue[sourcesLength];
/*      */     
/*  194 */     TypeStore store = get_store();
/*      */     
/*  196 */     int m = store.count_elements(set);
/*      */     
/*  198 */     for (; m > sourcesLength; m--) {
/*  199 */       store.remove_element(set, m - 1);
/*      */     }
/*  201 */     for (int i = 0; i < sourcesLength; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  205 */       if (i >= m) {
/*  206 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  208 */         user = store.find_element_user(set, i);
/*      */       } 
/*  210 */       dests[i] = (SimpleValue)user;
/*      */     } 
/*      */     
/*  213 */     return dests;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(boolean[] sources, QName elemName) {
/*  218 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  220 */     TypeStore store = get_store();
/*      */     
/*  222 */     int m = store.count_elements(elemName);
/*      */     
/*  224 */     for (; m > n; m--) {
/*  225 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  227 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  231 */       if (i >= m) {
/*  232 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  234 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  236 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(float[] sources, QName elemName) {
/*  242 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  244 */     TypeStore store = get_store();
/*      */     
/*  246 */     int m = store.count_elements(elemName);
/*      */     
/*  248 */     for (; m > n; m--) {
/*  249 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  251 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  255 */       if (i >= m) {
/*  256 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  258 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  260 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(double[] sources, QName elemName) {
/*  266 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  268 */     TypeStore store = get_store();
/*      */     
/*  270 */     int m = store.count_elements(elemName);
/*      */     
/*  272 */     for (; m > n; m--) {
/*  273 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  275 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  279 */       if (i >= m) {
/*  280 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  282 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  284 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(byte[] sources, QName elemName) {
/*  290 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  292 */     TypeStore store = get_store();
/*      */     
/*  294 */     int m = store.count_elements(elemName);
/*      */     
/*  296 */     for (; m > n; m--) {
/*  297 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  299 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  303 */       if (i >= m) {
/*  304 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  306 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  308 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(short[] sources, QName elemName) {
/*  314 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  316 */     TypeStore store = get_store();
/*      */     
/*  318 */     int m = store.count_elements(elemName);
/*      */     
/*  320 */     for (; m > n; m--) {
/*  321 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  323 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  327 */       if (i >= m) {
/*  328 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  330 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  332 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(int[] sources, QName elemName) {
/*  338 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  340 */     TypeStore store = get_store();
/*      */     
/*  342 */     int m = store.count_elements(elemName);
/*      */     
/*  344 */     for (; m > n; m--) {
/*  345 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  347 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  351 */       if (i >= m) {
/*  352 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  354 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  356 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(long[] sources, QName elemName) {
/*  362 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  364 */     TypeStore store = get_store();
/*      */     
/*  366 */     int m = store.count_elements(elemName);
/*      */     
/*  368 */     for (; m > n; m--) {
/*  369 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  371 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  375 */       if (i >= m) {
/*  376 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  378 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  380 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(BigDecimal[] sources, QName elemName) {
/*  386 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  388 */     TypeStore store = get_store();
/*      */     
/*  390 */     int m = store.count_elements(elemName);
/*      */     
/*  392 */     for (; m > n; m--) {
/*  393 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  395 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  399 */       if (i >= m) {
/*  400 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  402 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  404 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(BigInteger[] sources, QName elemName) {
/*  410 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  412 */     TypeStore store = get_store();
/*      */     
/*  414 */     int m = store.count_elements(elemName);
/*      */     
/*  416 */     for (; m > n; m--) {
/*  417 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  419 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  423 */       if (i >= m) {
/*  424 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  426 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  428 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(String[] sources, QName elemName) {
/*  434 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  436 */     TypeStore store = get_store();
/*      */     
/*  438 */     int m = store.count_elements(elemName);
/*      */     
/*  440 */     for (; m > n; m--) {
/*  441 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  443 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  447 */       if (i >= m) {
/*  448 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  450 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  452 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(byte[][] sources, QName elemName) {
/*  458 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  460 */     TypeStore store = get_store();
/*      */     
/*  462 */     int m = store.count_elements(elemName);
/*      */     
/*  464 */     for (; m > n; m--) {
/*  465 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  467 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  471 */       if (i >= m) {
/*  472 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  474 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  476 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(GDate[] sources, QName elemName) {
/*  482 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  484 */     TypeStore store = get_store();
/*      */     
/*  486 */     int m = store.count_elements(elemName);
/*      */     
/*  488 */     for (; m > n; m--) {
/*  489 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  491 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  495 */       if (i >= m) {
/*  496 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  498 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  500 */       ((XmlObjectBase)user).set((GDateSpecification)sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(GDuration[] sources, QName elemName) {
/*  506 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  508 */     TypeStore store = get_store();
/*      */     
/*  510 */     int m = store.count_elements(elemName);
/*      */     
/*  512 */     for (; m > n; m--) {
/*  513 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  515 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  519 */       if (i >= m) {
/*  520 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  522 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  524 */       ((XmlObjectBase)user).set((GDurationSpecification)sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(Calendar[] sources, QName elemName) {
/*  530 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  532 */     TypeStore store = get_store();
/*      */     
/*  534 */     int m = store.count_elements(elemName);
/*      */     
/*  536 */     for (; m > n; m--) {
/*  537 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  539 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  543 */       if (i >= m) {
/*  544 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  546 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  548 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(Date[] sources, QName elemName) {
/*  554 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  556 */     TypeStore store = get_store();
/*      */     
/*  558 */     int m = store.count_elements(elemName);
/*      */     
/*  560 */     for (; m > n; m--) {
/*  561 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  563 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  567 */       if (i >= m) {
/*  568 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  570 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  572 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(QName[] sources, QName elemName) {
/*  578 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  580 */     TypeStore store = get_store();
/*      */     
/*  582 */     int m = store.count_elements(elemName);
/*      */     
/*  584 */     for (; m > n; m--) {
/*  585 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  587 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  591 */       if (i >= m) {
/*  592 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  594 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  596 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(StringEnumAbstractBase[] sources, QName elemName) {
/*  602 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  604 */     TypeStore store = get_store();
/*      */     
/*  606 */     int m = store.count_elements(elemName);
/*      */     
/*  608 */     for (; m > n; m--) {
/*  609 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  611 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  615 */       if (i >= m) {
/*  616 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  618 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  620 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(List[] sources, QName elemName) {
/*  626 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  628 */     TypeStore store = get_store();
/*      */     
/*  630 */     int m = store.count_elements(elemName);
/*      */     
/*  632 */     for (; m > n; m--) {
/*  633 */       store.remove_element(elemName, m - 1);
/*      */     }
/*  635 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  639 */       if (i >= m) {
/*  640 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  642 */         user = store.find_element_user(elemName, i);
/*      */       } 
/*  644 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void unionArraySetterHelper(Object[] sources, QName elemName, QNameSet set) {
/*  650 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  652 */     TypeStore store = get_store();
/*      */     
/*  654 */     int m = store.count_elements(set);
/*      */     
/*  656 */     for (; m > n; m--) {
/*  657 */       store.remove_element(set, m - 1);
/*      */     }
/*  659 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  663 */       if (i >= m) {
/*  664 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  666 */         user = store.find_element_user(set, i);
/*      */       } 
/*  668 */       ((XmlObjectBase)user).objectSet(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(boolean[] sources, QName elemName, QNameSet set) {
/*  674 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  676 */     TypeStore store = get_store();
/*      */     
/*  678 */     int m = store.count_elements(set);
/*      */     
/*  680 */     for (; m > n; m--) {
/*  681 */       store.remove_element(set, m - 1);
/*      */     }
/*  683 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  687 */       if (i >= m) {
/*  688 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  690 */         user = store.find_element_user(set, i);
/*      */       } 
/*  692 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(float[] sources, QName elemName, QNameSet set) {
/*  698 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  700 */     TypeStore store = get_store();
/*      */     
/*  702 */     int m = store.count_elements(set);
/*      */     
/*  704 */     for (; m > n; m--) {
/*  705 */       store.remove_element(set, m - 1);
/*      */     }
/*  707 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  711 */       if (i >= m) {
/*  712 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  714 */         user = store.find_element_user(set, i);
/*      */       } 
/*  716 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(double[] sources, QName elemName, QNameSet set) {
/*  722 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  724 */     TypeStore store = get_store();
/*      */     
/*  726 */     int m = store.count_elements(set);
/*      */     
/*  728 */     for (; m > n; m--) {
/*  729 */       store.remove_element(set, m - 1);
/*      */     }
/*  731 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  735 */       if (i >= m) {
/*  736 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  738 */         user = store.find_element_user(set, i);
/*      */       } 
/*  740 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(byte[] sources, QName elemName, QNameSet set) {
/*  746 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  748 */     TypeStore store = get_store();
/*      */     
/*  750 */     int m = store.count_elements(set);
/*      */     
/*  752 */     for (; m > n; m--) {
/*  753 */       store.remove_element(set, m - 1);
/*      */     }
/*  755 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  759 */       if (i >= m) {
/*  760 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  762 */         user = store.find_element_user(set, i);
/*      */       } 
/*  764 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(short[] sources, QName elemName, QNameSet set) {
/*  770 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  772 */     TypeStore store = get_store();
/*      */     
/*  774 */     int m = store.count_elements(set);
/*      */     
/*  776 */     for (; m > n; m--) {
/*  777 */       store.remove_element(set, m - 1);
/*      */     }
/*  779 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  783 */       if (i >= m) {
/*  784 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  786 */         user = store.find_element_user(set, i);
/*      */       } 
/*  788 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(int[] sources, QName elemName, QNameSet set) {
/*  794 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  796 */     TypeStore store = get_store();
/*      */     
/*  798 */     int m = store.count_elements(set);
/*      */     
/*  800 */     for (; m > n; m--) {
/*  801 */       store.remove_element(set, m - 1);
/*      */     }
/*  803 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  807 */       if (i >= m) {
/*  808 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  810 */         user = store.find_element_user(set, i);
/*      */       } 
/*  812 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(long[] sources, QName elemName, QNameSet set) {
/*  818 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  820 */     TypeStore store = get_store();
/*      */     
/*  822 */     int m = store.count_elements(set);
/*      */     
/*  824 */     for (; m > n; m--) {
/*  825 */       store.remove_element(set, m - 1);
/*      */     }
/*  827 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  831 */       if (i >= m) {
/*  832 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  834 */         user = store.find_element_user(set, i);
/*      */       } 
/*  836 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(BigDecimal[] sources, QName elemName, QNameSet set) {
/*  842 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  844 */     TypeStore store = get_store();
/*      */     
/*  846 */     int m = store.count_elements(set);
/*      */     
/*  848 */     for (; m > n; m--) {
/*  849 */       store.remove_element(set, m - 1);
/*      */     }
/*  851 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  855 */       if (i >= m) {
/*  856 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  858 */         user = store.find_element_user(set, i);
/*      */       } 
/*  860 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(BigInteger[] sources, QName elemName, QNameSet set) {
/*  866 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  868 */     TypeStore store = get_store();
/*      */     
/*  870 */     int m = store.count_elements(set);
/*      */     
/*  872 */     for (; m > n; m--) {
/*  873 */       store.remove_element(set, m - 1);
/*      */     }
/*  875 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  879 */       if (i >= m) {
/*  880 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  882 */         user = store.find_element_user(set, i);
/*      */       } 
/*  884 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(String[] sources, QName elemName, QNameSet set) {
/*  890 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  892 */     TypeStore store = get_store();
/*      */     
/*  894 */     int m = store.count_elements(set);
/*      */     
/*  896 */     for (; m > n; m--) {
/*  897 */       store.remove_element(set, m - 1);
/*      */     }
/*  899 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  903 */       if (i >= m) {
/*  904 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  906 */         user = store.find_element_user(set, i);
/*      */       } 
/*  908 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(byte[][] sources, QName elemName, QNameSet set) {
/*  914 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  916 */     TypeStore store = get_store();
/*      */     
/*  918 */     int m = store.count_elements(set);
/*      */     
/*  920 */     for (; m > n; m--) {
/*  921 */       store.remove_element(set, m - 1);
/*      */     }
/*  923 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  927 */       if (i >= m) {
/*  928 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  930 */         user = store.find_element_user(set, i);
/*      */       } 
/*  932 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(GDate[] sources, QName elemName, QNameSet set) {
/*  938 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  940 */     TypeStore store = get_store();
/*      */     
/*  942 */     int m = store.count_elements(set);
/*      */     
/*  944 */     for (; m > n; m--) {
/*  945 */       store.remove_element(set, m - 1);
/*      */     }
/*  947 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  951 */       if (i >= m) {
/*  952 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  954 */         user = store.find_element_user(set, i);
/*      */       } 
/*  956 */       ((XmlObjectBase)user).set((GDateSpecification)sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(GDuration[] sources, QName elemName, QNameSet set) {
/*  962 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  964 */     TypeStore store = get_store();
/*      */     
/*  966 */     int m = store.count_elements(set);
/*      */     
/*  968 */     for (; m > n; m--) {
/*  969 */       store.remove_element(set, m - 1);
/*      */     }
/*  971 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  975 */       if (i >= m) {
/*  976 */         user = store.add_element_user(elemName);
/*      */       } else {
/*  978 */         user = store.find_element_user(set, i);
/*      */       } 
/*  980 */       ((XmlObjectBase)user).set((GDurationSpecification)sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(Calendar[] sources, QName elemName, QNameSet set) {
/*  986 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/*  988 */     TypeStore store = get_store();
/*      */     
/*  990 */     int m = store.count_elements(set);
/*      */     
/*  992 */     for (; m > n; m--) {
/*  993 */       store.remove_element(set, m - 1);
/*      */     }
/*  995 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/*  999 */       if (i >= m) {
/* 1000 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1002 */         user = store.find_element_user(set, i);
/*      */       } 
/* 1004 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(Date[] sources, QName elemName, QNameSet set) {
/* 1010 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/* 1012 */     TypeStore store = get_store();
/*      */     
/* 1014 */     int m = store.count_elements(set);
/*      */     
/* 1016 */     for (; m > n; m--) {
/* 1017 */       store.remove_element(set, m - 1);
/*      */     }
/* 1019 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/* 1023 */       if (i >= m) {
/* 1024 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1026 */         user = store.find_element_user(set, i);
/*      */       } 
/* 1028 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(QName[] sources, QName elemName, QNameSet set) {
/* 1034 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/* 1036 */     TypeStore store = get_store();
/*      */     
/* 1038 */     int m = store.count_elements(set);
/*      */     
/* 1040 */     for (; m > n; m--) {
/* 1041 */       store.remove_element(set, m - 1);
/*      */     }
/* 1043 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/* 1047 */       if (i >= m) {
/* 1048 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1050 */         user = store.find_element_user(set, i);
/*      */       } 
/* 1052 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(StringEnumAbstractBase[] sources, QName elemName, QNameSet set) {
/* 1058 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/* 1060 */     TypeStore store = get_store();
/*      */     
/* 1062 */     int m = store.count_elements(set);
/*      */     
/* 1064 */     for (; m > n; m--) {
/* 1065 */       store.remove_element(set, m - 1);
/*      */     }
/* 1067 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/* 1071 */       if (i >= m) {
/* 1072 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1074 */         user = store.find_element_user(set, i);
/*      */       } 
/* 1076 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(List[] sources, QName elemName, QNameSet set) {
/* 1082 */     int n = (sources == null) ? 0 : sources.length;
/*      */     
/* 1084 */     TypeStore store = get_store();
/*      */     
/* 1086 */     int m = store.count_elements(set);
/*      */     
/* 1088 */     for (; m > n; m--) {
/* 1089 */       store.remove_element(set, m - 1);
/*      */     }
/* 1091 */     for (int i = 0; i < n; i++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/* 1095 */       if (i >= m) {
/* 1096 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1098 */         user = store.find_element_user(set, i);
/*      */       } 
/* 1100 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(XmlObject[] sources, QName elemName) {
/* 1106 */     TypeStore store = get_store();
/*      */     
/* 1108 */     if (sources == null || sources.length == 0) {
/*      */       
/* 1110 */       int i1 = store.count_elements(elemName);
/* 1111 */       for (; i1 > 0; i1--) {
/* 1112 */         store.remove_element(elemName, 0);
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1118 */     int m = store.count_elements(elemName);
/* 1119 */     int startSrc = 0, startDest = 0; int i;
/* 1120 */     for (i = 0; i < sources.length; i++) {
/*      */       
/* 1122 */       if (!sources[i].isImmutable()) {
/*      */         
/* 1124 */         XmlCursor c = sources[i].newCursor();
/* 1125 */         if (c.toParent() && c.getObject() == this) {
/*      */           
/* 1127 */           c.dispose();
/*      */           break;
/*      */         } 
/* 1130 */         c.dispose();
/*      */       } 
/* 1132 */     }  if (i < sources.length) {
/*      */       
/* 1134 */       TypeStoreUser current = store.find_element_user(elemName, 0);
/* 1135 */       if (current == sources[i]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1143 */         int i1 = 0;
/* 1144 */         for (i1 = 0; i1 < i; i1++) {
/*      */           
/* 1146 */           TypeStoreUser user = store.insert_element_user(elemName, i1);
/* 1147 */           ((XmlObjectBase)user).set(sources[i1]);
/*      */         } 
/* 1149 */         i++; i1++; for (; i < sources.length; i++, i1++) {
/*      */           
/* 1151 */           XmlCursor c = sources[i].isImmutable() ? null : sources[i].newCursor();
/* 1152 */           if (c != null && c.toParent() && c.getObject() == this) {
/*      */             
/* 1154 */             c.dispose();
/* 1155 */             current = store.find_element_user(elemName, i1);
/* 1156 */             if (current == sources[i]) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */           
/* 1166 */           c.dispose();
/*      */           
/* 1168 */           TypeStoreUser user = store.insert_element_user(elemName, i1);
/* 1169 */           ((XmlObjectBase)user).set(sources[i]);
/*      */           continue;
/*      */         } 
/* 1172 */         startDest = i1;
/* 1173 */         startSrc = i;
/* 1174 */         m = store.count_elements(elemName);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1190 */     for (int j = i; j < sources.length; j++) {
/*      */       
/* 1192 */       TypeStoreUser user = store.add_element_user(elemName);
/* 1193 */       ((XmlObjectBase)user).set(sources[j]);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1199 */     int n = i;
/* 1200 */     for (; m > n - startSrc + startDest; m--) {
/* 1201 */       store.remove_element(elemName, m - 1);
/*      */     }
/*      */     int k;
/* 1204 */     for (i = startSrc, k = startDest; i < n; i++, k++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/* 1208 */       if (k >= m) {
/* 1209 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1211 */         user = store.find_element_user(elemName, k);
/*      */       } 
/* 1213 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void arraySetterHelper(XmlObject[] sources, QName elemName, QNameSet set) {
/* 1224 */     TypeStore store = get_store();
/*      */     
/* 1226 */     if (sources == null || sources.length == 0) {
/*      */       
/* 1228 */       int i1 = store.count_elements(set);
/* 1229 */       for (; i1 > 0; i1--) {
/* 1230 */         store.remove_element(set, 0);
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1236 */     int m = store.count_elements(set);
/* 1237 */     int startSrc = 0, startDest = 0; int i;
/* 1238 */     for (i = 0; i < sources.length; i++) {
/*      */       
/* 1240 */       if (!sources[i].isImmutable()) {
/*      */         
/* 1242 */         XmlCursor c = sources[i].newCursor();
/* 1243 */         if (c.toParent() && c.getObject() == this) {
/*      */           
/* 1245 */           c.dispose();
/*      */           break;
/*      */         } 
/* 1248 */         c.dispose();
/*      */       } 
/* 1250 */     }  if (i < sources.length) {
/*      */       
/* 1252 */       TypeStoreUser current = store.find_element_user(set, 0);
/* 1253 */       if (current == sources[i]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1261 */         int i1 = 0;
/* 1262 */         for (i1 = 0; i1 < i; i1++) {
/*      */           
/* 1264 */           TypeStoreUser user = store.insert_element_user(set, elemName, i1);
/* 1265 */           ((XmlObjectBase)user).set(sources[i1]);
/*      */         } 
/* 1267 */         i++; i1++; for (; i < sources.length; i++, i1++) {
/*      */           
/* 1269 */           XmlCursor c = sources[i].isImmutable() ? null : sources[i].newCursor();
/* 1270 */           if (c != null && c.toParent() && c.getObject() == this) {
/*      */             
/* 1272 */             c.dispose();
/* 1273 */             current = store.find_element_user(set, i1);
/* 1274 */             if (current == sources[i]) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */           
/* 1284 */           c.dispose();
/*      */           
/* 1286 */           TypeStoreUser user = store.insert_element_user(set, elemName, i1);
/* 1287 */           ((XmlObjectBase)user).set(sources[i]);
/*      */           continue;
/*      */         } 
/* 1290 */         startDest = i1;
/* 1291 */         startSrc = i;
/* 1292 */         m = store.count_elements(elemName);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1308 */     for (int j = i; j < sources.length; j++) {
/*      */       
/* 1310 */       TypeStoreUser user = store.add_element_user(elemName);
/* 1311 */       ((XmlObjectBase)user).set(sources[j]);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1317 */     int n = i;
/* 1318 */     for (; m > n - startSrc + startDest; m--) {
/* 1319 */       store.remove_element(set, m - 1);
/*      */     }
/*      */     int k;
/* 1322 */     for (i = startSrc, k = startDest; i < n; i++, k++) {
/*      */       TypeStoreUser user;
/*      */ 
/*      */       
/* 1326 */       if (k >= m) {
/* 1327 */         user = store.add_element_user(elemName);
/*      */       } else {
/* 1329 */         user = store.find_element_user(set, k);
/*      */       } 
/* 1331 */       ((XmlObjectBase)user).set(sources[i]);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlComplexContentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */