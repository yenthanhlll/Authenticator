package org.apache.xmlbeans.impl.values;

import org.apache.xmlbeans.XmlInt;

public class XmlIntImpl extends JavaIntHolder implements XmlInt {}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlIntImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */