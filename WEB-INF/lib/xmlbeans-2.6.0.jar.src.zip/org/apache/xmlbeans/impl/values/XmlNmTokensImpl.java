/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlNMTOKENS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlNmTokensImpl
/*    */   extends XmlListImpl
/*    */   implements XmlNMTOKENS
/*    */ {
/*    */   public XmlNmTokensImpl() {
/* 25 */     super(XmlNMTOKENS.type, false);
/*    */   } public XmlNmTokensImpl(SchemaType type, boolean complex) {
/* 27 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlNmTokensImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */