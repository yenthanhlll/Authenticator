/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlPositiveInteger;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaIntegerHolderEx
/*     */   extends JavaIntegerHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public JavaIntegerHolderEx(SchemaType type, boolean complex) {
/*  30 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaType schemaType() {
/*  36 */     return this._schemaType;
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*  40 */     BigInteger v = lex(s, _voorVc);
/*     */     
/*  42 */     if (_validateOnSet()) {
/*  43 */       validateValue(v, this._schemaType, _voorVc);
/*     */     }
/*  45 */     if (_validateOnSet()) {
/*  46 */       validateLexical(s, this._schemaType, _voorVc);
/*     */     }
/*  48 */     super.set_BigInteger(v);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_BigInteger(BigInteger v) {
/*  53 */     if (_validateOnSet()) {
/*  54 */       validateValue(v, this._schemaType, _voorVc);
/*     */     }
/*  56 */     super.set_BigInteger(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  61 */     JavaDecimalHolder.validateLexical(v, context);
/*  62 */     if (v.lastIndexOf('.') >= 0) {
/*  63 */       context.invalid("integer", new Object[] { v });
/*     */     }
/*     */ 
/*     */     
/*  67 */     if (sType.hasPatternFacet())
/*     */     {
/*  69 */       if (!sType.matchPatternFacet(v))
/*     */       {
/*  71 */         context.invalid("cvc-datatype-valid.1.1", new Object[] { "integer", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateValue(BigInteger v, SchemaType sType, ValidationContext context) {
/*  80 */     XmlPositiveInteger td = (XmlPositiveInteger)sType.getFacet(7);
/*  81 */     if (td != null) {
/*     */       
/*  83 */       String temp = v.toString();
/*  84 */       int len = temp.length();
/*  85 */       if (len > 0 && temp.charAt(0) == '-')
/*  86 */         len--; 
/*  87 */       if (len > td.getBigIntegerValue().intValue()) {
/*     */         
/*  89 */         context.invalid("cvc-totalDigits-valid", new Object[] { new Integer(len), temp, new Integer(td.getBigIntegerValue().intValue()), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/*  96 */     XmlAnySimpleType xmlAnySimpleType1 = sType.getFacet(3);
/*  97 */     if (xmlAnySimpleType1 != null) {
/*     */       
/*  99 */       BigInteger m = getBigIntegerValue((XmlObject)xmlAnySimpleType1);
/* 100 */       if (v.compareTo(m) <= 0) {
/*     */         
/* 102 */         context.invalid("cvc-minExclusive-valid", new Object[] { "integer", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     XmlAnySimpleType xmlAnySimpleType2 = sType.getFacet(4);
/* 110 */     if (xmlAnySimpleType2 != null) {
/*     */       
/* 112 */       BigInteger m = getBigIntegerValue((XmlObject)xmlAnySimpleType2);
/* 113 */       if (v.compareTo(m) < 0) {
/*     */         
/* 115 */         context.invalid("cvc-minInclusive-valid", new Object[] { "integer", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     XmlAnySimpleType xmlAnySimpleType3 = sType.getFacet(5);
/* 123 */     if (xmlAnySimpleType3 != null) {
/*     */       
/* 125 */       BigInteger m = getBigIntegerValue((XmlObject)xmlAnySimpleType3);
/* 126 */       if (v.compareTo(m) > 0) {
/*     */         
/* 128 */         context.invalid("cvc-maxInclusive-valid", new Object[] { "integer", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 135 */     XmlAnySimpleType xmlAnySimpleType4 = sType.getFacet(6);
/* 136 */     if (xmlAnySimpleType4 != null) {
/*     */       
/* 138 */       BigInteger m = getBigIntegerValue((XmlObject)xmlAnySimpleType4);
/* 139 */       if (v.compareTo(m) >= 0) {
/*     */         
/* 141 */         context.invalid("cvc-maxExclusive-valid", new Object[] { "integer", v, m, QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 149 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 151 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/*     */         
/* 153 */         if (v.equals(getBigIntegerValue((XmlObject)arrayOfXmlAnySimpleType[i])))
/*     */           return; 
/*     */       } 
/* 156 */       context.invalid("cvc-enumeration-valid", new Object[] { "integer", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static BigInteger getBigIntegerValue(XmlObject o) {
/* 163 */     SchemaType s = o.schemaType();
/* 164 */     switch (s.getDecimalSize()) {
/*     */       
/*     */       case 1000001:
/* 167 */         return ((XmlObjectBase)o).bigDecimalValue().toBigInteger();
/*     */       case 1000000:
/* 169 */         return ((XmlObjectBase)o).bigIntegerValue();
/*     */     } 
/* 171 */     throw new IllegalStateException("Bad facet type for Big Int: " + s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 177 */     validateLexical(lexical, schemaType(), ctx);
/* 178 */     validateValue(getBigIntegerValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaIntegerHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */