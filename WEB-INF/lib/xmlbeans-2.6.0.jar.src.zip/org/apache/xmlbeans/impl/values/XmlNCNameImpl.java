/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlNCName;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ import org.apache.xmlbeans.impl.common.XMLChar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlNCNameImpl
/*    */   extends JavaStringHolderEx
/*    */   implements XmlNCName
/*    */ {
/*    */   public XmlNCNameImpl() {
/* 27 */     super(XmlNCName.type, false);
/*    */   } public XmlNCNameImpl(SchemaType type, boolean complex) {
/* 29 */     super(type, complex);
/*    */   }
/*    */   
/*    */   public static void validateLexical(String v, ValidationContext context) {
/* 33 */     if (!XMLChar.isValidNCName(v)) {
/*    */       
/* 35 */       context.invalid("NCName", new Object[] { v });
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlNCNameImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */