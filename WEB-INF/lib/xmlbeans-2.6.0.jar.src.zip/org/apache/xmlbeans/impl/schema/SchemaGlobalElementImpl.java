/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaComponent;
/*     */ import org.apache.xmlbeans.SchemaGlobalElement;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaGlobalElementImpl
/*     */   extends SchemaLocalElementImpl
/*     */   implements SchemaGlobalElement
/*     */ {
/*  30 */   private Set _sgMembers = new LinkedHashSet();
/*  31 */   private static final QName[] _namearray = new QName[0];
/*     */   
/*     */   private boolean _finalExt;
/*     */   
/*     */   private boolean _finalRest;
/*     */   
/*     */   private SchemaContainer _container;
/*     */   
/*     */   private String _filename;
/*     */   
/*     */   private String _parseTNS;
/*     */   
/*     */   private boolean _chameleon;
/*     */   private SchemaGlobalElement.Ref _sg;
/*     */   private SchemaGlobalElement.Ref _selfref;
/*     */   
/*     */   public SchemaTypeSystem getTypeSystem() {
/*  48 */     return this._container.getTypeSystem();
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaContainer getContainer() {
/*  53 */     return this._container;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/*  58 */     return this._filename;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFilename(String filename) {
/*  63 */     this._filename = filename;
/*     */   }
/*     */ 
/*     */   
/*     */   void setFinal(boolean finalExt, boolean finalRest) {
/*  68 */     mutate(); this._finalExt = finalExt; this._finalRest = finalRest;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getComponentType() {
/*  73 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalElement substitutionGroup() {
/*  78 */     return (this._sg == null) ? null : this._sg.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSubstitutionGroup(SchemaGlobalElement.Ref sg) {
/*  83 */     this._sg = sg;
/*     */   }
/*     */ 
/*     */   
/*     */   public QName[] substitutionGroupMembers() {
/*  88 */     return (QName[])this._sgMembers.toArray((Object[])_namearray);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSubstitutionGroupMember(QName name) {
/*  93 */     mutate(); this._sgMembers.add(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean finalExtension() {
/*  99 */     return this._finalExt;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean finalRestriction() {
/* 104 */     return this._finalRest;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParseContext(XmlObject parseObject, String targetNamespace, boolean chameleon) {
/* 109 */     this._parseObject = parseObject;
/* 110 */     this._parseTNS = targetNamespace;
/* 111 */     this._chameleon = chameleon;
/*     */   }
/*     */   
/*     */   public XmlObject getParseObject() {
/* 115 */     return this._parseObject;
/*     */   }
/*     */   public String getTargetNamespace() {
/* 118 */     return this._parseTNS;
/*     */   }
/*     */   public String getChameleonNamespace() {
/* 121 */     return this._chameleon ? this._parseTNS : null;
/*     */   } public SchemaGlobalElementImpl(SchemaContainer container) {
/* 123 */     this._selfref = new SchemaGlobalElement.Ref(this);
/*     */     this._container = container;
/*     */   } public SchemaGlobalElement.Ref getRef() {
/* 126 */     return this._selfref;
/*     */   }
/*     */   public SchemaComponent.Ref getComponentRef() {
/* 129 */     return (SchemaComponent.Ref)getRef();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaGlobalElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */