/*    */ package org.apache.xmlbeans.impl.schema;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.apache.xmlbeans.ResourceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassLoaderResourceLoader
/*    */   implements ResourceLoader
/*    */ {
/*    */   ClassLoader _classLoader;
/*    */   
/*    */   public ClassLoaderResourceLoader(ClassLoader classLoader) {
/* 28 */     this._classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getResourceAsStream(String resourceName) {
/* 33 */     return this._classLoader.getResourceAsStream(resourceName);
/*    */   }
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\ClassLoaderResourceLoader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */