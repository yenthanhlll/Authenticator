/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaDependencies
/*     */ {
/*     */   private Map _dependencies;
/*     */   private Map _contributions;
/*     */   
/*     */   void registerDependency(String source, String target) {
/*  32 */     Set depSet = (Set)this._dependencies.get(target);
/*  33 */     if (depSet == null) {
/*     */       
/*  35 */       depSet = new HashSet();
/*  36 */       this._dependencies.put(target, depSet);
/*     */     } 
/*  38 */     depSet.add(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set computeTransitiveClosure(List modifiedNamespaces) {
/*  51 */     List nsList = new ArrayList(modifiedNamespaces);
/*  52 */     Set result = new HashSet(modifiedNamespaces);
/*  53 */     for (int i = 0; i < nsList.size(); i++) {
/*     */       
/*  55 */       Set deps = (Set)this._dependencies.get(nsList.get(i));
/*  56 */       if (deps != null)
/*     */       {
/*  58 */         for (Iterator it = deps.iterator(); it.hasNext(); ) {
/*     */           
/*  60 */           String ns = it.next();
/*  61 */           if (!result.contains(ns)) {
/*     */             
/*  63 */             nsList.add(ns);
/*  64 */             result.add(ns);
/*     */           } 
/*     */         }  } 
/*     */     } 
/*  68 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaDependencies() {
/*  73 */     this._dependencies = new HashMap();
/*  74 */     this._contributions = new HashMap();
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaDependencies(SchemaDependencies base, Set updatedNs) {
/*  79 */     this._dependencies = new HashMap();
/*  80 */     this._contributions = new HashMap();
/*  81 */     for (Iterator iterator1 = base._dependencies.keySet().iterator(); iterator1.hasNext(); ) {
/*     */       
/*  83 */       String target = iterator1.next();
/*  84 */       if (updatedNs.contains(target))
/*     */         continue; 
/*  86 */       Set depSet = new HashSet();
/*  87 */       this._dependencies.put(target, depSet);
/*  88 */       Set baseDepSet = (Set)base._dependencies.get(target);
/*  89 */       for (Iterator it2 = baseDepSet.iterator(); it2.hasNext(); ) {
/*     */         
/*  91 */         String source = it2.next();
/*  92 */         if (updatedNs.contains(source))
/*     */           continue; 
/*  94 */         depSet.add(source);
/*     */       } 
/*     */     } 
/*  97 */     for (Iterator it = base._contributions.keySet().iterator(); it.hasNext(); ) {
/*     */       
/*  99 */       String ns = it.next();
/* 100 */       if (updatedNs.contains(ns))
/*     */         continue; 
/* 102 */       List fileList = new ArrayList();
/* 103 */       this._contributions.put(ns, fileList);
/* 104 */       List baseFileList = (List)base._contributions.get(ns);
/* 105 */       for (Iterator it2 = baseFileList.iterator(); it2.hasNext();) {
/* 106 */         fileList.add(it2.next());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void registerContribution(String ns, String fileURL) {
/* 119 */     List fileList = (List)this._contributions.get(ns);
/* 120 */     if (fileList == null) {
/*     */       
/* 122 */       fileList = new ArrayList();
/* 123 */       this._contributions.put(ns, fileList);
/*     */     } 
/* 125 */     fileList.add(fileURL);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isFileRepresented(String fileURL) {
/* 130 */     for (Iterator it = this._contributions.values().iterator(); it.hasNext(); ) {
/*     */       
/* 132 */       List fileList = it.next();
/* 133 */       if (fileList.contains(fileURL))
/* 134 */         return true; 
/*     */     } 
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   List getFilesTouched(Set updatedNs) {
/* 141 */     List result = new ArrayList();
/* 142 */     for (Iterator it = updatedNs.iterator(); it.hasNext();)
/*     */     {
/* 144 */       result.addAll((List)this._contributions.get(it.next()));
/*     */     }
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   List getNamespacesTouched(Set modifiedFiles) {
/* 151 */     List result = new ArrayList();
/* 152 */     for (Iterator it = this._contributions.keySet().iterator(); it.hasNext(); ) {
/*     */       
/* 154 */       String ns = it.next();
/* 155 */       List files = (List)this._contributions.get(ns);
/* 156 */       for (int i = 0; i < files.size(); i++) {
/* 157 */         if (modifiedFiles.contains(files.get(i)))
/* 158 */           result.add(ns); 
/*     */       } 
/* 160 */     }  return result;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaDependencies.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */