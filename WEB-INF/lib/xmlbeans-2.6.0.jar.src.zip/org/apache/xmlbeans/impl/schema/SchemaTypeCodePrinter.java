/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.nio.charset.CharacterCodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.InterfaceExtension;
/*      */ import org.apache.xmlbeans.PrePostExtension;
/*      */ import org.apache.xmlbeans.SchemaCodePrinter;
/*      */ import org.apache.xmlbeans.SchemaProperty;
/*      */ import org.apache.xmlbeans.SchemaStringEnumEntry;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeSystem;
/*      */ import org.apache.xmlbeans.SystemProperties;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.common.NameUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SchemaTypeCodePrinter
/*      */   implements SchemaCodePrinter
/*      */ {
/*      */   Writer _writer;
/*      */   int _indent;
/*      */   boolean _useJava15;
/*   53 */   static final String LINE_SEPARATOR = (SystemProperties.getProperty("line.separator") == null) ? "\n" : SystemProperties.getProperty("line.separator");
/*      */   
/*      */   static final String MAX_SPACES = "                                        ";
/*      */   
/*      */   static final int INDENT_INCREMENT = 4;
/*      */   
/*      */   public static final String INDEX_CLASSNAME = "TypeSystemHolder";
/*      */   
/*      */   private static final int NOTHING = 1;
/*      */   private static final int ADD_NEW_VALUE = 3;
/*      */   private static final int THROW_EXCEPTION = 4;
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   public static void printTypeImpl(Writer writer, SchemaType sType, XmlOptions opt) throws IOException {
/*   67 */     getPrinter(opt).printTypeImpl(writer, sType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void printType(Writer writer, SchemaType sType, XmlOptions opt) throws IOException {
/*   74 */     getPrinter(opt).printType(writer, sType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void printLoader(Writer writer, SchemaTypeSystem system, XmlOptions opt) throws IOException {
/*   82 */     getPrinter(opt).printLoader(writer, system);
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaCodePrinter getPrinter(XmlOptions opt) {
/*   87 */     Object printer = XmlOptions.safeGet(opt, "SCHEMA_CODE_PRINTER");
/*      */     
/*   89 */     if (printer == null || !(printer instanceof SchemaCodePrinter))
/*      */     {
/*   91 */       printer = new SchemaTypeCodePrinter(opt);
/*      */     }
/*   93 */     return (SchemaCodePrinter)printer;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaTypeCodePrinter(XmlOptions opt) {
/*   98 */     this._indent = 0;
/*      */     
/*  100 */     String genversion = null;
/*      */     
/*  102 */     if (opt != null && XmlOptions.hasOption(opt, "GENERATE_JAVA_VERSION")) {
/*  103 */       genversion = (String)opt.get("GENERATE_JAVA_VERSION");
/*      */     }
/*  105 */     if (genversion == null) {
/*  106 */       genversion = "1.4";
/*      */     }
/*  108 */     this._useJava15 = "1.5".equals(genversion);
/*      */   }
/*      */ 
/*      */   
/*      */   void indent() {
/*  113 */     this._indent += 4;
/*      */   }
/*      */ 
/*      */   
/*      */   void outdent() {
/*  118 */     this._indent -= 4;
/*      */   }
/*      */ 
/*      */   
/*      */   String encodeString(String s) {
/*  123 */     StringBuffer sb = new StringBuffer();
/*      */     
/*  125 */     sb.append('"');
/*      */     
/*  127 */     for (int i = 0; i < s.length(); i++) {
/*      */       
/*  129 */       char ch = s.charAt(i);
/*      */       
/*  131 */       if (ch == '"') {
/*      */         
/*  133 */         sb.append('\\');
/*  134 */         sb.append('"');
/*      */       }
/*  136 */       else if (ch == '\\') {
/*      */         
/*  138 */         sb.append('\\');
/*  139 */         sb.append('\\');
/*      */       }
/*  141 */       else if (ch == '\r') {
/*      */         
/*  143 */         sb.append('\\');
/*  144 */         sb.append('r');
/*      */       }
/*  146 */       else if (ch == '\n') {
/*      */         
/*  148 */         sb.append('\\');
/*  149 */         sb.append('n');
/*      */       }
/*  151 */       else if (ch == '\t') {
/*      */         
/*  153 */         sb.append('\\');
/*  154 */         sb.append('t');
/*      */       } else {
/*      */         
/*  157 */         sb.append(ch);
/*      */       } 
/*      */     } 
/*  160 */     sb.append('"');
/*      */     
/*  162 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   void emit(String s) throws IOException {
/*  167 */     int indent = this._indent;
/*      */     
/*  169 */     if (indent > "                                        ".length() / 2) {
/*  170 */       indent = "                                        ".length() / 4 + indent / 2;
/*      */     }
/*  172 */     if (indent > "                                        ".length()) {
/*  173 */       indent = "                                        ".length();
/*      */     }
/*  175 */     this._writer.write("                                        ".substring(0, indent));
/*      */     
/*      */     try {
/*  178 */       this._writer.write(s);
/*      */     }
/*  180 */     catch (CharacterCodingException cce) {
/*      */       
/*  182 */       this._writer.write(makeSafe(s));
/*      */     } 
/*  184 */     this._writer.write(LINE_SEPARATOR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String makeSafe(String s) {
/*  192 */     Charset charset = Charset.forName(System.getProperty("file.encoding"));
/*  193 */     if (charset == null)
/*  194 */       throw new IllegalStateException("Default character set is null!"); 
/*  195 */     CharsetEncoder cEncoder = charset.newEncoder();
/*  196 */     StringBuffer result = new StringBuffer();
/*      */     int i;
/*  198 */     for (i = 0; i < s.length(); i++) {
/*      */       
/*  200 */       char c = s.charAt(i);
/*  201 */       if (!cEncoder.canEncode(c))
/*      */         break; 
/*      */     } 
/*  204 */     for (; i < s.length(); i++) {
/*      */       
/*  206 */       char c = s.charAt(i);
/*  207 */       if (cEncoder.canEncode(c)) {
/*  208 */         result.append(c);
/*      */       } else {
/*      */         
/*  211 */         String hexValue = Integer.toHexString(c);
/*  212 */         switch (hexValue.length()) {
/*      */           
/*      */           case 1:
/*  215 */             result.append("\\u000").append(hexValue); break;
/*      */           case 2:
/*  217 */             result.append("\\u00").append(hexValue); break;
/*      */           case 3:
/*  219 */             result.append("\\u0").append(hexValue); break;
/*      */           case 4:
/*  221 */             result.append("\\u").append(hexValue); break;
/*      */           default:
/*  223 */             throw new IllegalStateException();
/*      */         } 
/*      */       } 
/*      */     } 
/*  227 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public void printType(Writer writer, SchemaType sType) throws IOException {
/*  232 */     this._writer = writer;
/*  233 */     printTopComment(sType);
/*  234 */     printPackage(sType, true);
/*  235 */     emit("");
/*  236 */     printInnerType(sType, sType.getTypeSystem());
/*  237 */     this._writer.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void printTypeImpl(Writer writer, SchemaType sType) throws IOException {
/*  243 */     this._writer = writer;
/*  244 */     printTopComment(sType);
/*  245 */     printPackage(sType, false);
/*  246 */     printInnerTypeImpl(sType, sType.getTypeSystem(), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String findJavaType(SchemaType sType) {
/*  255 */     while (sType.getFullJavaName() == null) {
/*  256 */       sType = sType.getBaseType();
/*      */     }
/*  258 */     return sType.getFullJavaName();
/*      */   }
/*      */ 
/*      */   
/*      */   static String prettyQName(QName qname) {
/*  263 */     String result = qname.getLocalPart();
/*  264 */     if (qname.getNamespaceURI() != null)
/*  265 */       result = result + "(@" + qname.getNamespaceURI() + ")"; 
/*  266 */     return result;
/*      */   }
/*      */   void printInnerTypeJavaDoc(SchemaType sType) throws IOException {
/*      */     SchemaType[] members;
/*      */     int i;
/*  271 */     QName name = sType.getName();
/*  272 */     if (name == null)
/*      */     {
/*  274 */       if (sType.isDocumentType()) {
/*  275 */         name = sType.getDocumentElementName();
/*  276 */       } else if (sType.isAttributeType()) {
/*  277 */         name = sType.getAttributeTypeAttributeName();
/*  278 */       } else if (sType.getContainerField() != null) {
/*  279 */         name = sType.getContainerField().getName();
/*      */       } 
/*      */     }
/*  282 */     emit("/**");
/*  283 */     if (sType.isDocumentType()) {
/*  284 */       emit(" * A document containing one " + prettyQName(name) + " element.");
/*  285 */     } else if (sType.isAttributeType()) {
/*  286 */       emit(" * A document containing one " + prettyQName(name) + " attribute.");
/*  287 */     } else if (name != null) {
/*  288 */       emit(" * An XML " + prettyQName(name) + ".");
/*      */     } else {
/*  290 */       emit(" * An anonymous inner XML type.");
/*  291 */     }  emit(" *");
/*  292 */     switch (sType.getSimpleVariety()) {
/*      */       
/*      */       case 0:
/*  295 */         emit(" * This is a complex type.");
/*      */         break;
/*      */       case 1:
/*  298 */         emit(" * This is an atomic type that is a restriction of " + getFullJavaName(sType) + ".");
/*      */         break;
/*      */       case 3:
/*  301 */         emit(" * This is a list type whose items are " + sType.getListItemType().getFullJavaName() + ".");
/*      */         break;
/*      */       case 2:
/*  304 */         emit(" * This is a union type. Instances are of one of the following types:");
/*  305 */         members = sType.getUnionConstituentTypes();
/*  306 */         for (i = 0; i < members.length; i++)
/*  307 */           emit(" *     " + members[i].getFullJavaName()); 
/*      */         break;
/*      */     } 
/*  310 */     emit(" */");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFullJavaName(SchemaType sType) {
/*  316 */     SchemaTypeImpl sTypeI = (SchemaTypeImpl)sType;
/*  317 */     String ret = sTypeI.getFullJavaName();
/*      */     
/*  319 */     while (sTypeI.isRedefinition()) {
/*      */       
/*  321 */       ret = sTypeI.getFullJavaName();
/*  322 */       sTypeI = (SchemaTypeImpl)sTypeI.getBaseType();
/*      */     } 
/*  324 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   private String getUserTypeStaticHandlerMethod(boolean encode, SchemaTypeImpl stype) {
/*  329 */     String unqualifiedName = stype.getName().getLocalPart();
/*  330 */     if (unqualifiedName.length() < 2) {
/*  331 */       unqualifiedName = unqualifiedName.toUpperCase();
/*      */     } else {
/*  333 */       unqualifiedName = unqualifiedName.substring(0, 1).toUpperCase() + unqualifiedName.substring(1);
/*      */     } 
/*  335 */     if (encode) {
/*  336 */       return stype.getUserTypeHandlerName() + ".encode" + unqualifiedName;
/*      */     }
/*  338 */     return stype.getUserTypeHandlerName() + ".decode" + unqualifiedName;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String indexClassForSystem(SchemaTypeSystem system) {
/*  344 */     String name = system.getName();
/*  345 */     return name + "." + "TypeSystemHolder";
/*      */   }
/*      */ 
/*      */   
/*      */   static String shortIndexClassForSystem(SchemaTypeSystem system) {
/*  350 */     return "TypeSystemHolder";
/*      */   }
/*      */ 
/*      */   
/*      */   void printStaticTypeDeclaration(SchemaType sType, SchemaTypeSystem system) throws IOException {
/*  355 */     String interfaceShortName = sType.getShortJavaName();
/*  356 */     emit("public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)");
/*  357 */     indent();
/*  358 */     emit("org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(" + interfaceShortName + ".class.getClassLoader(), \"" + system.getName() + "\")" + ".resolveHandle(\"" + ((SchemaTypeSystemImpl)system).handleForType(sType) + "\");");
/*      */ 
/*      */ 
/*      */     
/*  362 */     outdent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printLoader(Writer writer, SchemaTypeSystem system) throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printInnerType(SchemaType sType, SchemaTypeSystem system) throws IOException {
/*  374 */     emit("");
/*      */     
/*  376 */     printInnerTypeJavaDoc(sType);
/*      */     
/*  378 */     startInterface(sType);
/*      */     
/*  380 */     printStaticTypeDeclaration(sType, system);
/*      */     
/*  382 */     if (sType.isSimpleType()) {
/*      */       
/*  384 */       if (sType.hasStringEnumValues()) {
/*  385 */         printStringEnumeration(sType);
/*      */       }
/*      */     } else {
/*      */       
/*  389 */       if (sType.getContentType() == 2 && sType.hasStringEnumValues()) {
/*  390 */         printStringEnumeration(sType);
/*      */       }
/*  392 */       SchemaProperty[] props = getDerivedProperties(sType);
/*      */       
/*  394 */       for (int i = 0; i < props.length; i++) {
/*      */         
/*  396 */         SchemaProperty prop = props[i];
/*      */         
/*  398 */         printPropertyGetters(prop.getName(), prop.isAttribute(), prop.getJavaPropertyName(), prop.getJavaTypeCode(), javaTypeForProperty(prop), xmlTypeForProperty(prop), (prop.hasNillable() != 0), prop.extendsJavaOption(), prop.extendsJavaArray(), prop.extendsJavaSingleton());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  411 */         if (!prop.isReadOnly())
/*      */         {
/*  413 */           printPropertySetters(prop.getName(), prop.isAttribute(), prop.getJavaPropertyName(), prop.getJavaTypeCode(), javaTypeForProperty(prop), xmlTypeForProperty(prop), (prop.hasNillable() != 0), prop.extendsJavaOption(), prop.extendsJavaArray(), prop.extendsJavaSingleton());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  430 */     printNestedInnerTypes(sType, system);
/*      */     
/*  432 */     printFactory(sType);
/*      */     
/*  434 */     endBlock();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void printFactory(SchemaType sType) throws IOException {
/*  440 */     boolean fullFactory = true;
/*  441 */     if (sType.isAnonymousType() && !sType.isDocumentType() && !sType.isAttributeType()) {
/*  442 */       fullFactory = false;
/*      */     }
/*  444 */     String fullName = sType.getFullJavaName().replace('$', '.');
/*      */     
/*  446 */     emit("");
/*  447 */     emit("/**");
/*  448 */     emit(" * A factory class with static methods for creating instances");
/*  449 */     emit(" * of this type.");
/*  450 */     emit(" */");
/*  451 */     emit("");
/*      */ 
/*      */     
/*  454 */     emit("public static final class Factory");
/*  455 */     emit("{");
/*  456 */     indent();
/*      */     
/*  458 */     if (sType.isSimpleType()) {
/*      */       
/*  460 */       emit("public static " + fullName + " newValue(java.lang.Object obj) {");
/*  461 */       emit("  return (" + fullName + ") type.newValue( obj ); }");
/*  462 */       emit("");
/*      */     } 
/*      */ 
/*      */     
/*  466 */     if (sType.isAbstract()) {
/*  467 */       emit("/** @deprecated No need to be able to create instances of abstract types */");
/*  468 */       if (this._useJava15)
/*  469 */         emit("@Deprecated"); 
/*      */     } 
/*  471 */     emit("public static " + fullName + " newInstance() {");
/*  472 */     emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }");
/*  473 */     emit("");
/*      */ 
/*      */     
/*  476 */     if (sType.isAbstract()) {
/*  477 */       emit("/** @deprecated No need to be able to create instances of abstract types */");
/*  478 */       if (this._useJava15)
/*  479 */         emit("@Deprecated"); 
/*      */     } 
/*  481 */     emit("public static " + fullName + " newInstance(org.apache.xmlbeans.XmlOptions options) {");
/*  482 */     emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }");
/*  483 */     emit("");
/*      */     
/*  485 */     if (fullFactory) {
/*      */       
/*  487 */       emit("/** @param xmlAsString the string value to parse */");
/*  488 */       emit("public static " + fullName + " parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {");
/*  489 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }");
/*  490 */       emit("");
/*      */       
/*  492 */       emit("public static " + fullName + " parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {");
/*  493 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }");
/*  494 */       emit("");
/*      */       
/*  496 */       emit("/** @param file the file from which to load an xml document */");
/*  497 */       emit("public static " + fullName + " parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  498 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }");
/*  499 */       emit("");
/*      */       
/*  501 */       emit("public static " + fullName + " parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  502 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }");
/*  503 */       emit("");
/*      */       
/*  505 */       emit("public static " + fullName + " parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  506 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }");
/*  507 */       emit("");
/*      */       
/*  509 */       emit("public static " + fullName + " parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  510 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }");
/*  511 */       emit("");
/*      */       
/*  513 */       emit("public static " + fullName + " parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  514 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }");
/*  515 */       emit("");
/*      */       
/*  517 */       emit("public static " + fullName + " parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  518 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }");
/*  519 */       emit("");
/*      */       
/*  521 */       emit("public static " + fullName + " parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  522 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }");
/*  523 */       emit("");
/*      */       
/*  525 */       emit("public static " + fullName + " parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {");
/*  526 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }");
/*  527 */       emit("");
/*      */       
/*  529 */       emit("public static " + fullName + " parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {");
/*  530 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }");
/*  531 */       emit("");
/*      */       
/*  533 */       emit("public static " + fullName + " parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {");
/*  534 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }");
/*  535 */       emit("");
/*      */       
/*  537 */       emit("public static " + fullName + " parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {");
/*  538 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }");
/*  539 */       emit("");
/*      */       
/*  541 */       emit("public static " + fullName + " parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {");
/*  542 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }");
/*  543 */       emit("");
/*      */       
/*  545 */       emit("/** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */");
/*  546 */       if (this._useJava15)
/*  547 */         emit("@Deprecated"); 
/*  548 */       emit("public static " + fullName + " parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {");
/*  549 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }");
/*  550 */       emit("");
/*      */       
/*  552 */       emit("/** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */");
/*  553 */       if (this._useJava15)
/*  554 */         emit("@Deprecated"); 
/*  555 */       emit("public static " + fullName + " parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {");
/*  556 */       emit("  return (" + fullName + ") org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }");
/*  557 */       emit("");
/*      */ 
/*      */       
/*  560 */       emit("/** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */");
/*  561 */       if (this._useJava15)
/*  562 */         emit("@Deprecated"); 
/*  563 */       emit("public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {");
/*  564 */       emit("  return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }");
/*  565 */       emit("");
/*      */ 
/*      */       
/*  568 */       emit("/** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */");
/*  569 */       if (this._useJava15)
/*  570 */         emit("@Deprecated"); 
/*  571 */       emit("public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {");
/*  572 */       emit("  return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }");
/*  573 */       emit("");
/*      */     } 
/*      */     
/*  576 */     emit("private Factory() { } // No instance of this class allowed");
/*  577 */     outdent();
/*  578 */     emit("}");
/*      */   }
/*      */ 
/*      */   
/*      */   void printNestedInnerTypes(SchemaType sType, SchemaTypeSystem system) throws IOException {
/*  583 */     boolean redefinition = (sType.getName() != null && sType.getName().equals(sType.getBaseType().getName()));
/*      */     
/*  585 */     while (sType != null) {
/*      */       
/*  587 */       SchemaType[] anonTypes = sType.getAnonymousTypes();
/*  588 */       for (int i = 0; i < anonTypes.length; i++) {
/*      */         
/*  590 */         if (anonTypes[i].isSkippedAnonymousType()) {
/*  591 */           printNestedInnerTypes(anonTypes[i], system);
/*      */         } else {
/*  593 */           printInnerType(anonTypes[i], system);
/*      */         } 
/*      */       } 
/*      */       
/*  597 */       if (!redefinition || (sType.getDerivationType() != 2 && !sType.isSimpleType())) {
/*      */         break;
/*      */       }
/*  600 */       sType = sType.getBaseType();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void printTopComment(SchemaType sType) throws IOException {
/*  606 */     emit("/*");
/*  607 */     if (sType.getName() != null) {
/*      */       
/*  609 */       emit(" * XML Type:  " + sType.getName().getLocalPart());
/*  610 */       emit(" * Namespace: " + sType.getName().getNamespaceURI());
/*      */     }
/*      */     else {
/*      */       
/*  614 */       QName thename = null;
/*      */       
/*  616 */       if (sType.isDocumentType()) {
/*      */         
/*  618 */         thename = sType.getDocumentElementName();
/*  619 */         emit(" * An XML document type.");
/*      */       }
/*  621 */       else if (sType.isAttributeType()) {
/*      */         
/*  623 */         thename = sType.getAttributeTypeAttributeName();
/*  624 */         emit(" * An XML attribute type.");
/*      */       } else {
/*      */         assert false;
/*      */       } 
/*      */       
/*  629 */       assert thename != null;
/*      */       
/*  631 */       emit(" * Localname: " + thename.getLocalPart());
/*  632 */       emit(" * Namespace: " + thename.getNamespaceURI());
/*      */     } 
/*  634 */     emit(" * Java type: " + sType.getFullJavaName());
/*  635 */     emit(" *");
/*  636 */     emit(" * Automatically generated - do not modify.");
/*  637 */     emit(" */");
/*      */   }
/*      */ 
/*      */   
/*      */   void printPackage(SchemaType sType, boolean intf) throws IOException {
/*      */     String fqjn;
/*  643 */     if (intf) {
/*  644 */       fqjn = sType.getFullJavaName();
/*      */     } else {
/*  646 */       fqjn = sType.getFullJavaImplName();
/*      */     } 
/*  648 */     int lastdot = fqjn.lastIndexOf('.');
/*  649 */     if (lastdot < 0)
/*      */       return; 
/*  651 */     String pkg = fqjn.substring(0, lastdot);
/*  652 */     emit("package " + pkg + ";");
/*      */   }
/*      */ 
/*      */   
/*      */   void startInterface(SchemaType sType) throws IOException {
/*  657 */     String shortName = sType.getShortJavaName();
/*      */     
/*  659 */     String baseInterface = findJavaType(sType.getBaseType());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  687 */     emit("public interface " + shortName + " extends " + baseInterface + getExtensionInterfaces(sType));
/*  688 */     emit("{");
/*  689 */     indent();
/*  690 */     emitSpecializedAccessors(sType);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getExtensionInterfaces(SchemaType sType) {
/*  695 */     SchemaTypeImpl sImpl = getImpl(sType);
/*  696 */     if (sImpl == null) {
/*  697 */       return "";
/*      */     }
/*  699 */     StringBuffer sb = new StringBuffer();
/*      */     
/*  701 */     InterfaceExtension[] exts = sImpl.getInterfaceExtensions();
/*  702 */     if (exts != null) for (int i = 0; i < exts.length; i++) {
/*  703 */         sb.append(", " + exts[i].getInterface());
/*      */       } 
/*  705 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaTypeImpl getImpl(SchemaType sType) {
/*  710 */     if (sType instanceof SchemaTypeImpl) {
/*  711 */       return (SchemaTypeImpl)sType;
/*      */     }
/*  713 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void emitSpecializedAccessors(SchemaType sType) throws IOException {
/*  718 */     if (sType.getSimpleVariety() == 1 && sType.getPrimitiveType().getBuiltinTypeCode() == 11) {
/*      */ 
/*      */       
/*  721 */       int bits = sType.getDecimalSize();
/*  722 */       int parentBits = sType.getBaseType().getDecimalSize();
/*  723 */       if (bits != parentBits || sType.getBaseType().getFullJavaName() == null)
/*      */       {
/*  725 */         if (bits == 1000000) {
/*      */           
/*  727 */           emit("java.math.BigInteger getBigIntegerValue();");
/*  728 */           emit("void setBigIntegerValue(java.math.BigInteger bi);");
/*  729 */           emit("/** @deprecated */");
/*  730 */           if (this._useJava15)
/*  731 */             emit("@Deprecated"); 
/*  732 */           emit("java.math.BigInteger bigIntegerValue();");
/*  733 */           emit("/** @deprecated */");
/*  734 */           if (this._useJava15)
/*  735 */             emit("@Deprecated"); 
/*  736 */           emit("void set(java.math.BigInteger bi);");
/*      */         }
/*  738 */         else if (bits == 64) {
/*      */           
/*  740 */           emit("long getLongValue();");
/*  741 */           emit("void setLongValue(long l);");
/*  742 */           emit("/** @deprecated */");
/*  743 */           if (this._useJava15)
/*  744 */             emit("@Deprecated"); 
/*  745 */           emit("long longValue();");
/*  746 */           emit("/** @deprecated */");
/*  747 */           if (this._useJava15)
/*  748 */             emit("@Deprecated"); 
/*  749 */           emit("void set(long l);");
/*      */         }
/*  751 */         else if (bits == 32) {
/*      */           
/*  753 */           emit("int getIntValue();");
/*  754 */           emit("void setIntValue(int i);");
/*  755 */           emit("/** @deprecated */");
/*  756 */           if (this._useJava15)
/*  757 */             emit("@Deprecated"); 
/*  758 */           emit("int intValue();");
/*  759 */           emit("/** @deprecated */");
/*  760 */           if (this._useJava15)
/*  761 */             emit("@Deprecated"); 
/*  762 */           emit("void set(int i);");
/*      */         }
/*  764 */         else if (bits == 16) {
/*      */           
/*  766 */           emit("short getShortValue();");
/*  767 */           emit("void setShortValue(short s);");
/*  768 */           emit("/** @deprecated */");
/*  769 */           if (this._useJava15)
/*  770 */             emit("@Deprecated"); 
/*  771 */           emit("short shortValue();");
/*  772 */           emit("/** @deprecated */");
/*  773 */           if (this._useJava15)
/*  774 */             emit("@Deprecated"); 
/*  775 */           emit("void set(short s);");
/*      */         }
/*  777 */         else if (bits == 8) {
/*      */           
/*  779 */           emit("byte getByteValue();");
/*  780 */           emit("void setByteValue(byte b);");
/*  781 */           emit("/** @deprecated */");
/*  782 */           if (this._useJava15)
/*  783 */             emit("@Deprecated"); 
/*  784 */           emit("byte byteValue();");
/*  785 */           emit("/** @deprecated */");
/*  786 */           if (this._useJava15)
/*  787 */             emit("@Deprecated"); 
/*  788 */           emit("void set(byte b);");
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  793 */     if (sType.getSimpleVariety() == 2) {
/*      */       
/*  795 */       emit("java.lang.Object getObjectValue();");
/*  796 */       emit("void setObjectValue(java.lang.Object val);");
/*  797 */       emit("/** @deprecated */");
/*  798 */       if (this._useJava15)
/*  799 */         emit("@Deprecated"); 
/*  800 */       emit("java.lang.Object objectValue();");
/*  801 */       emit("/** @deprecated */");
/*  802 */       if (this._useJava15)
/*  803 */         emit("@Deprecated"); 
/*  804 */       emit("void objectSet(java.lang.Object val);");
/*  805 */       emit("org.apache.xmlbeans.SchemaType instanceType();");
/*  806 */       SchemaType ctype = sType.getUnionCommonBaseType();
/*  807 */       if (ctype == null || ctype.getSimpleVariety() != 2);
/*  808 */       emitSpecializedAccessors(ctype);
/*      */     } 
/*      */     
/*  811 */     if (sType.getSimpleVariety() == 3) {
/*      */       
/*  813 */       emit("java.util.List getListValue();");
/*  814 */       emit("java.util.List xgetListValue();");
/*  815 */       emit("void setListValue(java.util.List list);");
/*  816 */       emit("/** @deprecated */");
/*  817 */       if (this._useJava15)
/*  818 */         emit("@Deprecated"); 
/*  819 */       emit("java.util.List listValue();");
/*  820 */       emit("/** @deprecated */");
/*  821 */       if (this._useJava15)
/*  822 */         emit("@Deprecated"); 
/*  823 */       emit("java.util.List xlistValue();");
/*  824 */       emit("/** @deprecated */");
/*  825 */       if (this._useJava15)
/*  826 */         emit("@Deprecated"); 
/*  827 */       emit("void set(java.util.List list);");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void startBlock() throws IOException {
/*  833 */     emit("{");
/*  834 */     indent();
/*      */   }
/*      */   
/*      */   void endBlock() throws IOException {
/*  838 */     outdent();
/*  839 */     emit("}");
/*      */   }
/*      */ 
/*      */   
/*      */   void printJavaDoc(String sentence) throws IOException {
/*  844 */     emit("");
/*  845 */     emit("/**");
/*  846 */     emit(" * " + sentence);
/*  847 */     emit(" */");
/*      */   }
/*      */ 
/*      */   
/*      */   void printShortJavaDoc(String sentence) throws IOException {
/*  852 */     emit("/** " + sentence + " */");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String javaStringEscape(String str) {
/*  859 */     for (int i = 0; i < str.length(); ) {
/*      */       
/*  861 */       switch (str.charAt(i)) {
/*      */         case '\n':
/*      */         case '\r':
/*      */         case '"':
/*      */         case '\\':
/*      */           break;
/*      */         
/*      */         default:
/*      */           i++;
/*      */           continue;
/*      */       } 
/*  872 */       StringBuffer sb = new StringBuffer();
/*  873 */       for (int j = 0; j < str.length(); j++) {
/*      */         
/*  875 */         char ch = str.charAt(j);
/*  876 */         switch (ch) {
/*      */           
/*      */           default:
/*  879 */             sb.append(ch);
/*      */             break;
/*      */           case '\n':
/*  882 */             sb.append("\\n");
/*      */             break;
/*      */           case '\r':
/*  885 */             sb.append("\\r");
/*      */             break;
/*      */           case '"':
/*  888 */             sb.append("\\\"");
/*      */             break;
/*      */           case '\\':
/*  891 */             sb.append("\\\\");
/*      */             break;
/*      */         } 
/*      */       } 
/*  895 */       return sb.toString();
/*      */     } 
/*      */     return str;
/*      */   }
/*      */   void printStringEnumeration(SchemaType sType) throws IOException {
/*  900 */     SchemaType baseEnumType = sType.getBaseEnumType();
/*  901 */     String baseEnumClass = baseEnumType.getFullJavaName();
/*  902 */     boolean hasBase = hasBase(sType);
/*      */     
/*  904 */     if (!hasBase) {
/*      */       
/*  906 */       emit("");
/*  907 */       emit("org.apache.xmlbeans.StringEnumAbstractBase enumValue();");
/*  908 */       emit("void set(org.apache.xmlbeans.StringEnumAbstractBase e);");
/*      */     } 
/*      */     
/*  911 */     emit("");
/*  912 */     SchemaStringEnumEntry[] entries = sType.getStringEnumEntries();
/*  913 */     HashSet seenValues = new HashSet();
/*  914 */     HashSet repeatValues = new HashSet(); int i;
/*  915 */     for (i = 0; i < entries.length; i++) {
/*      */       
/*  917 */       String enumValue = entries[i].getString();
/*  918 */       if (seenValues.contains(enumValue)) {
/*      */         
/*  920 */         repeatValues.add(enumValue);
/*      */       }
/*      */       else {
/*      */         
/*  924 */         seenValues.add(enumValue);
/*  925 */         String constName = entries[i].getEnumName();
/*  926 */         if (hasBase)
/*  927 */         { emit("static final " + baseEnumClass + ".Enum " + constName + " = " + baseEnumClass + "." + constName + ";"); }
/*      */         else
/*  929 */         { emit("static final Enum " + constName + " = Enum.forString(\"" + javaStringEscape(enumValue) + "\");"); } 
/*      */       } 
/*  931 */     }  emit("");
/*  932 */     for (i = 0; i < entries.length; i++) {
/*      */       
/*  934 */       if (!repeatValues.contains(entries[i].getString())) {
/*      */         
/*  936 */         String constName = "INT_" + entries[i].getEnumName();
/*  937 */         if (hasBase)
/*  938 */         { emit("static final int " + constName + " = " + baseEnumClass + "." + constName + ";"); }
/*      */         else
/*  940 */         { emit("static final int " + constName + " = Enum." + constName + ";"); } 
/*      */       } 
/*  942 */     }  if (!hasBase) {
/*      */       
/*  944 */       emit("");
/*  945 */       emit("/**");
/*  946 */       emit(" * Enumeration value class for " + baseEnumClass + ".");
/*  947 */       emit(" * These enum values can be used as follows:");
/*  948 */       emit(" * <pre>");
/*  949 */       emit(" * enum.toString(); // returns the string value of the enum");
/*  950 */       emit(" * enum.intValue(); // returns an int value, useful for switches");
/*  951 */       if (entries.length > 0)
/*  952 */         emit(" * // e.g., case Enum.INT_" + entries[0].getEnumName()); 
/*  953 */       emit(" * Enum.forString(s); // returns the enum value for a string");
/*  954 */       emit(" * Enum.forInt(i); // returns the enum value for an int");
/*  955 */       emit(" * </pre>");
/*  956 */       emit(" * Enumeration objects are immutable singleton objects that");
/*  957 */       emit(" * can be compared using == object equality. They have no");
/*  958 */       emit(" * public constructor. See the constants defined within this");
/*  959 */       emit(" * class for all the valid values.");
/*  960 */       emit(" */");
/*  961 */       emit("static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase");
/*  962 */       emit("{");
/*  963 */       indent();
/*  964 */       emit("/**");
/*  965 */       emit(" * Returns the enum value for a string, or null if none.");
/*  966 */       emit(" */");
/*  967 */       emit("public static Enum forString(java.lang.String s)");
/*  968 */       emit("    { return (Enum)table.forString(s); }");
/*  969 */       emit("/**");
/*  970 */       emit(" * Returns the enum value corresponding to an int, or null if none.");
/*  971 */       emit(" */");
/*  972 */       emit("public static Enum forInt(int i)");
/*  973 */       emit("    { return (Enum)table.forInt(i); }");
/*  974 */       emit("");
/*  975 */       emit("private Enum(java.lang.String s, int i)");
/*  976 */       emit("    { super(s, i); }");
/*  977 */       emit("");
/*  978 */       for (i = 0; i < entries.length; i++) {
/*      */         
/*  980 */         String constName = "INT_" + entries[i].getEnumName();
/*  981 */         int intValue = entries[i].getIntValue();
/*  982 */         emit("static final int " + constName + " = " + intValue + ";");
/*      */       } 
/*  984 */       emit("");
/*  985 */       emit("public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =");
/*  986 */       emit("    new org.apache.xmlbeans.StringEnumAbstractBase.Table");
/*  987 */       emit("(");
/*  988 */       indent();
/*  989 */       emit("new Enum[]");
/*  990 */       emit("{");
/*  991 */       indent();
/*  992 */       for (i = 0; i < entries.length; i++) {
/*      */         
/*  994 */         String enumValue = entries[i].getString();
/*  995 */         String constName = "INT_" + entries[i].getEnumName();
/*  996 */         emit("new Enum(\"" + javaStringEscape(enumValue) + "\", " + constName + "),");
/*      */       } 
/*  998 */       outdent();
/*  999 */       emit("}");
/* 1000 */       outdent();
/* 1001 */       emit(");");
/* 1002 */       emit("private static final long serialVersionUID = 1L;");
/* 1003 */       emit("private java.lang.Object readResolve() { return forInt(intValue()); } ");
/* 1004 */       outdent();
/* 1005 */       emit("}");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasBase(SchemaType sType) {
/*      */     boolean hasBase;
/* 1012 */     SchemaType baseEnumType = sType.getBaseEnumType();
/* 1013 */     if (baseEnumType.isAnonymousType() && baseEnumType.isSkippedAnonymousType()) {
/*      */       
/* 1015 */       if (sType.getContentBasedOnType() != null) {
/* 1016 */         hasBase = (sType.getContentBasedOnType().getBaseType() != baseEnumType);
/*      */       } else {
/* 1018 */         hasBase = (sType.getBaseType() != baseEnumType);
/*      */       } 
/*      */     } else {
/* 1021 */       hasBase = (baseEnumType != sType);
/* 1022 */     }  return hasBase;
/*      */   }
/*      */ 
/*      */   
/*      */   String xmlTypeForProperty(SchemaProperty sProp) {
/* 1027 */     SchemaType sType = sProp.javaBasedOnType();
/* 1028 */     return findJavaType(sType).replace('$', '.');
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean xmlTypeForPropertyIsUnion(SchemaProperty sProp) {
/* 1033 */     SchemaType sType = sProp.javaBasedOnType();
/* 1034 */     return (sType.isSimpleType() && sType.getSimpleVariety() == 2);
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isJavaPrimitive(int javaType) {
/* 1039 */     return (javaType < 1) ? false : (!(javaType > 7));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String javaWrappedType(int javaType) {
/* 1046 */     switch (javaType) {
/*      */       
/*      */       case 1:
/* 1049 */         return "java.lang.Boolean";
/*      */       case 2:
/* 1051 */         return "java.lang.Float";
/*      */       case 3:
/* 1053 */         return "java.lang.Double";
/*      */       case 4:
/* 1055 */         return "java.lang.Byte";
/*      */       case 5:
/* 1057 */         return "java.lang.Short";
/*      */       case 6:
/* 1059 */         return "java.lang.Integer";
/*      */       case 7:
/* 1061 */         return "java.lang.Long";
/*      */     } 
/*      */ 
/*      */     
/*      */     assert false;
/* 1066 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   String javaTypeForProperty(SchemaProperty sProp) {
/*      */     SchemaType sType;
/* 1073 */     if (sProp.getJavaTypeCode() == 0) {
/*      */       
/* 1075 */       SchemaType schemaType = sProp.javaBasedOnType();
/* 1076 */       return findJavaType(schemaType).replace('$', '.');
/*      */     } 
/*      */     
/* 1079 */     if (sProp.getJavaTypeCode() == 20)
/*      */     {
/* 1081 */       return ((SchemaTypeImpl)sProp.getType()).getUserTypeName();
/*      */     }
/*      */     
/* 1084 */     switch (sProp.getJavaTypeCode()) {
/*      */       
/*      */       case 1:
/* 1087 */         return "boolean";
/*      */       case 2:
/* 1089 */         return "float";
/*      */       case 3:
/* 1091 */         return "double";
/*      */       case 4:
/* 1093 */         return "byte";
/*      */       case 5:
/* 1095 */         return "short";
/*      */       case 6:
/* 1097 */         return "int";
/*      */       case 7:
/* 1099 */         return "long";
/*      */       
/*      */       case 8:
/* 1102 */         return "java.math.BigDecimal";
/*      */       case 9:
/* 1104 */         return "java.math.BigInteger";
/*      */       case 10:
/* 1106 */         return "java.lang.String";
/*      */       case 11:
/* 1108 */         return "byte[]";
/*      */       case 12:
/* 1110 */         return "org.apache.xmlbeans.GDate";
/*      */       case 13:
/* 1112 */         return "org.apache.xmlbeans.GDuration";
/*      */       case 14:
/* 1114 */         return "java.util.Date";
/*      */       case 15:
/* 1116 */         return "javax.xml.namespace.QName";
/*      */       case 16:
/* 1118 */         return "java.util.List";
/*      */       case 17:
/* 1120 */         return "java.util.Calendar";
/*      */       
/*      */       case 18:
/* 1123 */         sType = sProp.javaBasedOnType();
/* 1124 */         if (sType.getSimpleVariety() == 2)
/* 1125 */           sType = sType.getUnionCommonBaseType(); 
/* 1126 */         assert sType.getBaseEnumType() != null;
/* 1127 */         if (hasBase(sType)) {
/* 1128 */           return findJavaType(sType.getBaseEnumType()).replace('$', '.') + ".Enum";
/*      */         }
/* 1130 */         return findJavaType(sType).replace('$', '.') + ".Enum";
/*      */       
/*      */       case 19:
/* 1133 */         return "java.lang.Object";
/*      */     } 
/*      */     
/*      */     assert false;
/* 1137 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printPropertyGetters(QName qName, boolean isAttr, String propertyName, int javaType, String type, String xtype, boolean nillable, boolean optional, boolean several, boolean singleton) throws IOException {
/* 1148 */     String propdesc = "\"" + qName.getLocalPart() + "\"" + (isAttr ? " attribute" : " element");
/* 1149 */     boolean xmltype = (javaType == 0);
/*      */     
/* 1151 */     if (singleton) {
/*      */       
/* 1153 */       printJavaDoc((several ? "Gets first " : "Gets the ") + propdesc);
/* 1154 */       emit(type + " get" + propertyName + "();");
/*      */       
/* 1156 */       if (!xmltype) {
/*      */         
/* 1158 */         printJavaDoc((several ? "Gets (as xml) first " : "Gets (as xml) the ") + propdesc);
/* 1159 */         emit(xtype + " xget" + propertyName + "();");
/*      */       } 
/*      */       
/* 1162 */       if (nillable) {
/*      */         
/* 1164 */         printJavaDoc((several ? "Tests for nil first " : "Tests for nil ") + propdesc);
/* 1165 */         emit("boolean isNil" + propertyName + "();");
/*      */       } 
/*      */     } 
/*      */     
/* 1169 */     if (optional) {
/*      */       
/* 1171 */       printJavaDoc((several ? "True if has at least one " : "True if has ") + propdesc);
/* 1172 */       emit("boolean isSet" + propertyName + "();");
/*      */     } 
/*      */     
/* 1175 */     if (several) {
/*      */       
/* 1177 */       String arrayName = propertyName + "Array";
/*      */       
/* 1179 */       if (this._useJava15) {
/*      */         
/* 1181 */         String wrappedType = type;
/* 1182 */         if (isJavaPrimitive(javaType)) {
/* 1183 */           wrappedType = javaWrappedType(javaType);
/*      */         }
/* 1185 */         printJavaDoc("Gets a List of " + propdesc + "s");
/* 1186 */         emit("java.util.List<" + wrappedType + "> get" + propertyName + "List();");
/*      */       } 
/*      */       
/* 1189 */       if (this._useJava15) {
/*      */         
/* 1191 */         emit("");
/* 1192 */         emit("/**");
/* 1193 */         emit(" * Gets array of all " + propdesc + "s");
/* 1194 */         emit(" * @deprecated");
/* 1195 */         emit(" */");
/* 1196 */         emit("@Deprecated");
/*      */       } else {
/*      */         
/* 1199 */         printJavaDoc("Gets array of all " + propdesc + "s");
/* 1200 */       }  emit(type + "[] get" + arrayName + "();");
/*      */       
/* 1202 */       printJavaDoc("Gets ith " + propdesc);
/* 1203 */       emit(type + " get" + arrayName + "(int i);");
/*      */       
/* 1205 */       if (!xmltype) {
/*      */         
/* 1207 */         if (this._useJava15) {
/*      */           
/* 1209 */           printJavaDoc("Gets (as xml) a List of " + propdesc + "s");
/* 1210 */           emit("java.util.List<" + xtype + "> xget" + propertyName + "List();");
/*      */         } 
/*      */         
/* 1213 */         if (this._useJava15) {
/*      */           
/* 1215 */           emit("");
/* 1216 */           emit("/**");
/* 1217 */           emit(" * Gets (as xml) array of all " + propdesc + "s");
/* 1218 */           emit(" * @deprecated");
/* 1219 */           emit(" */");
/* 1220 */           emit("@Deprecated");
/*      */         } else {
/*      */           
/* 1223 */           printJavaDoc("Gets (as xml) array of all " + propdesc + "s");
/* 1224 */         }  emit(xtype + "[] xget" + arrayName + "();");
/*      */         
/* 1226 */         printJavaDoc("Gets (as xml) ith " + propdesc);
/* 1227 */         emit(xtype + " xget" + arrayName + "(int i);");
/*      */       } 
/*      */       
/* 1230 */       if (nillable) {
/*      */         
/* 1232 */         printJavaDoc("Tests for nil ith " + propdesc);
/* 1233 */         emit("boolean isNil" + arrayName + "(int i);");
/*      */       } 
/*      */       
/* 1236 */       printJavaDoc("Returns number of " + propdesc);
/* 1237 */       emit("int sizeOf" + arrayName + "();");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printPropertySetters(QName qName, boolean isAttr, String propertyName, int javaType, String type, String xtype, boolean nillable, boolean optional, boolean several, boolean singleton) throws IOException {
/* 1247 */     String safeVarName = NameUtil.nonJavaKeyword(NameUtil.lowerCamelCase(propertyName));
/* 1248 */     if (safeVarName.equals("i"))
/* 1249 */       safeVarName = "iValue"; 
/* 1250 */     boolean xmltype = (javaType == 0);
/*      */     
/* 1252 */     String propdesc = "\"" + qName.getLocalPart() + "\"" + (isAttr ? " attribute" : " element");
/*      */     
/* 1254 */     if (singleton) {
/*      */       
/* 1256 */       printJavaDoc((several ? "Sets first " : "Sets the ") + propdesc);
/* 1257 */       emit("void set" + propertyName + "(" + type + " " + safeVarName + ");");
/*      */       
/* 1259 */       if (!xmltype) {
/*      */         
/* 1261 */         printJavaDoc((several ? "Sets (as xml) first " : "Sets (as xml) the ") + propdesc);
/* 1262 */         emit("void xset" + propertyName + "(" + xtype + " " + safeVarName + ");");
/*      */       } 
/*      */       
/* 1265 */       if (xmltype && !several) {
/*      */         
/* 1267 */         printJavaDoc("Appends and returns a new empty " + propdesc);
/* 1268 */         emit(xtype + " addNew" + propertyName + "();");
/*      */       } 
/*      */       
/* 1271 */       if (nillable) {
/*      */         
/* 1273 */         printJavaDoc((several ? "Nils the first " : "Nils the ") + propdesc);
/* 1274 */         emit("void setNil" + propertyName + "();");
/*      */       } 
/*      */     } 
/*      */     
/* 1278 */     if (optional) {
/*      */       
/* 1280 */       printJavaDoc((several ? "Removes first " : "Unsets the ") + propdesc);
/* 1281 */       emit("void unset" + propertyName + "();");
/*      */     } 
/*      */     
/* 1284 */     if (several) {
/*      */       
/* 1286 */       String arrayName = propertyName + "Array";
/*      */       
/* 1288 */       printJavaDoc("Sets array of all " + propdesc);
/* 1289 */       emit("void set" + arrayName + "(" + type + "[] " + safeVarName + "Array);");
/*      */       
/* 1291 */       printJavaDoc("Sets ith " + propdesc);
/* 1292 */       emit("void set" + arrayName + "(int i, " + type + " " + safeVarName + ");");
/*      */       
/* 1294 */       if (!xmltype) {
/*      */         
/* 1296 */         printJavaDoc("Sets (as xml) array of all " + propdesc);
/* 1297 */         emit("void xset" + arrayName + "(" + xtype + "[] " + safeVarName + "Array);");
/*      */         
/* 1299 */         printJavaDoc("Sets (as xml) ith " + propdesc);
/* 1300 */         emit("void xset" + arrayName + "(int i, " + xtype + " " + safeVarName + ");");
/*      */       } 
/*      */       
/* 1303 */       if (nillable) {
/*      */         
/* 1305 */         printJavaDoc("Nils the ith " + propdesc);
/* 1306 */         emit("void setNil" + arrayName + "(int i);");
/*      */       } 
/*      */       
/* 1309 */       if (!xmltype) {
/*      */         
/* 1311 */         printJavaDoc("Inserts the value as the ith " + propdesc);
/* 1312 */         emit("void insert" + propertyName + "(int i, " + type + " " + safeVarName + ");");
/*      */         
/* 1314 */         printJavaDoc("Appends the value as the last " + propdesc);
/* 1315 */         emit("void add" + propertyName + "(" + type + " " + safeVarName + ");");
/*      */       } 
/*      */       
/* 1318 */       printJavaDoc("Inserts and returns a new empty value (as xml) as the ith " + propdesc);
/* 1319 */       emit(xtype + " insertNew" + propertyName + "(int i);");
/*      */       
/* 1321 */       printJavaDoc("Appends and returns a new empty value (as xml) as the last " + propdesc);
/* 1322 */       emit(xtype + " addNew" + propertyName + "();");
/*      */       
/* 1324 */       printJavaDoc("Removes the ith " + propdesc);
/* 1325 */       emit("void remove" + propertyName + "(int i);");
/*      */     } 
/*      */   }
/*      */   
/*      */   String getAtomicRestrictionType(SchemaType sType) {
/* 1330 */     SchemaType pType = sType.getPrimitiveType();
/* 1331 */     switch (pType.getBuiltinTypeCode()) {
/*      */       
/*      */       case 2:
/* 1334 */         return "org.apache.xmlbeans.impl.values.XmlAnySimpleTypeImpl";
/*      */       case 3:
/* 1336 */         return "org.apache.xmlbeans.impl.values.JavaBooleanHolderEx";
/*      */       case 4:
/* 1338 */         return "org.apache.xmlbeans.impl.values.JavaBase64HolderEx";
/*      */       case 5:
/* 1340 */         return "org.apache.xmlbeans.impl.values.JavaHexBinaryHolderEx";
/*      */       case 6:
/* 1342 */         return "org.apache.xmlbeans.impl.values.JavaUriHolderEx";
/*      */       case 7:
/* 1344 */         return "org.apache.xmlbeans.impl.values.JavaQNameHolderEx";
/*      */       case 8:
/* 1346 */         return "org.apache.xmlbeans.impl.values.JavaNotationHolderEx";
/*      */       case 9:
/* 1348 */         return "org.apache.xmlbeans.impl.values.JavaFloatHolderEx";
/*      */       case 10:
/* 1350 */         return "org.apache.xmlbeans.impl.values.JavaDoubleHolderEx";
/*      */       case 11:
/* 1352 */         switch (sType.getDecimalSize())
/*      */         { default:
/*      */             assert false;
/*      */           
/*      */           case 1000001:
/* 1357 */             return "org.apache.xmlbeans.impl.values.JavaDecimalHolderEx";
/*      */           case 1000000:
/* 1359 */             return "org.apache.xmlbeans.impl.values.JavaIntegerHolderEx";
/*      */           case 64:
/* 1361 */             return "org.apache.xmlbeans.impl.values.JavaLongHolderEx";
/*      */           case 8:
/*      */           case 16:
/*      */           case 32:
/* 1365 */             break; }  return "org.apache.xmlbeans.impl.values.JavaIntHolderEx";
/*      */       
/*      */       case 12:
/* 1368 */         if (sType.hasStringEnumValues()) {
/* 1369 */           return "org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx";
/*      */         }
/* 1371 */         return "org.apache.xmlbeans.impl.values.JavaStringHolderEx";
/*      */       
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/* 1381 */         return "org.apache.xmlbeans.impl.values.JavaGDateHolderEx";
/*      */       
/*      */       case 13:
/* 1384 */         return "org.apache.xmlbeans.impl.values.JavaGDurationHolderEx";
/*      */     } 
/* 1386 */     assert false : "unrecognized primitive type";
/* 1387 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static SchemaType findBaseType(SchemaType sType) {
/* 1393 */     while (sType.getFullJavaName() == null)
/* 1394 */       sType = sType.getBaseType(); 
/* 1395 */     return sType;
/*      */   }
/*      */   
/*      */   String getBaseClass(SchemaType sType) {
/* 1399 */     SchemaType baseType = findBaseType(sType.getBaseType());
/*      */     
/* 1401 */     switch (sType.getSimpleVariety()) {
/*      */ 
/*      */       
/*      */       case 0:
/* 1405 */         if (!XmlObject.type.equals(baseType))
/* 1406 */           return baseType.getFullJavaImplName(); 
/* 1407 */         return "org.apache.xmlbeans.impl.values.XmlComplexContentImpl";
/*      */ 
/*      */       
/*      */       case 1:
/* 1411 */         assert !sType.isBuiltinType();
/* 1412 */         return getAtomicRestrictionType(sType);
/*      */       
/*      */       case 3:
/* 1415 */         return "org.apache.xmlbeans.impl.values.XmlListImpl";
/*      */       
/*      */       case 2:
/* 1418 */         return "org.apache.xmlbeans.impl.values.XmlUnionImpl";
/*      */     } 
/*      */     
/* 1421 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */   
/*      */   void printConstructor(SchemaType sType, String shortName) throws IOException {
/* 1426 */     emit("");
/* 1427 */     emit("public " + shortName + "(org.apache.xmlbeans.SchemaType sType)");
/* 1428 */     startBlock();
/* 1429 */     emit("super(sType" + ((sType.getSimpleVariety() == 0) ? "" : (", " + (!sType.isSimpleType() ? 1 : 0))) + ");");
/*      */ 
/*      */ 
/*      */     
/* 1433 */     endBlock();
/*      */     
/* 1435 */     if (sType.getSimpleVariety() != 0) {
/*      */       
/* 1437 */       emit("");
/* 1438 */       emit("protected " + shortName + "(org.apache.xmlbeans.SchemaType sType, boolean b)");
/* 1439 */       startBlock();
/* 1440 */       emit("super(sType, b);");
/* 1441 */       endBlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void startClass(SchemaType sType, boolean isInner) throws IOException {
/* 1447 */     String shortName = sType.getShortJavaImplName();
/* 1448 */     String baseClass = getBaseClass(sType);
/* 1449 */     StringBuffer interfaces = new StringBuffer();
/* 1450 */     interfaces.append(sType.getFullJavaName().replace('$', '.'));
/*      */     
/* 1452 */     if (sType.getSimpleVariety() == 2) {
/* 1453 */       SchemaType[] memberTypes = sType.getUnionMemberTypes();
/* 1454 */       for (int i = 0; i < memberTypes.length; i++) {
/* 1455 */         interfaces.append(", " + memberTypes[i].getFullJavaName().replace('$', '.'));
/*      */       }
/*      */     } 
/* 1458 */     emit("public " + (isInner ? "static " : "") + "class " + shortName + " extends " + baseClass + " implements " + interfaces.toString());
/*      */ 
/*      */     
/* 1461 */     startBlock();
/*      */     
/* 1463 */     emit("private static final long serialVersionUID = 1L;");
/*      */   }
/*      */ 
/*      */   
/*      */   void makeAttributeDefaultValue(String jtargetType, SchemaProperty prop, String identifier) throws IOException {
/* 1468 */     String fullName = jtargetType;
/* 1469 */     if (fullName == null) {
/* 1470 */       fullName = prop.javaBasedOnType().getFullJavaName().replace('$', '.');
/*      */     }
/* 1472 */     emit("target = (" + fullName + ")get_default_attribute_value(" + identifier + ");");
/*      */   }
/*      */ 
/*      */   
/*      */   void makeMissingValue(int javaType) throws IOException {
/* 1477 */     switch (javaType) {
/*      */       
/*      */       case 1:
/* 1480 */         emit("return false;");
/*      */         return;
/*      */       case 2:
/* 1483 */         emit("return 0.0f;");
/*      */         return;
/*      */       case 3:
/* 1486 */         emit("return 0.0;");
/*      */         return;
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/* 1491 */         emit("return 0;");
/*      */         return;
/*      */       case 7:
/* 1494 */         emit("return 0L;");
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1510 */     emit("return null;");
/*      */   }
/*      */ 
/*      */   
/*      */   void printJGetArrayValue(int javaType, String type, SchemaTypeImpl stype) throws IOException {
/* 1515 */     switch (javaType) {
/*      */       
/*      */       case 0:
/* 1518 */         emit(type + "[] result = new " + type + "[targetList.size()];");
/* 1519 */         emit("targetList.toArray(result);");
/*      */         break;
/*      */       
/*      */       case 18:
/* 1523 */         emit(type + "[] result = new " + type + "[targetList.size()];");
/* 1524 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1525 */         emit("    result[i] = (" + type + ")((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();");
/*      */         break;
/*      */       
/*      */       case 1:
/* 1529 */         emit("boolean[] result = new boolean[targetList.size()];");
/* 1530 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1531 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getBooleanValue();");
/*      */         break;
/*      */       
/*      */       case 2:
/* 1535 */         emit("float[] result = new float[targetList.size()];");
/* 1536 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1537 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getFloatValue();");
/*      */         break;
/*      */       
/*      */       case 3:
/* 1541 */         emit("double[] result = new double[targetList.size()];");
/* 1542 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1543 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDoubleValue();");
/*      */         break;
/*      */       
/*      */       case 4:
/* 1547 */         emit("byte[] result = new byte[targetList.size()];");
/* 1548 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1549 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getByteValue();");
/*      */         break;
/*      */       
/*      */       case 5:
/* 1553 */         emit("short[] result = new short[targetList.size()];");
/* 1554 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1555 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getShortValue();");
/*      */         break;
/*      */       
/*      */       case 6:
/* 1559 */         emit("int[] result = new int[targetList.size()];");
/* 1560 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1561 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getIntValue();");
/*      */         break;
/*      */       
/*      */       case 7:
/* 1565 */         emit("long[] result = new long[targetList.size()];");
/* 1566 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1567 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getLongValue();");
/*      */         break;
/*      */       
/*      */       case 8:
/* 1571 */         emit("java.math.BigDecimal[] result = new java.math.BigDecimal[targetList.size()];");
/* 1572 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1573 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getBigDecimalValue();");
/*      */         break;
/*      */       
/*      */       case 9:
/* 1577 */         emit("java.math.BigInteger[] result = new java.math.BigInteger[targetList.size()];");
/* 1578 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1579 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getBigIntegerValue();");
/*      */         break;
/*      */       
/*      */       case 10:
/* 1583 */         emit("java.lang.String[] result = new java.lang.String[targetList.size()];");
/* 1584 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1585 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();");
/*      */         break;
/*      */       
/*      */       case 11:
/* 1589 */         emit("byte[][] result = new byte[targetList.size()][];");
/* 1590 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1591 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getByteArrayValue();");
/*      */         break;
/*      */       
/*      */       case 17:
/* 1595 */         emit("java.util.Calendar[] result = new java.util.Calendar[targetList.size()];");
/* 1596 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1597 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getCalendarValue();");
/*      */         break;
/*      */       
/*      */       case 14:
/* 1601 */         emit("java.util.Date[] result = new java.util.Date[targetList.size()];");
/* 1602 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1603 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getDateValue();");
/*      */         break;
/*      */       
/*      */       case 12:
/* 1607 */         emit("org.apache.xmlbeans.GDate[] result = new org.apache.xmlbeans.GDate[targetList.size()];");
/* 1608 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1609 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getGDateValue();");
/*      */         break;
/*      */       
/*      */       case 13:
/* 1613 */         emit("org.apache.xmlbeans.GDuration[] result = new org.apache.xmlbeans.GDuration[targetList.size()];");
/* 1614 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1615 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getGDurationValue();");
/*      */         break;
/*      */       
/*      */       case 15:
/* 1619 */         emit("javax.xml.namespace.QName[] result = new javax.xml.namespace.QName[targetList.size()];");
/* 1620 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1621 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getQNameValue();");
/*      */         break;
/*      */       
/*      */       case 16:
/* 1625 */         emit("java.util.List[] result = new java.util.List[targetList.size()];");
/* 1626 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1627 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getListValue();");
/*      */         break;
/*      */       
/*      */       case 19:
/* 1631 */         emit("java.lang.Object[] result = new java.lang.Object[targetList.size()];");
/* 1632 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1633 */         emit("    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getObjectValue();");
/*      */         break;
/*      */       
/*      */       case 20:
/* 1637 */         emit(stype.getUserTypeName() + "[] result = new " + stype.getUserTypeName() + "[targetList.size()];");
/* 1638 */         emit("for (int i = 0, len = targetList.size() ; i < len ; i++)");
/* 1639 */         emit("    result[i] = " + getUserTypeStaticHandlerMethod(false, stype) + "((org.apache.xmlbeans.SimpleValue)targetList.get(i));");
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1644 */         throw new IllegalStateException();
/*      */     } 
/* 1646 */     emit("return result;");
/*      */   }
/*      */   void printJGetValue(int javaType, String type, SchemaTypeImpl stype) throws IOException {
/* 1649 */     switch (javaType) {
/*      */       
/*      */       case 0:
/* 1652 */         emit("return target;");
/*      */         return;
/*      */       case 1:
/* 1655 */         emit("return target.getBooleanValue();");
/*      */         return;
/*      */       case 2:
/* 1658 */         emit("return target.getFloatValue();");
/*      */         return;
/*      */       case 3:
/* 1661 */         emit("return target.getDoubleValue();");
/*      */         return;
/*      */       case 4:
/* 1664 */         emit("return target.getByteValue();");
/*      */         return;
/*      */       case 5:
/* 1667 */         emit("return target.getShortValue();");
/*      */         return;
/*      */       case 6:
/* 1670 */         emit("return target.getIntValue();");
/*      */         return;
/*      */       case 7:
/* 1673 */         emit("return target.getLongValue();");
/*      */         return;
/*      */       case 8:
/* 1676 */         emit("return target.getBigDecimalValue();");
/*      */         return;
/*      */       case 9:
/* 1679 */         emit("return target.getBigIntegerValue();");
/*      */         return;
/*      */       case 10:
/* 1682 */         emit("return target.getStringValue();");
/*      */         return;
/*      */       case 11:
/* 1685 */         emit("return target.getByteArrayValue();");
/*      */         return;
/*      */       case 12:
/* 1688 */         emit("return target.getGDateValue();");
/*      */         return;
/*      */       case 13:
/* 1691 */         emit("return target.getGDurationValue();");
/*      */         return;
/*      */       case 17:
/* 1694 */         emit("return target.getCalendarValue();");
/*      */         return;
/*      */       case 14:
/* 1697 */         emit("return target.getDateValue();");
/*      */         return;
/*      */       case 15:
/* 1700 */         emit("return target.getQNameValue();");
/*      */         return;
/*      */       case 16:
/* 1703 */         emit("return target.getListValue();");
/*      */         return;
/*      */       case 18:
/* 1706 */         emit("return (" + type + ")target.getEnumValue();");
/*      */         return;
/*      */       case 19:
/* 1709 */         emit("return target.getObjectValue();");
/*      */         return;
/*      */       case 20:
/* 1712 */         emit("return " + getUserTypeStaticHandlerMethod(false, stype) + "(target);");
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1717 */     throw new IllegalStateException();
/*      */   }
/*      */   
/*      */   void printJSetValue(int javaType, String safeVarName, SchemaTypeImpl stype) throws IOException {
/* 1721 */     switch (javaType) {
/*      */       
/*      */       case 0:
/* 1724 */         emit("target.set(" + safeVarName + ");");
/*      */         return;
/*      */       case 1:
/* 1727 */         emit("target.setBooleanValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 2:
/* 1730 */         emit("target.setFloatValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 3:
/* 1733 */         emit("target.setDoubleValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 4:
/* 1736 */         emit("target.setByteValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 5:
/* 1739 */         emit("target.setShortValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 6:
/* 1742 */         emit("target.setIntValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 7:
/* 1745 */         emit("target.setLongValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 8:
/* 1748 */         emit("target.setBigDecimalValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 9:
/* 1751 */         emit("target.setBigIntegerValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 10:
/* 1754 */         emit("target.setStringValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 11:
/* 1757 */         emit("target.setByteArrayValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 12:
/* 1760 */         emit("target.setGDateValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 13:
/* 1763 */         emit("target.setGDurationValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 17:
/* 1766 */         emit("target.setCalendarValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 14:
/* 1769 */         emit("target.setDateValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 15:
/* 1772 */         emit("target.setQNameValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 16:
/* 1775 */         emit("target.setListValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 18:
/* 1778 */         emit("target.setEnumValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 19:
/* 1781 */         emit("target.setObjectValue(" + safeVarName + ");");
/*      */         return;
/*      */       case 20:
/* 1784 */         emit(getUserTypeStaticHandlerMethod(true, stype) + "(" + safeVarName + ", target);");
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1789 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */   
/*      */   String getIdentifier(Map qNameMap, QName qName) {
/* 1794 */     return ((String[])qNameMap.get(qName))[0];
/*      */   }
/*      */   
/*      */   String getSetIdentifier(Map qNameMap, QName qName) {
/* 1798 */     String[] identifiers = (String[])qNameMap.get(qName);
/* 1799 */     return (identifiers[1] == null) ? identifiers[0] : identifiers[1];
/*      */   }
/*      */   
/*      */   Map printStaticFields(SchemaProperty[] properties) throws IOException {
/* 1803 */     Map results = new HashMap();
/*      */     
/* 1805 */     emit("");
/* 1806 */     for (int i = 0; i < properties.length; i++) {
/*      */       
/* 1808 */       String[] identifiers = new String[2];
/* 1809 */       SchemaProperty prop = properties[i];
/* 1810 */       QName name = prop.getName();
/* 1811 */       results.put(name, identifiers);
/* 1812 */       String javaName = prop.getJavaPropertyName();
/* 1813 */       identifiers[0] = (javaName + "$" + (i * 2)).toUpperCase();
/* 1814 */       String uriString = "\"" + name.getNamespaceURI() + "\"";
/*      */       
/* 1816 */       emit("private static final javax.xml.namespace.QName " + identifiers[0] + " = ");
/*      */       
/* 1818 */       indent();
/* 1819 */       emit("new javax.xml.namespace.QName(" + uriString + ", \"" + name.getLocalPart() + "\");");
/*      */       
/* 1821 */       outdent();
/*      */       
/* 1823 */       if (properties[i].acceptedNames() != null) {
/*      */         
/* 1825 */         QName[] qnames = properties[i].acceptedNames();
/*      */         
/* 1827 */         if (qnames.length > 1) {
/*      */           
/* 1829 */           identifiers[1] = (javaName + "$" + (i * 2 + 1)).toUpperCase();
/*      */           
/* 1831 */           emit("private static final org.apache.xmlbeans.QNameSet " + identifiers[1] + " = org.apache.xmlbeans.QNameSet.forArray( new javax.xml.namespace.QName[] { ");
/*      */           
/* 1833 */           indent();
/* 1834 */           for (int j = 0; j < qnames.length; j++)
/*      */           {
/* 1836 */             emit("new javax.xml.namespace.QName(\"" + qnames[j].getNamespaceURI() + "\", \"" + qnames[j].getLocalPart() + "\"),");
/*      */           }
/*      */ 
/*      */           
/* 1840 */           outdent();
/*      */           
/* 1842 */           emit("});");
/*      */         } 
/*      */       } 
/*      */     } 
/* 1846 */     emit("");
/* 1847 */     return results;
/*      */   }
/*      */ 
/*      */   
/*      */   void emitImplementationPreamble() throws IOException {
/* 1852 */     emit("synchronized (monitor())");
/* 1853 */     emit("{");
/* 1854 */     indent();
/* 1855 */     emit("check_orphaned();");
/*      */   }
/*      */ 
/*      */   
/*      */   void emitImplementationPostamble() throws IOException {
/* 1860 */     outdent();
/* 1861 */     emit("}");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void emitDeclareTarget(boolean declareTarget, String xtype) throws IOException {
/* 1867 */     if (declareTarget) {
/* 1868 */       emit(xtype + " target = null;");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void emitAddTarget(String identifier, boolean isAttr, boolean declareTarget, String xtype) throws IOException {
/* 1874 */     if (isAttr) {
/* 1875 */       emit("target = (" + xtype + ")get_store().add_attribute_user(" + identifier + ");");
/*      */     } else {
/* 1877 */       emit("target = (" + xtype + ")get_store().add_element_user(" + identifier + ");");
/*      */     } 
/*      */   }
/*      */   
/*      */   void emitPre(SchemaType sType, int opType, String identifier, boolean isAttr) throws IOException {
/* 1882 */     emitPre(sType, opType, identifier, isAttr, "-1");
/*      */   }
/*      */ 
/*      */   
/*      */   void emitPre(SchemaType sType, int opType, String identifier, boolean isAttr, String index) throws IOException {
/* 1887 */     SchemaTypeImpl sImpl = getImpl(sType);
/* 1888 */     if (sImpl == null) {
/*      */       return;
/*      */     }
/* 1891 */     PrePostExtension ext = sImpl.getPrePostExtension();
/* 1892 */     if (ext != null)
/*      */     {
/* 1894 */       if (ext.hasPreCall()) {
/*      */         
/* 1896 */         emit("if ( " + ext.getStaticHandler() + ".preSet(" + prePostOpString(opType) + ", this, " + identifier + ", " + isAttr + ", " + index + "))");
/* 1897 */         startBlock();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void emitPost(SchemaType sType, int opType, String identifier, boolean isAttr) throws IOException {
/* 1904 */     emitPost(sType, opType, identifier, isAttr, "-1");
/*      */   }
/*      */ 
/*      */   
/*      */   void emitPost(SchemaType sType, int opType, String identifier, boolean isAttr, String index) throws IOException {
/* 1909 */     SchemaTypeImpl sImpl = getImpl(sType);
/* 1910 */     if (sImpl == null) {
/*      */       return;
/*      */     }
/* 1913 */     PrePostExtension ext = sImpl.getPrePostExtension();
/* 1914 */     if (ext != null) {
/*      */       
/* 1916 */       if (ext.hasPreCall())
/*      */       {
/* 1918 */         endBlock();
/*      */       }
/*      */       
/* 1921 */       if (ext.hasPostCall()) {
/* 1922 */         emit(ext.getStaticHandler() + ".postSet(" + prePostOpString(opType) + ", this, " + identifier + ", " + isAttr + ", " + index + ");");
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   String prePostOpString(int opType) {
/* 1928 */     switch (opType) {
/*      */       default:
/*      */         assert false;
/*      */ 
/*      */       
/*      */       case 1:
/* 1934 */         return "org.apache.xmlbeans.PrePostExtension.OPERATION_SET";
/*      */       
/*      */       case 2:
/* 1937 */         return "org.apache.xmlbeans.PrePostExtension.OPERATION_INSERT";
/*      */       case 3:
/*      */         break;
/* 1940 */     }  return "org.apache.xmlbeans.PrePostExtension.OPERATION_REMOVE";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void emitGetTarget(String setIdentifier, String identifier, boolean isAttr, String index, int nullBehaviour, String xtype) throws IOException {
/* 1956 */     assert setIdentifier != null && identifier != null;
/*      */     
/* 1958 */     emit(xtype + " target = null;");
/*      */     
/* 1960 */     if (isAttr) {
/* 1961 */       emit("target = (" + xtype + ")get_store().find_attribute_user(" + identifier + ");");
/*      */     } else {
/* 1963 */       emit("target = (" + xtype + ")get_store().find_element_user(" + setIdentifier + ", " + index + ");");
/*      */     } 
/* 1965 */     if (nullBehaviour == 1) {
/*      */       return;
/*      */     }
/* 1968 */     emit("if (target == null)");
/*      */     
/* 1970 */     startBlock();
/*      */     
/* 1972 */     switch (nullBehaviour) {
/*      */ 
/*      */       
/*      */       case 3:
/* 1976 */         emitAddTarget(identifier, isAttr, false, xtype);
/*      */         break;
/*      */       
/*      */       case 4:
/* 1980 */         emit("throw new IndexOutOfBoundsException();");
/*      */         break;
/*      */       
/*      */       case 1:
/*      */         break;
/*      */       
/*      */       default:
/* 1987 */         assert false : "Bad behaviour type: " + nullBehaviour;
/*      */         break;
/*      */     } 
/* 1990 */     endBlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printListGetter15Impl(String parentJavaName, String propdesc, String propertyName, String wrappedType, String xtype, boolean xmltype, boolean xget) throws IOException {
/* 1999 */     String arrayName = propertyName + "Array";
/* 2000 */     String listName = propertyName + "List";
/* 2001 */     String parentThis = parentJavaName + ".this.";
/*      */     
/* 2003 */     String xgetMethod = (xget ? "x" : "") + "get";
/* 2004 */     String xsetMethod = (xget ? "x" : "") + "set";
/*      */     
/* 2006 */     printJavaDoc("Gets " + (xget ? "(as xml) " : "") + "a List of " + propdesc + "s");
/*      */     
/* 2008 */     emit("public java.util.List<" + wrappedType + "> " + xgetMethod + listName + "()");
/* 2009 */     startBlock();
/*      */     
/* 2011 */     emit("final class " + listName + " extends java.util.AbstractList<" + wrappedType + ">");
/* 2012 */     startBlock();
/*      */ 
/*      */     
/* 2015 */     if (this._useJava15)
/* 2016 */       emit("@Override"); 
/* 2017 */     emit("public " + wrappedType + " get(int i)");
/* 2018 */     emit("    { return " + parentThis + xgetMethod + arrayName + "(i); }");
/* 2019 */     emit("");
/*      */ 
/*      */     
/* 2022 */     if (this._useJava15)
/* 2023 */       emit("@Override"); 
/* 2024 */     emit("public " + wrappedType + " set(int i, " + wrappedType + " o)");
/* 2025 */     startBlock();
/* 2026 */     emit(wrappedType + " old = " + parentThis + xgetMethod + arrayName + "(i);");
/* 2027 */     emit(parentThis + xsetMethod + arrayName + "(i, o);");
/* 2028 */     emit("return old;");
/* 2029 */     endBlock();
/* 2030 */     emit("");
/*      */ 
/*      */     
/* 2033 */     if (this._useJava15)
/* 2034 */       emit("@Override"); 
/* 2035 */     emit("public void add(int i, " + wrappedType + " o)");
/* 2036 */     if (xmltype || xget) {
/* 2037 */       emit("    { " + parentThis + "insertNew" + propertyName + "(i).set(o); }");
/*      */     } else {
/* 2039 */       emit("    { " + parentThis + "insert" + propertyName + "(i, o); }");
/* 2040 */     }  emit("");
/*      */ 
/*      */     
/* 2043 */     if (this._useJava15)
/* 2044 */       emit("@Override"); 
/* 2045 */     emit("public " + wrappedType + " remove(int i)");
/* 2046 */     startBlock();
/* 2047 */     emit(wrappedType + " old = " + parentThis + xgetMethod + arrayName + "(i);");
/* 2048 */     emit(parentThis + "remove" + propertyName + "(i);");
/* 2049 */     emit("return old;");
/* 2050 */     endBlock();
/* 2051 */     emit("");
/*      */ 
/*      */     
/* 2054 */     if (this._useJava15)
/* 2055 */       emit("@Override"); 
/* 2056 */     emit("public int size()");
/* 2057 */     emit("    { return " + parentThis + "sizeOf" + arrayName + "(); }");
/* 2058 */     emit("");
/*      */     
/* 2060 */     endBlock();
/*      */     
/* 2062 */     emit("");
/*      */     
/* 2064 */     emitImplementationPreamble();
/*      */     
/* 2066 */     emit("return new " + listName + "();");
/*      */     
/* 2068 */     emitImplementationPostamble();
/* 2069 */     endBlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printGetterImpls(String parentJavaName, SchemaProperty prop, QName qName, boolean isAttr, String propertyName, int javaType, String type, String xtype, boolean nillable, boolean optional, boolean several, boolean singleton, boolean isunion, String identifier, String setIdentifier) throws IOException {
/* 2080 */     String propdesc = "\"" + qName.getLocalPart() + "\"" + (isAttr ? " attribute" : " element");
/* 2081 */     boolean xmltype = (javaType == 0);
/* 2082 */     String jtargetType = (isunion || !xmltype) ? "org.apache.xmlbeans.SimpleValue" : xtype;
/*      */     
/* 2084 */     if (singleton) {
/*      */ 
/*      */       
/* 2087 */       printJavaDoc((several ? "Gets first " : "Gets the ") + propdesc);
/* 2088 */       emit("public " + type + " get" + propertyName + "()");
/* 2089 */       startBlock();
/* 2090 */       emitImplementationPreamble();
/*      */       
/* 2092 */       emitGetTarget(setIdentifier, identifier, isAttr, "0", 1, jtargetType);
/*      */       
/* 2094 */       if (isAttr && (prop.hasDefault() == 2 || prop.hasFixed() == 2)) {
/*      */ 
/*      */         
/* 2097 */         emit("if (target == null)");
/* 2098 */         startBlock();
/* 2099 */         makeAttributeDefaultValue(jtargetType, prop, identifier);
/* 2100 */         endBlock();
/*      */       } 
/* 2102 */       emit("if (target == null)");
/* 2103 */       startBlock();
/* 2104 */       makeMissingValue(javaType);
/* 2105 */       endBlock();
/*      */ 
/*      */       
/* 2108 */       printJGetValue(javaType, type, (SchemaTypeImpl)prop.getType());
/*      */ 
/*      */       
/* 2111 */       emitImplementationPostamble();
/*      */       
/* 2113 */       endBlock();
/*      */       
/* 2115 */       if (!xmltype) {
/*      */ 
/*      */         
/* 2118 */         printJavaDoc((several ? "Gets (as xml) first " : "Gets (as xml) the ") + propdesc);
/* 2119 */         emit("public " + xtype + " xget" + propertyName + "()");
/* 2120 */         startBlock();
/* 2121 */         emitImplementationPreamble();
/* 2122 */         emitGetTarget(setIdentifier, identifier, isAttr, "0", 1, xtype);
/*      */         
/* 2124 */         if (isAttr && (prop.hasDefault() == 2 || prop.hasFixed() == 2)) {
/*      */ 
/*      */           
/* 2127 */           emit("if (target == null)");
/* 2128 */           startBlock();
/* 2129 */           makeAttributeDefaultValue(xtype, prop, identifier);
/* 2130 */           endBlock();
/*      */         } 
/*      */         
/* 2133 */         emit("return target;");
/* 2134 */         emitImplementationPostamble();
/* 2135 */         endBlock();
/*      */       } 
/*      */       
/* 2138 */       if (nillable) {
/*      */ 
/*      */         
/* 2141 */         printJavaDoc((several ? "Tests for nil first " : "Tests for nil ") + propdesc);
/* 2142 */         emit("public boolean isNil" + propertyName + "()");
/* 2143 */         startBlock();
/* 2144 */         emitImplementationPreamble();
/* 2145 */         emitGetTarget(setIdentifier, identifier, isAttr, "0", 1, xtype);
/*      */         
/* 2147 */         emit("if (target == null) return false;");
/* 2148 */         emit("return target.isNil();");
/* 2149 */         emitImplementationPostamble();
/* 2150 */         endBlock();
/*      */       } 
/*      */     } 
/*      */     
/* 2154 */     if (optional) {
/*      */ 
/*      */       
/* 2157 */       printJavaDoc((several ? "True if has at least one " : "True if has ") + propdesc);
/* 2158 */       emit("public boolean isSet" + propertyName + "()");
/*      */       
/* 2160 */       startBlock();
/* 2161 */       emitImplementationPreamble();
/*      */       
/* 2163 */       if (isAttr) {
/* 2164 */         emit("return get_store().find_attribute_user(" + identifier + ") != null;");
/*      */       } else {
/* 2166 */         emit("return get_store().count_elements(" + setIdentifier + ") != 0;");
/*      */       } 
/* 2168 */       emitImplementationPostamble();
/* 2169 */       endBlock();
/*      */     } 
/*      */     
/* 2172 */     if (several) {
/*      */       
/* 2174 */       String arrayName = propertyName + "Array";
/*      */       
/* 2176 */       if (this._useJava15) {
/*      */ 
/*      */ 
/*      */         
/* 2180 */         String wrappedType = type;
/* 2181 */         if (isJavaPrimitive(javaType)) {
/* 2182 */           wrappedType = javaWrappedType(javaType);
/*      */         }
/* 2184 */         printListGetter15Impl(parentJavaName, propdesc, propertyName, wrappedType, xtype, xmltype, false);
/*      */       } 
/*      */ 
/*      */       
/* 2188 */       if (this._useJava15) {
/*      */         
/* 2190 */         emit("");
/* 2191 */         emit("/**");
/* 2192 */         emit(" * Gets array of all " + propdesc + "s");
/* 2193 */         emit(" * @deprecated");
/* 2194 */         emit(" */");
/* 2195 */         emit("@Deprecated");
/*      */       } else {
/*      */         
/* 2198 */         printJavaDoc("Gets array of all " + propdesc + "s");
/* 2199 */       }  emit("public " + type + "[] get" + arrayName + "()");
/* 2200 */       startBlock();
/* 2201 */       emitImplementationPreamble();
/*      */       
/* 2203 */       if (this._useJava15) {
/* 2204 */         emit("java.util.List<" + xtype + "> targetList = new java.util.ArrayList<" + xtype + ">();");
/*      */       } else {
/* 2206 */         emit("java.util.List targetList = new java.util.ArrayList();");
/* 2207 */       }  emit("get_store().find_all_element_users(" + setIdentifier + ", targetList);");
/*      */       
/* 2209 */       printJGetArrayValue(javaType, type, (SchemaTypeImpl)prop.getType());
/*      */       
/* 2211 */       emitImplementationPostamble();
/* 2212 */       endBlock();
/*      */ 
/*      */       
/* 2215 */       printJavaDoc("Gets ith " + propdesc);
/* 2216 */       emit("public " + type + " get" + arrayName + "(int i)");
/* 2217 */       startBlock();
/* 2218 */       emitImplementationPreamble();
/*      */       
/* 2220 */       emitGetTarget(setIdentifier, identifier, isAttr, "i", 4, jtargetType);
/* 2221 */       printJGetValue(javaType, type, (SchemaTypeImpl)prop.getType());
/*      */       
/* 2223 */       emitImplementationPostamble();
/* 2224 */       endBlock();
/*      */       
/* 2226 */       if (!xmltype) {
/*      */         
/* 2228 */         if (this._useJava15)
/*      */         {
/* 2230 */           printListGetter15Impl(parentJavaName, propdesc, propertyName, xtype, xtype, xmltype, true);
/*      */         }
/*      */ 
/*      */         
/* 2234 */         if (this._useJava15) {
/*      */           
/* 2236 */           emit("");
/* 2237 */           emit("/**");
/* 2238 */           emit(" * Gets array of all " + propdesc + "s");
/* 2239 */           emit(" * @deprecated");
/* 2240 */           emit(" */");
/* 2241 */           emit("@Deprecated");
/*      */         } else {
/*      */           
/* 2244 */           printJavaDoc("Gets (as xml) array of all " + propdesc + "s");
/* 2245 */         }  emit("public " + xtype + "[] xget" + arrayName + "()");
/* 2246 */         startBlock();
/* 2247 */         emitImplementationPreamble();
/* 2248 */         if (this._useJava15) {
/* 2249 */           emit("java.util.List<" + xtype + "> targetList = new java.util.ArrayList<" + xtype + ">();");
/*      */         } else {
/* 2251 */           emit("java.util.List targetList = new java.util.ArrayList();");
/* 2252 */         }  emit("get_store().find_all_element_users(" + setIdentifier + ", targetList);");
/* 2253 */         emit(xtype + "[] result = new " + xtype + "[targetList.size()];");
/* 2254 */         emit("targetList.toArray(result);");
/* 2255 */         emit("return result;");
/* 2256 */         emitImplementationPostamble();
/* 2257 */         endBlock();
/*      */ 
/*      */         
/* 2260 */         printJavaDoc("Gets (as xml) ith " + propdesc);
/* 2261 */         emit("public " + xtype + " xget" + arrayName + "(int i)");
/* 2262 */         startBlock();
/* 2263 */         emitImplementationPreamble();
/* 2264 */         emitGetTarget(setIdentifier, identifier, isAttr, "i", 4, xtype);
/* 2265 */         emit("return target;");
/* 2266 */         emitImplementationPostamble();
/* 2267 */         endBlock();
/*      */       } 
/*      */ 
/*      */       
/* 2271 */       if (nillable) {
/*      */ 
/*      */         
/* 2274 */         printJavaDoc("Tests for nil ith " + propdesc);
/* 2275 */         emit("public boolean isNil" + arrayName + "(int i)");
/* 2276 */         startBlock();
/* 2277 */         emitImplementationPreamble();
/* 2278 */         emitGetTarget(setIdentifier, identifier, isAttr, "i", 4, xtype);
/* 2279 */         emit("return target.isNil();");
/* 2280 */         emitImplementationPostamble();
/* 2281 */         endBlock();
/*      */       } 
/*      */ 
/*      */       
/* 2285 */       printJavaDoc("Returns number of " + propdesc);
/* 2286 */       emit("public int sizeOf" + arrayName + "()");
/* 2287 */       startBlock();
/* 2288 */       emitImplementationPreamble();
/* 2289 */       emit("return get_store().count_elements(" + setIdentifier + ");");
/* 2290 */       emitImplementationPostamble();
/* 2291 */       endBlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printSetterImpls(QName qName, SchemaProperty prop, boolean isAttr, String propertyName, int javaType, String type, String xtype, boolean nillable, boolean optional, boolean several, boolean singleton, boolean isunion, String identifier, String setIdentifier, SchemaType sType) throws IOException {
/* 2301 */     String safeVarName = NameUtil.nonJavaKeyword(NameUtil.lowerCamelCase(propertyName));
/* 2302 */     safeVarName = NameUtil.nonExtraKeyword(safeVarName);
/*      */     
/* 2304 */     boolean xmltype = (javaType == 0);
/* 2305 */     boolean isobj = (javaType == 19);
/* 2306 */     boolean isSubstGroup = (identifier != setIdentifier);
/* 2307 */     String jtargetType = (isunion || !xmltype) ? "org.apache.xmlbeans.SimpleValue" : xtype;
/*      */     
/* 2309 */     String propdesc = "\"" + qName.getLocalPart() + "\"" + (isAttr ? " attribute" : " element");
/*      */     
/* 2311 */     if (singleton) {
/*      */ 
/*      */       
/* 2314 */       printJavaDoc((several ? "Sets first " : "Sets the ") + propdesc);
/* 2315 */       emit("public void set" + propertyName + "(" + type + " " + safeVarName + ")");
/* 2316 */       startBlock();
/* 2317 */       if (xmltype && !isSubstGroup) {
/*      */         
/* 2319 */         emitPre(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2320 */         emit("generatedSetterHelperImpl(" + safeVarName + ", " + setIdentifier + ", 0, " + "org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);");
/*      */         
/* 2322 */         emitPost(sType, 1, identifier, isAttr, several ? "0" : "-1");
/*      */       }
/*      */       else {
/*      */         
/* 2326 */         emitImplementationPreamble();
/* 2327 */         emitPre(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2328 */         emitGetTarget(setIdentifier, identifier, isAttr, "0", 3, jtargetType);
/* 2329 */         printJSetValue(javaType, safeVarName, (SchemaTypeImpl)prop.getType());
/* 2330 */         emitPost(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2331 */         emitImplementationPostamble();
/*      */       } 
/* 2333 */       endBlock();
/*      */       
/* 2335 */       if (!xmltype) {
/*      */ 
/*      */         
/* 2338 */         printJavaDoc((several ? "Sets (as xml) first " : "Sets (as xml) the ") + propdesc);
/* 2339 */         emit("public void xset" + propertyName + "(" + xtype + " " + safeVarName + ")");
/* 2340 */         startBlock();
/* 2341 */         emitImplementationPreamble();
/* 2342 */         emitPre(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2343 */         emitGetTarget(setIdentifier, identifier, isAttr, "0", 3, xtype);
/* 2344 */         emit("target.set(" + safeVarName + ");");
/* 2345 */         emitPost(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2346 */         emitImplementationPostamble();
/* 2347 */         endBlock();
/*      */       } 
/*      */ 
/*      */       
/* 2351 */       if (xmltype && !several) {
/*      */ 
/*      */         
/* 2354 */         printJavaDoc("Appends and returns a new empty " + propdesc);
/* 2355 */         emit("public " + xtype + " addNew" + propertyName + "()");
/* 2356 */         startBlock();
/* 2357 */         emitImplementationPreamble();
/* 2358 */         emitDeclareTarget(true, xtype);
/* 2359 */         emitPre(sType, 2, identifier, isAttr);
/* 2360 */         emitAddTarget(identifier, isAttr, true, xtype);
/* 2361 */         emitPost(sType, 2, identifier, isAttr);
/* 2362 */         emit("return target;");
/* 2363 */         emitImplementationPostamble();
/* 2364 */         endBlock();
/*      */       } 
/*      */       
/* 2367 */       if (nillable) {
/*      */         
/* 2369 */         printJavaDoc((several ? "Nils the first " : "Nils the ") + propdesc);
/* 2370 */         emit("public void setNil" + propertyName + "()");
/* 2371 */         startBlock();
/* 2372 */         emitImplementationPreamble();
/* 2373 */         emitPre(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2374 */         emitGetTarget(setIdentifier, identifier, isAttr, "0", 3, xtype);
/* 2375 */         emit("target.setNil();");
/* 2376 */         emitPost(sType, 1, identifier, isAttr, several ? "0" : "-1");
/* 2377 */         emitImplementationPostamble();
/* 2378 */         endBlock();
/*      */       } 
/*      */     } 
/*      */     
/* 2382 */     if (optional) {
/*      */       
/* 2384 */       printJavaDoc((several ? "Removes first " : "Unsets the ") + propdesc);
/* 2385 */       emit("public void unset" + propertyName + "()");
/* 2386 */       startBlock();
/* 2387 */       emitImplementationPreamble();
/* 2388 */       emitPre(sType, 3, identifier, isAttr, several ? "0" : "-1");
/* 2389 */       if (isAttr) {
/* 2390 */         emit("get_store().remove_attribute(" + identifier + ");");
/*      */       } else {
/* 2392 */         emit("get_store().remove_element(" + setIdentifier + ", 0);");
/* 2393 */       }  emitPost(sType, 3, identifier, isAttr, several ? "0" : "-1");
/* 2394 */       emitImplementationPostamble();
/* 2395 */       endBlock();
/*      */     } 
/*      */     
/* 2398 */     if (several) {
/*      */       
/* 2400 */       String arrayName = propertyName + "Array";
/*      */       
/* 2402 */       if (xmltype) {
/*      */         
/* 2404 */         printJavaDoc("Sets array of all " + propdesc + "  WARNING: This method is not atomicaly synchronized.");
/* 2405 */         emit("public void set" + arrayName + "(" + type + "[] " + safeVarName + "Array)");
/* 2406 */         startBlock();
/*      */ 
/*      */         
/* 2409 */         emit("check_orphaned();");
/* 2410 */         emitPre(sType, 1, identifier, isAttr);
/*      */         
/* 2412 */         if (isobj) {
/*      */           
/* 2414 */           if (!isSubstGroup) {
/* 2415 */             emit("unionArraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ");");
/*      */           } else {
/* 2417 */             emit("unionArraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ", " + setIdentifier + ");");
/*      */           }
/*      */         
/*      */         }
/* 2421 */         else if (!isSubstGroup) {
/* 2422 */           emit("arraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ");");
/*      */         } else {
/* 2424 */           emit("arraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ", " + setIdentifier + ");");
/*      */         } 
/*      */         
/* 2427 */         emitPost(sType, 1, identifier, isAttr);
/*      */         
/* 2429 */         endBlock();
/*      */       }
/*      */       else {
/*      */         
/* 2433 */         printJavaDoc("Sets array of all " + propdesc);
/* 2434 */         emit("public void set" + arrayName + "(" + type + "[] " + safeVarName + "Array)");
/* 2435 */         startBlock();
/* 2436 */         emitImplementationPreamble();
/* 2437 */         emitPre(sType, 1, identifier, isAttr);
/*      */         
/* 2439 */         if (isobj) {
/*      */           
/* 2441 */           if (!isSubstGroup) {
/* 2442 */             emit("unionArraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ");");
/*      */           } else {
/* 2444 */             emit("unionArraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ", " + setIdentifier + ");");
/*      */           } 
/* 2446 */         } else if (prop.getJavaTypeCode() == 20) {
/*      */           
/* 2448 */           if (!isSubstGroup)
/*      */           {
/* 2450 */             emit("org.apache.xmlbeans.SimpleValue[] dests = arraySetterHelper(" + safeVarName + "Array.length" + ", " + identifier + ");");
/* 2451 */             emit("for ( int i = 0 ; i < dests.length ; i++ ) {");
/* 2452 */             emit("    " + getUserTypeStaticHandlerMethod(true, (SchemaTypeImpl)prop.getType()) + "(" + safeVarName + "Array[i], dests[i]);");
/*      */             
/* 2454 */             emit("}");
/*      */           }
/*      */           else
/*      */           {
/* 2458 */             emit("org.apache.xmlbeans.SimpleValue[] dests = arraySetterHelper(" + safeVarName + "Array.length" + ", " + identifier + ", " + setIdentifier + ");");
/* 2459 */             emit("for ( int i = 0 ; i < dests.length ; i++ ) {");
/* 2460 */             emit("    " + getUserTypeStaticHandlerMethod(true, (SchemaTypeImpl)prop.getType()) + "(" + safeVarName + "Array[i], dests[i]);");
/*      */             
/* 2462 */             emit("}");
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 2467 */         else if (!isSubstGroup) {
/* 2468 */           emit("arraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ");");
/*      */         } else {
/* 2470 */           emit("arraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ", " + setIdentifier + ");");
/*      */         } 
/*      */         
/* 2473 */         emitPost(sType, 1, identifier, isAttr);
/* 2474 */         emitImplementationPostamble();
/* 2475 */         endBlock();
/*      */       } 
/*      */       
/* 2478 */       printJavaDoc("Sets ith " + propdesc);
/* 2479 */       emit("public void set" + arrayName + "(int i, " + type + " " + safeVarName + ")");
/* 2480 */       startBlock();
/* 2481 */       if (xmltype && !isSubstGroup) {
/*      */         
/* 2483 */         emitPre(sType, 1, identifier, isAttr, "i");
/* 2484 */         emit("generatedSetterHelperImpl(" + safeVarName + ", " + setIdentifier + ", i, " + "org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);");
/*      */         
/* 2486 */         emitPost(sType, 1, identifier, isAttr, "i");
/*      */       }
/*      */       else {
/*      */         
/* 2490 */         emitImplementationPreamble();
/* 2491 */         emitPre(sType, 1, identifier, isAttr, "i");
/* 2492 */         emitGetTarget(setIdentifier, identifier, isAttr, "i", 4, jtargetType);
/* 2493 */         printJSetValue(javaType, safeVarName, (SchemaTypeImpl)prop.getType());
/* 2494 */         emitPost(sType, 1, identifier, isAttr, "i");
/* 2495 */         emitImplementationPostamble();
/*      */       } 
/* 2497 */       endBlock();
/*      */       
/* 2499 */       if (!xmltype) {
/*      */         
/* 2501 */         printJavaDoc("Sets (as xml) array of all " + propdesc);
/* 2502 */         emit("public void xset" + arrayName + "(" + xtype + "[]" + safeVarName + "Array)");
/* 2503 */         startBlock();
/* 2504 */         emitImplementationPreamble();
/* 2505 */         emitPre(sType, 1, identifier, isAttr);
/* 2506 */         emit("arraySetterHelper(" + safeVarName + "Array" + ", " + identifier + ");");
/* 2507 */         emitPost(sType, 1, identifier, isAttr);
/* 2508 */         emitImplementationPostamble();
/* 2509 */         endBlock();
/*      */         
/* 2511 */         printJavaDoc("Sets (as xml) ith " + propdesc);
/* 2512 */         emit("public void xset" + arrayName + "(int i, " + xtype + " " + safeVarName + ")");
/* 2513 */         startBlock();
/* 2514 */         emitImplementationPreamble();
/* 2515 */         emitPre(sType, 1, identifier, isAttr, "i");
/* 2516 */         emitGetTarget(setIdentifier, identifier, isAttr, "i", 4, xtype);
/* 2517 */         emit("target.set(" + safeVarName + ");");
/* 2518 */         emitPost(sType, 1, identifier, isAttr, "i");
/* 2519 */         emitImplementationPostamble();
/* 2520 */         endBlock();
/*      */       } 
/*      */       
/* 2523 */       if (nillable) {
/*      */         
/* 2525 */         printJavaDoc("Nils the ith " + propdesc);
/* 2526 */         emit("public void setNil" + arrayName + "(int i)");
/* 2527 */         startBlock();
/* 2528 */         emitImplementationPreamble();
/* 2529 */         emitPre(sType, 1, identifier, isAttr, "i");
/* 2530 */         emitGetTarget(setIdentifier, identifier, isAttr, "i", 4, xtype);
/* 2531 */         emit("target.setNil();");
/* 2532 */         emitPost(sType, 1, identifier, isAttr, "i");
/* 2533 */         emitImplementationPostamble();
/* 2534 */         endBlock();
/*      */       } 
/*      */       
/* 2537 */       if (!xmltype) {
/*      */         
/* 2539 */         printJavaDoc("Inserts the value as the ith " + propdesc);
/* 2540 */         emit("public void insert" + propertyName + "(int i, " + type + " " + safeVarName + ")");
/* 2541 */         startBlock();
/* 2542 */         emitImplementationPreamble();
/* 2543 */         emitPre(sType, 2, identifier, isAttr, "i");
/* 2544 */         emit(jtargetType + " target = ");
/* 2545 */         indent();
/* 2546 */         if (!isSubstGroup) {
/* 2547 */           emit("(" + jtargetType + ")get_store().insert_element_user(" + identifier + ", i);");
/*      */         } else {
/* 2549 */           emit("(" + jtargetType + ")get_store().insert_element_user(" + setIdentifier + ", " + identifier + ", i);");
/*      */         } 
/* 2551 */         outdent();
/* 2552 */         printJSetValue(javaType, safeVarName, (SchemaTypeImpl)prop.getType());
/* 2553 */         emitPost(sType, 2, identifier, isAttr, "i");
/* 2554 */         emitImplementationPostamble();
/* 2555 */         endBlock();
/*      */         
/* 2557 */         printJavaDoc("Appends the value as the last " + propdesc);
/* 2558 */         emit("public void add" + propertyName + "(" + type + " " + safeVarName + ")");
/* 2559 */         startBlock();
/* 2560 */         emitImplementationPreamble();
/* 2561 */         emitDeclareTarget(true, jtargetType);
/* 2562 */         emitPre(sType, 2, identifier, isAttr);
/* 2563 */         emitAddTarget(identifier, isAttr, true, jtargetType);
/* 2564 */         printJSetValue(javaType, safeVarName, (SchemaTypeImpl)prop.getType());
/* 2565 */         emitPost(sType, 2, identifier, isAttr);
/* 2566 */         emitImplementationPostamble();
/* 2567 */         endBlock();
/*      */       } 
/*      */       
/* 2570 */       printJavaDoc("Inserts and returns a new empty value (as xml) as the ith " + propdesc);
/* 2571 */       emit("public " + xtype + " insertNew" + propertyName + "(int i)");
/* 2572 */       startBlock();
/* 2573 */       emitImplementationPreamble();
/* 2574 */       emitDeclareTarget(true, xtype);
/* 2575 */       emitPre(sType, 2, identifier, isAttr, "i");
/* 2576 */       if (!isSubstGroup) {
/*      */         
/* 2578 */         emit("target = (" + xtype + ")get_store().insert_element_user(" + identifier + ", i);");
/*      */       }
/*      */       else {
/*      */         
/* 2582 */         emit("target = (" + xtype + ")get_store().insert_element_user(" + setIdentifier + ", " + identifier + ", i);");
/*      */       } 
/*      */       
/* 2585 */       emitPost(sType, 2, identifier, isAttr, "i");
/* 2586 */       emit("return target;");
/* 2587 */       emitImplementationPostamble();
/* 2588 */       endBlock();
/*      */       
/* 2590 */       printJavaDoc("Appends and returns a new empty value (as xml) as the last " + propdesc);
/* 2591 */       emit("public " + xtype + " addNew" + propertyName + "()");
/* 2592 */       startBlock();
/* 2593 */       emitImplementationPreamble();
/* 2594 */       emitDeclareTarget(true, xtype);
/* 2595 */       emitPre(sType, 2, identifier, isAttr);
/* 2596 */       emitAddTarget(identifier, isAttr, true, xtype);
/* 2597 */       emitPost(sType, 2, identifier, isAttr);
/* 2598 */       emit("return target;");
/* 2599 */       emitImplementationPostamble();
/* 2600 */       endBlock();
/*      */       
/* 2602 */       printJavaDoc("Removes the ith " + propdesc);
/* 2603 */       emit("public void remove" + propertyName + "(int i)");
/* 2604 */       startBlock();
/* 2605 */       emitImplementationPreamble();
/* 2606 */       emitPre(sType, 3, identifier, isAttr, "i");
/* 2607 */       emit("get_store().remove_element(" + setIdentifier + ", i);");
/* 2608 */       emitPost(sType, 3, identifier, isAttr, "i");
/* 2609 */       emitImplementationPostamble();
/* 2610 */       endBlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   static void getTypeName(Class c, StringBuffer sb) {
/* 2615 */     int arrayCount = 0;
/* 2616 */     while (c.isArray()) {
/* 2617 */       c = c.getComponentType();
/* 2618 */       arrayCount++;
/*      */     } 
/*      */     
/* 2621 */     sb.append(c.getName());
/*      */     
/* 2623 */     for (int i = 0; i < arrayCount; i++) {
/* 2624 */       sb.append("[]");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void printInnerTypeImpl(SchemaType sType, SchemaTypeSystem system, boolean isInner) throws IOException {
/* 2631 */     String shortName = sType.getShortJavaImplName();
/*      */     
/* 2633 */     printInnerTypeJavaDoc(sType);
/*      */     
/* 2635 */     startClass(sType, isInner);
/*      */     
/* 2637 */     printConstructor(sType, shortName);
/*      */     
/* 2639 */     printExtensionImplMethods(sType);
/*      */     
/* 2641 */     if (!sType.isSimpleType()) {
/*      */       SchemaProperty[] properties;
/*      */ 
/*      */       
/* 2645 */       if (sType.getContentType() == 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2654 */         SchemaType baseType = sType.getBaseType();
/* 2655 */         List extraProperties = null;
/* 2656 */         while (!baseType.isSimpleType() && !baseType.isBuiltinType()) {
/*      */           
/* 2658 */           SchemaProperty[] baseProperties = baseType.getDerivedProperties();
/* 2659 */           for (int j = 0; j < baseProperties.length; j++) {
/* 2660 */             if (!baseProperties[j].isAttribute() || sType.getAttributeProperty(baseProperties[j].getName()) == null) {
/*      */ 
/*      */               
/* 2663 */               if (extraProperties == null)
/* 2664 */                 extraProperties = new ArrayList(); 
/* 2665 */               extraProperties.add(baseProperties[j]);
/*      */             } 
/* 2667 */           }  baseType = baseType.getBaseType();
/*      */         } 
/*      */         
/* 2670 */         properties = sType.getProperties();
/* 2671 */         if (extraProperties != null)
/*      */         {
/* 2673 */           for (int j = 0; j < properties.length; j++)
/* 2674 */             extraProperties.add(properties[j]); 
/* 2675 */           properties = extraProperties.<SchemaProperty>toArray(new SchemaProperty[extraProperties.size()]);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2684 */         properties = getDerivedProperties(sType);
/*      */       } 
/*      */       
/* 2687 */       Map qNameMap = printStaticFields(properties);
/*      */       
/* 2689 */       for (int i = 0; i < properties.length; i++) {
/*      */         
/* 2691 */         SchemaProperty prop = properties[i];
/*      */         
/* 2693 */         QName name = prop.getName();
/* 2694 */         String xmlType = xmlTypeForProperty(prop);
/*      */         
/* 2696 */         printGetterImpls(shortName, prop, name, prop.isAttribute(), prop.getJavaPropertyName(), prop.getJavaTypeCode(), javaTypeForProperty(prop), xmlType, (prop.hasNillable() != 0), prop.extendsJavaOption(), prop.extendsJavaArray(), prop.extendsJavaSingleton(), xmlTypeForPropertyIsUnion(prop), getIdentifier(qNameMap, name), getSetIdentifier(qNameMap, name));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2714 */         if (!prop.isReadOnly())
/*      */         {
/* 2716 */           printSetterImpls(name, prop, prop.isAttribute(), prop.getJavaPropertyName(), prop.getJavaTypeCode(), javaTypeForProperty(prop), xmlType, (prop.hasNillable() != 0), prop.extendsJavaOption(), prop.extendsJavaArray(), prop.extendsJavaSingleton(), xmlTypeForPropertyIsUnion(prop), getIdentifier(qNameMap, name), getSetIdentifier(qNameMap, name), sType);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2737 */     printNestedTypeImpls(sType, system);
/*      */     
/* 2739 */     endBlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SchemaProperty[] getDerivedProperties(SchemaType sType) {
/* 2746 */     QName name = sType.getName();
/* 2747 */     if (name != null && name.equals(sType.getBaseType().getName())) {
/*      */       
/* 2749 */       SchemaType sType2 = sType.getBaseType();
/*      */ 
/*      */ 
/*      */       
/* 2753 */       SchemaProperty[] props = sType.getDerivedProperties();
/* 2754 */       Map propsByName = new LinkedHashMap(); int i;
/* 2755 */       for (i = 0; i < props.length; i++)
/* 2756 */         propsByName.put(props[i].getName(), props[i]); 
/* 2757 */       while (sType2 != null && name.equals(sType2.getName())) {
/*      */         
/* 2759 */         props = sType2.getDerivedProperties();
/* 2760 */         for (i = 0; i < props.length; i++) {
/* 2761 */           if (!propsByName.containsKey(props[i].getName()))
/* 2762 */             propsByName.put(props[i].getName(), props[i]); 
/* 2763 */         }  sType2 = sType2.getBaseType();
/*      */       } 
/* 2765 */       return (SchemaProperty[])propsByName.values().toArray((Object[])new SchemaProperty[0]);
/*      */     } 
/*      */     
/* 2768 */     return sType.getDerivedProperties();
/*      */   }
/*      */ 
/*      */   
/*      */   private void printExtensionImplMethods(SchemaType sType) throws IOException {
/* 2773 */     SchemaTypeImpl sImpl = getImpl(sType);
/* 2774 */     if (sImpl == null) {
/*      */       return;
/*      */     }
/* 2777 */     InterfaceExtension[] exts = sImpl.getInterfaceExtensions();
/* 2778 */     if (exts != null) for (int i = 0; i < exts.length; i++) {
/*      */         
/* 2780 */         InterfaceExtension.MethodSignature[] methods = exts[i].getMethods();
/* 2781 */         if (methods != null)
/*      */         {
/* 2783 */           for (int j = 0; j < methods.length; j++) {
/*      */             
/* 2785 */             printJavaDoc("Implementation method for interface " + exts[i].getStaticHandler());
/* 2786 */             printInterfaceMethodDecl(methods[j]);
/* 2787 */             startBlock();
/* 2788 */             printInterfaceMethodImpl(exts[i].getStaticHandler(), methods[j]);
/* 2789 */             endBlock();
/*      */           } 
/*      */         }
/*      */       } 
/*      */   
/*      */   }
/*      */   
/*      */   void printInterfaceMethodDecl(InterfaceExtension.MethodSignature method) throws IOException {
/* 2797 */     StringBuffer decl = new StringBuffer(60);
/*      */     
/* 2799 */     decl.append("public ").append(method.getReturnType());
/* 2800 */     decl.append(" ").append(method.getName()).append("(");
/*      */     
/* 2802 */     String[] paramTypes = method.getParameterTypes();
/* 2803 */     for (int i = 0; i < paramTypes.length; i++) {
/*      */       
/* 2805 */       if (i != 0)
/* 2806 */         decl.append(", "); 
/* 2807 */       decl.append(paramTypes[i]).append(" p").append(i);
/*      */     } 
/*      */     
/* 2810 */     decl.append(")");
/*      */     
/* 2812 */     String[] exceptions = method.getExceptionTypes();
/* 2813 */     for (int j = 0; j < exceptions.length; j++) {
/* 2814 */       decl.append(((j == 0) ? " throws " : ", ") + exceptions[j]);
/*      */     }
/* 2816 */     emit(decl.toString());
/*      */   }
/*      */ 
/*      */   
/*      */   void printInterfaceMethodImpl(String handler, InterfaceExtension.MethodSignature method) throws IOException {
/* 2821 */     StringBuffer impl = new StringBuffer(60);
/*      */     
/* 2823 */     if (!method.getReturnType().equals("void")) {
/* 2824 */       impl.append("return ");
/*      */     }
/* 2826 */     impl.append(handler).append(".").append(method.getName()).append("(this");
/*      */     
/* 2828 */     String[] params = method.getParameterTypes();
/* 2829 */     for (int i = 0; i < params.length; i++) {
/* 2830 */       impl.append(", p" + i);
/*      */     }
/* 2832 */     impl.append(");");
/*      */     
/* 2834 */     emit(impl.toString());
/*      */   }
/*      */ 
/*      */   
/*      */   void printNestedTypeImpls(SchemaType sType, SchemaTypeSystem system) throws IOException {
/* 2839 */     boolean redefinition = (sType.getName() != null && sType.getName().equals(sType.getBaseType().getName()));
/*      */     
/* 2841 */     while (sType != null) {
/*      */       
/* 2843 */       SchemaType[] anonTypes = sType.getAnonymousTypes();
/* 2844 */       for (int i = 0; i < anonTypes.length; i++) {
/*      */         
/* 2846 */         if (anonTypes[i].isSkippedAnonymousType()) {
/* 2847 */           printNestedTypeImpls(anonTypes[i], system);
/*      */         } else {
/* 2849 */           printInnerTypeImpl(anonTypes[i], system, true);
/*      */         } 
/*      */       } 
/*      */       
/* 2853 */       if (!redefinition || (sType.getDerivationType() != 2 && !sType.isSimpleType())) {
/*      */         break;
/*      */       }
/* 2856 */       sType = sType.getBaseType();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaTypeCodePrinter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */