/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.QNameSet;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Element;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.KeyrefDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StscResolver
/*     */ {
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public static void resolveAll() {
/*  44 */     StscState state = StscState.get();
/*     */     
/*  46 */     SchemaType[] documentTypes = state.documentTypes();
/*  47 */     for (int i = 0; i < documentTypes.length; i++) {
/*  48 */       resolveSubstitutionGroup((SchemaTypeImpl)documentTypes[i]);
/*     */     }
/*  50 */     List allSeenTypes = new ArrayList();
/*  51 */     allSeenTypes.addAll(Arrays.asList(state.documentTypes()));
/*  52 */     allSeenTypes.addAll(Arrays.asList(state.attributeTypes()));
/*  53 */     allSeenTypes.addAll(Arrays.asList(state.redefinedGlobalTypes()));
/*  54 */     allSeenTypes.addAll(Arrays.asList(state.globalTypes()));
/*     */     
/*  56 */     for (int j = 0; j < allSeenTypes.size(); j++) {
/*     */       
/*  58 */       SchemaType gType = allSeenTypes.get(j);
/*  59 */       resolveType((SchemaTypeImpl)gType);
/*  60 */       allSeenTypes.addAll(Arrays.asList(gType.getAnonymousTypes()));
/*     */     } 
/*     */ 
/*     */     
/*  64 */     resolveIdentityConstraints();
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean resolveType(SchemaTypeImpl sImpl) {
/*  69 */     if (sImpl.isResolved())
/*  70 */       return true; 
/*  71 */     if (sImpl.isResolving()) {
/*     */       
/*  73 */       StscState.get().error("Cyclic dependency error", 13, sImpl.getParseObject());
/*  74 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  78 */     sImpl.startResolving();
/*     */     
/*  80 */     if (sImpl.isDocumentType()) {
/*  81 */       resolveDocumentType(sImpl);
/*  82 */     } else if (sImpl.isAttributeType()) {
/*  83 */       resolveAttributeType(sImpl);
/*  84 */     } else if (sImpl.isSimpleType()) {
/*  85 */       StscSimpleTypeResolver.resolveSimpleType(sImpl);
/*     */     } else {
/*  87 */       StscComplexTypeResolver.resolveComplexType(sImpl);
/*     */     } 
/*  89 */     sImpl.finishResolving();
/*     */     
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean resolveSubstitutionGroup(SchemaTypeImpl sImpl) {
/*  96 */     assert sImpl.isDocumentType();
/*     */     
/*  98 */     if (sImpl.isSGResolved())
/*  99 */       return true; 
/* 100 */     if (sImpl.isSGResolving()) {
/*     */       
/* 102 */       StscState.get().error("Cyclic dependency error", 13, sImpl.getParseObject());
/* 103 */       return false;
/*     */     } 
/*     */     
/* 106 */     sImpl.startResolvingSGs();
/*     */ 
/*     */ 
/*     */     
/* 110 */     TopLevelElement elt = (TopLevelElement)sImpl.getParseObject();
/* 111 */     SchemaTypeImpl substitutionGroup = null;
/* 112 */     QName eltName = new QName(sImpl.getTargetNamespace(), elt.getName());
/*     */ 
/*     */     
/* 115 */     if (elt.isSetSubstitutionGroup()) {
/*     */       
/* 117 */       substitutionGroup = StscState.get().findDocumentType(elt.getSubstitutionGroup(), sImpl.getChameleonNamespace(), sImpl.getTargetNamespace());
/*     */ 
/*     */       
/* 120 */       if (substitutionGroup == null) {
/* 121 */         StscState.get().notFoundError(elt.getSubstitutionGroup(), 1, (XmlObject)elt.xgetSubstitutionGroup(), true);
/*     */       }
/* 123 */       else if (!resolveSubstitutionGroup(substitutionGroup)) {
/* 124 */         substitutionGroup = null;
/*     */       } else {
/* 126 */         sImpl.setSubstitutionGroup(elt.getSubstitutionGroup());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 131 */     while (substitutionGroup != null) {
/*     */ 
/*     */       
/* 134 */       substitutionGroup.addSubstitutionGroupMember(eltName);
/*     */       
/* 136 */       if (substitutionGroup.getSubstitutionGroup() == null) {
/*     */         break;
/*     */       }
/* 139 */       substitutionGroup = StscState.get().findDocumentType(substitutionGroup.getSubstitutionGroup(), substitutionGroup.getChameleonNamespace(), null);
/*     */ 
/*     */       
/* 142 */       assert substitutionGroup != null : "Could not find document type for: " + substitutionGroup.getSubstitutionGroup();
/*     */       
/* 144 */       if (!resolveSubstitutionGroup(substitutionGroup)) {
/* 145 */         substitutionGroup = null;
/*     */       }
/*     */     } 
/*     */     
/* 149 */     sImpl.finishResolvingSGs();
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resolveDocumentType(SchemaTypeImpl sImpl) {
/* 156 */     assert sImpl.isResolving();
/*     */     
/* 158 */     assert sImpl.isDocumentType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     List anonTypes = new ArrayList();
/*     */     
/* 166 */     SchemaGlobalElementImpl element = (SchemaGlobalElementImpl)StscTranslator.translateElement((Element)sImpl.getParseObject(), sImpl.getTargetNamespace(), sImpl.isChameleon(), null, null, anonTypes, sImpl);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     SchemaLocalElementImpl contentModel = null;
/*     */     
/* 175 */     if (element != null) {
/*     */       
/* 177 */       StscState.get().addGlobalElement(element);
/*     */       
/* 179 */       contentModel = new SchemaLocalElementImpl();
/*     */       
/* 181 */       contentModel.setParticleType(4);
/* 182 */       StscTranslator.copyGlobalElementToLocalElement(element, contentModel);
/* 183 */       contentModel.setMinOccurs(BigInteger.ONE);
/* 184 */       contentModel.setMaxOccurs(BigInteger.ONE);
/*     */       
/* 186 */       contentModel.setTransitionNotes(QNameSet.EMPTY, true);
/*     */     } 
/*     */     
/* 189 */     Map elementPropertyModel = StscComplexTypeResolver.buildContentPropertyModelByQName(contentModel, sImpl);
/*     */ 
/*     */ 
/*     */     
/* 193 */     SchemaTypeImpl baseType = (sImpl.getSubstitutionGroup() == null) ? BuiltinSchemaTypeSystem.ST_ANY_TYPE : StscState.get().findDocumentType(sImpl.getSubstitutionGroup(), sImpl.isChameleon() ? sImpl.getTargetNamespace() : null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     sImpl.setBaseTypeRef(baseType.getRef());
/* 200 */     sImpl.setBaseDepth(baseType.getBaseDepth() + 1);
/* 201 */     sImpl.setDerivationType(1);
/* 202 */     sImpl.setComplexTypeVariety(3);
/*     */     
/* 204 */     sImpl.setContentModel(contentModel, new SchemaAttributeModelImpl(), elementPropertyModel, Collections.EMPTY_MAP, false);
/*     */ 
/*     */ 
/*     */     
/* 208 */     sImpl.setWildcardSummary(QNameSet.EMPTY, false, QNameSet.EMPTY, false);
/*     */ 
/*     */     
/* 211 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resolveAttributeType(SchemaTypeImpl sImpl) {
/* 219 */     assert sImpl.isResolving();
/*     */     
/* 221 */     assert sImpl.isAttributeType();
/*     */     
/* 223 */     List anonTypes = new ArrayList();
/*     */     
/* 225 */     SchemaGlobalAttributeImpl attribute = (SchemaGlobalAttributeImpl)StscTranslator.translateAttribute((Attribute)sImpl.getParseObject(), sImpl.getTargetNamespace(), null, sImpl.isChameleon(), anonTypes, sImpl, null, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     SchemaAttributeModelImpl attributeModel = new SchemaAttributeModelImpl();
/*     */     
/* 232 */     if (attribute != null) {
/*     */       
/* 234 */       StscState.get().addGlobalAttribute(attribute);
/*     */       
/* 236 */       SchemaLocalAttributeImpl attributeCopy = new SchemaLocalAttributeImpl();
/* 237 */       StscTranslator.copyGlobalAttributeToLocalAttribute(attribute, attributeCopy);
/* 238 */       attributeModel.addAttribute(attributeCopy);
/*     */     } 
/*     */     
/* 241 */     sImpl.setBaseTypeRef(BuiltinSchemaTypeSystem.ST_ANY_TYPE.getRef());
/* 242 */     sImpl.setBaseDepth(sImpl.getBaseDepth() + 1);
/* 243 */     sImpl.setDerivationType(1);
/* 244 */     sImpl.setComplexTypeVariety(1);
/*     */     
/* 246 */     Map attributePropertyModel = StscComplexTypeResolver.buildAttributePropertyModelByQName(attributeModel, sImpl);
/*     */ 
/*     */ 
/*     */     
/* 250 */     sImpl.setContentModel(null, attributeModel, Collections.EMPTY_MAP, attributePropertyModel, false);
/*     */ 
/*     */     
/* 253 */     sImpl.setWildcardSummary(QNameSet.EMPTY, false, QNameSet.EMPTY, false);
/*     */ 
/*     */     
/* 256 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonTypes));
/*     */   }
/*     */ 
/*     */   
/*     */   private static SchemaType.Ref[] makeRefArray(Collection typeList) {
/* 261 */     SchemaType.Ref[] result = new SchemaType.Ref[typeList.size()];
/* 262 */     int j = 0;
/* 263 */     for (Iterator i = typeList.iterator(); i.hasNext(); j++)
/* 264 */       result[j] = ((SchemaType)i.next()).getRef(); 
/* 265 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resolveIdentityConstraints() {
/* 271 */     StscState state = StscState.get();
/* 272 */     SchemaIdentityConstraintImpl[] idcs = state.idConstraints();
/*     */     
/* 274 */     for (int i = 0; i < idcs.length; i++) {
/*     */       
/* 276 */       if (!idcs[i].isResolved()) {
/*     */         
/* 278 */         KeyrefDocument.Keyref xsdkr = (KeyrefDocument.Keyref)idcs[i].getParseObject();
/* 279 */         QName keyName = xsdkr.getRefer();
/* 280 */         SchemaIdentityConstraintImpl key = null;
/*     */         
/* 282 */         key = state.findIdConstraint(keyName, idcs[i].getChameleonNamespace(), idcs[i].getTargetNamespace());
/* 283 */         if (key == null) {
/*     */           
/* 285 */           state.notFoundError(keyName, 5, (XmlObject)xsdkr, true);
/*     */         }
/*     */         else {
/*     */           
/* 289 */           if (key.getConstraintCategory() == 2) {
/* 290 */             state.error("c-props-correct.1", (Object[])null, idcs[i].getParseObject());
/*     */           }
/*     */           
/* 293 */           if ((key.getFields()).length != (idcs[i].getFields()).length) {
/* 294 */             state.error("c-props-correct.2", (Object[])null, idcs[i].getParseObject());
/*     */           }
/*     */           
/* 297 */           idcs[i].setReferencedKey(key.getRef());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */