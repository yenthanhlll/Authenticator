/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.BindingConfig;
/*     */ import org.apache.xmlbeans.Filer;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.common.XmlErrorWatcher;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaTypeSystemCompiler
/*     */ {
/*     */   public static class Parameters
/*     */   {
/*     */     private SchemaTypeSystem existingSystem;
/*     */     private String name;
/*     */     private SchemaDocument.Schema[] schemas;
/*     */     private BindingConfig config;
/*     */     private SchemaTypeLoader linkTo;
/*     */     private XmlOptions options;
/*     */     private Collection errorListener;
/*     */     private boolean javaize;
/*     */     private URI baseURI;
/*     */     private Map sourcesToCopyMap;
/*     */     private File schemasDir;
/*     */     
/*     */     public SchemaTypeSystem getExistingTypeSystem() {
/*  66 */       return this.existingSystem;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setExistingTypeSystem(SchemaTypeSystem system) {
/*  71 */       this.existingSystem = system;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/*  76 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setName(String name) {
/*  81 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public SchemaDocument.Schema[] getSchemas() {
/*  86 */       return this.schemas;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSchemas(SchemaDocument.Schema[] schemas) {
/*  91 */       this.schemas = schemas;
/*     */     }
/*     */ 
/*     */     
/*     */     public BindingConfig getConfig() {
/*  96 */       return this.config;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setConfig(BindingConfig config) {
/* 101 */       this.config = config;
/*     */     }
/*     */ 
/*     */     
/*     */     public SchemaTypeLoader getLinkTo() {
/* 106 */       return this.linkTo;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLinkTo(SchemaTypeLoader linkTo) {
/* 111 */       this.linkTo = linkTo;
/*     */     }
/*     */ 
/*     */     
/*     */     public XmlOptions getOptions() {
/* 116 */       return this.options;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setOptions(XmlOptions options) {
/* 121 */       this.options = options;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection getErrorListener() {
/* 126 */       return this.errorListener;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setErrorListener(Collection errorListener) {
/* 131 */       this.errorListener = errorListener;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isJavaize() {
/* 136 */       return this.javaize;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setJavaize(boolean javaize) {
/* 141 */       this.javaize = javaize;
/*     */     }
/*     */ 
/*     */     
/*     */     public URI getBaseURI() {
/* 146 */       return this.baseURI;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setBaseURI(URI baseURI) {
/* 151 */       this.baseURI = baseURI;
/*     */     }
/*     */ 
/*     */     
/*     */     public Map getSourcesToCopyMap() {
/* 156 */       return this.sourcesToCopyMap;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSourcesToCopyMap(Map sourcesToCopyMap) {
/* 161 */       this.sourcesToCopyMap = sourcesToCopyMap;
/*     */     }
/*     */ 
/*     */     
/*     */     public File getSchemasDir() {
/* 166 */       return this.schemasDir;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSchemasDir(File schemasDir) {
/* 171 */       this.schemasDir = schemasDir;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaTypeSystem compile(Parameters params) {
/* 181 */     return compileImpl(params.getExistingTypeSystem(), params.getName(), params.getSchemas(), params.getConfig(), params.getLinkTo(), params.getOptions(), params.getErrorListener(), params.isJavaize(), params.getBaseURI(), params.getSourcesToCopyMap(), params.getSchemasDir());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaTypeSystemImpl compile(String name, SchemaTypeSystem existingSTS, XmlObject[] input, BindingConfig config, SchemaTypeLoader linkTo, Filer filer, XmlOptions options) throws XmlException {
/* 199 */     options = XmlOptions.maskNull(options);
/* 200 */     ArrayList schemas = new ArrayList();
/*     */     
/* 202 */     if (input != null)
/*     */     {
/* 204 */       for (int i = 0; i < input.length; i++) {
/*     */         
/* 206 */         if (input[i] instanceof SchemaDocument.Schema) {
/* 207 */           schemas.add(input[i]);
/* 208 */         } else if (input[i] instanceof SchemaDocument && ((SchemaDocument)input[i]).getSchema() != null) {
/* 209 */           schemas.add(((SchemaDocument)input[i]).getSchema());
/*     */         } else {
/* 211 */           throw new XmlException("Thread " + Thread.currentThread().getName() + ": The " + i + "th supplied input is not a schema document: its type is " + input[i].schemaType());
/*     */         } 
/*     */       } 
/*     */     }
/* 215 */     Collection userErrors = (Collection)options.get("ERROR_LISTENER");
/* 216 */     XmlErrorWatcher errorWatcher = new XmlErrorWatcher(userErrors);
/*     */     
/* 218 */     SchemaTypeSystemImpl stsi = compileImpl(existingSTS, name, schemas.<SchemaDocument.Schema>toArray(new SchemaDocument.Schema[schemas.size()]), config, linkTo, options, (Collection)errorWatcher, (filer != null), (URI)options.get("BASE_URI"), null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (errorWatcher.hasError() && stsi == null)
/*     */     {
/* 226 */       throw new XmlException(errorWatcher.firstError());
/*     */     }
/*     */     
/* 229 */     if (stsi != null && !stsi.isIncomplete() && filer != null) {
/*     */       
/* 231 */       stsi.save(filer);
/* 232 */       generateTypes(stsi, filer, options);
/*     */     } 
/*     */     
/* 235 */     return stsi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SchemaTypeSystemImpl compileImpl(SchemaTypeSystem system, String name, SchemaDocument.Schema[] schemas, BindingConfig config, SchemaTypeLoader linkTo, XmlOptions options, Collection outsideErrors, boolean javaize, URI baseURI, Map sourcesToCopyMap, File schemasDir) {
/* 246 */     if (linkTo == null) {
/* 247 */       throw new IllegalArgumentException("Must supply linkTo");
/*     */     }
/* 249 */     XmlErrorWatcher errorWatcher = new XmlErrorWatcher(outsideErrors);
/* 250 */     boolean incremental = (system != null);
/*     */ 
/*     */     
/* 253 */     StscState state = StscState.start();
/* 254 */     boolean validate = (options == null || !options.hasOption("COMPILE_NO_VALIDATION"));
/*     */     
/*     */     try {
/* 257 */       state.setErrorListener((Collection)errorWatcher);
/* 258 */       state.setBindingConfig(config);
/* 259 */       state.setOptions(options);
/* 260 */       state.setGivenTypeSystemName(name);
/* 261 */       state.setSchemasDir(schemasDir);
/* 262 */       if (baseURI != null) {
/* 263 */         state.setBaseUri(baseURI);
/*     */       }
/*     */       
/* 266 */       linkTo = SchemaTypeLoaderImpl.build(new SchemaTypeLoader[] { (SchemaTypeLoader)BuiltinSchemaTypeSystem.get(), linkTo }, null, null);
/* 267 */       state.setImportingTypeLoader(linkTo);
/*     */       
/* 269 */       List validSchemas = new ArrayList(schemas.length);
/*     */ 
/*     */       
/* 272 */       if (validate) {
/*     */         
/* 274 */         XmlOptions validateOptions = (new XmlOptions()).setErrorListener((Collection)errorWatcher);
/* 275 */         if (options.hasOption("VALIDATE_TREAT_LAX_AS_SKIP"))
/* 276 */           validateOptions.setValidateTreatLaxAsSkip(); 
/* 277 */         for (int i = 0; i < schemas.length; i++) {
/*     */           
/* 279 */           if (schemas[i].validate(validateOptions)) {
/* 280 */             validSchemas.add(schemas[i]);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 285 */         validSchemas.addAll(Arrays.asList(schemas));
/*     */       } 
/*     */       
/* 288 */       SchemaDocument.Schema[] startWith = validSchemas.<SchemaDocument.Schema>toArray(new SchemaDocument.Schema[validSchemas.size()]);
/*     */       
/* 290 */       if (incremental) {
/*     */         
/* 292 */         Set namespaces = new HashSet();
/* 293 */         startWith = getSchemasToRecompile((SchemaTypeSystemImpl)system, startWith, namespaces);
/* 294 */         state.initFromTypeSystem((SchemaTypeSystemImpl)system, namespaces);
/*     */       }
/*     */       else {
/*     */         
/* 298 */         state.setDependencies(new SchemaDependencies());
/*     */       } 
/*     */ 
/*     */       
/* 302 */       StscImporter.SchemaToProcess[] schemasAndChameleons = StscImporter.resolveImportsAndIncludes(startWith, incremental);
/*     */ 
/*     */       
/* 305 */       StscTranslator.addAllDefinitions(schemasAndChameleons);
/*     */ 
/*     */       
/* 308 */       StscResolver.resolveAll();
/*     */ 
/*     */       
/* 311 */       StscChecker.checkAll();
/*     */ 
/*     */       
/* 314 */       StscJavaizer.javaizeAllTypes(javaize);
/*     */ 
/*     */       
/* 317 */       StscState.get().sts().loadFromStscState(state);
/*     */ 
/*     */       
/* 320 */       if (sourcesToCopyMap != null) {
/* 321 */         sourcesToCopyMap.putAll(state.sourceCopyMap());
/*     */       }
/* 323 */       if (errorWatcher.hasError())
/*     */       {
/*     */         
/* 326 */         if (state.allowPartial() && state.getRecovered() == errorWatcher.size()) {
/*     */ 
/*     */           
/* 329 */           StscState.get().sts().setIncomplete(true);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 334 */           return null;
/*     */         } 
/*     */       }
/*     */       
/* 338 */       if (system != null) {
/* 339 */         ((SchemaTypeSystemImpl)system).setIncomplete(true);
/*     */       }
/* 341 */       return StscState.get().sts();
/*     */     }
/*     */     finally {
/*     */       
/* 345 */       StscState.end();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SchemaDocument.Schema[] getSchemasToRecompile(SchemaTypeSystemImpl system, SchemaDocument.Schema[] modified, Set namespaces) {
/* 358 */     Set modifiedFiles = new HashSet();
/* 359 */     Map haveFile = new HashMap();
/* 360 */     List result = new ArrayList();
/* 361 */     for (int i = 0; i < modified.length; i++) {
/*     */       
/* 363 */       String fileURL = modified[i].documentProperties().getSourceName();
/* 364 */       if (fileURL == null) {
/* 365 */         throw new IllegalArgumentException("One of the Schema files passed in doesn't have the source set, which prevents it to be incrementally compiled");
/*     */       }
/*     */       
/* 368 */       modifiedFiles.add(fileURL);
/* 369 */       haveFile.put(fileURL, modified[i]);
/* 370 */       result.add(modified[i]);
/*     */     } 
/* 372 */     SchemaDependencies dep = system.getDependencies();
/* 373 */     List nss = dep.getNamespacesTouched(modifiedFiles);
/* 374 */     namespaces.addAll(dep.computeTransitiveClosure(nss));
/* 375 */     List needRecompilation = dep.getFilesTouched(namespaces);
/* 376 */     StscState.get().setDependencies(new SchemaDependencies(dep, namespaces));
/* 377 */     for (int j = 0; j < needRecompilation.size(); j++) {
/*     */       
/* 379 */       String url = needRecompilation.get(j);
/* 380 */       SchemaDocument.Schema have = (SchemaDocument.Schema)haveFile.get(url);
/* 381 */       if (have == null) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 386 */           XmlObject xdoc = StscImporter.DownloadTable.downloadDocument(StscState.get().getS4SLoader(), null, url);
/*     */           
/* 388 */           XmlOptions voptions = new XmlOptions();
/* 389 */           voptions.setErrorListener(StscState.get().getErrorListener());
/* 390 */           if (!(xdoc instanceof SchemaDocument) || !xdoc.validate(voptions)) {
/*     */             
/* 392 */             StscState.get().error("Referenced document is not a valid schema, URL = " + url, 56, (XmlObject)null);
/*     */           }
/*     */           else {
/*     */             
/* 396 */             SchemaDocument sDoc = (SchemaDocument)xdoc;
/*     */             
/* 398 */             result.add(sDoc.getSchema());
/*     */           } 
/* 400 */         } catch (MalformedURLException mfe) {
/*     */           
/* 402 */           StscState.get().error("exception.loading.url", new Object[] { "MalformedURLException", url, mfe.getMessage() }, (XmlObject)null);
/*     */         
/*     */         }
/* 405 */         catch (IOException ioe) {
/*     */           
/* 407 */           StscState.get().error("exception.loading.url", new Object[] { "IOException", url, ioe.getMessage() }, (XmlObject)null);
/*     */         
/*     */         }
/* 410 */         catch (XmlException xmle) {
/*     */           
/* 412 */           StscState.get().error("exception.loading.url", new Object[] { "XmlException", url, xmle.getMessage() }, (XmlObject)null);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 417 */     return result.<SchemaDocument.Schema>toArray(new SchemaDocument.Schema[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean generateTypes(SchemaTypeSystem system, Filer filer, XmlOptions options) {
/* 434 */     if (system instanceof SchemaTypeSystemImpl && ((SchemaTypeSystemImpl)system).isIncomplete()) {
/* 435 */       return false;
/*     */     }
/* 437 */     boolean success = true;
/*     */     
/* 439 */     List types = new ArrayList();
/* 440 */     types.addAll(Arrays.asList(system.globalTypes()));
/* 441 */     types.addAll(Arrays.asList(system.documentTypes()));
/* 442 */     types.addAll(Arrays.asList(system.attributeTypes()));
/*     */     
/* 444 */     for (Iterator i = types.iterator(); i.hasNext(); ) {
/*     */       
/* 446 */       SchemaType type = i.next();
/* 447 */       if (type.isBuiltinType())
/*     */         continue; 
/* 449 */       if (type.getFullJavaName() == null) {
/*     */         continue;
/*     */       }
/* 452 */       String fjn = type.getFullJavaName();
/*     */       
/* 454 */       Writer writer = null;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 459 */         writer = filer.createSourceFile(fjn);
/* 460 */         SchemaTypeCodePrinter.printType(writer, type, options);
/*     */       }
/* 462 */       catch (IOException e) {
/*     */         
/* 464 */         System.err.println("IO Error " + e);
/* 465 */         success = false;
/*     */       } finally {
/*     */         
/* 468 */         try { if (writer != null) writer.close();  } catch (IOException e) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 474 */         fjn = type.getFullJavaImplName();
/* 475 */         writer = filer.createSourceFile(fjn);
/*     */         
/* 477 */         SchemaTypeCodePrinter.printTypeImpl(writer, type, options);
/*     */       }
/* 479 */       catch (IOException e) {
/*     */         
/* 481 */         System.err.println("IO Error " + e);
/* 482 */         success = false;
/*     */       } finally {
/*     */         
/* 485 */         try { if (writer != null) writer.close();  } catch (IOException e) {}
/*     */       } 
/*     */     } 
/*     */     
/* 489 */     return success;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaTypeSystemCompiler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */