/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.BindingConfig;
/*      */ import org.apache.xmlbeans.SchemaAttributeGroup;
/*      */ import org.apache.xmlbeans.SchemaComponent;
/*      */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*      */ import org.apache.xmlbeans.SchemaModelGroup;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeLoader;
/*      */ import org.apache.xmlbeans.SystemProperties;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.XmlBeans;
/*      */ import org.apache.xmlbeans.XmlError;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.common.ResolverUtil;
/*      */ import org.apache.xmlbeans.impl.util.HexBin;
/*      */ import org.apache.xmlbeans.impl.values.XmlStringImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlValueOutOfRangeException;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*      */ import org.xml.sax.EntityResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StscState
/*      */ {
/*      */   private String _givenStsName;
/*      */   private Collection _errorListener;
/*      */   private SchemaTypeSystemImpl _target;
/*      */   private BindingConfig _config;
/*      */   private Map _compatMap;
/*      */   private boolean _doingDownloads;
/*   63 */   private byte[] _digest = null;
/*      */   
/*      */   private boolean _noDigest = false;
/*      */   
/*      */   private boolean _allowPartial = false;
/*   68 */   private int _recoveredErrors = 0;
/*      */   
/*      */   private SchemaTypeLoader _importingLoader;
/*      */   
/*   72 */   private Map _containers = new LinkedHashMap();
/*      */   
/*      */   private SchemaDependencies _dependencies;
/*   75 */   private Map _redefinedGlobalTypes = new LinkedHashMap();
/*   76 */   private Map _redefinedModelGroups = new LinkedHashMap();
/*   77 */   private Map _redefinedAttributeGroups = new LinkedHashMap();
/*      */   
/*   79 */   private Map _globalTypes = new LinkedHashMap();
/*   80 */   private Map _globalElements = new LinkedHashMap();
/*   81 */   private Map _globalAttributes = new LinkedHashMap();
/*   82 */   private Map _modelGroups = new LinkedHashMap();
/*   83 */   private Map _attributeGroups = new LinkedHashMap();
/*   84 */   private Map _documentTypes = new LinkedHashMap();
/*   85 */   private Map _attributeTypes = new LinkedHashMap();
/*   86 */   private Map _typesByClassname = new LinkedHashMap();
/*   87 */   private Map _misspelledNames = new HashMap();
/*   88 */   private Set _processingGroups = new LinkedHashSet();
/*   89 */   private Map _idConstraints = new LinkedHashMap();
/*   90 */   private Set _namespaces = new HashSet();
/*   91 */   private List _annotations = new ArrayList();
/*      */   private boolean _noUpa;
/*      */   private boolean _noPvr;
/*      */   private boolean _noAnn;
/*      */   private boolean _mdefAll;
/*   96 */   private Set _mdefNamespaces = buildDefaultMdefNamespaces();
/*      */   
/*      */   private EntityResolver _entityResolver;
/*      */   
/*      */   private File _schemasDir;
/*      */   
/*      */   private static Set buildDefaultMdefNamespaces() {
/*  103 */     return new HashSet(Arrays.asList((Object[])new String[] { "http://www.openuri.org/2002/04/soap/conversation/" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   public static final Object CHAMELEON_INCLUDE_URI = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initFromTypeSystem(SchemaTypeSystemImpl system, Set newNamespaces) {
/*  129 */     SchemaContainer[] containers = system.containers();
/*  130 */     for (int i = 0; i < containers.length; i++) {
/*      */       
/*  132 */       if (!newNamespaces.contains(containers[i].getNamespace()))
/*      */       {
/*      */         
/*  135 */         addContainer(containers[i]);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addNewContainer(String namespace) {
/*  145 */     if (this._containers.containsKey(namespace)) {
/*      */       return;
/*      */     }
/*  148 */     SchemaContainer container = new SchemaContainer(namespace);
/*  149 */     container.setTypeSystem(sts());
/*  150 */     addNamespace(namespace);
/*  151 */     this._containers.put(namespace, container);
/*      */   }
/*      */ 
/*      */   
/*      */   private void addContainer(SchemaContainer container) {
/*  156 */     this._containers.put(container.getNamespace(), container);
/*  157 */     List redefModelGroups = container.redefinedModelGroups();
/*  158 */     for (int i = 0; i < redefModelGroups.size(); i++) {
/*      */       
/*  160 */       QName name = ((SchemaModelGroup)redefModelGroups.get(i)).getName();
/*  161 */       this._redefinedModelGroups.put(name, redefModelGroups.get(i));
/*      */     } 
/*      */     
/*  164 */     List redefAttrGroups = container.redefinedAttributeGroups();
/*  165 */     for (int j = 0; j < redefAttrGroups.size(); j++) {
/*      */       
/*  167 */       QName name = ((SchemaAttributeGroup)redefAttrGroups.get(j)).getName();
/*  168 */       this._redefinedAttributeGroups.put(name, redefAttrGroups.get(j));
/*      */     } 
/*      */     
/*  171 */     List redefTypes = container.redefinedGlobalTypes();
/*  172 */     for (int k = 0; k < redefTypes.size(); k++) {
/*      */       
/*  174 */       QName name = ((SchemaType)redefTypes.get(k)).getName();
/*  175 */       this._redefinedGlobalTypes.put(name, redefTypes.get(k));
/*      */     } 
/*      */     
/*  178 */     List globalElems = container.globalElements();
/*  179 */     for (int m = 0; m < globalElems.size(); m++) {
/*      */       
/*  181 */       QName name = ((SchemaGlobalElement)globalElems.get(m)).getName();
/*  182 */       this._globalElements.put(name, globalElems.get(m));
/*      */     } 
/*      */     
/*  185 */     List globalAtts = container.globalAttributes();
/*  186 */     for (int n = 0; n < globalAtts.size(); n++) {
/*      */       
/*  188 */       QName name = ((SchemaGlobalAttribute)globalAtts.get(n)).getName();
/*  189 */       this._globalAttributes.put(name, globalAtts.get(n));
/*      */     } 
/*      */     
/*  192 */     List modelGroups = container.modelGroups();
/*  193 */     for (int i1 = 0; i1 < modelGroups.size(); i1++) {
/*      */       
/*  195 */       QName name = ((SchemaModelGroup)modelGroups.get(i1)).getName();
/*  196 */       this._modelGroups.put(name, modelGroups.get(i1));
/*      */     } 
/*      */     
/*  199 */     List attrGroups = container.attributeGroups();
/*  200 */     for (int i2 = 0; i2 < attrGroups.size(); i2++) {
/*      */       
/*  202 */       QName name = ((SchemaAttributeGroup)attrGroups.get(i2)).getName();
/*  203 */       this._attributeGroups.put(name, attrGroups.get(i2));
/*      */     } 
/*      */     
/*  206 */     List globalTypes = container.globalTypes();
/*  207 */     for (int i3 = 0; i3 < globalTypes.size(); i3++) {
/*      */       
/*  209 */       SchemaType t = globalTypes.get(i3);
/*  210 */       QName name = t.getName();
/*  211 */       this._globalTypes.put(name, t);
/*  212 */       if (t.getFullJavaName() != null) {
/*  213 */         addClassname(t.getFullJavaName(), t);
/*      */       }
/*      */     } 
/*  216 */     List documentTypes = container.documentTypes();
/*  217 */     for (int i4 = 0; i4 < documentTypes.size(); i4++) {
/*      */       
/*  219 */       SchemaType t = documentTypes.get(i4);
/*  220 */       QName name = t.getProperties()[0].getName();
/*  221 */       this._documentTypes.put(name, t);
/*  222 */       if (t.getFullJavaName() != null) {
/*  223 */         addClassname(t.getFullJavaName(), t);
/*      */       }
/*      */     } 
/*  226 */     List attributeTypes = container.attributeTypes();
/*  227 */     for (int i5 = 0; i5 < attributeTypes.size(); i5++) {
/*      */       
/*  229 */       SchemaType t = attributeTypes.get(i5);
/*  230 */       QName name = t.getProperties()[0].getName();
/*  231 */       this._attributeTypes.put(name, t);
/*  232 */       if (t.getFullJavaName() != null) {
/*  233 */         addClassname(t.getFullJavaName(), t);
/*      */       }
/*      */     } 
/*  236 */     List identityConstraints = container.identityConstraints();
/*  237 */     for (int i6 = 0; i6 < identityConstraints.size(); i6++) {
/*      */       
/*  239 */       QName name = ((SchemaIdentityConstraint)identityConstraints.get(i6)).getName();
/*  240 */       this._idConstraints.put(name, identityConstraints.get(i6));
/*      */     } 
/*      */     
/*  243 */     this._annotations.addAll(container.annotations());
/*  244 */     this._namespaces.add(container.getNamespace());
/*  245 */     container.unsetImmutable();
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaContainer getContainer(String namespace) {
/*  250 */     return (SchemaContainer)this._containers.get(namespace);
/*      */   }
/*      */ 
/*      */   
/*      */   Map getContainerMap() {
/*  255 */     return Collections.unmodifiableMap(this._containers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerDependency(String sourceNs, String targetNs) {
/*  262 */     this._dependencies.registerDependency(sourceNs, targetNs);
/*      */   }
/*      */ 
/*      */   
/*      */   void registerContribution(String ns, String fileUrl) {
/*  267 */     this._dependencies.registerContribution(ns, fileUrl);
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaDependencies getDependencies() {
/*  272 */     return this._dependencies;
/*      */   }
/*      */ 
/*      */   
/*      */   void setDependencies(SchemaDependencies deps) {
/*  277 */     this._dependencies = deps;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isFileProcessed(String url) {
/*  282 */     return this._dependencies.isFileRepresented(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImportingTypeLoader(SchemaTypeLoader loader) {
/*  291 */     this._importingLoader = loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setErrorListener(Collection errorListener) {
/*  298 */     this._errorListener = errorListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, int code, XmlObject loc) {
/*  305 */     addError(this._errorListener, message, code, loc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String code, Object[] args, XmlObject loc) {
/*  311 */     addError(this._errorListener, code, args, loc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void recover(String code, Object[] args, XmlObject loc) {
/*  317 */     addError(this._errorListener, code, args, loc); this._recoveredErrors++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warning(String message, int code, XmlObject loc) {
/*  324 */     addWarning(this._errorListener, message, code, loc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warning(String code, Object[] args, XmlObject loc) {
/*  333 */     if (code == "reserved-type-name" && loc.documentProperties().getSourceName() != null && loc.documentProperties().getSourceName().indexOf("XMLSchema.xsd") > 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  338 */     addWarning(this._errorListener, code, args, loc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message) {
/*  345 */     addInfo(this._errorListener, message);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String code, Object[] args) {
/*  351 */     addInfo(this._errorListener, code, args);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addError(Collection errorListener, String message, int code, XmlObject location) {
/*  356 */     XmlError err = XmlError.forObject(message, 0, location);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  361 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addError(Collection errorListener, String code, Object[] args, XmlObject location) {
/*  366 */     XmlError err = XmlError.forObject(code, args, 0, location);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  372 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addError(Collection errorListener, String code, Object[] args, File location) {
/*  377 */     XmlError err = XmlError.forLocation(code, args, 0, location.toURI().toString(), 0, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  383 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addError(Collection errorListener, String code, Object[] args, URL location) {
/*  388 */     XmlError err = XmlError.forLocation(code, args, 0, location.toString(), 0, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  394 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addWarning(Collection errorListener, String message, int code, XmlObject location) {
/*  400 */     XmlError err = XmlError.forObject(message, 1, location);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  405 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addWarning(Collection errorListener, String code, Object[] args, XmlObject location) {
/*  410 */     XmlError err = XmlError.forObject(code, args, 1, location);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  416 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addInfo(Collection errorListener, String message) {
/*  421 */     XmlError err = XmlError.forMessage(message, 2);
/*  422 */     errorListener.add(err);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void addInfo(Collection errorListener, String code, Object[] args) {
/*  427 */     XmlError err = XmlError.forMessage(code, args, 2);
/*  428 */     errorListener.add(err);
/*      */   }
/*      */   
/*      */   public void setGivenTypeSystemName(String name) {
/*  432 */     this._givenStsName = name;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTargetSchemaTypeSystem(SchemaTypeSystemImpl target) {
/*  438 */     this._target = target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSchemaDigest(byte[] digest) {
/*  445 */     if (this._noDigest) {
/*      */       return;
/*      */     }
/*  448 */     if (digest == null) {
/*      */       
/*  450 */       this._noDigest = true;
/*  451 */       this._digest = null;
/*      */       
/*      */       return;
/*      */     } 
/*  455 */     if (this._digest == null)
/*  456 */       this._digest = new byte[16]; 
/*  457 */     int len = this._digest.length;
/*  458 */     if (digest.length < len)
/*  459 */       len = digest.length; 
/*  460 */     for (int i = 0; i < len; i++) {
/*  461 */       this._digest[i] = (byte)(this._digest[i] ^ digest[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaTypeSystemImpl sts() {
/*  469 */     if (this._target != null) {
/*  470 */       return this._target;
/*      */     }
/*  472 */     String name = this._givenStsName;
/*  473 */     if (name == null && this._digest != null) {
/*  474 */       name = "s" + new String(HexBin.encode(this._digest));
/*      */     }
/*  476 */     this._target = new SchemaTypeSystemImpl(name);
/*  477 */     return this._target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldDownloadURI(String uriString) {
/*  485 */     if (this._doingDownloads) {
/*  486 */       return true;
/*      */     }
/*  488 */     if (uriString == null) {
/*  489 */       return false;
/*      */     }
/*      */     
/*      */     try {
/*  493 */       URI uri = new URI(uriString);
/*  494 */       if (uri.getScheme().equalsIgnoreCase("jar") || uri.getScheme().equalsIgnoreCase("zip")) {
/*      */ 
/*      */ 
/*      */         
/*  498 */         String s = uri.getSchemeSpecificPart();
/*  499 */         int i = s.lastIndexOf('!');
/*  500 */         return shouldDownloadURI((i > 0) ? s.substring(0, i) : s);
/*      */       } 
/*  502 */       return uri.getScheme().equalsIgnoreCase("file");
/*      */     }
/*  504 */     catch (Exception e) {
/*      */       
/*  506 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptions(XmlOptions options) {
/*  515 */     if (options == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  520 */     this._allowPartial = options.hasOption("COMPILE_PARTIAL_TYPESYSTEM");
/*      */     
/*  522 */     this._compatMap = (Map)options.get("COMPILE_SUBSTITUTE_NAMES");
/*  523 */     this._noUpa = options.hasOption("COMPILE_NO_UPA_RULE") ? true : (!"true".equals(SystemProperties.getProperty("xmlbean.uniqueparticleattribution", "true")));
/*      */     
/*  525 */     this._noPvr = options.hasOption("COMPILE_NO_PVR_RULE") ? true : (!"true".equals(SystemProperties.getProperty("xmlbean.particlerestriction", "true")));
/*      */     
/*  527 */     this._noAnn = options.hasOption("COMPILE_NO_ANNOTATIONS") ? true : (!"true".equals(SystemProperties.getProperty("xmlbean.schemaannotations", "true")));
/*      */     
/*  529 */     this._doingDownloads = options.hasOption("COMPILE_DOWNLOAD_URLS") ? true : "true".equals(SystemProperties.getProperty("xmlbean.downloadurls", "false"));
/*      */     
/*  531 */     this._entityResolver = (EntityResolver)options.get("ENTITY_RESOLVER");
/*      */     
/*  533 */     if (this._entityResolver == null) {
/*  534 */       this._entityResolver = ResolverUtil.getGlobalEntityResolver();
/*      */     }
/*  536 */     if (this._entityResolver != null) {
/*  537 */       this._doingDownloads = true;
/*      */     }
/*  539 */     if (options.hasOption("COMPILE_MDEF_NAMESPACES")) {
/*      */       
/*  541 */       this._mdefNamespaces.addAll((Collection)options.get("COMPILE_MDEF_NAMESPACES"));
/*      */       
/*  543 */       String local = "##local";
/*  544 */       String any = "##any";
/*      */       
/*  546 */       if (this._mdefNamespaces.contains(local)) {
/*      */         
/*  548 */         this._mdefNamespaces.remove(local);
/*  549 */         this._mdefNamespaces.add("");
/*      */       } 
/*  551 */       if (this._mdefNamespaces.contains(any)) {
/*      */         
/*  553 */         this._mdefNamespaces.remove(any);
/*  554 */         this._mdefAll = true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EntityResolver getEntityResolver() {
/*  564 */     return this._entityResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean noUpa() {
/*  572 */     return this._noUpa;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean noPvr() {
/*  580 */     return this._noPvr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean noAnn() {
/*  588 */     return this._noAnn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean allowPartial() {
/*  597 */     return this._allowPartial;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRecovered() {
/*  606 */     return this._recoveredErrors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private QName compatName(QName name, String chameleonNamespace) {
/*  618 */     if (name.getNamespaceURI().length() == 0 && chameleonNamespace != null && chameleonNamespace.length() > 0) {
/*  619 */       name = new QName(chameleonNamespace, name.getLocalPart());
/*      */     }
/*  621 */     if (this._compatMap == null) {
/*  622 */       return name;
/*      */     }
/*  624 */     QName subst = (QName)this._compatMap.get(name);
/*  625 */     if (subst == null)
/*  626 */       return name; 
/*  627 */     return subst;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBindingConfig(BindingConfig config) throws IllegalArgumentException {
/*  636 */     this._config = config;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BindingConfig getBindingConfig() throws IllegalArgumentException {
/*  642 */     return this._config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPackageOverride(String namespace) {
/*  650 */     if (this._config == null)
/*  651 */       return null; 
/*  652 */     return this._config.lookupPackageForNamespace(namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJavaPrefix(String namespace) {
/*  660 */     if (this._config == null)
/*  661 */       return null; 
/*  662 */     return this._config.lookupPrefixForNamespace(namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJavaSuffix(String namespace) {
/*  670 */     if (this._config == null)
/*  671 */       return null; 
/*  672 */     return this._config.lookupSuffixForNamespace(namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJavaname(QName qname, int kind) {
/*  680 */     if (this._config == null)
/*  681 */       return null; 
/*  682 */     return this._config.lookupJavanameForQName(qname, kind);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String crunchName(QName name) {
/*  690 */     return name.getLocalPart().toLowerCase();
/*      */   }
/*      */ 
/*      */   
/*      */   void addSpelling(QName name, SchemaComponent comp) {
/*  695 */     this._misspelledNames.put(crunchName(name), comp);
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaComponent findSpelling(QName name) {
/*  700 */     return (SchemaComponent)this._misspelledNames.get(crunchName(name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addNamespace(String targetNamespace) {
/*  707 */     this._namespaces.add(targetNamespace);
/*      */   }
/*      */ 
/*      */   
/*      */   String[] getNamespaces() {
/*  712 */     return (String[])this._namespaces.toArray((Object[])new String[this._namespaces.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean linkerDefinesNamespace(String namespace) {
/*  717 */     return this._importingLoader.isNamespaceDefined(namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaTypeImpl findGlobalType(QName name, String chameleonNamespace, String sourceNamespace) {
/*  724 */     name = compatName(name, chameleonNamespace);
/*  725 */     SchemaTypeImpl result = (SchemaTypeImpl)this._globalTypes.get(name);
/*  726 */     boolean foundOnLoader = false;
/*  727 */     if (result == null) {
/*      */       
/*  729 */       result = (SchemaTypeImpl)this._importingLoader.findType(name);
/*  730 */       foundOnLoader = (result != null);
/*      */     } 
/*  732 */     if (!foundOnLoader && sourceNamespace != null)
/*  733 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/*  734 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaTypeImpl findRedefinedGlobalType(QName name, String chameleonNamespace, SchemaTypeImpl redefinedBy) {
/*  739 */     QName redefinedName = redefinedBy.getName();
/*  740 */     name = compatName(name, chameleonNamespace);
/*  741 */     if (name.equals(redefinedName))
/*      */     {
/*  743 */       return (SchemaTypeImpl)this._redefinedGlobalTypes.get(redefinedBy);
/*      */     }
/*      */     
/*  746 */     SchemaTypeImpl result = (SchemaTypeImpl)this._globalTypes.get(name);
/*  747 */     if (result == null) {
/*  748 */       result = (SchemaTypeImpl)this._importingLoader.findType(name);
/*      */     }
/*  750 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addGlobalType(SchemaTypeImpl type, SchemaTypeImpl redefined) {
/*  755 */     if (type != null) {
/*      */       
/*  757 */       QName name = type.getName();
/*  758 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/*  759 */       assert container != null && container == type.getContainer();
/*      */       
/*  761 */       if (redefined != null) {
/*      */         
/*  763 */         if (this._redefinedGlobalTypes.containsKey(redefined))
/*      */         {
/*  765 */           if (!ignoreMdef(name)) {
/*  766 */             if (this._mdefAll) {
/*  767 */               warning("sch-props-correct.2", new Object[] { "global type", QNameHelper.pretty(name), ((SchemaType)this._redefinedGlobalTypes.get(redefined)).getSourceName() }, type.getParseObject());
/*      */             }
/*      */             else {
/*      */               
/*  771 */               error("sch-props-correct.2", new Object[] { "global type", QNameHelper.pretty(name), ((SchemaType)this._redefinedGlobalTypes.get(redefined)).getSourceName() }, type.getParseObject());
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  779 */           this._redefinedGlobalTypes.put(redefined, type);
/*  780 */           container.addRedefinedType(type.getRef());
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  785 */       else if (this._globalTypes.containsKey(name)) {
/*      */         
/*  787 */         if (!ignoreMdef(name)) {
/*  788 */           if (this._mdefAll) {
/*  789 */             warning("sch-props-correct.2", new Object[] { "global type", QNameHelper.pretty(name), ((SchemaType)this._globalTypes.get(name)).getSourceName() }, type.getParseObject());
/*      */           }
/*      */           else {
/*      */             
/*  793 */             error("sch-props-correct.2", new Object[] { "global type", QNameHelper.pretty(name), ((SchemaType)this._globalTypes.get(name)).getSourceName() }, type.getParseObject());
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  801 */         this._globalTypes.put(name, type);
/*  802 */         container.addGlobalType(type.getRef());
/*  803 */         addSpelling(name, (SchemaComponent)type);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ignoreMdef(QName name) {
/*  811 */     return this._mdefNamespaces.contains(name.getNamespaceURI());
/*      */   }
/*      */   
/*      */   SchemaType[] globalTypes() {
/*  815 */     return (SchemaType[])this._globalTypes.values().toArray((Object[])new SchemaType[this._globalTypes.size()]);
/*      */   }
/*      */   SchemaType[] redefinedGlobalTypes() {
/*  818 */     return (SchemaType[])this._redefinedGlobalTypes.values().toArray((Object[])new SchemaType[this._redefinedGlobalTypes.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaTypeImpl findDocumentType(QName name, String chameleonNamespace, String sourceNamespace) {
/*  824 */     name = compatName(name, chameleonNamespace);
/*  825 */     SchemaTypeImpl result = (SchemaTypeImpl)this._documentTypes.get(name);
/*  826 */     boolean foundOnLoader = false;
/*  827 */     if (result == null) {
/*      */       
/*  829 */       result = (SchemaTypeImpl)this._importingLoader.findDocumentType(name);
/*  830 */       foundOnLoader = (result != null);
/*      */     } 
/*  832 */     if (!foundOnLoader && sourceNamespace != null)
/*  833 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/*  834 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addDocumentType(SchemaTypeImpl type, QName name) {
/*  839 */     if (this._documentTypes.containsKey(name)) {
/*      */       
/*  841 */       if (!ignoreMdef(name)) {
/*  842 */         if (this._mdefAll) {
/*  843 */           warning("sch-props-correct.2", new Object[] { "global element", QNameHelper.pretty(name), ((SchemaComponent)this._documentTypes.get(name)).getSourceName() }, type.getParseObject());
/*      */         }
/*      */         else {
/*      */           
/*  847 */           error("sch-props-correct.2", new Object[] { "global element", QNameHelper.pretty(name), ((SchemaComponent)this._documentTypes.get(name)).getSourceName() }, type.getParseObject());
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  855 */       this._documentTypes.put(name, type);
/*  856 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/*  857 */       assert container != null && container == type.getContainer();
/*  858 */       container.addDocumentType(type.getRef());
/*      */     } 
/*      */   }
/*      */   
/*      */   SchemaType[] documentTypes() {
/*  863 */     return (SchemaType[])this._documentTypes.values().toArray((Object[])new SchemaType[this._documentTypes.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaTypeImpl findAttributeType(QName name, String chameleonNamespace, String sourceNamespace) {
/*  869 */     name = compatName(name, chameleonNamespace);
/*  870 */     SchemaTypeImpl result = (SchemaTypeImpl)this._attributeTypes.get(name);
/*  871 */     boolean foundOnLoader = false;
/*  872 */     if (result == null) {
/*      */       
/*  874 */       result = (SchemaTypeImpl)this._importingLoader.findAttributeType(name);
/*  875 */       foundOnLoader = (result != null);
/*      */     } 
/*  877 */     if (!foundOnLoader && sourceNamespace != null)
/*  878 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/*  879 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addAttributeType(SchemaTypeImpl type, QName name) {
/*  884 */     if (this._attributeTypes.containsKey(name)) {
/*      */       
/*  886 */       if (!ignoreMdef(name)) {
/*  887 */         if (this._mdefAll) {
/*  888 */           warning("sch-props-correct.2", new Object[] { "global attribute", QNameHelper.pretty(name), ((SchemaComponent)this._attributeTypes.get(name)).getSourceName() }, type.getParseObject());
/*      */         }
/*      */         else {
/*      */           
/*  892 */           error("sch-props-correct.2", new Object[] { "global attribute", QNameHelper.pretty(name), ((SchemaComponent)this._attributeTypes.get(name)).getSourceName() }, type.getParseObject());
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  900 */       this._attributeTypes.put(name, type);
/*  901 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/*  902 */       assert container != null && container == type.getContainer();
/*  903 */       container.addAttributeType(type.getRef());
/*      */     } 
/*      */   }
/*      */   
/*      */   SchemaType[] attributeTypes() {
/*  908 */     return (SchemaType[])this._attributeTypes.values().toArray((Object[])new SchemaType[this._attributeTypes.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaGlobalAttributeImpl findGlobalAttribute(QName name, String chameleonNamespace, String sourceNamespace) {
/*  914 */     name = compatName(name, chameleonNamespace);
/*  915 */     SchemaGlobalAttributeImpl result = (SchemaGlobalAttributeImpl)this._globalAttributes.get(name);
/*  916 */     boolean foundOnLoader = false;
/*  917 */     if (result == null) {
/*      */       
/*  919 */       result = (SchemaGlobalAttributeImpl)this._importingLoader.findAttribute(name);
/*  920 */       foundOnLoader = (result != null);
/*      */     } 
/*  922 */     if (!foundOnLoader && sourceNamespace != null)
/*  923 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/*  924 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addGlobalAttribute(SchemaGlobalAttributeImpl attribute) {
/*  929 */     if (attribute != null) {
/*      */       
/*  931 */       QName name = attribute.getName();
/*  932 */       this._globalAttributes.put(name, attribute);
/*  933 */       addSpelling(name, (SchemaComponent)attribute);
/*  934 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/*  935 */       assert container != null && container == attribute.getContainer();
/*  936 */       container.addGlobalAttribute(attribute.getRef());
/*      */     } 
/*      */   }
/*      */   
/*      */   SchemaGlobalAttribute[] globalAttributes() {
/*  941 */     return (SchemaGlobalAttribute[])this._globalAttributes.values().toArray((Object[])new SchemaGlobalAttribute[this._globalAttributes.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaGlobalElementImpl findGlobalElement(QName name, String chameleonNamespace, String sourceNamespace) {
/*  947 */     name = compatName(name, chameleonNamespace);
/*  948 */     SchemaGlobalElementImpl result = (SchemaGlobalElementImpl)this._globalElements.get(name);
/*  949 */     boolean foundOnLoader = false;
/*  950 */     if (result == null) {
/*      */       
/*  952 */       result = (SchemaGlobalElementImpl)this._importingLoader.findElement(name);
/*  953 */       foundOnLoader = (result != null);
/*      */     } 
/*  955 */     if (!foundOnLoader && sourceNamespace != null)
/*  956 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/*  957 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addGlobalElement(SchemaGlobalElementImpl element) {
/*  962 */     if (element != null) {
/*      */       
/*  964 */       QName name = element.getName();
/*  965 */       this._globalElements.put(name, element);
/*  966 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/*  967 */       assert container != null && container == element.getContainer();
/*  968 */       container.addGlobalElement(element.getRef());
/*  969 */       addSpelling(name, (SchemaComponent)element);
/*      */     } 
/*      */   }
/*      */   
/*      */   SchemaGlobalElement[] globalElements() {
/*  974 */     return (SchemaGlobalElement[])this._globalElements.values().toArray((Object[])new SchemaGlobalElement[this._globalElements.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaAttributeGroupImpl findAttributeGroup(QName name, String chameleonNamespace, String sourceNamespace) {
/*  980 */     name = compatName(name, chameleonNamespace);
/*  981 */     SchemaAttributeGroupImpl result = (SchemaAttributeGroupImpl)this._attributeGroups.get(name);
/*  982 */     boolean foundOnLoader = false;
/*  983 */     if (result == null) {
/*      */       
/*  985 */       result = (SchemaAttributeGroupImpl)this._importingLoader.findAttributeGroup(name);
/*  986 */       foundOnLoader = (result != null);
/*      */     } 
/*  988 */     if (!foundOnLoader && sourceNamespace != null)
/*  989 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/*  990 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaAttributeGroupImpl findRedefinedAttributeGroup(QName name, String chameleonNamespace, SchemaAttributeGroupImpl redefinedBy) {
/*  995 */     QName redefinitionFor = redefinedBy.getName();
/*  996 */     name = compatName(name, chameleonNamespace);
/*  997 */     if (name.equals(redefinitionFor))
/*      */     {
/*  999 */       return (SchemaAttributeGroupImpl)this._redefinedAttributeGroups.get(redefinedBy);
/*      */     }
/*      */     
/* 1002 */     SchemaAttributeGroupImpl result = (SchemaAttributeGroupImpl)this._attributeGroups.get(name);
/* 1003 */     if (result == null)
/* 1004 */       result = (SchemaAttributeGroupImpl)this._importingLoader.findAttributeGroup(name); 
/* 1005 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addAttributeGroup(SchemaAttributeGroupImpl attributeGroup, SchemaAttributeGroupImpl redefined) {
/* 1010 */     if (attributeGroup != null) {
/*      */       
/* 1012 */       QName name = attributeGroup.getName();
/* 1013 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/* 1014 */       assert container != null && container == attributeGroup.getContainer();
/* 1015 */       if (redefined != null) {
/*      */         
/* 1017 */         if (this._redefinedAttributeGroups.containsKey(redefined))
/*      */         {
/* 1019 */           if (!ignoreMdef(name)) {
/* 1020 */             if (this._mdefAll) {
/* 1021 */               warning("sch-props-correct.2", new Object[] { "attribute group", QNameHelper.pretty(name), ((SchemaComponent)this._redefinedAttributeGroups.get(redefined)).getSourceName() }, attributeGroup.getParseObject());
/*      */             }
/*      */             else {
/*      */               
/* 1025 */               error("sch-props-correct.2", new Object[] { "attribute group", QNameHelper.pretty(name), ((SchemaComponent)this._redefinedAttributeGroups.get(redefined)).getSourceName() }, attributeGroup.getParseObject());
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1033 */           this._redefinedAttributeGroups.put(redefined, attributeGroup);
/* 1034 */           container.addRedefinedAttributeGroup(attributeGroup.getRef());
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1039 */       else if (this._attributeGroups.containsKey(name)) {
/*      */         
/* 1041 */         if (!ignoreMdef(name)) {
/* 1042 */           if (this._mdefAll) {
/* 1043 */             warning("sch-props-correct.2", new Object[] { "attribute group", QNameHelper.pretty(name), ((SchemaComponent)this._attributeGroups.get(name)).getSourceName() }, attributeGroup.getParseObject());
/*      */           }
/*      */           else {
/*      */             
/* 1047 */             error("sch-props-correct.2", new Object[] { "attribute group", QNameHelper.pretty(name), ((SchemaComponent)this._attributeGroups.get(name)).getSourceName() }, attributeGroup.getParseObject());
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1055 */         this._attributeGroups.put(attributeGroup.getName(), attributeGroup);
/* 1056 */         addSpelling(attributeGroup.getName(), (SchemaComponent)attributeGroup);
/* 1057 */         container.addAttributeGroup(attributeGroup.getRef());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaAttributeGroup[] attributeGroups() {
/* 1064 */     return (SchemaAttributeGroup[])this._attributeGroups.values().toArray((Object[])new SchemaAttributeGroup[this._attributeGroups.size()]);
/*      */   }
/*      */   SchemaAttributeGroup[] redefinedAttributeGroups() {
/* 1067 */     return (SchemaAttributeGroup[])this._redefinedAttributeGroups.values().toArray((Object[])new SchemaAttributeGroup[this._redefinedAttributeGroups.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaModelGroupImpl findModelGroup(QName name, String chameleonNamespace, String sourceNamespace) {
/* 1073 */     name = compatName(name, chameleonNamespace);
/* 1074 */     SchemaModelGroupImpl result = (SchemaModelGroupImpl)this._modelGroups.get(name);
/* 1075 */     boolean foundOnLoader = false;
/* 1076 */     if (result == null) {
/*      */       
/* 1078 */       result = (SchemaModelGroupImpl)this._importingLoader.findModelGroup(name);
/* 1079 */       foundOnLoader = (result != null);
/*      */     } 
/* 1081 */     if (!foundOnLoader && sourceNamespace != null)
/* 1082 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/* 1083 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaModelGroupImpl findRedefinedModelGroup(QName name, String chameleonNamespace, SchemaModelGroupImpl redefinedBy) {
/* 1088 */     QName redefinitionFor = redefinedBy.getName();
/* 1089 */     name = compatName(name, chameleonNamespace);
/* 1090 */     if (name.equals(redefinitionFor))
/*      */     {
/* 1092 */       return (SchemaModelGroupImpl)this._redefinedModelGroups.get(redefinedBy);
/*      */     }
/*      */     
/* 1095 */     SchemaModelGroupImpl result = (SchemaModelGroupImpl)this._modelGroups.get(name);
/* 1096 */     if (result == null)
/* 1097 */       result = (SchemaModelGroupImpl)this._importingLoader.findModelGroup(name); 
/* 1098 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   void addModelGroup(SchemaModelGroupImpl modelGroup, SchemaModelGroupImpl redefined) {
/* 1103 */     if (modelGroup != null) {
/*      */       
/* 1105 */       QName name = modelGroup.getName();
/* 1106 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/* 1107 */       assert container != null && container == modelGroup.getContainer();
/* 1108 */       if (redefined != null) {
/*      */         
/* 1110 */         if (this._redefinedModelGroups.containsKey(redefined))
/*      */         {
/* 1112 */           if (!ignoreMdef(name)) {
/* 1113 */             if (this._mdefAll) {
/* 1114 */               warning("sch-props-correct.2", new Object[] { "model group", QNameHelper.pretty(name), ((SchemaComponent)this._redefinedModelGroups.get(redefined)).getSourceName() }, modelGroup.getParseObject());
/*      */             }
/*      */             else {
/*      */               
/* 1118 */               error("sch-props-correct.2", new Object[] { "model group", QNameHelper.pretty(name), ((SchemaComponent)this._redefinedModelGroups.get(redefined)).getSourceName() }, modelGroup.getParseObject());
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1126 */           this._redefinedModelGroups.put(redefined, modelGroup);
/* 1127 */           container.addRedefinedModelGroup(modelGroup.getRef());
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1132 */       else if (this._modelGroups.containsKey(name)) {
/*      */         
/* 1134 */         if (!ignoreMdef(name)) {
/* 1135 */           if (this._mdefAll) {
/* 1136 */             warning("sch-props-correct.2", new Object[] { "model group", QNameHelper.pretty(name), ((SchemaComponent)this._modelGroups.get(name)).getSourceName() }, modelGroup.getParseObject());
/*      */           }
/*      */           else {
/*      */             
/* 1140 */             error("sch-props-correct.2", new Object[] { "model group", QNameHelper.pretty(name), ((SchemaComponent)this._modelGroups.get(name)).getSourceName() }, modelGroup.getParseObject());
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1148 */         this._modelGroups.put(modelGroup.getName(), modelGroup);
/* 1149 */         addSpelling(modelGroup.getName(), (SchemaComponent)modelGroup);
/* 1150 */         container.addModelGroup(modelGroup.getRef());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   SchemaModelGroup[] modelGroups() {
/* 1157 */     return (SchemaModelGroup[])this._modelGroups.values().toArray((Object[])new SchemaModelGroup[this._modelGroups.size()]);
/*      */   }
/*      */   SchemaModelGroup[] redefinedModelGroups() {
/* 1160 */     return (SchemaModelGroup[])this._redefinedModelGroups.values().toArray((Object[])new SchemaModelGroup[this._redefinedModelGroups.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   SchemaIdentityConstraintImpl findIdConstraint(QName name, String chameleonNamespace, String sourceNamespace) {
/* 1166 */     name = compatName(name, chameleonNamespace);
/* 1167 */     if (sourceNamespace != null)
/* 1168 */       registerDependency(sourceNamespace, name.getNamespaceURI()); 
/* 1169 */     return (SchemaIdentityConstraintImpl)this._idConstraints.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   void addIdConstraint(SchemaIdentityConstraintImpl idc) {
/* 1174 */     if (idc != null) {
/*      */       
/* 1176 */       QName name = idc.getName();
/* 1177 */       SchemaContainer container = getContainer(name.getNamespaceURI());
/* 1178 */       assert container != null && container == idc.getContainer();
/* 1179 */       if (this._idConstraints.containsKey(name)) {
/*      */         
/* 1181 */         if (!ignoreMdef(name)) {
/* 1182 */           warning("sch-props-correct.2", new Object[] { "identity constraint", QNameHelper.pretty(name), ((SchemaComponent)this._idConstraints.get(name)).getSourceName() }, idc.getParseObject());
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1188 */         this._idConstraints.put(name, idc);
/* 1189 */         addSpelling(idc.getName(), (SchemaComponent)idc);
/* 1190 */         container.addIdentityConstraint(idc.getRef());
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   SchemaIdentityConstraintImpl[] idConstraints() {
/* 1196 */     return (SchemaIdentityConstraintImpl[])this._idConstraints.values().toArray((Object[])new SchemaIdentityConstraintImpl[this._idConstraints.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void addAnnotation(SchemaAnnotationImpl ann, String targetNamespace) {
/* 1202 */     if (ann != null) {
/*      */       
/* 1204 */       SchemaContainer container = getContainer(targetNamespace);
/* 1205 */       assert container != null && container == ann.getContainer();
/* 1206 */       this._annotations.add(ann);
/* 1207 */       container.addAnnotation(ann);
/*      */     } 
/*      */   }
/*      */   
/*      */   List annotations() {
/* 1212 */     return this._annotations;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isProcessing(Object obj) {
/* 1217 */     return this._processingGroups.contains(obj);
/*      */   }
/*      */ 
/*      */   
/*      */   void startProcessing(Object obj) {
/* 1222 */     assert !this._processingGroups.contains(obj);
/* 1223 */     this._processingGroups.add(obj);
/*      */   }
/*      */ 
/*      */   
/*      */   void finishProcessing(Object obj) {
/* 1228 */     assert this._processingGroups.contains(obj);
/* 1229 */     this._processingGroups.remove(obj);
/*      */   }
/*      */ 
/*      */   
/*      */   Object[] getCurrentProcessing() {
/* 1234 */     return this._processingGroups.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Map typesByClassname() {
/* 1240 */     return Collections.unmodifiableMap(this._typesByClassname);
/*      */   }
/*      */   void addClassname(String classname, SchemaType type) {
/* 1243 */     this._typesByClassname.put(classname, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class StscStack
/*      */   {
/*      */     StscState current;
/*      */ 
/*      */     
/* 1254 */     ArrayList stack = new ArrayList();
/*      */     
/*      */     final StscState push() {
/* 1257 */       this.stack.add(this.current);
/* 1258 */       this.current = new StscState();
/* 1259 */       return this.current;
/*      */     }
/*      */     
/*      */     final void pop() {
/* 1263 */       this.current = this.stack.get(this.stack.size() - 1);
/* 1264 */       this.stack.remove(this.stack.size() - 1);
/*      */     }
/*      */     
/*      */     private StscStack() {} }
/* 1268 */   private static ThreadLocal tl_stscStack = new ThreadLocal();
/*      */ 
/*      */   
/*      */   public static StscState start() {
/* 1272 */     StscStack stscStack = tl_stscStack.get();
/*      */     
/* 1274 */     if (stscStack == null) {
/*      */       
/* 1276 */       stscStack = new StscStack();
/* 1277 */       tl_stscStack.set(stscStack);
/*      */     } 
/* 1279 */     return stscStack.push();
/*      */   }
/*      */ 
/*      */   
/*      */   public static StscState get() {
/* 1284 */     return ((StscStack)tl_stscStack.get()).current;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void end() {
/* 1289 */     StscStack stscStack = tl_stscStack.get();
/* 1290 */     stscStack.pop();
/* 1291 */     if (stscStack.stack.size() == 0) {
/* 1292 */       tl_stscStack.set(null);
/*      */     }
/*      */   }
/*      */   
/* 1296 */   private static final XmlValueRef XMLSTR_PRESERVE = buildString("preserve");
/* 1297 */   private static final XmlValueRef XMLSTR_REPLACE = buildString("preserve");
/* 1298 */   private static final XmlValueRef XMLSTR_COLLAPSE = buildString("preserve");
/*      */   
/* 1300 */   static final SchemaType[] EMPTY_ST_ARRAY = new SchemaType[0];
/* 1301 */   static final SchemaType.Ref[] EMPTY_STREF_ARRAY = new SchemaType.Ref[0];
/*      */   
/* 1303 */   private static final XmlValueRef[] FACETS_NONE = new XmlValueRef[] { null, null, null, null, null, null, null, null, null, null, null, null };
/*      */ 
/*      */ 
/*      */   
/* 1307 */   private static final boolean[] FIXED_FACETS_NONE = new boolean[] { 
/*      */       false, false, false, false, false, false, false, false, false, false, 
/*      */       false, false };
/*      */   
/* 1311 */   private static final XmlValueRef[] FACETS_WS_COLLAPSE = new XmlValueRef[] { null, null, null, null, null, null, null, null, null, build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/* 1315 */   private static final boolean[] FIXED_FACETS_WS = new boolean[] { 
/*      */       false, false, false, false, false, false, false, false, false, true, 
/*      */       false, false };
/*      */   
/* 1319 */   static final XmlValueRef[] FACETS_UNION = FACETS_NONE;
/* 1320 */   static final boolean[] FIXED_FACETS_UNION = FIXED_FACETS_NONE;
/* 1321 */   static final XmlValueRef[] FACETS_LIST = FACETS_WS_COLLAPSE;
/* 1322 */   static final boolean[] FIXED_FACETS_LIST = FIXED_FACETS_WS; private static final String PROJECT_URL_PREFIX = "project://local";
/*      */   Map _sourceForUri;
/*      */   
/*      */   static XmlValueRef build_wsstring(int wsr) {
/* 1326 */     switch (wsr) {
/*      */       
/*      */       case 1:
/* 1329 */         return XMLSTR_PRESERVE;
/*      */       case 2:
/* 1331 */         return XMLSTR_REPLACE;
/*      */       case 3:
/* 1333 */         return XMLSTR_COLLAPSE;
/*      */     } 
/* 1335 */     return null;
/*      */   }
/*      */   URI _baseURI; SchemaTypeLoader _s4sloader; static final boolean $assertionsDisabled;
/*      */   
/*      */   static XmlValueRef buildString(String str) {
/* 1340 */     if (str == null) {
/* 1341 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 1345 */       XmlStringImpl i = new XmlStringImpl();
/* 1346 */       i.set(str);
/* 1347 */       i.setImmutable();
/* 1348 */       return new XmlValueRef((XmlAnySimpleType)i);
/*      */     }
/* 1350 */     catch (XmlValueOutOfRangeException e) {
/*      */       
/* 1352 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void notFoundError(QName itemName, int code, XmlObject loc, boolean recovered) {
/* 1359 */     String expected, expectedName = QNameHelper.pretty(itemName);
/* 1360 */     String found = null;
/* 1361 */     String foundName = null;
/* 1362 */     String sourceName = null;
/*      */     
/* 1364 */     if (recovered) {
/* 1365 */       this._recoveredErrors++;
/*      */     }
/* 1367 */     switch (code) {
/*      */       
/*      */       case 0:
/* 1370 */         expected = "type";
/*      */         break;
/*      */       case 1:
/* 1373 */         expected = "element";
/*      */         break;
/*      */       case 3:
/* 1376 */         expected = "attribute";
/*      */         break;
/*      */       case 6:
/* 1379 */         expected = "model group";
/*      */         break;
/*      */       case 4:
/* 1382 */         expected = "attribute group";
/*      */         break;
/*      */       case 5:
/* 1385 */         expected = "identity constraint";
/*      */         break;
/*      */       default:
/*      */         assert false;
/* 1389 */         expected = "definition";
/*      */         break;
/*      */     } 
/*      */     
/* 1393 */     SchemaComponent foundComponent = findSpelling(itemName);
/*      */     
/* 1395 */     if (foundComponent != null) {
/*      */       
/* 1397 */       QName name = foundComponent.getName();
/* 1398 */       if (name != null) {
/*      */         
/* 1400 */         switch (foundComponent.getComponentType()) {
/*      */           
/*      */           case 0:
/* 1403 */             found = "type";
/* 1404 */             sourceName = ((SchemaType)foundComponent).getSourceName();
/*      */             break;
/*      */           case 1:
/* 1407 */             found = "element";
/* 1408 */             sourceName = ((SchemaGlobalElement)foundComponent).getSourceName();
/*      */             break;
/*      */           case 3:
/* 1411 */             found = "attribute";
/* 1412 */             sourceName = ((SchemaGlobalAttribute)foundComponent).getSourceName();
/*      */             break;
/*      */           case 4:
/* 1415 */             found = "attribute group";
/*      */             break;
/*      */           case 6:
/* 1418 */             found = "model group";
/*      */             break;
/*      */         } 
/*      */         
/* 1422 */         if (sourceName != null)
/*      */         {
/* 1424 */           sourceName = sourceName.substring(sourceName.lastIndexOf('/') + 1);
/*      */         }
/*      */         
/* 1427 */         if (!name.equals(itemName))
/*      */         {
/* 1429 */           foundName = QNameHelper.pretty(name);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1434 */     if (found == null) {
/*      */ 
/*      */       
/* 1437 */       error("src-resolve", new Object[] { expected, expectedName }, loc);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1442 */       error("src-resolve.a", new Object[] { expected, expectedName, found, (foundName == null) ? new Integer(0) : new Integer(1), foundName, (sourceName == null) ? new Integer(0) : new Integer(1), sourceName }, loc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String sourceNameForUri(String uri) {
/* 1465 */     return (String)this._sourceForUri.get(uri);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map sourceCopyMap() {
/* 1475 */     return Collections.unmodifiableMap(this._sourceForUri);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBaseUri(URI uri) {
/* 1483 */     this._baseURI = uri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String relativize(String uri) {
/* 1490 */     return relativize(uri, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public String computeSavedFilename(String uri) {
/* 1495 */     return relativize(uri, true);
/*      */   }
/*      */ 
/*      */   
/*      */   private String relativize(String uri, boolean forSavedFilename) {
/* 1500 */     if (uri == null) {
/* 1501 */       return null;
/*      */     }
/*      */     
/* 1504 */     if (uri.startsWith("/")) {
/*      */       
/* 1506 */       uri = "project://local" + uri.replace('\\', '/');
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1511 */       int colon = uri.indexOf(':');
/* 1512 */       if (colon <= 1 || !uri.substring(0, colon).matches("^\\w+$")) {
/* 1513 */         uri = "project://local/" + uri.replace('\\', '/');
/*      */       }
/*      */     } 
/*      */     
/* 1517 */     if (this._baseURI != null) {
/*      */       
/*      */       try {
/*      */         
/* 1521 */         URI relative = this._baseURI.relativize(new URI(uri));
/* 1522 */         if (!relative.isAbsolute()) {
/* 1523 */           return relative.toString();
/*      */         }
/* 1525 */         uri = relative.toString();
/*      */       }
/* 1527 */       catch (URISyntaxException e) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1532 */     if (!forSavedFilename) {
/* 1533 */       return uri;
/*      */     }
/* 1535 */     int lastslash = uri.lastIndexOf('/');
/* 1536 */     String dir = QNameHelper.hexsafe((lastslash == -1) ? "" : uri.substring(0, lastslash));
/*      */     
/* 1538 */     int question = uri.indexOf('?', lastslash + 1);
/* 1539 */     if (question == -1) {
/* 1540 */       return dir + "/" + uri.substring(lastslash + 1);
/*      */     }
/* 1542 */     String query = QNameHelper.hexsafe((question == -1) ? "" : uri.substring(question));
/*      */ 
/*      */     
/* 1545 */     if (query.startsWith("URI_SHA_1_")) {
/* 1546 */       return dir + "/" + uri.substring(lastslash + 1, question);
/*      */     }
/* 1548 */     return dir + "/" + uri.substring(lastslash + 1, question) + query;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSourceUri(String uri, String nameToUse) {
/* 1557 */     if (uri == null) {
/*      */       return;
/*      */     }
/* 1560 */     if (nameToUse == null) {
/* 1561 */       nameToUse = computeSavedFilename(uri);
/*      */     }
/* 1563 */     this._sourceForUri.put(uri, nameToUse);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection getErrorListener() {
/* 1571 */     return this._errorListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaTypeLoader getS4SLoader() {
/* 1579 */     return this._s4sloader;
/*      */   }
/*      */   private StscState() {
/* 1582 */     this._sourceForUri = new HashMap();
/* 1583 */     this._baseURI = URI.create("project://local/");
/* 1584 */     this._s4sloader = XmlBeans.typeLoaderForClassLoader(SchemaDocument.class.getClassLoader());
/*      */   }
/*      */   
/*      */   public File getSchemasDir() {
/* 1588 */     return this._schemasDir;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSchemasDir(File _schemasDir) {
/* 1593 */     this._schemasDir = _schemasDir;
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscState.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */