/*    */ package org.apache.xmlbeans.impl.schema;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlAnySimpleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlValueRef
/*    */ {
/*    */   XmlAnySimpleType _obj;
/*    */   SchemaType.Ref _typeref;
/*    */   Object _initVal;
/*    */   
/*    */   public XmlValueRef(XmlAnySimpleType xobj) {
/* 34 */     if (xobj == null)
/* 35 */       throw new IllegalArgumentException(); 
/* 36 */     this._obj = xobj;
/*    */   }
/*    */ 
/*    */   
/*    */   XmlValueRef(SchemaType.Ref typeref, Object initVal) {
/* 41 */     if (typeref == null)
/* 42 */       throw new IllegalArgumentException(); 
/* 43 */     this._typeref = typeref;
/* 44 */     this._initVal = initVal;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized XmlAnySimpleType get() {
/* 49 */     if (this._obj == null) {
/*    */       
/* 51 */       SchemaType type = this._typeref.get();
/* 52 */       if (type.getSimpleVariety() != 3) {
/* 53 */         this._obj = type.newValue(this._initVal);
/*    */       } else {
/*    */         
/* 56 */         List actualVals = new ArrayList();
/* 57 */         for (Iterator i = ((List)this._initVal).iterator(); i.hasNext(); ) {
/*    */           
/* 59 */           XmlValueRef ref = i.next();
/* 60 */           actualVals.add(ref.get());
/*    */         } 
/* 62 */         this._obj = type.newValue(actualVals);
/*    */       } 
/*    */     } 
/* 65 */     return this._obj;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\XmlValueRef.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */