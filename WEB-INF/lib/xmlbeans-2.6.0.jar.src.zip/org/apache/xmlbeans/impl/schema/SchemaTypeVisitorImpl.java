/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaField;
/*     */ import org.apache.xmlbeans.SchemaLocalElement;
/*     */ import org.apache.xmlbeans.SchemaParticle;
/*     */ import org.apache.xmlbeans.impl.values.TypeStoreVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaTypeVisitorImpl
/*     */   implements TypeStoreVisitor
/*     */ {
/*     */   static final boolean PROBE_VALIDITY = true;
/*     */   static final boolean CHECK_VALIDITY = false;
/*     */   private VisitorState[] _stack;
/*     */   private VisitorState[] _rollback;
/*     */   int _stackSize;
/*     */   int _rollbackSize;
/*     */   private boolean _isValid;
/*     */   private SchemaParticle _matchedParticle;
/*     */   private VisitorState _top;
/*     */   private int _rollbackIndex;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public SchemaTypeVisitorImpl(SchemaParticle part) {
/*  38 */     init(part);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaTypeVisitorImpl() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(SchemaParticle part) {
/*  48 */     if (this._stack == null)
/*     */     {
/*  50 */       this._stack = expand(null);
/*     */     }
/*  52 */     if (this._rollback == null)
/*     */     {
/*  54 */       this._rollback = expand(null);
/*     */     }
/*     */     
/*  57 */     this._stackSize = 0;
/*  58 */     this._rollbackSize = 0;
/*     */     
/*  60 */     if (part != null) {
/*     */       
/*  62 */       push(part);
/*  63 */       this._rollbackIndex = 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public VisitorState[] expand(VisitorState[] orig) {
/*  69 */     int newsize = (orig == null) ? 4 : (orig.length * 2);
/*  70 */     VisitorState[] result = new VisitorState[newsize];
/*  71 */     if (orig != null)
/*  72 */       System.arraycopy(orig, 0, result, 0, orig.length); 
/*  73 */     for (int i = (orig == null) ? 0 : orig.length; i < newsize; i++)
/*     */     {
/*  75 */       result[i] = new VisitorState();
/*     */     }
/*  77 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class VisitorState
/*     */   {
/*     */     SchemaParticle _curPart;
/*     */     
/*     */     int _curCount;
/*     */     
/*     */     int _curMax;
/*     */     
/*     */     int _curMin;
/*     */     int _processedChildCount;
/*     */     int _childCount;
/*     */     boolean[] _seen;
/*     */     
/*     */     private VisitorState() {}
/*     */     
/*     */     public void copy(VisitorState orig) {
/*  97 */       this._curPart = orig._curPart;
/*  98 */       this._curCount = orig._curCount;
/*  99 */       this._curMin = orig._curMin;
/* 100 */       this._curMax = orig._curMax;
/* 101 */       this._processedChildCount = orig._processedChildCount;
/* 102 */       this._childCount = orig._childCount;
/* 103 */       if (orig._seen != null) {
/*     */         
/* 105 */         this._seen = new boolean[orig._seen.length];
/* 106 */         System.arraycopy(orig._seen, 0, this._seen, 0, orig._seen.length);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void init(SchemaParticle part) {
/* 112 */       this._curPart = part;
/* 113 */       this._curMin = part.getIntMinOccurs();
/* 114 */       this._curMax = part.getIntMaxOccurs();
/* 115 */       this._curCount = 0;
/* 116 */       this._processedChildCount = 0;
/* 117 */       this._childCount = part.countOfParticleChild();
/* 118 */       this._seen = (part.getParticleType() == 1) ? new boolean[this._childCount] : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   VisitorState topRef() {
/* 133 */     return this._stack[this._stackSize - 1];
/*     */   }
/*     */ 
/*     */   
/*     */   void saveCopy(VisitorState ref) {
/* 138 */     if (this._rollback.length == this._rollbackSize) {
/* 139 */       this._rollback = expand(this._rollback);
/*     */     }
/* 141 */     this._rollback[this._rollbackSize].copy(ref);
/* 142 */     this._rollbackSize++;
/*     */   }
/*     */ 
/*     */   
/*     */   void addParticle(SchemaParticle part) {
/* 147 */     if (this._stack.length == this._stackSize)
/* 148 */       this._stack = expand(this._stack); 
/* 149 */     this._stack[this._stackSize].init(part);
/* 150 */     this._stackSize++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean prepare() {
/* 166 */     if (this._rollbackIndex == 0) {
/*     */       
/* 168 */       this._top = null;
/* 169 */       return false;
/*     */     } 
/*     */     
/* 172 */     this._top = topRef();
/* 173 */     saveCopy(this._top);
/* 174 */     this._rollbackIndex = this._stackSize - 1;
/* 175 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void push(SchemaParticle part) {
/* 191 */     addParticle(part);
/* 192 */     this._top = topRef();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean pop() {
/* 208 */     this._stackSize--;
/* 209 */     if (this._stackSize <= this._rollbackIndex)
/* 210 */       return prepare(); 
/* 211 */     this._top = topRef();
/* 212 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void commit() {
/* 228 */     this._top = null;
/* 229 */     this._rollbackIndex = this._stackSize;
/* 230 */     this._rollbackSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rollback() {
/* 246 */     while (this._rollbackSize > 0) {
/*     */       
/* 248 */       this._rollbackSize--;
/* 249 */       VisitorState temp = this._stack[this._rollbackIndex];
/* 250 */       this._stack[this._rollbackIndex] = this._rollback[this._rollbackSize];
/* 251 */       this._rollback[this._rollbackSize] = temp;
/* 252 */       this._rollbackIndex++;
/*     */     } 
/* 254 */     this._stackSize = this._rollbackIndex;
/* 255 */     this._top = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean notValid() {
/* 266 */     this._isValid = false;
/* 267 */     this._matchedParticle = null;
/* 268 */     rollback();
/* 269 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean ok(SchemaParticle part, boolean testValidity) {
/* 279 */     if (!testValidity) {
/*     */       
/* 281 */       this._matchedParticle = part;
/* 282 */       commit();
/*     */     }
/*     */     else {
/*     */       
/* 286 */       rollback();
/*     */     } 
/* 288 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(QName eltName) {
/* 304 */     return visit(eltName, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(QName eltName, boolean testValidity) {
/* 321 */     if (!prepare()) {
/* 322 */       return notValid();
/*     */     }
/*     */     
/* 325 */     int lastAtProcessedChildCount = -2;
/* 326 */     int lastAtStackSize = -2;
/*     */ 
/*     */     
/*     */     label78: while (true)
/*     */     { int i, skipped, j;
/*     */       
/* 332 */       if (this._top._curCount > this._top._curMin && lastAtProcessedChildCount == this._top._processedChildCount && lastAtStackSize == this._stackSize)
/*     */       {
/*     */ 
/*     */         
/* 336 */         this._top._curCount = this._top._curMax;
/*     */       }
/*     */ 
/*     */       
/* 340 */       lastAtProcessedChildCount = this._top._processedChildCount;
/* 341 */       lastAtStackSize = this._stackSize;
/*     */       
/* 343 */       while (this._top._curCount >= this._top._curMax)
/*     */       
/* 345 */       { if (!pop())
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 451 */           if (eltName == null) {
/* 452 */             return ok(null, testValidity);
/*     */           }
/*     */           
/* 455 */           return notValid(); }  }  switch (this._top._curPart.getParticleType()) { default: assert false;case 5: if (!this._top._curPart.canStartWithElement(eltName)) { if (this._top._curCount < this._top._curMin) return notValid();  break; }  this._top._curCount++; return ok(this._top._curPart, testValidity);case 4: if (!this._top._curPart.canStartWithElement(eltName)) { if (this._top._curCount < this._top._curMin) return notValid();  break; }  this._top._curCount++; return ok(this._top._curPart, testValidity);case 3: for (i = this._top._processedChildCount; i < this._top._childCount; i++) { SchemaParticle candidate = this._top._curPart.getParticleChild(i); if (candidate.canStartWithElement(eltName)) { this._top._processedChildCount = i + 1; push(candidate); continue label78; }  if (!candidate.isSkippable()) { if (this._top._processedChildCount != 0 || this._top._curCount < this._top._curMin) return notValid();  continue label78; }  }  this._top._curCount++; this._top._processedChildCount = 0; continue;case 2: for (i = 0; i < this._top._childCount; i++) { SchemaParticle candidate = this._top._curPart.getParticleChild(i); if (candidate.canStartWithElement(eltName)) { this._top._curCount++; push(candidate); continue label78; }  }  if (this._top._curCount < this._top._curMin && !this._top._curPart.isSkippable()) return notValid();  break;case 1: skipped = this._top._processedChildCount; for (j = 0; j < this._top._childCount; j++) { if (!this._top._seen[j]) { SchemaParticle candidate = this._top._curPart.getParticleChild(j); if (candidate.canStartWithElement(eltName)) { this._top._processedChildCount++; this._top._seen[j] = true; push(candidate); continue label78; }  if (candidate.isSkippable()) skipped++;  }  }  if (skipped < this._top._childCount) { if (this._top._curCount < this._top._curMin) return notValid();  break; }  this._top._curCount++; this._top._processedChildCount = 0; Arrays.fill(this._top._seen, false); continue; }  if (!pop()) break;  }  if (eltName == null) return ok(null, testValidity);  return notValid();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean testValid(QName eltName) {
/* 460 */     return visit(eltName, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get_elementflags() {
/* 468 */     if (currentParticle() == null || currentParticle().getParticleType() != 4) {
/* 469 */       return 0;
/*     */     }
/* 471 */     SchemaLocalElement elt = (SchemaLocalElement)currentParticle();
/*     */     
/* 473 */     return (elt.isNillable() ? 1 : 0) | (elt.isDefault() ? 2 : 0) | (elt.isFixed() ? 4 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get_default_text() {
/* 483 */     if (currentParticle() == null || currentParticle().getParticleType() != 4) {
/* 484 */       return null;
/*     */     }
/* 486 */     return ((SchemaLocalElement)currentParticle()).getDefaultText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaField get_schema_field() {
/* 493 */     if (currentParticle() instanceof SchemaField) {
/* 494 */       return (SchemaField)currentParticle();
/*     */     }
/* 496 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaParticle currentParticle() {
/* 504 */     return this._matchedParticle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllValid() {
/* 512 */     return this._isValid;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaTypeVisitorImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */