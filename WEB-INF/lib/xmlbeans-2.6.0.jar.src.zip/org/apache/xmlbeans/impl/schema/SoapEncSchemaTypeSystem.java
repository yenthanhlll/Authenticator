/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.Filer;
/*     */ import org.apache.xmlbeans.QNameSet;
/*     */ import org.apache.xmlbeans.SchemaAnnotation;
/*     */ import org.apache.xmlbeans.SchemaAttributeGroup;
/*     */ import org.apache.xmlbeans.SchemaComponent;
/*     */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*     */ import org.apache.xmlbeans.SchemaGlobalElement;
/*     */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*     */ import org.apache.xmlbeans.SchemaModelGroup;
/*     */ import org.apache.xmlbeans.SchemaParticle;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoapEncSchemaTypeSystem
/*     */   extends SchemaTypeLoaderBase
/*     */   implements SchemaTypeSystem
/*     */ {
/*     */   public static final String SOAPENC = "http://schemas.xmlsoap.org/soap/encoding/";
/*     */   public static final String SOAP_ARRAY = "Array";
/*     */   public static final String ARRAY_TYPE = "arrayType";
/*     */   private static final String ATTR_ID = "id";
/*     */   private static final String ATTR_HREF = "href";
/*     */   private static final String ATTR_OFFSET = "offset";
/*  58 */   private static final SchemaType[] EMPTY_SCHEMATYPE_ARRAY = new SchemaType[0];
/*  59 */   private static final SchemaGlobalElement[] EMPTY_SCHEMAELEMENT_ARRAY = new SchemaGlobalElement[0];
/*  60 */   private static final SchemaModelGroup[] EMPTY_SCHEMAMODELGROUP_ARRAY = new SchemaModelGroup[0];
/*  61 */   private static final SchemaAttributeGroup[] EMPTY_SCHEMAATTRIBUTEGROUP_ARRAY = new SchemaAttributeGroup[0];
/*  62 */   private static final SchemaAnnotation[] EMPTY_SCHEMAANNOTATION_ARRAY = new SchemaAnnotation[0];
/*     */ 
/*     */   
/*     */   public static SchemaTypeSystem get() {
/*  66 */     return _global;
/*     */   }
/*  68 */   private static SoapEncSchemaTypeSystem _global = new SoapEncSchemaTypeSystem();
/*     */   
/*     */   private SchemaTypeImpl soapArray;
/*     */   private SchemaGlobalAttributeImpl arrayType;
/*  72 */   private Map _handlesToObjects = new HashMap();
/*     */   private String soapArrayHandle;
/*  74 */   private SchemaContainer _container = new SchemaContainer("http://schemas.xmlsoap.org/soap/encoding/");
/*     */ 
/*     */ 
/*     */   
/*     */   private SoapEncSchemaTypeSystem() {
/*  79 */     this._container.setTypeSystem(this);
/*  80 */     this.soapArray = new SchemaTypeImpl(this._container, true);
/*  81 */     this._container.addGlobalType(this.soapArray.getRef());
/*  82 */     this.soapArray.setName(new QName("http://schemas.xmlsoap.org/soap/encoding/", "Array"));
/*  83 */     this.soapArrayHandle = "Array".toLowerCase() + "type";
/*  84 */     this.soapArray.setComplexTypeVariety(3);
/*  85 */     this.soapArray.setBaseTypeRef(BuiltinSchemaTypeSystem.ST_ANY_TYPE.getRef());
/*  86 */     this.soapArray.setBaseDepth(1);
/*  87 */     this.soapArray.setDerivationType(2);
/*  88 */     this.soapArray.setSimpleTypeVariety(0);
/*  89 */     SchemaParticleImpl contentModel = new SchemaParticleImpl();
/*  90 */     contentModel.setParticleType(3);
/*  91 */     contentModel.setMinOccurs(BigInteger.ZERO);
/*  92 */     contentModel.setMaxOccurs(BigInteger.ONE);
/*  93 */     contentModel.setTransitionRules(QNameSet.ALL, true);
/*  94 */     SchemaParticleImpl[] children = new SchemaParticleImpl[1];
/*  95 */     contentModel.setParticleChildren((SchemaParticle[])children);
/*  96 */     SchemaParticleImpl contentModel2 = new SchemaParticleImpl();
/*  97 */     contentModel2.setParticleType(5);
/*  98 */     contentModel2.setWildcardSet(QNameSet.ALL);
/*  99 */     contentModel2.setWildcardProcess(2);
/* 100 */     contentModel2.setMinOccurs(BigInteger.ZERO);
/* 101 */     contentModel2.setMaxOccurs(null);
/* 102 */     contentModel2.setTransitionRules(QNameSet.ALL, true);
/* 103 */     children[0] = contentModel2;
/*     */     
/* 105 */     SchemaAttributeModelImpl attrModel = new SchemaAttributeModelImpl();
/* 106 */     attrModel.setWildcardProcess(2);
/* 107 */     HashSet excludedURI = new HashSet();
/* 108 */     excludedURI.add("http://schemas.xmlsoap.org/soap/encoding/");
/* 109 */     attrModel.setWildcardSet(QNameSet.forSets(excludedURI, null, Collections.EMPTY_SET, Collections.EMPTY_SET));
/*     */     
/* 111 */     SchemaLocalAttributeImpl attr = new SchemaLocalAttributeImpl();
/* 112 */     attr.init(new QName("", "id"), BuiltinSchemaTypeSystem.ST_ID.getRef(), 2, null, null, null, false, null, null, null);
/*     */     
/* 114 */     attrModel.addAttribute(attr);
/* 115 */     attr = new SchemaLocalAttributeImpl();
/* 116 */     attr.init(new QName("", "href"), BuiltinSchemaTypeSystem.ST_ANY_URI.getRef(), 2, null, null, null, false, null, null, null);
/*     */     
/* 118 */     attrModel.addAttribute(attr);
/* 119 */     attr = new SchemaLocalAttributeImpl();
/* 120 */     attr.init(new QName("http://schemas.xmlsoap.org/soap/encoding/", "arrayType"), BuiltinSchemaTypeSystem.ST_STRING.getRef(), 2, null, null, null, false, null, null, null);
/*     */     
/* 122 */     attrModel.addAttribute(attr);
/* 123 */     attr = new SchemaLocalAttributeImpl();
/* 124 */     attr.init(new QName("http://schemas.xmlsoap.org/soap/encoding/", "offset"), BuiltinSchemaTypeSystem.ST_STRING.getRef(), 2, null, null, null, false, null, null, null);
/*     */     
/* 126 */     attrModel.addAttribute(attr);
/* 127 */     this.soapArray.setContentModel(contentModel, attrModel, Collections.EMPTY_MAP, Collections.EMPTY_MAP, false);
/*     */ 
/*     */     
/* 130 */     this.arrayType = new SchemaGlobalAttributeImpl(this._container);
/* 131 */     this._container.addGlobalAttribute(this.arrayType.getRef());
/* 132 */     this.arrayType.init(new QName("http://schemas.xmlsoap.org/soap/encoding/", "arrayType"), BuiltinSchemaTypeSystem.ST_STRING.getRef(), 2, null, null, null, false, null, null, null);
/*     */     
/* 134 */     this._handlesToObjects.put(this.soapArrayHandle, this.soapArray);
/* 135 */     this._handlesToObjects.put("arrayType".toLowerCase() + "attribute", this.arrayType);
/* 136 */     this._container.setImmutable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 144 */     return "schema.typesystem.soapenc.builtin";
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType findType(QName qName) {
/* 149 */     if ("http://schemas.xmlsoap.org/soap/encoding/".equals(qName.getNamespaceURI()) && "Array".equals(qName.getLocalPart()))
/*     */     {
/* 151 */       return this.soapArray;
/*     */     }
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType findDocumentType(QName qName) {
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType findAttributeType(QName qName) {
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalElement findElement(QName qName) {
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalAttribute findAttribute(QName qName) {
/* 173 */     if ("http://schemas.xmlsoap.org/soap/encoding/".equals(qName.getNamespaceURI()) && "arrayType".equals(qName.getLocalPart()))
/*     */     {
/* 175 */       return this.arrayType;
/*     */     }
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaModelGroup findModelGroup(QName qName) {
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAttributeGroup findAttributeGroup(QName qName) {
/* 187 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNamespaceDefined(String string) {
/* 192 */     return "http://schemas.xmlsoap.org/soap/encoding/".equals(string);
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType.Ref findTypeRef(QName qName) {
/* 197 */     SchemaType type = findType(qName);
/* 198 */     return (type == null) ? null : type.getRef();
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType.Ref findDocumentTypeRef(QName qName) {
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType.Ref findAttributeTypeRef(QName qName) {
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalElement.Ref findElementRef(QName qName) {
/* 213 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalAttribute.Ref findAttributeRef(QName qName) {
/* 218 */     SchemaGlobalAttribute attr = findAttribute(qName);
/* 219 */     return (attr == null) ? null : attr.getRef();
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaModelGroup.Ref findModelGroupRef(QName qName) {
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAttributeGroup.Ref findAttributeGroupRef(QName qName) {
/* 229 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaIdentityConstraint.Ref findIdentityConstraintRef(QName qName) {
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType typeForClassname(String string) {
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getSourceAsStream(String string) {
/* 244 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 252 */     return SoapEncSchemaTypeSystem.class.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaType[] globalTypes() {
/* 269 */     return new SchemaType[] { this.soapArray };
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType[] documentTypes() {
/* 274 */     return EMPTY_SCHEMATYPE_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType[] attributeTypes() {
/* 279 */     return EMPTY_SCHEMATYPE_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalElement[] globalElements() {
/* 284 */     return EMPTY_SCHEMAELEMENT_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalAttribute[] globalAttributes() {
/* 289 */     return new SchemaGlobalAttribute[] { this.arrayType };
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaModelGroup[] modelGroups() {
/* 294 */     return EMPTY_SCHEMAMODELGROUP_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAttributeGroup[] attributeGroups() {
/* 299 */     return EMPTY_SCHEMAATTRIBUTEGROUP_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAnnotation[] annotations() {
/* 304 */     return EMPTY_SCHEMAANNOTATION_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String handleForType(SchemaType type) {
/* 312 */     if (this.soapArray.equals(type)) {
/* 313 */       return this.soapArrayHandle;
/*     */     }
/* 315 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaComponent resolveHandle(String string) {
/* 323 */     return (SchemaComponent)this._handlesToObjects.get(string);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaType typeForHandle(String string) {
/* 331 */     return (SchemaType)this._handlesToObjects.get(string);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveToDirectory(File file) {
/* 341 */     throw new UnsupportedOperationException("The builtin soap encoding schema type system cannot be saved.");
/*     */   }
/*     */ 
/*     */   
/*     */   public void save(Filer filer) {
/* 346 */     throw new UnsupportedOperationException("The builtin soap encoding schema type system cannot be saved.");
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SoapEncSchemaTypeSystem.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */