/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaAnnotation;
/*     */ import org.apache.xmlbeans.SchemaComponent;
/*     */ import org.apache.xmlbeans.SchemaModelGroup;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaModelGroupImpl
/*     */   implements SchemaModelGroup
/*     */ {
/*     */   private SchemaContainer _container;
/*     */   private QName _name;
/*     */   private XmlObject _parseObject;
/*     */   private Object _userData;
/*     */   private String _parseTNS;
/*     */   private boolean _chameleon;
/*     */   private String _elemFormDefault;
/*     */   private String _attFormDefault;
/*     */   private boolean _redefinition;
/*     */   private SchemaAnnotation _annotation;
/*     */   private String _filename;
/*     */   private SchemaModelGroup.Ref _selfref;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public SchemaModelGroupImpl(SchemaContainer container) {
/* 109 */     this._selfref = new SchemaModelGroup.Ref(this); this._container = container; } public SchemaModelGroupImpl(SchemaContainer container, QName name) { this._selfref = new SchemaModelGroup.Ref(this); this._container = container; this._name = name; }
/*     */   public void init(QName name, String targetNamespace, boolean chameleon, String elemFormDefault, String attFormDefault, boolean redefinition, XmlObject x, SchemaAnnotation a, Object userData) { assert this._name == null || name.equals(this._name); this._name = name; this._parseTNS = targetNamespace; this._chameleon = chameleon; this._elemFormDefault = elemFormDefault; this._attFormDefault = attFormDefault; this._redefinition = redefinition; this._parseObject = x; this._annotation = a; this._userData = userData; }
/*     */   public SchemaTypeSystem getTypeSystem() { return this._container.getTypeSystem(); }
/* 112 */   SchemaContainer getContainer() { return this._container; } public int getComponentType() { return 6; } public void setFilename(String filename) { this._filename = filename; } public String getSourceName() { return this._filename; } public QName getName() { return this._name; } public SchemaModelGroup.Ref getRef() { return this._selfref; }
/*     */   public XmlObject getParseObject() { return this._parseObject; }
/*     */   public String getTargetNamespace() { return this._parseTNS; }
/* 115 */   public String getChameleonNamespace() { return this._chameleon ? this._parseTNS : null; } public String getElemFormDefault() { return this._elemFormDefault; } public String getAttFormDefault() { return this._attFormDefault; } public boolean isRedefinition() { return this._redefinition; } public SchemaAnnotation getAnnotation() { return this._annotation; } public SchemaComponent.Ref getComponentRef() { return (SchemaComponent.Ref)getRef(); }
/*     */   
/*     */   public Object getUserData() {
/* 118 */     return this._userData;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaModelGroupImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */