/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaAnnotation;
/*     */ import org.apache.xmlbeans.SchemaComponent;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Annotated;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AnnotationDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AppinfoDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.DocumentationDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaAnnotationImpl
/*     */   implements SchemaAnnotation
/*     */ {
/*     */   private SchemaContainer _container;
/*     */   private String[] _appInfoAsXml;
/*     */   private AppinfoDocument.Appinfo[] _appInfo;
/*     */   private String[] _documentationAsXml;
/*     */   private DocumentationDocument.Documentation[] _documentation;
/*     */   private SchemaAnnotation.Attribute[] _attributes;
/*     */   private String _filename;
/*     */   
/*     */   public void setFilename(String filename) {
/*  46 */     this._filename = filename;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/*  51 */     return this._filename;
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject[] getApplicationInformation() {
/*  56 */     if (this._appInfo == null) {
/*     */       
/*  58 */       int n = this._appInfoAsXml.length;
/*  59 */       this._appInfo = new AppinfoDocument.Appinfo[n];
/*  60 */       for (int i = 0; i < n; i++) {
/*     */         
/*  62 */         String appInfo = this._appInfoAsXml[i];
/*     */         
/*     */         try {
/*  65 */           this._appInfo[i] = AppinfoDocument.Factory.parse(appInfo).getAppinfo();
/*     */         
/*     */         }
/*  68 */         catch (XmlException e) {
/*     */ 
/*     */           
/*  71 */           this._appInfo[i] = AppinfoDocument.Factory.newInstance().getAppinfo();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  76 */     return (XmlObject[])this._appInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject[] getUserInformation() {
/*  81 */     if (this._documentation == null) {
/*     */       
/*  83 */       int n = this._documentationAsXml.length;
/*  84 */       this._documentation = new DocumentationDocument.Documentation[n];
/*  85 */       for (int i = 0; i < n; i++) {
/*     */         
/*  87 */         String doc = this._documentationAsXml[i];
/*     */         
/*     */         try {
/*  90 */           this._documentation[i] = DocumentationDocument.Factory.parse(doc).getDocumentation();
/*     */         
/*     */         }
/*  93 */         catch (XmlException e) {
/*     */ 
/*     */           
/*  96 */           this._documentation[i] = DocumentationDocument.Factory.newInstance().getDocumentation();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 101 */     return (XmlObject[])this._documentation;
/*     */   }
/*     */   
/*     */   public SchemaAnnotation.Attribute[] getAttributes() {
/* 105 */     return this._attributes;
/*     */   }
/*     */   public int getComponentType() {
/* 108 */     return 8;
/*     */   }
/*     */   public SchemaTypeSystem getTypeSystem() {
/* 111 */     return (this._container != null) ? this._container.getTypeSystem() : null;
/*     */   }
/*     */   SchemaContainer getContainer() {
/* 114 */     return this._container;
/*     */   }
/*     */   public QName getName() {
/* 117 */     return null;
/*     */   }
/*     */   public SchemaComponent.Ref getComponentRef() {
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static SchemaAnnotationImpl getAnnotation(SchemaContainer c, Annotated elem) {
/* 125 */     AnnotationDocument.Annotation ann = elem.getAnnotation();
/*     */     
/* 127 */     return getAnnotation(c, (XmlObject)elem, ann);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaAnnotationImpl getAnnotation(SchemaContainer c, XmlObject elem, AnnotationDocument.Annotation ann) {
/* 134 */     if (StscState.get().noAnn()) {
/* 135 */       return null;
/*     */     }
/* 137 */     SchemaAnnotationImpl result = new SchemaAnnotationImpl(c);
/*     */     
/* 139 */     ArrayList attrArray = new ArrayList(2);
/* 140 */     addNoSchemaAttributes(elem, attrArray);
/* 141 */     if (ann == null) {
/*     */       
/* 143 */       if (attrArray.size() == 0) {
/* 144 */         return null;
/*     */       }
/*     */       
/* 147 */       result._appInfo = new AppinfoDocument.Appinfo[0];
/* 148 */       result._documentation = new DocumentationDocument.Documentation[0];
/*     */     }
/*     */     else {
/*     */       
/* 152 */       result._appInfo = ann.getAppinfoArray();
/* 153 */       result._documentation = ann.getDocumentationArray();
/*     */       
/* 155 */       addNoSchemaAttributes((XmlObject)ann, attrArray);
/*     */     } 
/*     */     
/* 158 */     result._attributes = (SchemaAnnotation.Attribute[])attrArray.toArray((Object[])new AttributeImpl[attrArray.size()]);
/*     */     
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addNoSchemaAttributes(XmlObject elem, List attrList) {
/* 165 */     XmlCursor cursor = elem.newCursor();
/* 166 */     boolean hasAttributes = cursor.toFirstAttribute();
/* 167 */     while (hasAttributes) {
/*     */       
/* 169 */       QName name = cursor.getName();
/* 170 */       String namespaceURI = name.getNamespaceURI();
/* 171 */       if (!"".equals(namespaceURI) && !"http://www.w3.org/2001/XMLSchema".equals(namespaceURI)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 176 */         String prefix, attValue = cursor.getTextValue();
/*     */ 
/*     */         
/* 179 */         if (attValue.indexOf(':') > 0) {
/* 180 */           prefix = attValue.substring(0, attValue.indexOf(':'));
/*     */         } else {
/* 182 */           prefix = "";
/* 183 */         }  cursor.push();
/* 184 */         cursor.toParent();
/* 185 */         String valUri = cursor.namespaceForPrefix(prefix);
/* 186 */         cursor.pop();
/* 187 */         attrList.add(new AttributeImpl(name, attValue, valUri));
/*     */       } 
/* 189 */       hasAttributes = cursor.toNextAttribute();
/*     */     } 
/* 191 */     cursor.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private SchemaAnnotationImpl(SchemaContainer c) {
/* 196 */     this._container = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SchemaAnnotationImpl(SchemaContainer c, String[] aapStrings, String[] adocStrings, SchemaAnnotation.Attribute[] aat) {
/* 203 */     this._container = c;
/* 204 */     this._appInfoAsXml = aapStrings;
/* 205 */     this._documentationAsXml = adocStrings;
/* 206 */     this._attributes = aat;
/*     */   }
/*     */   
/*     */   static class AttributeImpl
/*     */     implements SchemaAnnotation.Attribute
/*     */   {
/*     */     private QName _name;
/*     */     private String _value;
/*     */     private String _valueUri;
/*     */     
/*     */     AttributeImpl(QName name, String value, String valueUri) {
/* 217 */       this._name = name;
/* 218 */       this._value = value;
/* 219 */       this._valueUri = valueUri;
/*     */     }
/*     */     
/*     */     public QName getName() {
/* 223 */       return this._name;
/*     */     }
/*     */     public String getValue() {
/* 226 */       return this._value;
/*     */     }
/*     */     public String getValueUri() {
/* 229 */       return this._valueUri;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaAnnotationImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */