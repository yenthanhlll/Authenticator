/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.QNameSetBuilder;
/*      */ import org.apache.xmlbeans.QNameSetSpecification;
/*      */ import org.apache.xmlbeans.SchemaAttributeModel;
/*      */ import org.apache.xmlbeans.SchemaField;
/*      */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*      */ import org.apache.xmlbeans.SchemaLocalElement;
/*      */ import org.apache.xmlbeans.SchemaParticle;
/*      */ import org.apache.xmlbeans.SchemaProperty;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AllNNI;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AnyDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroupRef;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexContentDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexRestrictionType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ExtensionType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Group;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalElement;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.NamespaceList;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleContentDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleExtensionType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleRestrictionType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Wildcard;
/*      */ 
/*      */ public class StscComplexTypeResolver {
/*      */   private static final int MODEL_GROUP_CODE = 100;
/*      */   
/*      */   public static Group getContentModel(ComplexType parseCt) {
/*   47 */     if (parseCt.getAll() != null) {
/*   48 */       return (Group)parseCt.getAll();
/*      */     }
/*   50 */     if (parseCt.getSequence() != null) {
/*   51 */       return (Group)parseCt.getSequence();
/*      */     }
/*   53 */     if (parseCt.getChoice() != null) {
/*   54 */       return (Group)parseCt.getChoice();
/*      */     }
/*   56 */     if (parseCt.getGroup() != null) {
/*   57 */       return (Group)parseCt.getGroup();
/*      */     }
/*   59 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Group getContentModel(ComplexRestrictionType parseRest) {
/*   64 */     if (parseRest.getAll() != null) {
/*   65 */       return (Group)parseRest.getAll();
/*      */     }
/*   67 */     if (parseRest.getSequence() != null) {
/*   68 */       return (Group)parseRest.getSequence();
/*      */     }
/*   70 */     if (parseRest.getChoice() != null) {
/*   71 */       return (Group)parseRest.getChoice();
/*      */     }
/*   73 */     if (parseRest.getGroup() != null) {
/*   74 */       return (Group)parseRest.getGroup();
/*      */     }
/*   76 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Group getContentModel(ExtensionType parseExt) {
/*   82 */     if (parseExt.getAll() != null) {
/*   83 */       return (Group)parseExt.getAll();
/*      */     }
/*   85 */     if (parseExt.getSequence() != null) {
/*   86 */       return (Group)parseExt.getSequence();
/*      */     }
/*   88 */     if (parseExt.getChoice() != null) {
/*   89 */       return (Group)parseExt.getChoice();
/*      */     }
/*   91 */     if (parseExt.getGroup() != null) {
/*   92 */       return (Group)parseExt.getGroup();
/*      */     }
/*   94 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static SchemaDocument.Schema getSchema(XmlObject o) {
/*  100 */     XmlCursor c = o.newCursor();
/*      */ 
/*      */     
/*      */     try {
/*  104 */       while (c.toParent()) {
/*      */         
/*  106 */         o = c.getObject();
/*      */         
/*  108 */         if (o.schemaType().equals(SchemaDocument.Schema.type)) {
/*  109 */           return (SchemaDocument.Schema)o;
/*      */         }
/*      */       } 
/*      */     } finally {
/*      */       
/*  114 */       c.dispose();
/*      */     } 
/*      */     
/*  117 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void resolveComplexType(SchemaTypeImpl sImpl) {
/*  122 */     ComplexType parseCt = (ComplexType)sImpl.getParseObject();
/*  123 */     StscState state = StscState.get();
/*  124 */     SchemaDocument.Schema schema = getSchema((XmlObject)parseCt);
/*      */ 
/*      */     
/*  127 */     boolean abs = parseCt.isSetAbstract() ? parseCt.getAbstract() : false;
/*  128 */     boolean finalExt = false;
/*  129 */     boolean finalRest = false;
/*  130 */     boolean finalList = false;
/*  131 */     boolean finalUnion = false;
/*      */     
/*  133 */     Object ds = null;
/*  134 */     if (parseCt.isSetFinal()) {
/*      */       
/*  136 */       ds = parseCt.getFinal();
/*      */     
/*      */     }
/*  139 */     else if (schema != null && schema.isSetFinalDefault()) {
/*      */       
/*  141 */       ds = schema.getFinalDefault();
/*      */     } 
/*      */     
/*  144 */     if (ds != null)
/*      */     {
/*  146 */       if (ds instanceof String && ds.equals("#all")) {
/*      */ 
/*      */         
/*  149 */         finalExt = finalRest = finalList = finalUnion = true;
/*      */       }
/*  151 */       else if (ds instanceof List) {
/*      */         
/*  153 */         if (((List)ds).contains("extension")) {
/*  154 */           finalExt = true;
/*      */         }
/*  156 */         if (((List)ds).contains("restriction")) {
/*  157 */           finalRest = true;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  170 */     sImpl.setAbstractFinal(abs, finalExt, finalRest, finalList, finalUnion);
/*      */ 
/*      */     
/*  173 */     boolean blockExt = false;
/*  174 */     boolean blockRest = false;
/*  175 */     Object block = null;
/*      */     
/*  177 */     if (parseCt.isSetBlock()) {
/*  178 */       block = parseCt.getBlock();
/*  179 */     } else if (schema != null && schema.isSetBlockDefault()) {
/*  180 */       block = schema.getBlockDefault();
/*      */     } 
/*  182 */     if (block != null)
/*      */     {
/*  184 */       if (block instanceof String && block.equals("#all")) {
/*      */ 
/*      */         
/*  187 */         blockExt = blockRest = true;
/*      */       }
/*  189 */       else if (block instanceof List) {
/*      */         
/*  191 */         if (((List)block).contains("extension"))
/*  192 */           blockExt = true; 
/*  193 */         if (((List)block).contains("restriction")) {
/*  194 */           blockRest = true;
/*      */         }
/*      */       } 
/*      */     }
/*  198 */     sImpl.setBlock(blockExt, blockRest);
/*      */ 
/*      */     
/*  201 */     ComplexContentDocument.ComplexContent parseCc = parseCt.getComplexContent();
/*  202 */     SimpleContentDocument.SimpleContent parseSc = parseCt.getSimpleContent();
/*  203 */     Group parseGroup = getContentModel(parseCt);
/*  204 */     int count = ((parseCc != null) ? 1 : 0) + ((parseSc != null) ? 1 : 0) + ((parseGroup != null) ? 1 : 0);
/*      */ 
/*      */ 
/*      */     
/*  208 */     if (count > 1) {
/*      */ 
/*      */       
/*  211 */       state.error("A complex type must define either a content model, or a simpleContent or complexContent derivation: more than one found.", 26, (XmlObject)parseCt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  216 */       parseGroup = null;
/*  217 */       if (parseCc != null && parseSc != null) {
/*  218 */         parseSc = null;
/*      */       }
/*      */     } 
/*  221 */     if (parseCc != null) {
/*      */ 
/*      */       
/*  224 */       if (parseCc.getExtension() != null && parseCc.getRestriction() != null) {
/*  225 */         state.error("Restriction conflicts with extension", 26, (XmlObject)parseCc.getRestriction());
/*      */       }
/*      */ 
/*      */       
/*  229 */       boolean mixed = parseCc.isSetMixed() ? parseCc.getMixed() : parseCt.getMixed();
/*      */       
/*  231 */       if (parseCc.getExtension() != null) {
/*  232 */         resolveCcExtension(sImpl, parseCc.getExtension(), mixed);
/*  233 */       } else if (parseCc.getRestriction() != null) {
/*  234 */         resolveCcRestriction(sImpl, parseCc.getRestriction(), mixed);
/*      */       }
/*      */       else {
/*      */         
/*  238 */         state.error("Missing restriction or extension", 27, (XmlObject)parseCc);
/*  239 */         resolveErrorType(sImpl);
/*      */       } 
/*      */       return;
/*      */     } 
/*  243 */     if (parseSc != null) {
/*      */ 
/*      */       
/*  246 */       if (parseSc.getExtension() != null && parseSc.getRestriction() != null) {
/*  247 */         state.error("Restriction conflicts with extension", 26, (XmlObject)parseSc.getRestriction());
/*      */       }
/*  249 */       if (parseSc.getExtension() != null) {
/*  250 */         resolveScExtension(sImpl, parseSc.getExtension());
/*  251 */       } else if (parseSc.getRestriction() != null) {
/*  252 */         resolveScRestriction(sImpl, parseSc.getRestriction());
/*      */       }
/*      */       else {
/*      */         
/*  256 */         state.error("Missing restriction or extension", 27, (XmlObject)parseSc);
/*  257 */         resolveErrorType(sImpl);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*  262 */     resolveBasicComplexType(sImpl);
/*      */   }
/*      */ 
/*      */   
/*      */   static void resolveErrorType(SchemaTypeImpl sImpl) {
/*  267 */     throw new RuntimeException("This type of error recovery not yet implemented.");
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaType.Ref[] makeRefArray(Collection typeList) {
/*  272 */     SchemaType.Ref[] result = new SchemaType.Ref[typeList.size()];
/*  273 */     int j = 0;
/*  274 */     for (Iterator i = typeList.iterator(); i.hasNext(); j++)
/*  275 */       result[j] = ((SchemaType)i.next()).getRef(); 
/*  276 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void resolveBasicComplexType(SchemaTypeImpl sImpl) {
/*  282 */     List anonymousTypes = new ArrayList();
/*  283 */     ComplexType parseTree = (ComplexType)sImpl.getParseObject();
/*  284 */     String targetNamespace = sImpl.getTargetNamespace();
/*  285 */     boolean chameleon = (sImpl.getChameleonNamespace() != null);
/*  286 */     Group parseGroup = getContentModel(parseTree);
/*      */     
/*  288 */     if (sImpl.isRedefinition())
/*      */     {
/*  290 */       StscState.get().error("src-redefine.5a", new Object[] { "<complexType>" }, (XmlObject)parseTree);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  295 */     int particleCode = translateParticleCode(parseGroup);
/*      */ 
/*      */     
/*  298 */     Map elementModel = new LinkedHashMap();
/*      */ 
/*      */     
/*  301 */     SchemaParticle contentModel = translateContentModel(sImpl, (XmlObject)parseGroup, targetNamespace, chameleon, sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), particleCode, anonymousTypes, elementModel, false, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  307 */     boolean isAll = (contentModel != null && contentModel.getParticleType() == 1);
/*      */ 
/*      */     
/*  310 */     SchemaAttributeModelImpl attrModel = new SchemaAttributeModelImpl();
/*  311 */     translateAttributeModel((XmlObject)parseTree, targetNamespace, chameleon, sImpl.getAttFormDefault(), anonymousTypes, sImpl, null, attrModel, null, true, null);
/*      */ 
/*      */ 
/*      */     
/*  315 */     WildcardResult wcElt = summarizeEltWildcards(contentModel);
/*  316 */     WildcardResult wcAttr = summarizeAttrWildcards(attrModel);
/*      */ 
/*      */     
/*  319 */     if (contentModel != null) {
/*      */       
/*  321 */       buildStateMachine(contentModel);
/*  322 */       if (!StscState.get().noUpa() && !((SchemaParticleImpl)contentModel).isDeterministic()) {
/*  323 */         StscState.get().error("cos-nonambig", (Object[])null, (XmlObject)parseGroup);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  328 */     Map elementPropertyModel = buildContentPropertyModelByQName(contentModel, sImpl);
/*      */ 
/*      */     
/*  331 */     Map attributePropertyModel = buildAttributePropertyModelByQName(attrModel, sImpl);
/*      */ 
/*      */     
/*  334 */     int complexVariety = parseTree.getMixed() ? 4 : ((contentModel == null) ? 1 : 3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  342 */     sImpl.setBaseTypeRef(BuiltinSchemaTypeSystem.ST_ANY_TYPE.getRef());
/*  343 */     sImpl.setBaseDepth(BuiltinSchemaTypeSystem.ST_ANY_TYPE.getBaseDepth() + 1);
/*  344 */     sImpl.setDerivationType(2);
/*  345 */     sImpl.setComplexTypeVariety(complexVariety);
/*  346 */     sImpl.setContentModel(contentModel, attrModel, elementPropertyModel, attributePropertyModel, isAll);
/*  347 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonymousTypes));
/*  348 */     sImpl.setWildcardSummary(wcElt.typedWildcards, wcElt.hasWildcards, wcAttr.typedWildcards, wcAttr.hasWildcards);
/*      */   }
/*      */   static void resolveCcRestriction(SchemaTypeImpl sImpl, ComplexRestrictionType parseTree, boolean mixed) {
/*      */     SchemaType baseType;
/*      */     SchemaAttributeModelImpl attrModel;
/*  353 */     StscState state = StscState.get();
/*  354 */     String targetNamespace = sImpl.getTargetNamespace();
/*  355 */     boolean chameleon = (sImpl.getChameleonNamespace() != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  361 */     if (parseTree.getBase() == null) {
/*      */ 
/*      */       
/*  364 */       state.error("A complexContent must define a base type", 28, (XmlObject)parseTree);
/*  365 */       baseType = null;
/*      */     }
/*      */     else {
/*      */       
/*  369 */       if (sImpl.isRedefinition()) {
/*      */         
/*  371 */         baseType = state.findRedefinedGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), sImpl);
/*  372 */         if (baseType != null && !baseType.getName().equals(sImpl.getName()))
/*      */         {
/*  374 */           state.error("src-redefine.5b", new Object[] { "<complexType>", QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  384 */         baseType = state.findGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), targetNamespace);
/*      */       } 
/*      */       
/*  387 */       if (baseType == null) {
/*  388 */         state.notFoundError(parseTree.getBase(), 0, (XmlObject)parseTree.xgetBase(), true);
/*      */       }
/*      */     } 
/*  391 */     if (baseType == null) {
/*  392 */       baseType = BuiltinSchemaTypeSystem.ST_ANY_TYPE;
/*      */     }
/*  394 */     if (baseType != null && baseType.finalRestriction())
/*      */     {
/*  396 */       state.error("derivation-ok-restriction.1", new Object[] { QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree.xgetBase());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  403 */     if (baseType != null)
/*      */     {
/*  405 */       if (!StscResolver.resolveType((SchemaTypeImpl)baseType)) {
/*  406 */         baseType = null;
/*      */       }
/*      */     }
/*  409 */     List anonymousTypes = new ArrayList();
/*  410 */     Group parseEg = getContentModel(parseTree);
/*      */ 
/*      */     
/*  413 */     int particleCode = translateParticleCode(parseEg);
/*      */ 
/*      */     
/*  416 */     Map elementModel = new LinkedHashMap();
/*      */ 
/*      */     
/*  419 */     SchemaParticle contentModel = translateContentModel(sImpl, (XmlObject)parseEg, targetNamespace, chameleon, sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), particleCode, anonymousTypes, elementModel, false, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  425 */     boolean isAll = (contentModel != null && contentModel.getParticleType() == 1);
/*      */ 
/*      */ 
/*      */     
/*  429 */     if (baseType == null) {
/*  430 */       attrModel = new SchemaAttributeModelImpl();
/*      */     } else {
/*  432 */       attrModel = new SchemaAttributeModelImpl(baseType.getAttributeModel());
/*  433 */     }  translateAttributeModel((XmlObject)parseTree, targetNamespace, chameleon, sImpl.getAttFormDefault(), anonymousTypes, sImpl, null, attrModel, baseType, false, null);
/*      */ 
/*      */ 
/*      */     
/*  437 */     WildcardResult wcElt = summarizeEltWildcards(contentModel);
/*  438 */     WildcardResult wcAttr = summarizeAttrWildcards(attrModel);
/*      */ 
/*      */     
/*  441 */     if (contentModel != null) {
/*      */       
/*  443 */       buildStateMachine(contentModel);
/*  444 */       if (!StscState.get().noUpa() && !((SchemaParticleImpl)contentModel).isDeterministic()) {
/*  445 */         StscState.get().error("cos-nonambig", (Object[])null, (XmlObject)parseEg);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  450 */     Map elementPropertyModel = buildContentPropertyModelByQName(contentModel, sImpl);
/*      */ 
/*      */     
/*  453 */     Map attributePropertyModel = buildAttributePropertyModelByQName(attrModel, sImpl);
/*      */ 
/*      */ 
/*      */     
/*  457 */     int complexVariety = mixed ? 4 : ((contentModel == null) ? 1 : 3);
/*      */ 
/*      */ 
/*      */     
/*  461 */     sImpl.setBaseTypeRef(baseType.getRef());
/*  462 */     sImpl.setBaseDepth(((SchemaTypeImpl)baseType).getBaseDepth() + 1);
/*  463 */     sImpl.setDerivationType(1);
/*  464 */     sImpl.setComplexTypeVariety(complexVariety);
/*  465 */     sImpl.setContentModel(contentModel, attrModel, elementPropertyModel, attributePropertyModel, isAll);
/*  466 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonymousTypes));
/*  467 */     sImpl.setWildcardSummary(wcElt.typedWildcards, wcElt.hasWildcards, wcAttr.typedWildcards, wcAttr.hasWildcards);
/*      */   }
/*      */ 
/*      */   
/*      */   static Map extractElementModel(SchemaType sType) {
/*  472 */     Map elementModel = new HashMap();
/*  473 */     if (sType != null) {
/*      */       
/*  475 */       SchemaProperty[] sProps = sType.getProperties();
/*  476 */       for (int i = 0; i < sProps.length; i++) {
/*      */         
/*  478 */         if (!sProps[i].isAttribute())
/*      */         {
/*  480 */           elementModel.put(sProps[i].getName(), sProps[i].getType());
/*      */         }
/*      */       } 
/*      */     } 
/*  484 */     return elementModel;
/*      */   }
/*      */   static void resolveCcExtension(SchemaTypeImpl sImpl, ExtensionType parseTree, boolean mixed) {
/*      */     SchemaType baseType;
/*      */     SchemaAttributeModelImpl attrModel;
/*      */     int complexVariety;
/*  490 */     StscState state = StscState.get();
/*  491 */     String targetNamespace = sImpl.getTargetNamespace();
/*  492 */     boolean chameleon = (sImpl.getChameleonNamespace() != null);
/*      */     
/*  494 */     if (parseTree.getBase() == null) {
/*      */ 
/*      */       
/*  497 */       state.error("A complexContent must define a base type", 28, (XmlObject)parseTree);
/*  498 */       baseType = null;
/*      */     }
/*      */     else {
/*      */       
/*  502 */       if (sImpl.isRedefinition()) {
/*      */         
/*  504 */         baseType = state.findRedefinedGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), sImpl);
/*  505 */         if (baseType != null && !baseType.getName().equals(sImpl.getName()))
/*      */         {
/*  507 */           state.error("src-redefine.5b", new Object[] { "<complexType>", QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  517 */         baseType = state.findGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), targetNamespace);
/*      */       } 
/*  519 */       if (baseType == null) {
/*  520 */         state.notFoundError(parseTree.getBase(), 0, (XmlObject)parseTree.xgetBase(), true);
/*      */       }
/*      */     } 
/*      */     
/*  524 */     if (baseType != null)
/*      */     {
/*  526 */       if (!StscResolver.resolveType((SchemaTypeImpl)baseType)) {
/*  527 */         baseType = null;
/*      */       }
/*      */     }
/*  530 */     if (baseType != null && baseType.isSimpleType()) {
/*      */       
/*  532 */       state.recover("src-ct.1", new Object[] { QNameHelper.pretty(baseType.getName()) }, (XmlObject)parseTree.xgetBase());
/*      */ 
/*      */       
/*  535 */       baseType = null;
/*      */     } 
/*      */     
/*  538 */     if (baseType != null && baseType.finalExtension())
/*      */     {
/*  540 */       state.error("cos-ct-extends.1.1", new Object[] { QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree.xgetBase());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  547 */     SchemaParticle baseContentModel = (baseType == null) ? null : baseType.getContentModel();
/*      */ 
/*      */     
/*  550 */     List anonymousTypes = new ArrayList();
/*  551 */     Map baseElementModel = extractElementModel(baseType);
/*  552 */     Group parseEg = getContentModel(parseTree);
/*      */     
/*  554 */     if (baseType != null && baseType.getContentType() == 2)
/*      */     {
/*  556 */       if (parseEg != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  561 */         state.recover("cos-ct-extends.1.4.1", new Object[] { QNameHelper.pretty(baseType.getName()) }, (XmlObject)parseTree.xgetBase());
/*      */ 
/*      */         
/*  564 */         baseType = null;
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  569 */         resolveScExtensionPart2(sImpl, baseType, parseTree, targetNamespace, chameleon);
/*      */         
/*      */         return;
/*      */       } 
/*      */     }
/*  574 */     SchemaParticle extensionModel = translateContentModel(sImpl, (XmlObject)parseEg, targetNamespace, chameleon, sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), translateParticleCode(parseEg), anonymousTypes, baseElementModel, false, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  580 */     if (extensionModel == null && !mixed) {
/*  581 */       mixed = (baseType != null && baseType.getContentType() == 4);
/*      */     }
/*      */     
/*  584 */     if (baseType != null && baseType.getContentType() != 1 && ((baseType.getContentType() == 4)) != mixed)
/*      */     {
/*      */       
/*  587 */       state.error("cos-ct-extends.1.4.2.2", (Object[])null, (XmlObject)parseTree.xgetBase());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  592 */     if (baseType != null && baseType.hasAllContent() && extensionModel != null) {
/*      */ 
/*      */       
/*  595 */       state.error("Cannot extend a type with 'all' content model", 42, (XmlObject)parseTree.xgetBase());
/*  596 */       extensionModel = null;
/*      */     } 
/*      */ 
/*      */     
/*  600 */     SchemaParticle contentModel = extendContentModel(baseContentModel, extensionModel, (XmlObject)parseTree);
/*      */ 
/*      */     
/*  603 */     boolean isAll = (contentModel != null && contentModel.getParticleType() == 1);
/*      */ 
/*      */ 
/*      */     
/*  607 */     if (baseType == null) {
/*  608 */       attrModel = new SchemaAttributeModelImpl();
/*      */     } else {
/*  610 */       attrModel = new SchemaAttributeModelImpl(baseType.getAttributeModel());
/*  611 */     }  translateAttributeModel((XmlObject)parseTree, targetNamespace, chameleon, sImpl.getAttFormDefault(), anonymousTypes, sImpl, null, attrModel, baseType, true, null);
/*      */ 
/*      */ 
/*      */     
/*  615 */     WildcardResult wcElt = summarizeEltWildcards(contentModel);
/*  616 */     WildcardResult wcAttr = summarizeAttrWildcards(attrModel);
/*      */ 
/*      */     
/*  619 */     if (contentModel != null) {
/*      */       
/*  621 */       buildStateMachine(contentModel);
/*  622 */       if (!StscState.get().noUpa() && !((SchemaParticleImpl)contentModel).isDeterministic()) {
/*  623 */         StscState.get().error("cos-nonambig", (Object[])null, (XmlObject)parseEg);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  628 */     Map elementPropertyModel = buildContentPropertyModelByQName(contentModel, sImpl);
/*      */ 
/*      */     
/*  631 */     Map attributePropertyModel = buildAttributePropertyModelByQName(attrModel, sImpl);
/*      */ 
/*      */ 
/*      */     
/*  635 */     if (contentModel == null && baseType != null && baseType.getContentType() == 2) {
/*      */ 
/*      */       
/*  638 */       complexVariety = 2;
/*  639 */       sImpl.setContentBasedOnTypeRef(baseType.getContentBasedOnType().getRef());
/*      */     } else {
/*      */       
/*  642 */       complexVariety = mixed ? 4 : ((contentModel == null) ? 1 : 3);
/*      */     } 
/*      */ 
/*      */     
/*  646 */     if (baseType == null)
/*  647 */       baseType = XmlObject.type; 
/*  648 */     sImpl.setBaseTypeRef(baseType.getRef());
/*  649 */     sImpl.setBaseDepth(((SchemaTypeImpl)baseType).getBaseDepth() + 1);
/*  650 */     sImpl.setDerivationType(2);
/*  651 */     sImpl.setComplexTypeVariety(complexVariety);
/*  652 */     sImpl.setContentModel(contentModel, attrModel, elementPropertyModel, attributePropertyModel, isAll);
/*  653 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonymousTypes));
/*  654 */     sImpl.setWildcardSummary(wcElt.typedWildcards, wcElt.hasWildcards, wcAttr.typedWildcards, wcAttr.hasWildcards);
/*      */   }
/*      */   
/*      */   static void resolveScRestriction(SchemaTypeImpl sImpl, SimpleRestrictionType parseTree) {
/*      */     SchemaType baseType;
/*      */     SchemaAttributeModelImpl attrModel;
/*  660 */     SchemaType contentType = null;
/*  661 */     StscState state = StscState.get();
/*  662 */     String targetNamespace = sImpl.getTargetNamespace();
/*  663 */     boolean chameleon = (sImpl.getChameleonNamespace() != null);
/*  664 */     List anonymousTypes = new ArrayList();
/*  665 */     if (parseTree.getSimpleType() != null) {
/*      */       
/*  667 */       LocalSimpleType typedef = parseTree.getSimpleType();
/*  668 */       SchemaTypeImpl anonType = StscTranslator.translateAnonymousSimpleType((SimpleType)typedef, targetNamespace, chameleon, sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), anonymousTypes, sImpl);
/*      */ 
/*      */ 
/*      */       
/*  672 */       contentType = anonType;
/*      */     } 
/*  674 */     if (parseTree.getBase() == null) {
/*      */       
/*  676 */       state.error("A simpleContent restriction must define a base type", 28, (XmlObject)parseTree);
/*      */       
/*  678 */       baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/*      */     else {
/*      */       
/*  682 */       if (sImpl.isRedefinition()) {
/*      */         
/*  684 */         baseType = state.findRedefinedGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), sImpl);
/*  685 */         if (baseType != null && !baseType.getName().equals(sImpl.getName()))
/*      */         {
/*  687 */           state.error("src-redefine.5b", new Object[] { "<simpleType>", QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  697 */         baseType = state.findGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), targetNamespace);
/*      */       } 
/*  699 */       if (baseType == null) {
/*      */         
/*  701 */         state.notFoundError(parseTree.getBase(), 0, (XmlObject)parseTree.xgetBase(), true);
/*      */         
/*  703 */         baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  708 */     StscResolver.resolveType((SchemaTypeImpl)baseType);
/*  709 */     if (contentType != null) {
/*  710 */       StscResolver.resolveType((SchemaTypeImpl)contentType);
/*      */     } else {
/*  712 */       contentType = baseType;
/*      */     } 
/*  714 */     if (baseType.isSimpleType()) {
/*      */ 
/*      */       
/*  717 */       state.recover("ct-props-correct.2", new Object[] { QNameHelper.pretty(baseType.getName()) }, (XmlObject)parseTree);
/*      */ 
/*      */ 
/*      */       
/*  721 */       baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/*  723 */     else if (baseType.getContentType() != 2 && contentType == null) {
/*      */ 
/*      */ 
/*      */       
/*  727 */       baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     } 
/*      */     
/*  730 */     if (baseType != null && baseType.finalRestriction())
/*      */     {
/*  732 */       state.error("derivation-ok-restriction.1", new Object[] { QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree.xgetBase());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  740 */     if (baseType == null) {
/*  741 */       attrModel = new SchemaAttributeModelImpl();
/*      */     } else {
/*  743 */       attrModel = new SchemaAttributeModelImpl(baseType.getAttributeModel());
/*  744 */     }  translateAttributeModel((XmlObject)parseTree, targetNamespace, chameleon, sImpl.getAttFormDefault(), anonymousTypes, sImpl, null, attrModel, baseType, false, null);
/*      */ 
/*      */ 
/*      */     
/*  748 */     WildcardResult wcAttr = summarizeAttrWildcards(attrModel);
/*      */ 
/*      */     
/*  751 */     Map attributePropertyModel = buildAttributePropertyModelByQName(attrModel, sImpl);
/*      */ 
/*      */     
/*  754 */     sImpl.setBaseTypeRef(baseType.getRef());
/*  755 */     sImpl.setBaseDepth(((SchemaTypeImpl)baseType).getBaseDepth() + 1);
/*  756 */     sImpl.setContentBasedOnTypeRef(contentType.getRef());
/*  757 */     sImpl.setDerivationType(1);
/*  758 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonymousTypes));
/*  759 */     sImpl.setWildcardSummary(QNameSet.EMPTY, false, wcAttr.typedWildcards, wcAttr.hasWildcards);
/*  760 */     sImpl.setComplexTypeVariety(2);
/*  761 */     sImpl.setContentModel(null, attrModel, null, attributePropertyModel, false);
/*  762 */     sImpl.setSimpleTypeVariety(contentType.getSimpleVariety());
/*  763 */     sImpl.setPrimitiveTypeRef((contentType.getPrimitiveType() == null) ? null : contentType.getPrimitiveType().getRef());
/*  764 */     switch (sImpl.getSimpleVariety()) {
/*      */       
/*      */       case 3:
/*  767 */         sImpl.setListItemTypeRef(contentType.getListItemType().getRef());
/*      */         break;
/*      */       
/*      */       case 2:
/*  771 */         sImpl.setUnionMemberTypeRefs(makeRefArray(Arrays.asList(contentType.getUnionMemberTypes())));
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  776 */     StscSimpleTypeResolver.resolveFacets(sImpl, (XmlObject)parseTree, (SchemaTypeImpl)contentType);
/*      */ 
/*      */     
/*  779 */     StscSimpleTypeResolver.resolveFundamentalFacets(sImpl);
/*      */   }
/*      */ 
/*      */   
/*      */   static void resolveScExtension(SchemaTypeImpl sImpl, SimpleExtensionType parseTree) {
/*      */     SchemaType baseType;
/*  785 */     StscState state = StscState.get();
/*  786 */     String targetNamespace = sImpl.getTargetNamespace();
/*  787 */     boolean chameleon = (sImpl.getChameleonNamespace() != null);
/*  788 */     if (parseTree.getBase() == null) {
/*      */       
/*  790 */       state.error("A simpleContent extension must define a base type", 28, (XmlObject)parseTree);
/*      */       
/*  792 */       baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/*      */     else {
/*      */       
/*  796 */       if (sImpl.isRedefinition()) {
/*      */         
/*  798 */         baseType = state.findRedefinedGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), sImpl);
/*  799 */         if (baseType != null && !baseType.getName().equals(sImpl.getName()))
/*      */         {
/*  801 */           state.error("src-redefine.5b", new Object[] { "<simpleType>", QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  811 */         baseType = state.findGlobalType(parseTree.getBase(), sImpl.getChameleonNamespace(), targetNamespace);
/*      */       } 
/*  813 */       if (baseType == null) {
/*      */         
/*  815 */         state.notFoundError(parseTree.getBase(), 0, (XmlObject)parseTree.xgetBase(), true);
/*      */         
/*  817 */         baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  822 */     StscResolver.resolveType((SchemaTypeImpl)baseType);
/*      */     
/*  824 */     if (!baseType.isSimpleType() && baseType.getContentType() != 2) {
/*      */ 
/*      */       
/*  827 */       state.error("src-ct.2", new Object[] { QNameHelper.pretty(baseType.getName()) }, (XmlObject)parseTree);
/*      */ 
/*      */ 
/*      */       
/*  831 */       baseType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     } 
/*      */     
/*  834 */     if (baseType != null && baseType.finalExtension())
/*      */     {
/*  836 */       state.error("cos-ct-extends.1.1", new Object[] { QNameHelper.pretty(baseType.getName()), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseTree.xgetBase());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  842 */     resolveScExtensionPart2(sImpl, baseType, (ExtensionType)parseTree, targetNamespace, chameleon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void resolveScExtensionPart2(SchemaTypeImpl sImpl, SchemaType baseType, ExtensionType parseTree, String targetNamespace, boolean chameleon) {
/*  849 */     List anonymousTypes = new ArrayList();
/*      */     
/*  851 */     SchemaAttributeModelImpl attrModel = new SchemaAttributeModelImpl(baseType.getAttributeModel());
/*  852 */     translateAttributeModel((XmlObject)parseTree, targetNamespace, chameleon, sImpl.getAttFormDefault(), anonymousTypes, sImpl, null, attrModel, baseType, true, null);
/*      */ 
/*      */     
/*  855 */     WildcardResult wcAttr = summarizeAttrWildcards(attrModel);
/*      */ 
/*      */     
/*  858 */     Map attributePropertyModel = buildAttributePropertyModelByQName(attrModel, sImpl);
/*      */ 
/*      */     
/*  861 */     sImpl.setBaseTypeRef(baseType.getRef());
/*  862 */     sImpl.setBaseDepth(((SchemaTypeImpl)baseType).getBaseDepth() + 1);
/*  863 */     sImpl.setContentBasedOnTypeRef(baseType.getRef());
/*  864 */     sImpl.setDerivationType(2);
/*  865 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonymousTypes));
/*  866 */     sImpl.setWildcardSummary(QNameSet.EMPTY, false, wcAttr.typedWildcards, wcAttr.hasWildcards);
/*  867 */     sImpl.setComplexTypeVariety(2);
/*  868 */     sImpl.setContentModel(null, attrModel, null, attributePropertyModel, false);
/*  869 */     sImpl.setSimpleTypeVariety(baseType.getSimpleVariety());
/*  870 */     sImpl.setPrimitiveTypeRef((baseType.getPrimitiveType() == null) ? null : baseType.getPrimitiveType().getRef());
/*  871 */     switch (sImpl.getSimpleVariety()) {
/*      */       
/*      */       case 3:
/*  874 */         sImpl.setListItemTypeRef(baseType.getListItemType().getRef());
/*      */         break;
/*      */       
/*      */       case 2:
/*  878 */         sImpl.setUnionMemberTypeRefs(makeRefArray(Arrays.asList(baseType.getUnionMemberTypes())));
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  883 */     StscSimpleTypeResolver.resolveFacets(sImpl, null, (SchemaTypeImpl)baseType);
/*      */ 
/*      */     
/*  886 */     StscSimpleTypeResolver.resolveFundamentalFacets(sImpl);
/*      */   }
/*      */   
/*      */   static class WildcardResult { QNameSet typedWildcards;
/*      */     boolean hasWildcards;
/*      */     
/*      */     WildcardResult(QNameSet typedWildcards, boolean hasWildcards) {
/*  893 */       this.typedWildcards = typedWildcards;
/*  894 */       this.hasWildcards = hasWildcards;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static WildcardResult summarizeAttrWildcards(SchemaAttributeModel attrModel) {
/*  902 */     if (attrModel.getWildcardProcess() == 0)
/*  903 */       return new WildcardResult(QNameSet.EMPTY, false); 
/*  904 */     if (attrModel.getWildcardProcess() == 3)
/*  905 */       return new WildcardResult(QNameSet.EMPTY, true); 
/*  906 */     return new WildcardResult(attrModel.getWildcardSet(), true);
/*      */   } static WildcardResult summarizeEltWildcards(SchemaParticle contentModel) {
/*      */     QNameSetBuilder set;
/*      */     boolean hasWildcards;
/*      */     int i;
/*  911 */     if (contentModel == null)
/*      */     {
/*  913 */       return new WildcardResult(QNameSet.EMPTY, false);
/*      */     }
/*      */     
/*  916 */     switch (contentModel.getParticleType()) {
/*      */       
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*  921 */         set = new QNameSetBuilder();
/*  922 */         hasWildcards = false;
/*  923 */         for (i = 0; i < contentModel.countOfParticleChild(); i++) {
/*      */           
/*  925 */           WildcardResult inner = summarizeEltWildcards(contentModel.getParticleChild(i));
/*  926 */           set.addAll((QNameSetSpecification)inner.typedWildcards);
/*  927 */           hasWildcards |= inner.hasWildcards;
/*      */         } 
/*  929 */         return new WildcardResult(set.toQNameSet(), hasWildcards);
/*      */       case 5:
/*  931 */         return new WildcardResult((contentModel.getWildcardProcess() == 3) ? QNameSet.EMPTY : contentModel.getWildcardSet(), true);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  937 */     return new WildcardResult(QNameSet.EMPTY, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void translateAttributeModel(XmlObject parseTree, String targetNamespace, boolean chameleon, String formDefault, List anonymousTypes, SchemaType outerType, Set seenAttributes, SchemaAttributeModelImpl result, SchemaType baseType, boolean extension, SchemaAttributeGroupImpl redefinitionFor) {
/*  948 */     StscState state = StscState.get();
/*  949 */     if (seenAttributes == null)
/*  950 */       seenAttributes = new HashSet(); 
/*  951 */     boolean seenWildcard = false;
/*  952 */     boolean seenRedefinition = false;
/*  953 */     SchemaAttributeModel baseModel = null;
/*  954 */     if (baseType != null) {
/*  955 */       baseModel = baseType.getAttributeModel();
/*      */     }
/*  957 */     XmlCursor cur = parseTree.newCursor();
/*      */     boolean more;
/*  959 */     for (more = cur.toFirstChild(); more; more = cur.toNextSibling()) {
/*      */       Attribute xsdattr; Wildcard xsdwc; AttributeGroupRef xsdag; SchemaLocalAttribute sAttr; NamespaceList nsList; QName ref; String nsText; SchemaAttributeGroupImpl group; QNameSet wcset; String subTargetNamespace; int wcprocess; SchemaAttributeGroupImpl nestedRedefinitionFor;
/*  961 */       switch (translateAttributeCode(cur.getName())) {
/*      */ 
/*      */         
/*      */         case 100:
/*  965 */           xsdattr = (Attribute)cur.getObject();
/*      */           
/*  967 */           sAttr = StscTranslator.translateAttribute(xsdattr, targetNamespace, formDefault, chameleon, anonymousTypes, outerType, baseModel, true);
/*  968 */           if (sAttr == null) {
/*      */             break;
/*      */           }
/*  971 */           if (seenAttributes.contains(sAttr.getName())) {
/*      */             
/*  973 */             state.error("ct-props-correct.4", new Object[] { QNameHelper.pretty(sAttr.getName()), QNameHelper.pretty(outerType.getName()) }, (XmlObject)xsdattr.xgetName());
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  979 */           seenAttributes.add(sAttr.getName());
/*      */           
/*  981 */           if (baseModel != null) {
/*      */             
/*  983 */             SchemaLocalAttribute baseAttr = baseModel.getAttribute(sAttr.getName());
/*  984 */             if (baseAttr == null) {
/*      */               
/*  986 */               if (!extension)
/*      */               {
/*  988 */                 if (!baseModel.getWildcardSet().contains(sAttr.getName())) {
/*  989 */                   state.error("derivation-ok-restriction.2.2", new Object[] { QNameHelper.pretty(sAttr.getName()), QNameHelper.pretty(outerType.getName()) }, (XmlObject)xsdattr);
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/*      */             }
/*  995 */             else if (extension) {
/*      */ 
/*      */               
/*  998 */               if (sAttr.getUse() == 1) {
/*  999 */                 state.error("An extension cannot prohibit an attribute from the base type; use restriction instead.", 37, (XmlObject)xsdattr.xgetUse());
/*      */               
/*      */               }
/*      */             }
/* 1003 */             else if (sAttr.getUse() != 3) {
/*      */               
/* 1005 */               if (baseAttr.getUse() == 3) {
/* 1006 */                 state.error("derivation-ok-restriction.2.1.1", new Object[] { QNameHelper.pretty(sAttr.getName()), QNameHelper.pretty(outerType.getName()) }, (XmlObject)xsdattr);
/*      */               }
/*      */               
/* 1009 */               if (sAttr.getUse() == 1) {
/* 1010 */                 result.removeProhibitedAttribute(sAttr.getName());
/*      */               }
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 1016 */           if (sAttr.getUse() != 1) {
/*      */             
/* 1018 */             result.addAttribute(sAttr);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */ 
/*      */             
/* 1027 */             SchemaType attrType = sAttr.getType();
/* 1028 */             if (anonymousTypes != null && anonymousTypes.contains(attrType))
/*      */             {
/* 1030 */               anonymousTypes.remove(attrType);
/*      */             }
/*      */           } 
/*      */           
/* 1034 */           if (sAttr.getDefaultText() != null && !sAttr.isFixed())
/*      */           {
/* 1036 */             if (sAttr.getUse() != 2) {
/* 1037 */               state.error("src-attribute.2", new Object[] { QNameHelper.pretty(sAttr.getName()) }, (XmlObject)xsdattr);
/*      */             }
/*      */           }
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 102:
/* 1046 */           xsdwc = (Wildcard)cur.getObject();
/* 1047 */           if (seenWildcard) {
/*      */ 
/*      */             
/* 1050 */             state.error("Only one attribute wildcard allowed", 38, (XmlObject)xsdwc);
/*      */             break;
/*      */           } 
/* 1053 */           seenWildcard = true;
/* 1054 */           nsList = xsdwc.xgetNamespace();
/*      */           
/* 1056 */           if (nsList == null) {
/* 1057 */             nsText = "##any";
/*      */           } else {
/* 1059 */             nsText = nsList.getStringValue();
/* 1060 */           }  wcset = QNameSet.forWildcardNamespaceString(nsText, targetNamespace);
/*      */           
/* 1062 */           if (baseModel != null && !extension) {
/*      */             
/* 1064 */             if (baseModel.getWildcardSet() == null) {
/*      */               
/* 1066 */               state.error("derivation-ok-restriction.4.1", (Object[])null, (XmlObject)xsdwc);
/*      */               break;
/*      */             } 
/* 1069 */             if (!baseModel.getWildcardSet().containsAll((QNameSetSpecification)wcset)) {
/*      */               
/* 1071 */               state.error("derivation-ok-restriction.4.2", new Object[] { nsText }, (XmlObject)xsdwc);
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */           
/* 1077 */           wcprocess = translateWildcardProcess(xsdwc.xgetProcessContents());
/* 1078 */           if (result.getWildcardProcess() == 0) {
/*      */             
/* 1080 */             result.setWildcardSet(wcset);
/* 1081 */             result.setWildcardProcess(wcprocess);
/*      */             
/*      */             break;
/*      */           } 
/* 1085 */           if (extension) {
/*      */             
/* 1087 */             result.setWildcardSet(wcset.union((QNameSetSpecification)result.getWildcardSet()));
/* 1088 */             result.setWildcardProcess(wcprocess);
/*      */             
/*      */             break;
/*      */           } 
/* 1092 */           result.setWildcardSet(wcset.intersect((QNameSetSpecification)result.getWildcardSet()));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 101:
/* 1100 */           xsdag = (AttributeGroupRef)cur.getObject();
/* 1101 */           ref = xsdag.getRef();
/* 1102 */           if (ref == null) {
/*      */ 
/*      */             
/* 1105 */             state.error("Attribute group reference must have a ref attribute", 39, (XmlObject)xsdag);
/*      */             
/*      */             break;
/*      */           } 
/* 1109 */           if (redefinitionFor != null) {
/*      */             
/* 1111 */             group = state.findRedefinedAttributeGroup(ref, chameleon ? targetNamespace : null, redefinitionFor);
/* 1112 */             if (group != null && redefinitionFor.getName().equals(group.getName()))
/*      */             {
/*      */               
/* 1115 */               if (seenRedefinition) {
/* 1116 */                 state.error("src-redefine.7.1", new Object[] { QNameHelper.pretty(redefinitionFor.getName()) }, (XmlObject)xsdag);
/*      */               }
/* 1118 */               seenRedefinition = true;
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1123 */             group = state.findAttributeGroup(ref, chameleon ? targetNamespace : null, targetNamespace);
/*      */           } 
/* 1125 */           if (group == null) {
/*      */             
/* 1127 */             state.notFoundError(ref, 4, (XmlObject)xsdag.xgetRef(), true);
/*      */             break;
/*      */           } 
/* 1130 */           if (state.isProcessing(group)) {
/*      */             
/* 1132 */             state.error("src-attribute_group.3", new Object[] { QNameHelper.pretty(group.getName()) }, group.getParseObject());
/*      */             
/*      */             break;
/*      */           } 
/* 1136 */           subTargetNamespace = targetNamespace;
/* 1137 */           if (group.getTargetNamespace() != null) {
/*      */             
/* 1139 */             subTargetNamespace = group.getTargetNamespace();
/* 1140 */             chameleon = (group.getChameleonNamespace() != null);
/*      */           } 
/*      */           
/* 1143 */           state.startProcessing(group);
/* 1144 */           nestedRedefinitionFor = null;
/* 1145 */           if (group.isRedefinition())
/* 1146 */             nestedRedefinitionFor = group; 
/* 1147 */           translateAttributeModel(group.getParseObject(), subTargetNamespace, chameleon, group.getFormDefault(), anonymousTypes, outerType, seenAttributes, result, baseType, extension, nestedRedefinitionFor);
/*      */ 
/*      */ 
/*      */           
/* 1151 */           state.finishProcessing(group);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1162 */     if (!extension && !seenWildcard) {
/*      */       
/* 1164 */       result.setWildcardSet(null);
/* 1165 */       result.setWildcardProcess(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SchemaParticle extendContentModel(SchemaParticle baseContentModel, SchemaParticle extendedContentModel, XmlObject parseTree) {
/* 1174 */     if (extendedContentModel == null) {
/* 1175 */       return baseContentModel;
/*      */     }
/*      */     
/* 1178 */     if (baseContentModel == null) {
/* 1179 */       return extendedContentModel;
/*      */     }
/*      */     
/* 1182 */     SchemaParticleImpl sPart = new SchemaParticleImpl();
/* 1183 */     sPart.setParticleType(3);
/*      */     
/* 1185 */     List accumulate = new ArrayList();
/* 1186 */     addMinusPointlessParticles(accumulate, baseContentModel, 3);
/* 1187 */     addMinusPointlessParticles(accumulate, extendedContentModel, 3);
/* 1188 */     sPart.setMinOccurs(BigInteger.ONE);
/* 1189 */     sPart.setMaxOccurs(BigInteger.ONE);
/* 1190 */     sPart.setParticleChildren((SchemaParticle[])accumulate.toArray((Object[])new SchemaParticle[accumulate.size()]));
/*      */ 
/*      */     
/* 1193 */     return filterPointlessParticlesAndVerifyAllParticles(sPart, parseTree);
/*      */   }
/*      */ 
/*      */   
/*      */   static BigInteger extractMinOccurs(XmlNonNegativeInteger nni) {
/* 1198 */     if (nni == null)
/* 1199 */       return BigInteger.ONE; 
/* 1200 */     BigInteger result = nni.getBigIntegerValue();
/* 1201 */     if (result == null)
/* 1202 */       return BigInteger.ONE; 
/* 1203 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static BigInteger extractMaxOccurs(AllNNI allNNI) {
/* 1208 */     if (allNNI == null) {
/* 1209 */       return BigInteger.ONE;
/*      */     }
/* 1211 */     if (allNNI.instanceType().getPrimitiveType().getBuiltinTypeCode() == 11) {
/* 1212 */       return ((XmlInteger)allNNI).getBigIntegerValue();
/*      */     }
/* 1214 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static class RedefinitionForGroup
/*      */   {
/*      */     private SchemaModelGroupImpl group;
/*      */     private boolean seenRedefinition = false;
/*      */     
/*      */     public RedefinitionForGroup(SchemaModelGroupImpl group) {
/* 1224 */       this.group = group;
/*      */     }
/*      */ 
/*      */     
/*      */     public SchemaModelGroupImpl getGroup() {
/* 1229 */       return this.group;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isSeenRedefinition() {
/* 1234 */       return this.seenRedefinition;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSeenRedefinition(boolean seenRedefinition) {
/* 1239 */       this.seenRedefinition = seenRedefinition;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SchemaParticle translateContentModel(SchemaType outerType, XmlObject parseTree, String targetNamespace, boolean chameleon, String elemFormDefault, String attFormDefault, int particleCode, List anonymousTypes, Map elementModel, boolean allowElt, RedefinitionForGroup redefinitionFor) {
/*      */     Group group1;
/*      */     BigInteger minOccurs, maxOccurs;
/*      */     SchemaParticleImpl sPart;
/* 1250 */     if (parseTree == null || particleCode == 0) {
/* 1251 */       return null;
/*      */     }
/* 1253 */     StscState state = StscState.get();
/*      */ 
/*      */ 
/*      */     
/* 1257 */     assert particleCode != 0;
/*      */     
/* 1259 */     boolean hasChildren = false;
/*      */ 
/*      */     
/* 1262 */     SchemaModelGroupImpl group = null;
/*      */ 
/*      */ 
/*      */     
/* 1266 */     if (particleCode == 4) {
/*      */       
/* 1268 */       if (!allowElt) {
/* 1269 */         state.error("Must be a sequence, choice or all here", 32, parseTree);
/*      */       }
/*      */ 
/*      */       
/* 1273 */       LocalElement parseElt = (LocalElement)parseTree;
/* 1274 */       sPart = StscTranslator.translateElement((Element)parseElt, targetNamespace, chameleon, elemFormDefault, attFormDefault, anonymousTypes, outerType);
/*      */       
/* 1276 */       if (sPart == null)
/* 1277 */         return null; 
/* 1278 */       minOccurs = extractMinOccurs(parseElt.xgetMinOccurs());
/* 1279 */       maxOccurs = extractMaxOccurs(parseElt.xgetMaxOccurs());
/*      */       
/* 1281 */       SchemaType oldType = (SchemaType)elementModel.get(sPart.getName());
/* 1282 */       if (oldType == null)
/*      */       {
/* 1284 */         elementModel.put(sPart.getName(), sPart.getType());
/*      */       }
/* 1286 */       else if (!sPart.getType().equals(oldType))
/*      */       {
/* 1288 */         state.error("cos-element-consistent", new Object[] { QNameHelper.pretty(sPart.getName()) }, parseTree);
/* 1289 */         return null;
/*      */       }
/*      */     
/* 1292 */     } else if (particleCode == 5) {
/*      */       QNameSet wcset;
/* 1294 */       if (!allowElt)
/* 1295 */         state.error("Must be a sequence, choice or all here", 32, parseTree); 
/* 1296 */       AnyDocument.Any parseAny = (AnyDocument.Any)parseTree;
/* 1297 */       sPart = new SchemaParticleImpl();
/* 1298 */       sPart.setParticleType(5);
/*      */       
/* 1300 */       NamespaceList nslist = parseAny.xgetNamespace();
/* 1301 */       if (nslist == null) {
/* 1302 */         wcset = QNameSet.ALL;
/*      */       } else {
/* 1304 */         wcset = QNameSet.forWildcardNamespaceString(nslist.getStringValue(), targetNamespace);
/* 1305 */       }  sPart.setWildcardSet(wcset);
/* 1306 */       sPart.setWildcardProcess(translateWildcardProcess(parseAny.xgetProcessContents()));
/* 1307 */       minOccurs = extractMinOccurs(parseAny.xgetMinOccurs());
/* 1308 */       maxOccurs = extractMaxOccurs(parseAny.xgetMaxOccurs());
/*      */     }
/*      */     else {
/*      */       
/* 1312 */       Group parseGroup = (Group)parseTree;
/* 1313 */       sPart = new SchemaParticleImpl();
/*      */ 
/*      */       
/* 1316 */       minOccurs = extractMinOccurs(parseGroup.xgetMinOccurs());
/* 1317 */       maxOccurs = extractMaxOccurs(parseGroup.xgetMaxOccurs());
/*      */       
/* 1319 */       if (particleCode == 100) {
/*      */         
/* 1321 */         QName ref = parseGroup.getRef();
/* 1322 */         if (ref == null) {
/*      */ 
/*      */           
/* 1325 */           state.error("Group reference must have a ref attribute", 33, parseTree);
/* 1326 */           return null;
/*      */         } 
/*      */         
/* 1329 */         if (redefinitionFor != null) {
/*      */           
/* 1331 */           group = state.findRedefinedModelGroup(ref, chameleon ? targetNamespace : null, redefinitionFor.getGroup());
/* 1332 */           if (group != null && group.getName().equals(redefinitionFor.getGroup().getName()))
/*      */           {
/* 1334 */             if (redefinitionFor.isSeenRedefinition()) {
/* 1335 */               state.error("src-redefine.6.1.1", new Object[] { QNameHelper.pretty(group.getName()) }, parseTree);
/*      */             }
/* 1337 */             if (!BigInteger.ONE.equals(maxOccurs) || !BigInteger.ONE.equals(minOccurs)) {
/* 1338 */               state.error("src-redefine.6.1.2", new Object[] { QNameHelper.pretty(group.getName()) }, parseTree);
/*      */             }
/* 1340 */             redefinitionFor.setSeenRedefinition(true);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1345 */           group = state.findModelGroup(ref, chameleon ? targetNamespace : null, targetNamespace);
/*      */         } 
/* 1347 */         if (group == null) {
/*      */           
/* 1349 */           state.notFoundError(ref, 6, (XmlObject)((Group)parseTree).xgetRef(), true);
/* 1350 */           return null;
/*      */         } 
/* 1352 */         if (state.isProcessing(group)) {
/*      */           
/* 1354 */           state.error("mg-props-correct.2", new Object[] { QNameHelper.pretty(group.getName()) }, group.getParseObject());
/*      */           
/* 1356 */           return null;
/*      */         } 
/*      */ 
/*      */         
/* 1360 */         XmlCursor cur = group.getParseObject().newCursor(); boolean more;
/* 1361 */         for (more = cur.toFirstChild(); more; more = cur.toNextSibling()) {
/*      */           
/* 1363 */           particleCode = translateParticleCode(cur.getName());
/* 1364 */           if (particleCode != 0) {
/*      */             
/* 1366 */             group1 = parseGroup = (Group)cur.getObject();
/*      */             break;
/*      */           } 
/*      */         } 
/* 1370 */         if (particleCode == 0) {
/*      */ 
/*      */           
/* 1373 */           state.error("Model group " + QNameHelper.pretty(group.getName()) + " is empty", 32, group.getParseObject());
/* 1374 */           return null;
/*      */         } 
/* 1376 */         if (particleCode != 1 && particleCode != 3 && particleCode != 2)
/*      */         {
/*      */           
/* 1379 */           state.error("Model group " + QNameHelper.pretty(group.getName()) + " is not a sequence, all, or choice", 32, group.getParseObject());
/*      */         }
/*      */         
/* 1382 */         String newTargetNamespace = group.getTargetNamespace();
/* 1383 */         if (newTargetNamespace != null)
/* 1384 */           targetNamespace = newTargetNamespace; 
/* 1385 */         elemFormDefault = group.getElemFormDefault();
/* 1386 */         attFormDefault = group.getAttFormDefault();
/* 1387 */         chameleon = (group.getChameleonNamespace() != null);
/*      */       } 
/*      */       
/* 1390 */       switch (particleCode) {
/*      */         
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/* 1395 */           sPart.setParticleType(particleCode);
/* 1396 */           hasChildren = true;
/*      */           break;
/*      */         
/*      */         default:
/*      */           assert false;
/* 1401 */           throw new IllegalStateException();
/*      */       } 
/*      */     
/*      */     } 
/* 1405 */     if (maxOccurs != null && minOccurs.compareTo(maxOccurs) > 0) {
/*      */       
/* 1407 */       state.error("p-props-correct.2.1", (Object[])null, (XmlObject)group1);
/* 1408 */       maxOccurs = minOccurs;
/*      */     } 
/*      */     
/* 1411 */     if (maxOccurs != null && maxOccurs.compareTo(BigInteger.ONE) < 0) {
/*      */       
/* 1413 */       state.warning("p-props-correct.2.2", (Object[])null, (XmlObject)group1);
/*      */ 
/*      */       
/* 1416 */       anonymousTypes.remove(sPart.getType());
/* 1417 */       return null;
/*      */     } 
/*      */     
/* 1420 */     sPart.setMinOccurs(minOccurs);
/* 1421 */     sPart.setMaxOccurs(maxOccurs);
/*      */     
/* 1423 */     if (group != null) {
/*      */       
/* 1425 */       state.startProcessing(group);
/* 1426 */       redefinitionFor = null;
/* 1427 */       if (group.isRedefinition()) {
/* 1428 */         redefinitionFor = new RedefinitionForGroup(group);
/*      */       }
/*      */     } 
/* 1431 */     if (hasChildren) {
/*      */       
/* 1433 */       XmlCursor cur = group1.newCursor();
/* 1434 */       List accumulate = new ArrayList(); boolean more;
/* 1435 */       for (more = cur.toFirstChild(); more; more = cur.toNextSibling()) {
/*      */         
/* 1437 */         int code = translateParticleCode(cur.getName());
/* 1438 */         if (code != 0)
/*      */         {
/* 1440 */           addMinusPointlessParticles(accumulate, translateContentModel(outerType, cur.getObject(), targetNamespace, chameleon, elemFormDefault, attFormDefault, code, anonymousTypes, elementModel, true, redefinitionFor), sPart.getParticleType());
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1447 */       sPart.setParticleChildren((SchemaParticle[])accumulate.toArray((Object[])new SchemaParticle[accumulate.size()]));
/*      */       
/* 1449 */       cur.dispose();
/*      */     } 
/*      */ 
/*      */     
/* 1453 */     SchemaParticle result = filterPointlessParticlesAndVerifyAllParticles(sPart, (XmlObject)group1);
/*      */     
/* 1455 */     if (group != null)
/*      */     {
/* 1457 */       state.finishProcessing(group);
/*      */     }
/*      */     
/* 1460 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static int translateWildcardProcess(Wildcard.ProcessContents process) {
/* 1465 */     if (process == null) {
/* 1466 */       return 1;
/*      */     }
/* 1468 */     String processValue = process.getStringValue();
/*      */     
/* 1470 */     if ("lax".equals(processValue)) {
/* 1471 */       return 2;
/*      */     }
/* 1473 */     if ("skip".equals(processValue)) {
/* 1474 */       return 3;
/*      */     }
/* 1476 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   static SchemaParticle filterPointlessParticlesAndVerifyAllParticles(SchemaParticle part, XmlObject parseTree) {
/* 1481 */     if (part.getMaxOccurs() != null && part.getMaxOccurs().signum() == 0) {
/* 1482 */       return null;
/*      */     }
/* 1484 */     switch (part.getParticleType()) {
/*      */       
/*      */       case 1:
/*      */       case 3:
/* 1488 */         if ((part.getParticleChildren()).length == 0)
/* 1489 */           return null; 
/* 1490 */         if (part.isSingleton() && part.countOfParticleChild() == 1) {
/* 1491 */           return part.getParticleChild(0);
/*      */         }
/*      */         break;
/*      */       case 2:
/* 1495 */         if ((part.getParticleChildren()).length == 0 && part.getMinOccurs().compareTo(BigInteger.ZERO) == 0)
/*      */         {
/* 1497 */           return null; } 
/* 1498 */         if (part.isSingleton() && part.countOfParticleChild() == 1) {
/* 1499 */           return part.getParticleChild(0);
/*      */         }
/*      */         break;
/*      */       case 4:
/*      */       case 5:
/* 1504 */         return part;
/*      */       
/*      */       default:
/*      */         assert false;
/* 1508 */         throw new IllegalStateException();
/*      */     } 
/*      */     
/* 1511 */     boolean isAll = (part.getParticleType() == 1);
/*      */     
/* 1513 */     if (isAll)
/*      */     {
/*      */       
/* 1516 */       if (part.getMaxOccurs() == null || part.getMaxOccurs().compareTo(BigInteger.ONE) > 0)
/*      */       {
/*      */ 
/*      */         
/* 1520 */         StscState.get().error("cos-all-limited.1.2a", (Object[])null, parseTree);
/*      */       }
/*      */     }
/*      */     
/* 1524 */     for (int i = 0; i < part.countOfParticleChild(); i++) {
/*      */       
/* 1526 */       SchemaParticle child = part.getParticleChild(i);
/* 1527 */       if (child.getParticleType() == 1) {
/*      */ 
/*      */ 
/*      */         
/* 1531 */         StscState.get().error("cos-all-limited.1.2b", (Object[])null, parseTree);
/*      */       }
/* 1533 */       else if (isAll && (child.getParticleType() != 4 || child.getMaxOccurs() == null || child.getMaxOccurs().compareTo(BigInteger.ONE) > 0)) {
/*      */ 
/*      */ 
/*      */         
/* 1537 */         StscState.get().error("cos-all-limited.2", (Object[])null, parseTree);
/*      */       } 
/*      */     } 
/*      */     
/* 1541 */     return part;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void addMinusPointlessParticles(List list, SchemaParticle part, int parentParticleType) {
/* 1547 */     if (part == null) {
/*      */       return;
/*      */     }
/* 1550 */     switch (part.getParticleType()) {
/*      */       
/*      */       case 3:
/* 1553 */         if (parentParticleType == 3 && part.isSingleton()) {
/*      */ 
/*      */           
/* 1556 */           list.addAll(Arrays.asList(part.getParticleChildren()));
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 2:
/* 1562 */         if (parentParticleType == 2 && part.isSingleton()) {
/*      */ 
/*      */           
/* 1565 */           list.addAll(Arrays.asList(part.getParticleChildren()));
/*      */           return;
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1573 */     list.add(part);
/*      */   }
/*      */ 
/*      */   
/*      */   static Map buildAttributePropertyModelByQName(SchemaAttributeModel attrModel, SchemaType owner) {
/* 1578 */     Map result = new LinkedHashMap();
/* 1579 */     SchemaLocalAttribute[] attruses = attrModel.getAttributes();
/*      */     
/* 1581 */     for (int i = 0; i < attruses.length; i++) {
/* 1582 */       result.put(attruses[i].getName(), buildUseProperty((SchemaField)attruses[i], owner));
/*      */     }
/* 1584 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static Map buildContentPropertyModelByQName(SchemaParticle part, SchemaType owner) {
/* 1589 */     if (part == null) {
/* 1590 */       return Collections.EMPTY_MAP;
/*      */     }
/* 1592 */     boolean asSequence = false;
/* 1593 */     Map model = null;
/*      */     
/* 1595 */     switch (part.getParticleType()) {
/*      */       
/*      */       case 1:
/*      */       case 3:
/* 1599 */         asSequence = true;
/*      */         break;
/*      */       case 2:
/* 1602 */         asSequence = false;
/*      */         break;
/*      */       case 4:
/* 1605 */         model = buildElementPropertyModel((SchemaLocalElement)part, owner);
/*      */         break;
/*      */       case 5:
/* 1608 */         model = Collections.EMPTY_MAP;
/*      */         break;
/*      */       default:
/*      */         assert false;
/* 1612 */         throw new IllegalStateException();
/*      */     } 
/*      */     
/* 1615 */     if (model == null) {
/*      */ 
/*      */       
/* 1618 */       model = new LinkedHashMap();
/* 1619 */       SchemaParticle[] children = part.getParticleChildren();
/*      */       
/* 1621 */       for (int i = 0; i < children.length; i++) {
/*      */ 
/*      */         
/* 1624 */         Map childModel = buildContentPropertyModelByQName(children[i], owner);
/*      */         
/* 1626 */         for (Iterator iterator = childModel.values().iterator(); iterator.hasNext(); ) {
/*      */           
/* 1628 */           SchemaProperty iProp = iterator.next();
/* 1629 */           SchemaPropertyImpl oProp = (SchemaPropertyImpl)model.get(iProp.getName());
/* 1630 */           if (oProp == null) {
/*      */             
/* 1632 */             if (!asSequence)
/* 1633 */               ((SchemaPropertyImpl)iProp).setMinOccurs(BigInteger.ZERO); 
/* 1634 */             model.put(iProp.getName(), iProp);
/*      */             
/*      */             continue;
/*      */           } 
/* 1638 */           assert oProp.getType().equals(iProp.getType());
/*      */           
/* 1640 */           mergeProperties(oProp, iProp, asSequence);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1645 */       BigInteger min = part.getMinOccurs();
/* 1646 */       BigInteger max = part.getMaxOccurs();
/*      */       
/* 1648 */       for (Iterator j = model.values().iterator(); j.hasNext(); ) {
/*      */         
/* 1650 */         SchemaProperty oProp = j.next();
/* 1651 */         BigInteger minOccurs = oProp.getMinOccurs();
/* 1652 */         BigInteger maxOccurs = oProp.getMaxOccurs();
/*      */         
/* 1654 */         minOccurs = minOccurs.multiply(min);
/* 1655 */         if (max != null && max.equals(BigInteger.ZERO)) {
/* 1656 */           maxOccurs = BigInteger.ZERO;
/* 1657 */         } else if (maxOccurs != null && !maxOccurs.equals(BigInteger.ZERO)) {
/* 1658 */           maxOccurs = (max == null) ? null : maxOccurs.multiply(max);
/*      */         } 
/* 1660 */         ((SchemaPropertyImpl)oProp).setMinOccurs(minOccurs);
/* 1661 */         ((SchemaPropertyImpl)oProp).setMaxOccurs(maxOccurs);
/*      */       } 
/*      */     } 
/*      */     
/* 1665 */     return model;
/*      */   }
/*      */ 
/*      */   
/*      */   static Map buildElementPropertyModel(SchemaLocalElement epart, SchemaType owner) {
/* 1670 */     Map result = new HashMap(1);
/*      */     
/* 1672 */     SchemaProperty sProp = buildUseProperty((SchemaField)epart, owner);
/* 1673 */     result.put(sProp.getName(), sProp);
/* 1674 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static SchemaProperty buildUseProperty(SchemaField use, SchemaType owner) {
/* 1679 */     SchemaPropertyImpl sPropImpl = new SchemaPropertyImpl();
/* 1680 */     sPropImpl.setName(use.getName());
/* 1681 */     sPropImpl.setContainerTypeRef(owner.getRef());
/* 1682 */     sPropImpl.setTypeRef(use.getType().getRef());
/* 1683 */     sPropImpl.setAttribute(use.isAttribute());
/* 1684 */     sPropImpl.setDefault(use.isDefault() ? 2 : 0);
/* 1685 */     sPropImpl.setFixed(use.isFixed() ? 2 : 0);
/* 1686 */     sPropImpl.setNillable(use.isNillable() ? 2 : 0);
/* 1687 */     sPropImpl.setDefaultText(use.getDefaultText());
/* 1688 */     sPropImpl.setMinOccurs(use.getMinOccurs());
/* 1689 */     sPropImpl.setMaxOccurs(use.getMaxOccurs());
/*      */     
/* 1691 */     if (use instanceof SchemaLocalElementImpl) {
/*      */       
/* 1693 */       SchemaLocalElementImpl elt = (SchemaLocalElementImpl)use;
/* 1694 */       sPropImpl.setAcceptedNames(elt.acceptedStartNames());
/*      */     } 
/*      */     
/* 1697 */     return sPropImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void mergeProperties(SchemaPropertyImpl into, SchemaProperty from, boolean asSequence) {
/* 1703 */     BigInteger minOccurs = into.getMinOccurs();
/* 1704 */     BigInteger maxOccurs = into.getMaxOccurs();
/* 1705 */     if (asSequence) {
/*      */       
/* 1707 */       minOccurs = minOccurs.add(from.getMinOccurs());
/* 1708 */       if (maxOccurs != null) {
/* 1709 */         maxOccurs = (from.getMaxOccurs() == null) ? null : maxOccurs.add(from.getMaxOccurs());
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1714 */       minOccurs = minOccurs.min(from.getMinOccurs());
/* 1715 */       if (maxOccurs != null) {
/* 1716 */         maxOccurs = (from.getMaxOccurs() == null) ? null : maxOccurs.max(from.getMaxOccurs());
/*      */       }
/*      */     } 
/* 1719 */     into.setMinOccurs(minOccurs);
/* 1720 */     into.setMaxOccurs(maxOccurs);
/*      */ 
/*      */     
/* 1723 */     if (from.hasNillable() != into.hasNillable())
/* 1724 */       into.setNillable(1); 
/* 1725 */     if (from.hasDefault() != into.hasDefault())
/* 1726 */       into.setDefault(1); 
/* 1727 */     if (from.hasFixed() != into.hasFixed()) {
/* 1728 */       into.setFixed(1);
/*      */     }
/*      */     
/* 1731 */     if (into.getDefaultText() != null)
/*      */     {
/* 1733 */       if (from.getDefaultText() == null || !into.getDefaultText().equals(from.getDefaultText()))
/*      */       {
/* 1735 */         into.setDefaultText(null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static SchemaParticle[] ensureStateMachine(SchemaParticle[] children) {
/* 1741 */     for (int i = 0; i < children.length; i++)
/*      */     {
/* 1743 */       buildStateMachine(children[i]);
/*      */     }
/* 1745 */     return children;
/*      */   }
/*      */   
/*      */   static void buildStateMachine(SchemaParticle contentModel) {
/*      */     int i;
/* 1750 */     if (contentModel == null) {
/*      */       return;
/*      */     }
/* 1753 */     SchemaParticleImpl partImpl = (SchemaParticleImpl)contentModel;
/* 1754 */     if (partImpl.hasTransitionNotes()) {
/*      */       return;
/*      */     }
/* 1757 */     QNameSetBuilder start = new QNameSetBuilder();
/* 1758 */     QNameSetBuilder excludenext = new QNameSetBuilder();
/* 1759 */     boolean deterministic = true;
/* 1760 */     SchemaParticle[] children = null;
/* 1761 */     boolean canskip = (partImpl.getMinOccurs().signum() == 0);
/*      */     
/* 1763 */     switch (partImpl.getParticleType()) {
/*      */ 
/*      */       
/*      */       case 4:
/* 1767 */         if (partImpl.hasTransitionRules()) {
/* 1768 */           start.addAll((QNameSetSpecification)partImpl.acceptedStartNames()); break;
/*      */         } 
/* 1770 */         start.add(partImpl.getName());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 1776 */         start.addAll((QNameSetSpecification)partImpl.getWildcardSet());
/*      */         break;
/*      */       
/*      */       case 3:
/* 1780 */         children = ensureStateMachine(partImpl.getParticleChildren());
/*      */ 
/*      */         
/* 1783 */         canskip = true;
/* 1784 */         for (i = 0; canskip && i < children.length; i++) {
/*      */           
/* 1786 */           if (!children[i].isSkippable()) {
/* 1787 */             canskip = false;
/*      */           }
/*      */         } 
/*      */         
/* 1791 */         for (i = 0; deterministic && i < children.length; i++) {
/*      */           
/* 1793 */           if (!((SchemaParticleImpl)children[i]).isDeterministic()) {
/* 1794 */             deterministic = false;
/*      */           }
/*      */         } 
/*      */         
/* 1798 */         for (i = 1; i < children.length; i++) {
/*      */           
/* 1800 */           excludenext.addAll((QNameSetSpecification)((SchemaParticleImpl)children[i - 1]).getExcludeNextSet());
/* 1801 */           if (deterministic && !excludenext.isDisjoint((QNameSetSpecification)children[i].acceptedStartNames()))
/* 1802 */             deterministic = false; 
/* 1803 */           if (children[i].isSkippable()) {
/* 1804 */             excludenext.addAll((QNameSetSpecification)children[i].acceptedStartNames());
/*      */           } else {
/* 1806 */             excludenext.clear();
/*      */           } 
/*      */         } 
/*      */         
/* 1810 */         for (i = 0; i < children.length; i++) {
/*      */           
/* 1812 */           start.addAll((QNameSetSpecification)children[i].acceptedStartNames());
/* 1813 */           if (!children[i].isSkippable()) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case 2:
/* 1819 */         children = ensureStateMachine(partImpl.getParticleChildren());
/*      */ 
/*      */         
/* 1822 */         canskip = false;
/* 1823 */         for (i = 0; !canskip && i < children.length; i++) {
/*      */           
/* 1825 */           if (children[i].isSkippable()) {
/* 1826 */             canskip = true;
/*      */           }
/*      */         } 
/*      */         
/* 1830 */         for (i = 0; deterministic && i < children.length; i++) {
/*      */           
/* 1832 */           if (!((SchemaParticleImpl)children[i]).isDeterministic()) {
/* 1833 */             deterministic = false;
/*      */           }
/*      */         } 
/*      */         
/* 1837 */         for (i = 0; i < children.length; i++) {
/*      */           
/* 1839 */           if (deterministic && !start.isDisjoint((QNameSetSpecification)children[i].acceptedStartNames()))
/* 1840 */             deterministic = false; 
/* 1841 */           start.addAll((QNameSetSpecification)children[i].acceptedStartNames());
/* 1842 */           excludenext.addAll((QNameSetSpecification)((SchemaParticleImpl)children[i]).getExcludeNextSet());
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/* 1848 */         children = ensureStateMachine(partImpl.getParticleChildren());
/*      */ 
/*      */         
/* 1851 */         canskip = true;
/* 1852 */         for (i = 0; !canskip && i < children.length; i++) {
/*      */           
/* 1854 */           if (!children[i].isSkippable()) {
/* 1855 */             canskip = false;
/*      */           }
/*      */         } 
/*      */         
/* 1859 */         for (i = 0; deterministic && i < children.length; i++) {
/*      */           
/* 1861 */           if (!((SchemaParticleImpl)children[i]).isDeterministic()) {
/* 1862 */             deterministic = false;
/*      */           }
/*      */         } 
/*      */         
/* 1866 */         for (i = 0; i < children.length; i++) {
/*      */           
/* 1868 */           if (deterministic && !start.isDisjoint((QNameSetSpecification)children[i].acceptedStartNames()))
/* 1869 */             deterministic = false; 
/* 1870 */           start.addAll((QNameSetSpecification)children[i].acceptedStartNames());
/* 1871 */           excludenext.addAll((QNameSetSpecification)((SchemaParticleImpl)children[i]).getExcludeNextSet());
/*      */         } 
/* 1873 */         if (canskip) {
/* 1874 */           excludenext.addAll((QNameSetSpecification)start);
/*      */         }
/*      */         break;
/*      */       
/*      */       default:
/* 1879 */         throw new IllegalStateException("Unrecognized schema particle");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1884 */     BigInteger minOccurs = partImpl.getMinOccurs();
/* 1885 */     BigInteger maxOccurs = partImpl.getMaxOccurs();
/* 1886 */     boolean canloop = (maxOccurs == null || maxOccurs.compareTo(BigInteger.ONE) > 0);
/* 1887 */     boolean varloop = (maxOccurs == null || minOccurs.compareTo(maxOccurs) < 0);
/*      */     
/* 1889 */     if (canloop && deterministic && !excludenext.isDisjoint((QNameSetSpecification)start)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1894 */       QNameSet suspectSet = excludenext.intersect((QNameSetSpecification)start);
/*      */ 
/*      */       
/* 1897 */       Map startMap = new HashMap();
/* 1898 */       particlesMatchingStart(partImpl, (QNameSetSpecification)suspectSet, startMap, new QNameSetBuilder());
/*      */ 
/*      */       
/* 1901 */       Map afterMap = new HashMap();
/* 1902 */       particlesMatchingAfter(partImpl, (QNameSetSpecification)suspectSet, afterMap, new QNameSetBuilder(), true);
/*      */ 
/*      */ 
/*      */       
/* 1906 */       deterministic = afterMapSubsumedByStartMap(startMap, afterMap);
/*      */     } 
/*      */     
/* 1909 */     if (varloop) {
/* 1910 */       excludenext.addAll((QNameSetSpecification)start);
/*      */     }
/* 1912 */     canskip = (canskip || minOccurs.signum() == 0);
/*      */     
/* 1914 */     partImpl.setTransitionRules(start.toQNameSet(), canskip);
/* 1915 */     partImpl.setTransitionNotes(excludenext.toQNameSet(), deterministic);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean afterMapSubsumedByStartMap(Map startMap, Map afterMap) {
/* 1920 */     if (afterMap.size() > startMap.size()) {
/* 1921 */       return false;
/*      */     }
/* 1923 */     if (afterMap.isEmpty()) {
/* 1924 */       return true;
/*      */     }
/* 1926 */     for (Iterator i = startMap.keySet().iterator(); i.hasNext(); ) {
/*      */       
/* 1928 */       SchemaParticle part = i.next();
/* 1929 */       if (part.getParticleType() == 5)
/*      */       {
/* 1931 */         if (afterMap.containsKey(part)) {
/*      */           
/* 1933 */           QNameSet startSet = (QNameSet)startMap.get(part);
/* 1934 */           QNameSet afterSet = (QNameSet)afterMap.get(part);
/* 1935 */           if (!startSet.containsAll((QNameSetSpecification)afterSet))
/* 1936 */             return false; 
/*      */         } 
/*      */       }
/* 1939 */       afterMap.remove(part);
/* 1940 */       if (afterMap.isEmpty())
/* 1941 */         return true; 
/*      */     } 
/* 1943 */     return afterMap.isEmpty(); } private static void particlesMatchingStart(SchemaParticle part, QNameSetSpecification suspectSet, Map result, QNameSetBuilder eliminate) { SchemaParticle[] children;
/*      */     int i;
/*      */     QNameSetBuilder remainingSuspects;
/*      */     QNameSetBuilder suspectsToEliminate;
/*      */     int j;
/* 1948 */     switch (part.getParticleType()) {
/*      */       
/*      */       case 4:
/* 1951 */         if (!suspectSet.contains(part.getName()))
/*      */           return; 
/* 1953 */         result.put(part, null);
/* 1954 */         eliminate.add(part.getName());
/*      */         return;
/*      */       
/*      */       case 5:
/* 1958 */         if (suspectSet.isDisjoint((QNameSetSpecification)part.getWildcardSet()))
/*      */           return; 
/* 1960 */         result.put(part, part.getWildcardSet().intersect(suspectSet));
/* 1961 */         eliminate.addAll((QNameSetSpecification)part.getWildcardSet());
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/* 1967 */         children = part.getParticleChildren();
/* 1968 */         for (i = 0; i < children.length; i++) {
/* 1969 */           particlesMatchingStart(children[i], suspectSet, result, eliminate);
/*      */         }
/*      */         return;
/*      */ 
/*      */       
/*      */       case 3:
/* 1975 */         children = part.getParticleChildren();
/* 1976 */         if (children.length == 0)
/*      */           return; 
/* 1978 */         if (!children[0].isSkippable()) {
/*      */           
/* 1980 */           particlesMatchingStart(children[0], suspectSet, result, eliminate);
/*      */           return;
/*      */         } 
/* 1983 */         remainingSuspects = new QNameSetBuilder(suspectSet);
/* 1984 */         suspectsToEliminate = new QNameSetBuilder();
/* 1985 */         for (j = 0; j < children.length; j++) {
/*      */           
/* 1987 */           particlesMatchingStart(children[j], (QNameSetSpecification)remainingSuspects, result, suspectsToEliminate);
/* 1988 */           eliminate.addAll((QNameSetSpecification)suspectsToEliminate);
/* 1989 */           if (!children[j].isSkippable())
/*      */             return; 
/* 1991 */           remainingSuspects.removeAll((QNameSetSpecification)suspectsToEliminate);
/* 1992 */           if (remainingSuspects.isEmpty())
/*      */             return; 
/* 1994 */           suspectsToEliminate.clear();
/*      */         } 
/*      */         return;
/*      */     }  } private static void particlesMatchingAfter(SchemaParticle part, QNameSetSpecification suspectSet, Map result, QNameSetBuilder eliminate, boolean top) {
/*      */     SchemaParticle[] children;
/*      */     int i;
/*      */     QNameSetBuilder remainingSuspects;
/*      */     QNameSetBuilder suspectsToEliminate;
/*      */     int j;
/* 2003 */     switch (part.getParticleType()) {
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/* 2008 */         children = part.getParticleChildren();
/* 2009 */         for (i = 0; i < children.length; i++) {
/* 2010 */           particlesMatchingAfter(children[i], suspectSet, result, eliminate, false);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/* 2016 */         children = part.getParticleChildren();
/* 2017 */         if (children.length == 0)
/*      */           break; 
/* 2019 */         if (!children[children.length - 1].isSkippable()) {
/*      */           
/* 2021 */           particlesMatchingAfter(children[0], suspectSet, result, eliminate, false);
/*      */           break;
/*      */         } 
/* 2024 */         remainingSuspects = new QNameSetBuilder(suspectSet);
/* 2025 */         suspectsToEliminate = new QNameSetBuilder();
/* 2026 */         for (j = children.length - 1; j >= 0; j--) {
/*      */           
/* 2028 */           particlesMatchingAfter(children[j], (QNameSetSpecification)remainingSuspects, result, suspectsToEliminate, false);
/* 2029 */           eliminate.addAll((QNameSetSpecification)suspectsToEliminate);
/* 2030 */           if (!children[j].isSkippable())
/*      */             break; 
/* 2032 */           remainingSuspects.removeAll((QNameSetSpecification)suspectsToEliminate);
/* 2033 */           if (remainingSuspects.isEmpty())
/*      */             break; 
/* 2035 */           suspectsToEliminate.clear();
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 2041 */     if (!top) {
/*      */       
/* 2043 */       BigInteger minOccurs = part.getMinOccurs();
/* 2044 */       BigInteger maxOccurs = part.getMaxOccurs();
/* 2045 */       boolean varloop = (maxOccurs == null || minOccurs.compareTo(maxOccurs) < 0);
/* 2046 */       if (varloop)
/*      */       {
/* 2048 */         particlesMatchingStart(part, suspectSet, result, eliminate); } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class CodeForNameEntry { public QName name;
/*      */     public int code;
/*      */     
/*      */     CodeForNameEntry(QName name, int code) {
/* 2056 */       this.name = name; this.code = code;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2063 */   private static CodeForNameEntry[] particleCodes = new CodeForNameEntry[] { new CodeForNameEntry(QNameHelper.forLNS("all", "http://www.w3.org/2001/XMLSchema"), 1), new CodeForNameEntry(QNameHelper.forLNS("sequence", "http://www.w3.org/2001/XMLSchema"), 3), new CodeForNameEntry(QNameHelper.forLNS("choice", "http://www.w3.org/2001/XMLSchema"), 2), new CodeForNameEntry(QNameHelper.forLNS("element", "http://www.w3.org/2001/XMLSchema"), 4), new CodeForNameEntry(QNameHelper.forLNS("any", "http://www.w3.org/2001/XMLSchema"), 5), new CodeForNameEntry(QNameHelper.forLNS("group", "http://www.w3.org/2001/XMLSchema"), 100) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2073 */   private static Map particleCodeMap = buildParticleCodeMap(); private static final int ATTRIBUTE_CODE = 100; private static final int ATTRIBUTE_GROUP_CODE = 101;
/*      */   private static final int ANY_ATTRIBUTE_CODE = 102;
/*      */   
/*      */   private static Map buildParticleCodeMap() {
/* 2077 */     Map result = new HashMap();
/* 2078 */     for (int i = 0; i < particleCodes.length; i++)
/* 2079 */       result.put((particleCodes[i]).name, new Integer((particleCodes[i]).code)); 
/* 2080 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int translateParticleCode(Group parseEg) {
/* 2085 */     if (parseEg == null)
/* 2086 */       return 0; 
/* 2087 */     return translateParticleCode(parseEg.newCursor().getName());
/*      */   }
/*      */ 
/*      */   
/*      */   private static int translateParticleCode(QName name) {
/* 2092 */     Integer result = (Integer)particleCodeMap.get(name);
/* 2093 */     if (result == null)
/* 2094 */       return 0; 
/* 2095 */     return result.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2102 */   private static CodeForNameEntry[] attributeCodes = new CodeForNameEntry[] { new CodeForNameEntry(QNameHelper.forLNS("attribute", "http://www.w3.org/2001/XMLSchema"), 100), new CodeForNameEntry(QNameHelper.forLNS("attributeGroup", "http://www.w3.org/2001/XMLSchema"), 101), new CodeForNameEntry(QNameHelper.forLNS("anyAttribute", "http://www.w3.org/2001/XMLSchema"), 102) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2109 */   private static Map attributeCodeMap = buildAttributeCodeMap();
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   private static Map buildAttributeCodeMap() {
/* 2113 */     Map result = new HashMap();
/* 2114 */     for (int i = 0; i < attributeCodes.length; i++)
/* 2115 */       result.put((attributeCodes[i]).name, new Integer((attributeCodes[i]).code)); 
/* 2116 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static int translateAttributeCode(QName currentName) {
/* 2121 */     Integer result = (Integer)attributeCodeMap.get(currentName);
/* 2122 */     if (result == null)
/* 2123 */       return 0; 
/* 2124 */     return result.intValue();
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscComplexTypeResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */