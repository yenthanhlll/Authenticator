/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.QNameSetBuilder;
/*      */ import org.apache.xmlbeans.QNameSetSpecification;
/*      */ import org.apache.xmlbeans.SchemaAttributeModel;
/*      */ import org.apache.xmlbeans.SchemaBookmark;
/*      */ import org.apache.xmlbeans.SchemaField;
/*      */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*      */ import org.apache.xmlbeans.SchemaParticle;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlNonNegativeInteger;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlPositiveInteger;
/*      */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.common.XMLChar;
/*      */ import org.apache.xmlbeans.impl.common.XPath;
/*      */ import org.apache.xmlbeans.impl.regex.RegularExpression;
/*      */ import org.apache.xmlbeans.impl.values.NamespaceContext;
/*      */ import org.apache.xmlbeans.impl.values.XmlNonNegativeIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlPositiveIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlValueOutOfRangeException;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Annotated;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AnnotationDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroup;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Element;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.FieldDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.FormChoice;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Keybase;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.KeyrefDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalComplexType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalSimpleType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.NamedAttributeGroup;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.NamedGroup;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.RedefineDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelAttribute;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelComplexType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelElement;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelSimpleType;
/*      */ import org.apache.xmlbeans.soap.SOAPArrayType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StscTranslator
/*      */ {
/*   74 */   private static final QName WSDL_ARRAYTYPE_NAME = QNameHelper.forLNS("arrayType", "http://schemas.xmlsoap.org/wsdl/");
/*      */ 
/*      */   
/*      */   private static final String FORM_QUALIFIED = "qualified";
/*      */ 
/*      */   
/*      */   public static void addAllDefinitions(StscImporter.SchemaToProcess[] schemasAndChameleons) {
/*   81 */     List redefinitions = new ArrayList();
/*   82 */     for (int i = 0; i < schemasAndChameleons.length; i++) {
/*      */       
/*   84 */       List redefines = schemasAndChameleons[i].getRedefines();
/*   85 */       if (redefines != null) {
/*      */         
/*   87 */         List redefineObjects = schemasAndChameleons[i].getRedefineObjects();
/*   88 */         Iterator it = redefines.iterator();
/*   89 */         Iterator ito = redefineObjects.iterator();
/*   90 */         while (it.hasNext()) {
/*      */ 
/*      */           
/*   93 */           assert ito.hasNext() : "The array of redefines and redefine objects have to have the same length";
/*   94 */           redefinitions.add(new RedefinitionHolder(it.next(), ito.next()));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  100 */     RedefinitionMaster globalRedefinitions = new RedefinitionMaster(redefinitions.<RedefinitionHolder>toArray(new RedefinitionHolder[redefinitions.size()]));
/*      */ 
/*      */     
/*  103 */     StscState state = StscState.get();
/*  104 */     for (int j = 0; j < schemasAndChameleons.length; j++) {
/*      */       
/*  106 */       SchemaDocument.Schema schema = schemasAndChameleons[j].getSchema();
/*  107 */       String givenTargetNamespace = schemasAndChameleons[j].getChameleonNamespace();
/*      */ 
/*      */ 
/*      */       
/*  111 */       if (schema.sizeOfNotationArray() > 0)
/*      */       {
/*  113 */         state.warning("Schema <notation> is not yet supported for this release.", 51, (XmlObject)schema.getNotationArray(0));
/*      */       }
/*      */ 
/*      */       
/*  117 */       String targetNamespace = schema.getTargetNamespace();
/*  118 */       boolean chameleon = false;
/*  119 */       if (givenTargetNamespace != null && targetNamespace == null) {
/*      */         
/*  121 */         targetNamespace = givenTargetNamespace;
/*  122 */         chameleon = true;
/*      */       } 
/*  124 */       if (targetNamespace == null) {
/*  125 */         targetNamespace = "";
/*      */       }
/*      */       
/*  128 */       if (targetNamespace.length() > 0 || !isEmptySchema(schema)) {
/*      */         
/*  130 */         state.registerContribution(targetNamespace, schema.documentProperties().getSourceName());
/*  131 */         state.addNewContainer(targetNamespace);
/*      */       } 
/*      */ 
/*      */       
/*  135 */       List redefChain = new ArrayList();
/*  136 */       TopLevelComplexType[] complexTypes = schema.getComplexTypeArray();
/*  137 */       for (int m = 0; m < complexTypes.length; m++) {
/*      */         
/*  139 */         TopLevelComplexType type = complexTypes[m];
/*      */ 
/*      */ 
/*      */         
/*  143 */         RedefinitionHolder[] rhArray = globalRedefinitions.getComplexTypeRedefinitions(type.getName(), schemasAndChameleons[j]);
/*      */         
/*  145 */         for (int i6 = 0; i6 < rhArray.length; i6++) {
/*      */ 
/*      */ 
/*      */           
/*  149 */           if (rhArray[i6] != null) {
/*      */             
/*  151 */             TopLevelComplexType redef = rhArray[i6].redefineComplexType(type.getName());
/*  152 */             assert redef != null;
/*  153 */             redefChain.add(type);
/*  154 */             type = redef;
/*      */           } 
/*      */         } 
/*      */         
/*  158 */         SchemaTypeImpl t = translateGlobalComplexType(type, targetNamespace, chameleon, (redefChain.size() > 0));
/*  159 */         state.addGlobalType(t, null);
/*      */ 
/*      */ 
/*      */         
/*  163 */         for (int i7 = redefChain.size() - 1; i7 >= 0; i7--) {
/*      */           
/*  165 */           TopLevelComplexType redef = redefChain.remove(i7);
/*  166 */           SchemaTypeImpl r = translateGlobalComplexType(redef, targetNamespace, chameleon, (i7 > 0));
/*  167 */           state.addGlobalType(r, t);
/*  168 */           t = r;
/*      */         } 
/*      */       } 
/*      */       
/*  172 */       TopLevelSimpleType[] simpleTypes = schema.getSimpleTypeArray();
/*  173 */       for (int n = 0; n < simpleTypes.length; n++) {
/*      */         
/*  175 */         TopLevelSimpleType type = simpleTypes[n];
/*      */         
/*  177 */         RedefinitionHolder[] rhArray = globalRedefinitions.getSimpleTypeRedefinitions(type.getName(), schemasAndChameleons[j]);
/*      */         
/*  179 */         for (int i6 = 0; i6 < rhArray.length; i6++) {
/*      */ 
/*      */ 
/*      */           
/*  183 */           if (rhArray[i6] != null) {
/*      */             
/*  185 */             TopLevelSimpleType redef = rhArray[i6].redefineSimpleType(type.getName());
/*  186 */             assert redef != null;
/*  187 */             redefChain.add(type);
/*  188 */             type = redef;
/*      */           } 
/*      */         } 
/*      */         
/*  192 */         SchemaTypeImpl t = translateGlobalSimpleType(type, targetNamespace, chameleon, (redefChain.size() > 0));
/*  193 */         state.addGlobalType(t, null);
/*      */         
/*  195 */         for (int i7 = redefChain.size() - 1; i7 >= 0; i7--) {
/*      */           
/*  197 */           TopLevelSimpleType redef = (TopLevelSimpleType)redefChain.remove(i7);
/*  198 */           SchemaTypeImpl r = translateGlobalSimpleType(redef, targetNamespace, chameleon, (i7 > 0));
/*  199 */           state.addGlobalType(r, t);
/*  200 */           t = r;
/*      */         } 
/*      */       } 
/*      */       
/*  204 */       TopLevelElement[] elements = schema.getElementArray();
/*  205 */       for (int i1 = 0; i1 < elements.length; i1++) {
/*      */         
/*  207 */         TopLevelElement element = elements[i1];
/*  208 */         state.addDocumentType(translateDocumentType(element, targetNamespace, chameleon), QNameHelper.forLNS(element.getName(), targetNamespace));
/*      */       } 
/*      */       
/*  211 */       TopLevelAttribute[] attributes = schema.getAttributeArray();
/*  212 */       for (int i2 = 0; i2 < attributes.length; i2++) {
/*      */         
/*  214 */         TopLevelAttribute attribute = attributes[i2];
/*  215 */         state.addAttributeType(translateAttributeType(attribute, targetNamespace, chameleon), QNameHelper.forLNS(attribute.getName(), targetNamespace));
/*      */       } 
/*      */       
/*  218 */       NamedGroup[] modelgroups = schema.getGroupArray();
/*  219 */       for (int i3 = 0; i3 < modelgroups.length; i3++) {
/*      */         
/*  221 */         NamedGroup group = modelgroups[i3];
/*      */         
/*  223 */         RedefinitionHolder[] rhArray = globalRedefinitions.getModelGroupRedefinitions(group.getName(), schemasAndChameleons[j]);
/*      */         
/*  225 */         for (int i6 = 0; i6 < rhArray.length; i6++) {
/*      */ 
/*      */ 
/*      */           
/*  229 */           if (rhArray[i6] != null) {
/*      */             
/*  231 */             NamedGroup redef = rhArray[i6].redefineModelGroup(group.getName());
/*  232 */             assert redef != null;
/*  233 */             redefChain.add(group);
/*  234 */             group = redef;
/*      */           } 
/*      */         } 
/*      */         
/*  238 */         SchemaModelGroupImpl g = translateModelGroup(group, targetNamespace, chameleon, (redefChain.size() > 0));
/*  239 */         state.addModelGroup(g, null);
/*      */         
/*  241 */         for (int i7 = redefChain.size() - 1; i7 >= 0; i7--) {
/*      */           
/*  243 */           NamedGroup redef = (NamedGroup)redefChain.remove(i7);
/*  244 */           SchemaModelGroupImpl r = translateModelGroup(redef, targetNamespace, chameleon, (i7 > 0));
/*  245 */           state.addModelGroup(r, g);
/*  246 */           g = r;
/*      */         } 
/*      */       } 
/*      */       
/*  250 */       NamedAttributeGroup[] attrgroups = schema.getAttributeGroupArray();
/*  251 */       for (int i4 = 0; i4 < attrgroups.length; i4++) {
/*      */         
/*  253 */         NamedAttributeGroup group = attrgroups[i4];
/*      */         
/*  255 */         RedefinitionHolder[] rhArray = globalRedefinitions.getAttributeGroupRedefinitions(group.getName(), schemasAndChameleons[j]);
/*      */         
/*  257 */         for (int i6 = 0; i6 < rhArray.length; i6++) {
/*      */ 
/*      */ 
/*      */           
/*  261 */           if (rhArray[i6] != null) {
/*      */             
/*  263 */             NamedAttributeGroup redef = rhArray[i6].redefineAttributeGroup(group.getName());
/*  264 */             assert redef != null;
/*  265 */             redefChain.add(group);
/*  266 */             group = redef;
/*      */           } 
/*      */         } 
/*      */         
/*  270 */         SchemaAttributeGroupImpl g = translateAttributeGroup((AttributeGroup)group, targetNamespace, chameleon, (redefChain.size() > 0));
/*  271 */         state.addAttributeGroup(g, null);
/*      */         
/*  273 */         for (int i7 = redefChain.size() - 1; i7 >= 0; i7--) {
/*      */           
/*  275 */           NamedAttributeGroup redef = (NamedAttributeGroup)redefChain.remove(i7);
/*  276 */           SchemaAttributeGroupImpl r = translateAttributeGroup((AttributeGroup)redef, targetNamespace, chameleon, (i7 > 0));
/*  277 */           state.addAttributeGroup(r, g);
/*  278 */           g = r;
/*      */         } 
/*      */       } 
/*      */       
/*  282 */       AnnotationDocument.Annotation[] annotations = schema.getAnnotationArray();
/*  283 */       for (int i5 = 0; i5 < annotations.length; i5++) {
/*  284 */         state.addAnnotation(SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (XmlObject)schema, annotations[i5]), targetNamespace);
/*      */       }
/*      */     } 
/*  287 */     for (int k = 0; k < redefinitions.size(); k++) {
/*  288 */       ((RedefinitionHolder)redefinitions.get(k)).complainAboutMissingDefinitions();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class RedefinitionHolder
/*      */   {
/*  294 */     private Map stRedefinitions = Collections.EMPTY_MAP;
/*  295 */     private Map ctRedefinitions = Collections.EMPTY_MAP;
/*  296 */     private Map agRedefinitions = Collections.EMPTY_MAP;
/*  297 */     private Map mgRedefinitions = Collections.EMPTY_MAP;
/*  298 */     private String schemaLocation = "";
/*      */     
/*      */     private StscImporter.SchemaToProcess schemaRedefined;
/*      */ 
/*      */     
/*      */     RedefinitionHolder(StscImporter.SchemaToProcess schemaToProcess, RedefineDocument.Redefine redefine) {
/*  304 */       this.schemaRedefined = schemaToProcess;
/*  305 */       if (redefine != null) {
/*      */         
/*  307 */         StscState state = StscState.get();
/*      */         
/*  309 */         this.stRedefinitions = new HashMap();
/*  310 */         this.ctRedefinitions = new HashMap();
/*  311 */         this.agRedefinitions = new HashMap();
/*  312 */         this.mgRedefinitions = new HashMap();
/*  313 */         if (redefine.getSchemaLocation() != null) {
/*  314 */           this.schemaLocation = redefine.getSchemaLocation();
/*      */         }
/*  316 */         TopLevelComplexType[] complexTypes = redefine.getComplexTypeArray();
/*  317 */         for (int i = 0; i < complexTypes.length; i++) {
/*      */           
/*  319 */           if (complexTypes[i].getName() != null)
/*      */           {
/*      */             
/*  322 */             if (this.ctRedefinitions.containsKey(complexTypes[i].getName())) {
/*  323 */               state.error("Duplicate type redefinition: " + complexTypes[i].getName(), 49, (XmlObject)null);
/*      */             } else {
/*  325 */               this.ctRedefinitions.put(complexTypes[i].getName(), complexTypes[i]);
/*      */             } 
/*      */           }
/*      */         } 
/*  329 */         TopLevelSimpleType[] simpleTypes = redefine.getSimpleTypeArray();
/*  330 */         for (int j = 0; j < simpleTypes.length; j++) {
/*      */           
/*  332 */           if (simpleTypes[j].getName() != null)
/*      */           {
/*  334 */             if (this.stRedefinitions.containsKey(simpleTypes[j].getName())) {
/*  335 */               state.error("Duplicate type redefinition: " + simpleTypes[j].getName(), 49, (XmlObject)null);
/*      */             } else {
/*  337 */               this.stRedefinitions.put(simpleTypes[j].getName(), simpleTypes[j]);
/*      */             } 
/*      */           }
/*      */         } 
/*  341 */         NamedGroup[] modelgroups = redefine.getGroupArray();
/*  342 */         for (int k = 0; k < modelgroups.length; k++) {
/*      */           
/*  344 */           if (modelgroups[k].getName() != null)
/*      */           {
/*  346 */             if (this.mgRedefinitions.containsKey(modelgroups[k].getName())) {
/*  347 */               state.error("Duplicate type redefinition: " + modelgroups[k].getName(), 49, (XmlObject)null);
/*      */             } else {
/*  349 */               this.mgRedefinitions.put(modelgroups[k].getName(), modelgroups[k]);
/*      */             } 
/*      */           }
/*      */         } 
/*  353 */         NamedAttributeGroup[] attrgroups = redefine.getAttributeGroupArray();
/*  354 */         for (int m = 0; m < attrgroups.length; m++) {
/*      */           
/*  356 */           if (attrgroups[m].getName() != null)
/*      */           {
/*  358 */             if (this.agRedefinitions.containsKey(attrgroups[m].getName())) {
/*  359 */               state.error("Duplicate type redefinition: " + attrgroups[m].getName(), 49, (XmlObject)null);
/*      */             } else {
/*  361 */               this.agRedefinitions.put(attrgroups[m].getName(), attrgroups[m]);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public TopLevelSimpleType redefineSimpleType(String name) {
/*  369 */       if (name == null || !this.stRedefinitions.containsKey(name))
/*  370 */         return null; 
/*  371 */       return (TopLevelSimpleType)this.stRedefinitions.remove(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public TopLevelComplexType redefineComplexType(String name) {
/*  376 */       if (name == null || !this.ctRedefinitions.containsKey(name))
/*  377 */         return null; 
/*  378 */       return (TopLevelComplexType)this.ctRedefinitions.remove(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public NamedGroup redefineModelGroup(String name) {
/*  383 */       if (name == null || !this.mgRedefinitions.containsKey(name))
/*  384 */         return null; 
/*  385 */       return (NamedGroup)this.mgRedefinitions.remove(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public NamedAttributeGroup redefineAttributeGroup(String name) {
/*  390 */       if (name == null || !this.agRedefinitions.containsKey(name))
/*  391 */         return null; 
/*  392 */       return (NamedAttributeGroup)this.agRedefinitions.remove(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void complainAboutMissingDefinitions() {
/*  397 */       if (this.stRedefinitions.isEmpty() && this.ctRedefinitions.isEmpty() && this.agRedefinitions.isEmpty() && this.mgRedefinitions.isEmpty()) {
/*      */         return;
/*      */       }
/*      */       
/*  401 */       StscState state = StscState.get();
/*      */       
/*  403 */       for (Iterator iterator3 = this.stRedefinitions.keySet().iterator(); iterator3.hasNext(); ) {
/*      */         
/*  405 */         String name = iterator3.next();
/*  406 */         state.error("Redefined simple type " + name + " not found in " + this.schemaLocation, 60, (XmlObject)this.stRedefinitions.get(name));
/*      */       } 
/*      */       
/*  409 */       for (Iterator iterator2 = this.ctRedefinitions.keySet().iterator(); iterator2.hasNext(); ) {
/*      */         
/*  411 */         String name = iterator2.next();
/*  412 */         state.error("Redefined complex type " + name + " not found in " + this.schemaLocation, 60, (XmlObject)this.ctRedefinitions.get(name));
/*      */       } 
/*      */       
/*  415 */       for (Iterator iterator1 = this.agRedefinitions.keySet().iterator(); iterator1.hasNext(); ) {
/*      */         
/*  417 */         String name = iterator1.next();
/*  418 */         state.error("Redefined attribute group " + name + " not found in " + this.schemaLocation, 60, (XmlObject)this.agRedefinitions.get(name));
/*      */       } 
/*      */       
/*  421 */       for (Iterator i = this.mgRedefinitions.keySet().iterator(); i.hasNext(); ) {
/*      */         
/*  423 */         String name = i.next();
/*  424 */         state.error("Redefined model group " + name + " not found in " + this.schemaLocation, 60, (XmlObject)this.mgRedefinitions.get(name));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class RedefinitionMaster
/*      */   {
/*  441 */     private Map stRedefinitions = Collections.EMPTY_MAP;
/*  442 */     private Map ctRedefinitions = Collections.EMPTY_MAP;
/*  443 */     private Map agRedefinitions = Collections.EMPTY_MAP;
/*  444 */     private Map mgRedefinitions = Collections.EMPTY_MAP;
/*  445 */     private static final StscTranslator.RedefinitionHolder[] EMPTY_REDEFINTION_HOLDER_ARRAY = new StscTranslator.RedefinitionHolder[0];
/*      */     private static final short SIMPLE_TYPE = 1;
/*      */     private static final short COMPLEX_TYPE = 2;
/*      */     
/*      */     RedefinitionMaster(StscTranslator.RedefinitionHolder[] redefHolders) {
/*  450 */       if (redefHolders.length > 0) {
/*      */         
/*  452 */         this.stRedefinitions = new HashMap();
/*  453 */         this.ctRedefinitions = new HashMap();
/*  454 */         this.agRedefinitions = new HashMap();
/*  455 */         this.mgRedefinitions = new HashMap();
/*      */         
/*  457 */         for (int i = 0; i < redefHolders.length; i++) {
/*      */           
/*  459 */           StscTranslator.RedefinitionHolder redefHolder = redefHolders[i]; Iterator it;
/*  460 */           for (it = redefHolder.stRedefinitions.keySet().iterator(); it.hasNext(); ) {
/*      */             
/*  462 */             Object key = it.next();
/*  463 */             List redefinedIn = (List)this.stRedefinitions.get(key);
/*  464 */             if (redefinedIn == null) {
/*      */               
/*  466 */               redefinedIn = new ArrayList();
/*  467 */               this.stRedefinitions.put(key, redefinedIn);
/*      */             } 
/*  469 */             redefinedIn.add(redefHolders[i]);
/*      */           } 
/*  471 */           for (it = redefHolder.ctRedefinitions.keySet().iterator(); it.hasNext(); ) {
/*      */             
/*  473 */             Object key = it.next();
/*  474 */             List redefinedIn = (List)this.ctRedefinitions.get(key);
/*  475 */             if (redefinedIn == null) {
/*      */               
/*  477 */               redefinedIn = new ArrayList();
/*  478 */               this.ctRedefinitions.put(key, redefinedIn);
/*      */             } 
/*  480 */             redefinedIn.add(redefHolders[i]);
/*      */           } 
/*  482 */           for (it = redefHolder.agRedefinitions.keySet().iterator(); it.hasNext(); ) {
/*      */             
/*  484 */             Object key = it.next();
/*  485 */             List redefinedIn = (List)this.agRedefinitions.get(key);
/*  486 */             if (redefinedIn == null) {
/*      */               
/*  488 */               redefinedIn = new ArrayList();
/*  489 */               this.agRedefinitions.put(key, redefinedIn);
/*      */             } 
/*  491 */             redefinedIn.add(redefHolders[i]);
/*      */           } 
/*  493 */           for (it = redefHolder.mgRedefinitions.keySet().iterator(); it.hasNext(); ) {
/*      */             
/*  495 */             Object key = it.next();
/*  496 */             List redefinedIn = (List)this.mgRedefinitions.get(key);
/*  497 */             if (redefinedIn == null) {
/*      */               
/*  499 */               redefinedIn = new ArrayList();
/*  500 */               this.mgRedefinitions.put(key, redefinedIn);
/*      */             } 
/*  502 */             redefinedIn.add(redefHolders[i]);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     private static final short MODEL_GROUP = 3; private static final short ATTRIBUTE_GROUP = 4;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     StscTranslator.RedefinitionHolder[] getSimpleTypeRedefinitions(String name, StscImporter.SchemaToProcess schema) {
/*  511 */       List redefines = (List)this.stRedefinitions.get(name);
/*  512 */       if (redefines == null)
/*  513 */         return EMPTY_REDEFINTION_HOLDER_ARRAY; 
/*  514 */       return doTopologicalSort(redefines, schema, name, (short)1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     StscTranslator.RedefinitionHolder[] getComplexTypeRedefinitions(String name, StscImporter.SchemaToProcess schema) {
/*  520 */       List redefines = (List)this.ctRedefinitions.get(name);
/*  521 */       if (redefines == null)
/*  522 */         return EMPTY_REDEFINTION_HOLDER_ARRAY; 
/*  523 */       return doTopologicalSort(redefines, schema, name, (short)2);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     StscTranslator.RedefinitionHolder[] getAttributeGroupRedefinitions(String name, StscImporter.SchemaToProcess schema) {
/*  529 */       List redefines = (List)this.agRedefinitions.get(name);
/*  530 */       if (redefines == null)
/*  531 */         return EMPTY_REDEFINTION_HOLDER_ARRAY; 
/*  532 */       return doTopologicalSort(redefines, schema, name, (short)4);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     StscTranslator.RedefinitionHolder[] getModelGroupRedefinitions(String name, StscImporter.SchemaToProcess schema) {
/*  538 */       List redefines = (List)this.mgRedefinitions.get(name);
/*  539 */       if (redefines == null)
/*  540 */         return EMPTY_REDEFINTION_HOLDER_ARRAY; 
/*  541 */       return doTopologicalSort(redefines, schema, name, (short)3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private StscTranslator.RedefinitionHolder[] doTopologicalSort(List genericRedefines, StscImporter.SchemaToProcess schema, String name, short componentType) {
/*  554 */       StscTranslator.RedefinitionHolder[] specificRedefines = new StscTranslator.RedefinitionHolder[genericRedefines.size()];
/*  555 */       int n = 0;
/*  556 */       for (int i = 0; i < genericRedefines.size(); i++) {
/*      */         
/*  558 */         StscTranslator.RedefinitionHolder h = genericRedefines.get(i);
/*  559 */         if (h.schemaRedefined == schema || h.schemaRedefined.indirectIncludes(schema))
/*      */         {
/*  561 */           specificRedefines[n++] = h;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  567 */       StscTranslator.RedefinitionHolder[] sortedRedefines = new StscTranslator.RedefinitionHolder[n];
/*  568 */       int[] numberOfIncludes = new int[n];
/*      */       
/*  570 */       for (int j = 0; j < n - 1; j++) {
/*      */         
/*  572 */         StscTranslator.RedefinitionHolder current = specificRedefines[j];
/*  573 */         for (int m = j + 1; m < n; m++) {
/*      */           
/*  575 */           if (current.schemaRedefined.indirectIncludes((specificRedefines[m]).schemaRedefined))
/*  576 */             numberOfIncludes[j] = numberOfIncludes[j] + 1; 
/*  577 */           if ((specificRedefines[m]).schemaRedefined.indirectIncludes(current.schemaRedefined)) {
/*  578 */             numberOfIncludes[m] = numberOfIncludes[m] + 1;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  583 */       int position = 0;
/*  584 */       boolean errorReported = false;
/*  585 */       while (position < n) {
/*      */         
/*  587 */         int index = -1; int m;
/*  588 */         for (m = 0; m < numberOfIncludes.length; m++) {
/*  589 */           if (numberOfIncludes[m] == 0)
/*      */           {
/*  591 */             if (index < 0)
/*  592 */               index = m;  } 
/*      */         } 
/*  594 */         if (index < 0) {
/*      */ 
/*      */           
/*  597 */           if (!errorReported) {
/*      */             
/*  599 */             StringBuffer fileNameList = new StringBuffer();
/*  600 */             XmlObject location = null;
/*  601 */             for (int i2 = 0; i2 < n; i2++) {
/*  602 */               if (specificRedefines[i2] != null) {
/*      */                 
/*  604 */                 fileNameList.append((specificRedefines[i2]).schemaLocation).append(',').append(' ');
/*      */                 
/*  606 */                 if (location == null)
/*  607 */                   location = locationFromRedefinitionAndCode(specificRedefines[i2], name, componentType); 
/*      */               } 
/*      */             } 
/*  610 */             StscState.get().error("Detected circular redefinition of " + componentNameFromCode(componentType) + " \"" + name + "\"; Files involved: " + fileNameList.toString(), 60, location);
/*      */ 
/*      */ 
/*      */             
/*  614 */             errorReported = true;
/*      */           } 
/*  616 */           int min = n;
/*  617 */           for (int i1 = 0; i1 < n; i1++) {
/*  618 */             if (numberOfIncludes[i1] > 0 && numberOfIncludes[i1] < min) {
/*      */               
/*  620 */               min = numberOfIncludes[i1];
/*  621 */               index = i1;
/*      */             } 
/*  623 */           }  numberOfIncludes[index] = numberOfIncludes[index] - 1;
/*      */           
/*      */           continue;
/*      */         } 
/*  627 */         assert specificRedefines[index] != null;
/*  628 */         sortedRedefines[position++] = specificRedefines[index];
/*  629 */         for (m = 0; m < n; m++) {
/*  630 */           if (specificRedefines[m] != null && (specificRedefines[m]).schemaRedefined.indirectIncludes((specificRedefines[index]).schemaRedefined))
/*      */           {
/*      */ 
/*      */             
/*  634 */             numberOfIncludes[m] = numberOfIncludes[m] - 1; } 
/*  635 */         }  specificRedefines[index] = null;
/*  636 */         numberOfIncludes[index] = numberOfIncludes[index] - 1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  643 */       for (int k = 1; k < n; k++) {
/*      */         int m;
/*      */ 
/*      */ 
/*      */         
/*  648 */         for (m = k - 1; m >= 0 && 
/*  649 */           sortedRedefines[m] == null; m--);
/*      */ 
/*      */         
/*  652 */         if (!(sortedRedefines[k]).schemaRedefined.indirectIncludes((sortedRedefines[m]).schemaRedefined)) {
/*      */ 
/*      */           
/*  655 */           StscState.get().error("Detected multiple redefinitions of " + componentNameFromCode(componentType) + " \"" + name + "\"; Files involved: " + (sortedRedefines[m]).schemaRedefined.getSourceName() + ", " + (sortedRedefines[k]).schemaRedefined.getSourceName(), 49, locationFromRedefinitionAndCode(sortedRedefines[k], name, componentType));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  663 */           switch (componentType) {
/*      */             
/*      */             case 1:
/*  666 */               sortedRedefines[k].redefineSimpleType(name); break;
/*      */             case 2:
/*  668 */               sortedRedefines[k].redefineComplexType(name); break;
/*      */             case 4:
/*  670 */               sortedRedefines[k].redefineAttributeGroup(name); break;
/*      */             case 3:
/*  672 */               sortedRedefines[k].redefineModelGroup(name); break;
/*      */           } 
/*  674 */           sortedRedefines[k] = null;
/*      */         } 
/*      */       } 
/*      */       
/*  678 */       return sortedRedefines;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String componentNameFromCode(short code) {
/*  684 */       switch (code)
/*      */       { case 1:
/*  686 */           componentName = "simple type";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  692 */           return componentName;case 2: componentName = "complex type"; return componentName;case 3: componentName = "model group"; return componentName;case 4: componentName = "attribute group"; return componentName; }  String componentName = ""; return componentName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private XmlObject locationFromRedefinitionAndCode(StscTranslator.RedefinitionHolder redefinition, String name, short code) {
/*  699 */       switch (code)
/*      */       
/*      */       { case 1:
/*  702 */           location = (XmlObject)redefinition.stRedefinitions.get(name);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  716 */           return location;case 2: location = (XmlObject)redefinition.ctRedefinitions.get(name); return location;case 3: location = (XmlObject)redefinition.mgRedefinitions.get(name); return location;case 4: location = (XmlObject)redefinition.agRedefinitions.get(name); return location; }  XmlObject location = null; return location;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static String findFilename(XmlObject xobj) {
/*  722 */     return StscState.get().sourceNameForUri(xobj.documentProperties().getSourceName());
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaTypeImpl translateDocumentType(TopLevelElement xsdType, String targetNamespace, boolean chameleon) {
/*  727 */     SchemaTypeImpl sType = new SchemaTypeImpl(StscState.get().getContainer(targetNamespace));
/*      */     
/*  729 */     sType.setDocumentType(true);
/*  730 */     sType.setParseContext((XmlObject)xsdType, targetNamespace, chameleon, null, null, false);
/*  731 */     sType.setFilename(findFilename((XmlObject)xsdType));
/*      */     
/*  733 */     return sType;
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaTypeImpl translateAttributeType(TopLevelAttribute xsdType, String targetNamespace, boolean chameleon) {
/*  738 */     SchemaTypeImpl sType = new SchemaTypeImpl(StscState.get().getContainer(targetNamespace));
/*      */     
/*  740 */     sType.setAttributeType(true);
/*  741 */     sType.setParseContext((XmlObject)xsdType, targetNamespace, chameleon, null, null, false);
/*  742 */     sType.setFilename(findFilename((XmlObject)xsdType));
/*      */     
/*  744 */     return sType;
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaTypeImpl translateGlobalComplexType(TopLevelComplexType xsdType, String targetNamespace, boolean chameleon, boolean redefinition) {
/*  749 */     StscState state = StscState.get();
/*      */     
/*  751 */     String localname = xsdType.getName();
/*  752 */     if (localname == null) {
/*      */       
/*  754 */       state.error("missing-name", new Object[] { "global type" }, (XmlObject)xsdType);
/*      */       
/*  756 */       return null;
/*      */     } 
/*  758 */     if (!XMLChar.isValidNCName(localname))
/*      */     {
/*  760 */       state.error("invalid-value", new Object[] { localname, "name" }, (XmlObject)xsdType.xgetName());
/*      */     }
/*      */ 
/*      */     
/*  764 */     QName name = QNameHelper.forLNS(localname, targetNamespace);
/*      */     
/*  766 */     if (isReservedTypeName(name)) {
/*      */       
/*  768 */       state.warning("reserved-type-name", new Object[] { QNameHelper.pretty(name) }, (XmlObject)xsdType);
/*  769 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  773 */     SchemaTypeImpl sType = new SchemaTypeImpl(state.getContainer(targetNamespace));
/*  774 */     sType.setParseContext((XmlObject)xsdType, targetNamespace, chameleon, null, null, redefinition);
/*  775 */     sType.setFilename(findFilename((XmlObject)xsdType));
/*  776 */     sType.setName(QNameHelper.forLNS(localname, targetNamespace));
/*  777 */     sType.setAnnotation(SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)xsdType));
/*  778 */     sType.setUserData(getUserData((XmlObject)xsdType));
/*  779 */     return sType;
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaTypeImpl translateGlobalSimpleType(TopLevelSimpleType xsdType, String targetNamespace, boolean chameleon, boolean redefinition) {
/*  784 */     StscState state = StscState.get();
/*      */     
/*  786 */     String localname = xsdType.getName();
/*  787 */     if (localname == null) {
/*      */       
/*  789 */       state.error("missing-name", new Object[] { "global type" }, (XmlObject)xsdType);
/*      */       
/*  791 */       return null;
/*      */     } 
/*  793 */     if (!XMLChar.isValidNCName(localname))
/*      */     {
/*  795 */       state.error("invalid-value", new Object[] { localname, "name" }, (XmlObject)xsdType.xgetName());
/*      */     }
/*      */ 
/*      */     
/*  799 */     QName name = QNameHelper.forLNS(localname, targetNamespace);
/*      */     
/*  801 */     if (isReservedTypeName(name)) {
/*      */       
/*  803 */       state.warning("reserved-type-name", new Object[] { QNameHelper.pretty(name) }, (XmlObject)xsdType);
/*  804 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  808 */     SchemaTypeImpl sType = new SchemaTypeImpl(state.getContainer(targetNamespace));
/*  809 */     sType.setSimpleType(true);
/*  810 */     sType.setParseContext((XmlObject)xsdType, targetNamespace, chameleon, null, null, redefinition);
/*  811 */     sType.setFilename(findFilename((XmlObject)xsdType));
/*  812 */     sType.setName(name);
/*  813 */     sType.setAnnotation(SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)xsdType));
/*  814 */     sType.setUserData(getUserData((XmlObject)xsdType));
/*  815 */     return sType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static SchemaTypeImpl translateAnonymousSimpleType(SimpleType typedef, String targetNamespace, boolean chameleon, String elemFormDefault, String attFormDefault, List anonymousTypes, SchemaType outerType) {
/*  822 */     StscState state = StscState.get();
/*  823 */     SchemaTypeImpl sType = new SchemaTypeImpl(state.getContainer(targetNamespace));
/*  824 */     sType.setSimpleType(true);
/*  825 */     sType.setParseContext((XmlObject)typedef, targetNamespace, chameleon, elemFormDefault, attFormDefault, false);
/*      */     
/*  827 */     sType.setOuterSchemaTypeRef(outerType.getRef());
/*  828 */     sType.setAnnotation(SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)typedef));
/*  829 */     sType.setUserData(getUserData((XmlObject)typedef));
/*  830 */     anonymousTypes.add(sType);
/*  831 */     return sType;
/*      */   }
/*      */ 
/*      */   
/*      */   static FormChoice findElementFormDefault(XmlObject obj) {
/*  836 */     XmlCursor cur = obj.newCursor();
/*  837 */     while (cur.getObject().schemaType() != SchemaDocument.Schema.type) {
/*  838 */       if (!cur.toParent())
/*  839 */         return null; 
/*  840 */     }  return ((SchemaDocument.Schema)cur.getObject()).xgetElementFormDefault();
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean uriMatch(String s1, String s2) {
/*  845 */     if (s1 == null)
/*  846 */       return (s2 == null || s2.equals("")); 
/*  847 */     if (s2 == null)
/*  848 */       return s1.equals(""); 
/*  849 */     return s1.equals(s2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copyGlobalElementToLocalElement(SchemaGlobalElement referenced, SchemaLocalElementImpl target) {
/*  855 */     target.setNameAndTypeRef(referenced.getName(), referenced.getType().getRef());
/*  856 */     target.setNillable(referenced.isNillable());
/*  857 */     target.setDefault(referenced.getDefaultText(), referenced.isFixed(), ((SchemaGlobalElementImpl)referenced).getParseObject());
/*  858 */     target.setIdentityConstraints(((SchemaLocalElementImpl)referenced).getIdentityConstraintRefs());
/*  859 */     target.setBlock(referenced.blockExtension(), referenced.blockRestriction(), referenced.blockSubstitution());
/*  860 */     target.setAbstract(referenced.isAbstract());
/*  861 */     target.setTransitionRules(((SchemaParticle)referenced).acceptedStartNames(), ((SchemaParticle)referenced).isSkippable());
/*      */     
/*  863 */     target.setAnnotation(referenced.getAnnotation());
/*      */   }
/*      */ 
/*      */   
/*      */   public static void copyGlobalAttributeToLocalAttribute(SchemaGlobalAttributeImpl referenced, SchemaLocalAttributeImpl target) {
/*  868 */     target.init(referenced.getName(), referenced.getTypeRef(), referenced.getUse(), referenced.getDefaultText(), referenced.getParseObject(), referenced._defaultValue, referenced.isFixed(), referenced.getWSDLArrayType(), referenced.getAnnotation(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SchemaLocalElementImpl translateElement(Element xsdElt, String targetNamespace, boolean chameleon, String elemFormDefault, String attFormDefault, List anonymousTypes, SchemaType outerType) {
/*      */     QName qname;
/*      */     SchemaLocalElementImpl impl;
/*      */     LocalSimpleType localSimpleType;
/*  887 */     StscState state = StscState.get();
/*      */     
/*  889 */     SchemaTypeImpl sgHead = null;
/*      */ 
/*      */     
/*  892 */     if (xsdElt.isSetSubstitutionGroup()) {
/*      */       
/*  894 */       sgHead = state.findDocumentType(xsdElt.getSubstitutionGroup(), ((SchemaTypeImpl)outerType).getChameleonNamespace(), targetNamespace);
/*      */ 
/*      */       
/*  897 */       if (sgHead != null) {
/*  898 */         StscResolver.resolveType(sgHead);
/*      */       }
/*      */     } 
/*  901 */     String name = xsdElt.getName();
/*  902 */     QName ref = xsdElt.getRef();
/*      */ 
/*      */     
/*  905 */     if (ref != null && name != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  910 */       state.error("src-element.2.1a", new Object[] { name }, (XmlObject)xsdElt.xgetRef());
/*      */       
/*  912 */       name = null;
/*      */     } 
/*  914 */     if (ref == null && name == null) {
/*      */       
/*  916 */       state.error("src-element.2.1b", (Object[])null, (XmlObject)xsdElt);
/*      */       
/*  918 */       return null;
/*      */     } 
/*  920 */     if (name != null && !XMLChar.isValidNCName(name))
/*      */     {
/*  922 */       state.error("invalid-value", new Object[] { name, "name" }, (XmlObject)xsdElt.xgetName());
/*      */     }
/*      */ 
/*      */     
/*  926 */     if (ref != null) {
/*      */       
/*  928 */       if (xsdElt.getType() != null)
/*      */       {
/*  930 */         state.error("src-element.2.2", new Object[] { "type" }, (XmlObject)xsdElt.xgetType());
/*      */       }
/*      */ 
/*      */       
/*  934 */       if (xsdElt.getSimpleType() != null)
/*      */       {
/*  936 */         state.error("src-element.2.2", new Object[] { "<simpleType>" }, (XmlObject)xsdElt.getSimpleType());
/*      */       }
/*      */ 
/*      */       
/*  940 */       if (xsdElt.getComplexType() != null)
/*      */       {
/*  942 */         state.error("src-element.2.2", new Object[] { "<complexType>" }, (XmlObject)xsdElt.getComplexType());
/*      */       }
/*      */ 
/*      */       
/*  946 */       if (xsdElt.getForm() != null)
/*      */       {
/*  948 */         state.error("src-element.2.2", new Object[] { "form" }, (XmlObject)xsdElt.xgetForm());
/*      */       }
/*      */ 
/*      */       
/*  952 */       if (xsdElt.sizeOfKeyArray() > 0)
/*      */       {
/*  954 */         state.warning("src-element.2.2", new Object[] { "<key>" }, (XmlObject)xsdElt);
/*      */       }
/*      */ 
/*      */       
/*  958 */       if (xsdElt.sizeOfKeyrefArray() > 0)
/*      */       {
/*  960 */         state.warning("src-element.2.2", new Object[] { "<keyref>" }, (XmlObject)xsdElt);
/*      */       }
/*      */ 
/*      */       
/*  964 */       if (xsdElt.sizeOfUniqueArray() > 0)
/*      */       {
/*  966 */         state.warning("src-element.2.2", new Object[] { "<unique>" }, (XmlObject)xsdElt);
/*      */       }
/*      */ 
/*      */       
/*  970 */       if (xsdElt.isSetDefault())
/*      */       {
/*  972 */         state.warning("src-element.2.2", new Object[] { "default" }, (XmlObject)xsdElt.xgetDefault());
/*      */       }
/*      */ 
/*      */       
/*  976 */       if (xsdElt.isSetFixed())
/*      */       {
/*  978 */         state.warning("src-element.2.2", new Object[] { "fixed" }, (XmlObject)xsdElt.xgetFixed());
/*      */       }
/*      */ 
/*      */       
/*  982 */       if (xsdElt.isSetBlock())
/*      */       {
/*  984 */         state.warning("src-element.2.2", new Object[] { "block" }, (XmlObject)xsdElt.xgetBlock());
/*      */       }
/*      */ 
/*      */       
/*  988 */       if (xsdElt.isSetNillable())
/*      */       {
/*  990 */         state.warning("src-element.2.2", new Object[] { "nillable" }, (XmlObject)xsdElt.xgetNillable());
/*      */       }
/*      */ 
/*      */       
/*  994 */       assert xsdElt instanceof org.apache.xmlbeans.impl.xb.xsdschema.LocalElement;
/*  995 */       SchemaGlobalElement referenced = state.findGlobalElement(ref, chameleon ? targetNamespace : null, targetNamespace);
/*  996 */       if (referenced == null) {
/*      */         
/*  998 */         state.notFoundError(ref, 1, (XmlObject)xsdElt.xgetRef(), true);
/*      */         
/* 1000 */         return null;
/*      */       } 
/* 1002 */       SchemaLocalElementImpl target = new SchemaLocalElementImpl();
/* 1003 */       target.setParticleType(4);
/* 1004 */       target.setUserData(getUserData((XmlObject)xsdElt));
/* 1005 */       copyGlobalElementToLocalElement(referenced, target);
/* 1006 */       return target;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1011 */     SchemaType sType = null;
/*      */     
/* 1013 */     if (xsdElt instanceof org.apache.xmlbeans.impl.xb.xsdschema.LocalElement) {
/*      */       
/* 1015 */       impl = new SchemaLocalElementImpl();
/* 1016 */       boolean qualified = false;
/* 1017 */       FormChoice form = xsdElt.xgetForm();
/* 1018 */       if (form != null) {
/* 1019 */         qualified = form.getStringValue().equals("qualified");
/* 1020 */       } else if (elemFormDefault != null) {
/* 1021 */         qualified = elemFormDefault.equals("qualified");
/*      */       } else {
/*      */         
/* 1024 */         form = findElementFormDefault((XmlObject)xsdElt);
/* 1025 */         qualified = (form != null && form.getStringValue().equals("qualified"));
/*      */       } 
/*      */       
/* 1028 */       qname = qualified ? QNameHelper.forLNS(name, targetNamespace) : QNameHelper.forLN(name);
/*      */     }
/*      */     else {
/*      */       
/* 1032 */       SchemaGlobalElementImpl gelt = new SchemaGlobalElementImpl(state.getContainer(targetNamespace));
/* 1033 */       impl = gelt;
/*      */ 
/*      */       
/* 1036 */       if (sgHead != null) {
/*      */         
/* 1038 */         SchemaGlobalElementImpl head = state.findGlobalElement(xsdElt.getSubstitutionGroup(), chameleon ? targetNamespace : null, targetNamespace);
/* 1039 */         if (head != null) {
/* 1040 */           gelt.setSubstitutionGroup(head.getRef());
/*      */         }
/*      */       } 
/*      */       
/* 1044 */       qname = QNameHelper.forLNS(name, targetNamespace);
/* 1045 */       SchemaTypeImpl docType = (SchemaTypeImpl)outerType;
/*      */       
/* 1047 */       QName[] sgMembers = docType.getSubstitutionGroupMembers();
/* 1048 */       QNameSetBuilder transitionRules = new QNameSetBuilder();
/* 1049 */       transitionRules.add(qname);
/*      */       
/* 1051 */       for (int m = 0; m < sgMembers.length; m++) {
/*      */         
/* 1053 */         gelt.addSubstitutionGroupMember(sgMembers[m]);
/* 1054 */         transitionRules.add(sgMembers[m]);
/*      */       } 
/*      */       
/* 1057 */       impl.setTransitionRules(QNameSet.forSpecification((QNameSetSpecification)transitionRules), false);
/* 1058 */       impl.setTransitionNotes(QNameSet.EMPTY, true);
/*      */       
/* 1060 */       boolean finalExt = false;
/* 1061 */       boolean finalRest = false;
/* 1062 */       Object ds = xsdElt.getFinal();
/* 1063 */       if (ds != null)
/*      */       {
/* 1065 */         if (ds instanceof String && ds.equals("#all")) {
/*      */ 
/*      */           
/* 1068 */           finalExt = finalRest = true;
/*      */         }
/* 1070 */         else if (ds instanceof List) {
/*      */           
/* 1072 */           if (((List)ds).contains("extension"))
/* 1073 */             finalExt = true; 
/* 1074 */           if (((List)ds).contains("restriction")) {
/* 1075 */             finalRest = true;
/*      */           }
/*      */         } 
/*      */       }
/* 1079 */       gelt.setFinal(finalExt, finalRest);
/* 1080 */       gelt.setAbstract(xsdElt.getAbstract());
/* 1081 */       gelt.setFilename(findFilename((XmlObject)xsdElt));
/* 1082 */       gelt.setParseContext((XmlObject)xsdElt, targetNamespace, chameleon);
/*      */     } 
/*      */     
/* 1085 */     SchemaAnnotationImpl ann = SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)xsdElt);
/* 1086 */     impl.setAnnotation(ann);
/* 1087 */     impl.setUserData(getUserData((XmlObject)xsdElt));
/* 1088 */     if (xsdElt.getType() != null) {
/*      */       
/* 1090 */       sType = state.findGlobalType(xsdElt.getType(), chameleon ? targetNamespace : null, targetNamespace);
/* 1091 */       if (sType == null) {
/* 1092 */         state.notFoundError(xsdElt.getType(), 0, (XmlObject)xsdElt.xgetType(), true);
/*      */       }
/*      */     } 
/* 1095 */     boolean simpleTypedef = false;
/* 1096 */     LocalComplexType localComplexType = xsdElt.getComplexType();
/* 1097 */     if (localComplexType == null) {
/*      */       
/* 1099 */       localSimpleType = xsdElt.getSimpleType();
/* 1100 */       simpleTypedef = true;
/*      */     } 
/*      */     
/* 1103 */     if (sType != null && localSimpleType != null) {
/*      */       
/* 1105 */       state.error("src-element.3", (Object[])null, (XmlObject)localSimpleType);
/* 1106 */       localSimpleType = null;
/*      */     } 
/*      */     
/* 1109 */     if (localSimpleType != null) {
/*      */       
/* 1111 */       Object[] grps = state.getCurrentProcessing();
/* 1112 */       QName[] context = new QName[grps.length];
/* 1113 */       for (int m = 0; m < context.length; m++) {
/* 1114 */         if (grps[m] instanceof SchemaModelGroupImpl)
/* 1115 */           context[m] = ((SchemaModelGroupImpl)grps[m]).getName(); 
/* 1116 */       }  SchemaType repeat = checkRecursiveGroupReference(context, qname, (SchemaTypeImpl)outerType);
/* 1117 */       if (repeat != null) {
/* 1118 */         sType = repeat;
/*      */       } else {
/*      */         
/* 1121 */         SchemaTypeImpl sTypeImpl = new SchemaTypeImpl(state.getContainer(targetNamespace));
/* 1122 */         sType = sTypeImpl;
/* 1123 */         sTypeImpl.setContainerField((SchemaField)impl);
/* 1124 */         sTypeImpl.setOuterSchemaTypeRef((outerType == null) ? null : outerType.getRef());
/* 1125 */         sTypeImpl.setGroupReferenceContext(context);
/*      */         
/* 1127 */         anonymousTypes.add(sType);
/* 1128 */         sTypeImpl.setSimpleType(simpleTypedef);
/* 1129 */         sTypeImpl.setParseContext((XmlObject)localSimpleType, targetNamespace, chameleon, elemFormDefault, attFormDefault, false);
/*      */         
/* 1131 */         sTypeImpl.setAnnotation(SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)localSimpleType));
/* 1132 */         sTypeImpl.setUserData(getUserData((XmlObject)localSimpleType));
/*      */       } 
/*      */     } 
/*      */     
/* 1136 */     if (sType == null)
/*      */     {
/*      */       
/* 1139 */       if (sgHead != null) {
/*      */         
/* 1141 */         SchemaGlobalElement head = state.findGlobalElement(xsdElt.getSubstitutionGroup(), chameleon ? targetNamespace : null, targetNamespace);
/*      */ 
/*      */ 
/*      */         
/* 1145 */         if (head != null) {
/* 1146 */           sType = head.getType();
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1153 */     if (sType == null) {
/* 1154 */       sType = BuiltinSchemaTypeSystem.ST_ANY_TYPE;
/*      */     }
/* 1156 */     SOAPArrayType wat = null;
/* 1157 */     XmlCursor c = xsdElt.newCursor();
/* 1158 */     String arrayType = c.getAttributeText(WSDL_ARRAYTYPE_NAME);
/* 1159 */     c.dispose();
/* 1160 */     if (arrayType != null) {
/*      */       
/*      */       try {
/*      */         
/* 1164 */         wat = new SOAPArrayType(arrayType, (PrefixResolver)new NamespaceContext((XmlObject)xsdElt));
/*      */       }
/* 1166 */       catch (XmlValueOutOfRangeException e) {
/*      */         
/* 1168 */         state.error("soaparray", new Object[] { arrayType }, (XmlObject)xsdElt);
/*      */       } 
/*      */     }
/* 1171 */     impl.setWsdlArrayType(wat);
/*      */     
/* 1173 */     boolean isFixed = xsdElt.isSetFixed();
/* 1174 */     if (xsdElt.isSetDefault() && isFixed) {
/*      */       
/* 1176 */       state.error("src-element.1", (Object[])null, (XmlObject)xsdElt.xgetFixed());
/*      */       
/* 1178 */       isFixed = false;
/*      */     } 
/* 1180 */     impl.setParticleType(4);
/* 1181 */     impl.setNameAndTypeRef(qname, sType.getRef());
/* 1182 */     impl.setNillable(xsdElt.getNillable());
/* 1183 */     impl.setDefault(isFixed ? xsdElt.getFixed() : xsdElt.getDefault(), isFixed, (XmlObject)xsdElt);
/*      */     
/* 1185 */     Object block = xsdElt.getBlock();
/* 1186 */     boolean blockExt = false;
/* 1187 */     boolean blockRest = false;
/* 1188 */     boolean blockSubst = false;
/*      */     
/* 1190 */     if (block != null)
/*      */     {
/* 1192 */       if (block instanceof String && block.equals("#all")) {
/*      */ 
/*      */         
/* 1195 */         blockExt = blockRest = blockSubst = true;
/*      */       }
/* 1197 */       else if (block instanceof List) {
/*      */         
/* 1199 */         if (((List)block).contains("extension"))
/* 1200 */           blockExt = true; 
/* 1201 */         if (((List)block).contains("restriction"))
/* 1202 */           blockRest = true; 
/* 1203 */         if (((List)block).contains("substitution")) {
/* 1204 */           blockSubst = true;
/*      */         }
/*      */       } 
/*      */     }
/* 1208 */     impl.setBlock(blockExt, blockRest, blockSubst);
/*      */     
/* 1210 */     boolean constraintFailed = false;
/*      */ 
/*      */ 
/*      */     
/* 1214 */     int length = xsdElt.sizeOfKeyArray() + xsdElt.sizeOfKeyrefArray() + xsdElt.sizeOfUniqueArray();
/* 1215 */     SchemaIdentityConstraintImpl[] constraints = new SchemaIdentityConstraintImpl[length];
/* 1216 */     int cur = 0;
/*      */ 
/*      */     
/* 1219 */     Keybase[] keys = xsdElt.getKeyArray();
/* 1220 */     for (int i = 0; i < keys.length; i++, cur++) {
/* 1221 */       constraints[cur] = translateIdentityConstraint(keys[i], targetNamespace, chameleon);
/* 1222 */       if (constraints[cur] != null) {
/* 1223 */         constraints[cur].setConstraintCategory(1);
/*      */       } else {
/* 1225 */         constraintFailed = true;
/*      */       } 
/*      */     } 
/*      */     
/* 1229 */     Keybase[] uc = xsdElt.getUniqueArray();
/* 1230 */     for (int j = 0; j < uc.length; j++, cur++) {
/* 1231 */       constraints[cur] = translateIdentityConstraint(uc[j], targetNamespace, chameleon);
/* 1232 */       if (constraints[cur] != null) {
/* 1233 */         constraints[cur].setConstraintCategory(3);
/*      */       } else {
/* 1235 */         constraintFailed = true;
/*      */       } 
/*      */     } 
/*      */     
/* 1239 */     KeyrefDocument.Keyref[] krs = xsdElt.getKeyrefArray();
/* 1240 */     for (int k = 0; k < krs.length; k++, cur++) {
/* 1241 */       constraints[cur] = translateIdentityConstraint((Keybase)krs[k], targetNamespace, chameleon);
/* 1242 */       if (constraints[cur] != null) {
/* 1243 */         constraints[cur].setConstraintCategory(2);
/*      */       } else {
/* 1245 */         constraintFailed = true;
/*      */       } 
/*      */     } 
/* 1248 */     if (!constraintFailed) {
/*      */       
/* 1250 */       SchemaIdentityConstraint.Ref[] refs = new SchemaIdentityConstraint.Ref[length];
/* 1251 */       for (int m = 0; m < refs.length; m++) {
/* 1252 */         refs[m] = constraints[m].getRef();
/*      */       }
/* 1254 */       impl.setIdentityConstraints(refs);
/*      */     } 
/*      */     
/* 1257 */     return impl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SchemaType checkRecursiveGroupReference(QName[] context, QName containingElement, SchemaTypeImpl outerType) {
/* 1285 */     if (context.length < 1)
/* 1286 */       return null; 
/* 1287 */     SchemaTypeImpl type = outerType;
/*      */     
/* 1289 */     while (type != null) {
/*      */       
/* 1291 */       if (type.getName() != null || type.isDocumentType())
/* 1292 */         return null; 
/* 1293 */       if (containingElement.equals(type.getContainerField().getName())) {
/*      */         
/* 1295 */         QName[] outerContext = type.getGroupReferenceContext();
/* 1296 */         if (outerContext != null && outerContext.length == context.length) {
/*      */ 
/*      */           
/* 1299 */           boolean equal = true;
/* 1300 */           for (int i = 0; i < context.length; i++) {
/* 1301 */             if ((context[i] != null || outerContext[i] != null) && (context[i] == null || !context[i].equals(outerContext[i]))) {
/*      */ 
/*      */               
/* 1304 */               equal = false; break;
/*      */             } 
/*      */           } 
/* 1307 */           if (equal)
/* 1308 */             return type; 
/*      */         } 
/*      */       } 
/* 1311 */       type = (SchemaTypeImpl)type.getOuterType();
/*      */     } 
/* 1313 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static String removeWhitespace(String xpath) {
/* 1318 */     StringBuffer sb = new StringBuffer();
/* 1319 */     for (int i = 0; i < xpath.length(); i++) {
/*      */       
/* 1321 */       char ch = xpath.charAt(i);
/* 1322 */       if (!XMLChar.isSpace(ch))
/*      */       {
/* 1324 */         sb.append(ch); } 
/*      */     } 
/* 1326 */     return sb.toString();
/*      */   }
/*      */   
/* 1329 */   public static final RegularExpression XPATH_REGEXP = new RegularExpression("(\\.//)?((((child::)?((\\i\\c*:)?(\\i\\c*|\\*)))|\\.)/)*((((child::)?((\\i\\c*:)?(\\i\\c*|\\*)))|\\.)|((attribute::|@)((\\i\\c*:)?(\\i\\c*|\\*))))(\\|(\\.//)?((((child::)?((\\i\\c*:)?(\\i\\c*|\\*)))|\\.)/)*((((child::)?((\\i\\c*:)?(\\i\\c*|\\*)))|\\.)|((attribute::|@)((\\i\\c*:)?(\\i\\c*|\\*)))))*", "X");
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   private static boolean checkXPathSyntax(String xpath) {
/* 1333 */     if (xpath == null) {
/* 1334 */       return false;
/*      */     }
/*      */     
/* 1337 */     xpath = removeWhitespace(xpath);
/*      */ 
/*      */     
/* 1340 */     synchronized (XPATH_REGEXP) {
/*      */       
/* 1342 */       return XPATH_REGEXP.matches(xpath);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static SchemaIdentityConstraintImpl translateIdentityConstraint(Keybase parseIC, String targetNamespace, boolean chameleon) {
/* 1349 */     StscState state = StscState.get();
/*      */ 
/*      */     
/* 1352 */     String selector = (parseIC.getSelector() == null) ? null : parseIC.getSelector().getXpath();
/* 1353 */     if (!checkXPathSyntax(selector)) {
/*      */       
/* 1355 */       state.error("c-selector-xpath", new Object[] { selector }, (XmlObject)parseIC.getSelector().xgetXpath());
/* 1356 */       return null;
/*      */     } 
/*      */     
/* 1359 */     FieldDocument.Field[] fieldElts = parseIC.getFieldArray();
/* 1360 */     for (int j = 0; j < fieldElts.length; j++) {
/*      */       
/* 1362 */       if (!checkXPathSyntax(fieldElts[j].getXpath())) {
/*      */         
/* 1364 */         state.error("c-fields-xpaths", new Object[] { fieldElts[j].getXpath() }, (XmlObject)fieldElts[j].xgetXpath());
/* 1365 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1370 */     SchemaIdentityConstraintImpl ic = new SchemaIdentityConstraintImpl(state.getContainer(targetNamespace));
/* 1371 */     ic.setName(QNameHelper.forLNS(parseIC.getName(), targetNamespace));
/* 1372 */     ic.setSelector(parseIC.getSelector().getXpath());
/* 1373 */     ic.setParseContext((XmlObject)parseIC, targetNamespace, chameleon);
/* 1374 */     SchemaAnnotationImpl ann = SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)parseIC);
/* 1375 */     ic.setAnnotation(ann);
/* 1376 */     ic.setUserData(getUserData((XmlObject)parseIC));
/*      */ 
/*      */     
/* 1379 */     XmlCursor c = parseIC.newCursor();
/* 1380 */     Map nsMap = new HashMap();
/*      */     
/* 1382 */     c.getAllNamespaces(nsMap);
/* 1383 */     nsMap.remove("");
/* 1384 */     ic.setNSMap(nsMap);
/* 1385 */     c.dispose();
/*      */     
/* 1387 */     String[] fields = new String[fieldElts.length];
/* 1388 */     for (int i = 0; i < fields.length; i++)
/* 1389 */       fields[i] = fieldElts[i].getXpath(); 
/* 1390 */     ic.setFields(fields);
/*      */     
/*      */     try {
/* 1393 */       ic.buildPaths();
/*      */     }
/* 1395 */     catch (org.apache.xmlbeans.impl.common.XPath.XPathCompileException e) {
/* 1396 */       state.error("invalid-xpath", new Object[] { e.getMessage() }, (XmlObject)parseIC);
/* 1397 */       return null;
/*      */     } 
/*      */     
/* 1400 */     state.addIdConstraint(ic);
/* 1401 */     ic.setFilename(findFilename((XmlObject)parseIC));
/*      */     
/* 1403 */     return state.findIdConstraint(ic.getName(), targetNamespace, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SchemaModelGroupImpl translateModelGroup(NamedGroup namedGroup, String targetNamespace, boolean chameleon, boolean redefinition) {
/* 1409 */     String name = namedGroup.getName();
/* 1410 */     if (name == null) {
/*      */       
/* 1412 */       StscState.get().error("missing-name", new Object[] { "model group" }, (XmlObject)namedGroup);
/* 1413 */       return null;
/*      */     } 
/* 1415 */     SchemaContainer c = StscState.get().getContainer(targetNamespace);
/* 1416 */     SchemaModelGroupImpl result = new SchemaModelGroupImpl(c);
/* 1417 */     SchemaAnnotationImpl ann = SchemaAnnotationImpl.getAnnotation(c, (Annotated)namedGroup);
/* 1418 */     FormChoice elemFormDefault = findElementFormDefault((XmlObject)namedGroup);
/* 1419 */     FormChoice attFormDefault = findAttributeFormDefault((XmlObject)namedGroup);
/* 1420 */     result.init(QNameHelper.forLNS(name, targetNamespace), targetNamespace, chameleon, (elemFormDefault == null) ? null : elemFormDefault.getStringValue(), (attFormDefault == null) ? null : attFormDefault.getStringValue(), redefinition, (XmlObject)namedGroup, ann, getUserData((XmlObject)namedGroup));
/*      */ 
/*      */ 
/*      */     
/* 1424 */     result.setFilename(findFilename((XmlObject)namedGroup));
/* 1425 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SchemaAttributeGroupImpl translateAttributeGroup(AttributeGroup attrGroup, String targetNamespace, boolean chameleon, boolean redefinition) {
/* 1430 */     String name = attrGroup.getName();
/* 1431 */     if (name == null) {
/*      */       
/* 1433 */       StscState.get().error("missing-name", new Object[] { "attribute group" }, (XmlObject)attrGroup);
/* 1434 */       return null;
/*      */     } 
/* 1436 */     SchemaContainer c = StscState.get().getContainer(targetNamespace);
/* 1437 */     SchemaAttributeGroupImpl result = new SchemaAttributeGroupImpl(c);
/* 1438 */     SchemaAnnotationImpl ann = SchemaAnnotationImpl.getAnnotation(c, (Annotated)attrGroup);
/* 1439 */     FormChoice formDefault = findAttributeFormDefault((XmlObject)attrGroup);
/* 1440 */     result.init(QNameHelper.forLNS(name, targetNamespace), targetNamespace, chameleon, (formDefault == null) ? null : formDefault.getStringValue(), redefinition, (XmlObject)attrGroup, ann, getUserData((XmlObject)attrGroup));
/*      */ 
/*      */     
/* 1443 */     result.setFilename(findFilename((XmlObject)attrGroup));
/* 1444 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static FormChoice findAttributeFormDefault(XmlObject obj) {
/* 1449 */     XmlCursor cur = obj.newCursor();
/* 1450 */     while (cur.getObject().schemaType() != SchemaDocument.Schema.type) {
/* 1451 */       if (!cur.toParent())
/* 1452 */         return null; 
/* 1453 */     }  return ((SchemaDocument.Schema)cur.getObject()).xgetAttributeFormDefault();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static SchemaLocalAttributeImpl translateAttribute(Attribute xsdAttr, String targetNamespace, String formDefault, boolean chameleon, List anonymousTypes, SchemaType outerType, SchemaAttributeModel baseModel, boolean local) {
/*      */     QName qname;
/*      */     SchemaLocalAttributeImpl sAttr;
/* 1461 */     StscState state = StscState.get();
/*      */     
/* 1463 */     String name = xsdAttr.getName();
/* 1464 */     QName ref = xsdAttr.getRef();
/*      */     
/* 1466 */     if (ref != null && name != null) {
/*      */       
/* 1468 */       if (name.equals(ref.getLocalPart()) && uriMatch(targetNamespace, ref.getNamespaceURI())) {
/* 1469 */         state.warning("src-attribute.3.1a", new Object[] { name }, (XmlObject)xsdAttr.xgetRef());
/*      */       } else {
/* 1471 */         state.error("src-attribute.3.1a", new Object[] { name }, (XmlObject)xsdAttr.xgetRef());
/*      */       } 
/* 1473 */       name = null;
/*      */     } 
/* 1475 */     if (ref == null && name == null) {
/*      */       
/* 1477 */       state.error("src-attribute.3.1b", (Object[])null, (XmlObject)xsdAttr);
/*      */       
/* 1479 */       return null;
/*      */     } 
/* 1481 */     if (name != null && !XMLChar.isValidNCName(name))
/*      */     {
/* 1483 */       state.error("invalid-value", new Object[] { name, "name" }, (XmlObject)xsdAttr.xgetName());
/*      */     }
/*      */ 
/*      */     
/* 1487 */     boolean isFixed = false;
/* 1488 */     String deftext = null;
/* 1489 */     String fmrfixedtext = null;
/*      */ 
/*      */     
/* 1492 */     SchemaType sType = null;
/* 1493 */     int use = 2;
/*      */     
/* 1495 */     if (local) {
/* 1496 */       sAttr = new SchemaLocalAttributeImpl();
/*      */     } else {
/*      */       
/* 1499 */       sAttr = new SchemaGlobalAttributeImpl(StscState.get().getContainer(targetNamespace));
/* 1500 */       ((SchemaGlobalAttributeImpl)sAttr).setParseContext((XmlObject)xsdAttr, targetNamespace, chameleon);
/*      */     } 
/*      */     
/* 1503 */     if (ref != null) {
/*      */       
/* 1505 */       if (xsdAttr.getType() != null)
/*      */       {
/* 1507 */         state.error("src-attribute.3.2", new Object[] { "type" }, (XmlObject)xsdAttr.xgetType());
/*      */       }
/*      */ 
/*      */       
/* 1511 */       if (xsdAttr.getSimpleType() != null)
/*      */       {
/* 1513 */         state.error("src-attribute.3.2", new Object[] { "<simpleType>" }, (XmlObject)xsdAttr.getSimpleType());
/*      */       }
/*      */ 
/*      */       
/* 1517 */       if (xsdAttr.getForm() != null)
/*      */       {
/* 1519 */         state.error("src-attribute.3.2", new Object[] { "form" }, (XmlObject)xsdAttr.xgetForm());
/*      */       }
/*      */ 
/*      */       
/* 1523 */       SchemaGlobalAttribute referenced = state.findGlobalAttribute(ref, chameleon ? targetNamespace : null, targetNamespace);
/* 1524 */       if (referenced == null) {
/*      */         
/* 1526 */         state.notFoundError(ref, 3, (XmlObject)xsdAttr.xgetRef(), true);
/*      */         
/* 1528 */         return null;
/*      */       } 
/*      */       
/* 1531 */       qname = ref;
/* 1532 */       use = referenced.getUse();
/* 1533 */       sType = referenced.getType();
/* 1534 */       deftext = referenced.getDefaultText();
/* 1535 */       if (deftext != null) {
/*      */         
/* 1537 */         isFixed = referenced.isFixed();
/* 1538 */         if (isFixed) {
/* 1539 */           fmrfixedtext = deftext;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 1544 */       if (local) {
/*      */         
/* 1546 */         boolean qualified = false;
/* 1547 */         FormChoice form = xsdAttr.xgetForm();
/* 1548 */         if (form != null) {
/* 1549 */           qualified = form.getStringValue().equals("qualified");
/* 1550 */         } else if (formDefault != null) {
/* 1551 */           qualified = formDefault.equals("qualified");
/*      */         } else {
/*      */           
/* 1554 */           form = findAttributeFormDefault((XmlObject)xsdAttr);
/* 1555 */           qualified = (form != null && form.getStringValue().equals("qualified"));
/*      */         } 
/*      */         
/* 1558 */         qname = qualified ? QNameHelper.forLNS(name, targetNamespace) : QNameHelper.forLN(name);
/*      */       }
/*      */       else {
/*      */         
/* 1562 */         qname = QNameHelper.forLNS(name, targetNamespace);
/*      */       } 
/*      */       
/* 1565 */       if (xsdAttr.getType() != null) {
/*      */         
/* 1567 */         sType = state.findGlobalType(xsdAttr.getType(), chameleon ? targetNamespace : null, targetNamespace);
/* 1568 */         if (sType == null) {
/* 1569 */           state.notFoundError(xsdAttr.getType(), 0, (XmlObject)xsdAttr.xgetType(), true);
/*      */         }
/*      */       } 
/* 1572 */       if (qname.getNamespaceURI().equals("http://www.w3.org/2001/XMLSchema-instance"))
/*      */       {
/* 1574 */         state.error("no-xsi", new Object[] { "http://www.w3.org/2001/XMLSchema-instance" }, (XmlObject)xsdAttr.xgetName());
/*      */       }
/*      */       
/* 1577 */       if (qname.getNamespaceURI().length() == 0 && qname.getLocalPart().equals("xmlns"))
/*      */       {
/* 1579 */         state.error("no-xmlns", (Object[])null, (XmlObject)xsdAttr.xgetName());
/*      */       }
/*      */       
/* 1582 */       LocalSimpleType typedef = xsdAttr.getSimpleType();
/*      */       
/* 1584 */       if (sType != null && typedef != null) {
/*      */         
/* 1586 */         state.error("src-attribute.4", (Object[])null, (XmlObject)typedef);
/* 1587 */         typedef = null;
/*      */       } 
/*      */       
/* 1590 */       if (typedef != null) {
/*      */         
/* 1592 */         SchemaTypeImpl sTypeImpl = new SchemaTypeImpl(state.getContainer(targetNamespace));
/* 1593 */         sType = sTypeImpl;
/* 1594 */         sTypeImpl.setContainerField((SchemaField)sAttr);
/* 1595 */         sTypeImpl.setOuterSchemaTypeRef((outerType == null) ? null : outerType.getRef());
/*      */         
/* 1597 */         anonymousTypes.add(sType);
/* 1598 */         sTypeImpl.setSimpleType(true);
/* 1599 */         sTypeImpl.setParseContext((XmlObject)typedef, targetNamespace, chameleon, null, null, false);
/* 1600 */         sTypeImpl.setAnnotation(SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)typedef));
/* 1601 */         sTypeImpl.setUserData(getUserData((XmlObject)typedef));
/*      */       } 
/*      */       
/* 1604 */       if (sType == null && baseModel != null && baseModel.getAttribute(qname) != null) {
/* 1605 */         sType = baseModel.getAttribute(qname).getType();
/*      */       }
/*      */     } 
/* 1608 */     if (sType == null) {
/* 1609 */       sType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/* 1611 */     if (!sType.isSimpleType()) {
/*      */ 
/*      */       
/* 1614 */       state.error("Attributes must have a simple type (not complex).", 46, (XmlObject)xsdAttr);
/*      */       
/* 1616 */       sType = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     } 
/*      */     
/* 1619 */     if (xsdAttr.isSetUse()) {
/*      */       
/* 1621 */       use = translateUseCode(xsdAttr.xgetUse());
/*      */ 
/*      */       
/* 1624 */       if (use != 2 && !isFixed) {
/* 1625 */         deftext = null;
/*      */       }
/*      */     } 
/* 1628 */     if (xsdAttr.isSetDefault() || xsdAttr.isSetFixed()) {
/*      */       
/* 1630 */       if (isFixed && !xsdAttr.isSetFixed()) {
/* 1631 */         state.error("A use of a fixed attribute definition must also be fixed", 9, (XmlObject)xsdAttr.xgetFixed());
/*      */       }
/* 1633 */       isFixed = xsdAttr.isSetFixed();
/*      */       
/* 1635 */       if (xsdAttr.isSetDefault() && isFixed) {
/*      */         
/* 1637 */         state.error("src-attribute.1", (Object[])null, (XmlObject)xsdAttr.xgetFixed());
/*      */         
/* 1639 */         isFixed = false;
/*      */       } 
/* 1641 */       deftext = isFixed ? xsdAttr.getFixed() : xsdAttr.getDefault();
/*      */ 
/*      */       
/* 1644 */       if (fmrfixedtext != null && !fmrfixedtext.equals(deftext)) {
/*      */         
/* 1646 */         state.error("au-value_constraint", (Object[])null, (XmlObject)xsdAttr.xgetFixed());
/*      */         
/* 1648 */         deftext = fmrfixedtext;
/*      */       } 
/*      */     } 
/*      */     
/* 1652 */     if (!local)
/*      */     {
/* 1654 */       ((SchemaGlobalAttributeImpl)sAttr).setFilename(findFilename((XmlObject)xsdAttr));
/*      */     }
/*      */     
/* 1657 */     SOAPArrayType wat = null;
/* 1658 */     XmlCursor c = xsdAttr.newCursor();
/* 1659 */     String arrayType = c.getAttributeText(WSDL_ARRAYTYPE_NAME);
/* 1660 */     c.dispose();
/* 1661 */     if (arrayType != null) {
/*      */       
/*      */       try {
/*      */         
/* 1665 */         wat = new SOAPArrayType(arrayType, (PrefixResolver)new NamespaceContext((XmlObject)xsdAttr));
/*      */       }
/* 1667 */       catch (XmlValueOutOfRangeException e) {
/*      */         
/* 1669 */         state.error("soaparray", new Object[] { arrayType }, (XmlObject)xsdAttr);
/*      */       } 
/*      */     }
/*      */     
/* 1673 */     SchemaAnnotationImpl ann = SchemaAnnotationImpl.getAnnotation(state.getContainer(targetNamespace), (Annotated)xsdAttr);
/* 1674 */     sAttr.init(qname, sType.getRef(), use, deftext, (XmlObject)xsdAttr, null, isFixed, wat, ann, getUserData((XmlObject)xsdAttr));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1681 */     return sAttr;
/*      */   }
/*      */ 
/*      */   
/*      */   static int translateUseCode(Attribute.Use attruse) {
/* 1686 */     if (attruse == null) {
/* 1687 */       return 2;
/*      */     }
/* 1689 */     String val = attruse.getStringValue();
/* 1690 */     if (val.equals("optional"))
/* 1691 */       return 2; 
/* 1692 */     if (val.equals("required"))
/* 1693 */       return 3; 
/* 1694 */     if (val.equals("prohibited"))
/* 1695 */       return 1; 
/* 1696 */     return 2;
/*      */   }
/*      */   
/*      */   static BigInteger buildBigInt(XmlAnySimpleType value) {
/*      */     BigInteger bigInt;
/* 1701 */     if (value == null)
/* 1702 */       return null; 
/* 1703 */     String text = value.getStringValue();
/*      */ 
/*      */     
/*      */     try {
/* 1707 */       bigInt = new BigInteger(text);
/*      */     }
/* 1709 */     catch (NumberFormatException e) {
/*      */       
/* 1711 */       StscState.get().error("invalid-value-detail", new Object[] { text, "nonNegativeInteger", e.getMessage() }, (XmlObject)value);
/* 1712 */       return null;
/*      */     } 
/*      */     
/* 1715 */     if (bigInt.signum() < 0) {
/*      */       
/* 1717 */       StscState.get().error("invalid-value", new Object[] { text, "nonNegativeInteger" }, (XmlObject)value);
/* 1718 */       return null;
/*      */     } 
/*      */     
/* 1721 */     return bigInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static XmlNonNegativeInteger buildNnInteger(XmlAnySimpleType value) {
/* 1727 */     BigInteger bigInt = buildBigInt(value);
/*      */     
/*      */     try {
/* 1730 */       XmlNonNegativeIntegerImpl i = new XmlNonNegativeIntegerImpl();
/* 1731 */       i.set(bigInt);
/* 1732 */       i.setImmutable();
/* 1733 */       return (XmlNonNegativeInteger)i;
/*      */     }
/* 1735 */     catch (XmlValueOutOfRangeException e) {
/*      */       
/* 1737 */       StscState.get().error("Internal error processing number", 21, (XmlObject)value);
/* 1738 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static XmlPositiveInteger buildPosInteger(XmlAnySimpleType value) {
/* 1744 */     BigInteger bigInt = buildBigInt(value);
/*      */     
/*      */     try {
/* 1747 */       XmlPositiveIntegerImpl i = new XmlPositiveIntegerImpl();
/* 1748 */       i.set(bigInt);
/* 1749 */       i.setImmutable();
/* 1750 */       return (XmlPositiveInteger)i;
/*      */     }
/* 1752 */     catch (XmlValueOutOfRangeException e) {
/*      */       
/* 1754 */       StscState.get().error("Internal error processing number", 21, (XmlObject)value);
/* 1755 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object getUserData(XmlObject pos) {
/* 1762 */     XmlCursor.XmlBookmark b = pos.newCursor().getBookmark(SchemaBookmark.class);
/* 1763 */     if (b != null && b instanceof SchemaBookmark) {
/* 1764 */       return ((SchemaBookmark)b).getValue();
/*      */     }
/* 1766 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isEmptySchema(SchemaDocument.Schema schema) {
/* 1771 */     XmlCursor cursor = schema.newCursor();
/* 1772 */     boolean result = !cursor.toFirstChild();
/* 1773 */     cursor.dispose();
/* 1774 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isReservedTypeName(QName name) {
/* 1779 */     return (BuiltinSchemaTypeSystem.get().findType(name) != null);
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscTranslator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */