/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.QNameSet;
/*     */ import org.apache.xmlbeans.SchemaParticle;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.impl.values.NamespaceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaParticleImpl
/*     */   implements SchemaParticle
/*     */ {
/*     */   private int _particleType;
/*     */   private BigInteger _minOccurs;
/*     */   private BigInteger _maxOccurs;
/*     */   private SchemaParticle[] _particleChildren;
/*     */   private boolean _isImmutable;
/*     */   private QNameSet _startSet;
/*     */   private QNameSet _excludeNextSet;
/*     */   private boolean _isSkippable;
/*     */   private boolean _isDeterministic;
/*     */   private int _intMinOccurs;
/*     */   private int _intMaxOccurs;
/*     */   private QNameSet _wildcardSet;
/*     */   private int _wildcardProcess;
/*     */   private String _defaultText;
/*     */   private boolean _isDefault;
/*     */   private boolean _isFixed;
/*     */   private QName _qName;
/*     */   private boolean _isNillable;
/*     */   private SchemaType.Ref _typeref;
/*     */   protected XmlObject _parseObject;
/*     */   private Object _userData;
/*     */   private XmlValueRef _defaultValue;
/*     */   
/*     */   protected void mutate() {
/*  56 */     if (this._isImmutable) throw new IllegalStateException(); 
/*     */   }
/*     */   public void setImmutable() {
/*  59 */     mutate(); this._isImmutable = true;
/*     */   }
/*     */   public boolean hasTransitionRules() {
/*  62 */     return (this._startSet != null);
/*     */   }
/*     */   public boolean hasTransitionNotes() {
/*  65 */     return (this._excludeNextSet != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransitionRules(QNameSet start, boolean isSkippable) {
/*  70 */     this._startSet = start;
/*  71 */     this._isSkippable = isSkippable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransitionNotes(QNameSet excludeNext, boolean isDeterministic) {
/*  76 */     this._excludeNextSet = excludeNext;
/*  77 */     this._isDeterministic = isDeterministic;
/*     */   }
/*     */   
/*     */   public boolean canStartWithElement(QName name) {
/*  81 */     return (name != null && this._startSet.contains(name));
/*     */   }
/*     */   public QNameSet acceptedStartNames() {
/*  84 */     return this._startSet;
/*     */   }
/*     */   public QNameSet getExcludeNextSet() {
/*  87 */     return this._excludeNextSet;
/*     */   }
/*     */   public boolean isSkippable() {
/*  90 */     return this._isSkippable;
/*     */   }
/*     */   public boolean isDeterministic() {
/*  93 */     return this._isDeterministic;
/*     */   }
/*     */   public int getParticleType() {
/*  96 */     return this._particleType;
/*     */   }
/*     */   public void setParticleType(int pType) {
/*  99 */     mutate(); this._particleType = pType;
/*     */   }
/*     */   public boolean isSingleton() {
/* 102 */     return (this._maxOccurs != null && this._maxOccurs.compareTo(BigInteger.ONE) == 0 && this._minOccurs.compareTo(BigInteger.ONE) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger getMinOccurs() {
/* 107 */     return this._minOccurs;
/*     */   }
/*     */   public void setMinOccurs(BigInteger min) {
/* 110 */     mutate(); this._minOccurs = min; this._intMinOccurs = pegBigInteger(min);
/*     */   }
/*     */   public int getIntMinOccurs() {
/* 113 */     return this._intMinOccurs;
/*     */   }
/*     */   public BigInteger getMaxOccurs() {
/* 116 */     return this._maxOccurs;
/*     */   }
/*     */   public int getIntMaxOccurs() {
/* 119 */     return this._intMaxOccurs;
/*     */   }
/*     */   public void setMaxOccurs(BigInteger max) {
/* 122 */     mutate(); this._maxOccurs = max; this._intMaxOccurs = pegBigInteger(max);
/*     */   }
/*     */   
/*     */   public SchemaParticle[] getParticleChildren() {
/* 126 */     if (this._particleChildren == null) {
/*     */       
/* 128 */       assert this._particleType != 1 && this._particleType != 3 && this._particleType != 2;
/*     */ 
/*     */       
/* 131 */       return null;
/*     */     } 
/* 133 */     SchemaParticle[] result = new SchemaParticle[this._particleChildren.length];
/* 134 */     System.arraycopy(this._particleChildren, 0, result, 0, this._particleChildren.length);
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public void setParticleChildren(SchemaParticle[] children) {
/* 139 */     mutate(); this._particleChildren = children;
/*     */   }
/*     */   public SchemaParticle getParticleChild(int i) {
/* 142 */     return this._particleChildren[i];
/*     */   }
/*     */   public int countOfParticleChild() {
/* 145 */     return (this._particleChildren == null) ? 0 : this._particleChildren.length;
/*     */   }
/*     */   public void setWildcardSet(QNameSet set) {
/* 148 */     mutate(); this._wildcardSet = set;
/*     */   }
/*     */   public QNameSet getWildcardSet() {
/* 151 */     return this._wildcardSet;
/*     */   }
/*     */   public void setWildcardProcess(int process) {
/* 154 */     mutate(); this._wildcardProcess = process;
/*     */   }
/*     */   public int getWildcardProcess() {
/* 157 */     return this._wildcardProcess;
/*     */   }
/* 159 */   private static final BigInteger _maxint = BigInteger.valueOf(2147483647L);
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static final int pegBigInteger(BigInteger bi) {
/* 163 */     if (bi == null)
/* 164 */       return Integer.MAX_VALUE; 
/* 165 */     if (bi.signum() <= 0)
/* 166 */       return 0; 
/* 167 */     if (bi.compareTo(_maxint) >= 0)
/* 168 */       return Integer.MAX_VALUE; 
/* 169 */     return bi.intValue();
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 173 */     return this._qName;
/*     */   }
/*     */   public void setNameAndTypeRef(QName formname, SchemaType.Ref typeref) {
/* 176 */     mutate(); this._qName = formname; this._typeref = typeref;
/*     */   }
/*     */   
/*     */   public boolean isTypeResolved() {
/* 180 */     return (this._typeref != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveTypeRef(SchemaType.Ref typeref) {
/* 185 */     if (this._typeref != null)
/* 186 */       throw new IllegalStateException(); 
/* 187 */     this._typeref = typeref;
/*     */   }
/*     */   
/*     */   public boolean isAttribute() {
/* 191 */     return false;
/*     */   }
/*     */   public SchemaType getType() {
/* 194 */     return (this._typeref == null) ? null : this._typeref.get();
/*     */   }
/*     */   public String getDefaultText() {
/* 197 */     return this._defaultText;
/*     */   }
/*     */   public boolean isDefault() {
/* 200 */     return this._isDefault;
/*     */   }
/*     */   public boolean isFixed() {
/* 203 */     return this._isFixed;
/*     */   }
/*     */   
/*     */   public void setDefault(String deftext, boolean isFixed, XmlObject parseObject) {
/* 207 */     mutate();
/* 208 */     this._defaultText = deftext;
/* 209 */     this._isDefault = (deftext != null);
/* 210 */     this._isFixed = isFixed;
/* 211 */     this._parseObject = parseObject;
/*     */   }
/*     */   
/*     */   public boolean isNillable() {
/* 215 */     return this._isNillable;
/*     */   }
/*     */   public void setNillable(boolean nillable) {
/* 218 */     mutate(); this._isNillable = nillable;
/*     */   }
/*     */   
/*     */   public XmlAnySimpleType getDefaultValue() {
/* 222 */     if (this._defaultValue != null)
/* 223 */       return this._defaultValue.get(); 
/* 224 */     if (this._defaultText != null && XmlAnySimpleType.type.isAssignableFrom(getType())) {
/*     */       
/* 226 */       if (this._parseObject != null && XmlQName.type.isAssignableFrom(getType())) {
/*     */         
/*     */         try {
/*     */           
/* 230 */           NamespaceContext.push(new NamespaceContext(this._parseObject));
/* 231 */           return getType().newValue(this._defaultText);
/*     */         }
/*     */         finally {
/*     */           
/* 235 */           NamespaceContext.pop();
/*     */         } 
/*     */       }
/* 238 */       return getType().newValue(this._defaultText);
/*     */     } 
/* 240 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultValue(XmlValueRef defaultRef) {
/* 245 */     mutate();
/* 246 */     this._defaultValue = defaultRef;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getUserData() {
/* 251 */     return this._userData;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUserData(Object data) {
/* 256 */     this._userData = data;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaParticleImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */