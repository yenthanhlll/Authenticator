/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.QNameSet;
/*     */ import org.apache.xmlbeans.SchemaAttributeModel;
/*     */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaAttributeModelImpl
/*     */   implements SchemaAttributeModel
/*     */ {
/*     */   private Map attrMap;
/*     */   private QNameSet wcSet;
/*     */   private int wcProcess;
/*     */   
/*     */   public SchemaAttributeModelImpl() {
/*  36 */     this.attrMap = new LinkedHashMap();
/*  37 */     this.wcSet = null;
/*  38 */     this.wcProcess = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAttributeModelImpl(SchemaAttributeModel sam) {
/*  43 */     this.attrMap = new LinkedHashMap();
/*  44 */     if (sam == null) {
/*     */       
/*  46 */       this.wcSet = null;
/*  47 */       this.wcProcess = 0;
/*     */     }
/*     */     else {
/*     */       
/*  51 */       SchemaLocalAttribute[] attrs = sam.getAttributes();
/*  52 */       for (int i = 0; i < attrs.length; i++)
/*     */       {
/*  54 */         this.attrMap.put(attrs[i].getName(), attrs[i]);
/*     */       }
/*     */       
/*  57 */       if (sam.getWildcardProcess() != 0) {
/*     */         
/*  59 */         this.wcSet = sam.getWildcardSet();
/*  60 */         this.wcProcess = sam.getWildcardProcess();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*  65 */   private static final SchemaLocalAttribute[] EMPTY_SLA_ARRAY = new SchemaLocalAttribute[0];
/*     */ 
/*     */   
/*     */   public SchemaLocalAttribute[] getAttributes() {
/*  69 */     return (SchemaLocalAttribute[])this.attrMap.values().toArray((Object[])EMPTY_SLA_ARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaLocalAttribute getAttribute(QName name) {
/*  74 */     return (SchemaLocalAttribute)this.attrMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAttribute(SchemaLocalAttribute attruse) {
/*  79 */     this.attrMap.put(attruse.getName(), attruse);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeProhibitedAttribute(QName name) {
/*  84 */     this.attrMap.remove(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameSet getWildcardSet() {
/*  89 */     return (this.wcSet == null) ? QNameSet.EMPTY : this.wcSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWildcardSet(QNameSet set) {
/*  94 */     this.wcSet = set;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWildcardProcess() {
/*  99 */     return this.wcProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWildcardProcess(int proc) {
/* 104 */     this.wcProcess = proc;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaAttributeModelImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */