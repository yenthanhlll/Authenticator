/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.CharArrayWriter;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.xmlbeans.SchemaTypeLoader;
/*      */ import org.apache.xmlbeans.XmlException;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.common.IOUtil;
/*      */ import org.apache.xmlbeans.impl.common.XmlEncodingSniffer;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ImportDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.IncludeDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.RedefineDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StscImporter
/*      */ {
/*      */   private static final String PROJECT_URL_PREFIX = "project://local";
/*      */   
/*      */   public static SchemaToProcess[] resolveImportsAndIncludes(SchemaDocument.Schema[] startWith, boolean forceSrcSave) {
/*   65 */     DownloadTable engine = new DownloadTable(startWith);
/*   66 */     return engine.resolveImportsAndIncludes(forceSrcSave);
/*      */   }
/*      */ 
/*      */   
/*      */   public static class SchemaToProcess
/*      */   {
/*      */     private SchemaDocument.Schema schema;
/*      */     private String chameleonNamespace;
/*      */     private List includes;
/*      */     private List redefines;
/*      */     private List redefineObjects;
/*      */     private Set indirectIncludes;
/*      */     private Set indirectIncludedBy;
/*      */     
/*      */     public SchemaToProcess(SchemaDocument.Schema schema, String chameleonNamespace) {
/*   81 */       this.schema = schema;
/*   82 */       this.chameleonNamespace = chameleonNamespace;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SchemaDocument.Schema getSchema() {
/*   90 */       return this.schema;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getSourceName() {
/*   98 */       return this.schema.documentProperties().getSourceName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getChameleonNamespace() {
/*  108 */       return this.chameleonNamespace;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List getRedefines() {
/*  120 */       return this.redefines;
/*      */     }
/*      */ 
/*      */     
/*      */     public List getRedefineObjects() {
/*  125 */       return this.redefineObjects;
/*      */     }
/*      */ 
/*      */     
/*      */     private void addInclude(SchemaToProcess include) {
/*  130 */       if (this.includes == null)
/*  131 */         this.includes = new ArrayList(); 
/*  132 */       this.includes.add(include);
/*      */     }
/*      */ 
/*      */     
/*      */     private void addRedefine(SchemaToProcess redefine, RedefineDocument.Redefine object) {
/*  137 */       if (this.redefines == null || this.redefineObjects == null) {
/*      */         
/*  139 */         this.redefines = new ArrayList();
/*  140 */         this.redefineObjects = new ArrayList();
/*      */       } 
/*  142 */       this.redefines.add(redefine);
/*  143 */       this.redefineObjects.add(object);
/*      */     }
/*      */ 
/*      */     
/*      */     private void buildIndirectReferences() {
/*  148 */       if (this.includes != null) {
/*  149 */         for (int i = 0; i < this.includes.size(); i++) {
/*      */           
/*  151 */           SchemaToProcess schemaToProcess = this.includes.get(i);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  156 */           addIndirectIncludes(schemaToProcess);
/*      */         } 
/*      */       }
/*  159 */       if (this.redefines != null) {
/*  160 */         for (int i = 0; i < this.redefines.size(); i++) {
/*      */           
/*  162 */           SchemaToProcess schemaToProcess = this.redefines.get(i);
/*  163 */           addIndirectIncludes(schemaToProcess);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     private void addIndirectIncludes(SchemaToProcess schemaToProcess) {
/*  169 */       if (this.indirectIncludes == null)
/*  170 */         this.indirectIncludes = new HashSet(); 
/*  171 */       this.indirectIncludes.add(schemaToProcess);
/*  172 */       if (schemaToProcess.indirectIncludedBy == null)
/*  173 */         schemaToProcess.indirectIncludedBy = new HashSet(); 
/*  174 */       schemaToProcess.indirectIncludedBy.add(this);
/*  175 */       addIndirectIncludesHelper(this, schemaToProcess);
/*  176 */       if (this.indirectIncludedBy != null) {
/*  177 */         for (Iterator it = this.indirectIncludedBy.iterator(); it.hasNext(); ) {
/*      */           
/*  179 */           SchemaToProcess stp = it.next();
/*  180 */           stp.indirectIncludes.add(schemaToProcess);
/*  181 */           schemaToProcess.indirectIncludedBy.add(stp);
/*  182 */           addIndirectIncludesHelper(stp, schemaToProcess);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     private static void addIndirectIncludesHelper(SchemaToProcess including, SchemaToProcess schemaToProcess) {
/*  189 */       if (schemaToProcess.indirectIncludes != null) {
/*  190 */         for (Iterator it = schemaToProcess.indirectIncludes.iterator(); it.hasNext(); ) {
/*      */           
/*  192 */           SchemaToProcess stp = it.next();
/*  193 */           including.indirectIncludes.add(stp);
/*  194 */           stp.indirectIncludedBy.add(including);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean indirectIncludes(SchemaToProcess schemaToProcess) {
/*  200 */       return (this.indirectIncludes != null && this.indirectIncludes.contains(schemaToProcess));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  205 */       if (this == o) return true; 
/*  206 */       if (!(o instanceof SchemaToProcess)) return false;
/*      */       
/*  208 */       SchemaToProcess schemaToProcess = (SchemaToProcess)o;
/*      */       
/*  210 */       if ((this.chameleonNamespace != null) ? !this.chameleonNamespace.equals(schemaToProcess.chameleonNamespace) : (schemaToProcess.chameleonNamespace != null)) return false; 
/*  211 */       if (this.schema != schemaToProcess.schema) return false;
/*      */       
/*  213 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  219 */       int result = this.schema.hashCode();
/*  220 */       result = 29 * result + ((this.chameleonNamespace != null) ? this.chameleonNamespace.hashCode() : 0);
/*  221 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String baseURLForDoc(XmlObject obj) {
/*  229 */     String path = obj.documentProperties().getSourceName();
/*      */     
/*  231 */     if (path == null) {
/*  232 */       return null;
/*      */     }
/*  234 */     if (path.startsWith("/")) {
/*  235 */       return "project://local" + path.replace('\\', '/');
/*      */     }
/*      */     
/*  238 */     int colon = path.indexOf(':');
/*  239 */     if (colon > 1 && path.substring(0, colon).matches("^\\w+$")) {
/*  240 */       return path;
/*      */     }
/*  242 */     return "project://local/" + path.replace('\\', '/');
/*      */   }
/*      */ 
/*      */   
/*      */   private static URI parseURI(String s) {
/*  247 */     if (s == null) {
/*  248 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  252 */       return new URI(s);
/*      */     }
/*  254 */     catch (URISyntaxException syntax) {
/*      */       
/*  256 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static URI resolve(URI base, String child) throws URISyntaxException {
/*  264 */     URI childUri = new URI(child);
/*  265 */     URI ruri = base.resolve(childUri);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  272 */     if (childUri.equals(ruri) && !childUri.isAbsolute() && (base.getScheme().equals("jar") || base.getScheme().equals("zip"))) {
/*      */       
/*  274 */       String r = base.toString();
/*  275 */       int lastslash = r.lastIndexOf('/');
/*  276 */       r = r.substring(0, lastslash) + "/" + childUri;
/*      */ 
/*      */ 
/*      */       
/*  280 */       int exclPointSlashIndex = r.lastIndexOf("!/");
/*  281 */       if (exclPointSlashIndex > 0) {
/*      */         
/*  283 */         int slashDotDotIndex = r.indexOf("/..", exclPointSlashIndex);
/*  284 */         while (slashDotDotIndex > 0) {
/*      */           
/*  286 */           int prevSlashIndex = r.lastIndexOf("/", slashDotDotIndex - 1);
/*  287 */           if (prevSlashIndex >= exclPointSlashIndex) {
/*      */             
/*  289 */             String temp = r.substring(slashDotDotIndex + 3);
/*  290 */             r = r.substring(0, prevSlashIndex).concat(temp);
/*      */           } 
/*  292 */           slashDotDotIndex = r.indexOf("/..", exclPointSlashIndex);
/*      */         } 
/*      */       } 
/*  295 */       return URI.create(r);
/*      */     } 
/*      */ 
/*      */     
/*  299 */     if ("file".equals(ruri.getScheme()) && !child.equals(ruri))
/*      */     {
/*  301 */       if (base.getPath().startsWith("//") && !ruri.getPath().startsWith("//")) {
/*      */         
/*  303 */         String path = "///".concat(ruri.getPath());
/*      */         
/*      */         try {
/*  306 */           ruri = new URI("file", null, path, ruri.getQuery(), ruri.getFragment());
/*      */         }
/*  308 */         catch (URISyntaxException uris) {}
/*      */       } 
/*      */     }
/*      */     
/*  312 */     return ruri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DownloadTable
/*      */   {
/*      */     private static class NsLocPair
/*      */     {
/*      */       private String namespaceURI;
/*      */ 
/*      */ 
/*      */       
/*      */       private String locationURL;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public NsLocPair(String namespaceURI, String locationURL) {
/*  332 */         this.namespaceURI = namespaceURI;
/*  333 */         this.locationURL = locationURL;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public String getNamespaceURI() {
/*  341 */         return this.namespaceURI;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getLocationURL() {
/*  346 */         return this.locationURL;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(Object o) {
/*  351 */         if (this == o) return true; 
/*  352 */         if (!(o instanceof NsLocPair)) return false;
/*      */         
/*  354 */         NsLocPair nsLocPair = (NsLocPair)o;
/*      */         
/*  356 */         if ((this.locationURL != null) ? !this.locationURL.equals(nsLocPair.locationURL) : (nsLocPair.locationURL != null)) return false; 
/*  357 */         if ((this.namespaceURI != null) ? !this.namespaceURI.equals(nsLocPair.namespaceURI) : (nsLocPair.namespaceURI != null)) return false;
/*      */         
/*  359 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*  365 */         int result = (this.namespaceURI != null) ? this.namespaceURI.hashCode() : 0;
/*  366 */         result = 29 * result + ((this.locationURL != null) ? this.locationURL.hashCode() : 0);
/*  367 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */     private static class DigestKey
/*      */     {
/*      */       byte[] _digest;
/*      */       int _hashCode;
/*      */       
/*      */       DigestKey(byte[] digest) {
/*  377 */         this._digest = digest;
/*  378 */         for (int i = 0; i < 4 && i < digest.length; i++) {
/*      */           
/*  380 */           this._hashCode <<= 8;
/*  381 */           this._hashCode += digest[i];
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(Object o) {
/*  387 */         if (this == o) return true; 
/*  388 */         if (!(o instanceof DigestKey)) return false; 
/*  389 */         return Arrays.equals(this._digest, ((DigestKey)o)._digest);
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*  394 */         return this._hashCode;
/*      */       }
/*      */     }
/*      */     
/*  398 */     private Map schemaByNsLocPair = new HashMap();
/*  399 */     private Map schemaByDigestKey = new HashMap();
/*  400 */     private LinkedList scanNeeded = new LinkedList();
/*  401 */     private Set emptyNamespaceSchemas = new HashSet();
/*  402 */     private Map scannedAlready = new HashMap();
/*  403 */     private Set failedDownloads = new HashSet();
/*      */ 
/*      */ 
/*      */     
/*      */     private SchemaDocument.Schema downloadSchema(XmlObject referencedBy, String targetNamespace, String locationURL) {
/*  408 */       if (locationURL == null) {
/*  409 */         return null;
/*      */       }
/*  411 */       StscState state = StscState.get();
/*      */ 
/*      */       
/*  414 */       URI baseURI = StscImporter.parseURI(StscImporter.baseURLForDoc(referencedBy));
/*  415 */       String absoluteURL = null;
/*      */       
/*      */       try {
/*  418 */         absoluteURL = (baseURI == null) ? locationURL : StscImporter.resolve(baseURI, locationURL).toString();
/*      */       }
/*  420 */       catch (URISyntaxException e) {
/*      */         
/*  422 */         state.error("Could not find resource - invalid location URL: " + e.getMessage(), 56, referencedBy);
/*  423 */         return null;
/*      */       } 
/*      */ 
/*      */       
/*  427 */       if (state.isFileProcessed(absoluteURL)) {
/*  428 */         return null;
/*      */       }
/*      */       
/*  431 */       if (absoluteURL != null && targetNamespace != null) {
/*      */         
/*  433 */         SchemaDocument.Schema result = (SchemaDocument.Schema)this.schemaByNsLocPair.get(new NsLocPair(targetNamespace, absoluteURL));
/*  434 */         if (result != null) {
/*  435 */           return result;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  447 */       if (targetNamespace != null && !targetNamespace.equals("")) {
/*      */ 
/*      */         
/*  450 */         if (!state.shouldDownloadURI(absoluteURL)) {
/*      */ 
/*      */ 
/*      */           
/*  454 */           SchemaDocument.Schema result = (SchemaDocument.Schema)this.schemaByNsLocPair.get(new NsLocPair(targetNamespace, null));
/*  455 */           if (result != null) {
/*  456 */             return result;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  461 */         if (state.linkerDefinesNamespace(targetNamespace)) {
/*  462 */           return null;
/*      */         }
/*      */       } 
/*      */       
/*  466 */       if (absoluteURL != null) {
/*      */         
/*  468 */         SchemaDocument.Schema result = (SchemaDocument.Schema)this.schemaByNsLocPair.get(new NsLocPair(null, absoluteURL));
/*  469 */         if (result != null) {
/*  470 */           return result;
/*      */         }
/*      */       } 
/*      */       
/*  474 */       if (absoluteURL == null) {
/*      */         
/*  476 */         state.error("Could not find resource - no valid location URL.", 56, referencedBy);
/*  477 */         return null;
/*      */       } 
/*      */       
/*  480 */       if (previouslyFailedToDownload(absoluteURL))
/*      */       {
/*      */         
/*  483 */         return null;
/*      */       }
/*      */       
/*  486 */       if (!state.shouldDownloadURI(absoluteURL)) {
/*      */         
/*  488 */         state.error("Could not load resource \"" + absoluteURL + "\" (network downloads disabled).", 56, referencedBy);
/*  489 */         addFailedDownload(absoluteURL);
/*  490 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  496 */       try { XmlObject xdoc = downloadDocument(state.getS4SLoader(), targetNamespace, absoluteURL);
/*      */         
/*  498 */         SchemaDocument.Schema result = findMatchByDigest(xdoc);
/*  499 */         String shortname = state.relativize(absoluteURL);
/*  500 */         if (result != null)
/*      */         
/*      */         { 
/*  503 */           String dupname = state.relativize(result.documentProperties().getSourceName());
/*  504 */           if (dupname != null) {
/*  505 */             state.info(shortname + " is the same as " + dupname + " (ignoring the duplicate file)");
/*      */           } else {
/*  507 */             state.info(shortname + " is the same as another schema");
/*      */           }
/*      */            }
/*      */         else
/*      */         
/*  512 */         { XmlOptions voptions = new XmlOptions();
/*  513 */           voptions.setErrorListener(state.getErrorListener());
/*  514 */           if (!(xdoc instanceof SchemaDocument) || !xdoc.validate(voptions)) {
/*      */             
/*  516 */             state.error("Referenced document is not a valid schema", 56, referencedBy);
/*      */           }
/*      */           else {
/*      */             
/*  520 */             SchemaDocument sDoc = (SchemaDocument)xdoc;
/*      */             
/*  522 */             result = sDoc.getSchema();
/*  523 */             state.info("Loading referenced file " + shortname);
/*      */             
/*  525 */             NsLocPair key = new NsLocPair(emptyStringIfNull(result.getTargetNamespace()), absoluteURL);
/*  526 */             addSuccessfulDownload(key, result);
/*  527 */             return result;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  543 */           addFailedDownload(absoluteURL);
/*  544 */           return null; }  NsLocPair nsLocPair = new NsLocPair(emptyStringIfNull(result.getTargetNamespace()), absoluteURL); addSuccessfulDownload(nsLocPair, result); return result; } catch (MalformedURLException malformed) { state.error("URL \"" + absoluteURL + "\" is not well-formed", 56, referencedBy); } catch (IOException connectionProblem) { state.error(connectionProblem.toString(), 56, referencedBy); } catch (XmlException e) { state.error("Problem parsing referenced XML resource - " + e.getMessage(), 56, referencedBy); }  addFailedDownload(absoluteURL); return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     static XmlObject downloadDocument(SchemaTypeLoader loader, String namespace, String absoluteURL) throws MalformedURLException, IOException, XmlException {
/*  550 */       StscState state = StscState.get();
/*      */       
/*  552 */       EntityResolver resolver = state.getEntityResolver();
/*  553 */       if (resolver != null) {
/*      */         
/*  555 */         InputSource source = null;
/*      */         
/*      */         try {
/*  558 */           source = resolver.resolveEntity(namespace, absoluteURL);
/*      */         }
/*  560 */         catch (SAXException e) {
/*      */           
/*  562 */           throw new XmlException(e);
/*      */         } 
/*      */         
/*  565 */         if (source != null) {
/*      */           
/*  567 */           state.addSourceUri(absoluteURL, null);
/*      */ 
/*      */           
/*  570 */           Reader reader = source.getCharacterStream();
/*  571 */           if (reader != null) {
/*      */             
/*  573 */             reader = copySchemaSource(absoluteURL, reader, state);
/*  574 */             XmlOptions xmlOptions1 = new XmlOptions();
/*  575 */             xmlOptions1.setLoadLineNumbers();
/*  576 */             xmlOptions1.setDocumentSourceName(absoluteURL);
/*  577 */             return loader.parse(reader, null, xmlOptions1);
/*      */           } 
/*      */ 
/*      */           
/*  581 */           InputStream bytes = source.getByteStream();
/*  582 */           if (bytes != null) {
/*      */             
/*  584 */             bytes = copySchemaSource(absoluteURL, bytes, state);
/*  585 */             String encoding = source.getEncoding();
/*  586 */             XmlOptions xmlOptions1 = new XmlOptions();
/*  587 */             xmlOptions1.setLoadLineNumbers();
/*  588 */             xmlOptions1.setLoadMessageDigest();
/*  589 */             xmlOptions1.setDocumentSourceName(absoluteURL);
/*  590 */             if (encoding != null)
/*  591 */               xmlOptions1.setCharacterEncoding(encoding); 
/*  592 */             return loader.parse(bytes, null, xmlOptions1);
/*      */           } 
/*      */ 
/*      */           
/*  596 */           String urlToLoad = source.getSystemId();
/*  597 */           if (urlToLoad == null) {
/*  598 */             throw new IOException("EntityResolver unable to resolve " + absoluteURL + " (for namespace " + namespace + ")");
/*      */           }
/*  600 */           copySchemaSource(absoluteURL, state, false);
/*  601 */           XmlOptions xmlOptions = new XmlOptions();
/*  602 */           xmlOptions.setLoadLineNumbers();
/*  603 */           xmlOptions.setLoadMessageDigest();
/*  604 */           xmlOptions.setDocumentSourceName(absoluteURL);
/*  605 */           URL uRL = new URL(urlToLoad);
/*  606 */           return loader.parse(uRL, null, xmlOptions);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  611 */       state.addSourceUri(absoluteURL, null);
/*  612 */       copySchemaSource(absoluteURL, state, false);
/*      */       
/*  614 */       XmlOptions options = new XmlOptions();
/*  615 */       options.setLoadLineNumbers();
/*  616 */       options.setLoadMessageDigest();
/*  617 */       URL urlDownload = new URL(absoluteURL);
/*      */       
/*  619 */       return loader.parse(urlDownload, null, options);
/*      */     }
/*      */ 
/*      */     
/*      */     private void addSuccessfulDownload(NsLocPair key, SchemaDocument.Schema schema) {
/*  624 */       byte[] digest = schema.documentProperties().getMessageDigest();
/*  625 */       if (digest == null) {
/*      */         
/*  627 */         StscState.get().addSchemaDigest(null);
/*      */       }
/*      */       else {
/*      */         
/*  631 */         DigestKey dk = new DigestKey(digest);
/*  632 */         if (!this.schemaByDigestKey.containsKey(dk)) {
/*      */           
/*  634 */           this.schemaByDigestKey.put(new DigestKey(digest), schema);
/*  635 */           StscState.get().addSchemaDigest(digest);
/*      */         } 
/*      */       } 
/*      */       
/*  639 */       this.schemaByNsLocPair.put(key, schema);
/*  640 */       NsLocPair key1 = new NsLocPair(key.getNamespaceURI(), null);
/*  641 */       if (!this.schemaByNsLocPair.containsKey(key1))
/*  642 */         this.schemaByNsLocPair.put(key1, schema); 
/*  643 */       NsLocPair key2 = new NsLocPair(null, key.getLocationURL());
/*  644 */       if (!this.schemaByNsLocPair.containsKey(key2)) {
/*  645 */         this.schemaByNsLocPair.put(key2, schema);
/*      */       }
/*      */     }
/*      */     
/*      */     private SchemaDocument.Schema findMatchByDigest(XmlObject original) {
/*  650 */       byte[] digest = original.documentProperties().getMessageDigest();
/*  651 */       if (digest == null)
/*  652 */         return null; 
/*  653 */       return (SchemaDocument.Schema)this.schemaByDigestKey.get(new DigestKey(digest));
/*      */     }
/*      */ 
/*      */     
/*      */     private void addFailedDownload(String locationURL) {
/*  658 */       this.failedDownloads.add(locationURL);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean previouslyFailedToDownload(String locationURL) {
/*  663 */       return this.failedDownloads.contains(locationURL);
/*      */     }
/*      */ 
/*      */     
/*      */     private static boolean nullableStringsMatch(String s1, String s2) {
/*  668 */       if (s1 == null && s2 == null)
/*  669 */         return true; 
/*  670 */       if (s1 == null || s2 == null)
/*  671 */         return false; 
/*  672 */       return s1.equals(s2);
/*      */     }
/*      */ 
/*      */     
/*      */     private static String emptyStringIfNull(String s) {
/*  677 */       if (s == null)
/*  678 */         return ""; 
/*  679 */       return s;
/*      */     }
/*      */ 
/*      */     
/*      */     private StscImporter.SchemaToProcess addScanNeeded(StscImporter.SchemaToProcess stp) {
/*  684 */       if (!this.scannedAlready.containsKey(stp)) {
/*      */         
/*  686 */         this.scannedAlready.put(stp, stp);
/*  687 */         this.scanNeeded.add(stp);
/*  688 */         return stp;
/*      */       } 
/*      */       
/*  691 */       return (StscImporter.SchemaToProcess)this.scannedAlready.get(stp);
/*      */     }
/*      */ 
/*      */     
/*      */     private void addEmptyNamespaceSchema(SchemaDocument.Schema s) {
/*  696 */       this.emptyNamespaceSchemas.add(s);
/*      */     }
/*      */ 
/*      */     
/*      */     private void usedEmptyNamespaceSchema(SchemaDocument.Schema s) {
/*  701 */       this.emptyNamespaceSchemas.remove(s);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean fetchRemainingEmptyNamespaceSchemas() {
/*  706 */       if (this.emptyNamespaceSchemas.isEmpty()) {
/*  707 */         return false;
/*      */       }
/*  709 */       for (Iterator i = this.emptyNamespaceSchemas.iterator(); i.hasNext(); ) {
/*      */         
/*  711 */         SchemaDocument.Schema schema = i.next();
/*  712 */         addScanNeeded(new StscImporter.SchemaToProcess(schema, null));
/*      */       } 
/*      */       
/*  715 */       this.emptyNamespaceSchemas.clear();
/*  716 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean hasNextToScan() {
/*  721 */       return !this.scanNeeded.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     private StscImporter.SchemaToProcess nextToScan() {
/*  726 */       StscImporter.SchemaToProcess next = this.scanNeeded.removeFirst();
/*  727 */       return next;
/*      */     }
/*      */ 
/*      */     
/*      */     public DownloadTable(SchemaDocument.Schema[] startWith) {
/*  732 */       for (int i = 0; i < startWith.length; i++) {
/*      */         
/*  734 */         String targetNamespace = startWith[i].getTargetNamespace();
/*  735 */         NsLocPair key = new NsLocPair(targetNamespace, StscImporter.baseURLForDoc((XmlObject)startWith[i]));
/*  736 */         addSuccessfulDownload(key, startWith[i]);
/*  737 */         if (targetNamespace != null) {
/*  738 */           addScanNeeded(new StscImporter.SchemaToProcess(startWith[i], null));
/*      */         } else {
/*  740 */           addEmptyNamespaceSchema(startWith[i]);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public StscImporter.SchemaToProcess[] resolveImportsAndIncludes(boolean forceSave) {
/*  746 */       StscState state = StscState.get();
/*  747 */       List result = new ArrayList();
/*  748 */       boolean hasRedefinitions = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       do {
/*  761 */         while (hasNextToScan()) {
/*      */           
/*  763 */           StscImporter.SchemaToProcess stp = nextToScan();
/*  764 */           String uri = stp.getSourceName();
/*  765 */           state.addSourceUri(uri, null);
/*  766 */           result.add(stp);
/*  767 */           copySchemaSource(uri, state, forceSave);
/*      */ 
/*      */ 
/*      */           
/*  771 */           ImportDocument.Import[] imports = stp.getSchema().getImportArray();
/*  772 */           for (int i = 0; i < imports.length; i++) {
/*      */             
/*  774 */             SchemaDocument.Schema imported = downloadSchema((XmlObject)imports[i], emptyStringIfNull(imports[i].getNamespace()), imports[i].getSchemaLocation());
/*      */ 
/*      */             
/*  777 */             if (imported != null)
/*      */             {
/*      */               
/*  780 */               if (!nullableStringsMatch(imported.getTargetNamespace(), imports[i].getNamespace())) {
/*      */                 
/*  782 */                 StscState.get().error("Imported schema has a target namespace \"" + imported.getTargetNamespace() + "\" that does not match the specified \"" + imports[i].getNamespace() + "\"", 4, (XmlObject)imports[i]);
/*      */               }
/*      */               else {
/*      */                 
/*  786 */                 addScanNeeded(new StscImporter.SchemaToProcess(imported, null));
/*      */               } 
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  793 */           IncludeDocument.Include[] includes = stp.getSchema().getIncludeArray();
/*  794 */           String sourceNamespace = stp.getChameleonNamespace();
/*  795 */           if (sourceNamespace == null)
/*  796 */             sourceNamespace = emptyStringIfNull(stp.getSchema().getTargetNamespace()); 
/*      */           int j;
/*  798 */           for (j = 0; j < includes.length; j++) {
/*      */             
/*  800 */             SchemaDocument.Schema included = downloadSchema((XmlObject)includes[j], null, includes[j].getSchemaLocation());
/*      */             
/*  802 */             if (included != null)
/*      */             {
/*      */               
/*  805 */               if (emptyStringIfNull(included.getTargetNamespace()).equals(sourceNamespace)) {
/*      */ 
/*      */                 
/*  808 */                 StscImporter.SchemaToProcess s = addScanNeeded(new StscImporter.SchemaToProcess(included, null));
/*  809 */                 stp.addInclude(s);
/*      */               }
/*  811 */               else if (included.getTargetNamespace() != null) {
/*      */ 
/*      */                 
/*  814 */                 StscState.get().error("Included schema has a target namespace \"" + included.getTargetNamespace() + "\" that does not match the source namespace \"" + sourceNamespace + "\"", 4, (XmlObject)includes[j]);
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/*  819 */                 StscImporter.SchemaToProcess s = addScanNeeded(new StscImporter.SchemaToProcess(included, sourceNamespace));
/*  820 */                 stp.addInclude(s);
/*  821 */                 usedEmptyNamespaceSchema(included);
/*      */               } 
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  828 */           RedefineDocument.Redefine[] redefines = stp.getSchema().getRedefineArray();
/*  829 */           sourceNamespace = stp.getChameleonNamespace();
/*  830 */           if (sourceNamespace == null)
/*  831 */             sourceNamespace = emptyStringIfNull(stp.getSchema().getTargetNamespace()); 
/*  832 */           for (j = 0; j < redefines.length; j++) {
/*      */             
/*  834 */             SchemaDocument.Schema redefined = downloadSchema((XmlObject)redefines[j], null, redefines[j].getSchemaLocation());
/*      */             
/*  836 */             if (redefined != null)
/*      */             {
/*      */               
/*  839 */               if (emptyStringIfNull(redefined.getTargetNamespace()).equals(sourceNamespace))
/*      */               {
/*      */                 
/*  842 */                 StscImporter.SchemaToProcess s = addScanNeeded(new StscImporter.SchemaToProcess(redefined, null));
/*  843 */                 stp.addRedefine(s, redefines[j]);
/*  844 */                 hasRedefinitions = true;
/*      */               }
/*  846 */               else if (redefined.getTargetNamespace() != null)
/*      */               {
/*      */                 
/*  849 */                 StscState.get().error("Redefined schema has a target namespace \"" + redefined.getTargetNamespace() + "\" that does not match the source namespace \"" + sourceNamespace + "\"", 4, (XmlObject)redefines[j]);
/*      */               
/*      */               }
/*      */               else
/*      */               {
/*  854 */                 StscImporter.SchemaToProcess s = addScanNeeded(new StscImporter.SchemaToProcess(redefined, sourceNamespace));
/*  855 */                 stp.addRedefine(s, redefines[j]);
/*  856 */                 usedEmptyNamespaceSchema(redefined);
/*  857 */                 hasRedefinitions = true;
/*      */               }
/*      */             
/*      */             }
/*      */           } 
/*      */         } 
/*  863 */       } while (fetchRemainingEmptyNamespaceSchemas());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  869 */       if (hasRedefinitions)
/*  870 */         for (int i = 0; i < result.size(); i++) {
/*      */           
/*  872 */           StscImporter.SchemaToProcess schemaToProcess = result.get(i);
/*  873 */           schemaToProcess.buildIndirectReferences();
/*      */         }  
/*  875 */       return result.<StscImporter.SchemaToProcess>toArray(new StscImporter.SchemaToProcess[result.size()]);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static Reader copySchemaSource(String url, Reader reader, StscState state) {
/*  881 */       if (state.getSchemasDir() == null) {
/*  882 */         return reader;
/*      */       }
/*  884 */       String schemalocation = state.sourceNameForUri(url);
/*  885 */       File targetFile = new File(state.getSchemasDir(), schemalocation);
/*  886 */       if (targetFile.exists()) {
/*  887 */         return reader;
/*      */       }
/*      */       
/*      */       try {
/*  891 */         File parentDir = new File(targetFile.getParent());
/*  892 */         IOUtil.createDir(parentDir, null);
/*      */         
/*  894 */         CharArrayReader car = copy(reader);
/*  895 */         XmlEncodingSniffer xes = new XmlEncodingSniffer(car, null);
/*  896 */         Writer out = new OutputStreamWriter(new FileOutputStream(targetFile), xes.getXmlEncoding());
/*  897 */         IOUtil.copyCompletely(car, out);
/*      */         
/*  899 */         car.reset();
/*  900 */         return car;
/*      */       }
/*  902 */       catch (IOException e) {
/*      */         
/*  904 */         System.err.println("IO Error " + e);
/*  905 */         return reader;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static InputStream copySchemaSource(String url, InputStream bytes, StscState state) {
/*  912 */       if (state.getSchemasDir() == null) {
/*  913 */         return bytes;
/*      */       }
/*  915 */       String schemalocation = state.sourceNameForUri(url);
/*  916 */       File targetFile = new File(state.getSchemasDir(), schemalocation);
/*  917 */       if (targetFile.exists()) {
/*  918 */         return bytes;
/*      */       }
/*      */       
/*      */       try {
/*  922 */         File parentDir = new File(targetFile.getParent());
/*  923 */         IOUtil.createDir(parentDir, null);
/*      */         
/*  925 */         ByteArrayInputStream bais = copy(bytes);
/*      */         
/*  927 */         FileOutputStream out = new FileOutputStream(targetFile);
/*  928 */         IOUtil.copyCompletely(bais, out);
/*      */         
/*  930 */         bais.reset();
/*  931 */         return bais;
/*      */       }
/*  933 */       catch (IOException e) {
/*      */         
/*  935 */         System.err.println("IO Error " + e);
/*  936 */         return bytes;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void copySchemaSource(String urlLoc, StscState state, boolean forceCopy) {
/*  943 */       if (state.getSchemasDir() != null) {
/*      */         
/*  945 */         String schemalocation = state.sourceNameForUri(urlLoc);
/*      */         
/*  947 */         File targetFile = new File(state.getSchemasDir(), schemalocation);
/*  948 */         if (forceCopy || !targetFile.exists()) {
/*      */           
/*      */           try {
/*      */             
/*  952 */             File parentDir = new File(targetFile.getParent());
/*  953 */             IOUtil.createDir(parentDir, null);
/*      */             
/*  955 */             InputStream in = null;
/*  956 */             URL url = new URL(urlLoc);
/*      */ 
/*      */             
/*      */             try {
/*  960 */               in = url.openStream();
/*      */             }
/*  962 */             catch (FileNotFoundException fnfe) {
/*      */               
/*  964 */               if (forceCopy && targetFile.exists()) {
/*  965 */                 targetFile.delete();
/*      */               } else {
/*  967 */                 throw fnfe;
/*      */               } 
/*  969 */             }  if (in != null)
/*      */             {
/*  971 */               FileOutputStream out = new FileOutputStream(targetFile);
/*  972 */               IOUtil.copyCompletely(in, out);
/*      */             }
/*      */           
/*  975 */           } catch (IOException e) {
/*      */             
/*  977 */             System.err.println("IO Error " + e);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static ByteArrayInputStream copy(InputStream is) throws IOException {
/*  986 */       byte[] buf = new byte[1024];
/*  987 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*      */       
/*      */       int bytesRead;
/*  990 */       while ((bytesRead = is.read(buf, 0, 1024)) > 0) {
/*  991 */         baos.write(buf, 0, bytesRead);
/*      */       }
/*  993 */       return new ByteArrayInputStream(baos.toByteArray());
/*      */     }
/*      */ 
/*      */     
/*      */     private static CharArrayReader copy(Reader is) throws IOException {
/*  998 */       char[] buf = new char[1024];
/*  999 */       CharArrayWriter baos = new CharArrayWriter();
/*      */       
/*      */       int bytesRead;
/* 1002 */       while ((bytesRead = is.read(buf, 0, 1024)) > 0) {
/* 1003 */         baos.write(buf, 0, bytesRead);
/*      */       }
/* 1005 */       return new CharArrayReader(baos.toCharArray());
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscImporter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */