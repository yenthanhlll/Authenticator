/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.CharsetDecoder;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.IllegalCharException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ASCIIXMLDecoder
/*     */   implements XMLDecoder
/*     */ {
/*     */   private boolean sawCR = false;
/*     */   
/*     */   public CharsetDecoder newCharsetDecoder() {
/*  36 */     return newXMLDecoder(); } public XMLDecoder newXMLDecoder() {
/*  37 */     return new ASCIIXMLDecoder();
/*     */   }
/*     */   public int minBytesPerChar() {
/*  40 */     return 1;
/*     */   }
/*     */   
/*     */   public int maxBytesPerChar() {
/*  44 */     return 1;
/*     */   }
/*     */   public void reset() {
/*  47 */     this.sawCR = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void decode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*  52 */     internalDecode(in_buf, in_off, in_len, out_buf, out_off, out_len, result, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeXMLDecl(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*  59 */     internalDecode(in_buf, in_off, in_len, out_buf, out_off, out_len, result, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalDecode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result, boolean decodeDecl) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/*  69 */     for (i = o = 0; i < in_len && o < out_len; i++) {
/*  70 */       char c = (char)(Byte.MAX_VALUE & in_buf[in_off + i]);
/*  71 */       if (c >= ' ') {
/*  72 */         this.sawCR = false;
/*  73 */         out_buf[out_off + o++] = c;
/*     */       } else {
/*     */         
/*  76 */         switch (c) {
/*     */           case '\n':
/*  78 */             if (this.sawCR) {
/*  79 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/*  82 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\r':
/*  86 */             this.sawCR = true;
/*  87 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\t':
/*  91 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*  95 */             if (decodeDecl) {
/*     */               break;
/*     */             }
/*  98 */             throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 104 */     result[0] = i;
/* 105 */     result[1] = o;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\ASCIIXMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */