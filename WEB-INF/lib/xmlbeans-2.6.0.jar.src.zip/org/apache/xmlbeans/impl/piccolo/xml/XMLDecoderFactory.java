/*    */ package org.apache.xmlbeans.impl.piccolo.xml;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLDecoderFactory
/*    */ {
/* 35 */   private static HashMap decoders = new HashMap();
/*    */   static {
/* 37 */     UTF8XMLDecoder utf8 = new UTF8XMLDecoder();
/* 38 */     ASCIIXMLDecoder ascii = new ASCIIXMLDecoder();
/* 39 */     ISO8859_1XMLDecoder iso8859 = new ISO8859_1XMLDecoder();
/* 40 */     UnicodeBigXMLDecoder utf16be = new UnicodeBigXMLDecoder();
/* 41 */     UnicodeLittleXMLDecoder utf16le = new UnicodeLittleXMLDecoder();
/* 42 */     decoders.put("UTF-8", utf8);
/* 43 */     decoders.put("UTF8", utf8);
/* 44 */     decoders.put("US-ASCII", ascii);
/* 45 */     decoders.put("ASCII", ascii);
/* 46 */     decoders.put("ISO-8859-1", iso8859);
/* 47 */     decoders.put("ISO8859_1", iso8859);
/* 48 */     decoders.put("UTF-16LE", utf16le);
/* 49 */     decoders.put("UNICODELITTLE", utf16le);
/* 50 */     decoders.put("UNICODELITTLEUNMARKED", utf16le);
/* 51 */     decoders.put("UTF-16BE", utf16be);
/* 52 */     decoders.put("UTF-16", utf16be);
/* 53 */     decoders.put("UNICODEBIG", utf16be);
/* 54 */     decoders.put("UNICODEBIGUNMARKED", utf16be);
/*    */   }
/*    */   
/*    */   public static XMLDecoder createDecoder(String encoding) throws UnsupportedEncodingException {
/* 58 */     XMLDecoder d = (XMLDecoder)decoders.get(encoding.toUpperCase());
/* 59 */     if (d != null) {
/* 60 */       return d.newXMLDecoder();
/*    */     }
/* 62 */     throw new UnsupportedEncodingException("Encoding '" + encoding + "' not supported");
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\XMLDecoderFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */