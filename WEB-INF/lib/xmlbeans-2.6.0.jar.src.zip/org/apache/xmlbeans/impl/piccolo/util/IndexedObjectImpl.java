/*    */ package org.apache.xmlbeans.impl.piccolo.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IndexedObjectImpl
/*    */   implements IndexedObject
/*    */ {
/*    */   private int index;
/*    */   private Object object;
/*    */   
/*    */   public IndexedObjectImpl(int index, Object object) {
/* 27 */     this.index = index;
/* 28 */     this.object = object;
/*    */   }
/*    */   
/* 31 */   public final int getIndex() { return this.index; } public final void setIndex(int index) {
/* 32 */     this.index = index;
/*    */   }
/* 34 */   public final Object getObject() { return this.object; } public final void setObject(Object object) {
/* 35 */     this.object = object;
/*    */   }
/*    */   public final Object clone() {
/* 38 */     return new IndexedObjectImpl(this.index, this.object);
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/* 42 */     if (o instanceof IndexedObject) {
/* 43 */       IndexedObject i = (IndexedObject)o;
/* 44 */       return (this.index == i.getIndex() && this.object.equals(i.getObject()));
/*    */     } 
/*    */     
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccol\\util\IndexedObjectImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */