/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.IllegalCharException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLReaderReader
/*     */   extends XMLInputReader
/*     */ {
/*     */   private static final int BUFFER_SIZE = 8192;
/*     */   private Reader in;
/*     */   private boolean rewindDeclaration;
/*  39 */   private char[] cbuf = new char[8192];
/*  40 */   private int cbufPos = 0; private int cbufEnd = 0;
/*     */   
/*     */   private boolean eofReached = false;
/*     */   private boolean sawCR = false;
/*  44 */   private char[] oneCharBuf = new char[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLReaderReader() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLReaderReader(Reader in) throws IOException {
/*  60 */     this(in, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLReaderReader(Reader in, boolean rewindDeclaration) throws IOException {
/*  72 */     reset(in, rewindDeclaration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(Reader in, boolean rewindDeclaration) throws IOException {
/*  78 */     resetInput();
/*  79 */     this.in = in;
/*  80 */     this.rewindDeclaration = rewindDeclaration;
/*  81 */     this.cbufPos = this.cbufEnd = 0;
/*  82 */     this.sawCR = false;
/*  83 */     this.eofReached = false;
/*  84 */     fillCharBuffer();
/*  85 */     processXMLDecl();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  89 */     this.eofReached = true;
/*  90 */     this.cbufPos = this.cbufEnd = 0;
/*  91 */     if (this.in != null)
/*  92 */       this.in.close(); 
/*     */   }
/*     */   
/*     */   public void mark(int readAheadLimit) throws IOException {
/*  96 */     throw new UnsupportedOperationException("mark() not supported");
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 104 */     int n = read(this.oneCharBuf, 0, 1);
/* 105 */     if (n <= 0) {
/* 106 */       return n;
/*     */     }
/* 108 */     return this.oneCharBuf[0];
/*     */   }
/*     */   
/*     */   public int read(char[] destbuf) throws IOException {
/* 112 */     return read(destbuf, 0, destbuf.length);
/*     */   }
/*     */   
/*     */   public int read(char[] destbuf, int off, int len) throws IOException {
/* 116 */     int charsRead = 0;
/*     */ 
/*     */     
/* 119 */     while (charsRead < len) {
/* 120 */       char c; if (this.cbufPos < this.cbufEnd) {
/* 121 */         c = this.cbuf[this.cbufPos++];
/*     */       } else {
/* 123 */         if (this.eofReached) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 128 */         if (charsRead == 0 || this.in.ready()) {
/* 129 */           fillCharBuffer();
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */       
/* 137 */       if (c >= ' ') {
/* 138 */         if (c <= '퟿' || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111)) {
/*     */ 
/*     */ 
/*     */           
/* 142 */           this.sawCR = false;
/* 143 */           destbuf[off + charsRead++] = c;
/*     */           continue;
/*     */         } 
/* 146 */         throw new IllegalCharException("Illegal XML Character: 0x" + Integer.toHexString(c));
/*     */       } 
/*     */ 
/*     */       
/* 150 */       switch (c) {
/*     */         case '\n':
/* 152 */           if (this.sawCR) {
/* 153 */             this.sawCR = false;
/*     */             continue;
/*     */           } 
/* 156 */           destbuf[off + charsRead++] = '\n';
/*     */           continue;
/*     */         
/*     */         case '\r':
/* 160 */           this.sawCR = true;
/* 161 */           destbuf[off + charsRead++] = '\n';
/*     */           continue;
/*     */         
/*     */         case '\t':
/* 165 */           destbuf[off + charsRead++] = '\t';
/*     */           continue;
/*     */       } 
/*     */       
/* 169 */       throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     return (charsRead == 0 && this.eofReached) ? -1 : charsRead;
/*     */   }
/*     */   
/*     */   public boolean ready() throws IOException {
/* 179 */     return (this.cbufEnd - this.cbufPos > 0 || this.in.ready());
/*     */   }
/*     */   
/*     */   public void reset() throws IOException {
/* 183 */     resetInput();
/* 184 */     this.in.reset();
/* 185 */     this.cbufPos = this.cbufEnd = 0;
/* 186 */     this.sawCR = false;
/* 187 */     this.eofReached = false;
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 191 */     int charsRead = 0;
/*     */ 
/*     */     
/* 194 */     while (charsRead < n) {
/* 195 */       char c; if (this.cbufPos < this.cbufEnd) {
/* 196 */         c = this.cbuf[this.cbufPos++];
/*     */       } else {
/* 198 */         if (this.eofReached)
/*     */           break; 
/* 200 */         fillCharBuffer();
/*     */         
/*     */         continue;
/*     */       } 
/* 204 */       if (c >= ' ') {
/* 205 */         if (c <= '퟿' || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111)) {
/*     */ 
/*     */ 
/*     */           
/* 209 */           this.sawCR = false;
/* 210 */           charsRead++;
/*     */           continue;
/*     */         } 
/* 213 */         throw new IllegalCharException("Illegal XML Character: 0x" + Integer.toHexString(c));
/*     */       } 
/*     */ 
/*     */       
/* 217 */       switch (c) {
/*     */         case '\n':
/* 219 */           if (this.sawCR) {
/* 220 */             this.sawCR = false;
/*     */             continue;
/*     */           } 
/* 223 */           charsRead++;
/*     */           continue;
/*     */         
/*     */         case '\r':
/* 227 */           this.sawCR = true;
/* 228 */           charsRead++;
/*     */           continue;
/*     */         
/*     */         case '\t':
/* 232 */           charsRead++;
/*     */           continue;
/*     */       } 
/*     */       
/* 236 */       throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     return ((charsRead == 0 && this.eofReached) ? -1L : charsRead);
/*     */   }
/*     */   
/*     */   private void fillCharBuffer() throws IOException {
/* 246 */     this.cbufPos = 0;
/* 247 */     this.cbufEnd = this.in.read(this.cbuf, 0, 8192);
/* 248 */     if (this.cbufEnd <= 0) {
/* 249 */       this.eofReached = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processXMLDecl() throws IOException {
/* 258 */     int numCharsParsed = parseXMLDeclaration(this.cbuf, 0, this.cbufEnd);
/*     */     
/* 260 */     if (numCharsParsed > 0)
/*     */     {
/*     */ 
/*     */       
/* 264 */       if (!this.rewindDeclaration)
/* 265 */         this.cbufPos += numCharsParsed; 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\XMLReaderReader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */