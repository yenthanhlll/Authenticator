/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.CharsetDecoder;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.IllegalCharException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ISO8859_1XMLDecoder
/*     */   implements XMLDecoder
/*     */ {
/*     */   private boolean sawCR = false;
/*     */   
/*     */   public CharsetDecoder newCharsetDecoder() {
/*  38 */     return newXMLDecoder(); } public XMLDecoder newXMLDecoder() {
/*  39 */     return new ISO8859_1XMLDecoder();
/*     */   }
/*     */   public int minBytesPerChar() {
/*  42 */     return 1;
/*     */   }
/*     */   
/*     */   public int maxBytesPerChar() {
/*  46 */     return 1;
/*     */   }
/*     */   public void reset() {
/*  49 */     this.sawCR = false;
/*     */   }
/*     */   
/*     */   public void decode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*  53 */     internalDecode(in_buf, in_off, in_len, out_buf, out_off, out_len, result, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeXMLDecl(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*  59 */     internalDecode(in_buf, in_off, in_len, out_buf, out_off, out_len, result, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalDecode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result, boolean decodeDecl) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/*  70 */     for (i = o = 0; i < in_len && o < out_len; i++) {
/*  71 */       char c = (char)(0xFF & in_buf[in_off + i]);
/*  72 */       if (c >= ' ') {
/*  73 */         this.sawCR = false;
/*  74 */         out_buf[out_off + o++] = c;
/*     */       } else {
/*     */         
/*  77 */         switch (c) {
/*     */           case '\n':
/*  79 */             if (this.sawCR) {
/*  80 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/*  83 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\r':
/*  87 */             this.sawCR = true;
/*  88 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\t':
/*  92 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*  96 */             if (decodeDecl) {
/*     */               break;
/*     */             }
/*  99 */             throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 105 */     result[0] = i;
/* 106 */     result[1] = o;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\ISO8859_1XMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */