/*    */ package org.apache.xmlbeans.impl.piccolo.xml;
/*    */ 
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FatalParsingException
/*    */   extends SAXException
/*    */ {
/*    */   FatalParsingException(String msg) {
/* 23 */     super(msg); } FatalParsingException(String msg, Exception ex) {
/* 24 */     super(msg, ex);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\FatalParsingException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */