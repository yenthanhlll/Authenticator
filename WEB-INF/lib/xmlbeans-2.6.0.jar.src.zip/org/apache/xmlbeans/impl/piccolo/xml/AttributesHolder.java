/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import org.xml.sax.AttributeList;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AttributesHolder
/*     */   implements Attributes, AttributeList
/*     */ {
/*     */   protected int length;
/*     */   protected String[] data;
/*     */   
/*     */   public void addAndCheckAttribute(String uri, String localName, String qName, String type, String value) throws SAXException {
/*  46 */     for (int i = 0; i < this.length; i++) {
/*  47 */       if (this.data[i * 5 + 2] == qName)
/*  48 */         throw new FatalParsingException("duplicate attribute '" + qName + "'"); 
/*     */     } 
/*  50 */     addAttribute(uri, localName, qName, type, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributesHolder() {
/*  60 */     this.length = 0;
/*  61 */     this.data = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributesHolder(Attributes atts) {
/*  73 */     setAttributes(atts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  86 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getURI(int index) {
/*  98 */     if (index >= 0 && index < this.length) {
/*  99 */       return this.data[index * 5];
/*     */     }
/*     */     
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalName(int index) {
/* 115 */     if (index >= 0 && index < this.length) {
/* 116 */       return this.data[index * 5 + 1];
/*     */     }
/*     */     
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(int i) {
/* 131 */     return getQName(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQName(int index) {
/* 142 */     if (index >= 0 && index < this.length) {
/* 143 */       return this.data[index * 5 + 2];
/*     */     }
/*     */     
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(int index) {
/* 159 */     if (index >= 0 && index < this.length) {
/* 160 */       return this.data[index * 5 + 3];
/*     */     }
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(int index) {
/* 175 */     if (index >= 0 && index < this.length) {
/* 176 */       return this.data[index * 5 + 4];
/*     */     }
/*     */     
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex(String uri, String localName) {
/* 197 */     int max = this.length * 5;
/* 198 */     for (int i = 0; i < max; i += 5) {
/* 199 */       if (this.data[i].equals(uri) && this.data[i + 1].equals(localName)) {
/* 200 */         return i / 5;
/*     */       }
/*     */     } 
/* 203 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex(String qName) {
/* 214 */     int max = this.length * 5;
/* 215 */     for (int i = 0; i < max; i += 5) {
/* 216 */       if (this.data[i + 2].equals(qName)) {
/* 217 */         return i / 5;
/*     */       }
/*     */     } 
/* 220 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(String uri, String localName) {
/* 234 */     int max = this.length * 5;
/* 235 */     for (int i = 0; i < max; i += 5) {
/* 236 */       if (this.data[i].equals(uri) && this.data[i + 1].equals(localName)) {
/* 237 */         return this.data[i + 3];
/*     */       }
/*     */     } 
/* 240 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType(String qName) {
/* 252 */     int max = this.length * 5;
/* 253 */     for (int i = 0; i < max; i += 5) {
/* 254 */       if (this.data[i + 2].equals(qName)) {
/* 255 */         return this.data[i + 3];
/*     */       }
/*     */     } 
/* 258 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(String uri, String localName) {
/* 272 */     int max = this.length * 5;
/* 273 */     for (int i = 0; i < max; i += 5) {
/* 274 */       if (this.data[i].equals(uri) && this.data[i + 1].equals(localName)) {
/* 275 */         return this.data[i + 4];
/*     */       }
/*     */     } 
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(String qName) {
/* 290 */     int max = this.length * 5;
/* 291 */     for (int i = 0; i < max; i += 5) {
/* 292 */       if (this.data[i + 2].equals(qName)) {
/* 293 */         return this.data[i + 4];
/*     */       }
/*     */     } 
/* 296 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 310 */     this.length = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Attributes atts) {
/* 322 */     clear();
/* 323 */     this.length = atts.getLength();
/* 324 */     if (this.length > 0) {
/* 325 */       this.data = new String[this.length * 5];
/* 326 */       for (int i = 0; i < this.length; i++) {
/* 327 */         this.data[i * 5] = atts.getURI(i);
/* 328 */         this.data[i * 5 + 1] = atts.getLocalName(i);
/* 329 */         this.data[i * 5 + 2] = atts.getQName(i);
/* 330 */         this.data[i * 5 + 3] = atts.getType(i);
/* 331 */         this.data[i * 5 + 4] = atts.getValue(i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttribute(String uri, String localName, String qName, String type, String value) {
/* 355 */     ensureCapacity(this.length + 1);
/* 356 */     this.data[this.length * 5] = uri;
/* 357 */     this.data[this.length * 5 + 1] = localName;
/* 358 */     this.data[this.length * 5 + 2] = qName;
/* 359 */     this.data[this.length * 5 + 3] = type;
/* 360 */     this.data[this.length * 5 + 4] = value;
/* 361 */     this.length++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(int index, String uri, String localName, String qName, String type, String value) {
/* 387 */     if (index >= 0 && index < this.length) {
/* 388 */       this.data[index * 5] = uri;
/* 389 */       this.data[index * 5 + 1] = localName;
/* 390 */       this.data[index * 5 + 2] = qName;
/* 391 */       this.data[index * 5 + 3] = type;
/* 392 */       this.data[index * 5 + 4] = value;
/*     */     } else {
/*     */       
/* 395 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(int index) {
/* 408 */     if (index >= 0 && index < this.length) {
/* 409 */       this.data[index * 5] = null;
/* 410 */       this.data[index * 5 + 1] = null;
/* 411 */       this.data[index * 5 + 2] = null;
/* 412 */       this.data[index * 5 + 3] = null;
/* 413 */       this.data[index * 5 + 4] = null;
/* 414 */       if (index < this.length - 1) {
/* 415 */         System.arraycopy(this.data, (index + 1) * 5, this.data, index * 5, (this.length - index - 1) * 5);
/*     */       }
/*     */       
/* 418 */       this.length--;
/*     */     } else {
/*     */       
/* 421 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURI(int index, String uri) {
/* 436 */     if (index >= 0 && index < this.length) {
/* 437 */       this.data[index * 5] = uri;
/*     */     } else {
/*     */       
/* 440 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalName(int index, String localName) {
/* 455 */     if (index >= 0 && index < this.length) {
/* 456 */       this.data[index * 5 + 1] = localName;
/*     */     } else {
/*     */       
/* 459 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQName(int index, String qName) {
/* 474 */     if (index >= 0 && index < this.length) {
/* 475 */       this.data[index * 5 + 2] = qName;
/*     */     } else {
/*     */       
/* 478 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(int index, String type) {
/* 492 */     if (index >= 0 && index < this.length) {
/* 493 */       this.data[index * 5 + 3] = type;
/*     */     } else {
/*     */       
/* 496 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int index, String value) {
/* 510 */     if (index >= 0 && index < this.length) {
/* 511 */       this.data[index * 5 + 4] = value;
/*     */     } else {
/*     */       
/* 514 */       badIndex(index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCapacity(int n) {
/*     */     int max;
/* 528 */     if (n <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 532 */     if (this.data == null || this.data.length == 0) {
/* 533 */       max = 25;
/*     */     } else {
/* 535 */       if (this.data.length >= n * 5) {
/*     */         return;
/*     */       }
/*     */       
/* 539 */       max = this.data.length;
/*     */     } 
/* 541 */     while (max < n * 5) {
/* 542 */       max *= 2;
/*     */     }
/* 544 */     String[] newData = new String[max];
/* 545 */     if (this.length > 0) {
/* 546 */       System.arraycopy(this.data, 0, newData, 0, this.length * 5);
/*     */     }
/* 548 */     this.data = newData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void badIndex(int index) throws ArrayIndexOutOfBoundsException {
/* 558 */     String msg = "Attempt to modify attribute at illegal index: " + index;
/* 559 */     throw new ArrayIndexOutOfBoundsException(msg);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\AttributesHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */