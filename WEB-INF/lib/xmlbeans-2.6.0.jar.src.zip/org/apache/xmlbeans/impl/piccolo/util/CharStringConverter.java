/*     */ package org.apache.xmlbeans.impl.piccolo.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharStringConverter
/*     */ {
/*     */   private static final float DEFAULT_LOAD = 0.7F;
/*     */   private float loadFactor;
/*  37 */   private int numEntries = 0;
/*     */   private int maxEntries;
/*     */   private int hashmask;
/*     */   private char[][] keys;
/*     */   private String[] values;
/*     */   
/*     */   public CharStringConverter(int initialCapacity, float loadFactor) {
/*  44 */     if (initialCapacity < 0) {
/*  45 */       throw new IllegalArgumentException("Illegal initial capacity: " + initialCapacity);
/*     */     }
/*     */     
/*  48 */     if (loadFactor < 0.0F || loadFactor > 1.0F) {
/*  49 */       throw new IllegalArgumentException("Illegal load factor: " + loadFactor);
/*     */     }
/*  51 */     int desiredSize = (int)(initialCapacity / loadFactor);
/*  52 */     int size = 16;
/*  53 */     while (size < desiredSize) {
/*  54 */       size <<= 1;
/*     */     }
/*  56 */     this.hashmask = size - 1;
/*  57 */     this.maxEntries = (int)(size * loadFactor);
/*  58 */     this.keys = new char[size][];
/*  59 */     this.values = new String[size];
/*  60 */     this.loadFactor = loadFactor;
/*     */   }
/*     */   
/*     */   public CharStringConverter() {
/*  64 */     this(0, 0.7F);
/*     */   }
/*     */   
/*     */   public CharStringConverter(int initialCapacity) {
/*  68 */     this(initialCapacity, 0.7F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCacheSize() {
/*  75 */     return this.numEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String convert(char[] ch) {
/*  82 */     return convert(ch, 0, ch.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String convert(char[] ch, int start, int length) {
/*  93 */     if (this.numEntries >= this.maxEntries) {
/*  94 */       rehash();
/*     */     }
/*     */     
/*  97 */     int offset = hashKey(ch, start, length) & this.hashmask;
/*  98 */     char[] k = null;
/*  99 */     while ((k = this.keys[offset]) != null && !keysAreEqual(k, 0, k.length, ch, start, length))
/*     */     {
/* 101 */       offset = offset - 1 & this.hashmask;
/*     */     }
/* 103 */     if (k != null) {
/* 104 */       return this.values[offset];
/*     */     }
/*     */ 
/*     */     
/* 108 */     k = new char[length];
/* 109 */     System.arraycopy(ch, start, k, 0, length);
/* 110 */     String v = (new String(k)).intern();
/* 111 */     this.keys[offset] = k;
/* 112 */     this.values[offset] = v;
/* 113 */     this.numEntries++;
/* 114 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   private void rehash() {
/* 119 */     int newlength = this.keys.length << 1;
/* 120 */     char[][] newkeys = new char[newlength][];
/* 121 */     String[] newvalues = new String[newlength];
/* 122 */     int newhashmask = newlength - 1;
/* 123 */     for (int i = 0; i < this.keys.length; i++) {
/* 124 */       char[] k = this.keys[i];
/* 125 */       String v = this.values[i];
/* 126 */       if (k != null) {
/* 127 */         int newoffset = hashKey(k, 0, k.length) & newhashmask;
/* 128 */         char[] newk = null;
/* 129 */         while ((newk = newkeys[newoffset]) != null && !keysAreEqual(newk, 0, newk.length, k, 0, k.length))
/*     */         {
/* 131 */           newoffset = newoffset - 1 & newhashmask;
/*     */         }
/* 133 */         newkeys[newoffset] = k;
/* 134 */         newvalues[newoffset] = v;
/*     */       } 
/*     */     } 
/* 137 */     this.keys = newkeys;
/* 138 */     this.values = newvalues;
/* 139 */     this.maxEntries = (int)(newlength * this.loadFactor);
/* 140 */     this.hashmask = newhashmask;
/*     */   }
/*     */   
/*     */   public void clearCache() {
/* 144 */     for (int i = 0; i < this.keys.length; i++) {
/* 145 */       this.keys[i] = null;
/* 146 */       this.values[i] = null;
/*     */     } 
/* 148 */     this.numEntries = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean keysAreEqual(char[] a, int astart, int alength, char[] b, int bstart, int blength) {
/* 153 */     if (alength != blength) {
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     for (int i = 0; i < alength; i++) {
/* 158 */       if (a[astart + i] != b[bstart + i]) {
/* 159 */         return false;
/*     */       }
/*     */     } 
/* 162 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int hashKey(char[] ch, int start, int length) {
/* 167 */     int hash = 0;
/* 168 */     for (int i = 0; i < length; i++) {
/* 169 */       hash = (hash << 5) + ch[start + i];
/*     */     }
/* 171 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccol\\util\CharStringConverter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */