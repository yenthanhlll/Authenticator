/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.apache.xmlbeans.impl.piccolo.util.FactoryServiceFinder;
/*     */ import org.xml.sax.Parser;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAXPSAXParserFactory
/*     */   extends SAXParserFactory
/*     */ {
/*  49 */   private Map featureMap = new HashMap();
/*  50 */   private static Boolean TRUE = new Boolean(true);
/*  51 */   private static Boolean FALSE = new Boolean(false);
/*  52 */   private Piccolo nvParser = new Piccolo();
/*     */ 
/*     */   
/*     */   private SAXParserFactory validatingFactory;
/*     */   
/*     */   private static final String VALIDATING_PROPERTY = "org.apache.xmlbeans.impl.piccolo.xml.ValidatingSAXParserFactory";
/*     */   
/*  59 */   private static Class validatingFactoryClass = findValidatingFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private ParserConfigurationException pendingValidatingException = null; private ParserConfigurationException pendingNonvalidatingException = null;
/*     */   
/*     */   private boolean validating = false, namespaceAware = false;
/*     */ 
/*     */   
/*     */   public static SAXParserFactory newInstance() {
/*  70 */     return new JAXPSAXParserFactory();
/*     */   }
/*     */   
/*     */   public JAXPSAXParserFactory() {
/*     */     try {
/*  75 */       if (validatingFactoryClass != null) {
/*  76 */         this.validatingFactory = validatingFactoryClass.newInstance();
/*     */         
/*  78 */         this.validatingFactory.setNamespaceAware(false);
/*  79 */         this.validatingFactory.setValidating(true);
/*     */       }
/*     */     
/*  82 */     } catch (Exception e) {
/*  83 */       this.validatingFactory = null;
/*     */     } 
/*     */     
/*  86 */     setNamespaceAware(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFeature(String name) throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException {
/*  93 */     if (this.validating && this.validatingFactory != null) {
/*  94 */       return this.validatingFactory.getFeature(name);
/*     */     }
/*  96 */     return this.nvParser.getFeature(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public SAXParser newSAXParser() throws ParserConfigurationException, SAXException {
/* 101 */     if (this.validating) {
/* 102 */       if (this.validatingFactory == null) {
/* 103 */         throw new ParserConfigurationException("XML document validation is not supported");
/*     */       }
/*     */       
/* 106 */       if (this.pendingValidatingException != null) {
/* 107 */         throw this.pendingValidatingException;
/*     */       }
/* 109 */       return this.validatingFactory.newSAXParser();
/*     */     } 
/*     */     
/* 112 */     if (this.pendingNonvalidatingException != null) {
/* 113 */       throw this.pendingNonvalidatingException;
/*     */     }
/* 115 */     return new JAXPSAXParser(new Piccolo(this.nvParser));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFeature(String name, boolean enabled) throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException {
/* 124 */     this.featureMap.put(name, enabled ? TRUE : FALSE);
/*     */ 
/*     */     
/* 127 */     if (this.validatingFactory != null) {
/* 128 */       if (this.pendingValidatingException != null) {
/* 129 */         reconfigureValidating();
/*     */       } else {
/*     */         try {
/* 132 */           this.validatingFactory.setFeature(name, enabled);
/*     */         }
/* 134 */         catch (ParserConfigurationException e) {
/* 135 */           this.pendingValidatingException = e;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 141 */     if (this.pendingNonvalidatingException != null) {
/* 142 */       reconfigureNonvalidating();
/*     */     }
/*     */     
/* 145 */     if (this.validating && this.pendingValidatingException != null) {
/* 146 */       throw this.pendingValidatingException;
/*     */     }
/* 148 */     if (!this.validating && this.pendingNonvalidatingException != null)
/* 149 */       throw this.pendingNonvalidatingException; 
/*     */   }
/*     */   
/*     */   public void setNamespaceAware(boolean awareness) {
/* 153 */     super.setNamespaceAware(awareness);
/* 154 */     this.namespaceAware = awareness;
/*     */     
/*     */     try {
/* 157 */       this.nvParser.setFeature("http://xml.org/sax/features/namespaces", awareness);
/*     */       
/* 159 */       this.nvParser.setFeature("http://xml.org/sax/features/namespace-prefixes", !awareness);
/*     */     
/*     */     }
/* 162 */     catch (SAXNotSupportedException e) {
/* 163 */       this.pendingNonvalidatingException = new ParserConfigurationException("Error setting namespace feature: " + e.toString());
/*     */     
/*     */     }
/* 166 */     catch (SAXNotRecognizedException e) {
/* 167 */       this.pendingNonvalidatingException = new ParserConfigurationException("Error setting namespace feature: " + e.toString());
/*     */     } 
/*     */ 
/*     */     
/* 171 */     if (this.validatingFactory != null)
/* 172 */       this.validatingFactory.setNamespaceAware(awareness); 
/*     */   }
/*     */   
/*     */   public void setValidating(boolean value) {
/* 176 */     super.setValidating(value);
/* 177 */     this.validating = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class findValidatingFactory() {
/*     */     try {
/* 185 */       String validatingClassName = System.getProperty("org.apache.xmlbeans.impl.piccolo.xml.ValidatingSAXParserFactory");
/*     */       
/* 187 */       if (validatingClassName != null) {
/* 188 */         return Class.forName(validatingClassName);
/*     */       }
/* 190 */     } catch (Exception e) {}
/*     */ 
/*     */     
/*     */     try {
/* 194 */       String javah = System.getProperty("java.home");
/* 195 */       String configFile = javah + File.separator + "lib" + File.separator + "jaxp.properties";
/*     */       
/* 197 */       File f = new File(configFile);
/* 198 */       if (f.exists()) {
/* 199 */         Properties props = new Properties();
/* 200 */         props.load(new FileInputStream(f));
/* 201 */         String validatingClassName = props.getProperty("org.apache.xmlbeans.impl.piccolo.xml.ValidatingSAXParserFactory");
/* 202 */         if (validatingClassName != null)
/* 203 */           return Class.forName(validatingClassName); 
/*     */       } 
/* 205 */     } catch (Exception e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 211 */       Enumeration enumValue = FactoryServiceFinder.findServices("javax.xml.parsers.SAXParserFactory");
/*     */       
/* 213 */       while (enumValue.hasMoreElements()) {
/*     */         try {
/* 215 */           String factory = enumValue.nextElement();
/* 216 */           if (!factory.equals("org.apache.xmlbeans.impl.piccolo.xml.Piccolo")) {
/* 217 */             return Class.forName(factory);
/*     */           }
/* 219 */         } catch (ClassNotFoundException e) {}
/*     */       }
/*     */     
/* 222 */     } catch (Exception e) {}
/*     */ 
/*     */     
/*     */     try {
/* 226 */       return Class.forName("org.apache.crimson.jaxp.SAXParserFactoryImpl");
/*     */     
/*     */     }
/* 229 */     catch (ClassNotFoundException e) {
/* 230 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void reconfigureValidating() {
/* 236 */     if (this.validatingFactory == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 240 */       Iterator iter = this.featureMap.entrySet().iterator();
/* 241 */       while (iter.hasNext()) {
/* 242 */         Map.Entry entry = iter.next();
/* 243 */         this.validatingFactory.setFeature((String)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 248 */     catch (ParserConfigurationException e) {
/* 249 */       this.pendingValidatingException = e;
/*     */     }
/* 251 */     catch (SAXNotRecognizedException e) {
/* 252 */       this.pendingValidatingException = new ParserConfigurationException(e.toString());
/*     */     
/*     */     }
/* 255 */     catch (SAXNotSupportedException e) {
/* 256 */       this.pendingValidatingException = new ParserConfigurationException(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void reconfigureNonvalidating() {
/*     */     try {
/* 263 */       Iterator iter = this.featureMap.entrySet().iterator();
/* 264 */       while (iter.hasNext()) {
/* 265 */         Map.Entry entry = iter.next();
/* 266 */         this.nvParser.setFeature((String)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 271 */     catch (SAXNotRecognizedException e) {
/* 272 */       this.pendingNonvalidatingException = new ParserConfigurationException(e.toString());
/*     */     
/*     */     }
/* 275 */     catch (SAXNotSupportedException e) {
/* 276 */       this.pendingNonvalidatingException = new ParserConfigurationException(e.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   static class JAXPSAXParser
/*     */     extends SAXParser {
/*     */     Piccolo parser;
/*     */     
/*     */     JAXPSAXParser(Piccolo parser) {
/* 285 */       this.parser = parser;
/*     */     }
/*     */     public Parser getParser() {
/* 288 */       return this.parser;
/*     */     }
/*     */     
/*     */     public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
/* 292 */       return this.parser.getProperty(name);
/*     */     }
/*     */     public XMLReader getXMLReader() {
/* 295 */       return this.parser;
/*     */     }
/*     */     public boolean isNamespaceAware() {
/* 298 */       return this.parser.fNamespaces;
/*     */     }
/*     */     public boolean isValidating() {
/* 301 */       return false;
/*     */     }
/*     */     
/*     */     public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
/* 305 */       this.parser.setProperty(name, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\JAXPSAXParserFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */