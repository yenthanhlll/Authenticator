/*     */ package org.apache.xmlbeans.impl.inst2xsd;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlByte;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlDate;
/*     */ import org.apache.xmlbeans.XmlDateTime;
/*     */ import org.apache.xmlbeans.XmlDuration;
/*     */ import org.apache.xmlbeans.XmlFloat;
/*     */ import org.apache.xmlbeans.XmlInt;
/*     */ import org.apache.xmlbeans.XmlInteger;
/*     */ import org.apache.xmlbeans.XmlLong;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlShort;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.XmlTime;
/*     */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.common.XmlWhitespace;
/*     */ import org.apache.xmlbeans.impl.inst2xsd.util.Attribute;
/*     */ import org.apache.xmlbeans.impl.inst2xsd.util.Element;
/*     */ import org.apache.xmlbeans.impl.inst2xsd.util.Type;
/*     */ import org.apache.xmlbeans.impl.inst2xsd.util.TypeSystemHolder;
/*     */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*     */ import org.apache.xmlbeans.impl.values.XmlAnyUriImpl;
/*     */ import org.apache.xmlbeans.impl.values.XmlDateImpl;
/*     */ import org.apache.xmlbeans.impl.values.XmlDateTimeImpl;
/*     */ import org.apache.xmlbeans.impl.values.XmlDurationImpl;
/*     */ import org.apache.xmlbeans.impl.values.XmlQNameImpl;
/*     */ import org.apache.xmlbeans.impl.values.XmlTimeImpl;
/*     */ 
/*     */ public class RussianDollStrategy implements XsdGenStrategy {
/*     */   static final String _xsi = "http://www.w3.org/2001/XMLSchema-instance";
/*  40 */   static final QName _xsiNil = new QName("http://www.w3.org/2001/XMLSchema-instance", "nil", "xsi");
/*  41 */   static final QName _xsiType = new QName("http://www.w3.org/2001/XMLSchema-instance", "type", "xsi");
/*     */ 
/*     */   
/*     */   public void processDoc(XmlObject[] instances, Inst2XsdOptions options, TypeSystemHolder typeSystemHolder) {
/*  45 */     for (int i = 0; i < instances.length; i++) {
/*     */       
/*  47 */       XmlObject instance = instances[i];
/*  48 */       XmlCursor xc = instance.newCursor();
/*     */ 
/*     */       
/*  51 */       StringBuffer comment = new StringBuffer();
/*     */       
/*  53 */       while (!xc.isStart()) {
/*     */         
/*  55 */         xc.toNextToken();
/*  56 */         if (xc.isComment()) {
/*  57 */           comment.append(xc.getTextValue()); continue;
/*  58 */         }  if (xc.isEnddoc()) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */       
/*  63 */       Element withElem = processElement(xc, comment.toString(), options, typeSystemHolder);
/*  64 */       withElem.setGlobal(true);
/*     */       
/*  66 */       addGlobalElement(withElem, typeSystemHolder, options);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Element addGlobalElement(Element withElem, TypeSystemHolder typeSystemHolder, Inst2XsdOptions options) {
/*  72 */     assert withElem.isGlobal();
/*  73 */     Element intoElem = typeSystemHolder.getGlobalElement(withElem.getName());
/*     */     
/*  75 */     if (intoElem == null) {
/*     */       
/*  77 */       typeSystemHolder.addGlobalElement(withElem);
/*  78 */       return withElem;
/*     */     } 
/*     */ 
/*     */     
/*  82 */     combineTypes(intoElem.getType(), withElem.getType(), options);
/*  83 */     combineElementComments(intoElem, withElem);
/*  84 */     return intoElem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Element processElement(XmlCursor xc, String comment, Inst2XsdOptions options, TypeSystemHolder typeSystemHolder) {
/*  91 */     assert xc.isStart();
/*  92 */     Element element = new Element();
/*  93 */     element.setName(xc.getName());
/*  94 */     element.setGlobal(false);
/*     */     
/*  96 */     Type elemType = Type.createUnnamedType(1);
/*  97 */     element.setType(elemType);
/*     */     
/*  99 */     StringBuffer textBuff = new StringBuffer();
/* 100 */     StringBuffer commentBuff = new StringBuffer();
/* 101 */     List children = new ArrayList();
/* 102 */     List attributes = new ArrayList();
/*     */     
/*     */     while (true) {
/*     */       QName attName;
/* 106 */       XmlCursor.TokenType tt = xc.toNextToken();
/* 107 */       switch (tt.intValue()) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 6:
/* 112 */           attName = xc.getName();
/* 113 */           if (!_xsiNil.getNamespaceURI().equals(attName.getNamespaceURI())) {
/* 114 */             attributes.add(processAttribute(xc, options, element.getName().getNamespaceURI(), typeSystemHolder)); continue;
/* 115 */           }  if (_xsiNil.equals(attName)) {
/* 116 */             element.setNillable(true);
/*     */           }
/*     */           continue;
/*     */         
/*     */         case 3:
/* 121 */           children.add(processElement(xc, commentBuff.toString(), options, typeSystemHolder));
/* 122 */           commentBuff.delete(0, commentBuff.length());
/*     */           continue;
/*     */         
/*     */         case 5:
/* 126 */           textBuff.append(xc.getChars());
/*     */           continue;
/*     */         
/*     */         case 8:
/* 130 */           commentBuff.append(xc.getTextValue());
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 7:
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 4:
/*     */           break;
/*     */ 
/*     */         
/*     */         case 9:
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 0:
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 152 */           throw new IllegalStateException();
/*     */       } 
/*     */       
/* 155 */       throw new IllegalStateException("Unknown TokenType.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 160 */     String collapsedText = XmlWhitespace.collapse(textBuff.toString(), 3);
/*     */     
/* 162 */     String commnetStr = (comment == null) ? ((commentBuff.length() == 0) ? null : commentBuff.toString()) : ((commentBuff.length() == 0) ? comment : commentBuff.insert(0, comment).toString());
/*     */ 
/*     */     
/* 165 */     element.setComment(commnetStr);
/*     */     
/* 167 */     if (children.size() > 0) {
/*     */ 
/*     */       
/* 170 */       if (collapsedText.length() > 0) {
/*     */         
/* 172 */         elemType.setContentType(4);
/*     */       }
/*     */       else {
/*     */         
/* 176 */         elemType.setContentType(3);
/*     */       } 
/* 178 */       processElementsInComplexType(elemType, children, element.getName().getNamespaceURI(), typeSystemHolder, options);
/* 179 */       processAttributesInComplexType(elemType, attributes);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 185 */       XmlCursor xcForNamespaces = xc.newCursor();
/* 186 */       xcForNamespaces.toParent();
/*     */       
/* 188 */       if (attributes.size() > 0) {
/*     */         
/* 190 */         elemType.setContentType(2);
/*     */         
/* 192 */         Type extendedType = Type.createNamedType(processSimpleContentType(textBuff.toString(), options, xcForNamespaces), 1);
/*     */         
/* 194 */         elemType.setExtensionType(extendedType);
/*     */         
/* 196 */         processAttributesInComplexType(elemType, attributes);
/*     */       }
/*     */       else {
/*     */         
/* 200 */         elemType.setContentType(1);
/* 201 */         elemType.setName(processSimpleContentType(textBuff.toString(), options, xcForNamespaces));
/*     */ 
/*     */         
/* 204 */         String enumValue = XmlString.type.getName().equals(elemType.getName()) ? textBuff.toString() : collapsedText;
/* 205 */         elemType.addEnumerationValue(enumValue, xcForNamespaces);
/*     */       } 
/*     */       
/* 208 */       xcForNamespaces.dispose();
/*     */     } 
/*     */     
/* 211 */     checkIfReferenceToGlobalTypeIsNeeded(element, typeSystemHolder, options);
/*     */     
/* 213 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processElementsInComplexType(Type elemType, List children, String parentNamespace, TypeSystemHolder typeSystemHolder, Inst2XsdOptions options) {
/* 219 */     Map elemNamesToElements = new HashMap();
/* 220 */     Element currentElem = null;
/*     */     
/* 222 */     for (Iterator iterator = children.iterator(); iterator.hasNext(); ) {
/*     */       
/* 224 */       Element child = iterator.next();
/*     */       
/* 226 */       if (currentElem == null) {
/*     */         
/* 228 */         checkIfElementReferenceIsNeeded(child, parentNamespace, typeSystemHolder, options);
/* 229 */         elemType.addElement(child);
/* 230 */         elemNamesToElements.put(child.getName(), child);
/* 231 */         currentElem = child;
/*     */         
/*     */         continue;
/*     */       } 
/* 235 */       if (currentElem.getName() == child.getName()) {
/*     */         
/* 237 */         combineTypes(currentElem.getType(), child.getType(), options);
/* 238 */         combineElementComments(currentElem, child);
/*     */         
/* 240 */         currentElem.setMinOccurs(0);
/* 241 */         currentElem.setMaxOccurs(-1);
/*     */         
/*     */         continue;
/*     */       } 
/* 245 */       Element sameElem = (Element)elemNamesToElements.get(child.getName());
/* 246 */       if (sameElem == null) {
/*     */         
/* 248 */         checkIfElementReferenceIsNeeded(child, parentNamespace, typeSystemHolder, options);
/* 249 */         elemType.addElement(child);
/* 250 */         elemNamesToElements.put(child.getName(), child);
/*     */       }
/*     */       else {
/*     */         
/* 254 */         combineTypes(currentElem.getType(), child.getType(), options);
/* 255 */         combineElementComments(currentElem, child);
/* 256 */         elemType.setTopParticleForComplexOrMixedContent(2);
/*     */       } 
/* 258 */       currentElem = child;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkIfElementReferenceIsNeeded(Element child, String parentNamespace, TypeSystemHolder typeSystemHolder, Inst2XsdOptions options) {
/* 266 */     if (!child.getName().getNamespaceURI().equals(parentNamespace)) {
/*     */       
/* 268 */       Element referencedElem = new Element();
/* 269 */       referencedElem.setGlobal(true);
/* 270 */       referencedElem.setName(child.getName());
/* 271 */       referencedElem.setType(child.getType());
/*     */       
/* 273 */       if (child.isNillable()) {
/*     */         
/* 275 */         referencedElem.setNillable(true);
/* 276 */         child.setNillable(false);
/*     */       } 
/*     */       
/* 279 */       referencedElem = addGlobalElement(referencedElem, typeSystemHolder, options);
/*     */       
/* 281 */       child.setRef(referencedElem);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkIfReferenceToGlobalTypeIsNeeded(Element elem, TypeSystemHolder typeSystemHolder, Inst2XsdOptions options) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processAttributesInComplexType(Type elemType, List attributes) {
/* 293 */     assert elemType.isComplexType();
/* 294 */     for (Iterator iterator = attributes.iterator(); iterator.hasNext(); ) {
/*     */       
/* 296 */       Attribute att = iterator.next();
/* 297 */       elemType.addAttribute(att);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Attribute processAttribute(XmlCursor xc, Inst2XsdOptions options, String parentNamespace, TypeSystemHolder typeSystemHolder) {
/* 304 */     assert xc.isAttr() : "xc not on attribute";
/* 305 */     Attribute attribute = new Attribute();
/* 306 */     QName attName = xc.getName();
/*     */     
/* 308 */     attribute.setName(attName);
/*     */     
/* 310 */     XmlCursor parent = xc.newCursor();
/* 311 */     parent.toParent();
/*     */     
/* 313 */     Type simpleContentType = Type.createNamedType(processSimpleContentType(xc.getTextValue(), options, parent), 1);
/*     */ 
/*     */     
/* 316 */     parent.dispose();
/*     */     
/* 318 */     attribute.setType(simpleContentType);
/*     */     
/* 320 */     checkIfAttributeReferenceIsNeeded(attribute, parentNamespace, typeSystemHolder);
/*     */     
/* 322 */     return attribute;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkIfAttributeReferenceIsNeeded(Attribute attribute, String parentNamespace, TypeSystemHolder typeSystemHolder) {
/* 327 */     if (!attribute.getName().getNamespaceURI().equals("") && !attribute.getName().getNamespaceURI().equals(parentNamespace)) {
/*     */ 
/*     */ 
/*     */       
/* 331 */       Attribute referencedAtt = new Attribute();
/* 332 */       referencedAtt.setGlobal(true);
/* 333 */       referencedAtt.setName(attribute.getName());
/* 334 */       referencedAtt.setType(attribute.getType());
/*     */       
/* 336 */       typeSystemHolder.addGlobalAttribute(referencedAtt);
/*     */       
/* 338 */       attribute.setRef(referencedAtt);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected class SCTValidationContext
/*     */     implements ValidationContext
/*     */   {
/*     */     protected boolean valid = true;
/*     */     private final RussianDollStrategy this$0;
/*     */     
/*     */     public boolean isValid() {
/* 349 */       return this.valid;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resetToValid() {
/* 354 */       this.valid = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void invalid(String message) {
/* 359 */       this.valid = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void invalid(String code, Object[] args) {
/* 364 */       this.valid = false;
/*     */     }
/*     */   }
/*     */   
/* 368 */   private SCTValidationContext _validationContext = new SCTValidationContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected QName processSimpleContentType(String lexicalValue, Inst2XsdOptions options, final XmlCursor xc) {
/* 382 */     if (options.getSimpleContentTypes() == 2) {
/* 383 */       return XmlString.type.getName();
/*     */     }
/* 385 */     if (options.getSimpleContentTypes() != 1) {
/* 386 */       throw new IllegalArgumentException("Unknown value for Inst2XsdOptions.getSimpleContentTypes() :" + options.getSimpleContentTypes());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 393 */       XsTypeConverter.lexByte(lexicalValue);
/* 394 */       return XmlByte.type.getName();
/*     */     }
/* 396 */     catch (Exception e) {
/*     */ 
/*     */       
/*     */       try {
/* 400 */         XsTypeConverter.lexShort(lexicalValue);
/* 401 */         return XmlShort.type.getName();
/*     */       }
/* 403 */       catch (Exception exception) {
/*     */ 
/*     */         
/*     */         try {
/* 407 */           XsTypeConverter.lexInt(lexicalValue);
/* 408 */           return XmlInt.type.getName();
/*     */         }
/* 410 */         catch (Exception exception1) {
/*     */ 
/*     */           
/*     */           try {
/* 414 */             XsTypeConverter.lexLong(lexicalValue);
/* 415 */             return XmlLong.type.getName();
/*     */           }
/* 417 */           catch (Exception exception2) {
/*     */ 
/*     */             
/*     */             try {
/* 421 */               XsTypeConverter.lexInteger(lexicalValue);
/* 422 */               return XmlInteger.type.getName();
/*     */             }
/* 424 */             catch (Exception exception3) {
/*     */ 
/*     */               
/*     */               try {
/* 428 */                 XsTypeConverter.lexFloat(lexicalValue);
/* 429 */                 return XmlFloat.type.getName();
/*     */               }
/* 431 */               catch (Exception exception4) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 448 */                 XmlDateImpl.validateLexical(lexicalValue, XmlDate.type, this._validationContext);
/* 449 */                 if (this._validationContext.isValid())
/* 450 */                   return XmlDate.type.getName(); 
/* 451 */                 this._validationContext.resetToValid();
/*     */                 
/* 453 */                 XmlDateTimeImpl.validateLexical(lexicalValue, XmlDateTime.type, this._validationContext);
/* 454 */                 if (this._validationContext.isValid())
/* 455 */                   return XmlDateTime.type.getName(); 
/* 456 */                 this._validationContext.resetToValid();
/*     */                 
/* 458 */                 XmlTimeImpl.validateLexical(lexicalValue, XmlTime.type, this._validationContext);
/* 459 */                 if (this._validationContext.isValid())
/* 460 */                   return XmlTime.type.getName(); 
/* 461 */                 this._validationContext.resetToValid();
/*     */                 
/* 463 */                 XmlDurationImpl.validateLexical(lexicalValue, XmlDuration.type, this._validationContext);
/* 464 */                 if (this._validationContext.isValid())
/* 465 */                   return XmlDuration.type.getName(); 
/* 466 */                 this._validationContext.resetToValid();
/*     */ 
/*     */                 
/* 469 */                 if (lexicalValue.startsWith("http://") || lexicalValue.startsWith("www.")) {
/*     */                   
/* 471 */                   XmlAnyUriImpl.validateLexical(lexicalValue, this._validationContext);
/* 472 */                   if (this._validationContext.isValid())
/* 473 */                     return XmlAnyURI.type.getName(); 
/* 474 */                   this._validationContext.resetToValid();
/*     */                 } 
/*     */ 
/*     */                 
/* 478 */                 int idx = lexicalValue.indexOf(':');
/* 479 */                 if (idx >= 0 && idx == lexicalValue.lastIndexOf(':') && idx + 1 < lexicalValue.length()) {
/*     */                   
/* 481 */                   PrefixResolver prefixResolver = new PrefixResolver() { private final XmlCursor val$xc; private final RussianDollStrategy this$0;
/*     */                       
/*     */                       public String getNamespaceForPrefix(String prefix) {
/* 484 */                         return xc.namespaceForPrefix(prefix);
/*     */                       } }
/*     */                     ;
/* 487 */                   QName qname = XmlQNameImpl.validateLexical(lexicalValue, this._validationContext, prefixResolver);
/* 488 */                   if (this._validationContext.isValid())
/* 489 */                     return XmlQName.type.getName(); 
/* 490 */                   this._validationContext.resetToValid();
/*     */                 } 
/*     */ 
/*     */ 
/*     */                 
/* 495 */                 return XmlString.type.getName();
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 501 */     }  } protected void combineTypes(Type into, Type with, Inst2XsdOptions options) { if (into == with) {
/*     */       return;
/*     */     }
/* 504 */     if (into.isGlobal() && with.isGlobal() && into.getName().equals(with.getName())) {
/*     */       return;
/*     */     }
/*     */     
/* 508 */     if (into.getContentType() == 1 && with.getContentType() == 1) {
/*     */ 
/*     */       
/* 511 */       combineSimpleTypes(into, with, options);
/*     */       
/*     */       return;
/*     */     } 
/* 515 */     if ((into.getContentType() == 1 || into.getContentType() == 2) && (with.getContentType() == 1 || with.getContentType() == 2)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 521 */       QName intoTypeName = into.isComplexType() ? into.getExtensionType().getName() : into.getName();
/* 522 */       QName withTypeName = with.isComplexType() ? with.getExtensionType().getName() : with.getName();
/*     */ 
/*     */       
/* 525 */       into.setContentType(2);
/*     */       
/* 527 */       QName moreGeneralTypeName = combineToMoreGeneralSimpleType(intoTypeName, withTypeName);
/* 528 */       if (into.isComplexType()) {
/*     */         
/* 530 */         Type extendedType = Type.createNamedType(moreGeneralTypeName, 1);
/* 531 */         into.setExtensionType(extendedType);
/*     */       } else {
/*     */         
/* 534 */         into.setName(moreGeneralTypeName);
/*     */       } 
/* 536 */       combineAttributesOfTypes(into, with);
/*     */       
/*     */       return;
/*     */     } 
/* 540 */     if (into.getContentType() == 3 && with.getContentType() == 3) {
/*     */ 
/*     */       
/* 543 */       combineAttributesOfTypes(into, with);
/* 544 */       combineElementsOfTypes(into, with, false, options);
/*     */       
/*     */       return;
/*     */     } 
/* 548 */     if (into.getContentType() == 1 || into.getContentType() == 2 || with.getContentType() == 1 || with.getContentType() == 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 553 */       into.setContentType(4);
/* 554 */       combineAttributesOfTypes(into, with);
/* 555 */       combineElementsOfTypes(into, with, true, options);
/*     */       
/*     */       return;
/*     */     } 
/* 559 */     if ((into.getContentType() == 1 || into.getContentType() == 2 || into.getContentType() == 3 || into.getContentType() == 4) && (with.getContentType() == 1 || with.getContentType() == 2 || with.getContentType() == 3 || with.getContentType() == 4)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 568 */       into.setContentType(4);
/* 569 */       combineAttributesOfTypes(into, with);
/* 570 */       combineElementsOfTypes(into, with, false, options);
/*     */       
/*     */       return;
/*     */     } 
/* 574 */     throw new IllegalArgumentException("Unknown content type."); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void combineSimpleTypes(Type into, Type with, Inst2XsdOptions options) {
/* 580 */     assert into.getContentType() == 1 && with.getContentType() == 1 : "Invalid arguments";
/*     */ 
/*     */     
/* 583 */     into.setName(combineToMoreGeneralSimpleType(into.getName(), with.getName()));
/*     */ 
/*     */     
/* 586 */     if (options.isUseEnumerations()) {
/*     */       
/* 588 */       into.addAllEnumerationsFrom(with);
/*     */       
/* 590 */       if (into.getEnumerationValues().size() > options.getUseEnumerations())
/*     */       {
/* 592 */         into.closeEnumeration();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected QName combineToMoreGeneralSimpleType(QName t1, QName t2) {
/* 599 */     if (t1.equals(t2)) {
/* 600 */       return t1;
/*     */     }
/* 602 */     if (t2.equals(XmlShort.type.getName()) && t1.equals(XmlByte.type.getName()))
/* 603 */       return t2; 
/* 604 */     if (t1.equals(XmlShort.type.getName()) && t2.equals(XmlByte.type.getName())) {
/* 605 */       return t1;
/*     */     }
/* 607 */     if (t2.equals(XmlInt.type.getName()) && (t1.equals(XmlShort.type.getName()) || t1.equals(XmlByte.type.getName())))
/*     */     {
/* 609 */       return t2; } 
/* 610 */     if (t1.equals(XmlInt.type.getName()) && (t2.equals(XmlShort.type.getName()) || t2.equals(XmlByte.type.getName())))
/*     */     {
/* 612 */       return t1;
/*     */     }
/* 614 */     if (t2.equals(XmlLong.type.getName()) && (t1.equals(XmlInt.type.getName()) || t1.equals(XmlShort.type.getName()) || t1.equals(XmlByte.type.getName())))
/*     */     {
/* 616 */       return t2; } 
/* 617 */     if (t1.equals(XmlLong.type.getName()) && (t2.equals(XmlInt.type.getName()) || t2.equals(XmlShort.type.getName()) || t2.equals(XmlByte.type.getName())))
/*     */     {
/* 619 */       return t1;
/*     */     }
/* 621 */     if (t2.equals(XmlInteger.type.getName()) && (t1.equals(XmlLong.type.getName()) || t1.equals(XmlInt.type.getName()) || t1.equals(XmlShort.type.getName()) || t1.equals(XmlByte.type.getName())))
/*     */     {
/*     */       
/* 624 */       return t2; } 
/* 625 */     if (t1.equals(XmlInteger.type.getName()) && (t2.equals(XmlLong.type.getName()) || t2.equals(XmlInt.type.getName()) || t2.equals(XmlShort.type.getName()) || t2.equals(XmlByte.type.getName())))
/*     */     {
/*     */       
/* 628 */       return t1;
/*     */     }
/* 630 */     if (t2.equals(XmlFloat.type.getName()) && (t1.equals(XmlInteger.type.getName()) || t1.equals(XmlLong.type.getName()) || t1.equals(XmlInt.type.getName()) || t1.equals(XmlShort.type.getName()) || t1.equals(XmlByte.type.getName())))
/*     */     {
/*     */ 
/*     */       
/* 634 */       return t2; } 
/* 635 */     if (t1.equals(XmlFloat.type.getName()) && (t2.equals(XmlInteger.type.getName()) || t2.equals(XmlLong.type.getName()) || t2.equals(XmlInt.type.getName()) || t2.equals(XmlShort.type.getName()) || t2.equals(XmlByte.type.getName())))
/*     */     {
/*     */ 
/*     */       
/* 639 */       return t1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 644 */     return XmlString.type.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void combineAttributesOfTypes(Type into, Type from) {
/*     */     int i;
/* 651 */     for (i = 0; i < from.getAttributes().size(); i++) {
/*     */       
/* 653 */       Attribute fromAtt = from.getAttributes().get(i);
/* 654 */       int j = 0; while (true) { if (j < into.getAttributes().size()) {
/*     */           
/* 656 */           Attribute intoAtt = into.getAttributes().get(j);
/* 657 */           if (intoAtt.getName().equals(fromAtt.getName())) {
/*     */             
/* 659 */             intoAtt.getType().setName(combineToMoreGeneralSimpleType(intoAtt.getType().getName(), fromAtt.getType().getName()));
/*     */             break;
/*     */           } 
/*     */           j++;
/*     */           continue;
/*     */         } 
/* 665 */         into.addAttribute(fromAtt);
/*     */         
/*     */         break; }
/*     */     
/*     */     } 
/* 670 */     for (i = 0; i < into.getAttributes().size(); i++) {
/*     */       
/* 672 */       Attribute intoAtt = into.getAttributes().get(i);
/* 673 */       for (int j = 0; j < from.getAttributes().size(); j++) {
/*     */         
/* 675 */         Attribute fromAtt = from.getAttributes().get(j);
/* 676 */         if (fromAtt.getName().equals(intoAtt.getName()));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 682 */       intoAtt.setOptional(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void combineElementsOfTypes(Type into, Type from, boolean makeElementsOptional, Inst2XsdOptions options) {
/* 688 */     boolean needsUnboundedChoice = false;
/*     */     
/* 690 */     if (into.getTopParticleForComplexOrMixedContent() != 1 || from.getTopParticleForComplexOrMixedContent() != 1)
/*     */     {
/* 692 */       needsUnboundedChoice = true;
/*     */     }
/* 694 */     List res = new ArrayList();
/*     */     
/* 696 */     int fromStartingIndex = 0;
/* 697 */     int fromMatchedIndex = -1;
/* 698 */     int intoMatchedIndex = -1;
/*     */ 
/*     */     
/* 701 */     for (int i = 0; !needsUnboundedChoice && i < into.getElements().size(); i++) {
/*     */ 
/*     */       
/* 704 */       Element intoElement = into.getElements().get(i);
/* 705 */       for (int k = fromStartingIndex; k < from.getElements().size(); k++) {
/*     */         
/* 707 */         Element fromElement = from.getElements().get(k);
/* 708 */         if (intoElement.getName().equals(fromElement.getName())) {
/*     */           
/* 710 */           fromMatchedIndex = k;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 716 */       if (fromMatchedIndex < fromStartingIndex) {
/*     */         
/* 718 */         res.add(intoElement);
/* 719 */         intoElement.setMinOccurs(0);
/*     */       } else {
/*     */         int j2;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 726 */         label77: for (j2 = fromStartingIndex; j2 < fromMatchedIndex; j2++) {
/*     */           
/* 728 */           Element fromCandidate = from.getElements().get(j2);
/*     */           
/* 730 */           for (int i2 = i + 1; i2 < into.getElements().size(); i2++) {
/*     */             
/* 732 */             Element intoCandidate = into.getElements().get(i2);
/* 733 */             if (fromCandidate.getName().equals(intoCandidate.getName())) {
/*     */               
/* 735 */               intoMatchedIndex = i2;
/*     */               
/*     */               break label77;
/*     */             } 
/*     */           } 
/*     */         } 
/* 741 */         if (intoMatchedIndex < i) {
/*     */ 
/*     */           
/* 744 */           for (int j3 = fromStartingIndex; j3 < fromMatchedIndex; j3++) {
/*     */             
/* 746 */             Element fromCandidate = from.getElements().get(j3);
/* 747 */             res.add(fromCandidate);
/* 748 */             fromCandidate.setMinOccurs(0);
/*     */           } 
/*     */           
/* 751 */           res.add(intoElement);
/* 752 */           Element fromMatchedElement = from.getElements().get(fromMatchedIndex);
/*     */           
/* 754 */           if (fromMatchedElement.getMinOccurs() <= 0)
/* 755 */             intoElement.setMinOccurs(0); 
/* 756 */           if (fromMatchedElement.getMaxOccurs() == -1) {
/* 757 */             intoElement.setMaxOccurs(-1);
/*     */           }
/* 759 */           combineTypes(intoElement.getType(), fromMatchedElement.getType(), options);
/* 760 */           combineElementComments(intoElement, fromMatchedElement);
/*     */           
/* 762 */           fromStartingIndex = fromMatchedIndex + 1;
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 768 */           needsUnboundedChoice = true;
/*     */         } 
/*     */       } 
/*     */     }  int j;
/* 772 */     for (j = fromStartingIndex; j < from.getElements().size(); j++) {
/*     */       
/* 774 */       Element remainingFromElement = from.getElements().get(j);
/* 775 */       res.add(remainingFromElement);
/* 776 */       remainingFromElement.setMinOccurs(0);
/*     */     } 
/*     */ 
/*     */     
/* 780 */     if (needsUnboundedChoice) {
/*     */       
/* 782 */       into.setTopParticleForComplexOrMixedContent(2);
/*     */ 
/*     */       
/* 785 */       for (j = 0; j < from.getElements().size(); j++) {
/*     */         
/* 787 */         Element fromElem = from.getElements().get(j);
/* 788 */         int k = 0; while (true) { if (k < into.getElements().size()) {
/*     */             
/* 790 */             Element intoElem = into.getElements().get(k);
/* 791 */             intoElem.setMinOccurs(1);
/* 792 */             intoElem.setMaxOccurs(1);
/*     */             
/* 794 */             if (intoElem == fromElem) {
/*     */               break;
/*     */             }
/* 797 */             if (intoElem.getName().equals(fromElem.getName())) {
/*     */               
/* 799 */               combineTypes(intoElem.getType(), fromElem.getType(), options);
/* 800 */               combineElementComments(intoElem, fromElem);
/*     */               
/*     */               break;
/*     */             } 
/*     */             k++;
/*     */             continue;
/*     */           } 
/* 807 */           into.addElement(fromElem);
/* 808 */           fromElem.setMinOccurs(1);
/* 809 */           fromElem.setMaxOccurs(1);
/*     */           
/*     */           break; }
/*     */       
/*     */       } 
/*     */       return;
/*     */     } 
/* 816 */     into.setElements(res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void combineElementComments(Element into, Element with) {
/* 823 */     if (with.getComment() != null && with.getComment().length() > 0)
/*     */     {
/* 825 */       if (into.getComment() == null) {
/* 826 */         into.setComment(with.getComment());
/*     */       } else {
/* 828 */         into.setComment(into.getComment() + with.getComment());
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xsd\RussianDollStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */