/*     */ package org.apache.xmlbeans.impl.inst2xsd;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlError;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.inst2xsd.util.TypeSystemHolder;
/*     */ import org.apache.xmlbeans.impl.tool.CommandLine;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Inst2Xsd
/*     */ {
/*     */   public static void main(String[] args) {
/*  49 */     if (args == null || args.length == 0) {
/*     */       
/*  51 */       printHelp();
/*  52 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  56 */     Set flags = new HashSet();
/*  57 */     flags.add("h");
/*  58 */     flags.add("help");
/*  59 */     flags.add("usage");
/*  60 */     flags.add("license");
/*  61 */     flags.add("version");
/*  62 */     flags.add("verbose");
/*  63 */     flags.add("validate");
/*     */     
/*  65 */     Set opts = new HashSet();
/*  66 */     opts.add("design");
/*  67 */     opts.add("simple-content-types");
/*  68 */     opts.add("enumerations");
/*  69 */     opts.add("outDir");
/*  70 */     opts.add("outPrefix");
/*     */     
/*  72 */     CommandLine cl = new CommandLine(args, flags, opts);
/*  73 */     Inst2XsdOptions inst2XsdOptions = new Inst2XsdOptions();
/*     */     
/*  75 */     if (cl.getOpt("license") != null) {
/*     */       
/*  77 */       CommandLine.printLicense();
/*  78 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  82 */     if (cl.getOpt("version") != null) {
/*     */       
/*  84 */       CommandLine.printVersion();
/*  85 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  89 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*     */       
/*  91 */       printHelp();
/*  92 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     String[] badopts = cl.getBadOpts();
/*  97 */     if (badopts.length > 0) {
/*     */       
/*  99 */       for (int j = 0; j < badopts.length; j++)
/* 100 */         System.out.println("Unrecognized option: " + badopts[j]); 
/* 101 */       printHelp();
/* 102 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 106 */     String design = cl.getOpt("design");
/* 107 */     if (design != null)
/*     */     {
/*     */ 
/*     */       
/* 111 */       if (design.equals("vb")) {
/*     */         
/* 113 */         inst2XsdOptions.setDesign(3);
/*     */       }
/* 115 */       else if (design.equals("rd")) {
/*     */         
/* 117 */         inst2XsdOptions.setDesign(1);
/*     */       }
/* 119 */       else if (design.equals("ss")) {
/*     */         
/* 121 */         inst2XsdOptions.setDesign(2);
/*     */       }
/*     */       else {
/*     */         
/* 125 */         printHelp();
/* 126 */         System.exit(0);
/*     */         return;
/*     */       } 
/*     */     }
/* 130 */     String simpleContent = cl.getOpt("simple-content-types");
/* 131 */     if (simpleContent != null)
/*     */     {
/*     */ 
/*     */       
/* 135 */       if (simpleContent.equals("smart")) {
/*     */         
/* 137 */         inst2XsdOptions.setSimpleContentTypes(1);
/*     */       }
/* 139 */       else if (simpleContent.equals("string")) {
/*     */         
/* 141 */         inst2XsdOptions.setSimpleContentTypes(2);
/*     */       }
/*     */       else {
/*     */         
/* 145 */         printHelp();
/* 146 */         System.exit(0);
/*     */         return;
/*     */       } 
/*     */     }
/* 150 */     String enumerations = cl.getOpt("enumerations");
/* 151 */     if (enumerations != null)
/*     */     {
/*     */ 
/*     */       
/* 155 */       if (enumerations.equals("never")) {
/*     */         
/* 157 */         inst2XsdOptions.setUseEnumerations(1);
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/*     */           
/* 163 */           int intVal = Integer.parseInt(enumerations);
/* 164 */           inst2XsdOptions.setUseEnumerations(intVal);
/*     */         }
/* 166 */         catch (NumberFormatException e) {
/*     */           
/* 168 */           printHelp();
/* 169 */           System.exit(0);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/* 174 */     File outDir = new File((cl.getOpt("outDir") == null) ? "." : cl.getOpt("outDir"));
/*     */     
/* 176 */     String outPrefix = cl.getOpt("outPrefix");
/* 177 */     if (outPrefix == null) {
/* 178 */       outPrefix = "schema";
/*     */     }
/* 180 */     inst2XsdOptions.setVerbose((cl.getOpt("verbose") != null));
/* 181 */     boolean validate = (cl.getOpt("validate") != null);
/*     */     
/* 183 */     File[] xmlFiles = cl.filesEndingWith(".xml");
/* 184 */     XmlObject[] xmlInstances = new XmlObject[xmlFiles.length];
/*     */     
/* 186 */     if (xmlInstances.length == 0) {
/*     */       
/* 188 */       printHelp();
/* 189 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 193 */     int i = 0;
/*     */     
/*     */     try {
/* 196 */       for (i = 0; i < xmlFiles.length; i++)
/*     */       {
/* 198 */         xmlInstances[i] = XmlObject.Factory.parse(xmlFiles[i]);
/*     */       }
/*     */     }
/* 201 */     catch (XmlException e) {
/*     */       
/* 203 */       System.err.println("Invalid xml file: '" + xmlFiles[i].getName() + "'. " + e.getMessage());
/*     */       
/*     */       return;
/* 206 */     } catch (IOException e) {
/*     */       
/* 208 */       System.err.println("Could not read file: '" + xmlFiles[i].getName() + "'. " + e.getMessage());
/*     */       
/*     */       return;
/*     */     } 
/* 212 */     SchemaDocument[] schemaDocs = inst2xsd(xmlInstances, inst2XsdOptions);
/*     */ 
/*     */     
/*     */     try {
/* 216 */       for (i = 0; i < schemaDocs.length; i++)
/*     */       {
/* 218 */         SchemaDocument schema = schemaDocs[i];
/*     */         
/* 220 */         if (inst2XsdOptions.isVerbose()) {
/* 221 */           System.out.println("----------------------\n\n" + schema);
/*     */         }
/* 223 */         schema.save(new File(outDir, outPrefix + i + ".xsd"), (new XmlOptions()).setSavePrettyPrint());
/*     */       }
/*     */     
/* 226 */     } catch (IOException e) {
/*     */       
/* 228 */       System.err.println("Could not write file: '" + outDir + File.pathSeparator + outPrefix + i + ".xsd" + "'. " + e.getMessage());
/*     */       
/*     */       return;
/*     */     } 
/* 232 */     if (validate)
/*     */     {
/* 234 */       validateInstances(schemaDocs, xmlInstances);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void printHelp() {
/* 240 */     System.out.println("Generates XMLSchema from instance xml documents.");
/* 241 */     System.out.println("Usage: inst2xsd [opts] [instance.xml]*");
/* 242 */     System.out.println("Options include:");
/* 243 */     System.out.println("    -design [rd|ss|vb] - XMLSchema design type");
/* 244 */     System.out.println("             rd  - Russian Doll Design - local elements and local types");
/* 245 */     System.out.println("             ss  - Salami Slice Design - global elements and local types");
/* 246 */     System.out.println("             vb  - Venetian Blind Design (default) - local elements and global complex types");
/* 247 */     System.out.println("    -simple-content-types [smart|string] - Simple content types detection (leaf text). Smart is the default");
/* 248 */     System.out.println("    -enumerations [never|NUMBER] - Use enumerations. Default value is 10.");
/* 249 */     System.out.println("    -outDir [dir] - Directory for output files. Default is '.'");
/* 250 */     System.out.println("    -outPrefix [file_name_prefix] - Prefix for output file names. Default is 'schema'");
/* 251 */     System.out.println("    -validate - Validates input instances agaist generated schemas.");
/* 252 */     System.out.println("    -verbose - print more informational messages");
/* 253 */     System.out.println("    -license - print license information");
/* 254 */     System.out.println("    -help - help imformation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SchemaDocument[] inst2xsd(Reader[] instReaders, Inst2XsdOptions options) throws IOException, XmlException {
/* 264 */     XmlObject[] instances = new XmlObject[instReaders.length];
/* 265 */     for (int i = 0; i < instReaders.length; i++)
/*     */     {
/* 267 */       instances[i] = XmlObject.Factory.parse(instReaders[i]);
/*     */     }
/* 269 */     return inst2xsd(instances, options);
/*     */   }
/*     */   
/*     */   public static SchemaDocument[] inst2xsd(XmlObject[] instances, Inst2XsdOptions options) {
/*     */     XsdGenStrategy strategy;
/* 274 */     if (options == null) {
/* 275 */       options = new Inst2XsdOptions();
/*     */     }
/*     */     
/* 278 */     TypeSystemHolder typeSystemHolder = new TypeSystemHolder();
/*     */ 
/*     */     
/* 281 */     switch (options.getDesign()) {
/*     */       
/*     */       case 1:
/* 284 */         strategy = new RussianDollStrategy();
/*     */         break;
/*     */       
/*     */       case 2:
/* 288 */         strategy = new SalamiSliceStrategy();
/*     */         break;
/*     */       
/*     */       case 3:
/* 292 */         strategy = new VenetianBlindStrategy();
/*     */         break;
/*     */       
/*     */       default:
/* 296 */         throw new IllegalArgumentException("Unknown design.");
/*     */     } 
/*     */     
/* 299 */     strategy.processDoc(instances, options, typeSystemHolder);
/*     */     
/* 301 */     if (options.isVerbose()) {
/* 302 */       System.out.println("typeSystemHolder.toString(): " + typeSystemHolder);
/*     */     }
/* 304 */     SchemaDocument[] sDocs = typeSystemHolder.getSchemaDocuments();
/*     */     
/* 306 */     return sDocs;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean validateInstances(SchemaDocument[] sDocs, XmlObject[] instances) {
/*     */     SchemaTypeLoader sLoader;
/* 312 */     Collection compErrors = new ArrayList();
/* 313 */     XmlOptions schemaOptions = new XmlOptions();
/* 314 */     schemaOptions.setErrorListener(compErrors);
/*     */     
/*     */     try {
/* 317 */       sLoader = XmlBeans.loadXsd((XmlObject[])sDocs, schemaOptions);
/*     */     }
/* 319 */     catch (Exception e) {
/*     */       
/* 321 */       if (compErrors.isEmpty() || !(e instanceof XmlException))
/*     */       {
/* 323 */         e.printStackTrace(System.out);
/*     */       }
/* 325 */       System.out.println("\n-------------------\n\nInvalid schemas.");
/* 326 */       for (Iterator errors = compErrors.iterator(); errors.hasNext(); ) {
/*     */         
/* 328 */         XmlError xe = errors.next();
/* 329 */         System.out.println(xe.getLine() + ":" + xe.getColumn() + " " + xe.getMessage());
/*     */       } 
/* 331 */       return false;
/*     */     } 
/*     */     
/* 334 */     System.out.println("\n-------------------");
/* 335 */     boolean result = true;
/*     */     
/* 337 */     for (int i = 0; i < instances.length; i++) {
/*     */       XmlObject xobj;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 343 */         xobj = sLoader.parse(instances[i].newXMLStreamReader(), null, (new XmlOptions()).setLoadLineNumbers());
/*     */       }
/* 345 */       catch (XmlException e) {
/*     */         
/* 347 */         System.out.println("Error:\n" + instances[i].documentProperties().getSourceName() + " not loadable: " + e);
/* 348 */         e.printStackTrace(System.out);
/* 349 */         result = false;
/*     */       } 
/*     */ 
/*     */       
/* 353 */       Collection errors = new ArrayList();
/*     */       
/* 355 */       if (xobj.schemaType() == XmlObject.type) {
/*     */         
/* 357 */         System.out.println(instances[i].documentProperties().getSourceName() + " NOT valid.  ");
/* 358 */         System.out.println("  Document type not found.");
/* 359 */         result = false;
/*     */       }
/* 361 */       else if (xobj.validate((new XmlOptions()).setErrorListener(errors))) {
/* 362 */         System.out.println("Instance[" + i + "] valid - " + instances[i].documentProperties().getSourceName());
/*     */       } else {
/*     */         
/* 365 */         System.out.println("Instance[" + i + "] NOT valid - " + instances[i].documentProperties().getSourceName());
/* 366 */         for (Iterator it = errors.iterator(); it.hasNext(); ) {
/*     */           
/* 368 */           XmlError xe = it.next();
/* 369 */           System.out.println(xe.getLine() + ":" + xe.getColumn() + " " + xe.getMessage());
/*     */         } 
/* 371 */         result = false;
/*     */       } 
/*     */     } 
/*     */     
/* 375 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xsd\Inst2Xsd.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */