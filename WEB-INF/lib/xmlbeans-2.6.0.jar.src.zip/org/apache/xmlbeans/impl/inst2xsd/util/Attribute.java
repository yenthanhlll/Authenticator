/*    */ package org.apache.xmlbeans.impl.inst2xsd.util;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Attribute
/*    */ {
/*    */   private QName _name;
/*    */   private Type _type;
/* 26 */   private Attribute _ref = null;
/*    */   private boolean _isGlobal = false;
/*    */   private boolean _isOptional = false;
/*    */   static final boolean $assertionsDisabled;
/*    */   
/*    */   public QName getName() {
/* 32 */     return this._name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setName(QName name) {
/* 37 */     this._name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public Type getType() {
/* 42 */     return isRef() ? getRef().getType() : this._type;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(Type type) {
/* 47 */     assert !isRef();
/* 48 */     this._type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRef() {
/* 53 */     return (this._ref != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Attribute getRef() {
/* 58 */     return this._ref;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRef(Attribute ref) {
/* 63 */     assert !isGlobal();
/* 64 */     this._ref = ref;
/* 65 */     this._type = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGlobal() {
/* 70 */     return this._isGlobal;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setGlobal(boolean isGlobal) {
/* 75 */     this._isGlobal = isGlobal;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOptional() {
/* 80 */     return this._isOptional;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setOptional(boolean isOptional) {
/* 85 */     assert isOptional && !isGlobal() : "Global attributes cannot be optional.";
/* 86 */     this._isOptional = isOptional;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return "\n    Attribute{_name=" + this._name + ", _type=" + this._type + ", _ref=" + ((this._ref != null) ? 1 : 0) + ", _isGlobal=" + this._isGlobal + ", _isOptional=" + this._isOptional + "}";
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xs\\util\Attribute.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */