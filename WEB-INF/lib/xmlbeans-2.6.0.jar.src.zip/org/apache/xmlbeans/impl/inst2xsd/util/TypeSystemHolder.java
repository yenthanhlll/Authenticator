/*     */ package org.apache.xmlbeans.impl.inst2xsd.util;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.DocumentationDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Element;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ExplicitGroup;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.FormChoice;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalComplexType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalElement;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.NoFixedFacet;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.RestrictionDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleContentDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleExtensionType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelAttribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelComplexType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeSystemHolder
/*     */ {
/*  41 */   Map _globalElements = new LinkedHashMap();
/*  42 */   Map _globalAttributes = new LinkedHashMap();
/*  43 */   Map _globalTypes = new LinkedHashMap();
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public void addGlobalElement(Element element) {
/*  48 */     assert element.isGlobal() && !element.isRef();
/*  49 */     this._globalElements.put(element.getName(), element);
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getGlobalElement(QName name) {
/*  54 */     return (Element)this._globalElements.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Element[] getGlobalElements() {
/*  59 */     Collection col = this._globalElements.values();
/*  60 */     return (Element[])col.toArray((Object[])new Element[col.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addGlobalAttribute(Attribute attribute) {
/*  65 */     assert attribute.isGlobal() && !attribute.isRef();
/*  66 */     this._globalAttributes.put(attribute.getName(), attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   public Attribute getGlobalAttribute(QName name) {
/*  71 */     return (Attribute)this._globalAttributes.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Attribute[] getGlobalAttributes() {
/*  76 */     Collection col = this._globalAttributes.values();
/*  77 */     return (Attribute[])col.toArray((Object[])new Attribute[col.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addGlobalType(Type type) {
/*  82 */     assert type.isGlobal() && type.getName() != null : "type must be a global type before being added.";
/*  83 */     this._globalTypes.put(type.getName(), type);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getGlobalType(QName name) {
/*  88 */     return (Type)this._globalTypes.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type[] getGlobalTypes() {
/*  93 */     Collection col = this._globalTypes.values();
/*  94 */     return (Type[])col.toArray((Object[])new Type[col.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaDocument[] getSchemaDocuments() {
/* 100 */     Map nsToSchemaDocs = new LinkedHashMap();
/*     */     
/* 102 */     for (Iterator iterator2 = this._globalElements.keySet().iterator(); iterator2.hasNext(); ) {
/*     */       
/* 104 */       QName globalElemName = iterator2.next();
/* 105 */       String tns = globalElemName.getNamespaceURI();
/* 106 */       SchemaDocument schDoc = getSchemaDocumentForTNS(nsToSchemaDocs, tns);
/*     */       
/* 108 */       fillUpGlobalElement((Element)this._globalElements.get(globalElemName), schDoc, tns);
/*     */     } 
/*     */     
/* 111 */     for (Iterator iterator1 = this._globalAttributes.keySet().iterator(); iterator1.hasNext(); ) {
/*     */       
/* 113 */       QName globalAttName = iterator1.next();
/* 114 */       String tns = globalAttName.getNamespaceURI();
/* 115 */       SchemaDocument schDoc = getSchemaDocumentForTNS(nsToSchemaDocs, tns);
/*     */       
/* 117 */       fillUpGlobalAttribute((Attribute)this._globalAttributes.get(globalAttName), schDoc, tns);
/*     */     } 
/*     */     
/* 120 */     for (Iterator iterator = this._globalTypes.keySet().iterator(); iterator.hasNext(); ) {
/*     */       
/* 122 */       QName globalTypeName = iterator.next();
/* 123 */       String tns = globalTypeName.getNamespaceURI();
/* 124 */       SchemaDocument schDoc = getSchemaDocumentForTNS(nsToSchemaDocs, tns);
/*     */       
/* 126 */       fillUpGlobalType((Type)this._globalTypes.get(globalTypeName), schDoc, tns);
/*     */     } 
/*     */     
/* 129 */     Collection schDocColl = nsToSchemaDocs.values();
/* 130 */     return (SchemaDocument[])schDocColl.toArray((Object[])new SchemaDocument[schDocColl.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static SchemaDocument getSchemaDocumentForTNS(Map nsToSchemaDocs, String tns) {
/* 135 */     SchemaDocument schDoc = (SchemaDocument)nsToSchemaDocs.get(tns);
/* 136 */     if (schDoc == null) {
/*     */       
/* 138 */       schDoc = SchemaDocument.Factory.newInstance();
/* 139 */       nsToSchemaDocs.put(tns, schDoc);
/*     */     } 
/* 141 */     return schDoc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static SchemaDocument.Schema getTopLevelSchemaElement(SchemaDocument schDoc, String tns) {
/* 147 */     SchemaDocument.Schema sch = schDoc.getSchema();
/* 148 */     if (sch == null) {
/*     */       
/* 150 */       sch = schDoc.addNewSchema();
/* 151 */       sch.setAttributeFormDefault(FormChoice.Enum.forString("unqualified"));
/* 152 */       sch.setElementFormDefault(FormChoice.Enum.forString("qualified"));
/* 153 */       if (!tns.equals(""))
/* 154 */         sch.setTargetNamespace(tns); 
/*     */     } 
/* 156 */     return sch;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillUpGlobalElement(Element globalElement, SchemaDocument schDoc, String tns) {
/* 162 */     assert tns.equals(globalElement.getName().getNamespaceURI());
/*     */     
/* 164 */     SchemaDocument.Schema sch = getTopLevelSchemaElement(schDoc, tns);
/*     */     
/* 166 */     TopLevelElement topLevelElem = sch.addNewElement();
/* 167 */     topLevelElem.setName(globalElement.getName().getLocalPart());
/*     */     
/* 169 */     if (globalElement.isNillable()) {
/* 170 */       topLevelElem.setNillable(globalElement.isNillable());
/*     */     }
/* 172 */     fillUpElementDocumentation((Element)topLevelElem, globalElement.getComment());
/*     */     
/* 174 */     Type elemType = globalElement.getType();
/* 175 */     fillUpTypeOnElement(elemType, (Element)topLevelElem, tns);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillUpLocalElement(Element element, LocalElement localSElement, String tns) {
/* 180 */     fillUpElementDocumentation((Element)localSElement, element.getComment());
/* 181 */     if (!element.isRef()) {
/*     */       
/* 183 */       assert element.getName().getNamespaceURI().equals(tns) || element.getName().getNamespaceURI().length() == 0;
/*     */       
/* 185 */       fillUpTypeOnElement(element.getType(), (Element)localSElement, tns);
/* 186 */       localSElement.setName(element.getName().getLocalPart());
/*     */     }
/*     */     else {
/*     */       
/* 190 */       localSElement.setRef(element.getName());
/* 191 */       assert !element.isNillable();
/*     */     } 
/*     */     
/* 194 */     if (element.getMaxOccurs() == -1)
/*     */     {
/* 196 */       localSElement.setMaxOccurs("unbounded");
/*     */     }
/* 198 */     if (element.getMinOccurs() != 1)
/*     */     {
/* 200 */       localSElement.setMinOccurs(new BigInteger("" + element.getMinOccurs()));
/*     */     }
/*     */     
/* 203 */     if (element.isNillable()) {
/* 204 */       localSElement.setNillable(element.isNillable());
/*     */     }
/*     */   }
/*     */   
/*     */   private void fillUpTypeOnElement(Type elemType, Element parentSElement, String tns) {
/* 209 */     if (elemType.isGlobal()) {
/*     */       
/* 211 */       assert elemType.getName() != null : "Global type must have a name.";
/* 212 */       parentSElement.setType(elemType.getName());
/*     */     }
/* 214 */     else if (elemType.getContentType() == 1) {
/*     */       
/* 216 */       if (elemType.isEnumeration()) {
/* 217 */         fillUpEnumeration(elemType, parentSElement);
/*     */       } else {
/* 219 */         parentSElement.setType(elemType.getName());
/*     */       } 
/*     */     } else {
/*     */       
/* 223 */       LocalComplexType localComplexType = parentSElement.addNewComplexType();
/* 224 */       fillUpContentForComplexType(elemType, (ComplexType)localComplexType, tns);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void fillUpEnumeration(Type type, Element parentSElement) {
/* 230 */     assert type.isEnumeration() && !type.isComplexType() : "Enumerations must be on simple types only.";
/* 231 */     RestrictionDocument.Restriction restriction = parentSElement.addNewSimpleType().addNewRestriction();
/* 232 */     restriction.setBase(type.getName());
/* 233 */     if (type.isQNameEnumeration()) {
/*     */       
/* 235 */       for (int i = 0; i < type.getEnumerationQNames().size(); i++)
/*     */       {
/* 237 */         QName value = type.getEnumerationQNames().get(i);
/* 238 */         XmlQName xqname = XmlQName.Factory.newValue(value);
/*     */         
/* 240 */         NoFixedFacet enumSElem = restriction.addNewEnumeration();
/* 241 */         XmlCursor xc = enumSElem.newCursor();
/*     */         
/* 243 */         String newPrefix = xc.prefixForNamespace(value.getNamespaceURI());
/* 244 */         xc.dispose();
/*     */         
/* 246 */         enumSElem.setValue((XmlAnySimpleType)XmlQName.Factory.newValue(new QName(value.getNamespaceURI(), value.getLocalPart(), newPrefix)));
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 252 */       for (int i = 0; i < type.getEnumerationValues().size(); i++) {
/*     */         
/* 254 */         String value = type.getEnumerationValues().get(i);
/* 255 */         restriction.addNewEnumeration().setValue((XmlAnySimpleType)XmlString.Factory.newValue(value));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillUpAttributesInComplexTypesSimpleContent(Type elemType, SimpleExtensionType sExtension, String tns) {
/* 263 */     for (int i = 0; i < elemType.getAttributes().size(); i++) {
/*     */       
/* 265 */       Attribute att = elemType.getAttributes().get(i);
/* 266 */       Attribute sAttribute = sExtension.addNewAttribute();
/* 267 */       fillUpLocalAttribute(att, sAttribute, tns);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillUpAttributesInComplexTypesComplexContent(Type elemType, ComplexType localSComplexType, String tns) {
/* 274 */     for (int i = 0; i < elemType.getAttributes().size(); i++) {
/*     */       
/* 276 */       Attribute att = elemType.getAttributes().get(i);
/* 277 */       Attribute sAttribute = localSComplexType.addNewAttribute();
/* 278 */       fillUpLocalAttribute(att, sAttribute, tns);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fillUpLocalAttribute(Attribute att, Attribute sAttribute, String tns) {
/* 284 */     if (att.isRef()) {
/*     */       
/* 286 */       sAttribute.setRef(att.getRef().getName());
/*     */     }
/*     */     else {
/*     */       
/* 290 */       assert att.getName().getNamespaceURI() == tns || att.getName().getNamespaceURI().equals("");
/* 291 */       sAttribute.setType(att.getType().getName());
/* 292 */       sAttribute.setName(att.getName().getLocalPart());
/* 293 */       if (att.isOptional()) {
/* 294 */         sAttribute.setUse(Attribute.Use.OPTIONAL);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void fillUpContentForComplexType(Type type, ComplexType sComplexType, String tns) {
/* 300 */     if (type.getContentType() == 2) {
/*     */       
/* 302 */       SimpleContentDocument.SimpleContent simpleContent = sComplexType.addNewSimpleContent();
/*     */       
/* 304 */       assert type.getExtensionType() != null && type.getExtensionType().getName() != null : "Extension type must exist and be named for a COMPLEX_TYPE_SIMPLE_CONTENT";
/*     */       
/* 306 */       SimpleExtensionType ext = simpleContent.addNewExtension();
/* 307 */       ext.setBase(type.getExtensionType().getName());
/*     */       
/* 309 */       fillUpAttributesInComplexTypesSimpleContent(type, ext, tns);
/*     */     } else {
/*     */       ExplicitGroup explicitGroup;
/*     */       
/* 313 */       if (type.getContentType() == 4)
/*     */       {
/* 315 */         sComplexType.setMixed(true);
/*     */       }
/*     */ 
/*     */       
/* 319 */       if (type.getContentType() == 5) {
/* 320 */         explicitGroup = null;
/* 321 */       } else if (type.getTopParticleForComplexOrMixedContent() == 1) {
/*     */         
/* 323 */         explicitGroup = sComplexType.addNewSequence();
/*     */       }
/* 325 */       else if (type.getTopParticleForComplexOrMixedContent() == 2) {
/*     */         
/* 327 */         explicitGroup = sComplexType.addNewChoice();
/* 328 */         explicitGroup.setMaxOccurs("unbounded");
/* 329 */         explicitGroup.setMinOccurs(new BigInteger("0"));
/*     */       } else {
/* 331 */         throw new IllegalStateException("Unknown particle type in complex and mixed content");
/*     */       } 
/* 333 */       for (int i = 0; i < type.getElements().size(); i++) {
/*     */         
/* 335 */         Element child = type.getElements().get(i);
/* 336 */         assert !child.isGlobal();
/* 337 */         LocalElement childLocalElement = explicitGroup.addNewElement();
/* 338 */         fillUpLocalElement(child, childLocalElement, tns);
/*     */       } 
/*     */       
/* 341 */       fillUpAttributesInComplexTypesComplexContent(type, sComplexType, tns);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillUpGlobalAttribute(Attribute globalAttribute, SchemaDocument schDoc, String tns) {
/* 348 */     assert tns.equals(globalAttribute.getName().getNamespaceURI());
/* 349 */     SchemaDocument.Schema sch = getTopLevelSchemaElement(schDoc, tns);
/*     */     
/* 351 */     TopLevelAttribute topLevelAtt = sch.addNewAttribute();
/* 352 */     topLevelAtt.setName(globalAttribute.getName().getLocalPart());
/*     */     
/* 354 */     Type elemType = globalAttribute.getType();
/*     */     
/* 356 */     if (elemType.getContentType() == 1) {
/*     */       
/* 358 */       topLevelAtt.setType(elemType.getName());
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 363 */       throw new IllegalStateException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void fillUpElementDocumentation(Element element, String comment) {
/* 369 */     if (comment != null && comment.length() > 0) {
/*     */       
/* 371 */       DocumentationDocument.Documentation documentation = element.addNewAnnotation().addNewDocumentation();
/* 372 */       documentation.set((XmlObject)XmlString.Factory.newValue(comment));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillUpGlobalType(Type globalType, SchemaDocument schDoc, String tns) {
/* 379 */     assert tns.equals(globalType.getName().getNamespaceURI());
/* 380 */     SchemaDocument.Schema sch = getTopLevelSchemaElement(schDoc, tns);
/*     */     
/* 382 */     TopLevelComplexType topLevelComplexType = sch.addNewComplexType();
/* 383 */     topLevelComplexType.setName(globalType.getName().getLocalPart());
/*     */     
/* 385 */     fillUpContentForComplexType(globalType, (ComplexType)topLevelComplexType, tns);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 390 */     return "TypeSystemHolder{\n\n_globalElements=" + this._globalElements + "\n\n_globalAttributes=" + this._globalAttributes + "\n\n_globalTypes=" + this._globalTypes + "\n}";
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xs\\util\TypeSystemHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */