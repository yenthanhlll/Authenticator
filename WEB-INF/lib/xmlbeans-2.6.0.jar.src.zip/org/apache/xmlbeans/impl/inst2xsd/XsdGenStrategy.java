package org.apache.xmlbeans.impl.inst2xsd;

import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.inst2xsd.util.TypeSystemHolder;

public interface XsdGenStrategy {
  void processDoc(XmlObject[] paramArrayOfXmlObject, Inst2XsdOptions paramInst2XsdOptions, TypeSystemHolder paramTypeSystemHolder);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xsd\XsdGenStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */