/*     */ package org.apache.xmlbeans.impl.inst2xsd.util;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Element
/*     */ {
/*  24 */   private QName _name = null;
/*  25 */   private Element _ref = null;
/*     */   private boolean _isGlobal = false;
/*  27 */   private int _minOccurs = 1;
/*  28 */   private int _maxOccurs = 1;
/*     */   public static final int UNBOUNDED = -1;
/*     */   private boolean _isNillable = false;
/*  31 */   private Type _type = null;
/*  32 */   private String _comment = null;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public QName getName() {
/*  36 */     return this._name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(QName name) {
/*  41 */     this._name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRef() {
/*  46 */     return (this._ref != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getRef() {
/*  51 */     return this._ref;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRef(Element ref) {
/*  56 */     assert !this._isGlobal;
/*  57 */     this._ref = ref;
/*  58 */     this._type = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGlobal() {
/*  63 */     return this._isGlobal;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGlobal(boolean isGlobal) {
/*  68 */     this._isGlobal = isGlobal;
/*  69 */     this._minOccurs = 1;
/*  70 */     this._maxOccurs = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinOccurs() {
/*  75 */     return this._minOccurs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinOccurs(int minOccurs) {
/*  80 */     this._minOccurs = minOccurs;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxOccurs() {
/*  85 */     return this._maxOccurs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxOccurs(int maxOccurs) {
/*  90 */     this._maxOccurs = maxOccurs;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNillable() {
/*  95 */     return this._isNillable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNillable(boolean isNillable) {
/* 100 */     this._isNillable = isNillable;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 105 */     return isRef() ? getRef().getType() : this._type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 110 */     assert !isRef();
/* 111 */     this._type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 116 */     return this._comment;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setComment(String comment) {
/* 121 */     this._comment = comment;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return "\n  Element{ _name = " + this._name + ", _ref = " + ((this._ref != null) ? 1 : 0) + ", _isGlobal = " + this._isGlobal + ", _minOccurs = " + this._minOccurs + ", _maxOccurs = " + this._maxOccurs + ", _isNillable = " + this._isNillable + ", _comment = " + this._comment + ",\n    _type = " + ((this._type == null) ? "null" : (this._type.isGlobal() ? this._type.getName().toString() : this._type.toString())) + "\n  }";
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xs\\util\Element.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */