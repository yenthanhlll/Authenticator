/*     */ package org.apache.xmlbeans.impl.config;
/*     */ 
/*     */ import org.apache.xmlbeans.InterfaceExtension;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JParameter;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterfaceExtensionImpl
/*     */   implements InterfaceExtension
/*     */ {
/*     */   private NameSet _xbeanSet;
/*     */   private String _interfaceClassName;
/*     */   private String _delegateToClassName;
/*     */   private MethodSignatureImpl[] _methods;
/*     */   
/*     */   static InterfaceExtensionImpl newInstance(JamClassLoader loader, NameSet xbeanSet, Extensionconfig.Interface intfXO) {
/*  35 */     InterfaceExtensionImpl result = new InterfaceExtensionImpl();
/*     */     
/*  37 */     result._xbeanSet = xbeanSet;
/*  38 */     JClass interfaceJClass = validateInterface(loader, intfXO.getName(), (XmlObject)intfXO);
/*     */ 
/*     */     
/*  41 */     if (interfaceJClass == null) {
/*     */       
/*  43 */       BindingConfigImpl.error("Interface '" + intfXO.getStaticHandler() + "' not found.", (XmlObject)intfXO);
/*  44 */       return null;
/*     */     } 
/*     */     
/*  47 */     result._interfaceClassName = interfaceJClass.getQualifiedName();
/*     */     
/*  49 */     result._delegateToClassName = intfXO.getStaticHandler();
/*  50 */     JClass delegateJClass = validateClass(loader, result._delegateToClassName, (XmlObject)intfXO);
/*     */     
/*  52 */     if (delegateJClass == null) {
/*     */       
/*  54 */       BindingConfigImpl.warning("Handler class '" + intfXO.getStaticHandler() + "' not found on classpath, skip validation.", (XmlObject)intfXO);
/*  55 */       return result;
/*     */     } 
/*     */     
/*  58 */     if (!result.validateMethods(interfaceJClass, delegateJClass, (XmlObject)intfXO)) {
/*  59 */       return null;
/*     */     }
/*  61 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static JClass validateInterface(JamClassLoader loader, String intfStr, XmlObject loc) {
/*  66 */     return validateJava(loader, intfStr, true, loc);
/*     */   }
/*     */ 
/*     */   
/*     */   static JClass validateClass(JamClassLoader loader, String clsStr, XmlObject loc) {
/*  71 */     return validateJava(loader, clsStr, false, loc);
/*     */   }
/*     */ 
/*     */   
/*     */   static JClass validateJava(JamClassLoader loader, String clsStr, boolean isInterface, XmlObject loc) {
/*  76 */     if (loader == null) {
/*  77 */       return null;
/*     */     }
/*  79 */     String ent = isInterface ? "Interface" : "Class";
/*  80 */     JClass cls = loader.loadClass(clsStr);
/*     */     
/*  82 */     if (cls == null || cls.isUnresolvedType()) {
/*     */       
/*  84 */       BindingConfigImpl.error(ent + " '" + clsStr + "' not found.", loc);
/*  85 */       return null;
/*     */     } 
/*     */     
/*  88 */     if ((isInterface && !cls.isInterface()) || (!isInterface && cls.isInterface()))
/*     */     {
/*     */       
/*  91 */       BindingConfigImpl.error("'" + clsStr + "' must be " + (isInterface ? "an interface" : "a class") + ".", loc);
/*     */     }
/*     */ 
/*     */     
/*  95 */     if (!cls.isPublic())
/*     */     {
/*  97 */       BindingConfigImpl.error(ent + " '" + clsStr + "' is not public.", loc);
/*     */     }
/*     */     
/* 100 */     return cls;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateMethods(JClass interfaceJClass, JClass delegateJClass, XmlObject loc) {
/* 106 */     boolean valid = true;
/*     */     
/* 108 */     JMethod[] interfaceMethods = interfaceJClass.getMethods();
/* 109 */     this._methods = new MethodSignatureImpl[interfaceMethods.length];
/*     */     
/* 111 */     for (int i = 0; i < interfaceMethods.length; i++) {
/*     */       
/* 113 */       JMethod method = validateMethod(interfaceJClass, delegateJClass, interfaceMethods[i], loc);
/* 114 */       if (method != null) {
/* 115 */         this._methods[i] = new MethodSignatureImpl(getStaticHandler(), method);
/*     */       } else {
/* 117 */         valid = false;
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     return valid;
/*     */   }
/*     */ 
/*     */   
/*     */   private JMethod validateMethod(JClass interfaceJClass, JClass delegateJClass, JMethod method, XmlObject loc) {
/* 126 */     String methodName = method.getSimpleName();
/* 127 */     JParameter[] params = method.getParameters();
/* 128 */     JClass returnType = method.getReturnType();
/*     */     
/* 130 */     JClass[] delegateParams = new JClass[params.length + 1];
/* 131 */     delegateParams[0] = returnType.forName("org.apache.xmlbeans.XmlObject");
/* 132 */     for (int i = 1; i < delegateParams.length; i++)
/*     */     {
/* 134 */       delegateParams[i] = params[i - 1].getType();
/*     */     }
/*     */     
/* 137 */     JMethod handlerMethod = null;
/* 138 */     handlerMethod = getMethod(delegateJClass, methodName, delegateParams);
/* 139 */     if (handlerMethod == null) {
/*     */       
/* 141 */       BindingConfigImpl.error("Handler class '" + delegateJClass.getQualifiedName() + "' does not contain method " + methodName + "(" + listTypes(delegateParams) + ")", loc);
/* 142 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     JClass[] intfExceptions = method.getExceptionTypes();
/* 147 */     JClass[] delegateExceptions = handlerMethod.getExceptionTypes();
/* 148 */     if (delegateExceptions.length != intfExceptions.length) {
/*     */       
/* 150 */       BindingConfigImpl.error("Handler method '" + delegateJClass.getQualifiedName() + "." + methodName + "(" + listTypes(delegateParams) + ")' must declare the same exceptions as the interface method '" + interfaceJClass.getQualifiedName() + "." + methodName + "(" + listTypes(params), loc);
/*     */       
/* 152 */       return null;
/*     */     } 
/*     */     
/* 155 */     for (int j = 0; j < delegateExceptions.length; j++) {
/*     */       
/* 157 */       if (delegateExceptions[j] != intfExceptions[j]) {
/*     */         
/* 159 */         BindingConfigImpl.error("Handler method '" + delegateJClass.getQualifiedName() + "." + methodName + "(" + listTypes(delegateParams) + ")' must declare the same exceptions as the interface method '" + interfaceJClass.getQualifiedName() + "." + methodName + "(" + listTypes(params), loc);
/*     */         
/* 161 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 165 */     if (!handlerMethod.isPublic() || !handlerMethod.isStatic()) {
/*     */       
/* 167 */       BindingConfigImpl.error("Method '" + delegateJClass.getQualifiedName() + "." + methodName + "(" + listTypes(delegateParams) + ")' must be declared public and static.", loc);
/* 168 */       return null;
/*     */     } 
/*     */     
/* 171 */     if (!returnType.equals(handlerMethod.getReturnType())) {
/*     */       
/* 173 */       BindingConfigImpl.error("Return type for method '" + handlerMethod.getReturnType() + " " + delegateJClass.getQualifiedName() + "." + methodName + "(" + listTypes(delegateParams) + ")' does not match the return type of the interface method :'" + returnType + "'.", loc);
/*     */       
/* 175 */       return null;
/*     */     } 
/*     */     
/* 178 */     return method;
/*     */   }
/*     */ 
/*     */   
/*     */   static JMethod getMethod(JClass cls, String name, JClass[] paramTypes) {
/* 183 */     JMethod[] methods = cls.getMethods();
/* 184 */     for (int i = 0; i < methods.length; i++) {
/*     */       
/* 186 */       JMethod method = methods[i];
/* 187 */       if (name.equals(method.getSimpleName())) {
/*     */ 
/*     */         
/* 190 */         JParameter[] mParams = method.getParameters();
/*     */ 
/*     */         
/* 193 */         if (mParams.length == paramTypes.length)
/*     */         
/*     */         { 
/* 196 */           for (int j = 0; j < mParams.length; j++) {
/*     */             
/* 198 */             JParameter mParam = mParams[j];
/* 199 */             if (!mParam.getType().equals(paramTypes[j]));
/*     */           } 
/*     */ 
/*     */           
/* 203 */           return method; } 
/*     */       } 
/* 205 */     }  return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String listTypes(JClass[] types) {
/* 210 */     StringBuffer result = new StringBuffer();
/* 211 */     for (int i = 0; i < types.length; i++) {
/*     */       
/* 213 */       JClass type = types[i];
/* 214 */       if (i > 0)
/* 215 */         result.append(", "); 
/* 216 */       result.append(emitType(type));
/*     */     } 
/* 218 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String listTypes(JParameter[] params) {
/* 223 */     StringBuffer result = new StringBuffer();
/* 224 */     for (int i = 0; i < params.length; i++) {
/*     */       
/* 226 */       JClass type = params[i].getType();
/* 227 */       if (i > 0)
/* 228 */         result.append(", "); 
/* 229 */       result.append(emitType(type));
/*     */     } 
/* 231 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String emitType(JClass cls) {
/* 236 */     if (cls.isArrayType()) {
/* 237 */       return emitType(cls.getArrayComponentType()) + "[]";
/*     */     }
/* 239 */     return cls.getQualifiedName().replace('$', '.');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(String fullJavaName) {
/* 245 */     return this._xbeanSet.contains(fullJavaName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStaticHandler() {
/* 250 */     return this._delegateToClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInterface() {
/* 255 */     return this._interfaceClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public InterfaceExtension.MethodSignature[] getMethods() {
/* 260 */     return (InterfaceExtension.MethodSignature[])this._methods;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 265 */     StringBuffer buf = new StringBuffer();
/* 266 */     buf.append("  static handler: ").append(this._delegateToClassName).append("\n");
/* 267 */     buf.append("  interface: ").append(this._interfaceClassName).append("\n");
/* 268 */     buf.append("  name set: ").append(this._xbeanSet).append("\n");
/*     */     
/* 270 */     for (int i = 0; i < this._methods.length; i++) {
/* 271 */       buf.append("  method[").append(i).append("]=").append(this._methods[i]).append("\n");
/*     */     }
/* 273 */     return buf.toString();
/*     */   }
/*     */   
/*     */   static class MethodSignatureImpl
/*     */     implements InterfaceExtension.MethodSignature
/*     */   {
/*     */     private String _intfName;
/* 280 */     private final int NOTINITIALIZED = -1;
/* 281 */     private int _hashCode = -1;
/*     */     
/*     */     private String _signature;
/*     */     
/*     */     private String _name;
/*     */     private String _return;
/*     */     private String[] _params;
/*     */     private String[] _exceptions;
/*     */     
/*     */     MethodSignatureImpl(String intfName, JMethod method) {
/* 291 */       if (intfName == null || method == null) {
/* 292 */         throw new IllegalArgumentException("Interface: " + intfName + " method: " + method);
/*     */       }
/* 294 */       this._intfName = intfName;
/* 295 */       this._hashCode = -1;
/* 296 */       this._signature = null;
/*     */       
/* 298 */       this._name = method.getSimpleName();
/* 299 */       this._return = method.getReturnType().getQualifiedName().replace('$', '.');
/*     */       
/* 301 */       JParameter[] paramTypes = method.getParameters();
/* 302 */       this._params = new String[paramTypes.length];
/* 303 */       for (int i = 0; i < paramTypes.length; i++) {
/* 304 */         this._params[i] = paramTypes[i].getType().getQualifiedName().replace('$', '.');
/*     */       }
/* 306 */       JClass[] exceptionTypes = method.getExceptionTypes();
/* 307 */       this._exceptions = new String[exceptionTypes.length];
/* 308 */       for (int j = 0; j < exceptionTypes.length; j++) {
/* 309 */         this._exceptions[j] = exceptionTypes[j].getQualifiedName().replace('$', '.');
/*     */       }
/*     */     }
/*     */     
/*     */     String getInterfaceName() {
/* 314 */       return this._intfName;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 319 */       return this._name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getReturnType() {
/* 324 */       return this._return;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getParameterTypes() {
/* 329 */       return this._params;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getExceptionTypes() {
/* 334 */       return this._exceptions;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 339 */       if (!(o instanceof MethodSignatureImpl)) {
/* 340 */         return false;
/*     */       }
/* 342 */       MethodSignatureImpl ms = (MethodSignatureImpl)o;
/*     */       
/* 344 */       if (!ms.getName().equals(getName())) {
/* 345 */         return false;
/*     */       }
/* 347 */       String[] params = getParameterTypes();
/* 348 */       String[] msParams = ms.getParameterTypes();
/*     */       
/* 350 */       if (msParams.length != params.length) {
/* 351 */         return false;
/*     */       }
/* 353 */       for (int i = 0; i < params.length; i++) {
/*     */         
/* 355 */         if (!msParams[i].equals(params[i])) {
/* 356 */           return false;
/*     */         }
/*     */       } 
/* 359 */       if (!this._intfName.equals(ms._intfName)) {
/* 360 */         return false;
/*     */       }
/* 362 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 367 */       if (this._hashCode != -1) {
/* 368 */         return this._hashCode;
/*     */       }
/* 370 */       int hash = getName().hashCode();
/*     */       
/* 372 */       String[] params = getParameterTypes();
/*     */       
/* 374 */       for (int i = 0; i < params.length; i++) {
/*     */         
/* 376 */         hash *= 19;
/* 377 */         hash += params[i].hashCode();
/*     */       } 
/*     */       
/* 380 */       hash += 21 * this._intfName.hashCode();
/*     */       
/* 382 */       this._hashCode = hash;
/* 383 */       return this._hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     String getSignature() {
/* 388 */       if (this._signature != null) {
/* 389 */         return this._signature;
/*     */       }
/* 391 */       StringBuffer sb = new StringBuffer(60);
/* 392 */       sb.append(this._name).append("(");
/* 393 */       for (int i = 0; i < this._params.length; i++)
/* 394 */         sb.append((i == 0) ? "" : " ,").append(this._params[i]); 
/* 395 */       sb.append(")");
/*     */       
/* 397 */       this._signature = sb.toString();
/*     */       
/* 399 */       return this._signature;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 404 */       StringBuffer buf = new StringBuffer();
/*     */       
/* 406 */       buf.append(getReturnType()).append(" ").append(getSignature());
/*     */       
/* 408 */       return buf.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\config\InterfaceExtensionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */