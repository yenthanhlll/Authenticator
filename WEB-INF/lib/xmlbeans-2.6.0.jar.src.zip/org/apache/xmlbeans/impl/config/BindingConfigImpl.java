/*     */ package org.apache.xmlbeans.impl.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.BindingConfig;
/*     */ import org.apache.xmlbeans.InterfaceExtension;
/*     */ import org.apache.xmlbeans.PrePostExtension;
/*     */ import org.apache.xmlbeans.UserType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.jam.JamService;
/*     */ import org.apache.xmlbeans.impl.jam.JamServiceFactory;
/*     */ import org.apache.xmlbeans.impl.jam.JamServiceParams;
/*     */ import org.apache.xmlbeans.impl.schema.StscState;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Nsconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Qnameconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Qnametargetenum;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Usertypeconfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingConfigImpl
/*     */   extends BindingConfig
/*     */ {
/*     */   private Map _packageMap;
/*     */   private Map _prefixMap;
/*     */   private Map _suffixMap;
/*     */   private Map _packageMapByUriPrefix;
/*     */   private Map _prefixMapByUriPrefix;
/*     */   private Map _suffixMapByUriPrefix;
/*     */   private Map _qnameTypeMap;
/*     */   private Map _qnameDocTypeMap;
/*     */   private Map _qnameElemMap;
/*     */   private Map _qnameAttMap;
/*     */   private List _interfaceExtensions;
/*     */   private List _prePostExtensions;
/*     */   private Map _userTypes;
/*     */   
/*     */   private BindingConfigImpl() {
/*  63 */     this._packageMap = Collections.EMPTY_MAP;
/*  64 */     this._prefixMap = Collections.EMPTY_MAP;
/*  65 */     this._suffixMap = Collections.EMPTY_MAP;
/*  66 */     this._packageMapByUriPrefix = Collections.EMPTY_MAP;
/*  67 */     this._prefixMapByUriPrefix = Collections.EMPTY_MAP;
/*  68 */     this._suffixMapByUriPrefix = Collections.EMPTY_MAP;
/*  69 */     this._qnameTypeMap = Collections.EMPTY_MAP;
/*  70 */     this._qnameDocTypeMap = Collections.EMPTY_MAP;
/*  71 */     this._qnameElemMap = Collections.EMPTY_MAP;
/*  72 */     this._qnameAttMap = Collections.EMPTY_MAP;
/*  73 */     this._interfaceExtensions = new ArrayList();
/*  74 */     this._prePostExtensions = new ArrayList();
/*  75 */     this._userTypes = Collections.EMPTY_MAP;
/*     */   }
/*     */ 
/*     */   
/*     */   public static BindingConfig forConfigDocuments(ConfigDocument.Config[] configs, File[] javaFiles, File[] classpath) {
/*  80 */     return new BindingConfigImpl(configs, javaFiles, classpath);
/*     */   }
/*     */ 
/*     */   
/*     */   private BindingConfigImpl(ConfigDocument.Config[] configs, File[] javaFiles, File[] classpath) {
/*  85 */     this._packageMap = new LinkedHashMap();
/*  86 */     this._prefixMap = new LinkedHashMap();
/*  87 */     this._suffixMap = new LinkedHashMap();
/*  88 */     this._packageMapByUriPrefix = new LinkedHashMap();
/*  89 */     this._prefixMapByUriPrefix = new LinkedHashMap();
/*  90 */     this._suffixMapByUriPrefix = new LinkedHashMap();
/*  91 */     this._qnameTypeMap = new LinkedHashMap();
/*  92 */     this._qnameDocTypeMap = new LinkedHashMap();
/*  93 */     this._qnameElemMap = new LinkedHashMap();
/*  94 */     this._qnameAttMap = new LinkedHashMap();
/*  95 */     this._interfaceExtensions = new ArrayList();
/*  96 */     this._prePostExtensions = new ArrayList();
/*  97 */     this._userTypes = new LinkedHashMap();
/*     */     
/*  99 */     for (int i = 0; i < configs.length; i++) {
/*     */       
/* 101 */       ConfigDocument.Config config = configs[i];
/* 102 */       Nsconfig[] nsa = config.getNamespaceArray();
/* 103 */       for (int j = 0; j < nsa.length; j++) {
/*     */         
/* 105 */         recordNamespaceSetting(nsa[j].getUri(), nsa[j].getPackage(), this._packageMap);
/* 106 */         recordNamespaceSetting(nsa[j].getUri(), nsa[j].getPrefix(), this._prefixMap);
/* 107 */         recordNamespaceSetting(nsa[j].getUri(), nsa[j].getSuffix(), this._suffixMap);
/* 108 */         recordNamespacePrefixSetting(nsa[j].getUriprefix(), nsa[j].getPackage(), this._packageMapByUriPrefix);
/* 109 */         recordNamespacePrefixSetting(nsa[j].getUriprefix(), nsa[j].getPrefix(), this._prefixMapByUriPrefix);
/* 110 */         recordNamespacePrefixSetting(nsa[j].getUriprefix(), nsa[j].getSuffix(), this._suffixMapByUriPrefix);
/*     */       } 
/*     */       
/* 113 */       Qnameconfig[] qnc = config.getQnameArray();
/* 114 */       for (int k = 0; k < qnc.length; k++) {
/*     */         
/* 116 */         List applyto = qnc[k].xgetTarget().xgetListValue();
/* 117 */         QName name = qnc[k].getName();
/* 118 */         String javaname = qnc[k].getJavaname();
/* 119 */         for (int i1 = 0; i1 < applyto.size(); i1++) {
/*     */           
/* 121 */           Qnametargetenum a = applyto.get(i1);
/* 122 */           switch (a.enumValue().intValue()) {
/*     */             
/*     */             case 1:
/* 125 */               this._qnameTypeMap.put(name, javaname);
/*     */               break;
/*     */             case 2:
/* 128 */               this._qnameDocTypeMap.put(name, javaname);
/*     */               break;
/*     */             case 3:
/* 131 */               this._qnameElemMap.put(name, javaname);
/*     */               break;
/*     */             case 4:
/* 134 */               this._qnameAttMap.put(name, javaname);
/*     */               break;
/*     */           } 
/*     */         
/*     */         } 
/*     */       } 
/* 140 */       Extensionconfig[] ext = config.getExtensionArray();
/* 141 */       for (int m = 0; m < ext.length; m++)
/*     */       {
/* 143 */         recordExtensionSetting(javaFiles, classpath, ext[m]);
/*     */       }
/*     */       
/* 146 */       Usertypeconfig[] utypes = config.getUsertypeArray();
/* 147 */       for (int n = 0; n < utypes.length; n++)
/*     */       {
/* 149 */         recordUserTypeSetting(javaFiles, classpath, utypes[n]);
/*     */       }
/*     */     } 
/*     */     
/* 153 */     secondPhaseValidation();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void addInterfaceExtension(InterfaceExtensionImpl ext) {
/* 159 */     if (ext == null) {
/*     */       return;
/*     */     }
/* 162 */     this._interfaceExtensions.add(ext);
/*     */   }
/*     */ 
/*     */   
/*     */   void addPrePostExtension(PrePostExtensionImpl ext) {
/* 167 */     if (ext == null) {
/*     */       return;
/*     */     }
/* 170 */     this._prePostExtensions.add(ext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void secondPhaseValidation() {
/* 176 */     Map methodSignatures = new HashMap();
/*     */     int i;
/* 178 */     for (i = 0; i < this._interfaceExtensions.size(); i++) {
/*     */       
/* 180 */       InterfaceExtensionImpl interfaceExtension = this._interfaceExtensions.get(i);
/*     */       
/* 182 */       InterfaceExtensionImpl.MethodSignatureImpl[] methods = (InterfaceExtensionImpl.MethodSignatureImpl[])interfaceExtension.getMethods();
/* 183 */       for (int j = 0; j < methods.length; j++) {
/*     */         
/* 185 */         InterfaceExtensionImpl.MethodSignatureImpl ms = methods[j];
/*     */         
/* 187 */         if (methodSignatures.containsKey(methods[j])) {
/*     */ 
/*     */           
/* 190 */           InterfaceExtensionImpl.MethodSignatureImpl ms2 = (InterfaceExtensionImpl.MethodSignatureImpl)methodSignatures.get(methods[j]);
/* 191 */           if (!ms.getReturnType().equals(ms2.getReturnType()))
/*     */           {
/* 193 */             error("Colliding methods '" + ms.getSignature() + "' in interfaces " + ms.getInterfaceName() + " and " + ms2.getInterfaceName() + ".", null);
/*     */           }
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */ 
/*     */         
/* 201 */         methodSignatures.put(methods[j], methods[j]);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 206 */     for (i = 0; i < this._prePostExtensions.size() - 1; i++) {
/*     */       
/* 208 */       PrePostExtensionImpl a = this._prePostExtensions.get(i);
/* 209 */       for (int j = 1; j < this._prePostExtensions.size(); j++) {
/*     */         
/* 211 */         PrePostExtensionImpl b = this._prePostExtensions.get(j);
/* 212 */         if (a.hasNameSetIntersection(b)) {
/* 213 */           error("The applicable domain for handler '" + a.getHandlerNameForJavaSource() + "' intersects with the one for '" + b.getHandlerNameForJavaSource() + "'.", null);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void recordNamespaceSetting(Object key, String value, Map result) {
/* 221 */     if (value == null)
/*     */       return; 
/* 223 */     if (key == null) {
/* 224 */       result.put("", value);
/* 225 */     } else if (key instanceof String && "##any".equals(key)) {
/* 226 */       result.put(key, value);
/* 227 */     } else if (key instanceof List) {
/*     */       
/* 229 */       for (Iterator i = ((List)key).iterator(); i.hasNext(); ) {
/*     */         
/* 231 */         String uri = i.next();
/* 232 */         if ("##local".equals(uri))
/* 233 */           uri = ""; 
/* 234 */         result.put(uri, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void recordNamespacePrefixSetting(List list, String value, Map result) {
/* 241 */     if (value == null)
/*     */       return; 
/* 243 */     if (list == null)
/*     */       return; 
/* 245 */     for (Iterator i = list.iterator(); i.hasNext();)
/*     */     {
/* 247 */       result.put(i.next(), value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void recordExtensionSetting(File[] javaFiles, File[] classpath, Extensionconfig ext) {
/* 253 */     NameSet xbeanSet = null;
/* 254 */     Object key = ext.getFor();
/*     */ 
/*     */     
/* 257 */     if (key instanceof String && "*".equals(key)) {
/* 258 */       xbeanSet = NameSet.EVERYTHING;
/* 259 */     } else if (key instanceof List) {
/*     */       
/* 261 */       NameSetBuilder xbeanSetBuilder = new NameSetBuilder();
/* 262 */       for (Iterator i = ((List)key).iterator(); i.hasNext(); ) {
/*     */         
/* 264 */         String xbeanName = i.next();
/* 265 */         xbeanSetBuilder.add(xbeanName);
/*     */       } 
/* 267 */       xbeanSet = xbeanSetBuilder.toNameSet();
/*     */     } 
/*     */     
/* 270 */     if (xbeanSet == null) {
/* 271 */       error("Invalid value of attribute 'for' : '" + key + "'.", (XmlObject)ext);
/*     */     }
/* 273 */     Extensionconfig.Interface[] intfXO = ext.getInterfaceArray();
/* 274 */     Extensionconfig.PrePostSet ppXO = ext.getPrePostSet();
/*     */     
/* 276 */     if (intfXO.length > 0 || ppXO != null) {
/*     */       
/* 278 */       JamClassLoader jamLoader = getJamLoader(javaFiles, classpath);
/* 279 */       for (int i = 0; i < intfXO.length; i++)
/*     */       {
/* 281 */         addInterfaceExtension(InterfaceExtensionImpl.newInstance(jamLoader, xbeanSet, intfXO[i]));
/*     */       }
/*     */       
/* 284 */       addPrePostExtension(PrePostExtensionImpl.newInstance(jamLoader, xbeanSet, ppXO));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void recordUserTypeSetting(File[] javaFiles, File[] classpath, Usertypeconfig usertypeconfig) {
/* 291 */     JamClassLoader jamLoader = getJamLoader(javaFiles, classpath);
/* 292 */     UserTypeImpl userType = UserTypeImpl.newInstance(jamLoader, usertypeconfig);
/* 293 */     this._userTypes.put(userType.getName(), userType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String lookup(Map map, Map mapByUriPrefix, String uri) {
/* 299 */     if (uri == null)
/* 300 */       uri = ""; 
/* 301 */     String result = (String)map.get(uri);
/* 302 */     if (result != null)
/* 303 */       return result; 
/* 304 */     if (mapByUriPrefix != null) {
/*     */       
/* 306 */       result = lookupByUriPrefix(mapByUriPrefix, uri);
/* 307 */       if (result != null) {
/* 308 */         return result;
/*     */       }
/*     */     } 
/* 311 */     return (String)map.get("##any");
/*     */   }
/*     */ 
/*     */   
/*     */   private String lookupByUriPrefix(Map mapByUriPrefix, String uri) {
/* 316 */     if (uri == null)
/* 317 */       return null; 
/* 318 */     if (!mapByUriPrefix.isEmpty()) {
/*     */       
/* 320 */       String uriprefix = null;
/* 321 */       Iterator i = mapByUriPrefix.keySet().iterator();
/* 322 */       while (i.hasNext()) {
/*     */         
/* 324 */         String nextprefix = i.next();
/* 325 */         if (uriprefix != null && nextprefix.length() < uriprefix.length())
/*     */           continue; 
/* 327 */         if (uri.startsWith(nextprefix)) {
/* 328 */           uriprefix = nextprefix;
/*     */         }
/*     */       } 
/* 331 */       if (uriprefix != null)
/* 332 */         return (String)mapByUriPrefix.get(uriprefix); 
/*     */     } 
/* 334 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void warning(String s, XmlObject xo) {
/* 340 */     StscState.get().error(s, 1, xo);
/*     */   }
/*     */ 
/*     */   
/*     */   static void error(String s, XmlObject xo) {
/* 345 */     StscState.get().error(s, 0, xo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String lookupPackageForNamespace(String uri) {
/* 352 */     return lookup(this._packageMap, this._packageMapByUriPrefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public String lookupPrefixForNamespace(String uri) {
/* 357 */     return lookup(this._prefixMap, this._prefixMapByUriPrefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public String lookupSuffixForNamespace(String uri) {
/* 362 */     return lookup(this._suffixMap, this._suffixMapByUriPrefix, uri);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String lookupJavanameForQName(QName qname) {
/* 368 */     String result = (String)this._qnameTypeMap.get(qname);
/* 369 */     if (result != null)
/* 370 */       return result; 
/* 371 */     return (String)this._qnameDocTypeMap.get(qname);
/*     */   }
/*     */ 
/*     */   
/*     */   public String lookupJavanameForQName(QName qname, int kind) {
/* 376 */     switch (kind) {
/*     */       
/*     */       case 1:
/* 379 */         return (String)this._qnameTypeMap.get(qname);
/*     */       case 2:
/* 381 */         return (String)this._qnameDocTypeMap.get(qname);
/*     */       case 3:
/* 383 */         return (String)this._qnameElemMap.get(qname);
/*     */       case 4:
/* 385 */         return (String)this._qnameAttMap.get(qname);
/*     */     } 
/* 387 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public UserType lookupUserTypeForQName(QName qname) {
/* 392 */     if (qname == null) {
/* 393 */       return null;
/*     */     }
/* 395 */     return (UserType)this._userTypes.get(qname);
/*     */   }
/*     */ 
/*     */   
/*     */   public InterfaceExtension[] getInterfaceExtensions() {
/* 400 */     return (InterfaceExtension[])this._interfaceExtensions.toArray((Object[])new InterfaceExtension[this._interfaceExtensions.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public InterfaceExtension[] getInterfaceExtensions(String fullJavaName) {
/* 405 */     List result = new ArrayList();
/* 406 */     for (int i = 0; i < this._interfaceExtensions.size(); i++) {
/*     */       
/* 408 */       InterfaceExtensionImpl intfExt = this._interfaceExtensions.get(i);
/* 409 */       if (intfExt.contains(fullJavaName)) {
/* 410 */         result.add(intfExt);
/*     */       }
/*     */     } 
/* 413 */     return result.<InterfaceExtension>toArray(new InterfaceExtension[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrePostExtension[] getPrePostExtensions() {
/* 418 */     return (PrePostExtension[])this._prePostExtensions.toArray((Object[])new PrePostExtension[this._prePostExtensions.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrePostExtension getPrePostExtension(String fullJavaName) {
/* 423 */     for (int i = 0; i < this._prePostExtensions.size(); i++) {
/*     */       
/* 425 */       PrePostExtensionImpl prePostExt = this._prePostExtensions.get(i);
/* 426 */       if (prePostExt.contains(fullJavaName))
/* 427 */         return prePostExt; 
/*     */     } 
/* 429 */     return null;
/*     */   }
/*     */   
/*     */   private JamClassLoader getJamLoader(File[] javaFiles, File[] classpath) {
/*     */     JamService service;
/* 434 */     JamServiceFactory jf = JamServiceFactory.getInstance();
/* 435 */     JamServiceParams params = jf.createServiceParams();
/* 436 */     params.set14WarningsEnabled(false);
/*     */     
/* 438 */     params.setShowWarnings(false);
/*     */ 
/*     */     
/* 441 */     if (javaFiles != null) {
/* 442 */       for (int i = 0; i < javaFiles.length; i++) {
/* 443 */         params.includeSourceFile(javaFiles[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 448 */     params.addClassLoader(getClass().getClassLoader());
/* 449 */     if (classpath != null) {
/* 450 */       for (int i = 0; i < classpath.length; i++) {
/* 451 */         params.addClasspath(classpath[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 457 */       service = jf.createService(params);
/*     */     }
/* 459 */     catch (IOException ioe) {
/*     */       
/* 461 */       error("Error when accessing .java files.", null);
/* 462 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     return service.getClassLoader();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\config\BindingConfigImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */