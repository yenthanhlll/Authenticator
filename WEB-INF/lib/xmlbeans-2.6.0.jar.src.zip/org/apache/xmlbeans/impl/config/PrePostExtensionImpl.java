/*     */ package org.apache.xmlbeans.impl.config;
/*     */ 
/*     */ import org.apache.xmlbeans.PrePostExtension;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrePostExtensionImpl
/*     */   implements PrePostExtension
/*     */ {
/*  29 */   private static JClass[] PARAMTYPES_PREPOST = null;
/*  30 */   private static final String[] PARAMTYPES_STRING = new String[] { "int", "org.apache.xmlbeans.XmlObject", "javax.xml.namespace.QName", "boolean", "int" };
/*     */   
/*     */   private static final String SIGNATURE;
/*     */   
/*     */   static {
/*  35 */     String sig = "(";
/*  36 */     for (int i = 0; i < PARAMTYPES_STRING.length; i++) {
/*     */       
/*  38 */       String t = PARAMTYPES_STRING[i];
/*  39 */       if (i != 0)
/*  40 */         sig = sig + ", "; 
/*  41 */       sig = sig + t;
/*     */     } 
/*  43 */     SIGNATURE = sig + ")";
/*     */   }
/*     */   
/*     */   private NameSet _xbeanSet;
/*     */   private JClass _delegateToClass;
/*     */   private String _delegateToClassName;
/*     */   private JMethod _preSet;
/*     */   private JMethod _postSet;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   static PrePostExtensionImpl newInstance(JamClassLoader jamLoader, NameSet xbeanSet, Extensionconfig.PrePostSet prePostXO) {
/*  54 */     if (prePostXO == null) {
/*  55 */       return null;
/*     */     }
/*  57 */     PrePostExtensionImpl result = new PrePostExtensionImpl();
/*     */     
/*  59 */     result._xbeanSet = xbeanSet;
/*  60 */     result._delegateToClassName = prePostXO.getStaticHandler();
/*  61 */     result._delegateToClass = InterfaceExtensionImpl.validateClass(jamLoader, result._delegateToClassName, (XmlObject)prePostXO);
/*     */     
/*  63 */     if (result._delegateToClass == null) {
/*     */       
/*  65 */       BindingConfigImpl.warning("Handler class '" + prePostXO.getStaticHandler() + "' not found on classpath, skip validation.", (XmlObject)prePostXO);
/*  66 */       return result;
/*     */     } 
/*     */     
/*  69 */     if (!result.lookAfterPreAndPost(jamLoader, (XmlObject)prePostXO)) {
/*  70 */       return null;
/*     */     }
/*  72 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean lookAfterPreAndPost(JamClassLoader jamLoader, XmlObject loc) {
/*  77 */     assert this._delegateToClass != null : "Delegate to class handler expected.";
/*  78 */     boolean valid = true;
/*     */     
/*  80 */     initParamPrePost(jamLoader);
/*     */     
/*  82 */     this._preSet = InterfaceExtensionImpl.getMethod(this._delegateToClass, "preSet", PARAMTYPES_PREPOST);
/*  83 */     if (this._preSet == null);
/*     */ 
/*     */     
/*  86 */     if (this._preSet != null && !this._preSet.getReturnType().equals(jamLoader.loadClass("boolean"))) {
/*     */ 
/*     */       
/*  89 */       BindingConfigImpl.warning("Method '" + this._delegateToClass.getSimpleName() + ".preSet" + SIGNATURE + "' " + "should return boolean to be considered for a preSet handler.", loc);
/*     */ 
/*     */       
/*  92 */       this._preSet = null;
/*     */     } 
/*     */     
/*  95 */     this._postSet = InterfaceExtensionImpl.getMethod(this._delegateToClass, "postSet", PARAMTYPES_PREPOST);
/*  96 */     if (this._postSet == null);
/*     */ 
/*     */     
/*  99 */     if (this._preSet == null && this._postSet == null) {
/*     */       
/* 101 */       BindingConfigImpl.error("prePostSet handler specified '" + this._delegateToClass.getSimpleName() + "' but no preSet" + SIGNATURE + " or " + "postSet" + SIGNATURE + " methods found.", loc);
/*     */ 
/*     */       
/* 104 */       valid = false;
/*     */     } 
/*     */     
/* 107 */     return valid;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initParamPrePost(JamClassLoader jamLoader) {
/* 112 */     if (PARAMTYPES_PREPOST == null) {
/*     */       
/* 114 */       PARAMTYPES_PREPOST = new JClass[PARAMTYPES_STRING.length];
/* 115 */       for (int i = 0; i < PARAMTYPES_PREPOST.length; i++) {
/*     */         
/* 117 */         PARAMTYPES_PREPOST[i] = jamLoader.loadClass(PARAMTYPES_STRING[i]);
/* 118 */         if (PARAMTYPES_PREPOST[i] == null)
/*     */         {
/* 120 */           throw new IllegalStateException("JAM should have access to the following types " + SIGNATURE);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NameSet getNameSet() {
/* 129 */     return this._xbeanSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String fullJavaName) {
/* 134 */     return this._xbeanSet.contains(fullJavaName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPreCall() {
/* 139 */     return (this._preSet != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPostCall() {
/* 144 */     return (this._postSet != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStaticHandler() {
/* 149 */     return this._delegateToClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHandlerNameForJavaSource() {
/* 158 */     if (this._delegateToClass == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     return InterfaceExtensionImpl.emitType(this._delegateToClass);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasNameSetIntersection(PrePostExtensionImpl ext) {
/* 166 */     return !NameSet.EMPTY.equals(this._xbeanSet.intersect(ext._xbeanSet));
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\config\PrePostExtensionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */