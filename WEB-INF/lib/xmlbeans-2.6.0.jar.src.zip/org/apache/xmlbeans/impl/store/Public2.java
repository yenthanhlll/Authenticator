/*     */ package org.apache.xmlbeans.impl.store;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.QNameSet;
/*     */ import org.apache.xmlbeans.SchemaField;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.values.NamespaceManager;
/*     */ import org.apache.xmlbeans.impl.values.TypeStore;
/*     */ import org.apache.xmlbeans.impl.values.TypeStoreUser;
/*     */ import org.apache.xmlbeans.impl.values.TypeStoreVisitor;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Public2
/*     */ {
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static Locale newLocale(Saaj saaj) {
/*  59 */     XmlOptions options = null;
/*     */     
/*  61 */     if (saaj != null) {
/*     */       
/*  63 */       options = new XmlOptions();
/*  64 */       options.put("SAAJ_IMPL", saaj);
/*     */     } 
/*     */     
/*  67 */     return Locale.getLocale(null, options);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Locale newLocale() {
/*  72 */     return Locale.getLocale(null, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setSync(Document doc, boolean sync) {
/*  77 */     assert doc instanceof DomImpl.Dom;
/*     */     
/*  79 */     Locale l = ((DomImpl.Dom)doc).locale();
/*     */     
/*  81 */     l._noSync = !sync;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String compilePath(String path, XmlOptions options) {
/*  86 */     return Path.compilePath(path, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public static DOMImplementation getDomImplementation() {
/*  91 */     return newLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public static DOMImplementation getDomImplementation(Saaj saaj) {
/*  96 */     return newLocale(saaj);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Document parse(String s) throws XmlException {
/*     */     DomImpl.Dom d;
/* 102 */     Locale l = newLocale();
/*     */ 
/*     */ 
/*     */     
/* 106 */     if (l.noSync()) { l.enter(); try { d = l.load(s); } finally { l.exit(); }  }
/* 107 */     else { synchronized (l) { l.enter(); try { d = l.load(s); } finally { l.exit(); }  }
/*     */        }
/* 109 */      return (Document)d;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Document parse(String s, XmlOptions options) throws XmlException {
/*     */     DomImpl.Dom d;
/* 115 */     Locale l = newLocale();
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (l.noSync()) { l.enter(); try { d = l.load(s, options); } finally { l.exit(); }  }
/* 120 */     else { synchronized (l) { l.enter(); try { d = l.load(s, options); } finally { l.exit(); }  }
/*     */        }
/* 122 */      return (Document)d;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Document parse(String s, Saaj saaj) throws XmlException {
/*     */     DomImpl.Dom d;
/* 128 */     Locale l = newLocale(saaj);
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (l.noSync()) { l.enter(); try { d = l.load(s); } finally { l.exit(); }  }
/* 133 */     else { synchronized (l) { l.enter(); try { d = l.load(s); } finally { l.exit(); }  }
/*     */        }
/* 135 */      return (Document)d;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Document parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/*     */     DomImpl.Dom d;
/* 141 */     Locale l = newLocale();
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (l.noSync()) { l.enter(); try { d = l.load(is, options); } finally { l.exit(); }  }
/* 146 */     else { synchronized (l) { l.enter(); try { d = l.load(is, options); } finally { l.exit(); }  }
/*     */        }
/* 148 */      return (Document)d;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Document parse(InputStream is, Saaj saaj) throws XmlException, IOException {
/*     */     DomImpl.Dom d;
/* 154 */     Locale l = newLocale(saaj);
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (l.noSync()) { l.enter(); try { d = l.load(is); } finally { l.exit(); }  }
/* 159 */     else { synchronized (l) { l.enter(); try { d = l.load(is); } finally { l.exit(); }  }
/*     */        }
/* 161 */      return (Document)d;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Node getNode(XMLStreamReader s) {
/* 166 */     return Jsr173.nodeFromStream(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public static XMLStreamReader getStream(Node n) {
/* 171 */     assert n instanceof DomImpl.Dom;
/*     */     
/* 173 */     DomImpl.Dom d = (DomImpl.Dom)n;
/*     */     
/* 175 */     Locale l = d.locale();
/*     */     
/* 177 */     if (l.noSync()) { l.enter(); try { return DomImpl.getXmlStreamReader(d); } finally { l.exit(); }  }
/* 178 */      synchronized (l) { l.enter(); try { return DomImpl.getXmlStreamReader(d); } finally { l.exit(); }
/*     */        }
/*     */   
/*     */   }
/*     */   public static String save(Node n) {
/* 183 */     return save(n, (XmlOptions)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void save(Node n, OutputStream os, XmlOptions options) throws IOException {
/* 188 */     XmlCursor c = getCursor(n);
/*     */     
/* 190 */     c.save(os, options);
/*     */     
/* 192 */     c.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String save(Node n, XmlOptions options) {
/* 197 */     assert n instanceof DomImpl.Dom;
/*     */     
/* 199 */     DomImpl.Dom d = (DomImpl.Dom)n;
/*     */     
/* 201 */     Locale l = d.locale();
/*     */     
/* 203 */     if (l.noSync()) { l.enter(); try { return saveImpl(d, options); } finally { l.exit(); }  }
/* 204 */      synchronized (l) { l.enter(); try { return saveImpl(d, options); } finally { l.exit(); }
/*     */        }
/*     */   
/*     */   }
/*     */   private static String saveImpl(DomImpl.Dom d, XmlOptions options) {
/* 209 */     Cur c = d.tempCur();
/*     */     
/* 211 */     String s = (new Saver.TextSaver(c, options, null)).saveToString();
/*     */     
/* 213 */     c.release();
/*     */     
/* 215 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String save(XmlCursor c) {
/* 220 */     return save(c, (XmlOptions)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String save(XmlCursor xc, XmlOptions options) {
/* 225 */     Cursor cursor = (Cursor)xc;
/*     */     
/* 227 */     Locale l = cursor.locale();
/*     */     
/* 229 */     if (l.noSync()) { l.enter(); try { return saveImpl(cursor, options); } finally { l.exit(); }  }
/* 230 */      synchronized (l) { l.enter(); try { return saveImpl(cursor, options); } finally { l.exit(); }
/*     */        }
/*     */   
/*     */   }
/*     */   private static String saveImpl(Cursor cursor, XmlOptions options) {
/* 235 */     Cur c = cursor.tempCur();
/*     */     
/* 237 */     String s = (new Saver.TextSaver(c, options, null)).saveToString();
/*     */     
/* 239 */     c.release();
/*     */     
/* 241 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public static XmlCursor newStore() {
/* 246 */     return newStore(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static XmlCursor newStore(Saaj saaj) {
/* 251 */     Locale l = newLocale(saaj);
/*     */     
/* 253 */     if (l.noSync()) { l.enter(); try { return _newStore(l); } finally { l.exit(); }  }
/* 254 */      synchronized (l) { l.enter(); try { return _newStore(l); } finally { l.exit(); }
/*     */        }
/*     */   
/*     */   }
/*     */   public static XmlCursor _newStore(Locale l) {
/* 259 */     Cur c = l.tempCur();
/*     */     
/* 261 */     c.createRoot();
/*     */     
/* 263 */     Cursor cursor = new Cursor(c);
/*     */     
/* 265 */     c.release();
/*     */     
/* 267 */     return cursor;
/*     */   }
/*     */ 
/*     */   
/*     */   public static XmlCursor getCursor(Node n) {
/* 272 */     assert n instanceof DomImpl.Dom;
/*     */     
/* 274 */     DomImpl.Dom d = (DomImpl.Dom)n;
/*     */     
/* 276 */     Locale l = d.locale();
/*     */     
/* 278 */     if (l.noSync()) { l.enter(); try { return DomImpl.getXmlCursor(d); } finally { l.exit(); }  }
/* 279 */      synchronized (l) { l.enter(); try { return DomImpl.getXmlCursor(d); } finally { l.exit(); }
/*     */        }
/*     */   
/*     */   }
/*     */   public static void dump(PrintStream o, DomImpl.Dom d) {
/* 284 */     d.dump(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dump(PrintStream o, Node n) {
/* 289 */     dump(o, (DomImpl.Dom)n);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dump(PrintStream o, XmlCursor c) {
/* 294 */     ((Cursor)c).dump(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dump(PrintStream o, XmlObject x) {
/* 299 */     XmlCursor xc = x.newCursor();
/* 300 */     Node n = xc.getDomNode();
/* 301 */     DomImpl.Dom d = (DomImpl.Dom)n;
/* 302 */     xc.dispose();
/*     */     
/* 304 */     dump(o, d);
/*     */   }
/*     */   
/* 307 */   public static void dump(DomImpl.Dom d) { dump(System.out, d); }
/* 308 */   public static void dump(Node n) { dump(System.out, n); }
/* 309 */   public static void dump(XmlCursor c) { dump(System.out, c); } public static void dump(XmlObject x) {
/* 310 */     dump(System.out, x);
/*     */   }
/*     */   private static class TestTypeStoreUser implements TypeStoreUser { private String _value;
/*     */     TestTypeStoreUser(String value) {
/* 314 */       this._value = value;
/*     */     }
/* 316 */     public SchemaType get_schema_type() { throw new RuntimeException("Not impl"); } public void attach_store(TypeStore store) {} public TypeStore get_store() {
/* 317 */       throw new RuntimeException("Not impl");
/*     */     } public void invalidate_value() {}
/* 319 */     public boolean uses_invalidate_value() { throw new RuntimeException("Not impl"); }
/* 320 */     public String build_text(NamespaceManager nsm) { return this._value; }
/* 321 */     public boolean build_nil() { throw new RuntimeException("Not impl"); }
/* 322 */     public void invalidate_nilvalue() { throw new RuntimeException("Not impl"); }
/* 323 */     public void invalidate_element_order() { throw new RuntimeException("Not impl"); }
/* 324 */     public void validate_now() { throw new RuntimeException("Not impl"); }
/* 325 */     public void disconnect_store() { throw new RuntimeException("Not impl"); }
/* 326 */     public TypeStoreUser create_element_user(QName eltName, QName xsiType) { return new TestTypeStoreUser("ELEM"); }
/* 327 */     public TypeStoreUser create_attribute_user(QName attrName) { throw new RuntimeException("Not impl"); }
/* 328 */     public String get_default_element_text(QName eltName) { throw new RuntimeException("Not impl"); }
/* 329 */     public String get_default_attribute_text(QName attrName) { throw new RuntimeException("Not impl"); }
/* 330 */     public SchemaType get_element_type(QName eltName, QName xsiType) { throw new RuntimeException("Not impl"); }
/* 331 */     public SchemaType get_attribute_type(QName attrName) { throw new RuntimeException("Not impl"); }
/* 332 */     public int get_elementflags(QName eltName) { throw new RuntimeException("Not impl"); }
/* 333 */     public int get_attributeflags(QName attrName) { throw new RuntimeException("Not impl"); }
/* 334 */     public SchemaField get_attribute_field(QName attrName) { throw new RuntimeException("Not impl"); }
/* 335 */     public boolean is_child_element_order_sensitive() { throw new RuntimeException("Not impl"); }
/* 336 */     public QNameSet get_element_ending_delimiters(QName eltname) { throw new RuntimeException("Not impl"); } public TypeStoreVisitor new_visitor() {
/* 337 */       throw new RuntimeException("Not impl");
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void test() throws Exception {
/* 344 */     Xobj x = (Xobj)parse("<a>XY</a>");
/*     */     
/* 346 */     Locale l = x._locale;
/*     */     
/* 348 */     l.enter();
/*     */ 
/*     */     
/*     */     try {
/* 352 */       Cur c = x.tempCur();
/*     */       
/* 354 */       c.next();
/*     */       
/* 356 */       Cur c2 = c.tempCur();
/* 357 */       c2.next();
/*     */       
/* 359 */       Cur c3 = c2.tempCur();
/* 360 */       c3.nextChars(1);
/*     */       
/* 362 */       Cur c4 = c3.tempCur();
/* 363 */       c4.nextChars(1);
/*     */       
/* 365 */       c.dump();
/*     */       
/* 367 */       c.moveNodeContents(c, true);
/*     */       
/* 369 */       c.dump();
/*     */     }
/* 371 */     catch (Throwable e) {
/*     */       
/* 373 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/*     */       
/* 377 */       l.exit();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\Public2.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */