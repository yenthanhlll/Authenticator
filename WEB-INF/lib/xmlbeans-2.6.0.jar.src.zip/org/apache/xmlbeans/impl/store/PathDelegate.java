/*    */ package org.apache.xmlbeans.impl.store;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PathDelegate
/*    */ {
/* 26 */   private static HashMap _constructors = new HashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static synchronized void init(String implClassName) {
/* 34 */     if (implClassName == null)
/* 35 */       implClassName = "org.apache.xmlbeans.impl.xpath.saxon.XBeansXPath"; 
/* 36 */     Class selectPathInterfaceImpl = null;
/* 37 */     boolean engineAvailable = true;
/*    */     
/*    */     try {
/* 40 */       selectPathInterfaceImpl = Class.forName(implClassName);
/*    */     }
/* 42 */     catch (ClassNotFoundException e) {
/*    */       
/* 44 */       engineAvailable = false;
/*    */     }
/* 46 */     catch (NoClassDefFoundError e) {
/*    */       
/* 48 */       engineAvailable = false;
/*    */     } 
/*    */     
/* 51 */     if (engineAvailable) {
/*    */       
/*    */       try {
/*    */         
/* 55 */         Constructor constructor = selectPathInterfaceImpl.getConstructor(new Class[] { String.class, String.class, Map.class, String.class });
/*    */         
/* 57 */         _constructors.put(implClassName, constructor);
/*    */       }
/* 59 */       catch (Exception e) {
/*    */         
/* 61 */         throw new RuntimeException(e);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized SelectPathInterface createInstance(String implClassName, String xpath, String contextVar, Map namespaceMap) {
/* 69 */     if (_constructors.get(implClassName) == null) {
/* 70 */       init(implClassName);
/*    */     }
/* 72 */     if (_constructors.get(implClassName) == null) {
/* 73 */       return null;
/*    */     }
/* 75 */     Constructor constructor = (Constructor)_constructors.get(implClassName);
/*    */     
/*    */     try {
/* 78 */       Object defaultNS = namespaceMap.get("$xmlbeans!default_uri");
/* 79 */       if (defaultNS != null)
/* 80 */         namespaceMap.remove("$xmlbeans!default_uri"); 
/* 81 */       return constructor.newInstance(new Object[] { xpath, contextVar, namespaceMap, defaultNS });
/*    */     
/*    */     }
/* 84 */     catch (Exception e) {
/*    */       
/* 86 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static interface SelectPathInterface {
/*    */     List selectPath(Object param1Object);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\PathDelegate.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */