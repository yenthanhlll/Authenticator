package org.apache.xmlbeans.impl.store;

import javax.xml.namespace.QName;

public interface QNameFactory {
  QName getQName(String paramString1, String paramString2);
  
  QName getQName(String paramString1, String paramString2, String paramString3);
  
  QName getQName(char[] paramArrayOfchar1, int paramInt1, int paramInt2, char[] paramArrayOfchar2, int paramInt3, int paramInt4);
  
  QName getQName(char[] paramArrayOfchar1, int paramInt1, int paramInt2, char[] paramArrayOfchar2, int paramInt3, int paramInt4, char[] paramArrayOfchar3, int paramInt5, int paramInt6);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\QNameFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */