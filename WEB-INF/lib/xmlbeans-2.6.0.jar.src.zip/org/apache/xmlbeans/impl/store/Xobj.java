/*      */ package org.apache.xmlbeans.impl.store;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.transform.Source;
/*      */ import org.apache.xmlbeans.CDataBookmark;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.SchemaField;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeLoader;
/*      */ import org.apache.xmlbeans.XmlBeans;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlException;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.common.ValidatorListener;
/*      */ import org.apache.xmlbeans.impl.common.XmlLocale;
/*      */ import org.apache.xmlbeans.impl.soap.Detail;
/*      */ import org.apache.xmlbeans.impl.soap.DetailEntry;
/*      */ import org.apache.xmlbeans.impl.soap.Name;
/*      */ import org.apache.xmlbeans.impl.soap.Node;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPBody;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPBodyElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPEnvelope;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPException;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPFault;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPFaultElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPHeader;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPHeaderElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPPart;
/*      */ import org.apache.xmlbeans.impl.values.NamespaceManager;
/*      */ import org.apache.xmlbeans.impl.values.TypeStore;
/*      */ import org.apache.xmlbeans.impl.values.TypeStoreUser;
/*      */ import org.apache.xmlbeans.impl.values.TypeStoreUserFactory;
/*      */ import org.apache.xmlbeans.impl.values.TypeStoreVisitor;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.CDATASection;
/*      */ import org.w3c.dom.Comment;
/*      */ import org.w3c.dom.DOMConfiguration;
/*      */ import org.w3c.dom.DOMImplementation;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.DocumentFragment;
/*      */ import org.w3c.dom.DocumentType;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.EntityReference;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.w3c.dom.ProcessingInstruction;
/*      */ import org.w3c.dom.Text;
/*      */ import org.w3c.dom.TypeInfo;
/*      */ import org.w3c.dom.UserDataHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class Xobj
/*      */   implements TypeStore
/*      */ {
/*      */   static final int TEXT = 0;
/*      */   static final int ROOT = 1;
/*      */   static final int ELEM = 2;
/*      */   static final int ATTR = 3;
/*      */   static final int COMMENT = 4;
/*      */   static final int PROCINST = 5;
/*      */   static final int END_POS = -1;
/*      */   static final int NO_POS = -2;
/*      */   static final int VACANT = 256;
/*      */   static final int STABLE_USER = 512;
/*      */   static final int INHIBIT_DISCONNECT = 1024;
/*      */   Locale _locale;
/*      */   QName _name;
/*      */   Cur _embedded;
/*      */   Bookmark _bookmarks;
/*      */   int _bits;
/*      */   Xobj _parent;
/*      */   Xobj _nextSibling;
/*      */   Xobj _prevSibling;
/*      */   Xobj _firstChild;
/*      */   Xobj _lastChild;
/*      */   Object _srcValue;
/*      */   Object _srcAfter;
/*      */   int _offValue;
/*      */   int _offAfter;
/*      */   int _cchValue;
/*      */   int _cchAfter;
/*      */   DomImpl.CharNode _charNodesValue;
/*      */   DomImpl.CharNode _charNodesAfter;
/*      */   TypeStoreUser _user;
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   Xobj(Locale l, int kind, int domType) {
/*  113 */     assert kind == 1 || kind == 2 || kind == 3 || kind == 4 || kind == 5;
/*      */     
/*  115 */     this._locale = l;
/*  116 */     this._bits = (domType << 4) + kind;
/*      */   }
/*      */   final boolean entered() {
/*  119 */     return this._locale.entered();
/*      */   }
/*  121 */   final int kind() { return this._bits & 0xF; } final int domType() {
/*  122 */     return (this._bits & 0xF0) >> 4;
/*      */   }
/*  124 */   final boolean isRoot() { return (kind() == 1); }
/*  125 */   final boolean isAttr() { return (kind() == 3); }
/*  126 */   final boolean isElem() { return (kind() == 2); }
/*  127 */   final boolean isProcinst() { return (kind() == 5); }
/*  128 */   final boolean isComment() { return (kind() == 4); }
/*  129 */   final boolean isContainer() { return Cur.kindIsContainer(kind()); } final boolean isUserNode() {
/*  130 */     int k = kind(); return (k == 2 || k == 1 || (k == 3 && !isXmlns()));
/*      */   }
/*  132 */   final boolean isNormalAttr() { return (isAttr() && !Locale.isXmlns(this._name)); } final boolean isXmlns() {
/*  133 */     return (isAttr() && Locale.isXmlns(this._name));
/*      */   }
/*  135 */   final int cchValue() { return this._cchValue; } final int cchAfter() {
/*  136 */     return this._cchAfter;
/*      */   }
/*  138 */   final int posAfter() { return 2 + this._cchValue; } final int posMax() {
/*  139 */     return 2 + this._cchValue + this._cchAfter;
/*      */   }
/*  141 */   final String getXmlnsPrefix() { return Locale.xmlnsPrefix(this._name); } final String getXmlnsUri() {
/*  142 */     return getValueAsString();
/*      */   }
/*      */   
/*      */   final boolean hasTextEnsureOccupancy() {
/*  146 */     ensureOccupancy();
/*  147 */     return hasTextNoEnsureOccupancy();
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean hasTextNoEnsureOccupancy() {
/*  152 */     if (this._cchValue > 0) {
/*  153 */       return true;
/*      */     }
/*  155 */     Xobj lastAttr = lastAttr();
/*      */     
/*  157 */     return (lastAttr != null && lastAttr._cchAfter > 0);
/*      */   }
/*      */   
/*  160 */   final boolean hasAttrs() { return (this._firstChild != null && this._firstChild.isAttr()); } final boolean hasChildren() {
/*  161 */     return (this._lastChild != null && !this._lastChild.isAttr());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int getDomZeroOneChildren() {
/*  173 */     if (this._firstChild == null && this._srcValue == null && this._charNodesValue == null)
/*      */     {
/*      */       
/*  176 */       return 0;
/*      */     }
/*  178 */     if (this._lastChild != null && this._lastChild.isAttr() && this._lastChild._charNodesAfter == null && this._lastChild._srcAfter == null && this._srcValue == null && this._charNodesValue == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  185 */       return 0;
/*      */     }
/*  187 */     if (this._firstChild == this._lastChild && this._firstChild != null && !this._firstChild.isAttr() && this._srcValue == null && this._charNodesValue == null && this._firstChild._srcAfter == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  194 */       return 1;
/*      */     }
/*  196 */     if (this._firstChild == null && this._srcValue != null && (this._charNodesValue == null || (this._charNodesValue._next == null && this._charNodesValue._cch == this._cchValue)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  202 */       return 1;
/*      */     }
/*  204 */     Xobj lastAttr = lastAttr();
/*  205 */     Xobj node = (lastAttr == null) ? null : lastAttr._nextSibling;
/*      */     
/*  207 */     if (lastAttr != null && lastAttr._srcAfter == null && node != null && node._srcAfter == null && node._nextSibling == null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  212 */       return 1;
/*      */     }
/*  214 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean isFirstChildPtrDomUsable() {
/*  225 */     if (this._firstChild == null && this._srcValue == null && this._charNodesValue == null)
/*      */     {
/*      */       
/*  228 */       return true;
/*      */     }
/*  230 */     if (this._firstChild != null && !this._firstChild.isAttr() && this._srcValue == null && this._charNodesValue == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  236 */       assert this._firstChild instanceof NodeXobj : "wrong node type";
/*  237 */       return true;
/*      */     } 
/*  239 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean isNextSiblingPtrDomUsable() {
/*  249 */     if (this._charNodesAfter == null && this._srcAfter == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  254 */       assert this._nextSibling == null || this._nextSibling instanceof NodeXobj : "wrong node type";
/*  255 */       return true;
/*      */     } 
/*  257 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean isExistingCharNodesValueUsable() {
/*  267 */     if (this._srcValue == null) return false; 
/*  268 */     if (this._charNodesValue != null && this._charNodesValue._next == null && this._charNodesValue._cch == this._cchValue)
/*      */     {
/*  270 */       return true; } 
/*  271 */     return false;
/*      */   }
/*      */   
/*      */   protected final boolean isCharNodesValueUsable() {
/*  275 */     return (isExistingCharNodesValueUsable() || (this._charNodesValue = Cur.updateCharNodes(this._locale, this, this._charNodesValue, this._cchValue)) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean isCharNodesAfterUsable() {
/*  289 */     if (this._srcAfter == null) return false; 
/*  290 */     if (this._charNodesAfter != null && this._charNodesAfter._next == null && this._charNodesAfter._cch == this._cchAfter)
/*      */     {
/*  292 */       return true; } 
/*  293 */     return ((this._charNodesAfter = Cur.updateCharNodes(this._locale, this, this._charNodesAfter, this._cchAfter)) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Xobj lastAttr() {
/*  301 */     if (this._firstChild == null || !this._firstChild.isAttr()) {
/*  302 */       return null;
/*      */     }
/*  304 */     Xobj lastAttr = this._firstChild;
/*      */     
/*  306 */     while (lastAttr._nextSibling != null && lastAttr._nextSibling.isAttr()) {
/*  307 */       lastAttr = lastAttr._nextSibling;
/*      */     }
/*  309 */     return lastAttr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int cchLeft(int p) {
/*  318 */     if (isRoot() && p == 0) {
/*  319 */       return 0;
/*      */     }
/*  321 */     Xobj x = getDenormal(p);
/*      */     
/*  323 */     p = posTemp();
/*  324 */     int pa = x.posAfter();
/*      */     
/*  326 */     return p - ((p < pa) ? 1 : pa);
/*      */   }
/*      */ 
/*      */   
/*      */   final int cchRight(int p) {
/*  331 */     assert p < posMax();
/*      */     
/*  333 */     if (p <= 0) {
/*  334 */       return 0;
/*      */     }
/*  336 */     int pa = posAfter();
/*      */     
/*  338 */     return (p < pa) ? (pa - p - 1) : (posMax() - p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Locale locale() {
/*  345 */     return this._locale;
/*  346 */   } public final int nodeType() { return domType(); } public final QName getQName() {
/*  347 */     return this._name;
/*      */   } public final Cur tempCur() {
/*  349 */     Cur c = this._locale.tempCur(); c.moveTo(this); return c;
/*      */   }
/*  351 */   public void dump(PrintStream o, Object ref) { Cur.dump(o, this, ref); }
/*  352 */   public void dump(PrintStream o) { Cur.dump(o, this, this); } public void dump() {
/*  353 */     dump(System.out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Cur getEmbedded() {
/*  361 */     this._locale.embedCurs();
/*      */     
/*  363 */     return this._embedded;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean inChars(int p, Xobj xIn, int pIn, int cch, boolean includeEnd) {
/*      */     int offset;
/*  370 */     assert p > 0 && p < posMax() && p != posAfter() - 1 && cch > 0;
/*  371 */     assert xIn.isNormal(pIn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  378 */     if (includeEnd) {
/*      */ 
/*      */ 
/*      */       
/*  382 */       if (xIn.isRoot() && pIn == 0) {
/*  383 */         return false;
/*      */       }
/*  385 */       xIn = xIn.getDenormal(pIn);
/*  386 */       pIn = xIn.posTemp();
/*      */       
/*  388 */       offset = 1;
/*      */     } else {
/*      */       
/*  391 */       offset = 0;
/*      */     } 
/*  393 */     return (xIn == this && pIn >= p && pIn < p + ((cch < 0) ? cchRight(p) : cch) + offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isJustAfterEnd(Xobj x, int p) {
/*  400 */     assert x.isNormal(p);
/*      */ 
/*      */ 
/*      */     
/*  404 */     if (x.isRoot() && p == 0) {
/*  405 */       return false;
/*      */     }
/*  407 */     return (x == this) ? ((p == posAfter())) : ((x.getDenormal(p) == this && x.posTemp() == posAfter()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isInSameTree(Xobj x) {
/*  415 */     if (this._locale != x._locale) {
/*  416 */       return false;
/*      */     }
/*  418 */     for (Xobj y = this;; y = y._parent) {
/*      */       
/*  420 */       if (y == x) {
/*  421 */         return true;
/*      */       }
/*  423 */       if (y._parent == null) {
/*      */         
/*  425 */         for (;; x = x._parent) {
/*      */           
/*  427 */           if (x == this) {
/*  428 */             return true;
/*      */           }
/*  430 */           if (x._parent == null)
/*  431 */             return (x == y); 
/*      */         } 
/*      */         break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   final boolean contains(Cur c) {
/*  439 */     assert c.isNormal();
/*      */     
/*  441 */     return contains(c._xobj, c._pos);
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean contains(Xobj x, int p) {
/*  446 */     assert x.isNormal(p);
/*      */     
/*  448 */     if (this == x) {
/*  449 */       return (p == -1 || (p > 0 && p < posAfter()));
/*      */     }
/*  451 */     if (this._firstChild == null) {
/*  452 */       return false;
/*      */     }
/*  454 */     for (; x != null; x = x._parent) {
/*  455 */       if (x == this)
/*  456 */         return true; 
/*      */     } 
/*  458 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   final Bookmark setBookmark(int p, Object key, Object value) {
/*  463 */     assert isNormal(p);
/*      */     Bookmark b;
/*  465 */     for (b = this._bookmarks; b != null; b = b._next) {
/*      */       
/*  467 */       if (p == b._pos && key == b._key) {
/*      */         
/*  469 */         if (value == null) {
/*      */           
/*  471 */           this._bookmarks = b.listRemove(this._bookmarks);
/*  472 */           return null;
/*      */         } 
/*      */         
/*  475 */         b._value = value;
/*      */         
/*  477 */         return b;
/*      */       } 
/*      */     } 
/*      */     
/*  481 */     if (value == null) {
/*  482 */       return null;
/*      */     }
/*  484 */     b = new Bookmark();
/*      */     
/*  486 */     b._xobj = this;
/*  487 */     b._pos = p;
/*  488 */     b._key = key;
/*  489 */     b._value = value;
/*      */     
/*  491 */     this._bookmarks = b.listInsert(this._bookmarks);
/*      */     
/*  493 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean hasBookmark(Object key, int pos) {
/*  498 */     for (Bookmark b = this._bookmarks; b != null; b = b._next) {
/*  499 */       if (b._pos == pos && key == b._key)
/*      */       {
/*      */         
/*  502 */         return true;
/*      */       }
/*      */     } 
/*  505 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj findXmlnsForPrefix(String prefix) {
/*  510 */     assert isContainer() && prefix != null;
/*      */     
/*  512 */     for (Xobj c = this; c != null; c = c._parent) {
/*  513 */       for (Xobj a = c.firstAttr(); a != null; a = a.nextAttr()) {
/*  514 */         if (a.isXmlns() && a.getXmlnsPrefix().equals(prefix))
/*  515 */           return a; 
/*      */       } 
/*  517 */     }  return null;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean removeAttr(QName name) {
/*  522 */     assert isContainer();
/*      */     
/*  524 */     Xobj a = getAttr(name);
/*      */     
/*  526 */     if (a == null) {
/*  527 */       return false;
/*      */     }
/*  529 */     Cur c = a.tempCur();
/*      */ 
/*      */     
/*      */     while (true) {
/*  533 */       c.moveNode(null);
/*      */       
/*  535 */       a = getAttr(name);
/*      */       
/*  537 */       if (a == null) {
/*      */         break;
/*      */       }
/*  540 */       c.moveTo(a);
/*      */     } 
/*      */     
/*  543 */     c.release();
/*      */     
/*  545 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj setAttr(QName name, String value) {
/*  550 */     assert isContainer();
/*      */     
/*  552 */     Cur c = tempCur();
/*      */     
/*  554 */     if (c.toAttr(name)) {
/*  555 */       c.removeFollowingAttrs();
/*      */     } else {
/*      */       
/*  558 */       c.next();
/*  559 */       c.createAttr(name);
/*      */     } 
/*      */     
/*  562 */     c.setValue(value);
/*      */     
/*  564 */     Xobj a = c._xobj;
/*      */     
/*  566 */     c.release();
/*      */     
/*  568 */     return a;
/*      */   }
/*      */ 
/*      */   
/*      */   final void setName(QName newName) {
/*  573 */     assert isAttr() || isElem() || isProcinst();
/*  574 */     assert newName != null;
/*      */     
/*  576 */     if (!this._name.equals(newName) || !this._name.getPrefix().equals(newName.getPrefix())) {
/*      */ 
/*      */       
/*  579 */       this._locale.notifyChange();
/*      */       
/*  581 */       QName oldName = this._name;
/*      */       
/*  583 */       this._name = newName;
/*  584 */       if (this instanceof NamedNodeXobj) {
/*      */         
/*  586 */         NamedNodeXobj me = (NamedNodeXobj)this;
/*  587 */         me._canHavePrefixUri = true;
/*      */       } 
/*      */       
/*  590 */       if (!isProcinst()) {
/*      */         
/*  592 */         Xobj disconnectFromHere = this;
/*      */         
/*  594 */         if (isAttr() && this._parent != null) {
/*      */           
/*  596 */           if (oldName.equals(Locale._xsiType) || newName.equals(Locale._xsiType)) {
/*  597 */             disconnectFromHere = this._parent;
/*      */           }
/*  599 */           if (oldName.equals(Locale._xsiNil) || newName.equals(Locale._xsiNil)) {
/*  600 */             this._parent.invalidateNil();
/*      */           }
/*      */         } 
/*  603 */         disconnectFromHere.disconnectNonRootUsers();
/*      */       } 
/*      */       
/*  606 */       this._locale._versionAll++;
/*  607 */       this._locale._versionSansText++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj ensureParent() {
/*  613 */     assert this._parent != null || (!isRoot() && cchAfter() == 0);
/*  614 */     return (this._parent == null) ? (new DocumentFragXobj(this._locale)).appendXobj(this) : this._parent;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj firstAttr() {
/*  619 */     return (this._firstChild == null || !this._firstChild.isAttr()) ? null : this._firstChild;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj nextAttr() {
/*  624 */     if (this._firstChild != null && this._firstChild.isAttr()) {
/*  625 */       return this._firstChild;
/*      */     }
/*  627 */     if (this._nextSibling != null && this._nextSibling.isAttr()) {
/*  628 */       return this._nextSibling;
/*      */     }
/*  630 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean isValid() {
/*  635 */     if (isVacant() && (this._cchValue != 0 || this._user == null)) {
/*  636 */       return false;
/*      */     }
/*  638 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   final int posTemp() {
/*  643 */     return this._locale._posTemp;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj getNormal(int p) {
/*  648 */     assert p == -1 || (p >= 0 && p <= posMax());
/*      */     
/*  650 */     Xobj x = this;
/*      */     
/*  652 */     if (p == x.posMax()) {
/*      */       
/*  654 */       if (x._nextSibling != null)
/*      */       {
/*  656 */         x = x._nextSibling;
/*  657 */         p = 0;
/*      */       }
/*      */       else
/*      */       {
/*  661 */         x = x.ensureParent();
/*  662 */         p = -1;
/*      */       }
/*      */     
/*  665 */     } else if (p == x.posAfter() - 1) {
/*  666 */       p = -1;
/*      */     } 
/*  668 */     this._locale._posTemp = p;
/*      */     
/*  670 */     return x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Xobj getDenormal(int p) {
/*  679 */     assert !isRoot() || p == -1 || p > 0;
/*      */     
/*  681 */     Xobj x = this;
/*      */     
/*  683 */     if (p == 0) {
/*      */       
/*  685 */       if (x._prevSibling == null)
/*      */       {
/*  687 */         x = x.ensureParent();
/*  688 */         p = x.posAfter() - 1;
/*      */       }
/*      */       else
/*      */       {
/*  692 */         x = x._prevSibling;
/*  693 */         p = x.posMax();
/*      */       }
/*      */     
/*  696 */     } else if (p == -1) {
/*      */       
/*  698 */       if (x._lastChild == null) {
/*  699 */         p = x.posAfter() - 1;
/*      */       } else {
/*      */         
/*  702 */         x = x._lastChild;
/*  703 */         p = x.posMax();
/*      */       } 
/*      */     } 
/*      */     
/*  707 */     this._locale._posTemp = p;
/*      */     
/*  709 */     return x;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean isNormal(int p) {
/*  714 */     if (!isValid()) {
/*  715 */       return false;
/*      */     }
/*  717 */     if (p == -1 || p == 0) {
/*  718 */       return true;
/*      */     }
/*  720 */     if (p < 0 || p >= posMax()) {
/*  721 */       return false;
/*      */     }
/*  723 */     if (p >= posAfter()) {
/*      */       
/*  725 */       if (isRoot()) {
/*  726 */         return false;
/*      */       }
/*  728 */       if (this._nextSibling != null && this._nextSibling.isAttr()) {
/*  729 */         return false;
/*      */       }
/*  731 */       if (this._parent == null || !this._parent.isContainer()) {
/*  732 */         return false;
/*      */       }
/*      */     } 
/*  735 */     if (p == posAfter() - 1) {
/*  736 */       return false;
/*      */     }
/*  738 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj walk(Xobj root, boolean walkChildren) {
/*  743 */     if (this._firstChild != null && walkChildren) {
/*  744 */       return this._firstChild;
/*      */     }
/*  746 */     for (Xobj x = this; x != root; x = x._parent) {
/*  747 */       if (x._nextSibling != null)
/*  748 */         return x._nextSibling; 
/*      */     } 
/*  750 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj removeXobj() {
/*  755 */     if (this._parent != null) {
/*      */       
/*  757 */       if (this._parent._firstChild == this) {
/*  758 */         this._parent._firstChild = this._nextSibling;
/*      */       }
/*  760 */       if (this._parent._lastChild == this) {
/*  761 */         this._parent._lastChild = this._prevSibling;
/*      */       }
/*  763 */       if (this._prevSibling != null) {
/*  764 */         this._prevSibling._nextSibling = this._nextSibling;
/*      */       }
/*  766 */       if (this._nextSibling != null) {
/*  767 */         this._nextSibling._prevSibling = this._prevSibling;
/*      */       }
/*  769 */       this._parent = null;
/*  770 */       this._prevSibling = null;
/*  771 */       this._nextSibling = null;
/*      */     } 
/*      */     
/*  774 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj insertXobj(Xobj s) {
/*  779 */     assert this._locale == s._locale;
/*  780 */     assert !s.isRoot() && !isRoot();
/*  781 */     assert s._parent == null;
/*  782 */     assert s._prevSibling == null;
/*  783 */     assert s._nextSibling == null;
/*      */     
/*  785 */     ensureParent();
/*      */     
/*  787 */     s._parent = this._parent;
/*  788 */     s._prevSibling = this._prevSibling;
/*  789 */     s._nextSibling = this;
/*      */     
/*  791 */     if (this._prevSibling != null) {
/*  792 */       this._prevSibling._nextSibling = s;
/*      */     } else {
/*  794 */       this._parent._firstChild = s;
/*      */     } 
/*  796 */     this._prevSibling = s;
/*      */     
/*  798 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj appendXobj(Xobj c) {
/*  803 */     assert this._locale == c._locale;
/*  804 */     assert !c.isRoot();
/*  805 */     assert c._parent == null;
/*  806 */     assert c._prevSibling == null;
/*  807 */     assert c._nextSibling == null;
/*  808 */     assert this._lastChild == null || this._firstChild != null;
/*      */     
/*  810 */     c._parent = this;
/*  811 */     c._prevSibling = this._lastChild;
/*      */     
/*  813 */     if (this._lastChild == null) {
/*  814 */       this._firstChild = c;
/*      */     } else {
/*  816 */       this._lastChild._nextSibling = c;
/*      */     } 
/*  818 */     this._lastChild = c;
/*      */     
/*  820 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   final void removeXobjs(Xobj first, Xobj last) {
/*  825 */     assert last._locale == first._locale;
/*  826 */     assert first._parent == this;
/*  827 */     assert last._parent == this;
/*      */     
/*  829 */     if (this._firstChild == first) {
/*  830 */       this._firstChild = last._nextSibling;
/*      */     }
/*  832 */     if (this._lastChild == last) {
/*  833 */       this._lastChild = first._prevSibling;
/*      */     }
/*  835 */     if (first._prevSibling != null) {
/*  836 */       first._prevSibling._nextSibling = last._nextSibling;
/*      */     }
/*  838 */     if (last._nextSibling != null) {
/*  839 */       last._nextSibling._prevSibling = first._prevSibling;
/*      */     }
/*      */ 
/*      */     
/*  843 */     first._prevSibling = null;
/*  844 */     last._nextSibling = null;
/*      */     
/*  846 */     for (; first != null; first = first._nextSibling) {
/*  847 */       first._parent = null;
/*      */     }
/*      */   }
/*      */   
/*      */   final void insertXobjs(Xobj first, Xobj last) {
/*  852 */     assert this._locale == first._locale;
/*  853 */     assert last._locale == first._locale;
/*  854 */     assert first._parent == null && last._parent == null;
/*  855 */     assert first._prevSibling == null;
/*  856 */     assert last._nextSibling == null;
/*      */     
/*  858 */     first._prevSibling = this._prevSibling;
/*  859 */     last._nextSibling = this;
/*      */     
/*  861 */     if (this._prevSibling != null) {
/*  862 */       this._prevSibling._nextSibling = first;
/*      */     } else {
/*  864 */       this._parent._firstChild = first;
/*      */     } 
/*  866 */     this._prevSibling = last;
/*      */     
/*  868 */     for (; first != this; first = first._nextSibling) {
/*  869 */       first._parent = this._parent;
/*      */     }
/*      */   }
/*      */   
/*      */   final void appendXobjs(Xobj first, Xobj last) {
/*  874 */     assert this._locale == first._locale;
/*  875 */     assert last._locale == first._locale;
/*  876 */     assert first._parent == null && last._parent == null;
/*  877 */     assert first._prevSibling == null;
/*  878 */     assert last._nextSibling == null;
/*  879 */     assert !first.isRoot();
/*      */     
/*  881 */     first._prevSibling = this._lastChild;
/*      */     
/*  883 */     if (this._lastChild == null) {
/*  884 */       this._firstChild = first;
/*      */     } else {
/*  886 */       this._lastChild._nextSibling = first;
/*      */     } 
/*  888 */     this._lastChild = last;
/*      */     
/*  890 */     for (; first != null; first = first._nextSibling) {
/*  891 */       first._parent = this;
/*      */     }
/*      */   }
/*      */   
/*      */   static final void disbandXobjs(Xobj first, Xobj last) {
/*  896 */     assert last._locale == first._locale;
/*  897 */     assert first._parent == null && last._parent == null;
/*  898 */     assert first._prevSibling == null;
/*  899 */     assert last._nextSibling == null;
/*  900 */     assert !first.isRoot();
/*      */     
/*  902 */     while (first != null) {
/*      */       
/*  904 */       Xobj next = first._nextSibling;
/*  905 */       first._nextSibling = first._prevSibling = null;
/*  906 */       first = next;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void invalidateSpecialAttr(Xobj newParent) {
/*  914 */     if (isAttr()) {
/*      */       
/*  916 */       if (this._name.equals(Locale._xsiType)) {
/*      */         
/*  918 */         if (this._parent != null) {
/*  919 */           this._parent.disconnectNonRootUsers();
/*      */         }
/*  921 */         if (newParent != null) {
/*  922 */           newParent.disconnectNonRootUsers();
/*      */         }
/*      */       } 
/*  925 */       if (this._name.equals(Locale._xsiNil)) {
/*      */         
/*  927 */         if (this._parent != null) {
/*  928 */           this._parent.invalidateNil();
/*      */         }
/*  930 */         if (newParent != null) {
/*  931 */           newParent.invalidateNil();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void removeCharsHelper(int p, int cchRemove, Xobj xTo, int pTo, boolean moveCurs, boolean invalidate) {
/*  948 */     assert p > 0 && p < posMax() && p != posAfter() - 1;
/*  949 */     assert cchRemove > 0;
/*  950 */     assert cchRight(p) >= cchRemove;
/*  951 */     assert !moveCurs || xTo != null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  962 */     for (Cur c = getEmbedded(); c != null; ) {
/*      */       
/*  964 */       Cur next = c._next;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  973 */       assert c._xobj == this;
/*      */       
/*  975 */       if (c._pos >= p && c._pos < p + cchRemove)
/*      */       {
/*  977 */         if (moveCurs) {
/*  978 */           c.moveToNoCheck(xTo, pTo + c._pos - p);
/*      */         } else {
/*  980 */           c.nextChars(cchRemove - c._pos + p);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  987 */       if (c._xobj == this && c._pos >= p + cchRemove) {
/*  988 */         c._pos -= cchRemove;
/*      */       }
/*  990 */       c = next;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     for (Bookmark b = this._bookmarks; b != null; ) {
/*      */       
/* 1000 */       Bookmark next = b._next;
/*      */ 
/*      */ 
/*      */       
/* 1004 */       assert b._xobj == this;
/*      */       
/* 1006 */       if (b._pos >= p && b._pos < p + cchRemove) {
/*      */         
/* 1008 */         assert xTo != null;
/* 1009 */         b.moveTo(xTo, pTo + b._pos - p);
/*      */       } 
/*      */       
/* 1012 */       if (b._xobj == this && b._pos >= p + cchRemove) {
/* 1013 */         b._pos -= cchRemove;
/*      */       }
/* 1015 */       b = b._next;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1020 */     int pa = posAfter();
/* 1021 */     CharUtil cu = this._locale.getCharUtil();
/*      */     
/* 1023 */     if (p < pa) {
/*      */       
/* 1025 */       this._srcValue = cu.removeChars(p - 1, cchRemove, this._srcValue, this._offValue, this._cchValue);
/* 1026 */       this._offValue = cu._offSrc;
/* 1027 */       this._cchValue = cu._cchSrc;
/*      */       
/* 1029 */       if (invalidate)
/*      */       {
/* 1031 */         invalidateUser();
/* 1032 */         invalidateSpecialAttr(null);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1037 */       this._srcAfter = cu.removeChars(p - pa, cchRemove, this._srcAfter, this._offAfter, this._cchAfter);
/* 1038 */       this._offAfter = cu._offSrc;
/* 1039 */       this._cchAfter = cu._cchSrc;
/*      */       
/* 1041 */       if (invalidate && this._parent != null) {
/* 1042 */         this._parent.invalidateUser();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void insertCharsHelper(int p, Object src, int off, int cch, boolean invalidate) {
/* 1052 */     assert p > 0;
/* 1053 */     assert p >= posAfter() || isOccupied();
/*      */     
/* 1055 */     int pa = posAfter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1062 */     if (p - ((p < pa) ? 1 : 2) < this._cchValue + this._cchAfter) {
/*      */       
/* 1064 */       for (Cur c = getEmbedded(); c != null; c = c._next) {
/* 1065 */         if (c._pos >= p)
/* 1066 */           c._pos += cch; 
/*      */       } 
/* 1068 */       for (Bookmark b = this._bookmarks; b != null; b = b._next) {
/* 1069 */         if (b._pos >= p) {
/* 1070 */           b._pos += cch;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1078 */     CharUtil cu = this._locale.getCharUtil();
/*      */     
/* 1080 */     if (p < pa) {
/*      */       
/* 1082 */       this._srcValue = cu.insertChars(p - 1, this._srcValue, this._offValue, this._cchValue, src, off, cch);
/* 1083 */       this._offValue = cu._offSrc;
/* 1084 */       this._cchValue = cu._cchSrc;
/*      */       
/* 1086 */       if (invalidate)
/*      */       {
/* 1088 */         invalidateUser();
/* 1089 */         invalidateSpecialAttr(null);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1094 */       this._srcAfter = cu.insertChars(p - pa, this._srcAfter, this._offAfter, this._cchAfter, src, off, cch);
/* 1095 */       this._offAfter = cu._offSrc;
/* 1096 */       this._cchAfter = cu._cchSrc;
/*      */       
/* 1098 */       if (invalidate && this._parent != null) {
/* 1099 */         this._parent.invalidateUser();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   Xobj copyNode(Locale toLocale) {
/* 1105 */     Xobj newParent = null;
/* 1106 */     Xobj copy = null;
/*      */     
/* 1108 */     Xobj x = this;
/*      */     while (true) {
/* 1110 */       x.ensureOccupancy();
/*      */       
/* 1112 */       Xobj newX = x.newNode(toLocale);
/*      */       
/* 1114 */       newX._srcValue = x._srcValue;
/* 1115 */       newX._offValue = x._offValue;
/* 1116 */       newX._cchValue = x._cchValue;
/*      */       
/* 1118 */       newX._srcAfter = x._srcAfter;
/* 1119 */       newX._offAfter = x._offAfter;
/* 1120 */       newX._cchAfter = x._cchAfter;
/*      */       
/* 1122 */       for (Bookmark b = x._bookmarks; b != null; b = b._next) {
/*      */         
/* 1124 */         if (x.hasBookmark(CDataBookmark.CDATA_BOOKMARK.getKey(), b._pos)) {
/* 1125 */           newX.setBookmark(b._pos, CDataBookmark.CDATA_BOOKMARK.getKey(), CDataBookmark.CDATA_BOOKMARK);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1131 */       if (newParent == null) {
/* 1132 */         copy = newX;
/*      */       } else {
/* 1134 */         newParent.appendXobj(newX);
/*      */       } 
/*      */ 
/*      */       
/* 1138 */       Xobj y = x;
/*      */       
/* 1140 */       if ((x = x.walk(this, true)) == null) {
/*      */         break;
/*      */       }
/* 1143 */       if (y == x._parent) {
/* 1144 */         newParent = newX; continue;
/*      */       } 
/* 1146 */       for (; y._parent != x._parent; y = y._parent) {
/* 1147 */         newParent = newParent._parent;
/*      */       }
/*      */     } 
/* 1150 */     copy._srcAfter = null;
/* 1151 */     copy._offAfter = 0;
/* 1152 */     copy._cchAfter = 0;
/*      */     
/* 1154 */     return copy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getCharsAsString(int p, int cch, int wsr) {
/* 1161 */     if (cchRight(p) == 0) {
/* 1162 */       return "";
/*      */     }
/* 1164 */     Object src = getChars(p, cch);
/*      */     
/* 1166 */     if (wsr == 1) {
/* 1167 */       return CharUtil.getString(src, this._locale._offSrc, this._locale._cchSrc);
/*      */     }
/* 1169 */     Locale.ScrubBuffer scrub = Locale.getScrubBuffer(wsr);
/*      */     
/* 1171 */     scrub.scrub(src, this._locale._offSrc, this._locale._cchSrc);
/*      */     
/* 1173 */     return scrub.getResultAsString();
/*      */   }
/*      */   
/*      */   String getCharsAfterAsString(int off, int cch) {
/* 1177 */     int offset = off + this._cchValue + 2;
/* 1178 */     if (offset == posMax())
/* 1179 */       offset = -1; 
/* 1180 */     return getCharsAsString(offset, cch, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   String getCharsValueAsString(int off, int cch) {
/* 1185 */     return getCharsAsString(off + 1, cch, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   String getValueAsString(int wsr) {
/* 1190 */     if (!hasChildren()) {
/*      */       
/* 1192 */       Object src = getFirstChars();
/*      */       
/* 1194 */       if (wsr == 1) {
/*      */         
/* 1196 */         String str = CharUtil.getString(src, this._locale._offSrc, this._locale._cchSrc);
/*      */ 
/*      */ 
/*      */         
/* 1200 */         int cch = str.length();
/*      */         
/* 1202 */         if (cch > 0) {
/*      */           
/* 1204 */           Xobj lastAttr = lastAttr();
/*      */           
/* 1206 */           assert ((lastAttr == null) ? this._cchValue : lastAttr._cchAfter) == cch;
/*      */           
/* 1208 */           if (lastAttr != null) {
/*      */             
/* 1210 */             lastAttr._srcAfter = str;
/* 1211 */             lastAttr._offAfter = 0;
/*      */           }
/*      */           else {
/*      */             
/* 1215 */             this._srcValue = str;
/* 1216 */             this._offValue = 0;
/*      */           } 
/*      */         } 
/*      */         
/* 1220 */         return str;
/*      */       } 
/*      */       
/* 1223 */       Locale.ScrubBuffer scrubBuffer = Locale.getScrubBuffer(wsr);
/*      */       
/* 1225 */       scrubBuffer.scrub(src, this._locale._offSrc, this._locale._cchSrc);
/*      */       
/* 1227 */       return scrubBuffer.getResultAsString();
/*      */     } 
/*      */     
/* 1230 */     Locale.ScrubBuffer scrub = Locale.getScrubBuffer(wsr);
/*      */     
/* 1232 */     Cur c = tempCur();
/*      */     
/* 1234 */     c.push();
/*      */     
/* 1236 */     c.next(); while (!c.isAtEndOfLastPush()) {
/*      */       
/* 1238 */       if (c.isText()) {
/* 1239 */         scrub.scrub(c.getChars(-1), c._offSrc, c._cchSrc);
/*      */       }
/* 1241 */       if (c.isComment() || c.isProcinst()) {
/* 1242 */         c.skip(); continue;
/*      */       } 
/* 1244 */       c.next();
/*      */     } 
/*      */     
/* 1247 */     String s = scrub.getResultAsString();
/*      */     
/* 1249 */     c.release();
/*      */     
/* 1251 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   String getValueAsString() {
/* 1256 */     return getValueAsString(1);
/*      */   }
/*      */   
/*      */   String getString(int p, int cch) {
/*      */     String s;
/* 1261 */     int cchRight = cchRight(p);
/*      */     
/* 1263 */     if (cchRight == 0) {
/* 1264 */       return "";
/*      */     }
/* 1266 */     if (cch < 0 || cch > cchRight) {
/* 1267 */       cch = cchRight;
/*      */     }
/* 1269 */     int pa = posAfter();
/*      */     
/* 1271 */     assert p > 0;
/*      */ 
/*      */ 
/*      */     
/* 1275 */     if (p >= pa) {
/*      */       
/* 1277 */       s = CharUtil.getString(this._srcAfter, this._offAfter + p - pa, cch);
/*      */       
/* 1279 */       if (p == pa && cch == this._cchAfter)
/*      */       {
/* 1281 */         this._srcAfter = s;
/* 1282 */         this._offAfter = 0;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1287 */       s = CharUtil.getString(this._srcValue, this._offValue + p - 1, cch);
/*      */       
/* 1289 */       if (p == 1 && cch == this._cchValue) {
/*      */         
/* 1291 */         this._srcValue = s;
/* 1292 */         this._offValue = 0;
/*      */       } 
/*      */     } 
/*      */     
/* 1296 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getFirstChars() {
/* 1304 */     ensureOccupancy();
/*      */     
/* 1306 */     if (this._cchValue > 0) {
/* 1307 */       return getChars(1, -1);
/*      */     }
/* 1309 */     Xobj lastAttr = lastAttr();
/*      */     
/* 1311 */     if (lastAttr == null || lastAttr._cchAfter <= 0) {
/*      */       
/* 1313 */       this._locale._offSrc = 0;
/* 1314 */       this._locale._cchSrc = 0;
/*      */       
/* 1316 */       return null;
/*      */     } 
/*      */     
/* 1319 */     return lastAttr.getChars(lastAttr.posAfter(), -1);
/*      */   }
/*      */ 
/*      */   
/*      */   Object getChars(int pos, int cch, Cur c) {
/* 1324 */     Object src = getChars(pos, cch);
/*      */     
/* 1326 */     c._offSrc = this._locale._offSrc;
/* 1327 */     c._cchSrc = this._locale._cchSrc;
/*      */     
/* 1329 */     return src;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getChars(int pos, int cch) {
/* 1336 */     assert isNormal(pos);
/*      */     
/* 1338 */     int cchRight = cchRight(pos);
/*      */     
/* 1340 */     if (cch < 0 || cch > cchRight) {
/* 1341 */       cch = cchRight;
/*      */     }
/* 1343 */     if (cch == 0) {
/*      */       
/* 1345 */       this._locale._offSrc = 0;
/* 1346 */       this._locale._cchSrc = 0;
/*      */       
/* 1348 */       return null;
/*      */     } 
/*      */     
/* 1351 */     return getCharsHelper(pos, cch);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Object getCharsHelper(int pos, int cch) {
/*      */     Object src;
/* 1358 */     assert cch > 0 && cchRight(pos) >= cch;
/*      */     
/* 1360 */     int pa = posAfter();
/*      */ 
/*      */ 
/*      */     
/* 1364 */     if (pos >= pa) {
/*      */       
/* 1366 */       src = this._srcAfter;
/* 1367 */       this._locale._offSrc = this._offAfter + pos - pa;
/*      */     }
/*      */     else {
/*      */       
/* 1371 */       src = this._srcValue;
/* 1372 */       this._locale._offSrc = this._offValue + pos - 1;
/*      */     } 
/*      */     
/* 1375 */     this._locale._cchSrc = cch;
/*      */     
/* 1377 */     return src;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setBit(int mask) {
/* 1384 */     this._bits |= mask; } final void clearBit(int mask) {
/* 1385 */     this._bits &= mask ^ 0xFFFFFFFF;
/*      */   }
/* 1387 */   final boolean bitIsSet(int mask) { return ((this._bits & mask) != 0); } final boolean bitIsClear(int mask) {
/* 1388 */     return ((this._bits & mask) == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isVacant() {
/* 1394 */     return bitIsSet(256);
/* 1395 */   } final boolean isOccupied() { return bitIsClear(256); } final boolean inhibitDisconnect() {
/* 1396 */     return bitIsSet(1024);
/*      */   } final boolean isStableUser() {
/* 1398 */     return bitIsSet(512);
/*      */   }
/*      */   
/*      */   void invalidateNil() {
/* 1402 */     if (this._user != null) {
/* 1403 */       this._user.invalidate_nilvalue();
/*      */     }
/*      */   }
/*      */   
/*      */   void setStableType(SchemaType type) {
/* 1408 */     setStableUser(((TypeStoreUserFactory)type).createTypeStoreUser());
/*      */   }
/*      */ 
/*      */   
/*      */   void setStableUser(TypeStoreUser user) {
/* 1413 */     disconnectNonRootUsers();
/* 1414 */     disconnectUser();
/*      */     
/* 1416 */     assert this._user == null;
/*      */     
/* 1418 */     this._user = user;
/*      */     
/* 1420 */     this._user.attach_store(this);
/*      */     
/* 1422 */     setBit(512);
/*      */   }
/*      */ 
/*      */   
/*      */   void disconnectUser() {
/* 1427 */     if (this._user != null && !inhibitDisconnect()) {
/*      */       
/* 1429 */       ensureOccupancy();
/* 1430 */       this._user.disconnect_store();
/* 1431 */       this._user = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disconnectNonRootUsers() {
/* 1443 */     for (Xobj x = this; x != null; x = next) {
/*      */       
/* 1445 */       Xobj next = x.walk(this, (x._user != null));
/*      */       
/* 1447 */       if (!x.isRoot()) {
/* 1448 */         x.disconnectUser();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void disconnectChildrenUsers() {
/* 1456 */     for (Xobj x = walk(this, (this._user == null)); x != null; x = next) {
/*      */       
/* 1458 */       Xobj next = x.walk(this, (x._user != null));
/*      */       
/* 1460 */       x.disconnectUser();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final String namespaceForPrefix(String prefix, boolean defaultAlwaysMapped) {
/* 1490 */     if (prefix == null) {
/* 1491 */       prefix = "";
/*      */     }
/*      */ 
/*      */     
/* 1495 */     if (prefix.equals("xml")) {
/* 1496 */       return "http://www.w3.org/XML/1998/namespace";
/*      */     }
/* 1498 */     if (prefix.equals("xmlns")) {
/* 1499 */       return "http://www.w3.org/2000/xmlns/";
/*      */     }
/* 1501 */     for (Xobj x = this; x != null; x = x._parent) {
/* 1502 */       for (Xobj a = x._firstChild; a != null && a.isAttr(); a = a._nextSibling) {
/* 1503 */         if (a.isXmlns() && a.getXmlnsPrefix().equals(prefix))
/* 1504 */           return a.getXmlnsUri(); 
/*      */       } 
/* 1506 */     }  return (defaultAlwaysMapped && prefix.length() == 0) ? "" : null;
/*      */   }
/*      */ 
/*      */   
/*      */   final String prefixForNamespace(String ns, String suggestion, boolean createIfMissing) {
/* 1511 */     if (ns == null) {
/* 1512 */       ns = "";
/*      */     }
/*      */ 
/*      */     
/* 1516 */     if (ns.equals("http://www.w3.org/XML/1998/namespace")) {
/* 1517 */       return "xml";
/*      */     }
/* 1519 */     if (ns.equals("http://www.w3.org/2000/xmlns/")) {
/* 1520 */       return "xmlns";
/*      */     }
/*      */ 
/*      */     
/* 1524 */     Xobj base = this;
/*      */     
/* 1526 */     while (!base.isContainer()) {
/* 1527 */       base = base.ensureParent();
/*      */     }
/*      */ 
/*      */     
/* 1531 */     if (ns.length() == 0) {
/*      */ 
/*      */ 
/*      */       
/* 1535 */       Xobj a = base.findXmlnsForPrefix("");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1540 */       if (a == null || a.getXmlnsUri().length() == 0) {
/* 1541 */         return "";
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1546 */       if (!createIfMissing) {
/* 1547 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1551 */       base.setAttr(this._locale.createXmlns(null), "");
/*      */       
/* 1553 */       return "";
/*      */     } 
/*      */     
/*      */     Xobj c;
/*      */     
/* 1558 */     for (c = base; c != null; c = c._parent) {
/* 1559 */       for (Xobj a = c.firstAttr(); a != null; a = a.nextAttr()) {
/* 1560 */         if (a.isXmlns() && a.getXmlnsUri().equals(ns) && 
/* 1561 */           base.findXmlnsForPrefix(a.getXmlnsPrefix()) == a) {
/* 1562 */           return a.getXmlnsPrefix();
/*      */         }
/*      */       } 
/*      */     } 
/* 1566 */     if (!createIfMissing) {
/* 1567 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1571 */     if (suggestion != null && (suggestion.length() == 0 || suggestion.toLowerCase().startsWith("xml") || base.findXmlnsForPrefix(suggestion) != null))
/*      */     {
/*      */ 
/*      */       
/* 1575 */       suggestion = null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1580 */     if (suggestion == null) {
/*      */       
/* 1582 */       String prefixBase = QNameHelper.suggestPrefix(ns);
/*      */       
/* 1584 */       suggestion = prefixBase;
/*      */       
/* 1586 */       int i = 1;
/* 1587 */       while (base.findXmlnsForPrefix(suggestion) != null) {
/*      */         suggestion = prefixBase + i++;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1593 */     c = base;
/*      */     
/* 1595 */     while (!c.isRoot() && !c.ensureParent().isRoot()) {
/* 1596 */       c = c._parent;
/*      */     }
/* 1598 */     base.setAttr(this._locale.createXmlns(suggestion), ns);
/*      */     
/* 1600 */     return suggestion;
/*      */   }
/*      */   
/*      */   final QName getValueAsQName() {
/*      */     String prefix, localname;
/* 1605 */     assert !hasChildren();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1613 */     String value = getValueAsString(3);
/*      */ 
/*      */ 
/*      */     
/* 1617 */     int firstcolon = value.indexOf(':');
/*      */     
/* 1619 */     if (firstcolon >= 0) {
/*      */       
/* 1621 */       prefix = value.substring(0, firstcolon);
/* 1622 */       localname = value.substring(firstcolon + 1);
/*      */     }
/*      */     else {
/*      */       
/* 1626 */       prefix = "";
/* 1627 */       localname = value;
/*      */     } 
/*      */     
/* 1630 */     String uri = namespaceForPrefix(prefix, true);
/*      */     
/* 1632 */     if (uri == null) {
/* 1633 */       return null;
/*      */     }
/* 1635 */     return new QName(uri, localname);
/*      */   }
/*      */ 
/*      */   
/*      */   final Xobj getAttr(QName name) {
/* 1640 */     for (Xobj x = this._firstChild; x != null && x.isAttr(); x = x._nextSibling) {
/* 1641 */       if (x._name.equals(name))
/* 1642 */         return x; 
/*      */     } 
/* 1644 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   final QName getXsiTypeName() {
/* 1649 */     assert isContainer();
/*      */     
/* 1651 */     Xobj a = getAttr(Locale._xsiType);
/*      */     
/* 1653 */     return (a == null) ? null : a.getValueAsQName();
/*      */   }
/*      */ 
/*      */   
/*      */   final XmlObject getObject() {
/* 1658 */     return isUserNode() ? (XmlObject)getUser() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   final TypeStoreUser getUser() {
/* 1663 */     assert isUserNode();
/* 1664 */     assert this._user != null || (!isRoot() && !isStableUser());
/*      */     
/* 1666 */     if (this._user == null) {
/*      */ 
/*      */ 
/*      */       
/* 1670 */       TypeStoreUser parentUser = (this._parent == null) ? ((TypeStoreUserFactory)XmlBeans.NO_TYPE).createTypeStoreUser() : this._parent.getUser();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1675 */       this._user = isElem() ? parentUser.create_element_user(this._name, getXsiTypeName()) : parentUser.create_attribute_user(this._name);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1680 */       this._user.attach_store(this);
/*      */     } 
/*      */     
/* 1683 */     return this._user;
/*      */   }
/*      */ 
/*      */   
/*      */   final void invalidateUser() {
/* 1688 */     assert isValid();
/* 1689 */     assert this._user == null || isUserNode();
/*      */     
/* 1691 */     if (this._user != null) {
/* 1692 */       this._user.invalidate_value();
/*      */     }
/*      */   }
/*      */   
/*      */   final void ensureOccupancy() {
/* 1697 */     assert isValid();
/*      */     
/* 1699 */     if (isVacant()) {
/*      */       
/* 1701 */       assert isUserNode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1707 */       clearBit(256);
/*      */       
/* 1709 */       TypeStoreUser user = this._user;
/* 1710 */       this._user = null;
/*      */       
/* 1712 */       String value = user.build_text((NamespaceManager)this);
/*      */ 
/*      */       
/* 1715 */       long saveVersion = this._locale._versionAll;
/* 1716 */       long saveVersionSansText = this._locale._versionSansText;
/*      */ 
/*      */       
/* 1719 */       setValue(value);
/* 1720 */       assert saveVersionSansText == this._locale._versionSansText;
/*      */       
/* 1722 */       this._locale._versionAll = saveVersion;
/*      */ 
/*      */       
/* 1725 */       assert this._user == null;
/* 1726 */       this._user = user;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setValue(String val) {
/* 1731 */     assert CharUtil.isValid(val, 0, val.length());
/*      */ 
/*      */ 
/*      */     
/* 1735 */     if (val.length() <= 0) {
/*      */       return;
/*      */     }
/* 1738 */     this._locale.notifyChange();
/* 1739 */     Xobj lastAttr = lastAttr();
/* 1740 */     int startPos = 1;
/* 1741 */     Xobj charOwner = this;
/* 1742 */     if (lastAttr != null) {
/*      */       
/* 1744 */       charOwner = lastAttr;
/* 1745 */       startPos = charOwner.posAfter();
/*      */     } 
/* 1747 */     charOwner.insertCharsHelper(startPos, val, 0, val.length(), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaTypeLoader get_schematypeloader() {
/* 1755 */     return this._locale._schemaTypeLoader;
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlLocale get_locale() {
/* 1760 */     return this._locale;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get_root_object() {
/* 1766 */     return this._locale;
/*      */   }
/*      */   
/* 1769 */   public boolean is_attribute() { assert isValid(); return isAttr(); } public boolean validate_on_set() {
/* 1770 */     assert isValid(); return this._locale._validateOnSet;
/*      */   }
/*      */   
/*      */   public void invalidate_text() {
/* 1774 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 1778 */       assert isValid();
/*      */       
/* 1780 */       if (isOccupied()) {
/*      */         
/* 1782 */         if (hasTextNoEnsureOccupancy() || hasChildren()) {
/*      */           
/* 1784 */           TypeStoreUser user = this._user;
/* 1785 */           this._user = null;
/*      */           
/* 1787 */           Cur c = tempCur();
/* 1788 */           c.moveNodeContents(null, false);
/* 1789 */           c.release();
/*      */           
/* 1791 */           assert this._user == null;
/* 1792 */           this._user = user;
/*      */         } 
/*      */         
/* 1795 */         setBit(256);
/*      */       } 
/*      */       
/* 1798 */       assert isValid();
/*      */     }
/*      */     finally {
/*      */       
/* 1802 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String fetch_text(int wsr) {
/* 1808 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 1812 */       assert isValid() && isOccupied();
/*      */       
/* 1814 */       return getValueAsString(wsr);
/*      */     }
/*      */     finally {
/*      */       
/* 1818 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlCursor new_cursor() {
/* 1824 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 1828 */       Cur c = tempCur();
/* 1829 */       XmlCursor xc = new Cursor(c);
/* 1830 */       c.release();
/* 1831 */       return xc;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1836 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaField get_schema_field() {
/* 1842 */     assert isValid();
/*      */     
/* 1844 */     if (isRoot()) {
/* 1845 */       return null;
/*      */     }
/* 1847 */     TypeStoreUser parentUser = ensureParent().getUser();
/*      */     
/* 1849 */     if (isAttr()) {
/* 1850 */       return parentUser.get_attribute_field(this._name);
/*      */     }
/* 1852 */     assert isElem();
/*      */     
/* 1854 */     TypeStoreVisitor visitor = parentUser.new_visitor();
/*      */     
/* 1856 */     if (visitor == null) {
/* 1857 */       return null;
/*      */     }
/* 1859 */     for (Xobj x = this._parent._firstChild;; x = x._nextSibling) {
/*      */       
/* 1861 */       if (x.isElem()) {
/*      */         
/* 1863 */         visitor.visit(x._name);
/*      */         
/* 1865 */         if (x == this) {
/* 1866 */           return visitor.get_schema_field();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void validate(ValidatorListener eventSink) {
/* 1873 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 1877 */       Cur c = tempCur();
/* 1878 */       Validate validate = new Validate(c, eventSink);
/* 1879 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 1883 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser change_type(SchemaType type) {
/* 1889 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 1893 */       Cur c = tempCur();
/* 1894 */       c.setType(type, false);
/* 1895 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 1899 */       this._locale.exit();
/*      */     } 
/*      */     
/* 1902 */     return getUser();
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser substitute(QName name, SchemaType type) {
/* 1907 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 1911 */       Cur c = tempCur();
/* 1912 */       c.setSubstitution(name, type, false);
/* 1913 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 1917 */       this._locale.exit();
/*      */     } 
/*      */     
/* 1920 */     return getUser();
/*      */   }
/*      */ 
/*      */   
/*      */   public QName get_xsi_type() {
/* 1925 */     return getXsiTypeName();
/*      */   }
/*      */ 
/*      */   
/*      */   public void store_text(String text) {
/* 1930 */     this._locale.enter();
/*      */     
/* 1932 */     TypeStoreUser user = this._user;
/* 1933 */     this._user = null;
/*      */ 
/*      */     
/*      */     try {
/* 1937 */       Cur c = tempCur();
/*      */       
/* 1939 */       c.moveNodeContents(null, false);
/*      */       
/* 1941 */       if (text != null && text.length() > 0) {
/*      */         
/* 1943 */         c.next();
/* 1944 */         c.insertString(text);
/*      */       } 
/*      */       
/* 1947 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 1951 */       assert this._user == null;
/* 1952 */       this._user = user;
/*      */       
/* 1954 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int compute_flags() {
/* 1960 */     if (isRoot()) {
/* 1961 */       return 0;
/*      */     }
/* 1963 */     TypeStoreUser parentUser = ensureParent().getUser();
/*      */     
/* 1965 */     if (isAttr()) {
/* 1966 */       return parentUser.get_attributeflags(this._name);
/*      */     }
/* 1968 */     int f = parentUser.get_elementflags(this._name);
/*      */     
/* 1970 */     if (f != -1) {
/* 1971 */       return f;
/*      */     }
/* 1973 */     TypeStoreVisitor visitor = parentUser.new_visitor();
/*      */     
/* 1975 */     if (visitor == null) {
/* 1976 */       return 0;
/*      */     }
/* 1978 */     for (Xobj x = this._parent._firstChild;; x = x._nextSibling) {
/*      */       
/* 1980 */       if (x.isElem()) {
/*      */         
/* 1982 */         visitor.visit(x._name);
/*      */         
/* 1984 */         if (x == this) {
/* 1985 */           return visitor.get_elementflags();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public String compute_default_text() {
/* 1992 */     if (isRoot()) {
/* 1993 */       return null;
/*      */     }
/* 1995 */     TypeStoreUser parentUser = ensureParent().getUser();
/*      */     
/* 1997 */     if (isAttr()) {
/* 1998 */       return parentUser.get_default_attribute_text(this._name);
/*      */     }
/* 2000 */     String result = parentUser.get_default_element_text(this._name);
/*      */     
/* 2002 */     if (result != null) {
/* 2003 */       return result;
/*      */     }
/* 2005 */     TypeStoreVisitor visitor = parentUser.new_visitor();
/*      */     
/* 2007 */     if (visitor == null) {
/* 2008 */       return null;
/*      */     }
/* 2010 */     for (Xobj x = this._parent._firstChild;; x = x._nextSibling) {
/*      */       
/* 2012 */       if (x.isElem()) {
/*      */         
/* 2014 */         visitor.visit(x._name);
/*      */         
/* 2016 */         if (x == this) {
/* 2017 */           return visitor.get_default_text();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean find_nil() {
/* 2024 */     if (isAttr()) {
/* 2025 */       return false;
/*      */     }
/* 2027 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2031 */       Xobj a = getAttr(Locale._xsiNil);
/*      */       
/* 2033 */       if (a == null) {
/* 2034 */         return false;
/*      */       }
/* 2036 */       String value = a.getValueAsString(3);
/*      */       
/* 2038 */       return (value.equals("true") || value.equals("1"));
/*      */     }
/*      */     finally {
/*      */       
/* 2042 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void invalidate_nil() {
/* 2048 */     if (isAttr()) {
/*      */       return;
/*      */     }
/* 2051 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2055 */       if (!this._user.build_nil()) {
/* 2056 */         removeAttr(Locale._xsiNil);
/*      */       } else {
/* 2058 */         setAttr(Locale._xsiNil, "true");
/*      */       } 
/*      */     } finally {
/*      */       
/* 2062 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int count_elements(QName name) {
/* 2068 */     return this._locale.count(this, name, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public int count_elements(QNameSet names) {
/* 2073 */     return this._locale.count(this, null, names);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser find_element_user(QName name, int i) {
/* 2078 */     for (Xobj x = this._firstChild; x != null; x = x._nextSibling) {
/* 2079 */       if (x.isElem() && x._name.equals(name) && --i < 0)
/* 2080 */         return x.getUser(); 
/*      */     } 
/* 2082 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser find_element_user(QNameSet names, int i) {
/* 2087 */     for (Xobj x = this._firstChild; x != null; x = x._nextSibling) {
/* 2088 */       if (x.isElem() && names.contains(x._name) && --i < 0)
/* 2089 */         return x.getUser(); 
/*      */     } 
/* 2091 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void find_all_element_users(QName name, List fillMeUp) {
/* 2096 */     for (Xobj x = this._firstChild; x != null; x = x._nextSibling) {
/* 2097 */       if (x.isElem() && x._name.equals(name))
/* 2098 */         fillMeUp.add(x.getUser()); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void find_all_element_users(QNameSet names, List fillMeUp) {
/* 2103 */     for (Xobj x = this._firstChild; x != null; x = x._nextSibling) {
/* 2104 */       if (x.isElem() && names.contains(x._name))
/* 2105 */         fillMeUp.add(x.getUser()); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static TypeStoreUser insertElement(QName name, Xobj x, int pos) {
/* 2110 */     x._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2114 */       Cur c = x._locale.tempCur();
/* 2115 */       c.moveTo(x, pos);
/* 2116 */       c.createElement(name);
/* 2117 */       TypeStoreUser user = c.getUser();
/* 2118 */       c.release();
/* 2119 */       return user;
/*      */     }
/*      */     finally {
/*      */       
/* 2123 */       x._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser insert_element_user(QName name, int i) {
/* 2129 */     if (i < 0) {
/* 2130 */       throw new IndexOutOfBoundsException();
/*      */     }
/* 2132 */     if (!isContainer()) {
/* 2133 */       throw new IllegalStateException();
/*      */     }
/* 2135 */     Xobj x = this._locale.findNthChildElem(this, name, null, i);
/*      */     
/* 2137 */     if (x == null) {
/*      */       
/* 2139 */       if (i > this._locale.count(this, name, null) + 1) {
/* 2140 */         throw new IndexOutOfBoundsException();
/*      */       }
/* 2142 */       return add_element_user(name);
/*      */     } 
/*      */     
/* 2145 */     return insertElement(name, x, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser insert_element_user(QNameSet names, QName name, int i) {
/* 2150 */     if (i < 0) {
/* 2151 */       throw new IndexOutOfBoundsException();
/*      */     }
/* 2153 */     if (!isContainer()) {
/* 2154 */       throw new IllegalStateException();
/*      */     }
/* 2156 */     Xobj x = this._locale.findNthChildElem(this, null, names, i);
/*      */     
/* 2158 */     if (x == null) {
/*      */       
/* 2160 */       if (i > this._locale.count(this, null, names) + 1) {
/* 2161 */         throw new IndexOutOfBoundsException();
/*      */       }
/* 2163 */       return add_element_user(name);
/*      */     } 
/*      */     
/* 2166 */     return insertElement(name, x, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser add_element_user(QName name) {
/* 2171 */     if (!isContainer()) {
/* 2172 */       throw new IllegalStateException();
/*      */     }
/* 2174 */     QNameSet endSet = null;
/* 2175 */     boolean gotEndSet = false;
/*      */     
/* 2177 */     Xobj candidate = null;
/*      */     
/* 2179 */     for (Xobj x = this._lastChild; x != null; x = x._prevSibling) {
/*      */       
/* 2181 */       if (x.isContainer()) {
/*      */         
/* 2183 */         if (x._name.equals(name)) {
/*      */           break;
/*      */         }
/* 2186 */         if (!gotEndSet) {
/*      */           
/* 2188 */           endSet = this._user.get_element_ending_delimiters(name);
/* 2189 */           gotEndSet = true;
/*      */         } 
/*      */         
/* 2192 */         if (endSet == null || endSet.contains(x._name)) {
/* 2193 */           candidate = x;
/*      */         }
/*      */       } 
/*      */     } 
/* 2197 */     return (candidate == null) ? insertElement(name, this, -1) : insertElement(name, candidate, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void removeElement(Xobj x) {
/* 2205 */     if (x == null) {
/* 2206 */       throw new IndexOutOfBoundsException();
/*      */     }
/* 2208 */     x._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2212 */       Cur c = x.tempCur();
/* 2213 */       c.moveNode(null);
/* 2214 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 2218 */       x._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void remove_element(QName name, int i) {
/* 2224 */     if (i < 0) {
/* 2225 */       throw new IndexOutOfBoundsException();
/*      */     }
/* 2227 */     if (!isContainer()) {
/* 2228 */       throw new IllegalStateException();
/*      */     }
/*      */     
/*      */     Xobj x;
/* 2232 */     for (x = this._firstChild; x != null && (
/* 2233 */       !x.isElem() || !x._name.equals(name) || --i >= 0); x = x._nextSibling);
/*      */ 
/*      */     
/* 2236 */     removeElement(x);
/*      */   }
/*      */ 
/*      */   
/*      */   public void remove_element(QNameSet names, int i) {
/* 2241 */     if (i < 0) {
/* 2242 */       throw new IndexOutOfBoundsException();
/*      */     }
/* 2244 */     if (!isContainer()) {
/* 2245 */       throw new IllegalStateException();
/*      */     }
/*      */     
/*      */     Xobj x;
/* 2249 */     for (x = this._firstChild; x != null && (
/* 2250 */       !x.isElem() || !names.contains(x._name) || --i >= 0); x = x._nextSibling);
/*      */ 
/*      */     
/* 2253 */     removeElement(x);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser find_attribute_user(QName name) {
/* 2258 */     Xobj a = getAttr(name);
/*      */     
/* 2260 */     return (a == null) ? null : a.getUser();
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser add_attribute_user(QName name) {
/* 2265 */     if (getAttr(name) != null) {
/* 2266 */       throw new IndexOutOfBoundsException();
/*      */     }
/* 2268 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2272 */       return setAttr(name, "").getUser();
/*      */     }
/*      */     finally {
/*      */       
/* 2276 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void remove_attribute(QName name) {
/* 2282 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2286 */       if (!removeAttr(name)) {
/* 2287 */         throw new IndexOutOfBoundsException();
/*      */       }
/*      */     } finally {
/*      */       
/* 2291 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeStoreUser copy_contents_from(TypeStore source) {
/* 2297 */     Xobj xSrc = (Xobj)source;
/*      */     
/* 2299 */     if (xSrc == this) {
/* 2300 */       return getUser();
/*      */     }
/* 2302 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2306 */       xSrc._locale.enter();
/*      */       
/* 2308 */       Cur c = tempCur();
/*      */ 
/*      */       
/*      */       try {
/* 2312 */         Cur cSrc1 = xSrc.tempCur();
/* 2313 */         Map sourceNamespaces = Locale.getAllNamespaces(cSrc1, null);
/* 2314 */         cSrc1.release();
/*      */         
/* 2316 */         if (isAttr()) {
/*      */           
/* 2318 */           Cur cSrc = xSrc.tempCur();
/* 2319 */           String value = Locale.getTextValue(cSrc);
/* 2320 */           cSrc.release();
/*      */           
/* 2322 */           c.setValue(value);
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 2329 */           disconnectChildrenUsers();
/*      */           
/* 2331 */           assert !inhibitDisconnect();
/*      */           
/* 2333 */           setBit(1024);
/*      */           
/* 2335 */           QName xsiType = isContainer() ? getXsiTypeName() : null;
/*      */           
/* 2337 */           Xobj copy = xSrc.copyNode(this._locale);
/*      */           
/* 2339 */           Cur.moveNodeContents(this, null, true);
/*      */           
/* 2341 */           c.next();
/*      */           
/* 2343 */           Cur.moveNodeContents(copy, c, true);
/*      */           
/* 2345 */           c.moveTo(this);
/*      */           
/* 2347 */           if (xsiType != null) {
/* 2348 */             c.setXsiType(xsiType);
/*      */           }
/* 2350 */           assert inhibitDisconnect();
/* 2351 */           clearBit(1024);
/*      */         } 
/*      */         
/* 2354 */         if (sourceNamespaces != null)
/*      */         {
/* 2356 */           if (!c.isContainer()) {
/* 2357 */             c.toParent();
/*      */           }
/* 2359 */           Locale.applyNamespaces(c, sourceNamespaces);
/*      */         }
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/* 2365 */         c.release();
/*      */         
/* 2367 */         xSrc._locale.exit();
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 2372 */       this._locale.exit();
/*      */     } 
/*      */     
/* 2375 */     return getUser();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeStoreUser copy(SchemaTypeLoader stl, SchemaType type, XmlOptions options) {
/* 2382 */     Xobj destination = null;
/* 2383 */     options = XmlOptions.maskNull(options);
/* 2384 */     SchemaType sType = (SchemaType)options.get("DOCUMENT_TYPE");
/*      */     
/* 2386 */     if (sType == null) {
/* 2387 */       sType = (type == null) ? XmlObject.type : type;
/*      */     }
/* 2389 */     Locale locale = locale();
/* 2390 */     if (Boolean.TRUE.equals(options.get("COPY_USE_NEW_LOCALE"))) {
/* 2391 */       locale = Locale.getLocale(stl, options);
/*      */     }
/* 2393 */     if (sType.isDocumentType() || (sType.isNoType() && this instanceof DocumentXobj)) {
/* 2394 */       destination = Cur.createDomDocumentRootXobj(locale, false);
/*      */     } else {
/* 2396 */       destination = Cur.createDomDocumentRootXobj(locale, true);
/*      */     } 
/*      */     
/* 2399 */     locale.enter();
/*      */     
/*      */     try {
/* 2402 */       Cur c = destination.tempCur();
/* 2403 */       c.setType(type);
/* 2404 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 2408 */       locale.exit();
/*      */     } 
/*      */     
/* 2411 */     TypeStoreUser tsu = destination.copy_contents_from(this);
/* 2412 */     return tsu;
/*      */   }
/*      */ 
/*      */   
/*      */   public void array_setter(XmlObject[] sources, QName elementName) {
/* 2417 */     this._locale.enter();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2423 */       int m = sources.length;
/*      */       
/* 2425 */       ArrayList copies = new ArrayList();
/* 2426 */       ArrayList types = new ArrayList();
/*      */       
/* 2428 */       for (int i = 0; i < m; i++) {
/*      */ 
/*      */ 
/*      */         
/* 2432 */         if (sources[i] == null) {
/* 2433 */           throw new IllegalArgumentException("Array element null");
/*      */         }
/* 2435 */         if (sources[i].isImmutable()) {
/*      */           
/* 2437 */           copies.add(null);
/* 2438 */           types.add(null);
/*      */         }
/*      */         else {
/*      */           
/* 2442 */           Xobj x = (Xobj)((TypeStoreUser)sources[i]).get_store();
/*      */           
/* 2444 */           if (x._locale == this._locale) {
/* 2445 */             copies.add(x.copyNode(this._locale));
/*      */           } else {
/*      */             
/* 2448 */             x._locale.enter();
/*      */ 
/*      */             
/*      */             try {
/* 2452 */               copies.add(x.copyNode(this._locale));
/*      */             }
/*      */             finally {
/*      */               
/* 2456 */               x._locale.exit();
/*      */             } 
/*      */           } 
/*      */           
/* 2460 */           types.add(sources[i].schemaType());
/*      */         } 
/*      */       } 
/*      */       
/* 2464 */       int n = count_elements(elementName);
/*      */       
/* 2466 */       for (; n > m; n--) {
/* 2467 */         remove_element(elementName, m);
/*      */       }
/* 2469 */       for (; m > n; n++) {
/* 2470 */         add_element_user(elementName);
/*      */       }
/* 2472 */       assert m == n;
/*      */       
/* 2474 */       ArrayList elements = new ArrayList();
/*      */       
/* 2476 */       find_all_element_users(elementName, elements);
/*      */       
/* 2478 */       for (int j = 0; j < elements.size(); j++) {
/* 2479 */         elements.set(j, (Xobj)((TypeStoreUser)elements.get(j)).get_store());
/*      */       }
/* 2481 */       assert elements.size() == n;
/*      */       
/* 2483 */       Cur c = tempCur();
/*      */       
/* 2485 */       for (int k = 0; k < n; k++) {
/*      */         
/* 2487 */         Xobj x = elements.get(k);
/*      */         
/* 2489 */         if (sources[k].isImmutable()) {
/* 2490 */           x.getObject().set(sources[k]);
/*      */         } else {
/*      */           
/* 2493 */           Cur.moveNodeContents(x, null, true);
/*      */           
/* 2495 */           c.moveTo(x);
/* 2496 */           c.next();
/*      */           
/* 2498 */           Cur.moveNodeContents(copies.get(k), c, true);
/*      */           
/* 2500 */           x.change_type(types.get(k));
/*      */         } 
/*      */       } 
/*      */       
/* 2504 */       c.release();
/*      */     }
/*      */     finally {
/*      */       
/* 2508 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void visit_elements(TypeStoreVisitor visitor) {
/* 2514 */     throw new RuntimeException("Not implemeneted");
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlObject[] exec_query(String queryExpr, XmlOptions options) throws XmlException {
/* 2519 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2523 */       Cur c = tempCur();
/*      */       
/* 2525 */       XmlObject[] result = Query.objectExecQuery(c, queryExpr, options);
/*      */       
/* 2527 */       c.release();
/*      */       
/* 2529 */       return result;
/*      */     }
/*      */     finally {
/*      */       
/* 2533 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String find_prefix_for_nsuri(String nsuri, String suggested_prefix) {
/* 2539 */     this._locale.enter();
/*      */ 
/*      */     
/*      */     try {
/* 2543 */       return prefixForNamespace(nsuri, suggested_prefix, true);
/*      */     }
/*      */     finally {
/*      */       
/* 2547 */       this._locale.exit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNamespaceForPrefix(String prefix) {
/* 2553 */     return namespaceForPrefix(prefix, true);
/*      */   }
/*      */   
/*      */   abstract DomImpl.Dom getDom();
/*      */   
/*      */   abstract Xobj newNode(Locale paramLocale);
/*      */   
/*      */   static abstract class NodeXobj
/*      */     extends Xobj
/*      */     implements DomImpl.Dom, Node, NodeList {
/*      */     NodeXobj(Locale l, int kind, int domType) {
/* 2564 */       super(l, kind, domType);
/*      */     }
/*      */     DomImpl.Dom getDom() {
/* 2567 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int getLength() {
/* 2573 */       return DomImpl._childNodes_getLength(this); } public Node item(int i) {
/* 2574 */       return DomImpl._childNodes_item(this, i);
/*      */     }
/* 2576 */     public Node appendChild(Node newChild) { return DomImpl._node_appendChild(this, newChild); }
/* 2577 */     public Node cloneNode(boolean deep) { return DomImpl._node_cloneNode(this, deep); }
/* 2578 */     public NamedNodeMap getAttributes() { return null; }
/* 2579 */     public NodeList getChildNodes() { return this; }
/* 2580 */     public Node getParentNode() { return DomImpl._node_getParentNode(this); }
/* 2581 */     public Node removeChild(Node oldChild) { return DomImpl._node_removeChild(this, oldChild); }
/* 2582 */     public Node getFirstChild() { return DomImpl._node_getFirstChild(this); }
/* 2583 */     public Node getLastChild() { return DomImpl._node_getLastChild(this); }
/* 2584 */     public String getLocalName() { return DomImpl._node_getLocalName(this); }
/* 2585 */     public String getNamespaceURI() { return DomImpl._node_getNamespaceURI(this); }
/* 2586 */     public Node getNextSibling() { return DomImpl._node_getNextSibling(this); }
/* 2587 */     public String getNodeName() { return DomImpl._node_getNodeName(this); }
/* 2588 */     public short getNodeType() { return DomImpl._node_getNodeType(this); }
/* 2589 */     public String getNodeValue() { return DomImpl._node_getNodeValue(this); }
/* 2590 */     public Document getOwnerDocument() { return DomImpl._node_getOwnerDocument(this); }
/* 2591 */     public String getPrefix() { return DomImpl._node_getPrefix(this); }
/* 2592 */     public Node getPreviousSibling() { return DomImpl._node_getPreviousSibling(this); }
/* 2593 */     public boolean hasAttributes() { return DomImpl._node_hasAttributes(this); }
/* 2594 */     public boolean hasChildNodes() { return DomImpl._node_hasChildNodes(this); }
/* 2595 */     public Node insertBefore(Node newChild, Node refChild) { return DomImpl._node_insertBefore(this, newChild, refChild); }
/* 2596 */     public boolean isSupported(String feature, String version) { return DomImpl._node_isSupported(this, feature, version); }
/* 2597 */     public void normalize() { DomImpl._node_normalize(this); }
/* 2598 */     public Node replaceChild(Node newChild, Node oldChild) { return DomImpl._node_replaceChild(this, newChild, oldChild); }
/* 2599 */     public void setNodeValue(String nodeValue) { DomImpl._node_setNodeValue(this, nodeValue); }
/* 2600 */     public void setPrefix(String prefix) { DomImpl._node_setPrefix(this, prefix); } public boolean nodeCanHavePrefixUri() {
/* 2601 */       return false;
/*      */     }
/*      */     
/* 2604 */     public Object getUserData(String key) { return DomImpl._node_getUserData(this, key); }
/* 2605 */     public Object setUserData(String key, Object data, UserDataHandler handler) { return DomImpl._node_setUserData(this, key, data, handler); }
/* 2606 */     public Object getFeature(String feature, String version) { return DomImpl._node_getFeature(this, feature, version); }
/* 2607 */     public boolean isEqualNode(Node arg) { return DomImpl._node_isEqualNode(this, arg); }
/* 2608 */     public boolean isSameNode(Node arg) { return DomImpl._node_isSameNode(this, arg); }
/* 2609 */     public String lookupNamespaceURI(String prefix) { return DomImpl._node_lookupNamespaceURI(this, prefix); }
/* 2610 */     public String lookupPrefix(String namespaceURI) { return DomImpl._node_lookupPrefix(this, namespaceURI); }
/* 2611 */     public boolean isDefaultNamespace(String namespaceURI) { return DomImpl._node_isDefaultNamespace(this, namespaceURI); }
/* 2612 */     public void setTextContent(String textContent) { DomImpl._node_setTextContent(this, textContent); }
/* 2613 */     public String getTextContent() { return DomImpl._node_getTextContent(this); }
/* 2614 */     public short compareDocumentPosition(Node other) { return DomImpl._node_compareDocumentPosition(this, other); } public String getBaseURI() {
/* 2615 */       return DomImpl._node_getBaseURI(this);
/*      */     } }
/*      */   
/*      */   static class DocumentXobj extends NodeXobj implements Document {
/*      */     private Hashtable _idToElement;
/*      */     
/*      */     DocumentXobj(Locale l) {
/* 2622 */       super(l, 1, 9);
/*      */     }
/*      */     Xobj newNode(Locale l) {
/* 2625 */       return new DocumentXobj(l);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Attr createAttribute(String name) {
/* 2631 */       return DomImpl._document_createAttribute(this, name);
/* 2632 */     } public Attr createAttributeNS(String namespaceURI, String qualifiedName) { return DomImpl._document_createAttributeNS(this, namespaceURI, qualifiedName); }
/* 2633 */     public CDATASection createCDATASection(String data) { return DomImpl._document_createCDATASection(this, data); }
/* 2634 */     public Comment createComment(String data) { return DomImpl._document_createComment(this, data); }
/* 2635 */     public DocumentFragment createDocumentFragment() { return DomImpl._document_createDocumentFragment(this); }
/* 2636 */     public Element createElement(String tagName) { return DomImpl._document_createElement(this, tagName); }
/* 2637 */     public Element createElementNS(String namespaceURI, String qualifiedName) { return DomImpl._document_createElementNS(this, namespaceURI, qualifiedName); }
/* 2638 */     public EntityReference createEntityReference(String name) { return DomImpl._document_createEntityReference(this, name); }
/* 2639 */     public ProcessingInstruction createProcessingInstruction(String target, String data) { return DomImpl._document_createProcessingInstruction(this, target, data); }
/* 2640 */     public Text createTextNode(String data) { return DomImpl._document_createTextNode(this, data); }
/* 2641 */     public DocumentType getDoctype() { return DomImpl._document_getDoctype(this); } public Element getDocumentElement() {
/* 2642 */       return DomImpl._document_getDocumentElement(this);
/*      */     } public Element getElementById(String elementId) {
/* 2644 */       if (this._idToElement == null) return null; 
/* 2645 */       Xobj o = (Xobj)this._idToElement.get(elementId);
/* 2646 */       if (o == null) return null; 
/* 2647 */       if (!isInSameTree(o))
/*      */       {
/* 2649 */         this._idToElement.remove(elementId);
/*      */       }
/* 2651 */       return (Element)o;
/*      */     }
/* 2653 */     public NodeList getElementsByTagName(String tagname) { return DomImpl._document_getElementsByTagName(this, tagname); }
/* 2654 */     public NodeList getElementsByTagNameNS(String namespaceURI, String localName) { return DomImpl._document_getElementsByTagNameNS(this, namespaceURI, localName); }
/* 2655 */     public DOMImplementation getImplementation() { return DomImpl._document_getImplementation(this); } public Node importNode(Node importedNode, boolean deep) {
/* 2656 */       return DomImpl._document_importNode(this, importedNode, deep);
/*      */     }
/*      */     
/* 2659 */     public Node adoptNode(Node source) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2660 */     public String getDocumentURI() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2661 */     public DOMConfiguration getDomConfig() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2662 */     public String getInputEncoding() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2663 */     public boolean getStrictErrorChecking() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2664 */     public String getXmlEncoding() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2665 */     public boolean getXmlStandalone() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2666 */     public String getXmlVersion() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2667 */     public void normalizeDocument() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2668 */     public Node renameNode(Node n, String namespaceURI, String qualifiedName) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2669 */     public void setDocumentURI(String documentURI) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2670 */     public void setStrictErrorChecking(boolean strictErrorChecking) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2671 */     public void setXmlStandalone(boolean xmlStandalone) { throw new RuntimeException("DOM Level 3 Not implemented"); } public void setXmlVersion(String xmlVersion) {
/* 2672 */       throw new RuntimeException("DOM Level 3 Not implemented");
/*      */     }
/*      */     protected void addIdElement(String idVal, DomImpl.Dom e) {
/* 2675 */       if (this._idToElement == null)
/* 2676 */         this._idToElement = new Hashtable(); 
/* 2677 */       this._idToElement.put(idVal, e);
/*      */     }
/*      */     void removeIdElement(String idVal) {
/* 2680 */       if (this._idToElement != null)
/* 2681 */         this._idToElement.remove(idVal); 
/*      */     }
/*      */   }
/*      */   
/*      */   static class DocumentFragXobj extends NodeXobj implements DocumentFragment {
/*      */     DocumentFragXobj(Locale l) {
/* 2687 */       super(l, 1, 11);
/*      */     } Xobj newNode(Locale l) {
/* 2689 */       return new DocumentFragXobj(l);
/*      */     } }
/*      */   
/*      */   static final class ElementAttributes implements NamedNodeMap {
/*      */     private Xobj.ElementXobj _elementXobj;
/*      */     
/*      */     ElementAttributes(Xobj.ElementXobj elementXobj) {
/* 2696 */       this._elementXobj = elementXobj;
/*      */     }
/*      */     
/* 2699 */     public int getLength() { return DomImpl._attributes_getLength(this._elementXobj); }
/* 2700 */     public Node getNamedItem(String name) { return DomImpl._attributes_getNamedItem(this._elementXobj, name); }
/* 2701 */     public Node getNamedItemNS(String namespaceURI, String localName) { return DomImpl._attributes_getNamedItemNS(this._elementXobj, namespaceURI, localName); }
/* 2702 */     public Node item(int index) { return DomImpl._attributes_item(this._elementXobj, index); }
/* 2703 */     public Node removeNamedItem(String name) { return DomImpl._attributes_removeNamedItem(this._elementXobj, name); }
/* 2704 */     public Node removeNamedItemNS(String namespaceURI, String localName) { return DomImpl._attributes_removeNamedItemNS(this._elementXobj, namespaceURI, localName); }
/* 2705 */     public Node setNamedItem(Node arg) { return DomImpl._attributes_setNamedItem(this._elementXobj, arg); } public Node setNamedItemNS(Node arg) {
/* 2706 */       return DomImpl._attributes_setNamedItemNS(this._elementXobj, arg);
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract class NamedNodeXobj
/*      */     extends NodeXobj {
/*      */     boolean _canHavePrefixUri;
/*      */     
/*      */     NamedNodeXobj(Locale l, int kind, int domType) {
/* 2715 */       super(l, kind, domType);
/* 2716 */       this._canHavePrefixUri = true;
/*      */     }
/*      */     public boolean nodeCanHavePrefixUri() {
/* 2719 */       return this._canHavePrefixUri;
/*      */     }
/*      */   }
/*      */   
/*      */   static class ElementXobj
/*      */     extends NamedNodeXobj implements Element {
/*      */     private Xobj.ElementAttributes _attributes;
/*      */     
/*      */     ElementXobj(Locale l, QName name) {
/* 2728 */       super(l, 2, 1);
/* 2729 */       this._name = name;
/*      */     }
/*      */     Xobj newNode(Locale l) {
/* 2732 */       return new ElementXobj(l, this._name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public NamedNodeMap getAttributes() {
/* 2740 */       if (this._attributes == null) {
/* 2741 */         this._attributes = new Xobj.ElementAttributes(this);
/*      */       }
/* 2743 */       return this._attributes;
/*      */     }
/*      */     
/* 2746 */     public String getAttribute(String name) { return DomImpl._element_getAttribute(this, name); }
/* 2747 */     public Attr getAttributeNode(String name) { return DomImpl._element_getAttributeNode(this, name); }
/* 2748 */     public Attr getAttributeNodeNS(String namespaceURI, String localName) { return DomImpl._element_getAttributeNodeNS(this, namespaceURI, localName); }
/* 2749 */     public String getAttributeNS(String namespaceURI, String localName) { return DomImpl._element_getAttributeNS(this, namespaceURI, localName); }
/* 2750 */     public NodeList getElementsByTagName(String name) { return DomImpl._element_getElementsByTagName(this, name); }
/* 2751 */     public NodeList getElementsByTagNameNS(String namespaceURI, String localName) { return DomImpl._element_getElementsByTagNameNS(this, namespaceURI, localName); }
/* 2752 */     public String getTagName() { return DomImpl._element_getTagName(this); }
/* 2753 */     public boolean hasAttribute(String name) { return DomImpl._element_hasAttribute(this, name); }
/* 2754 */     public boolean hasAttributeNS(String namespaceURI, String localName) { return DomImpl._element_hasAttributeNS(this, namespaceURI, localName); }
/* 2755 */     public void removeAttribute(String name) { DomImpl._element_removeAttribute(this, name); }
/* 2756 */     public Attr removeAttributeNode(Attr oldAttr) { return DomImpl._element_removeAttributeNode(this, oldAttr); }
/* 2757 */     public void removeAttributeNS(String namespaceURI, String localName) { DomImpl._element_removeAttributeNS(this, namespaceURI, localName); }
/* 2758 */     public void setAttribute(String name, String value) { DomImpl._element_setAttribute(this, name, value); }
/* 2759 */     public Attr setAttributeNode(Attr newAttr) { return DomImpl._element_setAttributeNode(this, newAttr); }
/* 2760 */     public Attr setAttributeNodeNS(Attr newAttr) { return DomImpl._element_setAttributeNodeNS(this, newAttr); } public void setAttributeNS(String namespaceURI, String qualifiedName, String value) {
/* 2761 */       DomImpl._element_setAttributeNS(this, namespaceURI, qualifiedName, value);
/*      */     }
/*      */     
/* 2764 */     public TypeInfo getSchemaTypeInfo() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2765 */     public void setIdAttribute(String name, boolean isId) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2766 */     public void setIdAttributeNS(String namespaceURI, String localName, boolean isId) { throw new RuntimeException("DOM Level 3 Not implemented"); } public void setIdAttributeNode(Attr idAttr, boolean isId) {
/* 2767 */       throw new RuntimeException("DOM Level 3 Not implemented");
/*      */     }
/*      */   }
/*      */   
/*      */   static class AttrXobj
/*      */     extends NamedNodeXobj
/*      */     implements Attr
/*      */   {
/*      */     AttrXobj(Locale l, QName name) {
/* 2776 */       super(l, 3, 2);
/* 2777 */       this._name = name;
/*      */     }
/*      */     Xobj newNode(Locale l) {
/* 2780 */       return new AttrXobj(l, this._name);
/*      */     }
/*      */     public Node getNextSibling() {
/* 2783 */       return null;
/*      */     }
/*      */     
/* 2786 */     public String getName() { return DomImpl._node_getNodeName(this); }
/* 2787 */     public Element getOwnerElement() { return DomImpl._attr_getOwnerElement(this); }
/* 2788 */     public boolean getSpecified() { return DomImpl._attr_getSpecified(this); }
/* 2789 */     public String getValue() { return DomImpl._node_getNodeValue(this); } public void setValue(String value) {
/* 2790 */       DomImpl._node_setNodeValue(this, value);
/*      */     }
/*      */     
/* 2793 */     public TypeInfo getSchemaTypeInfo() { throw new RuntimeException("DOM Level 3 Not implemented"); } public boolean isId() {
/* 2794 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   static class AttrIdXobj
/*      */     extends AttrXobj
/*      */   {
/*      */     AttrIdXobj(Locale l, QName name) {
/* 2802 */       super(l, name);
/*      */     }
/*      */     
/*      */     public boolean isId() {
/* 2806 */       return true;
/*      */     } }
/*      */   
/*      */   static class CommentXobj extends NodeXobj implements Comment {
/*      */     CommentXobj(Locale l) {
/* 2811 */       super(l, 4, 8);
/*      */     } Xobj newNode(Locale l) {
/* 2813 */       return new CommentXobj(l);
/*      */     } public NodeList getChildNodes() {
/* 2815 */       return DomImpl._emptyNodeList;
/*      */     }
/* 2817 */     public void appendData(String arg) { DomImpl._characterData_appendData(this, arg); }
/* 2818 */     public void deleteData(int offset, int count) { DomImpl._characterData_deleteData(this, offset, count); }
/* 2819 */     public String getData() { return DomImpl._characterData_getData(this); }
/* 2820 */     public int getLength() { return DomImpl._characterData_getLength(this); }
/* 2821 */     public Node getFirstChild() { return null; }
/* 2822 */     public void insertData(int offset, String arg) { DomImpl._characterData_insertData(this, offset, arg); }
/* 2823 */     public void replaceData(int offset, int count, String arg) { DomImpl._characterData_replaceData(this, offset, count, arg); }
/* 2824 */     public void setData(String data) { DomImpl._characterData_setData(this, data); } public String substringData(int offset, int count) {
/* 2825 */       return DomImpl._characterData_substringData(this, offset, count);
/*      */     }
/*      */   }
/*      */   
/*      */   static class ProcInstXobj
/*      */     extends NodeXobj implements ProcessingInstruction {
/*      */     ProcInstXobj(Locale l, String target) {
/* 2832 */       super(l, 5, 7);
/* 2833 */       this._name = this._locale.makeQName(null, target);
/*      */     }
/*      */     Xobj newNode(Locale l) {
/* 2836 */       return new ProcInstXobj(l, this._name.getLocalPart());
/*      */     }
/* 2838 */     public int getLength() { return 0; } public Node getFirstChild() {
/* 2839 */       return null;
/*      */     }
/* 2841 */     public String getData() { return DomImpl._processingInstruction_getData(this); }
/* 2842 */     public String getTarget() { return DomImpl._processingInstruction_getTarget(this); } public void setData(String data) {
/* 2843 */       DomImpl._processingInstruction_setData(this, data);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class SoapPartDocXobj
/*      */     extends DocumentXobj
/*      */   {
/*      */     Xobj.SoapPartDom _soapPartDom;
/*      */     
/*      */     SoapPartDocXobj(Locale l) {
/* 2854 */       super(l);
/*      */       
/* 2856 */       this._soapPartDom = new Xobj.SoapPartDom(this);
/*      */     }
/*      */     DomImpl.Dom getDom() {
/* 2859 */       return this._soapPartDom;
/*      */     } Xobj newNode(Locale l) {
/* 2861 */       return new SoapPartDocXobj(l);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SoapPartDom
/*      */     extends SOAPPart implements DomImpl.Dom, Document, NodeList {
/*      */     Xobj.SoapPartDocXobj _docXobj;
/*      */     
/*      */     SoapPartDom(Xobj.SoapPartDocXobj docXobj) {
/* 2870 */       this._docXobj = docXobj;
/*      */     }
/*      */     
/* 2873 */     public int nodeType() { return 9; }
/* 2874 */     public Locale locale() { return this._docXobj._locale; }
/* 2875 */     public Cur tempCur() { return this._docXobj.tempCur(); } public QName getQName() {
/* 2876 */       return this._docXobj._name;
/*      */     }
/* 2878 */     public void dump() { dump(System.out); }
/* 2879 */     public void dump(PrintStream o) { this._docXobj.dump(o); } public void dump(PrintStream o, Object ref) {
/* 2880 */       this._docXobj.dump(o, ref);
/*      */     } public String name() {
/* 2882 */       return "#document";
/*      */     }
/* 2884 */     public Node appendChild(Node newChild) { return DomImpl._node_appendChild(this, newChild); }
/* 2885 */     public Node cloneNode(boolean deep) { return DomImpl._node_cloneNode(this, deep); }
/* 2886 */     public NamedNodeMap getAttributes() { return null; }
/* 2887 */     public NodeList getChildNodes() { return this; }
/* 2888 */     public Node getParentNode() { return DomImpl._node_getParentNode(this); }
/* 2889 */     public Node removeChild(Node oldChild) { return DomImpl._node_removeChild(this, oldChild); }
/* 2890 */     public Node getFirstChild() { return DomImpl._node_getFirstChild(this); }
/* 2891 */     public Node getLastChild() { return DomImpl._node_getLastChild(this); }
/* 2892 */     public String getLocalName() { return DomImpl._node_getLocalName(this); }
/* 2893 */     public String getNamespaceURI() { return DomImpl._node_getNamespaceURI(this); }
/* 2894 */     public Node getNextSibling() { return DomImpl._node_getNextSibling(this); }
/* 2895 */     public String getNodeName() { return DomImpl._node_getNodeName(this); }
/* 2896 */     public short getNodeType() { return DomImpl._node_getNodeType(this); }
/* 2897 */     public String getNodeValue() { return DomImpl._node_getNodeValue(this); }
/* 2898 */     public Document getOwnerDocument() { return DomImpl._node_getOwnerDocument(this); }
/* 2899 */     public String getPrefix() { return DomImpl._node_getPrefix(this); }
/* 2900 */     public Node getPreviousSibling() { return DomImpl._node_getPreviousSibling(this); }
/* 2901 */     public boolean hasAttributes() { return DomImpl._node_hasAttributes(this); }
/* 2902 */     public boolean hasChildNodes() { return DomImpl._node_hasChildNodes(this); }
/* 2903 */     public Node insertBefore(Node newChild, Node refChild) { return DomImpl._node_insertBefore(this, newChild, refChild); }
/* 2904 */     public boolean isSupported(String feature, String version) { return DomImpl._node_isSupported(this, feature, version); }
/* 2905 */     public void normalize() { DomImpl._node_normalize(this); }
/* 2906 */     public Node replaceChild(Node newChild, Node oldChild) { return DomImpl._node_replaceChild(this, newChild, oldChild); }
/* 2907 */     public void setNodeValue(String nodeValue) { DomImpl._node_setNodeValue(this, nodeValue); } public void setPrefix(String prefix) {
/* 2908 */       DomImpl._node_setPrefix(this, prefix);
/*      */     }
/*      */     
/* 2911 */     public Object getUserData(String key) { return DomImpl._node_getUserData(this, key); }
/* 2912 */     public Object setUserData(String key, Object data, UserDataHandler handler) { return DomImpl._node_setUserData(this, key, data, handler); }
/* 2913 */     public Object getFeature(String feature, String version) { return DomImpl._node_getFeature(this, feature, version); }
/* 2914 */     public boolean isEqualNode(Node arg) { return DomImpl._node_isEqualNode(this, arg); }
/* 2915 */     public boolean isSameNode(Node arg) { return DomImpl._node_isSameNode(this, arg); }
/* 2916 */     public String lookupNamespaceURI(String prefix) { return DomImpl._node_lookupNamespaceURI(this, prefix); }
/* 2917 */     public String lookupPrefix(String namespaceURI) { return DomImpl._node_lookupPrefix(this, namespaceURI); }
/* 2918 */     public boolean isDefaultNamespace(String namespaceURI) { return DomImpl._node_isDefaultNamespace(this, namespaceURI); }
/* 2919 */     public void setTextContent(String textContent) { DomImpl._node_setTextContent(this, textContent); }
/* 2920 */     public String getTextContent() { return DomImpl._node_getTextContent(this); }
/* 2921 */     public short compareDocumentPosition(Node other) { return DomImpl._node_compareDocumentPosition(this, other); }
/* 2922 */     public String getBaseURI() { return DomImpl._node_getBaseURI(this); }
/* 2923 */     public Node adoptNode(Node source) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2924 */     public String getDocumentURI() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2925 */     public DOMConfiguration getDomConfig() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2926 */     public String getInputEncoding() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2927 */     public boolean getStrictErrorChecking() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2928 */     public String getXmlEncoding() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2929 */     public boolean getXmlStandalone() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2930 */     public String getXmlVersion() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2931 */     public void normalizeDocument() { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2932 */     public Node renameNode(Node n, String namespaceURI, String qualifiedName) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2933 */     public void setDocumentURI(String documentURI) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2934 */     public void setStrictErrorChecking(boolean strictErrorChecking) { throw new RuntimeException("DOM Level 3 Not implemented"); }
/* 2935 */     public void setXmlStandalone(boolean xmlStandalone) { throw new RuntimeException("DOM Level 3 Not implemented"); } public void setXmlVersion(String xmlVersion) {
/* 2936 */       throw new RuntimeException("DOM Level 3 Not implemented");
/*      */     }
/* 2938 */     public Attr createAttribute(String name) { return DomImpl._document_createAttribute(this, name); }
/* 2939 */     public Attr createAttributeNS(String namespaceURI, String qualifiedName) { return DomImpl._document_createAttributeNS(this, namespaceURI, qualifiedName); }
/* 2940 */     public CDATASection createCDATASection(String data) { return DomImpl._document_createCDATASection(this, data); }
/* 2941 */     public Comment createComment(String data) { return DomImpl._document_createComment(this, data); }
/* 2942 */     public DocumentFragment createDocumentFragment() { return DomImpl._document_createDocumentFragment(this); }
/* 2943 */     public Element createElement(String tagName) { return DomImpl._document_createElement(this, tagName); }
/* 2944 */     public Element createElementNS(String namespaceURI, String qualifiedName) { return DomImpl._document_createElementNS(this, namespaceURI, qualifiedName); }
/* 2945 */     public EntityReference createEntityReference(String name) { return DomImpl._document_createEntityReference(this, name); }
/* 2946 */     public ProcessingInstruction createProcessingInstruction(String target, String data) { return DomImpl._document_createProcessingInstruction(this, target, data); }
/* 2947 */     public Text createTextNode(String data) { return DomImpl._document_createTextNode(this, data); }
/* 2948 */     public DocumentType getDoctype() { return DomImpl._document_getDoctype(this); }
/* 2949 */     public Element getDocumentElement() { return DomImpl._document_getDocumentElement(this); }
/* 2950 */     public Element getElementById(String elementId) { return DomImpl._document_getElementById(this, elementId); }
/* 2951 */     public NodeList getElementsByTagName(String tagname) { return DomImpl._document_getElementsByTagName(this, tagname); }
/* 2952 */     public NodeList getElementsByTagNameNS(String namespaceURI, String localName) { return DomImpl._document_getElementsByTagNameNS(this, namespaceURI, localName); }
/* 2953 */     public DOMImplementation getImplementation() { return DomImpl._document_getImplementation(this); } public Node importNode(Node importedNode, boolean deep) {
/* 2954 */       return DomImpl._document_importNode(this, importedNode, deep);
/*      */     }
/* 2956 */     public int getLength() { return DomImpl._childNodes_getLength(this); } public Node item(int i) {
/* 2957 */       return DomImpl._childNodes_item(this, i);
/*      */     }
/* 2959 */     public void removeAllMimeHeaders() { DomImpl._soapPart_removeAllMimeHeaders(this); }
/* 2960 */     public void removeMimeHeader(String name) { DomImpl._soapPart_removeMimeHeader(this, name); }
/* 2961 */     public Iterator getAllMimeHeaders() { return DomImpl._soapPart_getAllMimeHeaders(this); }
/* 2962 */     public SOAPEnvelope getEnvelope() { return DomImpl._soapPart_getEnvelope(this); }
/* 2963 */     public Source getContent() { return DomImpl._soapPart_getContent(this); }
/* 2964 */     public void setContent(Source source) { DomImpl._soapPart_setContent(this, source); }
/* 2965 */     public String[] getMimeHeader(String name) { return DomImpl._soapPart_getMimeHeader(this, name); }
/* 2966 */     public void addMimeHeader(String name, String value) { DomImpl._soapPart_addMimeHeader(this, name, value); }
/* 2967 */     public void setMimeHeader(String name, String value) { DomImpl._soapPart_setMimeHeader(this, name, value); }
/* 2968 */     public Iterator getMatchingMimeHeaders(String[] names) { return DomImpl._soapPart_getMatchingMimeHeaders(this, names); } public Iterator getNonMatchingMimeHeaders(String[] names) {
/* 2969 */       return DomImpl._soapPart_getNonMatchingMimeHeaders(this, names);
/*      */     } public boolean nodeCanHavePrefixUri() {
/* 2971 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */   static class SoapElementXobj
/*      */     extends ElementXobj
/*      */     implements SOAPElement, Node {
/*      */     SoapElementXobj(Locale l, QName name) {
/* 2979 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 2981 */       return new SoapElementXobj(l, this._name);
/*      */     }
/* 2983 */     public void detachNode() { DomImpl._soapNode_detachNode(this); }
/* 2984 */     public void recycleNode() { DomImpl._soapNode_recycleNode(this); }
/* 2985 */     public String getValue() { return DomImpl._soapNode_getValue(this); }
/* 2986 */     public void setValue(String value) { DomImpl._soapNode_setValue(this, value); }
/* 2987 */     public SOAPElement getParentElement() { return DomImpl._soapNode_getParentElement(this); } public void setParentElement(SOAPElement p) {
/* 2988 */       DomImpl._soapNode_setParentElement(this, p);
/*      */     }
/* 2990 */     public void removeContents() { DomImpl._soapElement_removeContents(this); }
/* 2991 */     public String getEncodingStyle() { return DomImpl._soapElement_getEncodingStyle(this); }
/* 2992 */     public void setEncodingStyle(String encodingStyle) { DomImpl._soapElement_setEncodingStyle(this, encodingStyle); }
/* 2993 */     public boolean removeNamespaceDeclaration(String prefix) { return DomImpl._soapElement_removeNamespaceDeclaration(this, prefix); }
/* 2994 */     public Iterator getAllAttributes() { return DomImpl._soapElement_getAllAttributes(this); }
/* 2995 */     public Iterator getChildElements() { return DomImpl._soapElement_getChildElements(this); }
/* 2996 */     public Iterator getNamespacePrefixes() { return DomImpl._soapElement_getNamespacePrefixes(this); }
/* 2997 */     public SOAPElement addAttribute(Name name, String value) throws SOAPException { return DomImpl._soapElement_addAttribute(this, name, value); }
/* 2998 */     public SOAPElement addChildElement(SOAPElement oldChild) throws SOAPException { return DomImpl._soapElement_addChildElement(this, oldChild); }
/* 2999 */     public SOAPElement addChildElement(Name name) throws SOAPException { return DomImpl._soapElement_addChildElement(this, name); }
/* 3000 */     public SOAPElement addChildElement(String localName) throws SOAPException { return DomImpl._soapElement_addChildElement(this, localName); }
/* 3001 */     public SOAPElement addChildElement(String localName, String prefix) throws SOAPException { return DomImpl._soapElement_addChildElement(this, localName, prefix); }
/* 3002 */     public SOAPElement addChildElement(String localName, String prefix, String uri) throws SOAPException { return DomImpl._soapElement_addChildElement(this, localName, prefix, uri); }
/* 3003 */     public SOAPElement addNamespaceDeclaration(String prefix, String uri) { return DomImpl._soapElement_addNamespaceDeclaration(this, prefix, uri); }
/* 3004 */     public SOAPElement addTextNode(String data) { return DomImpl._soapElement_addTextNode(this, data); }
/* 3005 */     public String getAttributeValue(Name name) { return DomImpl._soapElement_getAttributeValue(this, name); }
/* 3006 */     public Iterator getChildElements(Name name) { return DomImpl._soapElement_getChildElements(this, name); }
/* 3007 */     public Name getElementName() { return DomImpl._soapElement_getElementName(this); }
/* 3008 */     public String getNamespaceURI(String prefix) { return DomImpl._soapElement_getNamespaceURI(this, prefix); }
/* 3009 */     public Iterator getVisibleNamespacePrefixes() { return DomImpl._soapElement_getVisibleNamespacePrefixes(this); } public boolean removeAttribute(Name name) {
/* 3010 */       return DomImpl._soapElement_removeAttribute(this, name);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SoapBodyXobj extends SoapElementXobj implements SOAPBody { SoapBodyXobj(Locale l, QName name) {
/* 3015 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3017 */       return new SoapBodyXobj(l, this._name);
/*      */     }
/* 3019 */     public boolean hasFault() { return DomImpl.soapBody_hasFault(this); }
/* 3020 */     public SOAPFault addFault() throws SOAPException { return DomImpl.soapBody_addFault(this); }
/* 3021 */     public SOAPFault getFault() { return DomImpl.soapBody_getFault(this); }
/* 3022 */     public SOAPBodyElement addBodyElement(Name name) { return DomImpl.soapBody_addBodyElement(this, name); }
/* 3023 */     public SOAPBodyElement addDocument(Document document) { return DomImpl.soapBody_addDocument(this, document); }
/* 3024 */     public SOAPFault addFault(Name name, String s) throws SOAPException { return DomImpl.soapBody_addFault(this, name, s); } public SOAPFault addFault(Name faultCode, String faultString, Locale locale) throws SOAPException {
/* 3025 */       return DomImpl.soapBody_addFault(this, faultCode, faultString, locale);
/*      */     } }
/*      */   
/*      */   static class SoapBodyElementXobj extends SoapElementXobj implements SOAPBodyElement {
/*      */     SoapBodyElementXobj(Locale l, QName name) {
/* 3030 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3032 */       return new SoapBodyElementXobj(l, this._name);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SoapEnvelopeXobj extends SoapElementXobj implements SOAPEnvelope { SoapEnvelopeXobj(Locale l, QName name) {
/* 3037 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3039 */       return new SoapEnvelopeXobj(l, this._name);
/*      */     }
/* 3041 */     public SOAPBody addBody() throws SOAPException { return DomImpl._soapEnvelope_addBody(this); }
/* 3042 */     public SOAPBody getBody() throws SOAPException { return DomImpl._soapEnvelope_getBody(this); }
/* 3043 */     public SOAPHeader getHeader() throws SOAPException { return DomImpl._soapEnvelope_getHeader(this); }
/* 3044 */     public SOAPHeader addHeader() throws SOAPException { return DomImpl._soapEnvelope_addHeader(this); }
/* 3045 */     public Name createName(String localName) { return DomImpl._soapEnvelope_createName(this, localName); } public Name createName(String localName, String prefix, String namespaceURI) {
/* 3046 */       return DomImpl._soapEnvelope_createName(this, localName, prefix, namespaceURI);
/*      */     } }
/*      */   
/*      */   static class SoapHeaderXobj extends SoapElementXobj implements SOAPHeader {
/*      */     SoapHeaderXobj(Locale l, QName name) {
/* 3051 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3053 */       return new SoapHeaderXobj(l, this._name);
/*      */     }
/* 3055 */     public Iterator examineAllHeaderElements() { return DomImpl.soapHeader_examineAllHeaderElements(this); }
/* 3056 */     public Iterator extractAllHeaderElements() { return DomImpl.soapHeader_extractAllHeaderElements(this); }
/* 3057 */     public Iterator examineHeaderElements(String actor) { return DomImpl.soapHeader_examineHeaderElements(this, actor); }
/* 3058 */     public Iterator examineMustUnderstandHeaderElements(String mustUnderstandString) { return DomImpl.soapHeader_examineMustUnderstandHeaderElements(this, mustUnderstandString); }
/* 3059 */     public Iterator extractHeaderElements(String actor) { return DomImpl.soapHeader_extractHeaderElements(this, actor); } public SOAPHeaderElement addHeaderElement(Name name) {
/* 3060 */       return DomImpl.soapHeader_addHeaderElement(this, name);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SoapHeaderElementXobj extends SoapElementXobj implements SOAPHeaderElement { SoapHeaderElementXobj(Locale l, QName name) {
/* 3065 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3067 */       return new SoapHeaderElementXobj(l, this._name);
/*      */     }
/* 3069 */     public void setMustUnderstand(boolean mustUnderstand) { DomImpl.soapHeaderElement_setMustUnderstand(this, mustUnderstand); }
/* 3070 */     public boolean getMustUnderstand() { return DomImpl.soapHeaderElement_getMustUnderstand(this); }
/* 3071 */     public void setActor(String actor) { DomImpl.soapHeaderElement_setActor(this, actor); } public String getActor() {
/* 3072 */       return DomImpl.soapHeaderElement_getActor(this);
/*      */     } }
/*      */   
/*      */   static class SoapFaultXobj extends SoapBodyElementXobj implements SOAPFault {
/*      */     SoapFaultXobj(Locale l, QName name) {
/* 3077 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3079 */       return new SoapFaultXobj(l, this._name);
/*      */     }
/* 3081 */     public void setFaultString(String faultString) { DomImpl.soapFault_setFaultString(this, faultString); }
/* 3082 */     public void setFaultString(String faultString, Locale locale) { DomImpl.soapFault_setFaultString(this, faultString, locale); }
/* 3083 */     public void setFaultCode(Name faultCodeName) throws SOAPException { DomImpl.soapFault_setFaultCode(this, faultCodeName); }
/* 3084 */     public void setFaultActor(String faultActorString) { DomImpl.soapFault_setFaultActor(this, faultActorString); }
/* 3085 */     public String getFaultActor() { return DomImpl.soapFault_getFaultActor(this); }
/* 3086 */     public String getFaultCode() { return DomImpl.soapFault_getFaultCode(this); }
/* 3087 */     public void setFaultCode(String faultCode) throws SOAPException { DomImpl.soapFault_setFaultCode(this, faultCode); }
/* 3088 */     public Locale getFaultStringLocale() { return DomImpl.soapFault_getFaultStringLocale(this); }
/* 3089 */     public Name getFaultCodeAsName() { return DomImpl.soapFault_getFaultCodeAsName(this); }
/* 3090 */     public String getFaultString() { return DomImpl.soapFault_getFaultString(this); }
/* 3091 */     public Detail addDetail() throws SOAPException { return DomImpl.soapFault_addDetail(this); } public Detail getDetail() {
/* 3092 */       return DomImpl.soapFault_getDetail(this);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SoapFaultElementXobj extends SoapElementXobj implements SOAPFaultElement { SoapFaultElementXobj(Locale l, QName name) {
/* 3097 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3099 */       return new SoapFaultElementXobj(l, this._name);
/*      */     } }
/*      */   
/*      */   static class DetailXobj extends SoapFaultElementXobj implements Detail {
/*      */     DetailXobj(Locale l, QName name) {
/* 3104 */       super(l, name);
/*      */     } Xobj newNode(Locale l) {
/* 3106 */       return new DetailXobj(l, this._name);
/*      */     }
/* 3108 */     public DetailEntry addDetailEntry(Name name) { return DomImpl.detail_addDetailEntry(this, name); } public Iterator getDetailEntries() {
/* 3109 */       return DomImpl.detail_getDetailEntries(this);
/*      */     }
/*      */   }
/*      */   
/*      */   static class DetailEntryXobj extends SoapElementXobj implements DetailEntry { Xobj newNode(Locale l) {
/* 3114 */       return new DetailEntryXobj(l, this._name);
/*      */     } DetailEntryXobj(Locale l, QName name) {
/* 3116 */       super(l, name);
/*      */     } }
/*      */   static class Bookmark implements XmlCursor.XmlMark { Xobj _xobj;
/*      */     int _pos;
/*      */     Bookmark _next;
/*      */     Bookmark _prev;
/*      */     Object _key;
/*      */     Object _value;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     boolean isOnList(Bookmark head) {
/* 3127 */       for (; head != null; head = head._next) {
/* 3128 */         if (head == this)
/* 3129 */           return true; 
/*      */       } 
/* 3131 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     Bookmark listInsert(Bookmark head) {
/* 3136 */       assert this._next == null && this._prev == null;
/*      */       
/* 3138 */       if (head == null) {
/* 3139 */         head = this._prev = this;
/*      */       } else {
/*      */         
/* 3142 */         this._prev = head._prev;
/* 3143 */         head._prev = head._prev._next = this;
/*      */       } 
/*      */       
/* 3146 */       return head;
/*      */     }
/*      */ 
/*      */     
/*      */     Bookmark listRemove(Bookmark head) {
/* 3151 */       assert this._prev != null && isOnList(head);
/*      */       
/* 3153 */       if (this._prev == this) {
/* 3154 */         head = null;
/*      */       } else {
/*      */         
/* 3157 */         if (head == this) {
/* 3158 */           head = this._next;
/*      */         } else {
/* 3160 */           this._prev._next = this._next;
/*      */         } 
/* 3162 */         if (this._next == null) {
/* 3163 */           head._prev = this._prev;
/*      */         } else {
/*      */           
/* 3166 */           this._next._prev = this._prev;
/* 3167 */           this._next = null;
/*      */         } 
/*      */       } 
/*      */       
/* 3171 */       this._prev = null;
/* 3172 */       assert this._next == null;
/*      */       
/* 3174 */       return head;
/*      */     }
/*      */ 
/*      */     
/*      */     void moveTo(Xobj x, int p) {
/* 3179 */       assert isOnList(this._xobj._bookmarks);
/*      */       
/* 3181 */       if (this._xobj != x) {
/*      */         
/* 3183 */         this._xobj._bookmarks = listRemove(this._xobj._bookmarks);
/* 3184 */         x._bookmarks = listInsert(x._bookmarks);
/*      */         
/* 3186 */         this._xobj = x;
/*      */       } 
/*      */       
/* 3189 */       this._pos = p;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public XmlCursor createCursor() {
/* 3198 */       if (this._xobj == null)
/*      */       {
/* 3200 */         throw new IllegalStateException("Attempting to create a cursor on a bookmark that has been cleared or replaced.");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3205 */       return Cursor.newCursor(this._xobj, this._pos);
/*      */     } }
/*      */ 
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\Xobj.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */