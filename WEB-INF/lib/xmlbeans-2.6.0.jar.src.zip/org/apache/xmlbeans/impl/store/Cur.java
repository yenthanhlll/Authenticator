/*      */ package org.apache.xmlbeans.impl.store;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.CDataBookmark;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlDocumentProperties;
/*      */ import org.apache.xmlbeans.XmlLineNumber;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.soap.Detail;
/*      */ import org.apache.xmlbeans.impl.soap.DetailEntry;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPBody;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPBodyElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPEnvelope;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPFault;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPFaultElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPHeader;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPHeaderElement;
/*      */ import org.apache.xmlbeans.impl.values.TypeStoreUser;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Cur
/*      */ {
/*      */   static final int TEXT = 0;
/*      */   static final int ROOT = 1;
/*      */   static final int ELEM = 2;
/*      */   static final int ATTR = 3;
/*      */   static final int COMMENT = 4;
/*      */   static final int PROCINST = 5;
/*      */   static final int POOLED = 0;
/*      */   static final int REGISTERED = 1;
/*      */   static final int EMBEDDED = 2;
/*      */   static final int DISPOSED = 3;
/*      */   static final int END_POS = -1;
/*      */   static final int NO_POS = -2;
/*      */   static final String LOAD_USE_LOCALE_CHAR_UTIL = "LOAD_USE_LOCALE_CHAR_UTIL";
/*      */   Locale _locale;
/*      */   Xobj _xobj;
/*      */   int _pos;
/*      */   int _state;
/*      */   String _id;
/*      */   Cur _nextTemp;
/*      */   Cur _prevTemp;
/*      */   int _tempFrame;
/*      */   Cur _next;
/*      */   Cur _prev;
/*      */   Locale.Ref _ref;
/*      */   int _stackTop;
/*      */   int _selectionFirst;
/*      */   int _selectionN;
/*      */   int _selectionLoc;
/*      */   int _selectionCount;
/*      */   private int _posTemp;
/*      */   int _offSrc;
/*      */   int _cchSrc;
/*      */   static final boolean $assertionsDisabled;
/*      */   static Class class$org$apache$xmlbeans$XmlLineNumber;
/*      */   
/*      */   Cur(Locale l) {
/*  122 */     this._locale = l;
/*  123 */     this._pos = -2;
/*      */     
/*  125 */     this._tempFrame = -1;
/*      */     
/*  127 */     this._state = 0;
/*      */     
/*  129 */     this._stackTop = -1;
/*  130 */     this._selectionFirst = -1;
/*  131 */     this._selectionN = -1;
/*  132 */     this._selectionLoc = -1;
/*  133 */     this._selectionCount = 0;
/*      */   }
/*      */   boolean isPositioned() {
/*  136 */     assert isNormal(); return (this._xobj != null);
/*      */   }
/*  138 */   static boolean kindIsContainer(int k) { return (k == 2 || k == 1); } static boolean kindIsFinish(int k) {
/*  139 */     return (k == -2 || k == -1);
/*      */   }
/*      */   
/*      */   int kind() {
/*  143 */     assert isPositioned();
/*  144 */     int kind = this._xobj.kind();
/*  145 */     return (this._pos == 0) ? kind : ((this._pos == -1) ? -kind : 0);
/*      */   }
/*      */   
/*  148 */   boolean isRoot() { assert isPositioned(); return (this._pos == 0 && this._xobj.kind() == 1); }
/*  149 */   boolean isElem() { assert isPositioned(); return (this._pos == 0 && this._xobj.kind() == 2); }
/*  150 */   boolean isAttr() { assert isPositioned(); return (this._pos == 0 && this._xobj.kind() == 3); }
/*  151 */   boolean isComment() { assert isPositioned(); return (this._pos == 0 && this._xobj.kind() == 4); }
/*  152 */   boolean isProcinst() { assert isPositioned(); return (this._pos == 0 && this._xobj.kind() == 5); }
/*  153 */   boolean isText() { assert isPositioned(); return (this._pos > 0); }
/*  154 */   boolean isEnd() { assert isPositioned(); return (this._pos == -1 && this._xobj.kind() == 2); }
/*  155 */   boolean isEndRoot() { assert isPositioned(); return (this._pos == -1 && this._xobj.kind() == 1); }
/*  156 */   boolean isNode() { assert isPositioned(); return (this._pos == 0); }
/*  157 */   boolean isContainer() { assert isPositioned(); return (this._pos == 0 && kindIsContainer(this._xobj.kind())); }
/*  158 */   boolean isFinish() { assert isPositioned(); return (this._pos == -1 && kindIsContainer(this._xobj.kind())); } boolean isUserNode() {
/*  159 */     assert isPositioned(); int k = kind(); return (k == 2 || k == 1 || (k == 3 && !isXmlns()));
/*      */   }
/*      */   
/*      */   boolean isContainerOrFinish() {
/*  163 */     assert isPositioned();
/*      */     
/*  165 */     if (this._pos != 0 && this._pos != -1) {
/*  166 */       return false;
/*      */     }
/*  168 */     int kind = this._xobj.kind();
/*  169 */     return (kind == 2 || kind == -2 || kind == 1 || kind == -1);
/*      */   }
/*      */   
/*  172 */   boolean isNormalAttr() { return (isNode() && this._xobj.isNormalAttr()); } boolean isXmlns() {
/*  173 */     return (isNode() && this._xobj.isXmlns());
/*      */   } boolean isTextCData() {
/*  175 */     return this._xobj.hasBookmark(CDataBookmark.class, this._pos);
/*      */   }
/*  177 */   QName getName() { assert isNode() || isEnd(); return this._xobj._name; }
/*  178 */   String getLocal() { return getName().getLocalPart(); } String getUri() {
/*  179 */     return getName().getNamespaceURI();
/*      */   }
/*  181 */   String getXmlnsPrefix() { assert isXmlns(); return this._xobj.getXmlnsPrefix(); } String getXmlnsUri() {
/*  182 */     assert isXmlns(); return this._xobj.getXmlnsUri();
/*      */   }
/*  184 */   boolean isDomDocRoot() { return (isRoot() && this._xobj.getDom() instanceof org.w3c.dom.Document); } boolean isDomFragRoot() {
/*  185 */     return (isRoot() && this._xobj.getDom() instanceof org.w3c.dom.DocumentFragment);
/*      */   }
/*  187 */   int cchRight() { assert isPositioned(); return this._xobj.cchRight(this._pos); } int cchLeft() {
/*  188 */     assert isPositioned(); return this._xobj.cchLeft(this._pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void createRoot() {
/*  196 */     createDomDocFragRoot();
/*      */   }
/*      */ 
/*      */   
/*      */   void createDomDocFragRoot() {
/*  201 */     moveTo(new Xobj.DocumentFragXobj(this._locale));
/*      */   }
/*      */ 
/*      */   
/*      */   void createDomDocumentRoot() {
/*  206 */     moveTo(createDomDocumentRootXobj(this._locale));
/*      */   }
/*      */ 
/*      */   
/*      */   void createAttr(QName name) {
/*  211 */     createHelper(new Xobj.AttrXobj(this._locale, name));
/*      */   }
/*      */ 
/*      */   
/*      */   void createComment() {
/*  216 */     createHelper(new Xobj.CommentXobj(this._locale));
/*      */   }
/*      */ 
/*      */   
/*      */   void createProcinst(String target) {
/*  221 */     createHelper(new Xobj.ProcInstXobj(this._locale, target));
/*      */   }
/*      */ 
/*      */   
/*      */   void createElement(QName name) {
/*  226 */     createElement(name, null);
/*      */   }
/*      */ 
/*      */   
/*      */   void createElement(QName name, QName parentName) {
/*  231 */     createHelper(createElementXobj(this._locale, name, parentName));
/*      */   }
/*      */ 
/*      */   
/*      */   static Xobj createDomDocumentRootXobj(Locale l) {
/*  236 */     return createDomDocumentRootXobj(l, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Xobj createDomDocumentRootXobj(Locale l, boolean fragment) {
/*      */     Xobj xo;
/*  243 */     if (l._saaj == null)
/*  244 */     { if (fragment) {
/*  245 */         xo = new Xobj.DocumentFragXobj(l);
/*      */       } else {
/*  247 */         xo = new Xobj.DocumentXobj(l);
/*      */       }  }
/*  249 */     else { xo = new Xobj.SoapPartDocXobj(l); }
/*      */     
/*  251 */     if (l._ownerDoc == null) {
/*  252 */       l._ownerDoc = xo.getDom();
/*      */     }
/*  254 */     return xo;
/*      */   }
/*      */ 
/*      */   
/*      */   static Xobj createElementXobj(Locale l, QName name, QName parentName) {
/*  259 */     if (l._saaj == null) {
/*  260 */       return new Xobj.ElementXobj(l, name);
/*      */     }
/*  262 */     Class c = l._saaj.identifyElement(name, parentName);
/*      */     
/*  264 */     if (c == SOAPElement.class) return new Xobj.SoapElementXobj(l, name); 
/*  265 */     if (c == SOAPBody.class) return new Xobj.SoapBodyXobj(l, name); 
/*  266 */     if (c == SOAPBodyElement.class) return new Xobj.SoapBodyElementXobj(l, name); 
/*  267 */     if (c == SOAPEnvelope.class) return new Xobj.SoapEnvelopeXobj(l, name); 
/*  268 */     if (c == SOAPHeader.class) return new Xobj.SoapHeaderXobj(l, name); 
/*  269 */     if (c == SOAPHeaderElement.class) return new Xobj.SoapHeaderElementXobj(l, name); 
/*  270 */     if (c == SOAPFaultElement.class) return new Xobj.SoapFaultElementXobj(l, name); 
/*  271 */     if (c == Detail.class) return new Xobj.DetailXobj(l, name); 
/*  272 */     if (c == DetailEntry.class) return new Xobj.DetailEntryXobj(l, name); 
/*  273 */     if (c == SOAPFault.class) return new Xobj.SoapFaultXobj(l, name);
/*      */     
/*  275 */     throw new IllegalStateException("Unknown SAAJ element class: " + c);
/*      */   }
/*      */ 
/*      */   
/*      */   private void createHelper(Xobj x) {
/*  280 */     assert x._locale == this._locale;
/*      */ 
/*      */ 
/*      */     
/*  284 */     if (isPositioned()) {
/*      */       
/*  286 */       Cur from = tempCur(x, 0);
/*  287 */       from.moveNode(this);
/*  288 */       from.release();
/*      */     } 
/*      */     
/*  291 */     moveTo(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isSamePos(Cur that) {
/*  300 */     assert isNormal() && (that == null || that.isNormal());
/*      */     
/*  302 */     return (this._xobj == that._xobj && this._pos == that._pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isJustAfterEnd(Cur that) {
/*  309 */     assert isNormal() && that != null && that.isNormal() && that.isNode();
/*      */     
/*  311 */     return that._xobj.isJustAfterEnd(this._xobj, this._pos);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isJustAfterEnd(Xobj x) {
/*  316 */     return x.isJustAfterEnd(this._xobj, this._pos);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isAtEndOf(Cur that) {
/*  321 */     assert that != null && that.isNormal() && that.isNode();
/*      */     
/*  323 */     return (this._xobj == that._xobj && this._pos == -1);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isInSameTree(Cur that) {
/*  328 */     assert isPositioned() && that.isPositioned();
/*      */     
/*  330 */     return this._xobj.isInSameTree(that._xobj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int comparePosition(Cur that) {
/*  337 */     assert isPositioned() && that.isPositioned();
/*      */ 
/*      */ 
/*      */     
/*  341 */     if (this._locale != that._locale) {
/*  342 */       return 2;
/*      */     }
/*      */ 
/*      */     
/*  346 */     Xobj xThis = this._xobj;
/*  347 */     int pThis = (this._pos == -1) ? (xThis.posAfter() - 1) : this._pos;
/*      */     
/*  349 */     Xobj xThat = that._xobj;
/*  350 */     int pThat = (that._pos == -1) ? (xThat.posAfter() - 1) : that._pos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  363 */     if (xThis == xThat) {
/*  364 */       return (pThis < pThat) ? -1 : ((pThis == pThat) ? 0 : 1);
/*      */     }
/*      */ 
/*      */     
/*  368 */     int dThis = 0;
/*      */     
/*  370 */     for (Xobj x = xThis._parent; x != null; x = x._parent) {
/*      */       
/*  372 */       dThis++;
/*      */       
/*  374 */       if (x == xThat) {
/*  375 */         return (pThat < xThat.posAfter() - 1) ? 1 : -1;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  380 */     int dThat = 0;
/*      */     
/*  382 */     for (Xobj xobj1 = xThat._parent; xobj1 != null; xobj1 = xobj1._parent) {
/*      */       
/*  384 */       dThat++;
/*      */       
/*  386 */       if (xobj1 == xThis) {
/*  387 */         return (pThis < xThis.posAfter() - 1) ? -1 : 1;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  392 */     while (dThis > dThat) { dThis--; xThis = xThis._parent; }
/*  393 */      while (dThat > dThis) { dThat--; xThat = xThat._parent; }
/*      */     
/*  395 */     assert dThat == dThis;
/*      */     
/*  397 */     if (dThat == 0) {
/*  398 */       return 2;
/*      */     }
/*  400 */     assert xThis._parent != null && xThat._parent != null;
/*      */     
/*  402 */     while (xThis._parent != xThat._parent) {
/*      */       
/*  404 */       if ((xThis = xThis._parent) == null) {
/*  405 */         return 2;
/*      */       }
/*  407 */       xThat = xThat._parent;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  413 */     if (xThis._prevSibling == null || xThat._nextSibling == null) {
/*  414 */       return -1;
/*      */     }
/*  416 */     if (xThis._nextSibling == null || xThat._prevSibling == null) {
/*  417 */       return 1;
/*      */     }
/*  419 */     while (xThis != null) {
/*  420 */       if ((xThis = xThis._prevSibling) == xThat)
/*  421 */         return 1; 
/*      */     } 
/*  423 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   void setName(QName newName) {
/*  428 */     assert isNode() && newName != null;
/*      */     
/*  430 */     this._xobj.setName(newName);
/*      */   }
/*      */ 
/*      */   
/*      */   void moveTo(Xobj x) {
/*  435 */     moveTo(x, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void moveTo(Xobj x, int p) {
/*  442 */     assert x == null || this._locale == x._locale;
/*  443 */     assert x != null || p == -2;
/*  444 */     assert x == null || x.isNormal(p) || (x.isVacant() && x._cchValue == 0 && x._user == null);
/*  445 */     assert this._state == 1 || this._state == 2;
/*  446 */     assert this._state == 2 || this._xobj == null || !isOnList(this._xobj._embedded);
/*  447 */     assert this._state == 1 || (this._xobj != null && isOnList(this._xobj._embedded));
/*      */     
/*  449 */     moveToNoCheck(x, p);
/*      */     
/*  451 */     assert isNormal() || (this._xobj.isVacant() && this._xobj._cchValue == 0 && this._xobj._user == null);
/*      */   }
/*      */ 
/*      */   
/*      */   void moveToNoCheck(Xobj x, int p) {
/*  456 */     if (this._state == 2 && x != this._xobj) {
/*      */       
/*  458 */       this._xobj._embedded = listRemove(this._xobj._embedded);
/*  459 */       this._locale._registered = listInsert(this._locale._registered);
/*  460 */       this._state = 1;
/*      */     } 
/*      */     
/*  463 */     this._xobj = x;
/*  464 */     this._pos = p;
/*      */   }
/*      */ 
/*      */   
/*      */   void moveToCur(Cur to) {
/*  469 */     assert isNormal() && (to == null || to.isNormal());
/*      */     
/*  471 */     if (to == null) {
/*  472 */       moveTo(null, -2);
/*      */     } else {
/*  474 */       moveTo(to._xobj, to._pos);
/*      */     } 
/*      */   }
/*      */   
/*      */   void moveToDom(DomImpl.Dom d) {
/*  479 */     assert this._locale == d.locale();
/*  480 */     assert d instanceof Xobj || d instanceof Xobj.SoapPartDom;
/*      */     
/*  482 */     moveTo((d instanceof Xobj) ? (Xobj)d : ((Xobj.SoapPartDom)d)._docXobj);
/*      */   }
/*      */   static final class Locations { private static final int NULL = -1; private static final int _initialSize = 32; private Locale _locale; private Xobj[] _xobjs; private int[] _poses; private Cur[] _curs; private int[] _next; private int[] _prev; private int[] _nextN;
/*      */     private int[] _prevN;
/*      */     private int _free;
/*      */     private int _naked;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     Locations(Locale l) {
/*  491 */       this._locale = l;
/*      */       
/*  493 */       this._xobjs = new Xobj[32];
/*  494 */       this._poses = new int[32];
/*  495 */       this._curs = new Cur[32];
/*  496 */       this._next = new int[32];
/*  497 */       this._prev = new int[32];
/*  498 */       this._nextN = new int[32];
/*  499 */       this._prevN = new int[32];
/*      */       
/*  501 */       for (int i = 31; i >= 0; i--) {
/*      */         
/*  503 */         assert this._xobjs[i] == null;
/*  504 */         this._poses[i] = -2;
/*  505 */         this._next[i] = i + 1;
/*  506 */         this._prev[i] = -1;
/*  507 */         this._nextN[i] = -1;
/*  508 */         this._prevN[i] = -1;
/*      */       } 
/*      */       
/*  511 */       this._next[31] = -1;
/*      */       
/*  513 */       this._free = 0;
/*  514 */       this._naked = -1;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isSamePos(int i, Cur c) {
/*  519 */       if (this._curs[i] == null) {
/*  520 */         return (c._xobj == this._xobjs[i] && c._pos == this._poses[i]);
/*      */       }
/*  522 */       return c.isSamePos(this._curs[i]);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isAtEndOf(int i, Cur c) {
/*  527 */       assert this._curs[i] != null || this._poses[i] == 0;
/*  528 */       assert this._curs[i] == null || this._curs[i].isNode();
/*      */       
/*  530 */       if (this._curs[i] == null) {
/*  531 */         return (c._xobj == this._xobjs[i] && c._pos == -1);
/*      */       }
/*  533 */       return c.isAtEndOf(this._curs[i]);
/*      */     }
/*      */ 
/*      */     
/*      */     void moveTo(int i, Cur c) {
/*  538 */       if (this._curs[i] == null) {
/*  539 */         c.moveTo(this._xobjs[i], this._poses[i]);
/*      */       } else {
/*  541 */         c.moveToCur(this._curs[i]);
/*      */       } 
/*      */     }
/*      */     
/*      */     int insert(int head, int before, int i) {
/*  546 */       return insert(head, before, i, this._next, this._prev);
/*      */     }
/*      */ 
/*      */     
/*      */     int remove(int head, int i) {
/*  551 */       Cur c = this._curs[i];
/*      */       
/*  553 */       assert c != null || this._xobjs[i] != null;
/*  554 */       assert c != null || this._xobjs[i] != null;
/*      */       
/*  556 */       if (c != null) {
/*      */         
/*  558 */         this._curs[i].release();
/*  559 */         this._curs[i] = null;
/*      */         
/*  561 */         assert this._xobjs[i] == null;
/*  562 */         assert this._poses[i] == -2;
/*      */       }
/*      */       else {
/*      */         
/*  566 */         assert this._xobjs[i] != null && this._poses[i] != -2;
/*      */         
/*  568 */         this._xobjs[i] = null;
/*  569 */         this._poses[i] = -2;
/*      */         
/*  571 */         this._naked = remove(this._naked, i, this._nextN, this._prevN);
/*      */       } 
/*      */       
/*  574 */       head = remove(head, i, this._next, this._prev);
/*      */       
/*  576 */       this._next[i] = this._free;
/*  577 */       this._free = i;
/*      */       
/*  579 */       return head;
/*      */     }
/*      */ 
/*      */     
/*      */     int allocate(Cur addThis) {
/*  584 */       assert addThis.isPositioned();
/*      */       
/*  586 */       if (this._free == -1) {
/*  587 */         makeRoom();
/*      */       }
/*  589 */       int i = this._free;
/*      */       
/*  591 */       this._free = this._next[i];
/*      */       
/*  593 */       this._next[i] = -1;
/*  594 */       assert this._prev[i] == -1;
/*      */       
/*  596 */       assert this._curs[i] == null;
/*  597 */       assert this._xobjs[i] == null;
/*  598 */       assert this._poses[i] == -2;
/*      */       
/*  600 */       this._xobjs[i] = addThis._xobj;
/*  601 */       this._poses[i] = addThis._pos;
/*      */       
/*  603 */       this._naked = insert(this._naked, -1, i, this._nextN, this._prevN);
/*      */       
/*  605 */       return i;
/*      */     }
/*      */ 
/*      */     
/*      */     private static int insert(int head, int before, int i, int[] next, int[] prev) {
/*  610 */       if (head == -1) {
/*      */         
/*  612 */         assert before == -1;
/*  613 */         prev[i] = i;
/*  614 */         head = i;
/*      */       }
/*  616 */       else if (before != -1) {
/*      */         
/*  618 */         prev[i] = prev[before];
/*  619 */         next[i] = before;
/*  620 */         prev[before] = i;
/*      */         
/*  622 */         if (head == before) {
/*  623 */           head = i;
/*      */         }
/*      */       } else {
/*      */         
/*  627 */         prev[i] = prev[head];
/*  628 */         assert next[i] == -1;
/*  629 */         next[prev[head]] = i;
/*  630 */         prev[head] = i;
/*      */       } 
/*      */       
/*  633 */       return head;
/*      */     }
/*      */ 
/*      */     
/*      */     private static int remove(int head, int i, int[] next, int[] prev) {
/*  638 */       if (prev[i] == i) {
/*      */         
/*  640 */         assert head == i;
/*  641 */         head = -1;
/*      */       }
/*      */       else {
/*      */         
/*  645 */         if (head == i) {
/*  646 */           head = next[i];
/*      */         } else {
/*  648 */           next[prev[i]] = next[i];
/*      */         } 
/*  650 */         if (next[i] == -1) {
/*  651 */           prev[head] = prev[i];
/*      */         } else {
/*      */           
/*  654 */           prev[next[i]] = prev[i];
/*  655 */           next[i] = -1;
/*      */         } 
/*      */       } 
/*      */       
/*  659 */       prev[i] = -1;
/*  660 */       assert next[i] == -1;
/*      */       
/*  662 */       return head;
/*      */     }
/*      */     
/*      */     void notifyChange() {
/*      */       int i;
/*  667 */       while ((i = this._naked) != -1) {
/*      */         
/*  669 */         assert this._curs[i] == null && this._xobjs[i] != null && this._poses[i] != -2;
/*      */         
/*  671 */         this._naked = remove(this._naked, i, this._nextN, this._prevN);
/*      */         
/*  673 */         this._curs[i] = this._locale.getCur();
/*  674 */         this._curs[i].moveTo(this._xobjs[i], this._poses[i]);
/*      */         
/*  676 */         this._xobjs[i] = null;
/*  677 */         this._poses[i] = -2;
/*      */       } 
/*      */     }
/*      */     
/*  681 */     int next(int i) { return this._next[i]; } int prev(int i) {
/*  682 */       return this._prev[i];
/*      */     }
/*      */     
/*      */     private void makeRoom() {
/*  686 */       assert this._free == -1;
/*      */       
/*  688 */       int l = this._xobjs.length;
/*      */       
/*  690 */       Xobj[] oldXobjs = this._xobjs;
/*  691 */       int[] oldPoses = this._poses;
/*  692 */       Cur[] oldCurs = this._curs;
/*  693 */       int[] oldNext = this._next;
/*  694 */       int[] oldPrev = this._prev;
/*  695 */       int[] oldNextN = this._nextN;
/*  696 */       int[] oldPrevN = this._prevN;
/*      */       
/*  698 */       this._xobjs = new Xobj[l * 2];
/*  699 */       this._poses = new int[l * 2];
/*  700 */       this._curs = new Cur[l * 2];
/*  701 */       this._next = new int[l * 2];
/*  702 */       this._prev = new int[l * 2];
/*  703 */       this._nextN = new int[l * 2];
/*  704 */       this._prevN = new int[l * 2];
/*      */       
/*  706 */       System.arraycopy(oldXobjs, 0, this._xobjs, 0, l);
/*  707 */       System.arraycopy(oldPoses, 0, this._poses, 0, l);
/*  708 */       System.arraycopy(oldCurs, 0, this._curs, 0, l);
/*  709 */       System.arraycopy(oldNext, 0, this._next, 0, l);
/*  710 */       System.arraycopy(oldPrev, 0, this._prev, 0, l);
/*  711 */       System.arraycopy(oldNextN, 0, this._nextN, 0, l);
/*  712 */       System.arraycopy(oldPrevN, 0, this._prevN, 0, l);
/*      */       
/*  714 */       for (int i = l * 2 - 1; i >= l; i--) {
/*      */         
/*  716 */         this._next[i] = i + 1;
/*  717 */         this._prev[i] = -1;
/*  718 */         this._nextN[i] = -1;
/*  719 */         this._prevN[i] = -1;
/*  720 */         this._poses[i] = -2;
/*      */       } 
/*      */       
/*  723 */       this._next[l * 2 - 1] = -1;
/*      */       
/*  725 */       this._free = l;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void push() {
/*  746 */     assert isPositioned();
/*      */     
/*  748 */     int i = this._locale._locations.allocate(this);
/*  749 */     this._stackTop = this._locale._locations.insert(this._stackTop, this._stackTop, i);
/*      */   }
/*      */ 
/*      */   
/*      */   void pop(boolean stay) {
/*  754 */     if (stay) {
/*  755 */       popButStay();
/*      */     } else {
/*  757 */       pop();
/*      */     } 
/*      */   }
/*      */   
/*      */   void popButStay() {
/*  762 */     if (this._stackTop != -1) {
/*  763 */       this._stackTop = this._locale._locations.remove(this._stackTop, this._stackTop);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean pop() {
/*  768 */     if (this._stackTop == -1) {
/*  769 */       return false;
/*      */     }
/*  771 */     this._locale._locations.moveTo(this._stackTop, this);
/*  772 */     this._stackTop = this._locale._locations.remove(this._stackTop, this._stackTop);
/*      */     
/*  774 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isAtLastPush() {
/*  779 */     assert this._stackTop != -1;
/*      */     
/*  781 */     return this._locale._locations.isSamePos(this._stackTop, this);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isAtEndOfLastPush() {
/*  786 */     assert this._stackTop != -1;
/*      */     
/*  788 */     return this._locale._locations.isAtEndOf(this._stackTop, this);
/*      */   }
/*      */ 
/*      */   
/*      */   void addToSelection(Cur that) {
/*  793 */     assert that != null && that.isNormal();
/*  794 */     assert isPositioned() && that.isPositioned();
/*      */     
/*  796 */     int i = this._locale._locations.allocate(that);
/*  797 */     this._selectionFirst = this._locale._locations.insert(this._selectionFirst, -1, i);
/*      */     
/*  799 */     this._selectionCount++;
/*      */   }
/*      */ 
/*      */   
/*      */   void addToSelection() {
/*  804 */     assert isPositioned();
/*      */     
/*  806 */     int i = this._locale._locations.allocate(this);
/*  807 */     this._selectionFirst = this._locale._locations.insert(this._selectionFirst, -1, i);
/*      */     
/*  809 */     this._selectionCount++;
/*      */   }
/*      */ 
/*      */   
/*      */   private int selectionIndex(int i) {
/*  814 */     assert this._selectionN >= -1 && i >= 0 && i < this._selectionCount;
/*      */     
/*  816 */     if (this._selectionN == -1) {
/*      */       
/*  818 */       this._selectionN = 0;
/*  819 */       this._selectionLoc = this._selectionFirst;
/*      */     } 
/*      */     
/*  822 */     while (this._selectionN < i) {
/*      */       
/*  824 */       this._selectionLoc = this._locale._locations.next(this._selectionLoc);
/*  825 */       this._selectionN++;
/*      */     } 
/*      */     
/*  828 */     while (this._selectionN > i) {
/*      */       
/*  830 */       this._selectionLoc = this._locale._locations.prev(this._selectionLoc);
/*  831 */       this._selectionN--;
/*      */     } 
/*      */     
/*  834 */     return this._selectionLoc;
/*      */   }
/*      */ 
/*      */   
/*      */   void removeSelection(int i) {
/*  839 */     assert i >= 0 && i < this._selectionCount;
/*      */     
/*  841 */     int j = selectionIndex(i);
/*      */ 
/*      */ 
/*      */     
/*  845 */     if (i < this._selectionN) {
/*  846 */       this._selectionN--;
/*  847 */     } else if (i == this._selectionN) {
/*      */       
/*  849 */       this._selectionN--;
/*      */       
/*  851 */       if (i == 0) {
/*  852 */         this._selectionLoc = -1;
/*      */       } else {
/*  854 */         this._selectionLoc = this._locale._locations.prev(this._selectionLoc);
/*      */       } 
/*      */     } 
/*  857 */     this._selectionFirst = this._locale._locations.remove(this._selectionFirst, j);
/*      */     
/*  859 */     this._selectionCount--;
/*      */   }
/*      */ 
/*      */   
/*      */   int selectionCount() {
/*  864 */     return this._selectionCount;
/*      */   }
/*      */ 
/*      */   
/*      */   void moveToSelection(int i) {
/*  869 */     assert i >= 0 && i < this._selectionCount;
/*      */     
/*  871 */     this._locale._locations.moveTo(selectionIndex(i), this);
/*      */   }
/*      */ 
/*      */   
/*      */   void clearSelection() {
/*  876 */     assert this._selectionCount >= 0;
/*      */     
/*  878 */     while (this._selectionCount > 0)
/*  879 */       removeSelection(0); 
/*      */   }
/*      */   
/*  882 */   boolean toParent() { return toParent(false); } boolean toParentRaw() {
/*  883 */     return toParent(true);
/*      */   }
/*  885 */   Xobj getParent() { return getParent(false); } Xobj getParentRaw() {
/*  886 */     return getParent(true);
/*      */   }
/*      */   
/*      */   boolean hasParent() {
/*  890 */     assert isPositioned();
/*      */     
/*  892 */     if (this._pos == -1 || (this._pos >= 1 && this._pos < this._xobj.posAfter())) {
/*  893 */       return true;
/*      */     }
/*  895 */     assert this._pos == 0 || this._xobj._parent != null;
/*      */     
/*  897 */     return (this._xobj._parent != null);
/*      */   }
/*      */ 
/*      */   
/*      */   Xobj getParentNoRoot() {
/*  902 */     assert isPositioned();
/*      */     
/*  904 */     if (this._pos == -1 || (this._pos >= 1 && this._pos < this._xobj.posAfter())) {
/*  905 */       return this._xobj;
/*      */     }
/*  907 */     assert this._pos == 0 || this._xobj._parent != null;
/*      */     
/*  909 */     if (this._xobj._parent != null) {
/*  910 */       return this._xobj._parent;
/*      */     }
/*  912 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   Xobj getParent(boolean raw) {
/*  917 */     assert isPositioned();
/*      */     
/*  919 */     if (this._pos == -1 || (this._pos >= 1 && this._pos < this._xobj.posAfter())) {
/*  920 */       return this._xobj;
/*      */     }
/*  922 */     assert this._pos == 0 || this._xobj._parent != null;
/*      */     
/*  924 */     if (this._xobj._parent != null) {
/*  925 */       return this._xobj._parent;
/*      */     }
/*  927 */     if (raw || this._xobj.isRoot()) {
/*  928 */       return null;
/*      */     }
/*  930 */     Cur r = this._locale.tempCur();
/*      */     
/*  932 */     r.createRoot();
/*      */     
/*  934 */     Xobj root = r._xobj;
/*      */     
/*  936 */     r.next();
/*  937 */     moveNode(r);
/*  938 */     r.release();
/*      */     
/*  940 */     return root;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toParent(boolean raw) {
/*  945 */     Xobj parent = getParent(raw);
/*      */     
/*  947 */     if (parent == null) {
/*  948 */       return false;
/*      */     }
/*  950 */     moveTo(parent);
/*      */     
/*  952 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   void toRoot() {
/*  957 */     Xobj xobj = this._xobj;
/*  958 */     while (!xobj.isRoot()) {
/*      */       
/*  960 */       if (xobj._parent == null) {
/*      */         
/*  962 */         Cur r = this._locale.tempCur();
/*      */         
/*  964 */         r.createRoot();
/*      */         
/*  966 */         Xobj root = r._xobj;
/*      */         
/*  968 */         r.next();
/*  969 */         moveNode(r);
/*  970 */         r.release();
/*      */         
/*  972 */         xobj = root;
/*      */         break;
/*      */       } 
/*  975 */       xobj = xobj._parent;
/*      */     } 
/*  977 */     moveTo(xobj);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean hasText() {
/*  982 */     assert isNode();
/*      */     
/*  984 */     return this._xobj.hasTextEnsureOccupancy();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean hasAttrs() {
/*  989 */     assert isNode();
/*      */     
/*  991 */     return this._xobj.hasAttrs();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean hasChildren() {
/*  996 */     assert isNode();
/*      */     
/*  998 */     return this._xobj.hasChildren();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toFirstChild() {
/* 1003 */     assert isNode();
/*      */     
/* 1005 */     if (!this._xobj.hasChildren()) {
/* 1006 */       return false;
/*      */     }
/* 1008 */     for (Xobj x = this._xobj._firstChild;; x = x._nextSibling) {
/*      */       
/* 1010 */       if (!x.isAttr()) {
/*      */         
/* 1012 */         moveTo(x);
/* 1013 */         return true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean toLastChild() {
/* 1020 */     assert isNode();
/*      */     
/* 1022 */     if (!this._xobj.hasChildren()) {
/* 1023 */       return false;
/*      */     }
/* 1025 */     moveTo(this._xobj._lastChild);
/*      */     
/* 1027 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toNextSibling() {
/* 1032 */     assert isNode();
/*      */     
/* 1034 */     if (this._xobj.isAttr()) {
/*      */       
/* 1036 */       if (this._xobj._nextSibling != null && this._xobj._nextSibling.isAttr())
/*      */       {
/* 1038 */         moveTo(this._xobj._nextSibling);
/* 1039 */         return true;
/*      */       }
/*      */     
/* 1042 */     } else if (this._xobj._nextSibling != null) {
/*      */       
/* 1044 */       moveTo(this._xobj._nextSibling);
/* 1045 */       return true;
/*      */     } 
/*      */     
/* 1048 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   void setValueAsQName(QName qname) {
/* 1053 */     assert isNode();
/*      */     
/* 1055 */     String value = qname.getLocalPart();
/* 1056 */     String ns = qname.getNamespaceURI();
/*      */     
/* 1058 */     String prefix = prefixForNamespace(ns, (qname.getPrefix().length() > 0) ? qname.getPrefix() : null, true);
/*      */ 
/*      */ 
/*      */     
/* 1062 */     if (prefix.length() > 0) {
/* 1063 */       value = prefix + ":" + value;
/*      */     }
/* 1065 */     setValue(value);
/*      */   }
/*      */ 
/*      */   
/*      */   void setValue(String value) {
/* 1070 */     assert isNode();
/*      */     
/* 1072 */     moveNodeContents(null, false);
/*      */     
/* 1074 */     next();
/*      */     
/* 1076 */     insertString(value);
/*      */     
/* 1078 */     toParent();
/*      */   }
/*      */ 
/*      */   
/*      */   void removeFollowingAttrs() {
/* 1083 */     assert isAttr();
/*      */     
/* 1085 */     QName attrName = getName();
/*      */     
/* 1087 */     push();
/*      */     
/* 1089 */     if (toNextAttr())
/*      */     {
/* 1091 */       while (isAttr()) {
/*      */         
/* 1093 */         if (getName().equals(attrName)) {
/* 1094 */           moveNode(null); continue;
/* 1095 */         }  if (!toNextAttr()) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1100 */     pop();
/*      */   }
/*      */ 
/*      */   
/*      */   String getAttrValue(QName name) {
/* 1105 */     String s = null;
/*      */     
/* 1107 */     push();
/*      */     
/* 1109 */     if (toAttr(name)) {
/* 1110 */       s = getValueAsString();
/*      */     }
/* 1112 */     pop();
/*      */     
/* 1114 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   void setAttrValueAsQName(QName name, QName value) {
/* 1119 */     assert isContainer();
/*      */     
/* 1121 */     if (value == null) {
/*      */       
/* 1123 */       this._xobj.removeAttr(name);
/*      */     }
/*      */     else {
/*      */       
/* 1127 */       if (toAttr(name)) {
/*      */         
/* 1129 */         removeFollowingAttrs();
/*      */       }
/*      */       else {
/*      */         
/* 1133 */         next();
/* 1134 */         createAttr(name);
/*      */       } 
/*      */       
/* 1137 */       setValueAsQName(value);
/*      */       
/* 1139 */       toParent();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   boolean removeAttr(QName name) {
/* 1145 */     assert isContainer();
/*      */     
/* 1147 */     return this._xobj.removeAttr(name);
/*      */   }
/*      */ 
/*      */   
/*      */   void setAttrValue(QName name, String value) {
/* 1152 */     assert isContainer();
/*      */     
/* 1154 */     this._xobj.setAttr(name, value);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toAttr(QName name) {
/* 1159 */     assert isNode();
/*      */     
/* 1161 */     Xobj a = this._xobj.getAttr(name);
/*      */     
/* 1163 */     if (a == null) {
/* 1164 */       return false;
/*      */     }
/* 1166 */     moveTo(a);
/*      */     
/* 1168 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toFirstAttr() {
/* 1173 */     assert isNode();
/*      */     
/* 1175 */     Xobj firstAttr = this._xobj.firstAttr();
/*      */     
/* 1177 */     if (firstAttr == null) {
/* 1178 */       return false;
/*      */     }
/* 1180 */     moveTo(firstAttr);
/*      */     
/* 1182 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toLastAttr() {
/* 1187 */     assert isNode();
/*      */     
/* 1189 */     if (!toFirstAttr()) {
/* 1190 */       return false;
/*      */     }
/* 1192 */     while (toNextAttr());
/*      */ 
/*      */     
/* 1195 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toNextAttr() {
/* 1200 */     assert isAttr() || isContainer();
/*      */     
/* 1202 */     Xobj nextAttr = this._xobj.nextAttr();
/*      */     
/* 1204 */     if (nextAttr == null) {
/* 1205 */       return false;
/*      */     }
/* 1207 */     moveTo(nextAttr);
/*      */     
/* 1209 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean toPrevAttr() {
/* 1214 */     if (isAttr()) {
/*      */       
/* 1216 */       if (this._xobj._prevSibling == null) {
/* 1217 */         moveTo(this._xobj.ensureParent());
/*      */       } else {
/* 1219 */         moveTo(this._xobj._prevSibling);
/*      */       } 
/* 1221 */       return true;
/*      */     } 
/*      */     
/* 1224 */     prev();
/*      */     
/* 1226 */     if (!isContainer()) {
/*      */       
/* 1228 */       next();
/* 1229 */       return false;
/*      */     } 
/*      */     
/* 1232 */     return toLastAttr();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean skipWithAttrs() {
/* 1237 */     assert isNode();
/*      */     
/* 1239 */     if (skip()) {
/* 1240 */       return true;
/*      */     }
/* 1242 */     if (this._xobj.isRoot()) {
/* 1243 */       return false;
/*      */     }
/* 1245 */     assert this._xobj.isAttr();
/*      */     
/* 1247 */     toParent();
/*      */     
/* 1249 */     next();
/*      */     
/* 1251 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean skip() {
/* 1256 */     assert isNode();
/*      */     
/* 1258 */     if (this._xobj.isRoot()) {
/* 1259 */       return false;
/*      */     }
/* 1261 */     if (this._xobj.isAttr()) {
/*      */       
/* 1263 */       if (this._xobj._nextSibling == null || !this._xobj._nextSibling.isAttr()) {
/* 1264 */         return false;
/*      */       }
/* 1266 */       moveTo(this._xobj._nextSibling, 0);
/*      */     } else {
/*      */       
/* 1269 */       moveTo(getNormal(this._xobj, this._xobj.posAfter()), this._posTemp);
/*      */     } 
/* 1271 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   void toEnd() {
/* 1276 */     assert isNode();
/*      */     
/* 1278 */     moveTo(this._xobj, -1);
/*      */   }
/*      */ 
/*      */   
/*      */   void moveToCharNode(DomImpl.CharNode node) {
/* 1283 */     assert node.getDom() != null && node.getDom().locale() == this._locale;
/*      */     
/* 1285 */     moveToDom(node.getDom());
/*      */ 
/*      */ 
/*      */     
/* 1289 */     this._xobj.ensureOccupancy();
/*      */     
/* 1291 */     DomImpl.CharNode n = this._xobj._charNodesValue = updateCharNodes(this._locale, this._xobj, this._xobj._charNodesValue, this._xobj._cchValue);
/*      */ 
/*      */     
/* 1294 */     for (; n != null; n = n._next) {
/*      */       
/* 1296 */       if (node == n) {
/*      */         
/* 1298 */         moveTo(getNormal(this._xobj, n._off + 1), this._posTemp);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1303 */     n = this._xobj._charNodesAfter = updateCharNodes(this._locale, this._xobj, this._xobj._charNodesAfter, this._xobj._cchAfter);
/*      */ 
/*      */     
/* 1306 */     for (; n != null; n = n._next) {
/*      */       
/* 1308 */       if (node == n) {
/*      */         
/* 1310 */         moveTo(getNormal(this._xobj, n._off + this._xobj._cchValue + 2), this._posTemp);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     assert false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean prevWithAttrs() {
/* 1320 */     if (prev()) {
/* 1321 */       return true;
/*      */     }
/* 1323 */     if (!isAttr()) {
/* 1324 */       return false;
/*      */     }
/* 1326 */     toParent();
/*      */     
/* 1328 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean prev() {
/* 1333 */     assert isPositioned();
/*      */     
/* 1335 */     if (this._xobj.isRoot() && this._pos == 0) {
/* 1336 */       return false;
/*      */     }
/* 1338 */     if (this._xobj.isAttr() && this._pos == 0 && this._xobj._prevSibling == null) {
/* 1339 */       return false;
/*      */     }
/* 1341 */     Xobj x = getDenormal();
/* 1342 */     int p = this._posTemp;
/*      */     
/* 1344 */     assert p > 0 && p != -1;
/*      */     
/* 1346 */     int pa = x.posAfter();
/*      */     
/* 1348 */     if (p > pa) {
/* 1349 */       p = pa;
/* 1350 */     } else if (p == pa) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1358 */       if (x.isAttr() && (x._cchAfter > 0 || x._nextSibling == null || !x._nextSibling.isAttr())) {
/*      */ 
/*      */         
/* 1361 */         x = x.ensureParent();
/* 1362 */         p = 0;
/*      */       } else {
/*      */         
/* 1365 */         p = -1;
/*      */       } 
/* 1367 */     } else if (p == pa - 1) {
/*      */       
/* 1369 */       x.ensureOccupancy();
/* 1370 */       p = (x._cchValue > 0) ? 1 : 0;
/*      */     }
/* 1372 */     else if (p > 1) {
/* 1373 */       p = 1;
/*      */     } else {
/*      */       
/* 1376 */       assert p == 1;
/* 1377 */       p = 0;
/*      */     } 
/*      */     
/* 1380 */     moveTo(getNormal(x, p), this._posTemp);
/*      */     
/* 1382 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean next(boolean withAttrs) {
/* 1387 */     return withAttrs ? nextWithAttrs() : next();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean nextWithAttrs() {
/* 1392 */     int k = kind();
/*      */     
/* 1394 */     if (kindIsContainer(k)) {
/*      */       
/* 1396 */       if (toFirstAttr()) {
/* 1397 */         return true;
/*      */       }
/* 1399 */     } else if (k == -3) {
/*      */       
/* 1401 */       if (next()) {
/* 1402 */         return true;
/*      */       }
/* 1404 */       toParent();
/*      */       
/* 1406 */       if (!toParentRaw()) {
/* 1407 */         return false;
/*      */       }
/*      */     } 
/* 1410 */     return next();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean next() {
/* 1415 */     assert isNormal();
/*      */     
/* 1417 */     Xobj x = this._xobj;
/* 1418 */     int p = this._pos;
/*      */     
/* 1420 */     int pa = x.posAfter();
/*      */     
/* 1422 */     if (p >= pa) {
/* 1423 */       p = this._xobj.posMax();
/* 1424 */     } else if (p == -1) {
/*      */       
/* 1426 */       if (x.isRoot() || (x.isAttr() && (x._nextSibling == null || !x._nextSibling.isAttr()))) {
/* 1427 */         return false;
/*      */       }
/* 1429 */       p = pa;
/*      */     }
/* 1431 */     else if (p > 0) {
/*      */       
/* 1433 */       assert x._firstChild == null || !x._firstChild.isAttr();
/*      */       
/* 1435 */       if (x._firstChild != null) {
/*      */         
/* 1437 */         x = x._firstChild;
/* 1438 */         p = 0;
/*      */       } else {
/*      */         
/* 1441 */         p = -1;
/*      */       } 
/*      */     } else {
/*      */       
/* 1445 */       assert p == 0;
/*      */       
/* 1447 */       x.ensureOccupancy();
/*      */       
/* 1449 */       p = 1;
/*      */       
/* 1451 */       if (x._cchValue == 0)
/*      */       {
/* 1453 */         if (x._firstChild != null)
/*      */         {
/* 1455 */           if (x._firstChild.isAttr()) {
/*      */             
/* 1457 */             Xobj a = x._firstChild;
/*      */             
/* 1459 */             while (a._nextSibling != null && a._nextSibling.isAttr()) {
/* 1460 */               a = a._nextSibling;
/*      */             }
/* 1462 */             if (a._cchAfter > 0)
/*      */             {
/* 1464 */               x = a;
/* 1465 */               p = a.posAfter();
/*      */             }
/* 1467 */             else if (a._nextSibling != null)
/*      */             {
/* 1469 */               x = a._nextSibling;
/* 1470 */               p = 0;
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1475 */             x = x._firstChild;
/* 1476 */             p = 0;
/*      */           } 
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/* 1482 */     moveTo(getNormal(x, p), this._posTemp);
/*      */     
/* 1484 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   int prevChars(int cch) {
/* 1489 */     assert isPositioned();
/*      */     
/* 1491 */     int cchLeft = cchLeft();
/*      */     
/* 1493 */     if (cch < 0 || cch > cchLeft) {
/* 1494 */       cch = cchLeft;
/*      */     }
/*      */ 
/*      */     
/* 1498 */     if (cch != 0) {
/* 1499 */       moveTo(getNormal(getDenormal(), this._posTemp - cch), this._posTemp);
/*      */     }
/* 1501 */     return cch;
/*      */   }
/*      */ 
/*      */   
/*      */   int nextChars(int cch) {
/* 1506 */     assert isPositioned();
/*      */     
/* 1508 */     int cchRight = cchRight();
/*      */     
/* 1510 */     if (cchRight == 0) {
/* 1511 */       return 0;
/*      */     }
/* 1513 */     if (cch < 0 || cch >= cchRight) {
/*      */ 
/*      */       
/* 1516 */       next();
/* 1517 */       return cchRight;
/*      */     } 
/*      */     
/* 1520 */     moveTo(getNormal(this._xobj, this._pos + cch), this._posTemp);
/*      */     
/* 1522 */     return cch;
/*      */   }
/*      */ 
/*      */   
/*      */   void setCharNodes(DomImpl.CharNode nodes) {
/* 1527 */     assert nodes == null || this._locale == nodes.locale();
/* 1528 */     assert isPositioned();
/*      */     
/* 1530 */     Xobj x = getDenormal();
/* 1531 */     int p = this._posTemp;
/*      */     
/* 1533 */     assert !x.isRoot() || (p > 0 && p < x.posAfter());
/*      */     
/* 1535 */     if (p >= x.posAfter()) {
/* 1536 */       x._charNodesAfter = nodes;
/*      */     } else {
/* 1538 */       x._charNodesValue = nodes;
/*      */     } 
/* 1540 */     for (; nodes != null; nodes = nodes._next) {
/* 1541 */       nodes.setDom((DomImpl.Dom)x);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   DomImpl.CharNode getCharNodes() {
/*      */     DomImpl.CharNode nodes;
/* 1549 */     assert isPositioned();
/* 1550 */     assert !isRoot();
/*      */     
/* 1552 */     Xobj x = getDenormal();
/*      */ 
/*      */ 
/*      */     
/* 1556 */     if (this._posTemp >= x.posAfter()) {
/*      */       
/* 1558 */       nodes = x._charNodesAfter = updateCharNodes(this._locale, x, x._charNodesAfter, x._cchAfter);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1563 */       x.ensureOccupancy();
/*      */       
/* 1565 */       nodes = x._charNodesValue = updateCharNodes(this._locale, x, x._charNodesValue, x._cchValue);
/*      */     } 
/*      */ 
/*      */     
/* 1569 */     return nodes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static DomImpl.CharNode updateCharNodes(Locale l, Xobj x, DomImpl.CharNode nodes, int cch) {
/* 1575 */     assert nodes == null || nodes.locale() == l;
/*      */     
/* 1577 */     DomImpl.CharNode node = nodes;
/* 1578 */     int i = 0;
/*      */     
/* 1580 */     while (node != null && cch > 0) {
/*      */       
/* 1582 */       assert node.getDom() == x;
/*      */       
/* 1584 */       if (node._cch > cch) {
/* 1585 */         node._cch = cch;
/*      */       }
/* 1587 */       node._off = i;
/* 1588 */       i += node._cch;
/* 1589 */       cch -= node._cch;
/*      */       
/* 1591 */       node = node._next;
/*      */     } 
/*      */     
/* 1594 */     if (cch <= 0) {
/*      */       
/* 1596 */       for (; node != null; node = node._next)
/*      */       {
/* 1598 */         assert node.getDom() == x;
/*      */         
/* 1600 */         if (node._cch != 0) {
/* 1601 */           node._cch = 0;
/*      */         }
/* 1603 */         node._off = i;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1608 */       node = l.createTextNode();
/* 1609 */       node.setDom((DomImpl.Dom)x);
/* 1610 */       node._cch = cch;
/* 1611 */       node._off = i;
/* 1612 */       nodes = DomImpl.CharNode.appendNode(nodes, node);
/*      */     } 
/*      */     
/* 1615 */     return nodes;
/*      */   }
/*      */ 
/*      */   
/*      */   final QName getXsiTypeName() {
/* 1620 */     assert isNode();
/*      */     
/* 1622 */     return this._xobj.getXsiTypeName();
/*      */   }
/*      */ 
/*      */   
/*      */   final void setXsiType(QName value) {
/* 1627 */     assert isContainer();
/*      */     
/* 1629 */     setAttrValueAsQName(Locale._xsiType, value);
/*      */   }
/*      */ 
/*      */   
/*      */   final QName valueAsQName() {
/* 1634 */     throw new RuntimeException("Not implemented");
/*      */   }
/*      */ 
/*      */   
/*      */   final String namespaceForPrefix(String prefix, boolean defaultAlwaysMapped) {
/* 1639 */     return this._xobj.namespaceForPrefix(prefix, defaultAlwaysMapped);
/*      */   }
/*      */ 
/*      */   
/*      */   final String prefixForNamespace(String ns, String suggestion, boolean createIfMissing) {
/* 1644 */     return (isContainer() ? this._xobj : getParent()).prefixForNamespace(ns, suggestion, createIfMissing);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean contains(Cur that) {
/* 1653 */     assert isNode();
/* 1654 */     assert that != null && that.isPositioned();
/*      */     
/* 1656 */     return this._xobj.contains(that);
/*      */   }
/*      */ 
/*      */   
/*      */   void insertString(String s) {
/* 1661 */     if (s != null) {
/* 1662 */       insertChars(s, 0, s.length());
/*      */     }
/*      */   }
/*      */   
/*      */   void insertChars(Object src, int off, int cch) {
/* 1667 */     assert isPositioned() && !isRoot();
/* 1668 */     assert CharUtil.isValid(src, off, cch);
/*      */ 
/*      */ 
/*      */     
/* 1672 */     if (cch <= 0) {
/*      */       return;
/*      */     }
/* 1675 */     this._locale.notifyChange();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1683 */     if (this._pos == -1) {
/* 1684 */       this._xobj.ensureOccupancy();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1689 */     Xobj x = getDenormal();
/* 1690 */     int p = this._posTemp;
/*      */     
/* 1692 */     assert p > 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1698 */     x.insertCharsHelper(p, src, off, cch, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1704 */     moveTo(x, p);
/*      */     
/* 1706 */     this._locale._versionAll++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object moveChars(Cur to, int cchMove) {
/* 1714 */     assert isPositioned();
/* 1715 */     assert cchMove <= 0 || cchMove <= cchRight();
/* 1716 */     assert to == null || (to.isPositioned() && !to.isRoot());
/*      */     
/* 1718 */     if (cchMove < 0) {
/* 1719 */       cchMove = cchRight();
/*      */     }
/*      */ 
/*      */     
/* 1723 */     if (cchMove == 0) {
/*      */       
/* 1725 */       this._offSrc = 0;
/* 1726 */       this._cchSrc = 0;
/*      */       
/* 1728 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1734 */     Object srcMoved = getChars(cchMove);
/* 1735 */     int offMoved = this._offSrc;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1740 */     assert isText() && ((this._pos >= this._xobj.posAfter()) ? this._xobj._parent : this._xobj).isOccupied();
/*      */     
/* 1742 */     if (to == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1749 */       for (Xobj.Bookmark b = this._xobj._bookmarks; b != null; b = b._next)
/*      */       {
/* 1751 */         if (inChars(b, cchMove, false))
/*      */         {
/* 1753 */           Cur c = this._locale.tempCur();
/*      */           
/* 1755 */           c.createRoot();
/* 1756 */           c.next();
/*      */           
/* 1758 */           Object chars = moveChars(c, cchMove);
/*      */           
/* 1760 */           c.release();
/*      */           
/* 1762 */           return chars;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1776 */       if (inChars(to, cchMove, true)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1781 */         to.moveToCur(this);
/* 1782 */         nextChars(cchMove);
/*      */         
/* 1784 */         this._offSrc = offMoved;
/* 1785 */         this._cchSrc = cchMove;
/*      */         
/* 1787 */         return srcMoved;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1792 */       to.insertChars(srcMoved, offMoved, cchMove);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1800 */     this._locale.notifyChange();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1805 */     if (to == null) {
/* 1806 */       this._xobj.removeCharsHelper(this._pos, cchMove, null, -2, false, true);
/*      */     } else {
/* 1808 */       this._xobj.removeCharsHelper(this._pos, cchMove, to._xobj, to._pos, false, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1816 */     this._locale._versionAll++;
/*      */     
/* 1818 */     this._offSrc = offMoved;
/* 1819 */     this._cchSrc = cchMove;
/*      */     
/* 1821 */     return srcMoved;
/*      */   }
/*      */ 
/*      */   
/*      */   void moveNode(Cur to) {
/* 1826 */     assert isNode() && !isRoot();
/* 1827 */     assert to == null || to.isPositioned();
/* 1828 */     assert to == null || !contains(to);
/* 1829 */     assert to == null || !to.isRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1838 */     Xobj x = this._xobj;
/*      */     
/* 1840 */     skip();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1846 */     moveNode(x, to);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void transferChars(Xobj xFrom, int pFrom, Xobj xTo, int pTo, int cch) {
/* 1857 */     assert xFrom != xTo;
/* 1858 */     assert xFrom._locale == xTo._locale;
/* 1859 */     assert pFrom > 0 && pFrom < xFrom.posMax();
/* 1860 */     assert pTo > 0 && pTo <= xTo.posMax();
/* 1861 */     assert cch > 0 && cch <= xFrom.cchRight(pFrom);
/* 1862 */     assert pTo >= xTo.posAfter() || xTo.isOccupied();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1869 */     xTo.insertCharsHelper(pTo, xFrom.getCharsHelper(pFrom, cch), xFrom._locale._offSrc, xFrom._locale._cchSrc, false);
/*      */ 
/*      */ 
/*      */     
/* 1873 */     xFrom.removeCharsHelper(pFrom, cch, xTo, pTo, true, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void moveNode(Xobj x, Cur to) {
/* 1880 */     assert x != null && !x.isRoot();
/* 1881 */     assert to == null || to.isPositioned();
/* 1882 */     assert to == null || !x.contains(to);
/* 1883 */     assert to == null || !to.isRoot();
/*      */     
/* 1885 */     if (to != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1891 */       if (to._pos == -1) {
/* 1892 */         to._xobj.ensureOccupancy();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1899 */       if ((to._pos == 0 && to._xobj == x) || to.isJustAfterEnd(x)) {
/*      */ 
/*      */ 
/*      */         
/* 1903 */         to.moveTo(x);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1910 */     x._locale.notifyChange();
/*      */     
/* 1912 */     x._locale._versionAll++;
/* 1913 */     x._locale._versionSansText++;
/*      */     
/* 1915 */     if (to != null && to._locale != x._locale) {
/*      */       
/* 1917 */       to._locale.notifyChange();
/*      */       
/* 1919 */       to._locale._versionAll++;
/* 1920 */       to._locale._versionSansText++;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1926 */     if (x.isAttr()) {
/* 1927 */       x.invalidateSpecialAttr((to == null) ? null : to.getParentRaw());
/*      */     } else {
/*      */       
/* 1930 */       if (x._parent != null) {
/* 1931 */         x._parent.invalidateUser();
/*      */       }
/* 1933 */       if (to != null && to.hasParent()) {
/* 1934 */         to.getParent().invalidateUser();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1944 */     if (x._cchAfter > 0) {
/* 1945 */       transferChars(x, x.posAfter(), x.getDenormal(0), x.posTemp(), x._cchAfter);
/*      */     }
/* 1947 */     assert x._cchAfter == 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1953 */     x._locale.embedCurs();
/*      */     
/* 1955 */     for (Xobj y = x; y != null; y = y.walk(x, true)) {
/*      */       
/* 1957 */       while (y._embedded != null) {
/* 1958 */         y._embedded.moveTo(x.getNormal(x.posAfter()));
/*      */       }
/* 1960 */       y.disconnectUser();
/*      */       
/* 1962 */       if (to != null) {
/* 1963 */         y._locale = to._locale;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1968 */     x.removeXobj();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1973 */     if (to != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1979 */       Xobj here = to._xobj;
/* 1980 */       boolean append = (to._pos != 0);
/*      */       
/* 1982 */       int cchRight = to.cchRight();
/*      */       
/* 1984 */       if (cchRight > 0) {
/*      */         
/* 1986 */         to.push();
/* 1987 */         to.next();
/* 1988 */         here = to._xobj;
/* 1989 */         append = (to._pos != 0);
/* 1990 */         to.pop();
/*      */       } 
/*      */       
/* 1993 */       if (append) {
/* 1994 */         here.appendXobj(x);
/*      */       } else {
/* 1996 */         here.insertXobj(x);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2001 */       if (cchRight > 0) {
/* 2002 */         transferChars(to._xobj, to._pos, x, x.posAfter(), cchRight);
/*      */       }
/* 2004 */       to.moveTo(x);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void moveNodeContents(Cur to, boolean moveAttrs) {
/* 2010 */     assert this._pos == 0;
/* 2011 */     assert to == null || !to.isRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2016 */     moveNodeContents(this._xobj, to, moveAttrs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void moveNodeContents(Xobj x, Cur to, boolean moveAttrs) {
/* 2023 */     assert to == null || !to.isRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2028 */     boolean hasAttrs = x.hasAttrs();
/* 2029 */     boolean noSubNodesToMove = (!x.hasChildren() && (!moveAttrs || !hasAttrs));
/*      */ 
/*      */ 
/*      */     
/* 2033 */     if (noSubNodesToMove) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2039 */       if (x.isVacant() && to == null) {
/*      */         
/* 2041 */         x.clearBit(256);
/*      */         
/* 2043 */         x.invalidateUser();
/* 2044 */         x.invalidateSpecialAttr(null);
/* 2045 */         x._locale._versionAll++;
/*      */       }
/* 2047 */       else if (x.hasTextEnsureOccupancy()) {
/*      */         
/* 2049 */         Cur c = x.tempCur();
/* 2050 */         c.next();
/* 2051 */         c.moveChars(to, -1);
/* 2052 */         c.release();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 2061 */     if (to != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2066 */       if (x == to._xobj && to._pos == -1) {
/*      */ 
/*      */ 
/*      */         
/* 2070 */         to.moveTo(x);
/* 2071 */         to.next((moveAttrs && hasAttrs));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2081 */       boolean isAtLeftEdge = false;
/*      */       
/* 2083 */       if (to._locale == x._locale) {
/*      */         
/* 2085 */         to.push();
/* 2086 */         to.moveTo(x);
/* 2087 */         to.next((moveAttrs && hasAttrs));
/* 2088 */         isAtLeftEdge = to.isAtLastPush();
/* 2089 */         to.pop();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2094 */       if (isAtLeftEdge) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 2099 */       assert !x.contains(to);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2105 */       assert to.getParent().isOccupied();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2114 */     int valueMovedCch = 0;
/*      */     
/* 2116 */     if (x.hasTextNoEnsureOccupancy()) {
/*      */       
/* 2118 */       Cur c = x.tempCur();
/* 2119 */       c.next();
/* 2120 */       c.moveChars(to, -1);
/* 2121 */       c.release();
/*      */       
/* 2123 */       if (to != null) {
/* 2124 */         to.nextChars(valueMovedCch = c._cchSrc);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2131 */     x._locale.embedCurs();
/*      */     
/* 2133 */     Xobj firstToMove = x.walk(x, true);
/* 2134 */     boolean sawBookmark = false;
/*      */     
/* 2136 */     Xobj y = firstToMove; while (true) { if (y != null)
/*      */       
/* 2138 */       { if (y._parent == x && y.isAttr())
/*      */         
/* 2140 */         { assert y._cchAfter == 0;
/*      */           
/* 2142 */           if (!moveAttrs)
/*      */           
/* 2144 */           { firstToMove = y._nextSibling; }
/*      */           
/*      */           else
/*      */           
/* 2148 */           { y.invalidateSpecialAttr((to == null) ? null : to.getParent());
/*      */             
/*      */             Cur c;
/* 2151 */             while ((c = y._embedded) != null)
/* 2152 */               c.moveTo(x, -1);  }  continue; }  } else { break; }  Cur cur; while ((cur = y._embedded) != null) cur.moveTo(x, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       y = y.walk(x, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2162 */     Xobj lastToMove = x._lastChild;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2170 */     Cur surragateTo = null;
/*      */     
/* 2172 */     if (sawBookmark && to == null) {
/*      */       
/* 2174 */       surragateTo = to = x._locale.tempCur();
/* 2175 */       to.createRoot();
/* 2176 */       to.next();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2183 */     if (!lastToMove.isAttr()) {
/* 2184 */       x.invalidateUser();
/*      */     }
/* 2186 */     x._locale._versionAll++;
/* 2187 */     x._locale._versionSansText++;
/*      */     
/* 2189 */     if (to != null && valueMovedCch == 0) {
/*      */       
/* 2191 */       to.getParent().invalidateUser();
/* 2192 */       to._locale._versionAll++;
/* 2193 */       to._locale._versionSansText++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2198 */     x.removeXobjs(firstToMove, lastToMove);
/*      */     
/* 2200 */     if (to != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2205 */       Xobj here = to._xobj;
/* 2206 */       boolean append = (to._pos != 0);
/*      */       
/* 2208 */       int cchRight = to.cchRight();
/*      */       
/* 2210 */       if (cchRight > 0) {
/*      */         
/* 2212 */         to.push();
/* 2213 */         to.next();
/* 2214 */         here = to._xobj;
/* 2215 */         append = (to._pos != 0);
/* 2216 */         to.pop();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2230 */       if (firstToMove.isAttr()) {
/*      */         
/* 2232 */         Xobj lastNewAttr = firstToMove;
/*      */         
/* 2234 */         while (lastNewAttr._nextSibling != null && lastNewAttr._nextSibling.isAttr()) {
/* 2235 */           lastNewAttr = lastNewAttr._nextSibling;
/*      */         }
/*      */ 
/*      */         
/* 2239 */         Xobj xobj1 = to.getParent();
/*      */         
/* 2241 */         if (cchRight > 0) {
/* 2242 */           transferChars(to._xobj, to._pos, lastNewAttr, lastNewAttr.posMax(), cchRight);
/*      */         }
/* 2244 */         if (xobj1.hasTextNoEnsureOccupancy()) {
/*      */           int p, cch;
/*      */ 
/*      */           
/* 2248 */           if (xobj1._cchValue > 0) {
/*      */             
/* 2250 */             p = 1;
/* 2251 */             cch = xobj1._cchValue;
/*      */           }
/*      */           else {
/*      */             
/* 2255 */             xobj1 = xobj1.lastAttr();
/* 2256 */             p = xobj1.posAfter();
/* 2257 */             cch = xobj1._cchAfter;
/*      */           } 
/*      */           
/* 2260 */           transferChars(xobj1, p, lastNewAttr, lastNewAttr.posAfter(), cch);
/*      */         }
/*      */       
/* 2263 */       } else if (cchRight > 0) {
/* 2264 */         transferChars(to._xobj, to._pos, lastToMove, lastToMove.posMax(), cchRight);
/*      */       } 
/*      */ 
/*      */       
/* 2268 */       if (append) {
/* 2269 */         here.appendXobjs(firstToMove, lastToMove);
/*      */       } else {
/* 2271 */         here.insertXobjs(firstToMove, lastToMove);
/*      */       } 
/*      */ 
/*      */       
/* 2275 */       to.moveTo(firstToMove);
/* 2276 */       to.prevChars(valueMovedCch);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2281 */     if (surragateTo != null) {
/* 2282 */       surragateTo.release();
/*      */     }
/*      */   }
/*      */   
/*      */   protected final Xobj.Bookmark setBookmark(Object key, Object value) {
/* 2287 */     assert isNormal();
/* 2288 */     assert key != null;
/*      */     
/* 2290 */     return this._xobj.setBookmark(this._pos, key, value);
/*      */   }
/*      */ 
/*      */   
/*      */   Object getBookmark(Object key) {
/* 2295 */     assert isNormal();
/* 2296 */     assert key != null;
/*      */     
/* 2298 */     for (Xobj.Bookmark b = this._xobj._bookmarks; b != null; b = b._next) {
/* 2299 */       if (b._pos == this._pos && b._key == key)
/* 2300 */         return b._value; 
/*      */     } 
/* 2302 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   int firstBookmarkInChars(Object key, int cch) {
/* 2307 */     assert isNormal();
/* 2308 */     assert key != null;
/* 2309 */     assert cch > 0;
/* 2310 */     assert cch <= cchRight();
/*      */     
/* 2312 */     int d = -1;
/*      */     
/* 2314 */     if (isText())
/*      */     {
/* 2316 */       for (Xobj.Bookmark b = this._xobj._bookmarks; b != null; b = b._next) {
/* 2317 */         if (b._key == key && inChars(b, cch, false))
/* 2318 */           d = (d == -1 || b._pos - this._pos < d) ? (b._pos - this._pos) : d; 
/*      */       } 
/*      */     }
/* 2321 */     return d;
/*      */   }
/*      */ 
/*      */   
/*      */   int firstBookmarkInCharsLeft(Object key, int cch) {
/* 2326 */     assert isNormal();
/* 2327 */     assert key != null;
/* 2328 */     assert cch > 0;
/* 2329 */     assert cch <= cchLeft();
/*      */     
/* 2331 */     int d = -1;
/*      */     
/* 2333 */     if (cchLeft() > 0) {
/*      */       
/* 2335 */       Xobj x = getDenormal();
/* 2336 */       int p = this._posTemp - cch;
/*      */       
/* 2338 */       for (Xobj.Bookmark b = x._bookmarks; b != null; b = b._next) {
/* 2339 */         if (b._key == key && x.inChars(p, b._xobj, b._pos, cch, false))
/* 2340 */           d = (d == -1 || b._pos - p < d) ? (b._pos - p) : d; 
/*      */       } 
/*      */     } 
/* 2343 */     return d;
/*      */   }
/*      */ 
/*      */   
/*      */   String getCharsAsString(int cch) {
/* 2348 */     assert isNormal() && this._xobj != null;
/*      */     
/* 2350 */     return getCharsAsString(cch, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   String getCharsAsString(int cch, int wsr) {
/* 2355 */     return this._xobj.getCharsAsString(this._pos, cch, wsr);
/*      */   }
/*      */ 
/*      */   
/*      */   String getValueAsString(int wsr) {
/* 2360 */     assert isNode();
/*      */     
/* 2362 */     return this._xobj.getValueAsString(wsr);
/*      */   }
/*      */ 
/*      */   
/*      */   String getValueAsString() {
/* 2367 */     assert isNode();
/* 2368 */     assert !hasChildren();
/*      */     
/* 2370 */     return this._xobj.getValueAsString();
/*      */   }
/*      */ 
/*      */   
/*      */   Object getChars(int cch) {
/* 2375 */     assert isPositioned();
/*      */     
/* 2377 */     return this._xobj.getChars(this._pos, cch, this);
/*      */   }
/*      */ 
/*      */   
/*      */   Object getFirstChars() {
/* 2382 */     assert isNode();
/*      */     
/* 2384 */     Object src = this._xobj.getFirstChars();
/*      */     
/* 2386 */     this._offSrc = this._locale._offSrc;
/* 2387 */     this._cchSrc = this._locale._cchSrc;
/*      */     
/* 2389 */     return src;
/*      */   }
/*      */ 
/*      */   
/*      */   void copyNode(Cur to) {
/* 2394 */     assert to != null;
/* 2395 */     assert isNode();
/*      */     
/* 2397 */     Xobj copy = this._xobj.copyNode(to._locale);
/*      */ 
/*      */ 
/*      */     
/* 2401 */     if (to.isPositioned()) {
/* 2402 */       moveNode(copy, to);
/*      */     } else {
/* 2404 */       to.moveTo(copy);
/*      */     } 
/*      */   }
/*      */   
/*      */   Cur weakCur(Object o) {
/* 2409 */     Cur c = this._locale.weakCur(o);
/* 2410 */     c.moveToCur(this);
/* 2411 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   Cur tempCur() {
/* 2416 */     return tempCur(null);
/*      */   }
/*      */ 
/*      */   
/*      */   Cur tempCur(String id) {
/* 2421 */     Cur c = this._locale.tempCur(id);
/* 2422 */     c.moveToCur(this);
/* 2423 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private Cur tempCur(Xobj x, int p) {
/* 2428 */     assert this._locale == x._locale;
/* 2429 */     assert x != null || p == -2;
/*      */     
/* 2431 */     Cur c = this._locale.tempCur();
/*      */     
/* 2433 */     if (x != null) {
/* 2434 */       c.moveTo(getNormal(x, p), this._posTemp);
/*      */     }
/* 2436 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean inChars(Cur c, int cch, boolean includeEnd) {
/* 2445 */     assert isPositioned() && isText() && cchRight() >= cch;
/* 2446 */     assert c.isNormal();
/*      */     
/* 2448 */     return this._xobj.inChars(this._pos, c._xobj, c._pos, cch, includeEnd);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean inChars(Xobj.Bookmark b, int cch, boolean includeEnd) {
/* 2453 */     assert isPositioned() && isText() && cchRight() >= cch;
/* 2454 */     assert b._xobj.isNormal(b._pos);
/*      */     
/* 2456 */     return this._xobj.inChars(this._pos, b._xobj, b._pos, cch, includeEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Xobj getNormal(Xobj x, int p) {
/* 2464 */     Xobj nx = x.getNormal(p);
/* 2465 */     this._posTemp = x._locale._posTemp;
/* 2466 */     return nx;
/*      */   }
/*      */ 
/*      */   
/*      */   private Xobj getDenormal() {
/* 2471 */     assert isPositioned();
/*      */     
/* 2473 */     return getDenormal(this._xobj, this._pos);
/*      */   }
/*      */ 
/*      */   
/*      */   private Xobj getDenormal(Xobj x, int p) {
/* 2478 */     Xobj dx = x.getDenormal(p);
/* 2479 */     this._posTemp = x._locale._posTemp;
/* 2480 */     return dx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setType(SchemaType type) {
/* 2487 */     setType(type, true);
/*      */   }
/*      */ 
/*      */   
/*      */   void setType(SchemaType type, boolean complain) {
/* 2492 */     assert type != null;
/* 2493 */     assert isUserNode();
/*      */     
/* 2495 */     TypeStoreUser user = peekUser();
/*      */     
/* 2497 */     if (user != null && user.get_schema_type() == type) {
/*      */       return;
/*      */     }
/* 2500 */     if (isRoot()) {
/*      */       
/* 2502 */       this._xobj.setStableType(type);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2508 */     TypeStoreUser parentUser = this._xobj.ensureParent().getUser();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2513 */     if (isAttr()) {
/*      */       
/* 2515 */       if (complain && parentUser.get_attribute_type(getName()) != type)
/*      */       {
/* 2517 */         throw new IllegalArgumentException("Can't set type of attribute to " + type.toString());
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 2525 */     assert isElem();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2530 */     if (parentUser.get_element_type(getName(), null) == type) {
/*      */       
/* 2532 */       removeAttr(Locale._xsiType);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 2539 */     QName typeName = type.getName();
/*      */     
/* 2541 */     if (typeName == null) {
/*      */       
/* 2543 */       if (complain) {
/* 2544 */         throw new IllegalArgumentException("Can't set type of element, type is un-named");
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2551 */     if (parentUser.get_element_type(getName(), typeName) != type) {
/*      */       
/* 2553 */       if (complain) {
/* 2554 */         throw new IllegalArgumentException("Can't set type of element, invalid type");
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/* 2559 */     setAttrValueAsQName(Locale._xsiType, typeName);
/*      */   }
/*      */ 
/*      */   
/*      */   void setSubstitution(QName name, SchemaType type) {
/* 2564 */     setSubstitution(name, type, true);
/*      */   }
/*      */ 
/*      */   
/*      */   void setSubstitution(QName name, SchemaType type, boolean complain) {
/* 2569 */     assert name != null;
/* 2570 */     assert type != null;
/* 2571 */     assert isUserNode();
/*      */     
/* 2573 */     TypeStoreUser user = peekUser();
/*      */     
/* 2575 */     if (user != null && user.get_schema_type() == type && name.equals(getName())) {
/*      */       return;
/*      */     }
/* 2578 */     if (isRoot()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2587 */     TypeStoreUser parentUser = this._xobj.ensureParent().getUser();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2592 */     if (isAttr()) {
/*      */       
/* 2594 */       if (complain)
/*      */       {
/* 2596 */         throw new IllegalArgumentException("Can't use substitution with attributes");
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 2604 */     assert isElem();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2609 */     if (parentUser.get_element_type(name, null) == type) {
/*      */       
/* 2611 */       setName(name);
/* 2612 */       removeAttr(Locale._xsiType);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 2619 */     QName typeName = type.getName();
/*      */     
/* 2621 */     if (typeName == null) {
/*      */       
/* 2623 */       if (complain) {
/* 2624 */         throw new IllegalArgumentException("Can't set xsi:type on element, type is un-named");
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2631 */     if (parentUser.get_element_type(name, typeName) != type) {
/*      */       
/* 2633 */       if (complain) {
/* 2634 */         throw new IllegalArgumentException("Can't set xsi:type on element, invalid type");
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/* 2639 */     setName(name);
/* 2640 */     setAttrValueAsQName(Locale._xsiType, typeName);
/*      */   }
/*      */ 
/*      */   
/*      */   TypeStoreUser peekUser() {
/* 2645 */     assert isUserNode();
/*      */     
/* 2647 */     return this._xobj._user;
/*      */   }
/*      */ 
/*      */   
/*      */   XmlObject getObject() {
/* 2652 */     return isUserNode() ? (XmlObject)getUser() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   TypeStoreUser getUser() {
/* 2657 */     assert isUserNode();
/*      */     
/* 2659 */     return this._xobj.getUser();
/*      */   }
/*      */ 
/*      */   
/*      */   DomImpl.Dom getDom() {
/* 2664 */     assert isNormal();
/* 2665 */     assert isPositioned();
/*      */     
/* 2667 */     if (isText()) {
/*      */       
/* 2669 */       int cch = cchLeft();
/*      */       
/* 2671 */       for (DomImpl.CharNode cn = getCharNodes();; cn = cn._next) {
/* 2672 */         if ((cch -= cn._cch) < 0)
/* 2673 */           return cn; 
/*      */       } 
/*      */     } 
/* 2676 */     return this._xobj.getDom();
/*      */   }
/*      */ 
/*      */   
/*      */   static void release(Cur c) {
/* 2681 */     if (c != null) {
/* 2682 */       c.release();
/*      */     }
/*      */   }
/*      */   
/*      */   void release() {
/* 2687 */     if (this._tempFrame >= 0) {
/*      */       
/* 2689 */       if (this._nextTemp != null) {
/* 2690 */         this._nextTemp._prevTemp = this._prevTemp;
/*      */       }
/* 2692 */       if (this._prevTemp == null) {
/* 2693 */         this._locale._tempFrames[this._tempFrame] = this._nextTemp;
/*      */       } else {
/* 2695 */         this._prevTemp._nextTemp = this._nextTemp;
/*      */       } 
/* 2697 */       this._prevTemp = this._nextTemp = null;
/* 2698 */       this._tempFrame = -1;
/*      */     } 
/*      */     
/* 2701 */     if (this._state != 0 && this._state != 3) {
/*      */ 
/*      */ 
/*      */       
/* 2705 */       while (this._stackTop != -1) {
/* 2706 */         popButStay();
/*      */       }
/* 2708 */       clearSelection();
/*      */       
/* 2710 */       this._id = null;
/*      */ 
/*      */ 
/*      */       
/* 2714 */       moveToCur(null);
/*      */       
/* 2716 */       assert isNormal();
/*      */       
/* 2718 */       assert this._xobj == null;
/* 2719 */       assert this._pos == -2;
/*      */ 
/*      */ 
/*      */       
/* 2723 */       if (this._ref != null) {
/*      */         
/* 2725 */         this._ref.clear();
/* 2726 */         this._ref._cur = null;
/*      */       } 
/*      */       
/* 2729 */       this._ref = null;
/*      */ 
/*      */ 
/*      */       
/* 2733 */       assert this._state == 1;
/* 2734 */       this._locale._registered = listRemove(this._locale._registered);
/*      */       
/* 2736 */       if (this._locale._curPoolCount < 16) {
/*      */         
/* 2738 */         this._locale._curPool = listInsert(this._locale._curPool);
/* 2739 */         this._state = 0;
/* 2740 */         this._locale._curPoolCount++;
/*      */       }
/*      */       else {
/*      */         
/* 2744 */         this._locale = null;
/* 2745 */         this._state = 3;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isOnList(Cur head) {
/* 2752 */     for (; head != null; head = head._next) {
/* 2753 */       if (head == this)
/* 2754 */         return true; 
/*      */     } 
/* 2756 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   Cur listInsert(Cur head) {
/* 2761 */     assert this._next == null && this._prev == null;
/*      */     
/* 2763 */     if (head == null) {
/* 2764 */       head = this._prev = this;
/*      */     } else {
/*      */       
/* 2767 */       this._prev = head._prev;
/* 2768 */       head._prev = head._prev._next = this;
/*      */     } 
/*      */     
/* 2771 */     return head;
/*      */   }
/*      */ 
/*      */   
/*      */   Cur listRemove(Cur head) {
/* 2776 */     assert this._prev != null && isOnList(head);
/*      */     
/* 2778 */     if (this._prev == this) {
/* 2779 */       head = null;
/*      */     } else {
/*      */       
/* 2782 */       if (head == this) {
/* 2783 */         head = this._next;
/*      */       } else {
/* 2785 */         this._prev._next = this._next;
/*      */       } 
/* 2787 */       if (this._next == null) {
/* 2788 */         head._prev = this._prev;
/*      */       } else {
/*      */         
/* 2791 */         this._next._prev = this._prev;
/* 2792 */         this._next = null;
/*      */       } 
/*      */     } 
/*      */     
/* 2796 */     this._prev = null;
/* 2797 */     assert this._next == null;
/*      */     
/* 2799 */     return head;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNormal() {
/* 2809 */     if (this._state == 0 || this._state == 3) {
/* 2810 */       return false;
/*      */     }
/* 2812 */     if (this._xobj == null) {
/* 2813 */       return (this._pos == -2);
/*      */     }
/* 2815 */     if (!this._xobj.isNormal(this._pos)) {
/* 2816 */       return false;
/*      */     }
/* 2818 */     if (this._state == 2) {
/* 2819 */       return isOnList(this._xobj._embedded);
/*      */     }
/* 2821 */     assert this._state == 1;
/*      */     
/* 2823 */     return isOnList(this._locale._registered);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class CurLoadContext
/*      */     extends Locale.LoadContext
/*      */   {
/*      */     private boolean _stripLeft;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Locale _locale;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private CharUtil _charUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Xobj _frontier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _after;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Xobj _lastXobj;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int _lastPos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _discardDocElem;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private QName _replaceDocElem;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _stripWhitespace;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _stripComments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _stripProcinsts;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Map _substituteNamespaces;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Map _additionalNamespaces;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String _doctypeName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String _doctypePublicId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String _doctypeSystemId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final boolean $assertionsDisabled;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void start(Xobj xo) {
/*      */       assert this._frontier != null;
/*      */       assert !this._after || this._frontier._parent != null;
/*      */       flushText();
/*      */       if (this._after) {
/*      */         this._frontier = this._frontier._parent;
/*      */         this._after = false;
/*      */       } 
/*      */       this._frontier.appendXobj(xo);
/*      */       this._frontier = xo;
/*      */       this._lastXobj = xo;
/*      */       this._lastPos = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void end() {
/*      */       assert this._frontier != null;
/*      */       assert !this._after || this._frontier._parent != null;
/*      */       flushText();
/*      */       if (this._after) {
/*      */         this._frontier = this._frontier._parent;
/*      */       } else {
/*      */         this._after = true;
/*      */       } 
/*      */       this._lastXobj = this._frontier;
/*      */       this._lastPos = -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void text(Object src, int off, int cch) {
/*      */       if (cch <= 0) {
/*      */         return;
/*      */       }
/*      */       this._lastXobj = this._frontier;
/*      */       this._lastPos = this._frontier._cchValue + 1;
/*      */       if (this._after) {
/*      */         this._lastPos += this._frontier._cchAfter + 1;
/*      */         this._frontier._srcAfter = this._charUtil.saveChars(src, off, cch, this._frontier._srcAfter, this._frontier._offAfter, this._frontier._cchAfter);
/*      */         this._frontier._offAfter = this._charUtil._offSrc;
/*      */         this._frontier._cchAfter = this._charUtil._cchSrc;
/*      */       } else {
/*      */         this._frontier._srcValue = this._charUtil.saveChars(src, off, cch, this._frontier._srcValue, this._frontier._offValue, this._frontier._cchValue);
/*      */         this._frontier._offValue = this._charUtil._offSrc;
/*      */         this._frontier._cchValue = this._charUtil._cchSrc;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void flushText() {
/*      */       if (this._stripWhitespace) {
/*      */         if (this._after) {
/*      */           this._frontier._srcAfter = this._charUtil.stripRight(this._frontier._srcAfter, this._frontier._offAfter, this._frontier._cchAfter);
/*      */           this._frontier._offAfter = this._charUtil._offSrc;
/*      */           this._frontier._cchAfter = this._charUtil._cchSrc;
/*      */         } else {
/*      */           this._frontier._srcValue = this._charUtil.stripRight(this._frontier._srcValue, this._frontier._offValue, this._frontier._cchValue);
/*      */           this._frontier._offValue = this._charUtil._offSrc;
/*      */           this._frontier._cchValue = this._charUtil._cchSrc;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     CurLoadContext(Locale l, XmlOptions options) {
/* 3114 */       this._stripLeft = true; options = XmlOptions.maskNull(options); this._locale = l; this._charUtil = options.hasOption("LOAD_USE_LOCALE_CHAR_UTIL") ? this._locale.getCharUtil() : CharUtil.getThreadLocalCharUtil(); this._frontier = Cur.createDomDocumentRootXobj(this._locale); this._after = false; this._lastXobj = this._frontier; this._lastPos = 0; if (options.hasOption("LOAD_REPLACE_DOCUMENT_ELEMENT")) { this._replaceDocElem = (QName)options.get("LOAD_REPLACE_DOCUMENT_ELEMENT"); this._discardDocElem = true; }  this._stripWhitespace = options.hasOption("LOAD_STRIP_WHITESPACE"); this._stripComments = options.hasOption("LOAD_STRIP_COMMENTS"); this._stripProcinsts = options.hasOption("LOAD_STRIP_PROCINSTS"); this._substituteNamespaces = (Map)options.get("LOAD_SUBSTITUTE_NAMESPACES"); this._additionalNamespaces = (Map)options.get("LOAD_ADDITIONAL_NAMESPACES"); this._locale._versionAll++; this._locale._versionSansText++;
/*      */     } private Xobj parent() { return this._after ? this._frontier._parent : this._frontier; } private QName checkName(QName name, boolean local) { if (this._substituteNamespaces != null && (!local || name.getNamespaceURI().length() > 0)) { String substituteUri = (String)this._substituteNamespaces.get(name.getNamespaceURI()); if (substituteUri != null)
/*      */           name = this._locale.makeQName(substituteUri, name.getLocalPart(), name.getPrefix());  }  return name; } protected void startDTD(String name, String publicId, String systemId) { this._doctypeName = name; this._doctypePublicId = publicId; this._doctypeSystemId = systemId; }
/*      */     protected void endDTD() {}
/* 3118 */     private void stripText(Object src, int off, int cch) { if (this._stripWhitespace)
/*      */       {
/*      */         
/* 3121 */         if (this._stripLeft) {
/*      */           
/* 3123 */           src = this._charUtil.stripLeft(src, off, cch);
/* 3124 */           this._stripLeft = false;
/* 3125 */           off = this._charUtil._offSrc;
/* 3126 */           cch = this._charUtil._cchSrc;
/*      */         } 
/*      */       }
/*      */       
/* 3130 */       text(src, off, cch); }
/*      */     protected void startElement(QName name) { start(Cur.createElementXobj(this._locale, checkName(name, false), (parent())._name));
/*      */       this._stripLeft = true; }
/*      */     protected void endElement() { assert parent().isElem();
/*      */       end();
/* 3135 */       this._stripLeft = true; } protected void text(String s) { if (s == null) {
/*      */         return;
/*      */       }
/* 3138 */       stripText(s, 0, s.length()); }
/*      */     protected void xmlns(String prefix, String uri) { assert parent().isContainer(); if (this._substituteNamespaces != null) { String substituteUri = (String)this._substituteNamespaces.get(uri); if (substituteUri != null) uri = substituteUri;  }  Xobj x = new Xobj.AttrXobj(this._locale, this._locale.createXmlns(prefix)); start(x); text(uri, 0, uri.length()); end(); this._lastXobj = x; this._lastPos = 0; }
/*      */     protected void attr(QName name, String value) { assert parent().isContainer(); QName parentName = this._after ? this._lastXobj._parent.getQName() : this._lastXobj.getQName(); boolean isId = isAttrOfTypeId(name, parentName); Xobj x = isId ? new Xobj.AttrIdXobj(this._locale, checkName(name, true)) : new Xobj.AttrXobj(this._locale, checkName(name, true)); start(x); text(value, 0, value.length()); end(); if (isId) { Cur c1 = x.tempCur(); c1.toRoot(); Xobj doc = c1._xobj; c1.release(); if (doc instanceof Xobj.DocumentXobj) ((Xobj.DocumentXobj)doc).addIdElement(value, x._parent.getDom());  }  this._lastXobj = x; this._lastPos = 0; }
/*      */     protected void attr(String local, String uri, String prefix, String value) { attr(this._locale.makeQName(uri, local, prefix), value); }
/*      */     protected void procInst(String target, String value) { if (!this._stripProcinsts) { Xobj x = new Xobj.ProcInstXobj(this._locale, target); start(x); text(value, 0, value.length()); end(); this._lastXobj = x; this._lastPos = 0; }  this._stripLeft = true; }
/* 3143 */     protected void comment(String comment) { if (!this._stripComments) comment(comment, 0, comment.length());  this._stripLeft = true; } protected void comment(char[] chars, int off, int cch) { if (!this._stripComments) comment(this._charUtil.saveChars(chars, off, cch), this._charUtil._offSrc, this._charUtil._cchSrc);  this._stripLeft = true; } private void comment(Object src, int off, int cch) { Xobj x = new Xobj.CommentXobj(this._locale); start(x); text(src, off, cch); end(); this._lastXobj = x; this._lastPos = 0; } protected void text(char[] src, int off, int cch) { stripText(src, off, cch); }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void bookmark(XmlCursor.XmlBookmark bm) {
/* 3148 */       this._lastXobj.setBookmark(this._lastPos, bm.getKey(), bm);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void bookmarkLastNonAttr(XmlCursor.XmlBookmark bm) {
/* 3153 */       if (this._lastPos > 0 || !this._lastXobj.isAttr()) {
/* 3154 */         this._lastXobj.setBookmark(this._lastPos, bm.getKey(), bm);
/*      */       } else {
/*      */         
/* 3157 */         assert this._lastXobj._parent != null;
/*      */         
/* 3159 */         this._lastXobj._parent.setBookmark(0, bm.getKey(), bm);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void bookmarkLastAttr(QName attrName, XmlCursor.XmlBookmark bm) {
/* 3165 */       if (this._lastPos == 0 && this._lastXobj.isAttr()) {
/*      */         
/* 3167 */         assert this._lastXobj._parent != null;
/*      */         
/* 3169 */         Xobj a = this._lastXobj._parent.getAttr(attrName);
/*      */         
/* 3171 */         if (a != null) {
/* 3172 */           a.setBookmark(0, bm.getKey(), bm);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void lineNumber(int line, int column, int offset) {
/* 3178 */       this._lastXobj.setBookmark(this._lastPos, (Cur.class$org$apache$xmlbeans$XmlLineNumber == null) ? (Cur.class$org$apache$xmlbeans$XmlLineNumber = Cur.class$("org.apache.xmlbeans.XmlLineNumber")) : Cur.class$org$apache$xmlbeans$XmlLineNumber, new XmlLineNumber(line, column, offset));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void abort() {
/* 3186 */       this._stripLeft = true;
/* 3187 */       while (!parent().isRoot()) {
/* 3188 */         end();
/*      */       }
/* 3190 */       finish().release();
/*      */     }
/*      */ 
/*      */     
/*      */     protected Cur finish() {
/* 3195 */       flushText();
/*      */       
/* 3197 */       if (this._after) {
/* 3198 */         this._frontier = this._frontier._parent;
/*      */       }
/* 3200 */       assert this._frontier != null && this._frontier._parent == null && this._frontier.isRoot();
/*      */       
/* 3202 */       Cur c = this._frontier.tempCur();
/*      */       
/* 3204 */       if (!Locale.toFirstChildElement(c)) {
/* 3205 */         return c;
/*      */       }
/*      */ 
/*      */       
/* 3209 */       boolean isFrag = Locale.isFragmentQName(c.getName());
/*      */       
/* 3211 */       if (this._discardDocElem || isFrag) {
/*      */         
/* 3213 */         if (this._replaceDocElem != null) {
/* 3214 */           c.setName(this._replaceDocElem);
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 3220 */           while (c.toParent());
/*      */ 
/*      */           
/* 3223 */           c.next();
/*      */           
/* 3225 */           while (!c.isElem()) {
/* 3226 */             if (c.isText()) { c.moveChars(null, -1); continue; }  c.moveNode(null);
/*      */           } 
/* 3228 */           assert c.isElem();
/* 3229 */           c.skip();
/*      */           
/* 3231 */           while (!c.isFinish()) {
/* 3232 */             if (c.isText()) { c.moveChars(null, -1); continue; }  c.moveNode(null);
/*      */           } 
/* 3234 */           c.toParent();
/*      */           
/* 3236 */           c.next();
/*      */           
/* 3238 */           assert c.isElem();
/*      */           
/* 3240 */           Cur c2 = c.tempCur();
/*      */           
/* 3242 */           c.moveNodeContents(c, true);
/*      */           
/* 3244 */           c.moveToCur(c2);
/*      */           
/* 3246 */           c2.release();
/*      */           
/* 3248 */           c.moveNode(null);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 3253 */         if (isFrag) {
/*      */           
/* 3255 */           c.moveTo(this._frontier);
/*      */           
/* 3257 */           if (c.toFirstAttr())
/*      */           {
/*      */             while (true) {
/*      */               
/* 3261 */               if (c.isXmlns() && c.getXmlnsUri().equals("http://www.openuri.org/fragment")) {
/*      */                 
/* 3263 */                 c.moveNode(null);
/*      */                 
/* 3265 */                 if (!c.isAttr())
/*      */                   break;  continue;
/*      */               } 
/* 3268 */               if (!c.toNextAttr()) {
/*      */                 break;
/*      */               }
/*      */             } 
/*      */           }
/* 3273 */           c.moveTo(this._frontier);
/* 3274 */           this._frontier = Cur.createDomDocumentRootXobj(this._locale, true);
/*      */           
/* 3276 */           Cur c2 = this._frontier.tempCur();
/* 3277 */           c2.next();
/* 3278 */           c.moveNodeContents(c2, true);
/* 3279 */           c.moveTo(this._frontier);
/* 3280 */           c2.release();
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3285 */       if (this._additionalNamespaces != null) {
/*      */         
/* 3287 */         c.moveTo(this._frontier);
/* 3288 */         Locale.toFirstChildElement(c);
/* 3289 */         Locale.applyNamespaces(c, this._additionalNamespaces);
/*      */       } 
/*      */       
/* 3292 */       if (this._doctypeName != null && (this._doctypePublicId != null || this._doctypeSystemId != null)) {
/*      */         
/* 3294 */         XmlDocumentProperties props = Locale.getDocProps(c, true);
/* 3295 */         props.setDoctypeName(this._doctypeName);
/* 3296 */         if (this._doctypePublicId != null)
/* 3297 */           props.setDoctypePublicId(this._doctypePublicId); 
/* 3298 */         if (this._doctypeSystemId != null) {
/* 3299 */           props.setDoctypeSystemId(this._doctypeSystemId);
/*      */         }
/*      */       } 
/* 3302 */       c.moveTo(this._frontier);
/*      */       
/* 3304 */       assert c.isRoot();
/*      */       
/* 3306 */       return c;
/*      */     }
/*      */ 
/*      */     
/*      */     public void dump() {
/* 3311 */       this._frontier.dump();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String kindName(int kind) {
/* 3342 */     switch (kind) {
/*      */       case 1:
/* 3344 */         return "ROOT";
/* 3345 */       case 2: return "ELEM";
/* 3346 */       case 3: return "ATTR";
/* 3347 */       case 4: return "COMMENT";
/* 3348 */       case 5: return "PROCINST";
/* 3349 */       case 0: return "TEXT";
/* 3350 */     }  return "<< Unknown Kind (" + kind + ") >>";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void dump(PrintStream o, DomImpl.Dom d, Object ref) {}
/*      */ 
/*      */ 
/*      */   
/*      */   static void dump(PrintStream o, DomImpl.Dom d) {
/* 3360 */     d.dump(o);
/*      */   }
/*      */ 
/*      */   
/*      */   static void dump(DomImpl.Dom d) {
/* 3365 */     dump(System.out, d);
/*      */   }
/*      */ 
/*      */   
/*      */   static void dump(Node n) {
/* 3370 */     dump(System.out, n);
/*      */   }
/*      */ 
/*      */   
/*      */   static void dump(PrintStream o, Node n) {
/* 3375 */     dump(o, (DomImpl.Dom)n);
/*      */   }
/*      */ 
/*      */   
/*      */   void dump() {
/* 3380 */     dump(System.out, this._xobj, this);
/*      */   }
/*      */ 
/*      */   
/*      */   void dump(PrintStream o) {
/* 3385 */     if (this._xobj == null) {
/*      */       
/* 3387 */       o.println("Unpositioned xptr");
/*      */       
/*      */       return;
/*      */     } 
/* 3391 */     dump(o, this._xobj, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void dump(PrintStream o, Xobj xo, Object ref) {
/* 3396 */     if (ref == null) {
/* 3397 */       ref = xo;
/*      */     }
/* 3399 */     while (xo._parent != null) {
/* 3400 */       xo = xo._parent;
/*      */     }
/* 3402 */     dumpXobj(o, xo, 0, ref);
/*      */     
/* 3404 */     o.println();
/*      */   }
/*      */ 
/*      */   
/*      */   private static void dumpCur(PrintStream o, String prefix, Cur c, Object ref) {
/* 3409 */     o.print(" ");
/*      */     
/* 3411 */     if (ref == c) {
/* 3412 */       o.print("*:");
/*      */     }
/* 3414 */     o.print(prefix + ((c._id == null) ? "<cur>" : c._id) + "[" + c._pos + "]");
/*      */   }
/*      */   
/*      */   private static void dumpCurs(PrintStream o, Xobj xo, Object ref) {
/*      */     Cur c;
/* 3419 */     for (c = xo._embedded; c != null; c = c._next) {
/* 3420 */       dumpCur(o, "E:", c, ref);
/*      */     }
/* 3422 */     for (c = xo._locale._registered; c != null; c = c._next) {
/*      */       
/* 3424 */       if (c._xobj == xo) {
/* 3425 */         dumpCur(o, "R:", c, ref);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void dumpBookmarks(PrintStream o, Xobj xo, Object ref) {
/* 3431 */     for (Xobj.Bookmark b = xo._bookmarks; b != null; b = b._next) {
/*      */       
/* 3433 */       o.print(" ");
/*      */       
/* 3435 */       if (ref == b) {
/* 3436 */         o.print("*:");
/*      */       }
/* 3438 */       if (b._value instanceof XmlLineNumber) {
/*      */         
/* 3440 */         XmlLineNumber l = (XmlLineNumber)b._value;
/* 3441 */         o.print("<line:" + l.getLine() + ">" + "[" + b._pos + "]");
/*      */       } else {
/*      */         
/* 3444 */         o.print("<mark>[" + b._pos + "]");
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void dumpCharNodes(PrintStream o, DomImpl.CharNode nodes, Object ref) {
/* 3450 */     for (DomImpl.CharNode n = nodes; n != null; n = n._next) {
/*      */       
/* 3452 */       o.print(" ");
/*      */       
/* 3454 */       if (n == ref) {
/* 3455 */         o.print("*");
/*      */       }
/* 3457 */       o.print(((n instanceof DomImpl.TextNode) ? "TEXT" : "CDATA") + "[" + n._cch + "]");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void dumpChars(PrintStream o, Object src, int off, int cch) {
/* 3465 */     o.print("\"");
/*      */     
/* 3467 */     String s = CharUtil.getString(src, off, cch);
/*      */     
/* 3469 */     for (int i = 0; i < s.length(); i++) {
/*      */       
/* 3471 */       if (i == 36) {
/*      */         
/* 3473 */         o.print("...");
/*      */         
/*      */         break;
/*      */       } 
/* 3477 */       char ch = s.charAt(i);
/*      */       
/* 3479 */       if (ch >= ' ' && ch < '') {
/* 3480 */         o.print(ch);
/* 3481 */       } else if (ch == '\n') {
/* 3482 */         o.print("\\n");
/* 3483 */       } else if (ch == '\r') {
/* 3484 */         o.print("\\r");
/* 3485 */       } else if (ch == '\t') {
/* 3486 */         o.print("\\t");
/* 3487 */       } else if (ch == '"') {
/* 3488 */         o.print("\\\"");
/*      */       } else {
/* 3490 */         o.print("<#" + ch + ">");
/*      */       } 
/*      */     } 
/* 3493 */     o.print("\"");
/*      */   }
/*      */ 
/*      */   
/*      */   private static void dumpXobj(PrintStream o, Xobj xo, int level, Object ref) {
/* 3498 */     if (xo == null) {
/*      */       return;
/*      */     }
/* 3501 */     if (xo == ref) {
/* 3502 */       o.print("* ");
/*      */     } else {
/* 3504 */       o.print("  ");
/*      */     } 
/* 3506 */     for (int i = 0; i < level; i++) {
/* 3507 */       o.print("  ");
/*      */     }
/* 3509 */     o.print(kindName(xo.kind()));
/*      */     
/* 3511 */     if (xo._name != null) {
/*      */       
/* 3513 */       o.print(" ");
/*      */       
/* 3515 */       if (xo._name.getPrefix().length() > 0) {
/* 3516 */         o.print(xo._name.getPrefix() + ":");
/*      */       }
/* 3518 */       o.print(xo._name.getLocalPart());
/*      */       
/* 3520 */       if (xo._name.getNamespaceURI().length() > 0) {
/* 3521 */         o.print("@" + xo._name.getNamespaceURI());
/*      */       }
/*      */     } 
/* 3524 */     if (xo._srcValue != null || xo._charNodesValue != null) {
/*      */       
/* 3526 */       o.print(" Value( ");
/* 3527 */       dumpChars(o, xo._srcValue, xo._offValue, xo._cchValue);
/* 3528 */       dumpCharNodes(o, xo._charNodesValue, ref);
/* 3529 */       o.print(" )");
/*      */     } 
/*      */     
/* 3532 */     if (xo._user != null) {
/* 3533 */       o.print(" (USER)");
/*      */     }
/* 3535 */     if (xo.isVacant()) {
/* 3536 */       o.print(" (VACANT)");
/*      */     }
/* 3538 */     if (xo._srcAfter != null || xo._charNodesAfter != null) {
/*      */       
/* 3540 */       o.print(" After( ");
/* 3541 */       dumpChars(o, xo._srcAfter, xo._offAfter, xo._cchAfter);
/* 3542 */       dumpCharNodes(o, xo._charNodesAfter, ref);
/* 3543 */       o.print(" )");
/*      */     } 
/*      */     
/* 3546 */     dumpCurs(o, xo, ref);
/* 3547 */     dumpBookmarks(o, xo, ref);
/*      */     
/* 3549 */     String className = xo.getClass().getName();
/*      */     
/* 3551 */     int j = className.lastIndexOf('.');
/*      */     
/* 3553 */     if (j > 0) {
/*      */       
/* 3555 */       className = className.substring(j + 1);
/*      */       
/* 3557 */       j = className.lastIndexOf('$');
/*      */       
/* 3559 */       if (j > 0) {
/* 3560 */         className = className.substring(j + 1);
/*      */       }
/*      */     } 
/* 3563 */     o.print(" (");
/* 3564 */     o.print(className);
/* 3565 */     o.print(")");
/*      */     
/* 3567 */     o.println();
/*      */     
/* 3569 */     for (xo = xo._firstChild; xo != null; xo = xo._nextSibling) {
/* 3570 */       dumpXobj(o, xo, level + 1, ref);
/*      */     }
/*      */   }
/*      */   
/*      */   void setId(String id) {
/* 3575 */     this._id = id;
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\Cur.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */