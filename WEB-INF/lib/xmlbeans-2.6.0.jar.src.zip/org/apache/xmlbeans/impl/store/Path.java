/*     */ package org.apache.xmlbeans.impl.store;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBoolean;
/*     */ import org.apache.xmlbeans.XmlDate;
/*     */ import org.apache.xmlbeans.XmlDecimal;
/*     */ import org.apache.xmlbeans.XmlDouble;
/*     */ import org.apache.xmlbeans.XmlFloat;
/*     */ import org.apache.xmlbeans.XmlInteger;
/*     */ import org.apache.xmlbeans.XmlLong;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.common.XPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Path
/*     */ {
/*     */   public static final String PATH_DELEGATE_INTERFACE = "PATH_DELEGATE_INTERFACE";
/*  39 */   public static String _useDelegateForXpath = "use delegate for xpath";
/*  40 */   public static String _useXdkForXpath = "use xdk for xpath";
/*  41 */   public static String _useXqrlForXpath = "use xqrl for xpath";
/*  42 */   public static String _useXbeanForXpath = "use xbean for xpath";
/*  43 */   public static String _forceXqrl2002ForXpathXQuery = "use xqrl-2002 for xpath";
/*     */   
/*     */   private static final int USE_XBEAN = 1;
/*     */   
/*     */   private static final int USE_XQRL = 2;
/*     */   private static final int USE_DELEGATE = 4;
/*     */   private static final int USE_XQRL2002 = 8;
/*     */   private static final int USE_XDK = 16;
/*  51 */   private static Map _xbeanPathCache = new WeakHashMap();
/*  52 */   private static Map _xdkPathCache = new WeakHashMap();
/*  53 */   private static Map _xqrlPathCache = new WeakHashMap();
/*  54 */   private static Map _xqrl2002PathCache = new WeakHashMap();
/*     */   
/*     */   private static Method _xdkCompilePath;
/*     */   
/*     */   private static Method _xqrlCompilePath;
/*     */   
/*     */   private static Method _xqrl2002CompilePath;
/*     */   private static boolean _xdkAvailable = true;
/*     */   private static boolean _xqrlAvailable = true;
/*     */   private static boolean _xqrl2002Available = true;
/*     */   private static String _delIntfName;
/*     */   protected final String _pathKey;
/*     */   
/*     */   static {
/*  68 */     ClassLoader cl = Path.class.getClassLoader();
/*  69 */     String id = "META-INF/services/org.apache.xmlbeans.impl.store.PathDelegate.SelectPathInterface";
/*  70 */     InputStream in = cl.getResourceAsStream(id);
/*     */     
/*     */     try {
/*  73 */       BufferedReader br = new BufferedReader(new InputStreamReader(in));
/*  74 */       _delIntfName = br.readLine().trim();
/*  75 */       br.close();
/*     */     }
/*  77 */     catch (Exception e) {
/*     */       
/*  79 */       _delIntfName = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Path(String key) {
/*  87 */     this._pathKey = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getCurrentNodeVar(XmlOptions options) {
/* 106 */     String currentNodeVar = "this";
/*     */     
/* 108 */     options = XmlOptions.maskNull(options);
/*     */     
/* 110 */     if (options.hasOption("XQUERY_CURRENT_NODE_VAR")) {
/* 111 */       currentNodeVar = (String)options.get("XQUERY_CURRENT_NODE_VAR");
/*     */       
/* 113 */       if (currentNodeVar.startsWith("$")) {
/* 114 */         throw new IllegalArgumentException("Omit the '$' prefix for the current node variable");
/*     */       }
/*     */     } 
/*     */     
/* 118 */     return currentNodeVar;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Path getCompiledPath(String pathExpr, XmlOptions options) {
/* 123 */     options = XmlOptions.maskNull(options);
/*     */     
/* 125 */     int force = options.hasOption(_useDelegateForXpath) ? 4 : (options.hasOption(_useXqrlForXpath) ? 2 : (options.hasOption(_useXdkForXpath) ? 16 : (options.hasOption(_useXbeanForXpath) ? 1 : (options.hasOption(_forceXqrl2002ForXpathXQuery) ? 8 : 23))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     String delIntfName = options.hasOption("PATH_DELEGATE_INTERFACE") ? (String)options.get("PATH_DELEGATE_INTERFACE") : _delIntfName;
/*     */ 
/*     */ 
/*     */     
/* 136 */     return getCompiledPath(pathExpr, force, getCurrentNodeVar(options), delIntfName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static synchronized Path getCompiledPath(String pathExpr, int force, String currentVar, String delIntfName) {
/* 142 */     Path path = null;
/* 143 */     WeakReference pathWeakRef = null;
/* 144 */     Map namespaces = ((force & 0x4) != 0) ? new HashMap() : null;
/*     */     
/* 146 */     if ((force & 0x1) != 0)
/* 147 */       pathWeakRef = (WeakReference)_xbeanPathCache.get(pathExpr); 
/* 148 */     if (pathWeakRef == null && (force & 0x2) != 0)
/* 149 */       pathWeakRef = (WeakReference)_xqrlPathCache.get(pathExpr); 
/* 150 */     if (pathWeakRef == null && (force & 0x10) != 0)
/* 151 */       pathWeakRef = (WeakReference)_xdkPathCache.get(pathExpr); 
/* 152 */     if (pathWeakRef == null && (force & 0x8) != 0) {
/* 153 */       pathWeakRef = (WeakReference)_xqrl2002PathCache.get(pathExpr);
/*     */     }
/* 155 */     if (pathWeakRef != null)
/* 156 */       path = pathWeakRef.get(); 
/* 157 */     if (path != null) {
/* 158 */       return path;
/*     */     }
/* 160 */     if ((force & 0x1) != 0)
/* 161 */       path = getCompiledPathXbean(pathExpr, currentVar, namespaces); 
/* 162 */     if (path == null && (force & 0x2) != 0)
/* 163 */       path = getCompiledPathXqrl(pathExpr, currentVar); 
/* 164 */     if (path == null && (force & 0x10) != 0)
/* 165 */       path = getCompiledPathXdk(pathExpr, currentVar); 
/* 166 */     if (path == null && (force & 0x4) != 0)
/* 167 */       path = getCompiledPathDelegate(pathExpr, currentVar, namespaces, delIntfName); 
/* 168 */     if (path == null && (force & 0x8) != 0) {
/* 169 */       path = getCompiledPathXqrl2002(pathExpr, currentVar);
/*     */     }
/* 171 */     if (path == null) {
/*     */       
/* 173 */       StringBuffer errMessage = new StringBuffer();
/* 174 */       if ((force & 0x1) != 0)
/* 175 */         errMessage.append(" Trying XBeans path engine..."); 
/* 176 */       if ((force & 0x2) != 0)
/* 177 */         errMessage.append(" Trying XQRL..."); 
/* 178 */       if ((force & 0x10) != 0)
/* 179 */         errMessage.append(" Trying XDK..."); 
/* 180 */       if ((force & 0x4) != 0)
/* 181 */         errMessage.append(" Trying delegated path engine..."); 
/* 182 */       if ((force & 0x8) != 0) {
/* 183 */         errMessage.append(" Trying XQRL2002...");
/*     */       }
/* 185 */       throw new RuntimeException(errMessage.toString() + " FAILED on " + pathExpr);
/*     */     } 
/*     */     
/* 188 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized Path getCompiledPathXdk(String pathExpr, String currentVar) {
/* 193 */     Path path = createXdkCompiledPath(pathExpr, currentVar);
/* 194 */     if (path != null) {
/* 195 */       _xdkPathCache.put(path._pathKey, new WeakReference(path));
/*     */     }
/* 197 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized Path getCompiledPathXqrl(String pathExpr, String currentVar) {
/* 202 */     Path path = createXqrlCompiledPath(pathExpr, currentVar);
/* 203 */     if (path != null) {
/* 204 */       _xqrlPathCache.put(path._pathKey, new WeakReference(path));
/*     */     }
/* 206 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized Path getCompiledPathXqrl2002(String pathExpr, String currentVar) {
/* 211 */     Path path = createXqrl2002CompiledPath(pathExpr, currentVar);
/* 212 */     if (path != null) {
/* 213 */       _xqrl2002PathCache.put(path._pathKey, new WeakReference(path));
/*     */     }
/* 215 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized Path getCompiledPathXbean(String pathExpr, String currentVar, Map namespaces) {
/* 221 */     Path path = XbeanPath.create(pathExpr, currentVar, namespaces);
/* 222 */     if (path != null) {
/* 223 */       _xbeanPathCache.put(path._pathKey, new WeakReference(path));
/*     */     }
/* 225 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized Path getCompiledPathDelegate(String pathExpr, String currentVar, Map namespaces, String delIntfName) {
/* 230 */     Path path = null;
/* 231 */     if (namespaces == null) {
/* 232 */       namespaces = new HashMap();
/*     */     }
/*     */     
/*     */     try {
/* 236 */       XPath.compileXPath(pathExpr, currentVar, namespaces);
/*     */     }
/* 238 */     catch (org.apache.xmlbeans.impl.common.XPath.XPathCompileException e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     int offset = (namespaces.get("$xmlbeans!ns_boundary") == null) ? 0 : ((Integer)namespaces.get("$xmlbeans!ns_boundary")).intValue();
/*     */ 
/*     */ 
/*     */     
/* 247 */     namespaces.remove("$xmlbeans!ns_boundary");
/* 248 */     path = DelegatePathImpl.create(delIntfName, pathExpr.substring(offset), currentVar, namespaces);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String compilePath(String pathExpr, XmlOptions options) {
/* 259 */     return (getCompiledPath(pathExpr, options))._pathKey;
/*     */   }
/*     */   
/*     */   static interface PathEngine {
/*     */     void release();
/*     */     
/*     */     boolean next(Cur param1Cur); }
/*     */   
/*     */   private static final class XbeanPath extends Path {
/*     */     private final String _currentVar;
/*     */     
/*     */     static Path create(String pathExpr, String currentVar, Map namespaces) {
/*     */       try {
/* 272 */         return new XbeanPath(pathExpr, currentVar, XPath.compileXPath(pathExpr, currentVar, namespaces));
/*     */       
/*     */       }
/* 275 */       catch (org.apache.xmlbeans.impl.common.XPath.XPathCompileException e) {
/* 276 */         return null;
/*     */       } 
/*     */     }
/*     */     private final XPath _compiledPath; public Map namespaces;
/*     */     
/*     */     private XbeanPath(String pathExpr, String currentVar, XPath xpath) {
/* 282 */       super(pathExpr);
/*     */       
/* 284 */       this._currentVar = currentVar;
/* 285 */       this._compiledPath = xpath;
/*     */     }
/*     */ 
/*     */     
/*     */     Path.PathEngine execute(Cur c, XmlOptions options) {
/* 290 */       options = XmlOptions.maskNull(options);
/* 291 */       String delIntfName = options.hasOption("PATH_DELEGATE_INTERFACE") ? (String)options.get("PATH_DELEGATE_INTERFACE") : Path._delIntfName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       if (!c.isContainer() || this._compiledPath.sawDeepDot()) {
/*     */         
/* 302 */         int force = 22;
/* 303 */         return getCompiledPath(this._pathKey, force, this._currentVar, delIntfName).execute(c, options);
/*     */       } 
/* 305 */       return new Path.XbeanPathEngine(this._compiledPath, c);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Path createXdkCompiledPath(String pathExpr, String currentVar) {
/* 315 */     if (!_xdkAvailable) {
/* 316 */       return null;
/*     */     }
/* 318 */     if (_xdkCompilePath == null) {
/*     */       
/*     */       try {
/*     */         
/* 322 */         Class xdkImpl = Class.forName("org.apache.xmlbeans.impl.store.OXQXBXqrlImpl");
/*     */         
/* 324 */         _xdkCompilePath = xdkImpl.getDeclaredMethod("compilePath", new Class[] { String.class, String.class, Boolean.class });
/*     */ 
/*     */       
/*     */       }
/* 328 */       catch (ClassNotFoundException e) {
/*     */         
/* 330 */         _xdkAvailable = false;
/* 331 */         return null;
/*     */       }
/* 333 */       catch (Exception e) {
/*     */         
/* 335 */         _xdkAvailable = false;
/* 336 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 340 */     Object[] args = { pathExpr, currentVar, new Boolean(true) };
/*     */     
/*     */     try {
/* 343 */       return (Path)_xdkCompilePath.invoke(null, args);
/*     */     }
/* 345 */     catch (InvocationTargetException e) {
/* 346 */       Throwable t = e.getCause();
/* 347 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/* 349 */     catch (IllegalAccessException e) {
/* 350 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Path createXqrlCompiledPath(String pathExpr, String currentVar) {
/* 356 */     if (!_xqrlAvailable) {
/* 357 */       return null;
/*     */     }
/* 359 */     if (_xqrlCompilePath == null) {
/*     */       
/*     */       try {
/*     */         
/* 363 */         Class xqrlImpl = Class.forName("org.apache.xmlbeans.impl.store.XqrlImpl");
/*     */         
/* 365 */         _xqrlCompilePath = xqrlImpl.getDeclaredMethod("compilePath", new Class[] { String.class, String.class, Boolean.class });
/*     */ 
/*     */       
/*     */       }
/* 369 */       catch (ClassNotFoundException e) {
/*     */         
/* 371 */         _xqrlAvailable = false;
/* 372 */         return null;
/*     */       }
/* 374 */       catch (Exception e) {
/*     */         
/* 376 */         _xqrlAvailable = false;
/* 377 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 381 */     Object[] args = { pathExpr, currentVar, new Boolean(true) };
/*     */     
/*     */     try {
/* 384 */       return (Path)_xqrlCompilePath.invoke(null, args);
/*     */     }
/* 386 */     catch (InvocationTargetException e) {
/* 387 */       Throwable t = e.getCause();
/* 388 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/* 390 */     catch (IllegalAccessException e) {
/* 391 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Path createXqrl2002CompiledPath(String pathExpr, String currentVar) {
/* 397 */     if (!_xqrl2002Available) {
/* 398 */       return null;
/*     */     }
/* 400 */     if (_xqrl2002CompilePath == null) {
/*     */       
/*     */       try {
/*     */         
/* 404 */         Class xqrlImpl = Class.forName("org.apache.xmlbeans.impl.store.Xqrl2002Impl");
/*     */         
/* 406 */         _xqrl2002CompilePath = xqrlImpl.getDeclaredMethod("compilePath", new Class[] { String.class, String.class, Boolean.class });
/*     */ 
/*     */       
/*     */       }
/* 410 */       catch (ClassNotFoundException e) {
/*     */         
/* 412 */         _xqrl2002Available = false;
/* 413 */         return null;
/*     */       }
/* 415 */       catch (Exception e) {
/*     */         
/* 417 */         _xqrl2002Available = false;
/* 418 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 422 */     Object[] args = { pathExpr, currentVar, new Boolean(true) };
/*     */ 
/*     */     
/*     */     try {
/* 426 */       return (Path)_xqrl2002CompilePath.invoke(null, args);
/*     */     }
/* 428 */     catch (InvocationTargetException e) {
/*     */       
/* 430 */       Throwable t = e.getCause();
/* 431 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/* 433 */     catch (IllegalAccessException e) {
/*     */       
/* 435 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   abstract PathEngine execute(Cur paramCur, XmlOptions paramXmlOptions);
/*     */   
/*     */   private static final class XbeanPathEngine extends XPath.ExecutionContext implements PathEngine { private final long _version;
/*     */     private Cur _cur;
/*     */     static final boolean $assertionsDisabled;
/*     */     
/*     */     XbeanPathEngine(XPath xpath, Cur c) {
/* 445 */       assert c.isContainer();
/*     */       
/* 447 */       this._version = c._locale.version();
/* 448 */       this._cur = c.weakCur(this);
/*     */       
/* 450 */       this._cur.push();
/*     */       
/* 452 */       init(xpath);
/*     */       
/* 454 */       int ret = start();
/*     */       
/* 456 */       if ((ret & 0x1) != 0) {
/* 457 */         c.addToSelection();
/*     */       }
/* 459 */       doAttrs(ret, c);
/*     */       
/* 461 */       if ((ret & 0x2) == 0 || !Locale.toFirstChildElement(this._cur)) {
/* 462 */         release();
/*     */       }
/*     */     }
/*     */     
/*     */     private void advance(Cur c) {
/* 467 */       assert this._cur != null;
/*     */       
/* 469 */       if (this._cur.isFinish()) {
/*     */         
/* 471 */         if (this._cur.isAtEndOfLastPush()) {
/* 472 */           release();
/*     */         } else {
/* 474 */           end();
/* 475 */           this._cur.next();
/*     */         }
/*     */       
/* 478 */       } else if (this._cur.isElem()) {
/*     */         
/* 480 */         int ret = element(this._cur.getName());
/*     */         
/* 482 */         if ((ret & 0x1) != 0) {
/* 483 */           c.addToSelection(this._cur);
/*     */         }
/* 485 */         doAttrs(ret, c);
/*     */         
/* 487 */         if ((ret & 0x2) == 0 || !Locale.toFirstChildElement(this._cur)) {
/*     */           
/* 489 */           end();
/* 490 */           this._cur.skip();
/*     */         } 
/*     */       } else {
/*     */         
/*     */         do
/*     */         {
/*     */           
/* 497 */           this._cur.next();
/*     */         }
/* 499 */         while (!this._cur.isContainerOrFinish());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void doAttrs(int ret, Cur c) {
/* 505 */       assert this._cur.isContainer();
/*     */       
/* 507 */       if ((ret & 0x4) != 0 && 
/* 508 */         this._cur.toFirstAttr()) {
/*     */         do {
/* 510 */           if (!attr(this._cur.getName()))
/* 511 */             continue;  c.addToSelection(this._cur);
/*     */         }
/* 513 */         while (this._cur.toNextAttr());
/*     */         
/* 515 */         this._cur.toParent();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean next(Cur c) {
/* 522 */       if (this._cur != null && this._version != this._cur._locale.version()) {
/* 523 */         throw new ConcurrentModificationException("Document changed during select");
/*     */       }
/* 525 */       int startCount = c.selectionCount();
/*     */       
/* 527 */       while (this._cur != null) {
/* 528 */         advance(c);
/*     */         
/* 530 */         if (startCount != c.selectionCount()) {
/* 531 */           return true;
/*     */         }
/*     */       } 
/* 534 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void release() {
/* 539 */       if (this._cur != null) {
/* 540 */         this._cur.release();
/* 541 */         this._cur = null;
/*     */       } 
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DelegatePathImpl
/*     */     extends Path
/*     */   {
/*     */     private PathDelegate.SelectPathInterface _xpathImpl;
/*     */     
/*     */     static final boolean $assertionsDisabled;
/*     */ 
/*     */     
/*     */     static Path create(String implClassName, String pathExpr, String currentNodeVar, Map namespaceMap) {
/* 556 */       assert !currentNodeVar.startsWith("$");
/*     */       
/* 558 */       PathDelegate.SelectPathInterface impl = PathDelegate.createInstance(implClassName, pathExpr, currentNodeVar, namespaceMap);
/*     */       
/* 560 */       if (impl == null) {
/* 561 */         return null;
/*     */       }
/* 563 */       return new DelegatePathImpl(impl, pathExpr);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DelegatePathImpl(PathDelegate.SelectPathInterface xpathImpl, String pathExpr) {
/* 570 */       super(pathExpr);
/* 571 */       this._xpathImpl = xpathImpl;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Path.PathEngine execute(Cur c, XmlOptions options) {
/* 576 */       return new DelegatePathEngine(this._xpathImpl, c);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static class DelegatePathEngine
/*     */       extends XPath.ExecutionContext
/*     */       implements Path.PathEngine
/*     */     {
/*     */       private Cur _cur;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private PathDelegate.SelectPathInterface _engine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private boolean _firstCall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private long _version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       static final boolean $assertionsDisabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       DelegatePathEngine(PathDelegate.SelectPathInterface xpathImpl, Cur c) {
/* 682 */         this._firstCall = true;
/*     */         this._engine = xpathImpl;
/*     */         this._version = c._locale.version();
/*     */         this._cur = c.weakCur(this);
/*     */       }
/*     */       
/*     */       public boolean next(Cur c) {
/*     */         if (!this._firstCall)
/*     */           return false; 
/*     */         this._firstCall = false;
/*     */         if (this._cur != null && this._version != this._cur._locale.version())
/*     */           throw new ConcurrentModificationException("Document changed during select"); 
/*     */         Object context_node = this._cur.getDom();
/*     */         List resultsList = this._engine.selectPath(context_node);
/*     */         for (int i = 0; i < resultsList.size(); i++) {
/*     */           Object node = resultsList.get(i);
/*     */           Cur pos = null;
/*     */           if (!(node instanceof org.w3c.dom.Node)) {
/*     */             String value = resultsList.get(i).toString();
/*     */             Locale l = c._locale;
/*     */             try {
/*     */               pos = l.load("<xml-fragment/>").tempCur();
/*     */               pos.setValue(value);
/*     */               SchemaType type = getType(node);
/*     */               Locale.autoTypeDocument(pos, type, null);
/*     */               pos.next();
/*     */             } catch (Exception e) {
/*     */               throw new RuntimeException(e);
/*     */             } 
/*     */           } else {
/*     */             assert node instanceof DomImpl.Dom : "New object created in XPATH!";
/*     */             pos = ((DomImpl.Dom)node).tempCur();
/*     */           } 
/*     */           c.addToSelection(pos);
/*     */           pos.release();
/*     */         } 
/*     */         release();
/*     */         this._engine = null;
/*     */         return true;
/*     */       }
/*     */       
/*     */       private SchemaType getType(Object node) {
/*     */         SchemaType type;
/*     */         if (node instanceof Integer) {
/*     */           type = XmlInteger.type;
/*     */         } else if (node instanceof Double) {
/*     */           type = XmlDouble.type;
/*     */         } else if (node instanceof Long) {
/*     */           type = XmlLong.type;
/*     */         } else if (node instanceof Float) {
/*     */           type = XmlFloat.type;
/*     */         } else if (node instanceof java.math.BigDecimal) {
/*     */           type = XmlDecimal.type;
/*     */         } else if (node instanceof Boolean) {
/*     */           type = XmlBoolean.type;
/*     */         } else if (node instanceof String) {
/*     */           type = XmlString.type;
/*     */         } else if (node instanceof java.util.Date) {
/*     */           type = XmlDate.type;
/*     */         } else {
/*     */           type = XmlAnySimpleType.type;
/*     */         } 
/*     */         return type;
/*     */       }
/*     */       
/*     */       public void release() {
/*     */         if (this._cur != null) {
/*     */           this._cur.release();
/*     */           this._cur = null;
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\Path.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */