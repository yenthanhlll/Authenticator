/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlNCName;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.FormChoice;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalSimpleType;
/*     */ 
/*     */ public class AttributeImpl
/*     */   extends AnnotatedImpl implements Attribute {
/*     */   public AttributeImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName SIMPLETYPE$0 = new QName("http://www.w3.org/2001/XMLSchema", "simpleType");
/*     */   
/*  24 */   private static final QName NAME$2 = new QName("", "name");
/*     */   
/*  26 */   private static final QName REF$4 = new QName("", "ref");
/*     */   
/*  28 */   private static final QName TYPE$6 = new QName("", "type");
/*     */   
/*  30 */   private static final QName USE$8 = new QName("", "use");
/*     */   
/*  32 */   private static final QName DEFAULT$10 = new QName("", "default");
/*     */   
/*  34 */   private static final QName FIXED$12 = new QName("", "fixed");
/*     */   
/*  36 */   private static final QName FORM$14 = new QName("", "form");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSimpleType getSimpleType() {
/*  45 */     synchronized (monitor()) {
/*     */       
/*  47 */       check_orphaned();
/*  48 */       LocalSimpleType target = null;
/*  49 */       target = (LocalSimpleType)get_store().find_element_user(SIMPLETYPE$0, 0);
/*  50 */       if (target == null)
/*     */       {
/*  52 */         return null;
/*     */       }
/*  54 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetSimpleType() {
/*  63 */     synchronized (monitor()) {
/*     */       
/*  65 */       check_orphaned();
/*  66 */       return (get_store().count_elements(SIMPLETYPE$0) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSimpleType(LocalSimpleType simpleType) {
/*  75 */     synchronized (monitor()) {
/*     */       
/*  77 */       check_orphaned();
/*  78 */       LocalSimpleType target = null;
/*  79 */       target = (LocalSimpleType)get_store().find_element_user(SIMPLETYPE$0, 0);
/*  80 */       if (target == null)
/*     */       {
/*  82 */         target = (LocalSimpleType)get_store().add_element_user(SIMPLETYPE$0);
/*     */       }
/*  84 */       target.set((XmlObject)simpleType);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSimpleType addNewSimpleType() {
/*  93 */     synchronized (monitor()) {
/*     */       
/*  95 */       check_orphaned();
/*  96 */       LocalSimpleType target = null;
/*  97 */       target = (LocalSimpleType)get_store().add_element_user(SIMPLETYPE$0);
/*  98 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSimpleType() {
/* 107 */     synchronized (monitor()) {
/*     */       
/* 109 */       check_orphaned();
/* 110 */       get_store().remove_element(SIMPLETYPE$0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 119 */     synchronized (monitor()) {
/*     */       
/* 121 */       check_orphaned();
/* 122 */       SimpleValue target = null;
/* 123 */       target = (SimpleValue)get_store().find_attribute_user(NAME$2);
/* 124 */       if (target == null)
/*     */       {
/* 126 */         return null;
/*     */       }
/* 128 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlNCName xgetName() {
/* 137 */     synchronized (monitor()) {
/*     */       
/* 139 */       check_orphaned();
/* 140 */       XmlNCName target = null;
/* 141 */       target = (XmlNCName)get_store().find_attribute_user(NAME$2);
/* 142 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetName() {
/* 151 */     synchronized (monitor()) {
/*     */       
/* 153 */       check_orphaned();
/* 154 */       return (get_store().find_attribute_user(NAME$2) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 163 */     synchronized (monitor()) {
/*     */       
/* 165 */       check_orphaned();
/* 166 */       SimpleValue target = null;
/* 167 */       target = (SimpleValue)get_store().find_attribute_user(NAME$2);
/* 168 */       if (target == null)
/*     */       {
/* 170 */         target = (SimpleValue)get_store().add_attribute_user(NAME$2);
/*     */       }
/* 172 */       target.setStringValue(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetName(XmlNCName name) {
/* 181 */     synchronized (monitor()) {
/*     */       
/* 183 */       check_orphaned();
/* 184 */       XmlNCName target = null;
/* 185 */       target = (XmlNCName)get_store().find_attribute_user(NAME$2);
/* 186 */       if (target == null)
/*     */       {
/* 188 */         target = (XmlNCName)get_store().add_attribute_user(NAME$2);
/*     */       }
/* 190 */       target.set((XmlObject)name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetName() {
/* 199 */     synchronized (monitor()) {
/*     */       
/* 201 */       check_orphaned();
/* 202 */       get_store().remove_attribute(NAME$2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getRef() {
/* 211 */     synchronized (monitor()) {
/*     */       
/* 213 */       check_orphaned();
/* 214 */       SimpleValue target = null;
/* 215 */       target = (SimpleValue)get_store().find_attribute_user(REF$4);
/* 216 */       if (target == null)
/*     */       {
/* 218 */         return null;
/*     */       }
/* 220 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetRef() {
/* 229 */     synchronized (monitor()) {
/*     */       
/* 231 */       check_orphaned();
/* 232 */       XmlQName target = null;
/* 233 */       target = (XmlQName)get_store().find_attribute_user(REF$4);
/* 234 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetRef() {
/* 243 */     synchronized (monitor()) {
/*     */       
/* 245 */       check_orphaned();
/* 246 */       return (get_store().find_attribute_user(REF$4) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRef(QName ref) {
/* 255 */     synchronized (monitor()) {
/*     */       
/* 257 */       check_orphaned();
/* 258 */       SimpleValue target = null;
/* 259 */       target = (SimpleValue)get_store().find_attribute_user(REF$4);
/* 260 */       if (target == null)
/*     */       {
/* 262 */         target = (SimpleValue)get_store().add_attribute_user(REF$4);
/*     */       }
/* 264 */       target.setQNameValue(ref);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetRef(XmlQName ref) {
/* 273 */     synchronized (monitor()) {
/*     */       
/* 275 */       check_orphaned();
/* 276 */       XmlQName target = null;
/* 277 */       target = (XmlQName)get_store().find_attribute_user(REF$4);
/* 278 */       if (target == null)
/*     */       {
/* 280 */         target = (XmlQName)get_store().add_attribute_user(REF$4);
/*     */       }
/* 282 */       target.set((XmlObject)ref);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetRef() {
/* 291 */     synchronized (monitor()) {
/*     */       
/* 293 */       check_orphaned();
/* 294 */       get_store().remove_attribute(REF$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getType() {
/* 303 */     synchronized (monitor()) {
/*     */       
/* 305 */       check_orphaned();
/* 306 */       SimpleValue target = null;
/* 307 */       target = (SimpleValue)get_store().find_attribute_user(TYPE$6);
/* 308 */       if (target == null)
/*     */       {
/* 310 */         return null;
/*     */       }
/* 312 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetType() {
/* 321 */     synchronized (monitor()) {
/*     */       
/* 323 */       check_orphaned();
/* 324 */       XmlQName target = null;
/* 325 */       target = (XmlQName)get_store().find_attribute_user(TYPE$6);
/* 326 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetType() {
/* 335 */     synchronized (monitor()) {
/*     */       
/* 337 */       check_orphaned();
/* 338 */       return (get_store().find_attribute_user(TYPE$6) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(QName type) {
/* 347 */     synchronized (monitor()) {
/*     */       
/* 349 */       check_orphaned();
/* 350 */       SimpleValue target = null;
/* 351 */       target = (SimpleValue)get_store().find_attribute_user(TYPE$6);
/* 352 */       if (target == null)
/*     */       {
/* 354 */         target = (SimpleValue)get_store().add_attribute_user(TYPE$6);
/*     */       }
/* 356 */       target.setQNameValue(type);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetType(XmlQName type) {
/* 365 */     synchronized (monitor()) {
/*     */       
/* 367 */       check_orphaned();
/* 368 */       XmlQName target = null;
/* 369 */       target = (XmlQName)get_store().find_attribute_user(TYPE$6);
/* 370 */       if (target == null)
/*     */       {
/* 372 */         target = (XmlQName)get_store().add_attribute_user(TYPE$6);
/*     */       }
/* 374 */       target.set((XmlObject)type);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetType() {
/* 383 */     synchronized (monitor()) {
/*     */       
/* 385 */       check_orphaned();
/* 386 */       get_store().remove_attribute(TYPE$6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute.Use.Enum getUse() {
/* 395 */     synchronized (monitor()) {
/*     */       
/* 397 */       check_orphaned();
/* 398 */       SimpleValue target = null;
/* 399 */       target = (SimpleValue)get_store().find_attribute_user(USE$8);
/* 400 */       if (target == null)
/*     */       {
/* 402 */         target = (SimpleValue)get_default_attribute_value(USE$8);
/*     */       }
/* 404 */       if (target == null)
/*     */       {
/* 406 */         return null;
/*     */       }
/* 408 */       return (Attribute.Use.Enum)target.getEnumValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute.Use xgetUse() {
/* 417 */     synchronized (monitor()) {
/*     */       
/* 419 */       check_orphaned();
/* 420 */       Attribute.Use target = null;
/* 421 */       target = (Attribute.Use)get_store().find_attribute_user(USE$8);
/* 422 */       if (target == null)
/*     */       {
/* 424 */         target = (Attribute.Use)get_default_attribute_value(USE$8);
/*     */       }
/* 426 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetUse() {
/* 435 */     synchronized (monitor()) {
/*     */       
/* 437 */       check_orphaned();
/* 438 */       return (get_store().find_attribute_user(USE$8) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUse(Attribute.Use.Enum use) {
/* 447 */     synchronized (monitor()) {
/*     */       
/* 449 */       check_orphaned();
/* 450 */       SimpleValue target = null;
/* 451 */       target = (SimpleValue)get_store().find_attribute_user(USE$8);
/* 452 */       if (target == null)
/*     */       {
/* 454 */         target = (SimpleValue)get_store().add_attribute_user(USE$8);
/*     */       }
/* 456 */       target.setEnumValue((StringEnumAbstractBase)use);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetUse(Attribute.Use use) {
/* 465 */     synchronized (monitor()) {
/*     */       
/* 467 */       check_orphaned();
/* 468 */       Attribute.Use target = null;
/* 469 */       target = (Attribute.Use)get_store().find_attribute_user(USE$8);
/* 470 */       if (target == null)
/*     */       {
/* 472 */         target = (Attribute.Use)get_store().add_attribute_user(USE$8);
/*     */       }
/* 474 */       target.set((XmlObject)use);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetUse() {
/* 483 */     synchronized (monitor()) {
/*     */       
/* 485 */       check_orphaned();
/* 486 */       get_store().remove_attribute(USE$8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefault() {
/* 495 */     synchronized (monitor()) {
/*     */       
/* 497 */       check_orphaned();
/* 498 */       SimpleValue target = null;
/* 499 */       target = (SimpleValue)get_store().find_attribute_user(DEFAULT$10);
/* 500 */       if (target == null)
/*     */       {
/* 502 */         return null;
/*     */       }
/* 504 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetDefault() {
/* 513 */     synchronized (monitor()) {
/*     */       
/* 515 */       check_orphaned();
/* 516 */       XmlString target = null;
/* 517 */       target = (XmlString)get_store().find_attribute_user(DEFAULT$10);
/* 518 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetDefault() {
/* 527 */     synchronized (monitor()) {
/*     */       
/* 529 */       check_orphaned();
/* 530 */       return (get_store().find_attribute_user(DEFAULT$10) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String xdefault) {
/* 539 */     synchronized (monitor()) {
/*     */       
/* 541 */       check_orphaned();
/* 542 */       SimpleValue target = null;
/* 543 */       target = (SimpleValue)get_store().find_attribute_user(DEFAULT$10);
/* 544 */       if (target == null)
/*     */       {
/* 546 */         target = (SimpleValue)get_store().add_attribute_user(DEFAULT$10);
/*     */       }
/* 548 */       target.setStringValue(xdefault);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetDefault(XmlString xdefault) {
/* 557 */     synchronized (monitor()) {
/*     */       
/* 559 */       check_orphaned();
/* 560 */       XmlString target = null;
/* 561 */       target = (XmlString)get_store().find_attribute_user(DEFAULT$10);
/* 562 */       if (target == null)
/*     */       {
/* 564 */         target = (XmlString)get_store().add_attribute_user(DEFAULT$10);
/*     */       }
/* 566 */       target.set((XmlObject)xdefault);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetDefault() {
/* 575 */     synchronized (monitor()) {
/*     */       
/* 577 */       check_orphaned();
/* 578 */       get_store().remove_attribute(DEFAULT$10);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFixed() {
/* 587 */     synchronized (monitor()) {
/*     */       
/* 589 */       check_orphaned();
/* 590 */       SimpleValue target = null;
/* 591 */       target = (SimpleValue)get_store().find_attribute_user(FIXED$12);
/* 592 */       if (target == null)
/*     */       {
/* 594 */         return null;
/*     */       }
/* 596 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetFixed() {
/* 605 */     synchronized (monitor()) {
/*     */       
/* 607 */       check_orphaned();
/* 608 */       XmlString target = null;
/* 609 */       target = (XmlString)get_store().find_attribute_user(FIXED$12);
/* 610 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetFixed() {
/* 619 */     synchronized (monitor()) {
/*     */       
/* 621 */       check_orphaned();
/* 622 */       return (get_store().find_attribute_user(FIXED$12) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFixed(String fixed) {
/* 631 */     synchronized (monitor()) {
/*     */       
/* 633 */       check_orphaned();
/* 634 */       SimpleValue target = null;
/* 635 */       target = (SimpleValue)get_store().find_attribute_user(FIXED$12);
/* 636 */       if (target == null)
/*     */       {
/* 638 */         target = (SimpleValue)get_store().add_attribute_user(FIXED$12);
/*     */       }
/* 640 */       target.setStringValue(fixed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetFixed(XmlString fixed) {
/* 649 */     synchronized (monitor()) {
/*     */       
/* 651 */       check_orphaned();
/* 652 */       XmlString target = null;
/* 653 */       target = (XmlString)get_store().find_attribute_user(FIXED$12);
/* 654 */       if (target == null)
/*     */       {
/* 656 */         target = (XmlString)get_store().add_attribute_user(FIXED$12);
/*     */       }
/* 658 */       target.set((XmlObject)fixed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetFixed() {
/* 667 */     synchronized (monitor()) {
/*     */       
/* 669 */       check_orphaned();
/* 670 */       get_store().remove_attribute(FIXED$12);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormChoice.Enum getForm() {
/* 679 */     synchronized (monitor()) {
/*     */       
/* 681 */       check_orphaned();
/* 682 */       SimpleValue target = null;
/* 683 */       target = (SimpleValue)get_store().find_attribute_user(FORM$14);
/* 684 */       if (target == null)
/*     */       {
/* 686 */         return null;
/*     */       }
/* 688 */       return (FormChoice.Enum)target.getEnumValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormChoice xgetForm() {
/* 697 */     synchronized (monitor()) {
/*     */       
/* 699 */       check_orphaned();
/* 700 */       FormChoice target = null;
/* 701 */       target = (FormChoice)get_store().find_attribute_user(FORM$14);
/* 702 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetForm() {
/* 711 */     synchronized (monitor()) {
/*     */       
/* 713 */       check_orphaned();
/* 714 */       return (get_store().find_attribute_user(FORM$14) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForm(FormChoice.Enum form) {
/* 723 */     synchronized (monitor()) {
/*     */       
/* 725 */       check_orphaned();
/* 726 */       SimpleValue target = null;
/* 727 */       target = (SimpleValue)get_store().find_attribute_user(FORM$14);
/* 728 */       if (target == null)
/*     */       {
/* 730 */         target = (SimpleValue)get_store().add_attribute_user(FORM$14);
/*     */       }
/* 732 */       target.setEnumValue((StringEnumAbstractBase)form);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetForm(FormChoice form) {
/* 741 */     synchronized (monitor()) {
/*     */       
/* 743 */       check_orphaned();
/* 744 */       FormChoice target = null;
/* 745 */       target = (FormChoice)get_store().find_attribute_user(FORM$14);
/* 746 */       if (target == null)
/*     */       {
/* 748 */         target = (FormChoice)get_store().add_attribute_user(FORM$14);
/*     */       }
/* 750 */       target.set((XmlObject)form);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetForm() {
/* 759 */     synchronized (monitor()) {
/*     */       
/* 761 */       check_orphaned();
/* 762 */       get_store().remove_attribute(FORM$14);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UseImpl
/*     */     extends JavaStringEnumerationHolderEx
/*     */     implements Attribute.Use
/*     */   {
/*     */     public UseImpl(SchemaType sType) {
/* 775 */       super(sType, false);
/*     */     }
/*     */ 
/*     */     
/*     */     protected UseImpl(SchemaType sType, boolean b) {
/* 780 */       super(sType, b);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AttributeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */