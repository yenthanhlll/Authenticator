/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeDocument;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeDocumentImpl
/*    */   extends XmlComplexContentImpl
/*    */   implements AttributeDocument
/*    */ {
/*    */   public AttributeDocumentImpl(SchemaType sType) {
/* 20 */     super(sType);
/*    */   }
/*    */   
/* 23 */   private static final QName ATTRIBUTE$0 = new QName("http://www.w3.org/2001/XMLSchema", "attribute");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TopLevelAttribute getAttribute() {
/* 32 */     synchronized (monitor()) {
/*    */       
/* 34 */       check_orphaned();
/* 35 */       TopLevelAttribute target = null;
/* 36 */       target = (TopLevelAttribute)get_store().find_element_user(ATTRIBUTE$0, 0);
/* 37 */       if (target == null)
/*    */       {
/* 39 */         return null;
/*    */       }
/* 41 */       return target;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAttribute(TopLevelAttribute attribute) {
/* 50 */     synchronized (monitor()) {
/*    */       
/* 52 */       check_orphaned();
/* 53 */       TopLevelAttribute target = null;
/* 54 */       target = (TopLevelAttribute)get_store().find_element_user(ATTRIBUTE$0, 0);
/* 55 */       if (target == null)
/*    */       {
/* 57 */         target = (TopLevelAttribute)get_store().add_element_user(ATTRIBUTE$0);
/*    */       }
/* 59 */       target.set((XmlObject)attribute);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TopLevelAttribute addNewAttribute() {
/* 68 */     synchronized (monitor()) {
/*    */       
/* 70 */       check_orphaned();
/* 71 */       TopLevelAttribute target = null;
/* 72 */       target = (TopLevelAttribute)get_store().add_element_user(ATTRIBUTE$0);
/* 73 */       return target;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AttributeDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */