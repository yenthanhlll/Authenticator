/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface TestCase extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestCase == null) ? (null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestCase = null.class$("org.apache.xmlbeans.impl.xb.ltgfmt.TestCase")) : null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestCase).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("testcase939btype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDescription(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetDescription(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Files getFiles();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFiles(Files paramFiles);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Files addNewFiles();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getId();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlID xgetId();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetId();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setId(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetId(XmlID paramXmlID);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetId();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getOrigin();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlToken xgetOrigin();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetOrigin();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setOrigin(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetOrigin(XmlToken paramXmlToken);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetOrigin();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getModified();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlBoolean xgetModified();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetModified();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setModified(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetModified(XmlBoolean paramXmlBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetModified();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Files
/*     */     extends XmlObject
/*     */   {
/* 163 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((TestCase.null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestCase$Files == null) ? (TestCase.null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestCase$Files = TestCase.null.class$("org.apache.xmlbeans.impl.xb.ltgfmt.TestCase$Files")) : TestCase.null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestCase$Files).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("files7c3eelemtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FileDesc[] getFileArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FileDesc getFileArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfFileArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setFileArray(FileDesc[] param1ArrayOfFileDesc);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setFileArray(int param1Int, FileDesc param1FileDesc);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FileDesc insertNewFile(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FileDesc addNewFile();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeFile(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static TestCase.Files newInstance() {
/* 214 */         return (TestCase.Files)XmlBeans.getContextTypeLoader().newInstance(TestCase.Files.type, null);
/*     */       }
/*     */       public static TestCase.Files newInstance(XmlOptions options) {
/* 217 */         return (TestCase.Files)XmlBeans.getContextTypeLoader().newInstance(TestCase.Files.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static TestCase newInstance() {
/* 231 */       return (TestCase)XmlBeans.getContextTypeLoader().newInstance(TestCase.type, null);
/*     */     }
/*     */     public static TestCase newInstance(XmlOptions options) {
/* 234 */       return (TestCase)XmlBeans.getContextTypeLoader().newInstance(TestCase.type, options);
/*     */     }
/*     */     
/*     */     public static TestCase parse(String xmlAsString) throws XmlException {
/* 238 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(xmlAsString, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 241 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(xmlAsString, TestCase.type, options);
/*     */     }
/*     */     
/*     */     public static TestCase parse(File file) throws XmlException, IOException {
/* 245 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(file, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(File file, XmlOptions options) throws XmlException, IOException {
/* 248 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(file, TestCase.type, options);
/*     */     }
/*     */     public static TestCase parse(URL u) throws XmlException, IOException {
/* 251 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(u, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 254 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(u, TestCase.type, options);
/*     */     }
/*     */     public static TestCase parse(InputStream is) throws XmlException, IOException {
/* 257 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(is, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 260 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(is, TestCase.type, options);
/*     */     }
/*     */     public static TestCase parse(Reader r) throws XmlException, IOException {
/* 263 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(r, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 266 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(r, TestCase.type, options);
/*     */     }
/*     */     public static TestCase parse(XMLStreamReader sr) throws XmlException {
/* 269 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(sr, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 272 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(sr, TestCase.type, options);
/*     */     }
/*     */     public static TestCase parse(Node node) throws XmlException {
/* 275 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(node, TestCase.type, null);
/*     */     }
/*     */     public static TestCase parse(Node node, XmlOptions options) throws XmlException {
/* 278 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(node, TestCase.type, options);
/*     */     }
/*     */     
/*     */     public static TestCase parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 282 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(xis, TestCase.type, null);
/*     */     }
/*     */     
/*     */     public static TestCase parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 286 */       return (TestCase)XmlBeans.getContextTypeLoader().parse(xis, TestCase.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 290 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, TestCase.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 294 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, TestCase.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\TestCase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */