/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface TestsDocument extends XmlObject {
/*  19 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestsDocument == null) ? (null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestsDocument = null.class$("org.apache.xmlbeans.impl.xb.ltgfmt.TestsDocument")) : null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestsDocument).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("tests5621doctype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Tests getTests();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTests(Tests paramTests);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Tests addNewTests();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Tests
/*     */     extends XmlObject
/*     */   {
/*  44 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((TestsDocument.null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestsDocument$Tests == null) ? (TestsDocument.null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestsDocument$Tests = TestsDocument.null.class$("org.apache.xmlbeans.impl.xb.ltgfmt.TestsDocument$Tests")) : TestsDocument.null.class$org$apache$xmlbeans$impl$xb$ltgfmt$TestsDocument$Tests).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("tests9d6eelemtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TestCase[] getTestArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TestCase getTestArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfTestArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setTestArray(TestCase[] param1ArrayOfTestCase);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setTestArray(int param1Int, TestCase param1TestCase);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TestCase insertNewTest(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TestCase addNewTest();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeTest(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static TestsDocument.Tests newInstance() {
/*  95 */         return (TestsDocument.Tests)XmlBeans.getContextTypeLoader().newInstance(TestsDocument.Tests.type, null);
/*     */       }
/*     */       public static TestsDocument.Tests newInstance(XmlOptions options) {
/*  98 */         return (TestsDocument.Tests)XmlBeans.getContextTypeLoader().newInstance(TestsDocument.Tests.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static TestsDocument newInstance() {
/* 112 */       return (TestsDocument)XmlBeans.getContextTypeLoader().newInstance(TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument newInstance(XmlOptions options) {
/* 115 */       return (TestsDocument)XmlBeans.getContextTypeLoader().newInstance(TestsDocument.type, options);
/*     */     }
/*     */     
/*     */     public static TestsDocument parse(String xmlAsString) throws XmlException {
/* 119 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(xmlAsString, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 122 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(xmlAsString, TestsDocument.type, options);
/*     */     }
/*     */     
/*     */     public static TestsDocument parse(File file) throws XmlException, IOException {
/* 126 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(file, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(File file, XmlOptions options) throws XmlException, IOException {
/* 129 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(file, TestsDocument.type, options);
/*     */     }
/*     */     public static TestsDocument parse(URL u) throws XmlException, IOException {
/* 132 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(u, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 135 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(u, TestsDocument.type, options);
/*     */     }
/*     */     public static TestsDocument parse(InputStream is) throws XmlException, IOException {
/* 138 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(is, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 141 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(is, TestsDocument.type, options);
/*     */     }
/*     */     public static TestsDocument parse(Reader r) throws XmlException, IOException {
/* 144 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(r, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 147 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(r, TestsDocument.type, options);
/*     */     }
/*     */     public static TestsDocument parse(XMLStreamReader sr) throws XmlException {
/* 150 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(sr, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 153 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(sr, TestsDocument.type, options);
/*     */     }
/*     */     public static TestsDocument parse(Node node) throws XmlException {
/* 156 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(node, TestsDocument.type, null);
/*     */     }
/*     */     public static TestsDocument parse(Node node, XmlOptions options) throws XmlException {
/* 159 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(node, TestsDocument.type, options);
/*     */     }
/*     */     
/*     */     public static TestsDocument parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 163 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(xis, TestsDocument.type, null);
/*     */     }
/*     */     
/*     */     public static TestsDocument parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 167 */       return (TestsDocument)XmlBeans.getContextTypeLoader().parse(xis, TestsDocument.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 171 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, TestsDocument.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 175 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, TestsDocument.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\TestsDocument.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */