/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Qnameconfig extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnameconfig == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnameconfig = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Qnameconfig")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnameconfig).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("qnameconfig463ftype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   QName getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlQName xgetName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setName(QName paramQName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetName(XmlQName paramXmlQName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setJavaname(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetJavaname(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List getTarget();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Qnametargetlist xgetTarget();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetTarget();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTarget(List paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetTarget(Qnametargetlist paramQnametargetlist);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetTarget();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Qnameconfig newInstance() {
/* 119 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().newInstance(Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig newInstance(XmlOptions options) {
/* 122 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().newInstance(Qnameconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Qnameconfig parse(String xmlAsString) throws XmlException {
/* 126 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 129 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Qnameconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Qnameconfig parse(File file) throws XmlException, IOException {
/* 133 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(file, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(File file, XmlOptions options) throws XmlException, IOException {
/* 136 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(file, Qnameconfig.type, options);
/*     */     }
/*     */     public static Qnameconfig parse(URL u) throws XmlException, IOException {
/* 139 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(u, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 142 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(u, Qnameconfig.type, options);
/*     */     }
/*     */     public static Qnameconfig parse(InputStream is) throws XmlException, IOException {
/* 145 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(is, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 148 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(is, Qnameconfig.type, options);
/*     */     }
/*     */     public static Qnameconfig parse(Reader r) throws XmlException, IOException {
/* 151 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(r, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 154 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(r, Qnameconfig.type, options);
/*     */     }
/*     */     public static Qnameconfig parse(XMLStreamReader sr) throws XmlException {
/* 157 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(sr, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 160 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(sr, Qnameconfig.type, options);
/*     */     }
/*     */     public static Qnameconfig parse(Node node) throws XmlException {
/* 163 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(node, Qnameconfig.type, null);
/*     */     }
/*     */     public static Qnameconfig parse(Node node, XmlOptions options) throws XmlException {
/* 166 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(node, Qnameconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Qnameconfig parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 170 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(xis, Qnameconfig.type, null);
/*     */     }
/*     */     
/*     */     public static Qnameconfig parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 174 */       return (Qnameconfig)XmlBeans.getContextTypeLoader().parse(xis, Qnameconfig.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 178 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Qnameconfig.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 182 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Qnameconfig.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\Qnameconfig.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */