/*     */ package org.apache.xmlbeans.impl.xb.xmlschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlLanguage;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlschema.LangAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LangAttributeImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements LangAttribute
/*     */ {
/*     */   public LangAttributeImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName LANG$0 = new QName("http://www.w3.org/XML/1998/namespace", "lang");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLang() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       SimpleValue target = null;
/*  36 */       target = (SimpleValue)get_store().find_attribute_user(LANG$0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlLanguage xgetLang() {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       XmlLanguage target = null;
/*  54 */       target = (XmlLanguage)get_store().find_attribute_user(LANG$0);
/*  55 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetLang() {
/*  64 */     synchronized (monitor()) {
/*     */       
/*  66 */       check_orphaned();
/*  67 */       return (get_store().find_attribute_user(LANG$0) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLang(String lang) {
/*  76 */     synchronized (monitor()) {
/*     */       
/*  78 */       check_orphaned();
/*  79 */       SimpleValue target = null;
/*  80 */       target = (SimpleValue)get_store().find_attribute_user(LANG$0);
/*  81 */       if (target == null)
/*     */       {
/*  83 */         target = (SimpleValue)get_store().add_attribute_user(LANG$0);
/*     */       }
/*  85 */       target.setStringValue(lang);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetLang(XmlLanguage lang) {
/*  94 */     synchronized (monitor()) {
/*     */       
/*  96 */       check_orphaned();
/*  97 */       XmlLanguage target = null;
/*  98 */       target = (XmlLanguage)get_store().find_attribute_user(LANG$0);
/*  99 */       if (target == null)
/*     */       {
/* 101 */         target = (XmlLanguage)get_store().add_attribute_user(LANG$0);
/*     */       }
/* 103 */       target.set((XmlObject)lang);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetLang() {
/* 112 */     synchronized (monitor()) {
/*     */       
/* 114 */       check_orphaned();
/* 115 */       get_store().remove_attribute(LANG$0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlschema\impl\LangAttributeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */