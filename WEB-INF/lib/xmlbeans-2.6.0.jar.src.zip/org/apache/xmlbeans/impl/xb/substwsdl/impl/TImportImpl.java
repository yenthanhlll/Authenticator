/*     */ package org.apache.xmlbeans.impl.xb.substwsdl.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.substwsdl.TImport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TImportImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements TImport
/*     */ {
/*     */   public TImportImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName NAMESPACE$0 = new QName("", "namespace");
/*     */   
/*  24 */   private static final QName LOCATION$2 = new QName("", "location");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  33 */     synchronized (monitor()) {
/*     */       
/*  35 */       check_orphaned();
/*  36 */       SimpleValue target = null;
/*  37 */       target = (SimpleValue)get_store().find_attribute_user(NAMESPACE$0);
/*  38 */       if (target == null)
/*     */       {
/*  40 */         return null;
/*     */       }
/*  42 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI xgetNamespace() {
/*  51 */     synchronized (monitor()) {
/*     */       
/*  53 */       check_orphaned();
/*  54 */       XmlAnyURI target = null;
/*  55 */       target = (XmlAnyURI)get_store().find_attribute_user(NAMESPACE$0);
/*  56 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespace(String namespace) {
/*  65 */     synchronized (monitor()) {
/*     */       
/*  67 */       check_orphaned();
/*  68 */       SimpleValue target = null;
/*  69 */       target = (SimpleValue)get_store().find_attribute_user(NAMESPACE$0);
/*  70 */       if (target == null)
/*     */       {
/*  72 */         target = (SimpleValue)get_store().add_attribute_user(NAMESPACE$0);
/*     */       }
/*  74 */       target.setStringValue(namespace);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetNamespace(XmlAnyURI namespace) {
/*  83 */     synchronized (monitor()) {
/*     */       
/*  85 */       check_orphaned();
/*  86 */       XmlAnyURI target = null;
/*  87 */       target = (XmlAnyURI)get_store().find_attribute_user(NAMESPACE$0);
/*  88 */       if (target == null)
/*     */       {
/*  90 */         target = (XmlAnyURI)get_store().add_attribute_user(NAMESPACE$0);
/*     */       }
/*  92 */       target.set((XmlObject)namespace);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 101 */     synchronized (monitor()) {
/*     */       
/* 103 */       check_orphaned();
/* 104 */       SimpleValue target = null;
/* 105 */       target = (SimpleValue)get_store().find_attribute_user(LOCATION$2);
/* 106 */       if (target == null)
/*     */       {
/* 108 */         return null;
/*     */       }
/* 110 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI xgetLocation() {
/* 119 */     synchronized (monitor()) {
/*     */       
/* 121 */       check_orphaned();
/* 122 */       XmlAnyURI target = null;
/* 123 */       target = (XmlAnyURI)get_store().find_attribute_user(LOCATION$2);
/* 124 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocation(String location) {
/* 133 */     synchronized (monitor()) {
/*     */       
/* 135 */       check_orphaned();
/* 136 */       SimpleValue target = null;
/* 137 */       target = (SimpleValue)get_store().find_attribute_user(LOCATION$2);
/* 138 */       if (target == null)
/*     */       {
/* 140 */         target = (SimpleValue)get_store().add_attribute_user(LOCATION$2);
/*     */       }
/* 142 */       target.setStringValue(location);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetLocation(XmlAnyURI location) {
/* 151 */     synchronized (monitor()) {
/*     */       
/* 153 */       check_orphaned();
/* 154 */       XmlAnyURI target = null;
/* 155 */       target = (XmlAnyURI)get_store().find_attribute_user(LOCATION$2);
/* 156 */       if (target == null)
/*     */       {
/* 158 */         target = (XmlAnyURI)get_store().add_attribute_user(LOCATION$2);
/*     */       }
/* 160 */       target.set((XmlObject)location);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\substwsdl\impl\TImportImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */