/*     */ package org.apache.xmlbeans.impl.xb.xsdownload.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemaEntry;
/*     */ 
/*     */ public class DownloadedSchemaEntryImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements DownloadedSchemaEntry
/*     */ {
/*     */   public DownloadedSchemaEntryImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName FILENAME$0 = new QName("http://www.bea.com/2003/01/xmlbean/xsdownload", "filename");
/*     */   
/*  24 */   private static final QName SHA1$2 = new QName("http://www.bea.com/2003/01/xmlbean/xsdownload", "sha1");
/*     */   
/*  26 */   private static final QName SCHEMALOCATION$4 = new QName("http://www.bea.com/2003/01/xmlbean/xsdownload", "schemaLocation");
/*     */   
/*  28 */   private static final QName NAMESPACE$6 = new QName("http://www.bea.com/2003/01/xmlbean/xsdownload", "namespace");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilename() {
/*  37 */     synchronized (monitor()) {
/*     */       
/*  39 */       check_orphaned();
/*  40 */       SimpleValue target = null;
/*  41 */       target = (SimpleValue)get_store().find_element_user(FILENAME$0, 0);
/*  42 */       if (target == null)
/*     */       {
/*  44 */         return null;
/*     */       }
/*  46 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetFilename() {
/*  55 */     synchronized (monitor()) {
/*     */       
/*  57 */       check_orphaned();
/*  58 */       XmlToken target = null;
/*  59 */       target = (XmlToken)get_store().find_element_user(FILENAME$0, 0);
/*  60 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilename(String filename) {
/*  69 */     synchronized (monitor()) {
/*     */       
/*  71 */       check_orphaned();
/*  72 */       SimpleValue target = null;
/*  73 */       target = (SimpleValue)get_store().find_element_user(FILENAME$0, 0);
/*  74 */       if (target == null)
/*     */       {
/*  76 */         target = (SimpleValue)get_store().add_element_user(FILENAME$0);
/*     */       }
/*  78 */       target.setStringValue(filename);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetFilename(XmlToken filename) {
/*  87 */     synchronized (monitor()) {
/*     */       
/*  89 */       check_orphaned();
/*  90 */       XmlToken target = null;
/*  91 */       target = (XmlToken)get_store().find_element_user(FILENAME$0, 0);
/*  92 */       if (target == null)
/*     */       {
/*  94 */         target = (XmlToken)get_store().add_element_user(FILENAME$0);
/*     */       }
/*  96 */       target.set((XmlObject)filename);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSha1() {
/* 105 */     synchronized (monitor()) {
/*     */       
/* 107 */       check_orphaned();
/* 108 */       SimpleValue target = null;
/* 109 */       target = (SimpleValue)get_store().find_element_user(SHA1$2, 0);
/* 110 */       if (target == null)
/*     */       {
/* 112 */         return null;
/*     */       }
/* 114 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetSha1() {
/* 123 */     synchronized (monitor()) {
/*     */       
/* 125 */       check_orphaned();
/* 126 */       XmlToken target = null;
/* 127 */       target = (XmlToken)get_store().find_element_user(SHA1$2, 0);
/* 128 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSha1(String sha1) {
/* 137 */     synchronized (monitor()) {
/*     */       
/* 139 */       check_orphaned();
/* 140 */       SimpleValue target = null;
/* 141 */       target = (SimpleValue)get_store().find_element_user(SHA1$2, 0);
/* 142 */       if (target == null)
/*     */       {
/* 144 */         target = (SimpleValue)get_store().add_element_user(SHA1$2);
/*     */       }
/* 146 */       target.setStringValue(sha1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetSha1(XmlToken sha1) {
/* 155 */     synchronized (monitor()) {
/*     */       
/* 157 */       check_orphaned();
/* 158 */       XmlToken target = null;
/* 159 */       target = (XmlToken)get_store().find_element_user(SHA1$2, 0);
/* 160 */       if (target == null)
/*     */       {
/* 162 */         target = (XmlToken)get_store().add_element_user(SHA1$2);
/*     */       }
/* 164 */       target.set((XmlObject)sha1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSchemaLocationArray() {
/* 173 */     synchronized (monitor()) {
/*     */       
/* 175 */       check_orphaned();
/* 176 */       List targetList = new ArrayList();
/* 177 */       get_store().find_all_element_users(SCHEMALOCATION$4, targetList);
/* 178 */       String[] result = new String[targetList.size()];
/* 179 */       for (int i = 0, len = targetList.size(); i < len; i++)
/* 180 */         result[i] = ((SimpleValue)targetList.get(i)).getStringValue(); 
/* 181 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchemaLocationArray(int i) {
/* 190 */     synchronized (monitor()) {
/*     */       
/* 192 */       check_orphaned();
/* 193 */       SimpleValue target = null;
/* 194 */       target = (SimpleValue)get_store().find_element_user(SCHEMALOCATION$4, i);
/* 195 */       if (target == null)
/*     */       {
/* 197 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 199 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI[] xgetSchemaLocationArray() {
/* 208 */     synchronized (monitor()) {
/*     */       
/* 210 */       check_orphaned();
/* 211 */       List targetList = new ArrayList();
/* 212 */       get_store().find_all_element_users(SCHEMALOCATION$4, targetList);
/* 213 */       XmlAnyURI[] result = new XmlAnyURI[targetList.size()];
/* 214 */       targetList.toArray((Object[])result);
/* 215 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI xgetSchemaLocationArray(int i) {
/* 224 */     synchronized (monitor()) {
/*     */       
/* 226 */       check_orphaned();
/* 227 */       XmlAnyURI target = null;
/* 228 */       target = (XmlAnyURI)get_store().find_element_user(SCHEMALOCATION$4, i);
/* 229 */       if (target == null)
/*     */       {
/* 231 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 233 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOfSchemaLocationArray() {
/* 242 */     synchronized (monitor()) {
/*     */       
/* 244 */       check_orphaned();
/* 245 */       return get_store().count_elements(SCHEMALOCATION$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaLocationArray(String[] schemaLocationArray) {
/* 254 */     synchronized (monitor()) {
/*     */       
/* 256 */       check_orphaned();
/* 257 */       arraySetterHelper(schemaLocationArray, SCHEMALOCATION$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaLocationArray(int i, String schemaLocation) {
/* 266 */     synchronized (monitor()) {
/*     */       
/* 268 */       check_orphaned();
/* 269 */       SimpleValue target = null;
/* 270 */       target = (SimpleValue)get_store().find_element_user(SCHEMALOCATION$4, i);
/* 271 */       if (target == null)
/*     */       {
/* 273 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 275 */       target.setStringValue(schemaLocation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetSchemaLocationArray(XmlAnyURI[] schemaLocationArray) {
/* 284 */     synchronized (monitor()) {
/*     */       
/* 286 */       check_orphaned();
/* 287 */       arraySetterHelper((XmlObject[])schemaLocationArray, SCHEMALOCATION$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetSchemaLocationArray(int i, XmlAnyURI schemaLocation) {
/* 296 */     synchronized (monitor()) {
/*     */       
/* 298 */       check_orphaned();
/* 299 */       XmlAnyURI target = null;
/* 300 */       target = (XmlAnyURI)get_store().find_element_user(SCHEMALOCATION$4, i);
/* 301 */       if (target == null)
/*     */       {
/* 303 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 305 */       target.set((XmlObject)schemaLocation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertSchemaLocation(int i, String schemaLocation) {
/* 314 */     synchronized (monitor()) {
/*     */       
/* 316 */       check_orphaned();
/* 317 */       SimpleValue target = (SimpleValue)get_store().insert_element_user(SCHEMALOCATION$4, i);
/*     */       
/* 319 */       target.setStringValue(schemaLocation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSchemaLocation(String schemaLocation) {
/* 328 */     synchronized (monitor()) {
/*     */       
/* 330 */       check_orphaned();
/* 331 */       SimpleValue target = null;
/* 332 */       target = (SimpleValue)get_store().add_element_user(SCHEMALOCATION$4);
/* 333 */       target.setStringValue(schemaLocation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI insertNewSchemaLocation(int i) {
/* 342 */     synchronized (monitor()) {
/*     */       
/* 344 */       check_orphaned();
/* 345 */       XmlAnyURI target = null;
/* 346 */       target = (XmlAnyURI)get_store().insert_element_user(SCHEMALOCATION$4, i);
/* 347 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI addNewSchemaLocation() {
/* 356 */     synchronized (monitor()) {
/*     */       
/* 358 */       check_orphaned();
/* 359 */       XmlAnyURI target = null;
/* 360 */       target = (XmlAnyURI)get_store().add_element_user(SCHEMALOCATION$4);
/* 361 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSchemaLocation(int i) {
/* 370 */     synchronized (monitor()) {
/*     */       
/* 372 */       check_orphaned();
/* 373 */       get_store().remove_element(SCHEMALOCATION$4, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/* 382 */     synchronized (monitor()) {
/*     */       
/* 384 */       check_orphaned();
/* 385 */       SimpleValue target = null;
/* 386 */       target = (SimpleValue)get_store().find_element_user(NAMESPACE$6, 0);
/* 387 */       if (target == null)
/*     */       {
/* 389 */         return null;
/*     */       }
/* 391 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI xgetNamespace() {
/* 400 */     synchronized (monitor()) {
/*     */       
/* 402 */       check_orphaned();
/* 403 */       XmlAnyURI target = null;
/* 404 */       target = (XmlAnyURI)get_store().find_element_user(NAMESPACE$6, 0);
/* 405 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetNamespace() {
/* 414 */     synchronized (monitor()) {
/*     */       
/* 416 */       check_orphaned();
/* 417 */       return (get_store().count_elements(NAMESPACE$6) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespace(String namespace) {
/* 426 */     synchronized (monitor()) {
/*     */       
/* 428 */       check_orphaned();
/* 429 */       SimpleValue target = null;
/* 430 */       target = (SimpleValue)get_store().find_element_user(NAMESPACE$6, 0);
/* 431 */       if (target == null)
/*     */       {
/* 433 */         target = (SimpleValue)get_store().add_element_user(NAMESPACE$6);
/*     */       }
/* 435 */       target.setStringValue(namespace);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetNamespace(XmlAnyURI namespace) {
/* 444 */     synchronized (monitor()) {
/*     */       
/* 446 */       check_orphaned();
/* 447 */       XmlAnyURI target = null;
/* 448 */       target = (XmlAnyURI)get_store().find_element_user(NAMESPACE$6, 0);
/* 449 */       if (target == null)
/*     */       {
/* 451 */         target = (XmlAnyURI)get_store().add_element_user(NAMESPACE$6);
/*     */       }
/* 453 */       target.set((XmlObject)namespace);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetNamespace() {
/* 462 */     synchronized (monitor()) {
/*     */       
/* 464 */       check_orphaned();
/* 465 */       get_store().remove_element(NAMESPACE$6, 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdownload\impl\DownloadedSchemaEntryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */