/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.JavaNameList;
/*     */ 
/*     */ public class ExtensionconfigImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements Extensionconfig
/*     */ {
/*     */   public ExtensionconfigImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName INTERFACE$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "interface");
/*     */   
/*  24 */   private static final QName PREPOSTSET$2 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "prePostSet");
/*     */   
/*  26 */   private static final QName FOR$4 = new QName("", "for");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extensionconfig.Interface[] getInterfaceArray() {
/*  35 */     synchronized (monitor()) {
/*     */       
/*  37 */       check_orphaned();
/*  38 */       List targetList = new ArrayList();
/*  39 */       get_store().find_all_element_users(INTERFACE$0, targetList);
/*  40 */       Extensionconfig.Interface[] result = new Extensionconfig.Interface[targetList.size()];
/*  41 */       targetList.toArray((Object[])result);
/*  42 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extensionconfig.Interface getInterfaceArray(int i) {
/*  51 */     synchronized (monitor()) {
/*     */       
/*  53 */       check_orphaned();
/*  54 */       Extensionconfig.Interface target = null;
/*  55 */       target = (Extensionconfig.Interface)get_store().find_element_user(INTERFACE$0, i);
/*  56 */       if (target == null)
/*     */       {
/*  58 */         throw new IndexOutOfBoundsException();
/*     */       }
/*  60 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOfInterfaceArray() {
/*  69 */     synchronized (monitor()) {
/*     */       
/*  71 */       check_orphaned();
/*  72 */       return get_store().count_elements(INTERFACE$0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterfaceArray(Extensionconfig.Interface[] xinterfaceArray) {
/*  81 */     synchronized (monitor()) {
/*     */       
/*  83 */       check_orphaned();
/*  84 */       arraySetterHelper((XmlObject[])xinterfaceArray, INTERFACE$0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterfaceArray(int i, Extensionconfig.Interface xinterface) {
/*  93 */     synchronized (monitor()) {
/*     */       
/*  95 */       check_orphaned();
/*  96 */       Extensionconfig.Interface target = null;
/*  97 */       target = (Extensionconfig.Interface)get_store().find_element_user(INTERFACE$0, i);
/*  98 */       if (target == null)
/*     */       {
/* 100 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 102 */       target.set((XmlObject)xinterface);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extensionconfig.Interface insertNewInterface(int i) {
/* 111 */     synchronized (monitor()) {
/*     */       
/* 113 */       check_orphaned();
/* 114 */       Extensionconfig.Interface target = null;
/* 115 */       target = (Extensionconfig.Interface)get_store().insert_element_user(INTERFACE$0, i);
/* 116 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extensionconfig.Interface addNewInterface() {
/* 125 */     synchronized (monitor()) {
/*     */       
/* 127 */       check_orphaned();
/* 128 */       Extensionconfig.Interface target = null;
/* 129 */       target = (Extensionconfig.Interface)get_store().add_element_user(INTERFACE$0);
/* 130 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeInterface(int i) {
/* 139 */     synchronized (monitor()) {
/*     */       
/* 141 */       check_orphaned();
/* 142 */       get_store().remove_element(INTERFACE$0, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extensionconfig.PrePostSet getPrePostSet() {
/* 151 */     synchronized (monitor()) {
/*     */       
/* 153 */       check_orphaned();
/* 154 */       Extensionconfig.PrePostSet target = null;
/* 155 */       target = (Extensionconfig.PrePostSet)get_store().find_element_user(PREPOSTSET$2, 0);
/* 156 */       if (target == null)
/*     */       {
/* 158 */         return null;
/*     */       }
/* 160 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetPrePostSet() {
/* 169 */     synchronized (monitor()) {
/*     */       
/* 171 */       check_orphaned();
/* 172 */       return (get_store().count_elements(PREPOSTSET$2) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrePostSet(Extensionconfig.PrePostSet prePostSet) {
/* 181 */     synchronized (monitor()) {
/*     */       
/* 183 */       check_orphaned();
/* 184 */       Extensionconfig.PrePostSet target = null;
/* 185 */       target = (Extensionconfig.PrePostSet)get_store().find_element_user(PREPOSTSET$2, 0);
/* 186 */       if (target == null)
/*     */       {
/* 188 */         target = (Extensionconfig.PrePostSet)get_store().add_element_user(PREPOSTSET$2);
/*     */       }
/* 190 */       target.set((XmlObject)prePostSet);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extensionconfig.PrePostSet addNewPrePostSet() {
/* 199 */     synchronized (monitor()) {
/*     */       
/* 201 */       check_orphaned();
/* 202 */       Extensionconfig.PrePostSet target = null;
/* 203 */       target = (Extensionconfig.PrePostSet)get_store().add_element_user(PREPOSTSET$2);
/* 204 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetPrePostSet() {
/* 213 */     synchronized (monitor()) {
/*     */       
/* 215 */       check_orphaned();
/* 216 */       get_store().remove_element(PREPOSTSET$2, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getFor() {
/* 225 */     synchronized (monitor()) {
/*     */       
/* 227 */       check_orphaned();
/* 228 */       SimpleValue target = null;
/* 229 */       target = (SimpleValue)get_store().find_attribute_user(FOR$4);
/* 230 */       if (target == null)
/*     */       {
/* 232 */         return null;
/*     */       }
/* 234 */       return target.getObjectValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaNameList xgetFor() {
/* 243 */     synchronized (monitor()) {
/*     */       
/* 245 */       check_orphaned();
/* 246 */       JavaNameList target = null;
/* 247 */       target = (JavaNameList)get_store().find_attribute_user(FOR$4);
/* 248 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetFor() {
/* 257 */     synchronized (monitor()) {
/*     */       
/* 259 */       check_orphaned();
/* 260 */       return (get_store().find_attribute_user(FOR$4) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFor(Object xfor) {
/* 269 */     synchronized (monitor()) {
/*     */       
/* 271 */       check_orphaned();
/* 272 */       SimpleValue target = null;
/* 273 */       target = (SimpleValue)get_store().find_attribute_user(FOR$4);
/* 274 */       if (target == null)
/*     */       {
/* 276 */         target = (SimpleValue)get_store().add_attribute_user(FOR$4);
/*     */       }
/* 278 */       target.setObjectValue(xfor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetFor(JavaNameList xfor) {
/* 287 */     synchronized (monitor()) {
/*     */       
/* 289 */       check_orphaned();
/* 290 */       JavaNameList target = null;
/* 291 */       target = (JavaNameList)get_store().find_attribute_user(FOR$4);
/* 292 */       if (target == null)
/*     */       {
/* 294 */         target = (JavaNameList)get_store().add_attribute_user(FOR$4);
/*     */       }
/* 296 */       target.set((XmlObject)xfor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetFor() {
/* 305 */     synchronized (monitor()) {
/*     */       
/* 307 */       check_orphaned();
/* 308 */       get_store().remove_attribute(FOR$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class InterfaceImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements Extensionconfig.Interface
/*     */   {
/*     */     public InterfaceImpl(SchemaType sType) {
/* 321 */       super(sType);
/*     */     }
/*     */     
/* 324 */     private static final QName STATICHANDLER$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "staticHandler");
/*     */     
/* 326 */     private static final QName NAME$2 = new QName("", "name");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getStaticHandler() {
/* 335 */       synchronized (monitor()) {
/*     */         
/* 337 */         check_orphaned();
/* 338 */         SimpleValue target = null;
/* 339 */         target = (SimpleValue)get_store().find_element_user(STATICHANDLER$0, 0);
/* 340 */         if (target == null)
/*     */         {
/* 342 */           return null;
/*     */         }
/* 344 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlString xgetStaticHandler() {
/* 353 */       synchronized (monitor()) {
/*     */         
/* 355 */         check_orphaned();
/* 356 */         XmlString target = null;
/* 357 */         target = (XmlString)get_store().find_element_user(STATICHANDLER$0, 0);
/* 358 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStaticHandler(String staticHandler) {
/* 367 */       synchronized (monitor()) {
/*     */         
/* 369 */         check_orphaned();
/* 370 */         SimpleValue target = null;
/* 371 */         target = (SimpleValue)get_store().find_element_user(STATICHANDLER$0, 0);
/* 372 */         if (target == null)
/*     */         {
/* 374 */           target = (SimpleValue)get_store().add_element_user(STATICHANDLER$0);
/*     */         }
/* 376 */         target.setStringValue(staticHandler);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetStaticHandler(XmlString staticHandler) {
/* 385 */       synchronized (monitor()) {
/*     */         
/* 387 */         check_orphaned();
/* 388 */         XmlString target = null;
/* 389 */         target = (XmlString)get_store().find_element_user(STATICHANDLER$0, 0);
/* 390 */         if (target == null)
/*     */         {
/* 392 */           target = (XmlString)get_store().add_element_user(STATICHANDLER$0);
/*     */         }
/* 394 */         target.set((XmlObject)staticHandler);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 403 */       synchronized (monitor()) {
/*     */         
/* 405 */         check_orphaned();
/* 406 */         SimpleValue target = null;
/* 407 */         target = (SimpleValue)get_store().find_attribute_user(NAME$2);
/* 408 */         if (target == null)
/*     */         {
/* 410 */           return null;
/*     */         }
/* 412 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlString xgetName() {
/* 421 */       synchronized (monitor()) {
/*     */         
/* 423 */         check_orphaned();
/* 424 */         XmlString target = null;
/* 425 */         target = (XmlString)get_store().find_attribute_user(NAME$2);
/* 426 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetName() {
/* 435 */       synchronized (monitor()) {
/*     */         
/* 437 */         check_orphaned();
/* 438 */         return (get_store().find_attribute_user(NAME$2) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setName(String name) {
/* 447 */       synchronized (monitor()) {
/*     */         
/* 449 */         check_orphaned();
/* 450 */         SimpleValue target = null;
/* 451 */         target = (SimpleValue)get_store().find_attribute_user(NAME$2);
/* 452 */         if (target == null)
/*     */         {
/* 454 */           target = (SimpleValue)get_store().add_attribute_user(NAME$2);
/*     */         }
/* 456 */         target.setStringValue(name);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetName(XmlString name) {
/* 465 */       synchronized (monitor()) {
/*     */         
/* 467 */         check_orphaned();
/* 468 */         XmlString target = null;
/* 469 */         target = (XmlString)get_store().find_attribute_user(NAME$2);
/* 470 */         if (target == null)
/*     */         {
/* 472 */           target = (XmlString)get_store().add_attribute_user(NAME$2);
/*     */         }
/* 474 */         target.set((XmlObject)name);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetName() {
/* 483 */       synchronized (monitor()) {
/*     */         
/* 485 */         check_orphaned();
/* 486 */         get_store().remove_attribute(NAME$2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PrePostSetImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements Extensionconfig.PrePostSet
/*     */   {
/*     */     public PrePostSetImpl(SchemaType sType) {
/* 500 */       super(sType);
/*     */     }
/*     */     
/* 503 */     private static final QName STATICHANDLER$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "staticHandler");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getStaticHandler() {
/* 512 */       synchronized (monitor()) {
/*     */         
/* 514 */         check_orphaned();
/* 515 */         SimpleValue target = null;
/* 516 */         target = (SimpleValue)get_store().find_element_user(STATICHANDLER$0, 0);
/* 517 */         if (target == null)
/*     */         {
/* 519 */           return null;
/*     */         }
/* 521 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlString xgetStaticHandler() {
/* 530 */       synchronized (monitor()) {
/*     */         
/* 532 */         check_orphaned();
/* 533 */         XmlString target = null;
/* 534 */         target = (XmlString)get_store().find_element_user(STATICHANDLER$0, 0);
/* 535 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStaticHandler(String staticHandler) {
/* 544 */       synchronized (monitor()) {
/*     */         
/* 546 */         check_orphaned();
/* 547 */         SimpleValue target = null;
/* 548 */         target = (SimpleValue)get_store().find_element_user(STATICHANDLER$0, 0);
/* 549 */         if (target == null)
/*     */         {
/* 551 */           target = (SimpleValue)get_store().add_element_user(STATICHANDLER$0);
/*     */         }
/* 553 */         target.setStringValue(staticHandler);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetStaticHandler(XmlString staticHandler) {
/* 562 */       synchronized (monitor()) {
/*     */         
/* 564 */         check_orphaned();
/* 565 */         XmlString target = null;
/* 566 */         target = (XmlString)get_store().find_element_user(STATICHANDLER$0, 0);
/* 567 */         if (target == null)
/*     */         {
/* 569 */           target = (XmlString)get_store().add_element_user(STATICHANDLER$0);
/*     */         }
/* 571 */         target.set((XmlObject)staticHandler);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\ExtensionconfigImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */