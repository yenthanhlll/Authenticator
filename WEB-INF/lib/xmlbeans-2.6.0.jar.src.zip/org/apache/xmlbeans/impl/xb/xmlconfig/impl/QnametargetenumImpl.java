/*    */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*    */ import org.apache.xmlbeans.impl.xb.xmlconfig.Qnametargetenum;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QnametargetenumImpl
/*    */   extends JavaStringEnumerationHolderEx
/*    */   implements Qnametargetenum
/*    */ {
/*    */   public QnametargetenumImpl(SchemaType sType) {
/* 19 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected QnametargetenumImpl(SchemaType sType, boolean b) {
/* 24 */     super(sType, b);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\QnametargetenumImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */