/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.All;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroupRef;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ExplicitGroup;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ExtensionType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.GroupRef;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Wildcard;
/*     */ 
/*     */ public class ExtensionTypeImpl extends AnnotatedImpl implements ExtensionType {
/*     */   public ExtensionTypeImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName GROUP$0 = new QName("http://www.w3.org/2001/XMLSchema", "group");
/*     */   
/*  24 */   private static final QName ALL$2 = new QName("http://www.w3.org/2001/XMLSchema", "all");
/*     */   
/*  26 */   private static final QName CHOICE$4 = new QName("http://www.w3.org/2001/XMLSchema", "choice");
/*     */   
/*  28 */   private static final QName SEQUENCE$6 = new QName("http://www.w3.org/2001/XMLSchema", "sequence");
/*     */   
/*  30 */   private static final QName ATTRIBUTE$8 = new QName("http://www.w3.org/2001/XMLSchema", "attribute");
/*     */   
/*  32 */   private static final QName ATTRIBUTEGROUP$10 = new QName("http://www.w3.org/2001/XMLSchema", "attributeGroup");
/*     */   
/*  34 */   private static final QName ANYATTRIBUTE$12 = new QName("http://www.w3.org/2001/XMLSchema", "anyAttribute");
/*     */   
/*  36 */   private static final QName BASE$14 = new QName("", "base");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroupRef getGroup() {
/*  45 */     synchronized (monitor()) {
/*     */       
/*  47 */       check_orphaned();
/*  48 */       GroupRef target = null;
/*  49 */       target = (GroupRef)get_store().find_element_user(GROUP$0, 0);
/*  50 */       if (target == null)
/*     */       {
/*  52 */         return null;
/*     */       }
/*  54 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetGroup() {
/*  63 */     synchronized (monitor()) {
/*     */       
/*  65 */       check_orphaned();
/*  66 */       return (get_store().count_elements(GROUP$0) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGroup(GroupRef group) {
/*  75 */     synchronized (monitor()) {
/*     */       
/*  77 */       check_orphaned();
/*  78 */       GroupRef target = null;
/*  79 */       target = (GroupRef)get_store().find_element_user(GROUP$0, 0);
/*  80 */       if (target == null)
/*     */       {
/*  82 */         target = (GroupRef)get_store().add_element_user(GROUP$0);
/*     */       }
/*  84 */       target.set((XmlObject)group);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroupRef addNewGroup() {
/*  93 */     synchronized (monitor()) {
/*     */       
/*  95 */       check_orphaned();
/*  96 */       GroupRef target = null;
/*  97 */       target = (GroupRef)get_store().add_element_user(GROUP$0);
/*  98 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetGroup() {
/* 107 */     synchronized (monitor()) {
/*     */       
/* 109 */       check_orphaned();
/* 110 */       get_store().remove_element(GROUP$0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public All getAll() {
/* 119 */     synchronized (monitor()) {
/*     */       
/* 121 */       check_orphaned();
/* 122 */       All target = null;
/* 123 */       target = (All)get_store().find_element_user(ALL$2, 0);
/* 124 */       if (target == null)
/*     */       {
/* 126 */         return null;
/*     */       }
/* 128 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetAll() {
/* 137 */     synchronized (monitor()) {
/*     */       
/* 139 */       check_orphaned();
/* 140 */       return (get_store().count_elements(ALL$2) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAll(All all) {
/* 149 */     synchronized (monitor()) {
/*     */       
/* 151 */       check_orphaned();
/* 152 */       All target = null;
/* 153 */       target = (All)get_store().find_element_user(ALL$2, 0);
/* 154 */       if (target == null)
/*     */       {
/* 156 */         target = (All)get_store().add_element_user(ALL$2);
/*     */       }
/* 158 */       target.set((XmlObject)all);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public All addNewAll() {
/* 167 */     synchronized (monitor()) {
/*     */       
/* 169 */       check_orphaned();
/* 170 */       All target = null;
/* 171 */       target = (All)get_store().add_element_user(ALL$2);
/* 172 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetAll() {
/* 181 */     synchronized (monitor()) {
/*     */       
/* 183 */       check_orphaned();
/* 184 */       get_store().remove_element(ALL$2, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExplicitGroup getChoice() {
/* 193 */     synchronized (monitor()) {
/*     */       
/* 195 */       check_orphaned();
/* 196 */       ExplicitGroup target = null;
/* 197 */       target = (ExplicitGroup)get_store().find_element_user(CHOICE$4, 0);
/* 198 */       if (target == null)
/*     */       {
/* 200 */         return null;
/*     */       }
/* 202 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetChoice() {
/* 211 */     synchronized (monitor()) {
/*     */       
/* 213 */       check_orphaned();
/* 214 */       return (get_store().count_elements(CHOICE$4) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChoice(ExplicitGroup choice) {
/* 223 */     synchronized (monitor()) {
/*     */       
/* 225 */       check_orphaned();
/* 226 */       ExplicitGroup target = null;
/* 227 */       target = (ExplicitGroup)get_store().find_element_user(CHOICE$4, 0);
/* 228 */       if (target == null)
/*     */       {
/* 230 */         target = (ExplicitGroup)get_store().add_element_user(CHOICE$4);
/*     */       }
/* 232 */       target.set((XmlObject)choice);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExplicitGroup addNewChoice() {
/* 241 */     synchronized (monitor()) {
/*     */       
/* 243 */       check_orphaned();
/* 244 */       ExplicitGroup target = null;
/* 245 */       target = (ExplicitGroup)get_store().add_element_user(CHOICE$4);
/* 246 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetChoice() {
/* 255 */     synchronized (monitor()) {
/*     */       
/* 257 */       check_orphaned();
/* 258 */       get_store().remove_element(CHOICE$4, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExplicitGroup getSequence() {
/* 267 */     synchronized (monitor()) {
/*     */       
/* 269 */       check_orphaned();
/* 270 */       ExplicitGroup target = null;
/* 271 */       target = (ExplicitGroup)get_store().find_element_user(SEQUENCE$6, 0);
/* 272 */       if (target == null)
/*     */       {
/* 274 */         return null;
/*     */       }
/* 276 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetSequence() {
/* 285 */     synchronized (monitor()) {
/*     */       
/* 287 */       check_orphaned();
/* 288 */       return (get_store().count_elements(SEQUENCE$6) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSequence(ExplicitGroup sequence) {
/* 297 */     synchronized (monitor()) {
/*     */       
/* 299 */       check_orphaned();
/* 300 */       ExplicitGroup target = null;
/* 301 */       target = (ExplicitGroup)get_store().find_element_user(SEQUENCE$6, 0);
/* 302 */       if (target == null)
/*     */       {
/* 304 */         target = (ExplicitGroup)get_store().add_element_user(SEQUENCE$6);
/*     */       }
/* 306 */       target.set((XmlObject)sequence);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExplicitGroup addNewSequence() {
/* 315 */     synchronized (monitor()) {
/*     */       
/* 317 */       check_orphaned();
/* 318 */       ExplicitGroup target = null;
/* 319 */       target = (ExplicitGroup)get_store().add_element_user(SEQUENCE$6);
/* 320 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSequence() {
/* 329 */     synchronized (monitor()) {
/*     */       
/* 331 */       check_orphaned();
/* 332 */       get_store().remove_element(SEQUENCE$6, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute[] getAttributeArray() {
/* 341 */     synchronized (monitor()) {
/*     */       
/* 343 */       check_orphaned();
/* 344 */       List targetList = new ArrayList();
/* 345 */       get_store().find_all_element_users(ATTRIBUTE$8, targetList);
/* 346 */       Attribute[] result = new Attribute[targetList.size()];
/* 347 */       targetList.toArray((Object[])result);
/* 348 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute getAttributeArray(int i) {
/* 357 */     synchronized (monitor()) {
/*     */       
/* 359 */       check_orphaned();
/* 360 */       Attribute target = null;
/* 361 */       target = (Attribute)get_store().find_element_user(ATTRIBUTE$8, i);
/* 362 */       if (target == null)
/*     */       {
/* 364 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 366 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOfAttributeArray() {
/* 375 */     synchronized (monitor()) {
/*     */       
/* 377 */       check_orphaned();
/* 378 */       return get_store().count_elements(ATTRIBUTE$8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeArray(Attribute[] attributeArray) {
/* 387 */     synchronized (monitor()) {
/*     */       
/* 389 */       check_orphaned();
/* 390 */       arraySetterHelper((XmlObject[])attributeArray, ATTRIBUTE$8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeArray(int i, Attribute attribute) {
/* 399 */     synchronized (monitor()) {
/*     */       
/* 401 */       check_orphaned();
/* 402 */       Attribute target = null;
/* 403 */       target = (Attribute)get_store().find_element_user(ATTRIBUTE$8, i);
/* 404 */       if (target == null)
/*     */       {
/* 406 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 408 */       target.set((XmlObject)attribute);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute insertNewAttribute(int i) {
/* 417 */     synchronized (monitor()) {
/*     */       
/* 419 */       check_orphaned();
/* 420 */       Attribute target = null;
/* 421 */       target = (Attribute)get_store().insert_element_user(ATTRIBUTE$8, i);
/* 422 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute addNewAttribute() {
/* 431 */     synchronized (monitor()) {
/*     */       
/* 433 */       check_orphaned();
/* 434 */       Attribute target = null;
/* 435 */       target = (Attribute)get_store().add_element_user(ATTRIBUTE$8);
/* 436 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(int i) {
/* 445 */     synchronized (monitor()) {
/*     */       
/* 447 */       check_orphaned();
/* 448 */       get_store().remove_element(ATTRIBUTE$8, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef[] getAttributeGroupArray() {
/* 457 */     synchronized (monitor()) {
/*     */       
/* 459 */       check_orphaned();
/* 460 */       List targetList = new ArrayList();
/* 461 */       get_store().find_all_element_users(ATTRIBUTEGROUP$10, targetList);
/* 462 */       AttributeGroupRef[] result = new AttributeGroupRef[targetList.size()];
/* 463 */       targetList.toArray((Object[])result);
/* 464 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef getAttributeGroupArray(int i) {
/* 473 */     synchronized (monitor()) {
/*     */       
/* 475 */       check_orphaned();
/* 476 */       AttributeGroupRef target = null;
/* 477 */       target = (AttributeGroupRef)get_store().find_element_user(ATTRIBUTEGROUP$10, i);
/* 478 */       if (target == null)
/*     */       {
/* 480 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 482 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOfAttributeGroupArray() {
/* 491 */     synchronized (monitor()) {
/*     */       
/* 493 */       check_orphaned();
/* 494 */       return get_store().count_elements(ATTRIBUTEGROUP$10);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeGroupArray(AttributeGroupRef[] attributeGroupArray) {
/* 503 */     synchronized (monitor()) {
/*     */       
/* 505 */       check_orphaned();
/* 506 */       arraySetterHelper((XmlObject[])attributeGroupArray, ATTRIBUTEGROUP$10);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeGroupArray(int i, AttributeGroupRef attributeGroup) {
/* 515 */     synchronized (monitor()) {
/*     */       
/* 517 */       check_orphaned();
/* 518 */       AttributeGroupRef target = null;
/* 519 */       target = (AttributeGroupRef)get_store().find_element_user(ATTRIBUTEGROUP$10, i);
/* 520 */       if (target == null)
/*     */       {
/* 522 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 524 */       target.set((XmlObject)attributeGroup);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef insertNewAttributeGroup(int i) {
/* 533 */     synchronized (monitor()) {
/*     */       
/* 535 */       check_orphaned();
/* 536 */       AttributeGroupRef target = null;
/* 537 */       target = (AttributeGroupRef)get_store().insert_element_user(ATTRIBUTEGROUP$10, i);
/* 538 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef addNewAttributeGroup() {
/* 547 */     synchronized (monitor()) {
/*     */       
/* 549 */       check_orphaned();
/* 550 */       AttributeGroupRef target = null;
/* 551 */       target = (AttributeGroupRef)get_store().add_element_user(ATTRIBUTEGROUP$10);
/* 552 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttributeGroup(int i) {
/* 561 */     synchronized (monitor()) {
/*     */       
/* 563 */       check_orphaned();
/* 564 */       get_store().remove_element(ATTRIBUTEGROUP$10, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Wildcard getAnyAttribute() {
/* 573 */     synchronized (monitor()) {
/*     */       
/* 575 */       check_orphaned();
/* 576 */       Wildcard target = null;
/* 577 */       target = (Wildcard)get_store().find_element_user(ANYATTRIBUTE$12, 0);
/* 578 */       if (target == null)
/*     */       {
/* 580 */         return null;
/*     */       }
/* 582 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetAnyAttribute() {
/* 591 */     synchronized (monitor()) {
/*     */       
/* 593 */       check_orphaned();
/* 594 */       return (get_store().count_elements(ANYATTRIBUTE$12) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnyAttribute(Wildcard anyAttribute) {
/* 603 */     synchronized (monitor()) {
/*     */       
/* 605 */       check_orphaned();
/* 606 */       Wildcard target = null;
/* 607 */       target = (Wildcard)get_store().find_element_user(ANYATTRIBUTE$12, 0);
/* 608 */       if (target == null)
/*     */       {
/* 610 */         target = (Wildcard)get_store().add_element_user(ANYATTRIBUTE$12);
/*     */       }
/* 612 */       target.set((XmlObject)anyAttribute);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Wildcard addNewAnyAttribute() {
/* 621 */     synchronized (monitor()) {
/*     */       
/* 623 */       check_orphaned();
/* 624 */       Wildcard target = null;
/* 625 */       target = (Wildcard)get_store().add_element_user(ANYATTRIBUTE$12);
/* 626 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetAnyAttribute() {
/* 635 */     synchronized (monitor()) {
/*     */       
/* 637 */       check_orphaned();
/* 638 */       get_store().remove_element(ANYATTRIBUTE$12, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getBase() {
/* 647 */     synchronized (monitor()) {
/*     */       
/* 649 */       check_orphaned();
/* 650 */       SimpleValue target = null;
/* 651 */       target = (SimpleValue)get_store().find_attribute_user(BASE$14);
/* 652 */       if (target == null)
/*     */       {
/* 654 */         return null;
/*     */       }
/* 656 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetBase() {
/* 665 */     synchronized (monitor()) {
/*     */       
/* 667 */       check_orphaned();
/* 668 */       XmlQName target = null;
/* 669 */       target = (XmlQName)get_store().find_attribute_user(BASE$14);
/* 670 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBase(QName base) {
/* 679 */     synchronized (monitor()) {
/*     */       
/* 681 */       check_orphaned();
/* 682 */       SimpleValue target = null;
/* 683 */       target = (SimpleValue)get_store().find_attribute_user(BASE$14);
/* 684 */       if (target == null)
/*     */       {
/* 686 */         target = (SimpleValue)get_store().add_attribute_user(BASE$14);
/*     */       }
/* 688 */       target.setQNameValue(base);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetBase(XmlQName base) {
/* 697 */     synchronized (monitor()) {
/*     */       
/* 699 */       check_orphaned();
/* 700 */       XmlQName target = null;
/* 701 */       target = (XmlQName)get_store().find_attribute_user(BASE$14);
/* 702 */       if (target == null)
/*     */       {
/* 704 */         target = (XmlQName)get_store().add_attribute_user(BASE$14);
/*     */       }
/* 706 */       target.set((XmlObject)base);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\ExtensionTypeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */