/*     */ package org.apache.xmlbeans.impl.xb.xmlschema;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface BaseAttribute extends XmlObject {
/*  19 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlschema$BaseAttribute == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlschema$BaseAttribute = null.class$("org.apache.xmlbeans.impl.xb.xmlschema.BaseAttribute")) : null.class$org$apache$xmlbeans$impl$xb$xmlschema$BaseAttribute).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLLANG").resolveHandle("basece23attrtypetype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getBase();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI xgetBase();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetBase();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setBase(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetBase(XmlAnyURI paramXmlAnyURI);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetBase();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static BaseAttribute newInstance() {
/*  60 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().newInstance(BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute newInstance(XmlOptions options) {
/*  63 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().newInstance(BaseAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static BaseAttribute parse(String xmlAsString) throws XmlException {
/*  67 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(xmlAsString, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(String xmlAsString, XmlOptions options) throws XmlException {
/*  70 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(xmlAsString, BaseAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static BaseAttribute parse(File file) throws XmlException, IOException {
/*  74 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(file, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(File file, XmlOptions options) throws XmlException, IOException {
/*  77 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(file, BaseAttribute.type, options);
/*     */     }
/*     */     public static BaseAttribute parse(URL u) throws XmlException, IOException {
/*  80 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(u, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(URL u, XmlOptions options) throws XmlException, IOException {
/*  83 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(u, BaseAttribute.type, options);
/*     */     }
/*     */     public static BaseAttribute parse(InputStream is) throws XmlException, IOException {
/*  86 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(is, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/*  89 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(is, BaseAttribute.type, options);
/*     */     }
/*     */     public static BaseAttribute parse(Reader r) throws XmlException, IOException {
/*  92 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(r, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(Reader r, XmlOptions options) throws XmlException, IOException {
/*  95 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(r, BaseAttribute.type, options);
/*     */     }
/*     */     public static BaseAttribute parse(XMLStreamReader sr) throws XmlException {
/*  98 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(sr, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 101 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(sr, BaseAttribute.type, options);
/*     */     }
/*     */     public static BaseAttribute parse(Node node) throws XmlException {
/* 104 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(node, BaseAttribute.type, null);
/*     */     }
/*     */     public static BaseAttribute parse(Node node, XmlOptions options) throws XmlException {
/* 107 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(node, BaseAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static BaseAttribute parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 111 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(xis, BaseAttribute.type, null);
/*     */     }
/*     */     
/*     */     public static BaseAttribute parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 115 */       return (BaseAttribute)XmlBeans.getContextTypeLoader().parse(xis, BaseAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 119 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, BaseAttribute.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 123 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, BaseAttribute.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlschema\BaseAttribute.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */