/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface ConfigDocument extends XmlObject {
/*  19 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$ConfigDocument == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$ConfigDocument = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$ConfigDocument).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("config4185doctype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Config getConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setConfig(Config paramConfig);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Config addNewConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Config
/*     */     extends XmlObject
/*     */   {
/*  44 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((ConfigDocument.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$ConfigDocument$Config == null) ? (ConfigDocument.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$ConfigDocument$Config = ConfigDocument.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument$Config")) : ConfigDocument.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$ConfigDocument$Config).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("configf467elemtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Nsconfig[] getNamespaceArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Nsconfig getNamespaceArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfNamespaceArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setNamespaceArray(Nsconfig[] param1ArrayOfNsconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setNamespaceArray(int param1Int, Nsconfig param1Nsconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Nsconfig insertNewNamespace(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Nsconfig addNewNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeNamespace(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Qnameconfig[] getQnameArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Qnameconfig getQnameArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfQnameArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setQnameArray(Qnameconfig[] param1ArrayOfQnameconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setQnameArray(int param1Int, Qnameconfig param1Qnameconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Qnameconfig insertNewQname(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Qnameconfig addNewQname();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeQname(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Extensionconfig[] getExtensionArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Extensionconfig getExtensionArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfExtensionArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setExtensionArray(Extensionconfig[] param1ArrayOfExtensionconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setExtensionArray(int param1Int, Extensionconfig param1Extensionconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Extensionconfig insertNewExtension(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Extensionconfig addNewExtension();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeExtension(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Usertypeconfig[] getUsertypeArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Usertypeconfig getUsertypeArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfUsertypeArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setUsertypeArray(Usertypeconfig[] param1ArrayOfUsertypeconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setUsertypeArray(int param1Int, Usertypeconfig param1Usertypeconfig);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Usertypeconfig insertNewUsertype(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Usertypeconfig addNewUsertype();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeUsertype(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static ConfigDocument.Config newInstance() {
/* 215 */         return (ConfigDocument.Config)XmlBeans.getContextTypeLoader().newInstance(ConfigDocument.Config.type, null);
/*     */       }
/*     */       public static ConfigDocument.Config newInstance(XmlOptions options) {
/* 218 */         return (ConfigDocument.Config)XmlBeans.getContextTypeLoader().newInstance(ConfigDocument.Config.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static ConfigDocument newInstance() {
/* 232 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().newInstance(ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument newInstance(XmlOptions options) {
/* 235 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().newInstance(ConfigDocument.type, options);
/*     */     }
/*     */     
/*     */     public static ConfigDocument parse(String xmlAsString) throws XmlException {
/* 239 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(xmlAsString, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 242 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(xmlAsString, ConfigDocument.type, options);
/*     */     }
/*     */     
/*     */     public static ConfigDocument parse(File file) throws XmlException, IOException {
/* 246 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(file, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(File file, XmlOptions options) throws XmlException, IOException {
/* 249 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(file, ConfigDocument.type, options);
/*     */     }
/*     */     public static ConfigDocument parse(URL u) throws XmlException, IOException {
/* 252 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(u, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 255 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(u, ConfigDocument.type, options);
/*     */     }
/*     */     public static ConfigDocument parse(InputStream is) throws XmlException, IOException {
/* 258 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(is, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 261 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(is, ConfigDocument.type, options);
/*     */     }
/*     */     public static ConfigDocument parse(Reader r) throws XmlException, IOException {
/* 264 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(r, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 267 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(r, ConfigDocument.type, options);
/*     */     }
/*     */     public static ConfigDocument parse(XMLStreamReader sr) throws XmlException {
/* 270 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(sr, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 273 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(sr, ConfigDocument.type, options);
/*     */     }
/*     */     public static ConfigDocument parse(Node node) throws XmlException {
/* 276 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(node, ConfigDocument.type, null);
/*     */     }
/*     */     public static ConfigDocument parse(Node node, XmlOptions options) throws XmlException {
/* 279 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(node, ConfigDocument.type, options);
/*     */     }
/*     */     
/*     */     public static ConfigDocument parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 283 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(xis, ConfigDocument.type, null);
/*     */     }
/*     */     
/*     */     public static ConfigDocument parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 287 */       return (ConfigDocument)XmlBeans.getContextTypeLoader().parse(xis, ConfigDocument.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 291 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, ConfigDocument.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 295 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, ConfigDocument.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\ConfigDocument.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */