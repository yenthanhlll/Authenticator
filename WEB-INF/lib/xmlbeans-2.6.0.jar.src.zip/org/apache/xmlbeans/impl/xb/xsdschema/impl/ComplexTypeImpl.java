/*      */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.SimpleValue;
/*      */ import org.apache.xmlbeans.XmlBoolean;
/*      */ import org.apache.xmlbeans.XmlNCName;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.All;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroupRef;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexContentDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.DerivationSet;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ExplicitGroup;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.GroupRef;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleContentDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Wildcard;
/*      */ 
/*      */ public class ComplexTypeImpl extends AnnotatedImpl implements ComplexType {
/*      */   public ComplexTypeImpl(SchemaType sType) {
/*   19 */     super(sType);
/*      */   }
/*      */   
/*   22 */   private static final QName SIMPLECONTENT$0 = new QName("http://www.w3.org/2001/XMLSchema", "simpleContent");
/*      */   
/*   24 */   private static final QName COMPLEXCONTENT$2 = new QName("http://www.w3.org/2001/XMLSchema", "complexContent");
/*      */   
/*   26 */   private static final QName GROUP$4 = new QName("http://www.w3.org/2001/XMLSchema", "group");
/*      */   
/*   28 */   private static final QName ALL$6 = new QName("http://www.w3.org/2001/XMLSchema", "all");
/*      */   
/*   30 */   private static final QName CHOICE$8 = new QName("http://www.w3.org/2001/XMLSchema", "choice");
/*      */   
/*   32 */   private static final QName SEQUENCE$10 = new QName("http://www.w3.org/2001/XMLSchema", "sequence");
/*      */   
/*   34 */   private static final QName ATTRIBUTE$12 = new QName("http://www.w3.org/2001/XMLSchema", "attribute");
/*      */   
/*   36 */   private static final QName ATTRIBUTEGROUP$14 = new QName("http://www.w3.org/2001/XMLSchema", "attributeGroup");
/*      */   
/*   38 */   private static final QName ANYATTRIBUTE$16 = new QName("http://www.w3.org/2001/XMLSchema", "anyAttribute");
/*      */   
/*   40 */   private static final QName NAME$18 = new QName("", "name");
/*      */   
/*   42 */   private static final QName MIXED$20 = new QName("", "mixed");
/*      */   
/*   44 */   private static final QName ABSTRACT$22 = new QName("", "abstract");
/*      */   
/*   46 */   private static final QName FINAL$24 = new QName("", "final");
/*      */   
/*   48 */   private static final QName BLOCK$26 = new QName("", "block");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleContentDocument.SimpleContent getSimpleContent() {
/*   57 */     synchronized (monitor()) {
/*      */       
/*   59 */       check_orphaned();
/*   60 */       SimpleContentDocument.SimpleContent target = null;
/*   61 */       target = (SimpleContentDocument.SimpleContent)get_store().find_element_user(SIMPLECONTENT$0, 0);
/*   62 */       if (target == null)
/*      */       {
/*   64 */         return null;
/*      */       }
/*   66 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetSimpleContent() {
/*   75 */     synchronized (monitor()) {
/*      */       
/*   77 */       check_orphaned();
/*   78 */       return (get_store().count_elements(SIMPLECONTENT$0) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSimpleContent(SimpleContentDocument.SimpleContent simpleContent) {
/*   87 */     synchronized (monitor()) {
/*      */       
/*   89 */       check_orphaned();
/*   90 */       SimpleContentDocument.SimpleContent target = null;
/*   91 */       target = (SimpleContentDocument.SimpleContent)get_store().find_element_user(SIMPLECONTENT$0, 0);
/*   92 */       if (target == null)
/*      */       {
/*   94 */         target = (SimpleContentDocument.SimpleContent)get_store().add_element_user(SIMPLECONTENT$0);
/*      */       }
/*   96 */       target.set((XmlObject)simpleContent);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleContentDocument.SimpleContent addNewSimpleContent() {
/*  105 */     synchronized (monitor()) {
/*      */       
/*  107 */       check_orphaned();
/*  108 */       SimpleContentDocument.SimpleContent target = null;
/*  109 */       target = (SimpleContentDocument.SimpleContent)get_store().add_element_user(SIMPLECONTENT$0);
/*  110 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetSimpleContent() {
/*  119 */     synchronized (monitor()) {
/*      */       
/*  121 */       check_orphaned();
/*  122 */       get_store().remove_element(SIMPLECONTENT$0, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ComplexContentDocument.ComplexContent getComplexContent() {
/*  131 */     synchronized (monitor()) {
/*      */       
/*  133 */       check_orphaned();
/*  134 */       ComplexContentDocument.ComplexContent target = null;
/*  135 */       target = (ComplexContentDocument.ComplexContent)get_store().find_element_user(COMPLEXCONTENT$2, 0);
/*  136 */       if (target == null)
/*      */       {
/*  138 */         return null;
/*      */       }
/*  140 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetComplexContent() {
/*  149 */     synchronized (monitor()) {
/*      */       
/*  151 */       check_orphaned();
/*  152 */       return (get_store().count_elements(COMPLEXCONTENT$2) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComplexContent(ComplexContentDocument.ComplexContent complexContent) {
/*  161 */     synchronized (monitor()) {
/*      */       
/*  163 */       check_orphaned();
/*  164 */       ComplexContentDocument.ComplexContent target = null;
/*  165 */       target = (ComplexContentDocument.ComplexContent)get_store().find_element_user(COMPLEXCONTENT$2, 0);
/*  166 */       if (target == null)
/*      */       {
/*  168 */         target = (ComplexContentDocument.ComplexContent)get_store().add_element_user(COMPLEXCONTENT$2);
/*      */       }
/*  170 */       target.set((XmlObject)complexContent);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ComplexContentDocument.ComplexContent addNewComplexContent() {
/*  179 */     synchronized (monitor()) {
/*      */       
/*  181 */       check_orphaned();
/*  182 */       ComplexContentDocument.ComplexContent target = null;
/*  183 */       target = (ComplexContentDocument.ComplexContent)get_store().add_element_user(COMPLEXCONTENT$2);
/*  184 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetComplexContent() {
/*  193 */     synchronized (monitor()) {
/*      */       
/*  195 */       check_orphaned();
/*  196 */       get_store().remove_element(COMPLEXCONTENT$2, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GroupRef getGroup() {
/*  205 */     synchronized (monitor()) {
/*      */       
/*  207 */       check_orphaned();
/*  208 */       GroupRef target = null;
/*  209 */       target = (GroupRef)get_store().find_element_user(GROUP$4, 0);
/*  210 */       if (target == null)
/*      */       {
/*  212 */         return null;
/*      */       }
/*  214 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetGroup() {
/*  223 */     synchronized (monitor()) {
/*      */       
/*  225 */       check_orphaned();
/*  226 */       return (get_store().count_elements(GROUP$4) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGroup(GroupRef group) {
/*  235 */     synchronized (monitor()) {
/*      */       
/*  237 */       check_orphaned();
/*  238 */       GroupRef target = null;
/*  239 */       target = (GroupRef)get_store().find_element_user(GROUP$4, 0);
/*  240 */       if (target == null)
/*      */       {
/*  242 */         target = (GroupRef)get_store().add_element_user(GROUP$4);
/*      */       }
/*  244 */       target.set((XmlObject)group);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GroupRef addNewGroup() {
/*  253 */     synchronized (monitor()) {
/*      */       
/*  255 */       check_orphaned();
/*  256 */       GroupRef target = null;
/*  257 */       target = (GroupRef)get_store().add_element_user(GROUP$4);
/*  258 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetGroup() {
/*  267 */     synchronized (monitor()) {
/*      */       
/*  269 */       check_orphaned();
/*  270 */       get_store().remove_element(GROUP$4, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public All getAll() {
/*  279 */     synchronized (monitor()) {
/*      */       
/*  281 */       check_orphaned();
/*  282 */       All target = null;
/*  283 */       target = (All)get_store().find_element_user(ALL$6, 0);
/*  284 */       if (target == null)
/*      */       {
/*  286 */         return null;
/*      */       }
/*  288 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetAll() {
/*  297 */     synchronized (monitor()) {
/*      */       
/*  299 */       check_orphaned();
/*  300 */       return (get_store().count_elements(ALL$6) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAll(All all) {
/*  309 */     synchronized (monitor()) {
/*      */       
/*  311 */       check_orphaned();
/*  312 */       All target = null;
/*  313 */       target = (All)get_store().find_element_user(ALL$6, 0);
/*  314 */       if (target == null)
/*      */       {
/*  316 */         target = (All)get_store().add_element_user(ALL$6);
/*      */       }
/*  318 */       target.set((XmlObject)all);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public All addNewAll() {
/*  327 */     synchronized (monitor()) {
/*      */       
/*  329 */       check_orphaned();
/*  330 */       All target = null;
/*  331 */       target = (All)get_store().add_element_user(ALL$6);
/*  332 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetAll() {
/*  341 */     synchronized (monitor()) {
/*      */       
/*  343 */       check_orphaned();
/*  344 */       get_store().remove_element(ALL$6, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExplicitGroup getChoice() {
/*  353 */     synchronized (monitor()) {
/*      */       
/*  355 */       check_orphaned();
/*  356 */       ExplicitGroup target = null;
/*  357 */       target = (ExplicitGroup)get_store().find_element_user(CHOICE$8, 0);
/*  358 */       if (target == null)
/*      */       {
/*  360 */         return null;
/*      */       }
/*  362 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetChoice() {
/*  371 */     synchronized (monitor()) {
/*      */       
/*  373 */       check_orphaned();
/*  374 */       return (get_store().count_elements(CHOICE$8) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChoice(ExplicitGroup choice) {
/*  383 */     synchronized (monitor()) {
/*      */       
/*  385 */       check_orphaned();
/*  386 */       ExplicitGroup target = null;
/*  387 */       target = (ExplicitGroup)get_store().find_element_user(CHOICE$8, 0);
/*  388 */       if (target == null)
/*      */       {
/*  390 */         target = (ExplicitGroup)get_store().add_element_user(CHOICE$8);
/*      */       }
/*  392 */       target.set((XmlObject)choice);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExplicitGroup addNewChoice() {
/*  401 */     synchronized (monitor()) {
/*      */       
/*  403 */       check_orphaned();
/*  404 */       ExplicitGroup target = null;
/*  405 */       target = (ExplicitGroup)get_store().add_element_user(CHOICE$8);
/*  406 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetChoice() {
/*  415 */     synchronized (monitor()) {
/*      */       
/*  417 */       check_orphaned();
/*  418 */       get_store().remove_element(CHOICE$8, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExplicitGroup getSequence() {
/*  427 */     synchronized (monitor()) {
/*      */       
/*  429 */       check_orphaned();
/*  430 */       ExplicitGroup target = null;
/*  431 */       target = (ExplicitGroup)get_store().find_element_user(SEQUENCE$10, 0);
/*  432 */       if (target == null)
/*      */       {
/*  434 */         return null;
/*      */       }
/*  436 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetSequence() {
/*  445 */     synchronized (monitor()) {
/*      */       
/*  447 */       check_orphaned();
/*  448 */       return (get_store().count_elements(SEQUENCE$10) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSequence(ExplicitGroup sequence) {
/*  457 */     synchronized (monitor()) {
/*      */       
/*  459 */       check_orphaned();
/*  460 */       ExplicitGroup target = null;
/*  461 */       target = (ExplicitGroup)get_store().find_element_user(SEQUENCE$10, 0);
/*  462 */       if (target == null)
/*      */       {
/*  464 */         target = (ExplicitGroup)get_store().add_element_user(SEQUENCE$10);
/*      */       }
/*  466 */       target.set((XmlObject)sequence);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExplicitGroup addNewSequence() {
/*  475 */     synchronized (monitor()) {
/*      */       
/*  477 */       check_orphaned();
/*  478 */       ExplicitGroup target = null;
/*  479 */       target = (ExplicitGroup)get_store().add_element_user(SEQUENCE$10);
/*  480 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetSequence() {
/*  489 */     synchronized (monitor()) {
/*      */       
/*  491 */       check_orphaned();
/*  492 */       get_store().remove_element(SEQUENCE$10, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attribute[] getAttributeArray() {
/*  501 */     synchronized (monitor()) {
/*      */       
/*  503 */       check_orphaned();
/*  504 */       List targetList = new ArrayList();
/*  505 */       get_store().find_all_element_users(ATTRIBUTE$12, targetList);
/*  506 */       Attribute[] result = new Attribute[targetList.size()];
/*  507 */       targetList.toArray((Object[])result);
/*  508 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attribute getAttributeArray(int i) {
/*  517 */     synchronized (monitor()) {
/*      */       
/*  519 */       check_orphaned();
/*  520 */       Attribute target = null;
/*  521 */       target = (Attribute)get_store().find_element_user(ATTRIBUTE$12, i);
/*  522 */       if (target == null)
/*      */       {
/*  524 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  526 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sizeOfAttributeArray() {
/*  535 */     synchronized (monitor()) {
/*      */       
/*  537 */       check_orphaned();
/*  538 */       return get_store().count_elements(ATTRIBUTE$12);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeArray(Attribute[] attributeArray) {
/*  547 */     synchronized (monitor()) {
/*      */       
/*  549 */       check_orphaned();
/*  550 */       arraySetterHelper((XmlObject[])attributeArray, ATTRIBUTE$12);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeArray(int i, Attribute attribute) {
/*  559 */     synchronized (monitor()) {
/*      */       
/*  561 */       check_orphaned();
/*  562 */       Attribute target = null;
/*  563 */       target = (Attribute)get_store().find_element_user(ATTRIBUTE$12, i);
/*  564 */       if (target == null)
/*      */       {
/*  566 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  568 */       target.set((XmlObject)attribute);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attribute insertNewAttribute(int i) {
/*  577 */     synchronized (monitor()) {
/*      */       
/*  579 */       check_orphaned();
/*  580 */       Attribute target = null;
/*  581 */       target = (Attribute)get_store().insert_element_user(ATTRIBUTE$12, i);
/*  582 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attribute addNewAttribute() {
/*  591 */     synchronized (monitor()) {
/*      */       
/*  593 */       check_orphaned();
/*  594 */       Attribute target = null;
/*  595 */       target = (Attribute)get_store().add_element_user(ATTRIBUTE$12);
/*  596 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(int i) {
/*  605 */     synchronized (monitor()) {
/*      */       
/*  607 */       check_orphaned();
/*  608 */       get_store().remove_element(ATTRIBUTE$12, i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AttributeGroupRef[] getAttributeGroupArray() {
/*  617 */     synchronized (monitor()) {
/*      */       
/*  619 */       check_orphaned();
/*  620 */       List targetList = new ArrayList();
/*  621 */       get_store().find_all_element_users(ATTRIBUTEGROUP$14, targetList);
/*  622 */       AttributeGroupRef[] result = new AttributeGroupRef[targetList.size()];
/*  623 */       targetList.toArray((Object[])result);
/*  624 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AttributeGroupRef getAttributeGroupArray(int i) {
/*  633 */     synchronized (monitor()) {
/*      */       
/*  635 */       check_orphaned();
/*  636 */       AttributeGroupRef target = null;
/*  637 */       target = (AttributeGroupRef)get_store().find_element_user(ATTRIBUTEGROUP$14, i);
/*  638 */       if (target == null)
/*      */       {
/*  640 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  642 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sizeOfAttributeGroupArray() {
/*  651 */     synchronized (monitor()) {
/*      */       
/*  653 */       check_orphaned();
/*  654 */       return get_store().count_elements(ATTRIBUTEGROUP$14);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeGroupArray(AttributeGroupRef[] attributeGroupArray) {
/*  663 */     synchronized (monitor()) {
/*      */       
/*  665 */       check_orphaned();
/*  666 */       arraySetterHelper((XmlObject[])attributeGroupArray, ATTRIBUTEGROUP$14);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeGroupArray(int i, AttributeGroupRef attributeGroup) {
/*  675 */     synchronized (monitor()) {
/*      */       
/*  677 */       check_orphaned();
/*  678 */       AttributeGroupRef target = null;
/*  679 */       target = (AttributeGroupRef)get_store().find_element_user(ATTRIBUTEGROUP$14, i);
/*  680 */       if (target == null)
/*      */       {
/*  682 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  684 */       target.set((XmlObject)attributeGroup);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AttributeGroupRef insertNewAttributeGroup(int i) {
/*  693 */     synchronized (monitor()) {
/*      */       
/*  695 */       check_orphaned();
/*  696 */       AttributeGroupRef target = null;
/*  697 */       target = (AttributeGroupRef)get_store().insert_element_user(ATTRIBUTEGROUP$14, i);
/*  698 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AttributeGroupRef addNewAttributeGroup() {
/*  707 */     synchronized (monitor()) {
/*      */       
/*  709 */       check_orphaned();
/*  710 */       AttributeGroupRef target = null;
/*  711 */       target = (AttributeGroupRef)get_store().add_element_user(ATTRIBUTEGROUP$14);
/*  712 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttributeGroup(int i) {
/*  721 */     synchronized (monitor()) {
/*      */       
/*  723 */       check_orphaned();
/*  724 */       get_store().remove_element(ATTRIBUTEGROUP$14, i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Wildcard getAnyAttribute() {
/*  733 */     synchronized (monitor()) {
/*      */       
/*  735 */       check_orphaned();
/*  736 */       Wildcard target = null;
/*  737 */       target = (Wildcard)get_store().find_element_user(ANYATTRIBUTE$16, 0);
/*  738 */       if (target == null)
/*      */       {
/*  740 */         return null;
/*      */       }
/*  742 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetAnyAttribute() {
/*  751 */     synchronized (monitor()) {
/*      */       
/*  753 */       check_orphaned();
/*  754 */       return (get_store().count_elements(ANYATTRIBUTE$16) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAnyAttribute(Wildcard anyAttribute) {
/*  763 */     synchronized (monitor()) {
/*      */       
/*  765 */       check_orphaned();
/*  766 */       Wildcard target = null;
/*  767 */       target = (Wildcard)get_store().find_element_user(ANYATTRIBUTE$16, 0);
/*  768 */       if (target == null)
/*      */       {
/*  770 */         target = (Wildcard)get_store().add_element_user(ANYATTRIBUTE$16);
/*      */       }
/*  772 */       target.set((XmlObject)anyAttribute);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Wildcard addNewAnyAttribute() {
/*  781 */     synchronized (monitor()) {
/*      */       
/*  783 */       check_orphaned();
/*  784 */       Wildcard target = null;
/*  785 */       target = (Wildcard)get_store().add_element_user(ANYATTRIBUTE$16);
/*  786 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetAnyAttribute() {
/*  795 */     synchronized (monitor()) {
/*      */       
/*  797 */       check_orphaned();
/*  798 */       get_store().remove_element(ANYATTRIBUTE$16, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  807 */     synchronized (monitor()) {
/*      */       
/*  809 */       check_orphaned();
/*  810 */       SimpleValue target = null;
/*  811 */       target = (SimpleValue)get_store().find_attribute_user(NAME$18);
/*  812 */       if (target == null)
/*      */       {
/*  814 */         return null;
/*      */       }
/*  816 */       return target.getStringValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlNCName xgetName() {
/*  825 */     synchronized (monitor()) {
/*      */       
/*  827 */       check_orphaned();
/*  828 */       XmlNCName target = null;
/*  829 */       target = (XmlNCName)get_store().find_attribute_user(NAME$18);
/*  830 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetName() {
/*  839 */     synchronized (monitor()) {
/*      */       
/*  841 */       check_orphaned();
/*  842 */       return (get_store().find_attribute_user(NAME$18) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  851 */     synchronized (monitor()) {
/*      */       
/*  853 */       check_orphaned();
/*  854 */       SimpleValue target = null;
/*  855 */       target = (SimpleValue)get_store().find_attribute_user(NAME$18);
/*  856 */       if (target == null)
/*      */       {
/*  858 */         target = (SimpleValue)get_store().add_attribute_user(NAME$18);
/*      */       }
/*  860 */       target.setStringValue(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetName(XmlNCName name) {
/*  869 */     synchronized (monitor()) {
/*      */       
/*  871 */       check_orphaned();
/*  872 */       XmlNCName target = null;
/*  873 */       target = (XmlNCName)get_store().find_attribute_user(NAME$18);
/*  874 */       if (target == null)
/*      */       {
/*  876 */         target = (XmlNCName)get_store().add_attribute_user(NAME$18);
/*      */       }
/*  878 */       target.set((XmlObject)name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetName() {
/*  887 */     synchronized (monitor()) {
/*      */       
/*  889 */       check_orphaned();
/*  890 */       get_store().remove_attribute(NAME$18);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMixed() {
/*  899 */     synchronized (monitor()) {
/*      */       
/*  901 */       check_orphaned();
/*  902 */       SimpleValue target = null;
/*  903 */       target = (SimpleValue)get_store().find_attribute_user(MIXED$20);
/*  904 */       if (target == null)
/*      */       {
/*  906 */         target = (SimpleValue)get_default_attribute_value(MIXED$20);
/*      */       }
/*  908 */       if (target == null)
/*      */       {
/*  910 */         return false;
/*      */       }
/*  912 */       return target.getBooleanValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlBoolean xgetMixed() {
/*  921 */     synchronized (monitor()) {
/*      */       
/*  923 */       check_orphaned();
/*  924 */       XmlBoolean target = null;
/*  925 */       target = (XmlBoolean)get_store().find_attribute_user(MIXED$20);
/*  926 */       if (target == null)
/*      */       {
/*  928 */         target = (XmlBoolean)get_default_attribute_value(MIXED$20);
/*      */       }
/*  930 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetMixed() {
/*  939 */     synchronized (monitor()) {
/*      */       
/*  941 */       check_orphaned();
/*  942 */       return (get_store().find_attribute_user(MIXED$20) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMixed(boolean mixed) {
/*  951 */     synchronized (monitor()) {
/*      */       
/*  953 */       check_orphaned();
/*  954 */       SimpleValue target = null;
/*  955 */       target = (SimpleValue)get_store().find_attribute_user(MIXED$20);
/*  956 */       if (target == null)
/*      */       {
/*  958 */         target = (SimpleValue)get_store().add_attribute_user(MIXED$20);
/*      */       }
/*  960 */       target.setBooleanValue(mixed);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetMixed(XmlBoolean mixed) {
/*  969 */     synchronized (monitor()) {
/*      */       
/*  971 */       check_orphaned();
/*  972 */       XmlBoolean target = null;
/*  973 */       target = (XmlBoolean)get_store().find_attribute_user(MIXED$20);
/*  974 */       if (target == null)
/*      */       {
/*  976 */         target = (XmlBoolean)get_store().add_attribute_user(MIXED$20);
/*      */       }
/*  978 */       target.set((XmlObject)mixed);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMixed() {
/*  987 */     synchronized (monitor()) {
/*      */       
/*  989 */       check_orphaned();
/*  990 */       get_store().remove_attribute(MIXED$20);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAbstract() {
/*  999 */     synchronized (monitor()) {
/*      */       
/* 1001 */       check_orphaned();
/* 1002 */       SimpleValue target = null;
/* 1003 */       target = (SimpleValue)get_store().find_attribute_user(ABSTRACT$22);
/* 1004 */       if (target == null)
/*      */       {
/* 1006 */         target = (SimpleValue)get_default_attribute_value(ABSTRACT$22);
/*      */       }
/* 1008 */       if (target == null)
/*      */       {
/* 1010 */         return false;
/*      */       }
/* 1012 */       return target.getBooleanValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlBoolean xgetAbstract() {
/* 1021 */     synchronized (monitor()) {
/*      */       
/* 1023 */       check_orphaned();
/* 1024 */       XmlBoolean target = null;
/* 1025 */       target = (XmlBoolean)get_store().find_attribute_user(ABSTRACT$22);
/* 1026 */       if (target == null)
/*      */       {
/* 1028 */         target = (XmlBoolean)get_default_attribute_value(ABSTRACT$22);
/*      */       }
/* 1030 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetAbstract() {
/* 1039 */     synchronized (monitor()) {
/*      */       
/* 1041 */       check_orphaned();
/* 1042 */       return (get_store().find_attribute_user(ABSTRACT$22) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAbstract(boolean xabstract) {
/* 1051 */     synchronized (monitor()) {
/*      */       
/* 1053 */       check_orphaned();
/* 1054 */       SimpleValue target = null;
/* 1055 */       target = (SimpleValue)get_store().find_attribute_user(ABSTRACT$22);
/* 1056 */       if (target == null)
/*      */       {
/* 1058 */         target = (SimpleValue)get_store().add_attribute_user(ABSTRACT$22);
/*      */       }
/* 1060 */       target.setBooleanValue(xabstract);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetAbstract(XmlBoolean xabstract) {
/* 1069 */     synchronized (monitor()) {
/*      */       
/* 1071 */       check_orphaned();
/* 1072 */       XmlBoolean target = null;
/* 1073 */       target = (XmlBoolean)get_store().find_attribute_user(ABSTRACT$22);
/* 1074 */       if (target == null)
/*      */       {
/* 1076 */         target = (XmlBoolean)get_store().add_attribute_user(ABSTRACT$22);
/*      */       }
/* 1078 */       target.set((XmlObject)xabstract);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetAbstract() {
/* 1087 */     synchronized (monitor()) {
/*      */       
/* 1089 */       check_orphaned();
/* 1090 */       get_store().remove_attribute(ABSTRACT$22);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getFinal() {
/* 1099 */     synchronized (monitor()) {
/*      */       
/* 1101 */       check_orphaned();
/* 1102 */       SimpleValue target = null;
/* 1103 */       target = (SimpleValue)get_store().find_attribute_user(FINAL$24);
/* 1104 */       if (target == null)
/*      */       {
/* 1106 */         return null;
/*      */       }
/* 1108 */       return target.getObjectValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DerivationSet xgetFinal() {
/* 1117 */     synchronized (monitor()) {
/*      */       
/* 1119 */       check_orphaned();
/* 1120 */       DerivationSet target = null;
/* 1121 */       target = (DerivationSet)get_store().find_attribute_user(FINAL$24);
/* 1122 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetFinal() {
/* 1131 */     synchronized (monitor()) {
/*      */       
/* 1133 */       check_orphaned();
/* 1134 */       return (get_store().find_attribute_user(FINAL$24) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFinal(Object xfinal) {
/* 1143 */     synchronized (monitor()) {
/*      */       
/* 1145 */       check_orphaned();
/* 1146 */       SimpleValue target = null;
/* 1147 */       target = (SimpleValue)get_store().find_attribute_user(FINAL$24);
/* 1148 */       if (target == null)
/*      */       {
/* 1150 */         target = (SimpleValue)get_store().add_attribute_user(FINAL$24);
/*      */       }
/* 1152 */       target.setObjectValue(xfinal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetFinal(DerivationSet xfinal) {
/* 1161 */     synchronized (monitor()) {
/*      */       
/* 1163 */       check_orphaned();
/* 1164 */       DerivationSet target = null;
/* 1165 */       target = (DerivationSet)get_store().find_attribute_user(FINAL$24);
/* 1166 */       if (target == null)
/*      */       {
/* 1168 */         target = (DerivationSet)get_store().add_attribute_user(FINAL$24);
/*      */       }
/* 1170 */       target.set((XmlObject)xfinal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetFinal() {
/* 1179 */     synchronized (monitor()) {
/*      */       
/* 1181 */       check_orphaned();
/* 1182 */       get_store().remove_attribute(FINAL$24);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getBlock() {
/* 1191 */     synchronized (monitor()) {
/*      */       
/* 1193 */       check_orphaned();
/* 1194 */       SimpleValue target = null;
/* 1195 */       target = (SimpleValue)get_store().find_attribute_user(BLOCK$26);
/* 1196 */       if (target == null)
/*      */       {
/* 1198 */         return null;
/*      */       }
/* 1200 */       return target.getObjectValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DerivationSet xgetBlock() {
/* 1209 */     synchronized (monitor()) {
/*      */       
/* 1211 */       check_orphaned();
/* 1212 */       DerivationSet target = null;
/* 1213 */       target = (DerivationSet)get_store().find_attribute_user(BLOCK$26);
/* 1214 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetBlock() {
/* 1223 */     synchronized (monitor()) {
/*      */       
/* 1225 */       check_orphaned();
/* 1226 */       return (get_store().find_attribute_user(BLOCK$26) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlock(Object block) {
/* 1235 */     synchronized (monitor()) {
/*      */       
/* 1237 */       check_orphaned();
/* 1238 */       SimpleValue target = null;
/* 1239 */       target = (SimpleValue)get_store().find_attribute_user(BLOCK$26);
/* 1240 */       if (target == null)
/*      */       {
/* 1242 */         target = (SimpleValue)get_store().add_attribute_user(BLOCK$26);
/*      */       }
/* 1244 */       target.setObjectValue(block);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetBlock(DerivationSet block) {
/* 1253 */     synchronized (monitor()) {
/*      */       
/* 1255 */       check_orphaned();
/* 1256 */       DerivationSet target = null;
/* 1257 */       target = (DerivationSet)get_store().find_attribute_user(BLOCK$26);
/* 1258 */       if (target == null)
/*      */       {
/* 1260 */         target = (DerivationSet)get_store().add_attribute_user(BLOCK$26);
/*      */       }
/* 1262 */       target.set((XmlObject)block);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetBlock() {
/* 1271 */     synchronized (monitor()) {
/*      */       
/* 1273 */       check_orphaned();
/* 1274 */       get_store().remove_attribute(BLOCK$26);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\ComplexTypeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */