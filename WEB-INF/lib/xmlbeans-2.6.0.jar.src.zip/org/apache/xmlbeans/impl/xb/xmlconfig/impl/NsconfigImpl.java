/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.NamespaceList;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.NamespacePrefixList;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Nsconfig;
/*     */ 
/*     */ public class NsconfigImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements Nsconfig
/*     */ {
/*     */   public NsconfigImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName PACKAGE$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "package");
/*     */   
/*  24 */   private static final QName PREFIX$2 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "prefix");
/*     */   
/*  26 */   private static final QName SUFFIX$4 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "suffix");
/*     */   
/*  28 */   private static final QName URI$6 = new QName("", "uri");
/*     */   
/*  30 */   private static final QName URIPREFIX$8 = new QName("", "uriprefix");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackage() {
/*  39 */     synchronized (monitor()) {
/*     */       
/*  41 */       check_orphaned();
/*  42 */       SimpleValue target = null;
/*  43 */       target = (SimpleValue)get_store().find_element_user(PACKAGE$0, 0);
/*  44 */       if (target == null)
/*     */       {
/*  46 */         return null;
/*     */       }
/*  48 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetPackage() {
/*  57 */     synchronized (monitor()) {
/*     */       
/*  59 */       check_orphaned();
/*  60 */       XmlString target = null;
/*  61 */       target = (XmlString)get_store().find_element_user(PACKAGE$0, 0);
/*  62 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetPackage() {
/*  71 */     synchronized (monitor()) {
/*     */       
/*  73 */       check_orphaned();
/*  74 */       return (get_store().count_elements(PACKAGE$0) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackage(String xpackage) {
/*  83 */     synchronized (monitor()) {
/*     */       
/*  85 */       check_orphaned();
/*  86 */       SimpleValue target = null;
/*  87 */       target = (SimpleValue)get_store().find_element_user(PACKAGE$0, 0);
/*  88 */       if (target == null)
/*     */       {
/*  90 */         target = (SimpleValue)get_store().add_element_user(PACKAGE$0);
/*     */       }
/*  92 */       target.setStringValue(xpackage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetPackage(XmlString xpackage) {
/* 101 */     synchronized (monitor()) {
/*     */       
/* 103 */       check_orphaned();
/* 104 */       XmlString target = null;
/* 105 */       target = (XmlString)get_store().find_element_user(PACKAGE$0, 0);
/* 106 */       if (target == null)
/*     */       {
/* 108 */         target = (XmlString)get_store().add_element_user(PACKAGE$0);
/*     */       }
/* 110 */       target.set((XmlObject)xpackage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetPackage() {
/* 119 */     synchronized (monitor()) {
/*     */       
/* 121 */       check_orphaned();
/* 122 */       get_store().remove_element(PACKAGE$0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 131 */     synchronized (monitor()) {
/*     */       
/* 133 */       check_orphaned();
/* 134 */       SimpleValue target = null;
/* 135 */       target = (SimpleValue)get_store().find_element_user(PREFIX$2, 0);
/* 136 */       if (target == null)
/*     */       {
/* 138 */         return null;
/*     */       }
/* 140 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetPrefix() {
/* 149 */     synchronized (monitor()) {
/*     */       
/* 151 */       check_orphaned();
/* 152 */       XmlString target = null;
/* 153 */       target = (XmlString)get_store().find_element_user(PREFIX$2, 0);
/* 154 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetPrefix() {
/* 163 */     synchronized (monitor()) {
/*     */       
/* 165 */       check_orphaned();
/* 166 */       return (get_store().count_elements(PREFIX$2) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 175 */     synchronized (monitor()) {
/*     */       
/* 177 */       check_orphaned();
/* 178 */       SimpleValue target = null;
/* 179 */       target = (SimpleValue)get_store().find_element_user(PREFIX$2, 0);
/* 180 */       if (target == null)
/*     */       {
/* 182 */         target = (SimpleValue)get_store().add_element_user(PREFIX$2);
/*     */       }
/* 184 */       target.setStringValue(prefix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetPrefix(XmlString prefix) {
/* 193 */     synchronized (monitor()) {
/*     */       
/* 195 */       check_orphaned();
/* 196 */       XmlString target = null;
/* 197 */       target = (XmlString)get_store().find_element_user(PREFIX$2, 0);
/* 198 */       if (target == null)
/*     */       {
/* 200 */         target = (XmlString)get_store().add_element_user(PREFIX$2);
/*     */       }
/* 202 */       target.set((XmlObject)prefix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetPrefix() {
/* 211 */     synchronized (monitor()) {
/*     */       
/* 213 */       check_orphaned();
/* 214 */       get_store().remove_element(PREFIX$2, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuffix() {
/* 223 */     synchronized (monitor()) {
/*     */       
/* 225 */       check_orphaned();
/* 226 */       SimpleValue target = null;
/* 227 */       target = (SimpleValue)get_store().find_element_user(SUFFIX$4, 0);
/* 228 */       if (target == null)
/*     */       {
/* 230 */         return null;
/*     */       }
/* 232 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetSuffix() {
/* 241 */     synchronized (monitor()) {
/*     */       
/* 243 */       check_orphaned();
/* 244 */       XmlString target = null;
/* 245 */       target = (XmlString)get_store().find_element_user(SUFFIX$4, 0);
/* 246 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetSuffix() {
/* 255 */     synchronized (monitor()) {
/*     */       
/* 257 */       check_orphaned();
/* 258 */       return (get_store().count_elements(SUFFIX$4) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuffix(String suffix) {
/* 267 */     synchronized (monitor()) {
/*     */       
/* 269 */       check_orphaned();
/* 270 */       SimpleValue target = null;
/* 271 */       target = (SimpleValue)get_store().find_element_user(SUFFIX$4, 0);
/* 272 */       if (target == null)
/*     */       {
/* 274 */         target = (SimpleValue)get_store().add_element_user(SUFFIX$4);
/*     */       }
/* 276 */       target.setStringValue(suffix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetSuffix(XmlString suffix) {
/* 285 */     synchronized (monitor()) {
/*     */       
/* 287 */       check_orphaned();
/* 288 */       XmlString target = null;
/* 289 */       target = (XmlString)get_store().find_element_user(SUFFIX$4, 0);
/* 290 */       if (target == null)
/*     */       {
/* 292 */         target = (XmlString)get_store().add_element_user(SUFFIX$4);
/*     */       }
/* 294 */       target.set((XmlObject)suffix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSuffix() {
/* 303 */     synchronized (monitor()) {
/*     */       
/* 305 */       check_orphaned();
/* 306 */       get_store().remove_element(SUFFIX$4, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUri() {
/* 315 */     synchronized (monitor()) {
/*     */       
/* 317 */       check_orphaned();
/* 318 */       SimpleValue target = null;
/* 319 */       target = (SimpleValue)get_store().find_attribute_user(URI$6);
/* 320 */       if (target == null)
/*     */       {
/* 322 */         return null;
/*     */       }
/* 324 */       return target.getObjectValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceList xgetUri() {
/* 333 */     synchronized (monitor()) {
/*     */       
/* 335 */       check_orphaned();
/* 336 */       NamespaceList target = null;
/* 337 */       target = (NamespaceList)get_store().find_attribute_user(URI$6);
/* 338 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetUri() {
/* 347 */     synchronized (monitor()) {
/*     */       
/* 349 */       check_orphaned();
/* 350 */       return (get_store().find_attribute_user(URI$6) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUri(Object uri) {
/* 359 */     synchronized (monitor()) {
/*     */       
/* 361 */       check_orphaned();
/* 362 */       SimpleValue target = null;
/* 363 */       target = (SimpleValue)get_store().find_attribute_user(URI$6);
/* 364 */       if (target == null)
/*     */       {
/* 366 */         target = (SimpleValue)get_store().add_attribute_user(URI$6);
/*     */       }
/* 368 */       target.setObjectValue(uri);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetUri(NamespaceList uri) {
/* 377 */     synchronized (monitor()) {
/*     */       
/* 379 */       check_orphaned();
/* 380 */       NamespaceList target = null;
/* 381 */       target = (NamespaceList)get_store().find_attribute_user(URI$6);
/* 382 */       if (target == null)
/*     */       {
/* 384 */         target = (NamespaceList)get_store().add_attribute_user(URI$6);
/*     */       }
/* 386 */       target.set((XmlObject)uri);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetUri() {
/* 395 */     synchronized (monitor()) {
/*     */       
/* 397 */       check_orphaned();
/* 398 */       get_store().remove_attribute(URI$6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getUriprefix() {
/* 407 */     synchronized (monitor()) {
/*     */       
/* 409 */       check_orphaned();
/* 410 */       SimpleValue target = null;
/* 411 */       target = (SimpleValue)get_store().find_attribute_user(URIPREFIX$8);
/* 412 */       if (target == null)
/*     */       {
/* 414 */         return null;
/*     */       }
/* 416 */       return target.getListValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespacePrefixList xgetUriprefix() {
/* 425 */     synchronized (monitor()) {
/*     */       
/* 427 */       check_orphaned();
/* 428 */       NamespacePrefixList target = null;
/* 429 */       target = (NamespacePrefixList)get_store().find_attribute_user(URIPREFIX$8);
/* 430 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetUriprefix() {
/* 439 */     synchronized (monitor()) {
/*     */       
/* 441 */       check_orphaned();
/* 442 */       return (get_store().find_attribute_user(URIPREFIX$8) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUriprefix(List uriprefix) {
/* 451 */     synchronized (monitor()) {
/*     */       
/* 453 */       check_orphaned();
/* 454 */       SimpleValue target = null;
/* 455 */       target = (SimpleValue)get_store().find_attribute_user(URIPREFIX$8);
/* 456 */       if (target == null)
/*     */       {
/* 458 */         target = (SimpleValue)get_store().add_attribute_user(URIPREFIX$8);
/*     */       }
/* 460 */       target.setListValue(uriprefix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetUriprefix(NamespacePrefixList uriprefix) {
/* 469 */     synchronized (monitor()) {
/*     */       
/* 471 */       check_orphaned();
/* 472 */       NamespacePrefixList target = null;
/* 473 */       target = (NamespacePrefixList)get_store().find_attribute_user(URIPREFIX$8);
/* 474 */       if (target == null)
/*     */       {
/* 476 */         target = (NamespacePrefixList)get_store().add_attribute_user(URIPREFIX$8);
/*     */       }
/* 478 */       target.set((XmlObject)uriprefix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetUriprefix() {
/* 487 */     synchronized (monitor()) {
/*     */       
/* 489 */       check_orphaned();
/* 490 */       get_store().remove_attribute(URIPREFIX$8);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\NsconfigImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */