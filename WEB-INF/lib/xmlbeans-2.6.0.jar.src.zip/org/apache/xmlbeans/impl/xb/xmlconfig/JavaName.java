/*    */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.net.URL;
/*    */ import javax.xml.stream.XMLStreamReader;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlBeans;
/*    */ import org.apache.xmlbeans.XmlException;
/*    */ import org.apache.xmlbeans.XmlOptions;
/*    */ import org.apache.xmlbeans.XmlToken;
/*    */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*    */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public interface JavaName extends XmlToken {
/* 18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaName == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaName = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.JavaName")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaName).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("javanamee640type");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final class Factory
/*    */   {
/*    */     public static JavaName newValue(Object obj) {
/* 29 */       return (JavaName)JavaName.type.newValue(obj);
/*    */     }
/*    */     public static JavaName newInstance() {
/* 32 */       return (JavaName)XmlBeans.getContextTypeLoader().newInstance(JavaName.type, null);
/*    */     }
/*    */     public static JavaName newInstance(XmlOptions options) {
/* 35 */       return (JavaName)XmlBeans.getContextTypeLoader().newInstance(JavaName.type, options);
/*    */     }
/*    */     
/*    */     public static JavaName parse(String xmlAsString) throws XmlException {
/* 39 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(xmlAsString, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 42 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(xmlAsString, JavaName.type, options);
/*    */     }
/*    */     
/*    */     public static JavaName parse(File file) throws XmlException, IOException {
/* 46 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(file, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(File file, XmlOptions options) throws XmlException, IOException {
/* 49 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(file, JavaName.type, options);
/*    */     }
/*    */     public static JavaName parse(URL u) throws XmlException, IOException {
/* 52 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(u, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 55 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(u, JavaName.type, options);
/*    */     }
/*    */     public static JavaName parse(InputStream is) throws XmlException, IOException {
/* 58 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(is, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 61 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(is, JavaName.type, options);
/*    */     }
/*    */     public static JavaName parse(Reader r) throws XmlException, IOException {
/* 64 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(r, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 67 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(r, JavaName.type, options);
/*    */     }
/*    */     public static JavaName parse(XMLStreamReader sr) throws XmlException {
/* 70 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(sr, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 73 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(sr, JavaName.type, options);
/*    */     }
/*    */     public static JavaName parse(Node node) throws XmlException {
/* 76 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(node, JavaName.type, null);
/*    */     }
/*    */     public static JavaName parse(Node node, XmlOptions options) throws XmlException {
/* 79 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(node, JavaName.type, options);
/*    */     }
/*    */     
/*    */     public static JavaName parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 83 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(xis, JavaName.type, null);
/*    */     }
/*    */     
/*    */     public static JavaName parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 87 */       return (JavaName)XmlBeans.getContextTypeLoader().parse(xis, JavaName.type, options);
/*    */     }
/*    */     
/*    */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 91 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, JavaName.type, null);
/*    */     }
/*    */     
/*    */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 95 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, JavaName.type, options);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\JavaName.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */