/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroupRef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeGroupRefImpl
/*     */   extends AttributeGroupImpl
/*     */   implements AttributeGroupRef
/*     */ {
/*     */   public AttributeGroupRefImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName REF$0 = new QName("", "ref");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getRef() {
/*  31 */     synchronized (monitor()) {
/*     */       
/*  33 */       check_orphaned();
/*  34 */       SimpleValue target = null;
/*  35 */       target = (SimpleValue)get_store().find_attribute_user(REF$0);
/*  36 */       if (target == null)
/*     */       {
/*  38 */         return null;
/*     */       }
/*  40 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetRef() {
/*  49 */     synchronized (monitor()) {
/*     */       
/*  51 */       check_orphaned();
/*  52 */       XmlQName target = null;
/*  53 */       target = (XmlQName)get_store().find_attribute_user(REF$0);
/*  54 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetRef() {
/*  63 */     synchronized (monitor()) {
/*     */       
/*  65 */       check_orphaned();
/*  66 */       return (get_store().find_attribute_user(REF$0) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRef(QName ref) {
/*  75 */     synchronized (monitor()) {
/*     */       
/*  77 */       check_orphaned();
/*  78 */       SimpleValue target = null;
/*  79 */       target = (SimpleValue)get_store().find_attribute_user(REF$0);
/*  80 */       if (target == null)
/*     */       {
/*  82 */         target = (SimpleValue)get_store().add_attribute_user(REF$0);
/*     */       }
/*  84 */       target.setQNameValue(ref);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetRef(XmlQName ref) {
/*  93 */     synchronized (monitor()) {
/*     */       
/*  95 */       check_orphaned();
/*  96 */       XmlQName target = null;
/*  97 */       target = (XmlQName)get_store().find_attribute_user(REF$0);
/*  98 */       if (target == null)
/*     */       {
/* 100 */         target = (XmlQName)get_store().add_attribute_user(REF$0);
/*     */       }
/* 102 */       target.set((XmlObject)ref);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetRef() {
/* 111 */     synchronized (monitor()) {
/*     */       
/* 113 */       check_orphaned();
/* 114 */       get_store().remove_attribute(REF$0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AttributeGroupRefImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */