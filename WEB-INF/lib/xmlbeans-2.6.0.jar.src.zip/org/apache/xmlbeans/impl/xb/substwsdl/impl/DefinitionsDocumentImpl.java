/*     */ package org.apache.xmlbeans.impl.xb.substwsdl.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.substwsdl.DefinitionsDocument;
/*     */ import org.apache.xmlbeans.impl.xb.substwsdl.TImport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefinitionsDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements DefinitionsDocument
/*     */ {
/*     */   public DefinitionsDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName DEFINITIONS$0 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "definitions");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefinitionsDocument.Definitions getDefinitions() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       DefinitionsDocument.Definitions target = null;
/*  36 */       target = (DefinitionsDocument.Definitions)get_store().find_element_user(DEFINITIONS$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefinitions(DefinitionsDocument.Definitions definitions) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       DefinitionsDocument.Definitions target = null;
/*  54 */       target = (DefinitionsDocument.Definitions)get_store().find_element_user(DEFINITIONS$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (DefinitionsDocument.Definitions)get_store().add_element_user(DEFINITIONS$0);
/*     */       }
/*  59 */       target.set((XmlObject)definitions);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefinitionsDocument.Definitions addNewDefinitions() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       DefinitionsDocument.Definitions target = null;
/*  72 */       target = (DefinitionsDocument.Definitions)get_store().add_element_user(DEFINITIONS$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DefinitionsImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements DefinitionsDocument.Definitions
/*     */   {
/*     */     public DefinitionsImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName IMPORT$0 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "import");
/*     */     
/*  91 */     private static final QName TYPES$2 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "types");
/*     */     
/*  93 */     private static final QName MESSAGE$4 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "message");
/*     */     
/*  95 */     private static final QName BINDING$6 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "binding");
/*     */     
/*  97 */     private static final QName PORTTYPE$8 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "portType");
/*     */     
/*  99 */     private static final QName SERVICE$10 = new QName("http://www.apache.org/internal/xmlbeans/wsdlsubst", "service");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TImport[] getImportArray() {
/* 108 */       synchronized (monitor()) {
/*     */         
/* 110 */         check_orphaned();
/* 111 */         List targetList = new ArrayList();
/* 112 */         get_store().find_all_element_users(IMPORT$0, targetList);
/* 113 */         TImport[] result = new TImport[targetList.size()];
/* 114 */         targetList.toArray((Object[])result);
/* 115 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TImport getImportArray(int i) {
/* 124 */       synchronized (monitor()) {
/*     */         
/* 126 */         check_orphaned();
/* 127 */         TImport target = null;
/* 128 */         target = (TImport)get_store().find_element_user(IMPORT$0, i);
/* 129 */         if (target == null)
/*     */         {
/* 131 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 133 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfImportArray() {
/* 142 */       synchronized (monitor()) {
/*     */         
/* 144 */         check_orphaned();
/* 145 */         return get_store().count_elements(IMPORT$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setImportArray(TImport[] ximportArray) {
/* 154 */       synchronized (monitor()) {
/*     */         
/* 156 */         check_orphaned();
/* 157 */         arraySetterHelper((XmlObject[])ximportArray, IMPORT$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setImportArray(int i, TImport ximport) {
/* 166 */       synchronized (monitor()) {
/*     */         
/* 168 */         check_orphaned();
/* 169 */         TImport target = null;
/* 170 */         target = (TImport)get_store().find_element_user(IMPORT$0, i);
/* 171 */         if (target == null)
/*     */         {
/* 173 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 175 */         target.set((XmlObject)ximport);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TImport insertNewImport(int i) {
/* 184 */       synchronized (monitor()) {
/*     */         
/* 186 */         check_orphaned();
/* 187 */         TImport target = null;
/* 188 */         target = (TImport)get_store().insert_element_user(IMPORT$0, i);
/* 189 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TImport addNewImport() {
/* 198 */       synchronized (monitor()) {
/*     */         
/* 200 */         check_orphaned();
/* 201 */         TImport target = null;
/* 202 */         target = (TImport)get_store().add_element_user(IMPORT$0);
/* 203 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeImport(int i) {
/* 212 */       synchronized (monitor()) {
/*     */         
/* 214 */         check_orphaned();
/* 215 */         get_store().remove_element(IMPORT$0, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject[] getTypesArray() {
/* 224 */       synchronized (monitor()) {
/*     */         
/* 226 */         check_orphaned();
/* 227 */         List targetList = new ArrayList();
/* 228 */         get_store().find_all_element_users(TYPES$2, targetList);
/* 229 */         XmlObject[] result = new XmlObject[targetList.size()];
/* 230 */         targetList.toArray((Object[])result);
/* 231 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject getTypesArray(int i) {
/* 240 */       synchronized (monitor()) {
/*     */         
/* 242 */         check_orphaned();
/* 243 */         XmlObject target = null;
/* 244 */         target = (XmlObject)get_store().find_element_user(TYPES$2, i);
/* 245 */         if (target == null)
/*     */         {
/* 247 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 249 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfTypesArray() {
/* 258 */       synchronized (monitor()) {
/*     */         
/* 260 */         check_orphaned();
/* 261 */         return get_store().count_elements(TYPES$2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setTypesArray(XmlObject[] typesArray) {
/* 270 */       synchronized (monitor()) {
/*     */         
/* 272 */         check_orphaned();
/* 273 */         arraySetterHelper(typesArray, TYPES$2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setTypesArray(int i, XmlObject types) {
/* 282 */       synchronized (monitor()) {
/*     */         
/* 284 */         check_orphaned();
/* 285 */         XmlObject target = null;
/* 286 */         target = (XmlObject)get_store().find_element_user(TYPES$2, i);
/* 287 */         if (target == null)
/*     */         {
/* 289 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 291 */         target.set(types);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject insertNewTypes(int i) {
/* 300 */       synchronized (monitor()) {
/*     */         
/* 302 */         check_orphaned();
/* 303 */         XmlObject target = null;
/* 304 */         target = (XmlObject)get_store().insert_element_user(TYPES$2, i);
/* 305 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject addNewTypes() {
/* 314 */       synchronized (monitor()) {
/*     */         
/* 316 */         check_orphaned();
/* 317 */         XmlObject target = null;
/* 318 */         target = (XmlObject)get_store().add_element_user(TYPES$2);
/* 319 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeTypes(int i) {
/* 328 */       synchronized (monitor()) {
/*     */         
/* 330 */         check_orphaned();
/* 331 */         get_store().remove_element(TYPES$2, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject[] getMessageArray() {
/* 340 */       synchronized (monitor()) {
/*     */         
/* 342 */         check_orphaned();
/* 343 */         List targetList = new ArrayList();
/* 344 */         get_store().find_all_element_users(MESSAGE$4, targetList);
/* 345 */         XmlObject[] result = new XmlObject[targetList.size()];
/* 346 */         targetList.toArray((Object[])result);
/* 347 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject getMessageArray(int i) {
/* 356 */       synchronized (monitor()) {
/*     */         
/* 358 */         check_orphaned();
/* 359 */         XmlObject target = null;
/* 360 */         target = (XmlObject)get_store().find_element_user(MESSAGE$4, i);
/* 361 */         if (target == null)
/*     */         {
/* 363 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 365 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfMessageArray() {
/* 374 */       synchronized (monitor()) {
/*     */         
/* 376 */         check_orphaned();
/* 377 */         return get_store().count_elements(MESSAGE$4);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setMessageArray(XmlObject[] messageArray) {
/* 386 */       synchronized (monitor()) {
/*     */         
/* 388 */         check_orphaned();
/* 389 */         arraySetterHelper(messageArray, MESSAGE$4);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setMessageArray(int i, XmlObject message) {
/* 398 */       synchronized (monitor()) {
/*     */         
/* 400 */         check_orphaned();
/* 401 */         XmlObject target = null;
/* 402 */         target = (XmlObject)get_store().find_element_user(MESSAGE$4, i);
/* 403 */         if (target == null)
/*     */         {
/* 405 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 407 */         target.set(message);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject insertNewMessage(int i) {
/* 416 */       synchronized (monitor()) {
/*     */         
/* 418 */         check_orphaned();
/* 419 */         XmlObject target = null;
/* 420 */         target = (XmlObject)get_store().insert_element_user(MESSAGE$4, i);
/* 421 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject addNewMessage() {
/* 430 */       synchronized (monitor()) {
/*     */         
/* 432 */         check_orphaned();
/* 433 */         XmlObject target = null;
/* 434 */         target = (XmlObject)get_store().add_element_user(MESSAGE$4);
/* 435 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeMessage(int i) {
/* 444 */       synchronized (monitor()) {
/*     */         
/* 446 */         check_orphaned();
/* 447 */         get_store().remove_element(MESSAGE$4, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject[] getBindingArray() {
/* 456 */       synchronized (monitor()) {
/*     */         
/* 458 */         check_orphaned();
/* 459 */         List targetList = new ArrayList();
/* 460 */         get_store().find_all_element_users(BINDING$6, targetList);
/* 461 */         XmlObject[] result = new XmlObject[targetList.size()];
/* 462 */         targetList.toArray((Object[])result);
/* 463 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject getBindingArray(int i) {
/* 472 */       synchronized (monitor()) {
/*     */         
/* 474 */         check_orphaned();
/* 475 */         XmlObject target = null;
/* 476 */         target = (XmlObject)get_store().find_element_user(BINDING$6, i);
/* 477 */         if (target == null)
/*     */         {
/* 479 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 481 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfBindingArray() {
/* 490 */       synchronized (monitor()) {
/*     */         
/* 492 */         check_orphaned();
/* 493 */         return get_store().count_elements(BINDING$6);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBindingArray(XmlObject[] bindingArray) {
/* 502 */       synchronized (monitor()) {
/*     */         
/* 504 */         check_orphaned();
/* 505 */         arraySetterHelper(bindingArray, BINDING$6);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBindingArray(int i, XmlObject binding) {
/* 514 */       synchronized (monitor()) {
/*     */         
/* 516 */         check_orphaned();
/* 517 */         XmlObject target = null;
/* 518 */         target = (XmlObject)get_store().find_element_user(BINDING$6, i);
/* 519 */         if (target == null)
/*     */         {
/* 521 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 523 */         target.set(binding);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject insertNewBinding(int i) {
/* 532 */       synchronized (monitor()) {
/*     */         
/* 534 */         check_orphaned();
/* 535 */         XmlObject target = null;
/* 536 */         target = (XmlObject)get_store().insert_element_user(BINDING$6, i);
/* 537 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject addNewBinding() {
/* 546 */       synchronized (monitor()) {
/*     */         
/* 548 */         check_orphaned();
/* 549 */         XmlObject target = null;
/* 550 */         target = (XmlObject)get_store().add_element_user(BINDING$6);
/* 551 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeBinding(int i) {
/* 560 */       synchronized (monitor()) {
/*     */         
/* 562 */         check_orphaned();
/* 563 */         get_store().remove_element(BINDING$6, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject[] getPortTypeArray() {
/* 572 */       synchronized (monitor()) {
/*     */         
/* 574 */         check_orphaned();
/* 575 */         List targetList = new ArrayList();
/* 576 */         get_store().find_all_element_users(PORTTYPE$8, targetList);
/* 577 */         XmlObject[] result = new XmlObject[targetList.size()];
/* 578 */         targetList.toArray((Object[])result);
/* 579 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject getPortTypeArray(int i) {
/* 588 */       synchronized (monitor()) {
/*     */         
/* 590 */         check_orphaned();
/* 591 */         XmlObject target = null;
/* 592 */         target = (XmlObject)get_store().find_element_user(PORTTYPE$8, i);
/* 593 */         if (target == null)
/*     */         {
/* 595 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 597 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfPortTypeArray() {
/* 606 */       synchronized (monitor()) {
/*     */         
/* 608 */         check_orphaned();
/* 609 */         return get_store().count_elements(PORTTYPE$8);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setPortTypeArray(XmlObject[] portTypeArray) {
/* 618 */       synchronized (monitor()) {
/*     */         
/* 620 */         check_orphaned();
/* 621 */         arraySetterHelper(portTypeArray, PORTTYPE$8);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setPortTypeArray(int i, XmlObject portType) {
/* 630 */       synchronized (monitor()) {
/*     */         
/* 632 */         check_orphaned();
/* 633 */         XmlObject target = null;
/* 634 */         target = (XmlObject)get_store().find_element_user(PORTTYPE$8, i);
/* 635 */         if (target == null)
/*     */         {
/* 637 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 639 */         target.set(portType);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject insertNewPortType(int i) {
/* 648 */       synchronized (monitor()) {
/*     */         
/* 650 */         check_orphaned();
/* 651 */         XmlObject target = null;
/* 652 */         target = (XmlObject)get_store().insert_element_user(PORTTYPE$8, i);
/* 653 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject addNewPortType() {
/* 662 */       synchronized (monitor()) {
/*     */         
/* 664 */         check_orphaned();
/* 665 */         XmlObject target = null;
/* 666 */         target = (XmlObject)get_store().add_element_user(PORTTYPE$8);
/* 667 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removePortType(int i) {
/* 676 */       synchronized (monitor()) {
/*     */         
/* 678 */         check_orphaned();
/* 679 */         get_store().remove_element(PORTTYPE$8, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject[] getServiceArray() {
/* 688 */       synchronized (monitor()) {
/*     */         
/* 690 */         check_orphaned();
/* 691 */         List targetList = new ArrayList();
/* 692 */         get_store().find_all_element_users(SERVICE$10, targetList);
/* 693 */         XmlObject[] result = new XmlObject[targetList.size()];
/* 694 */         targetList.toArray((Object[])result);
/* 695 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject getServiceArray(int i) {
/* 704 */       synchronized (monitor()) {
/*     */         
/* 706 */         check_orphaned();
/* 707 */         XmlObject target = null;
/* 708 */         target = (XmlObject)get_store().find_element_user(SERVICE$10, i);
/* 709 */         if (target == null)
/*     */         {
/* 711 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 713 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfServiceArray() {
/* 722 */       synchronized (monitor()) {
/*     */         
/* 724 */         check_orphaned();
/* 725 */         return get_store().count_elements(SERVICE$10);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setServiceArray(XmlObject[] serviceArray) {
/* 734 */       synchronized (monitor()) {
/*     */         
/* 736 */         check_orphaned();
/* 737 */         arraySetterHelper(serviceArray, SERVICE$10);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setServiceArray(int i, XmlObject service) {
/* 746 */       synchronized (monitor()) {
/*     */         
/* 748 */         check_orphaned();
/* 749 */         XmlObject target = null;
/* 750 */         target = (XmlObject)get_store().find_element_user(SERVICE$10, i);
/* 751 */         if (target == null)
/*     */         {
/* 753 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 755 */         target.set(service);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject insertNewService(int i) {
/* 764 */       synchronized (monitor()) {
/*     */         
/* 766 */         check_orphaned();
/* 767 */         XmlObject target = null;
/* 768 */         target = (XmlObject)get_store().insert_element_user(SERVICE$10, i);
/* 769 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlObject addNewService() {
/* 778 */       synchronized (monitor()) {
/*     */         
/* 780 */         check_orphaned();
/* 781 */         XmlObject target = null;
/* 782 */         target = (XmlObject)get_store().add_element_user(SERVICE$10);
/* 783 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeService(int i) {
/* 792 */       synchronized (monitor()) {
/*     */         
/* 794 */         check_orphaned();
/* 795 */         get_store().remove_element(SERVICE$10, i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\substwsdl\impl\DefinitionsDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */