/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlBoolean;
/*     */ import org.apache.xmlbeans.XmlID;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.FileDesc;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.TestCase;
/*     */ 
/*     */ public class TestCaseImpl extends XmlComplexContentImpl implements TestCase {
/*     */   public TestCaseImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName DESCRIPTION$0 = new QName("http://www.bea.com/2003/05/xmlbean/ltgfmt", "description");
/*     */   
/*  24 */   private static final QName FILES$2 = new QName("http://www.bea.com/2003/05/xmlbean/ltgfmt", "files");
/*     */   
/*  26 */   private static final QName ID$4 = new QName("", "id");
/*     */   
/*  28 */   private static final QName ORIGIN$6 = new QName("", "origin");
/*     */   
/*  30 */   private static final QName MODIFIED$8 = new QName("", "modified");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  39 */     synchronized (monitor()) {
/*     */       
/*  41 */       check_orphaned();
/*  42 */       SimpleValue target = null;
/*  43 */       target = (SimpleValue)get_store().find_element_user(DESCRIPTION$0, 0);
/*  44 */       if (target == null)
/*     */       {
/*  46 */         return null;
/*     */       }
/*  48 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetDescription() {
/*  57 */     synchronized (monitor()) {
/*     */       
/*  59 */       check_orphaned();
/*  60 */       XmlString target = null;
/*  61 */       target = (XmlString)get_store().find_element_user(DESCRIPTION$0, 0);
/*  62 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetDescription() {
/*  71 */     synchronized (monitor()) {
/*     */       
/*  73 */       check_orphaned();
/*  74 */       return (get_store().count_elements(DESCRIPTION$0) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String description) {
/*  83 */     synchronized (monitor()) {
/*     */       
/*  85 */       check_orphaned();
/*  86 */       SimpleValue target = null;
/*  87 */       target = (SimpleValue)get_store().find_element_user(DESCRIPTION$0, 0);
/*  88 */       if (target == null)
/*     */       {
/*  90 */         target = (SimpleValue)get_store().add_element_user(DESCRIPTION$0);
/*     */       }
/*  92 */       target.setStringValue(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetDescription(XmlString description) {
/* 101 */     synchronized (monitor()) {
/*     */       
/* 103 */       check_orphaned();
/* 104 */       XmlString target = null;
/* 105 */       target = (XmlString)get_store().find_element_user(DESCRIPTION$0, 0);
/* 106 */       if (target == null)
/*     */       {
/* 108 */         target = (XmlString)get_store().add_element_user(DESCRIPTION$0);
/*     */       }
/* 110 */       target.set((XmlObject)description);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetDescription() {
/* 119 */     synchronized (monitor()) {
/*     */       
/* 121 */       check_orphaned();
/* 122 */       get_store().remove_element(DESCRIPTION$0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestCase.Files getFiles() {
/* 131 */     synchronized (monitor()) {
/*     */       
/* 133 */       check_orphaned();
/* 134 */       TestCase.Files target = null;
/* 135 */       target = (TestCase.Files)get_store().find_element_user(FILES$2, 0);
/* 136 */       if (target == null)
/*     */       {
/* 138 */         return null;
/*     */       }
/* 140 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFiles(TestCase.Files files) {
/* 149 */     synchronized (monitor()) {
/*     */       
/* 151 */       check_orphaned();
/* 152 */       TestCase.Files target = null;
/* 153 */       target = (TestCase.Files)get_store().find_element_user(FILES$2, 0);
/* 154 */       if (target == null)
/*     */       {
/* 156 */         target = (TestCase.Files)get_store().add_element_user(FILES$2);
/*     */       }
/* 158 */       target.set((XmlObject)files);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestCase.Files addNewFiles() {
/* 167 */     synchronized (monitor()) {
/*     */       
/* 169 */       check_orphaned();
/* 170 */       TestCase.Files target = null;
/* 171 */       target = (TestCase.Files)get_store().add_element_user(FILES$2);
/* 172 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 181 */     synchronized (monitor()) {
/*     */       
/* 183 */       check_orphaned();
/* 184 */       SimpleValue target = null;
/* 185 */       target = (SimpleValue)get_store().find_attribute_user(ID$4);
/* 186 */       if (target == null)
/*     */       {
/* 188 */         return null;
/*     */       }
/* 190 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlID xgetId() {
/* 199 */     synchronized (monitor()) {
/*     */       
/* 201 */       check_orphaned();
/* 202 */       XmlID target = null;
/* 203 */       target = (XmlID)get_store().find_attribute_user(ID$4);
/* 204 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetId() {
/* 213 */     synchronized (monitor()) {
/*     */       
/* 215 */       check_orphaned();
/* 216 */       return (get_store().find_attribute_user(ID$4) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setId(String id) {
/* 225 */     synchronized (monitor()) {
/*     */       
/* 227 */       check_orphaned();
/* 228 */       SimpleValue target = null;
/* 229 */       target = (SimpleValue)get_store().find_attribute_user(ID$4);
/* 230 */       if (target == null)
/*     */       {
/* 232 */         target = (SimpleValue)get_store().add_attribute_user(ID$4);
/*     */       }
/* 234 */       target.setStringValue(id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetId(XmlID id) {
/* 243 */     synchronized (monitor()) {
/*     */       
/* 245 */       check_orphaned();
/* 246 */       XmlID target = null;
/* 247 */       target = (XmlID)get_store().find_attribute_user(ID$4);
/* 248 */       if (target == null)
/*     */       {
/* 250 */         target = (XmlID)get_store().add_attribute_user(ID$4);
/*     */       }
/* 252 */       target.set((XmlObject)id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetId() {
/* 261 */     synchronized (monitor()) {
/*     */       
/* 263 */       check_orphaned();
/* 264 */       get_store().remove_attribute(ID$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOrigin() {
/* 273 */     synchronized (monitor()) {
/*     */       
/* 275 */       check_orphaned();
/* 276 */       SimpleValue target = null;
/* 277 */       target = (SimpleValue)get_store().find_attribute_user(ORIGIN$6);
/* 278 */       if (target == null)
/*     */       {
/* 280 */         return null;
/*     */       }
/* 282 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetOrigin() {
/* 291 */     synchronized (monitor()) {
/*     */       
/* 293 */       check_orphaned();
/* 294 */       XmlToken target = null;
/* 295 */       target = (XmlToken)get_store().find_attribute_user(ORIGIN$6);
/* 296 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetOrigin() {
/* 305 */     synchronized (monitor()) {
/*     */       
/* 307 */       check_orphaned();
/* 308 */       return (get_store().find_attribute_user(ORIGIN$6) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrigin(String origin) {
/* 317 */     synchronized (monitor()) {
/*     */       
/* 319 */       check_orphaned();
/* 320 */       SimpleValue target = null;
/* 321 */       target = (SimpleValue)get_store().find_attribute_user(ORIGIN$6);
/* 322 */       if (target == null)
/*     */       {
/* 324 */         target = (SimpleValue)get_store().add_attribute_user(ORIGIN$6);
/*     */       }
/* 326 */       target.setStringValue(origin);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetOrigin(XmlToken origin) {
/* 335 */     synchronized (monitor()) {
/*     */       
/* 337 */       check_orphaned();
/* 338 */       XmlToken target = null;
/* 339 */       target = (XmlToken)get_store().find_attribute_user(ORIGIN$6);
/* 340 */       if (target == null)
/*     */       {
/* 342 */         target = (XmlToken)get_store().add_attribute_user(ORIGIN$6);
/*     */       }
/* 344 */       target.set((XmlObject)origin);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetOrigin() {
/* 353 */     synchronized (monitor()) {
/*     */       
/* 355 */       check_orphaned();
/* 356 */       get_store().remove_attribute(ORIGIN$6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getModified() {
/* 365 */     synchronized (monitor()) {
/*     */       
/* 367 */       check_orphaned();
/* 368 */       SimpleValue target = null;
/* 369 */       target = (SimpleValue)get_store().find_attribute_user(MODIFIED$8);
/* 370 */       if (target == null)
/*     */       {
/* 372 */         return false;
/*     */       }
/* 374 */       return target.getBooleanValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlBoolean xgetModified() {
/* 383 */     synchronized (monitor()) {
/*     */       
/* 385 */       check_orphaned();
/* 386 */       XmlBoolean target = null;
/* 387 */       target = (XmlBoolean)get_store().find_attribute_user(MODIFIED$8);
/* 388 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetModified() {
/* 397 */     synchronized (monitor()) {
/*     */       
/* 399 */       check_orphaned();
/* 400 */       return (get_store().find_attribute_user(MODIFIED$8) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModified(boolean modified) {
/* 409 */     synchronized (monitor()) {
/*     */       
/* 411 */       check_orphaned();
/* 412 */       SimpleValue target = null;
/* 413 */       target = (SimpleValue)get_store().find_attribute_user(MODIFIED$8);
/* 414 */       if (target == null)
/*     */       {
/* 416 */         target = (SimpleValue)get_store().add_attribute_user(MODIFIED$8);
/*     */       }
/* 418 */       target.setBooleanValue(modified);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetModified(XmlBoolean modified) {
/* 427 */     synchronized (monitor()) {
/*     */       
/* 429 */       check_orphaned();
/* 430 */       XmlBoolean target = null;
/* 431 */       target = (XmlBoolean)get_store().find_attribute_user(MODIFIED$8);
/* 432 */       if (target == null)
/*     */       {
/* 434 */         target = (XmlBoolean)get_store().add_attribute_user(MODIFIED$8);
/*     */       }
/* 436 */       target.set((XmlObject)modified);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetModified() {
/* 445 */     synchronized (monitor()) {
/*     */       
/* 447 */       check_orphaned();
/* 448 */       get_store().remove_attribute(MODIFIED$8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FilesImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements TestCase.Files
/*     */   {
/*     */     public FilesImpl(SchemaType sType) {
/* 461 */       super(sType);
/*     */     }
/*     */     
/* 464 */     private static final QName FILE$0 = new QName("http://www.bea.com/2003/05/xmlbean/ltgfmt", "file");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FileDesc[] getFileArray() {
/* 473 */       synchronized (monitor()) {
/*     */         
/* 475 */         check_orphaned();
/* 476 */         List targetList = new ArrayList();
/* 477 */         get_store().find_all_element_users(FILE$0, targetList);
/* 478 */         FileDesc[] result = new FileDesc[targetList.size()];
/* 479 */         targetList.toArray((Object[])result);
/* 480 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FileDesc getFileArray(int i) {
/* 489 */       synchronized (monitor()) {
/*     */         
/* 491 */         check_orphaned();
/* 492 */         FileDesc target = null;
/* 493 */         target = (FileDesc)get_store().find_element_user(FILE$0, i);
/* 494 */         if (target == null)
/*     */         {
/* 496 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 498 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfFileArray() {
/* 507 */       synchronized (monitor()) {
/*     */         
/* 509 */         check_orphaned();
/* 510 */         return get_store().count_elements(FILE$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setFileArray(FileDesc[] fileArray) {
/* 519 */       synchronized (monitor()) {
/*     */         
/* 521 */         check_orphaned();
/* 522 */         arraySetterHelper((XmlObject[])fileArray, FILE$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setFileArray(int i, FileDesc file) {
/* 531 */       synchronized (monitor()) {
/*     */         
/* 533 */         check_orphaned();
/* 534 */         FileDesc target = null;
/* 535 */         target = (FileDesc)get_store().find_element_user(FILE$0, i);
/* 536 */         if (target == null)
/*     */         {
/* 538 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 540 */         target.set((XmlObject)file);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FileDesc insertNewFile(int i) {
/* 549 */       synchronized (monitor()) {
/*     */         
/* 551 */         check_orphaned();
/* 552 */         FileDesc target = null;
/* 553 */         target = (FileDesc)get_store().insert_element_user(FILE$0, i);
/* 554 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FileDesc addNewFile() {
/* 563 */       synchronized (monitor()) {
/*     */         
/* 565 */         check_orphaned();
/* 566 */         FileDesc target = null;
/* 567 */         target = (FileDesc)get_store().add_element_user(FILE$0);
/* 568 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeFile(int i) {
/* 577 */       synchronized (monitor()) {
/*     */         
/* 579 */         check_orphaned();
/* 580 */         get_store().remove_element(FILE$0, i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\impl\TestCaseImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */