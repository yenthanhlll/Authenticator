/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlID;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Annotated;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AnnotationDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedImpl
/*     */   extends OpenAttrsImpl
/*     */   implements Annotated
/*     */ {
/*     */   public AnnotatedImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName ANNOTATION$0 = new QName("http://www.w3.org/2001/XMLSchema", "annotation");
/*     */   
/*  24 */   private static final QName ID$2 = new QName("", "id");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationDocument.Annotation getAnnotation() {
/*  33 */     synchronized (monitor()) {
/*     */       
/*  35 */       check_orphaned();
/*  36 */       AnnotationDocument.Annotation target = null;
/*  37 */       target = (AnnotationDocument.Annotation)get_store().find_element_user(ANNOTATION$0, 0);
/*  38 */       if (target == null)
/*     */       {
/*  40 */         return null;
/*     */       }
/*  42 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetAnnotation() {
/*  51 */     synchronized (monitor()) {
/*     */       
/*  53 */       check_orphaned();
/*  54 */       return (get_store().count_elements(ANNOTATION$0) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotation(AnnotationDocument.Annotation annotation) {
/*  63 */     synchronized (monitor()) {
/*     */       
/*  65 */       check_orphaned();
/*  66 */       AnnotationDocument.Annotation target = null;
/*  67 */       target = (AnnotationDocument.Annotation)get_store().find_element_user(ANNOTATION$0, 0);
/*  68 */       if (target == null)
/*     */       {
/*  70 */         target = (AnnotationDocument.Annotation)get_store().add_element_user(ANNOTATION$0);
/*     */       }
/*  72 */       target.set((XmlObject)annotation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationDocument.Annotation addNewAnnotation() {
/*  81 */     synchronized (monitor()) {
/*     */       
/*  83 */       check_orphaned();
/*  84 */       AnnotationDocument.Annotation target = null;
/*  85 */       target = (AnnotationDocument.Annotation)get_store().add_element_user(ANNOTATION$0);
/*  86 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetAnnotation() {
/*  95 */     synchronized (monitor()) {
/*     */       
/*  97 */       check_orphaned();
/*  98 */       get_store().remove_element(ANNOTATION$0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 107 */     synchronized (monitor()) {
/*     */       
/* 109 */       check_orphaned();
/* 110 */       SimpleValue target = null;
/* 111 */       target = (SimpleValue)get_store().find_attribute_user(ID$2);
/* 112 */       if (target == null)
/*     */       {
/* 114 */         return null;
/*     */       }
/* 116 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlID xgetId() {
/* 125 */     synchronized (monitor()) {
/*     */       
/* 127 */       check_orphaned();
/* 128 */       XmlID target = null;
/* 129 */       target = (XmlID)get_store().find_attribute_user(ID$2);
/* 130 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetId() {
/* 139 */     synchronized (monitor()) {
/*     */       
/* 141 */       check_orphaned();
/* 142 */       return (get_store().find_attribute_user(ID$2) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setId(String id) {
/* 151 */     synchronized (monitor()) {
/*     */       
/* 153 */       check_orphaned();
/* 154 */       SimpleValue target = null;
/* 155 */       target = (SimpleValue)get_store().find_attribute_user(ID$2);
/* 156 */       if (target == null)
/*     */       {
/* 158 */         target = (SimpleValue)get_store().add_attribute_user(ID$2);
/*     */       }
/* 160 */       target.setStringValue(id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetId(XmlID id) {
/* 169 */     synchronized (monitor()) {
/*     */       
/* 171 */       check_orphaned();
/* 172 */       XmlID target = null;
/* 173 */       target = (XmlID)get_store().find_attribute_user(ID$2);
/* 174 */       if (target == null)
/*     */       {
/* 176 */         target = (XmlID)get_store().add_attribute_user(ID$2);
/*     */       }
/* 178 */       target.set((XmlObject)id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetId() {
/* 187 */     synchronized (monitor()) {
/*     */       
/* 189 */       check_orphaned();
/* 190 */       get_store().remove_attribute(ID$2);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AnnotatedImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */