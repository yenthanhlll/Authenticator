/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.ElementDocument;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementDocumentImpl
/*    */   extends XmlComplexContentImpl
/*    */   implements ElementDocument
/*    */ {
/*    */   public ElementDocumentImpl(SchemaType sType) {
/* 20 */     super(sType);
/*    */   }
/*    */   
/* 23 */   private static final QName ELEMENT$0 = new QName("http://www.w3.org/2001/XMLSchema", "element");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TopLevelElement getElement() {
/* 32 */     synchronized (monitor()) {
/*    */       
/* 34 */       check_orphaned();
/* 35 */       TopLevelElement target = null;
/* 36 */       target = (TopLevelElement)get_store().find_element_user(ELEMENT$0, 0);
/* 37 */       if (target == null)
/*    */       {
/* 39 */         return null;
/*    */       }
/* 41 */       return target;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setElement(TopLevelElement element) {
/* 50 */     synchronized (monitor()) {
/*    */       
/* 52 */       check_orphaned();
/* 53 */       TopLevelElement target = null;
/* 54 */       target = (TopLevelElement)get_store().find_element_user(ELEMENT$0, 0);
/* 55 */       if (target == null)
/*    */       {
/* 57 */         target = (TopLevelElement)get_store().add_element_user(ELEMENT$0);
/*    */       }
/* 59 */       target.set((XmlObject)element);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TopLevelElement addNewElement() {
/* 68 */     synchronized (monitor()) {
/*    */       
/* 70 */       check_orphaned();
/* 71 */       TopLevelElement target = null;
/* 72 */       target = (TopLevelElement)get_store().add_element_user(ELEMENT$0);
/* 73 */       return target;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\ElementDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */