/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Extensionconfig extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("extensionconfig2ac2type");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Interface[] getInterfaceArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Interface getInterfaceArray(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeOfInterfaceArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInterfaceArray(Interface[] paramArrayOfInterface);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInterfaceArray(int paramInt, Interface paramInterface);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Interface insertNewInterface(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Interface addNewInterface();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeInterface(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrePostSet getPrePostSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetPrePostSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPrePostSet(PrePostSet paramPrePostSet);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrePostSet addNewPrePostSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetPrePostSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getFor();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JavaNameList xgetFor();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetFor();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFor(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetFor(JavaNameList paramJavaNameList);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetFor();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Interface
/*     */     extends XmlObject
/*     */   {
/* 123 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((Extensionconfig.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig$Interface == null) ? (Extensionconfig.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig$Interface = Extensionconfig.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig$Interface")) : Extensionconfig.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig$Interface).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("interface02a7elemtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getStaticHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     XmlString xgetStaticHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setStaticHandler(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void xsetStaticHandler(XmlString param1XmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     XmlString xgetName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isSetName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setName(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void xsetName(XmlString param1XmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void unsetName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static Extensionconfig.Interface newInstance() {
/* 184 */         return (Extensionconfig.Interface)XmlBeans.getContextTypeLoader().newInstance(Extensionconfig.Interface.type, null);
/*     */       }
/*     */       public static Extensionconfig.Interface newInstance(XmlOptions options) {
/* 187 */         return (Extensionconfig.Interface)XmlBeans.getContextTypeLoader().newInstance(Extensionconfig.Interface.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface PrePostSet
/*     */     extends XmlObject
/*     */   {
/* 200 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((Extensionconfig.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig$PrePostSet == null) ? (Extensionconfig.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig$PrePostSet = Extensionconfig.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig$PrePostSet")) : Extensionconfig.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Extensionconfig$PrePostSet).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("prepostset5c9delemtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getStaticHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     XmlString xgetStaticHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setStaticHandler(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void xsetStaticHandler(XmlString param1XmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static Extensionconfig.PrePostSet newInstance() {
/* 231 */         return (Extensionconfig.PrePostSet)XmlBeans.getContextTypeLoader().newInstance(Extensionconfig.PrePostSet.type, null);
/*     */       }
/*     */       public static Extensionconfig.PrePostSet newInstance(XmlOptions options) {
/* 234 */         return (Extensionconfig.PrePostSet)XmlBeans.getContextTypeLoader().newInstance(Extensionconfig.PrePostSet.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Extensionconfig newInstance() {
/* 248 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().newInstance(Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig newInstance(XmlOptions options) {
/* 251 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().newInstance(Extensionconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Extensionconfig parse(String xmlAsString) throws XmlException {
/* 255 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 258 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Extensionconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Extensionconfig parse(File file) throws XmlException, IOException {
/* 262 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(file, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(File file, XmlOptions options) throws XmlException, IOException {
/* 265 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(file, Extensionconfig.type, options);
/*     */     }
/*     */     public static Extensionconfig parse(URL u) throws XmlException, IOException {
/* 268 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(u, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 271 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(u, Extensionconfig.type, options);
/*     */     }
/*     */     public static Extensionconfig parse(InputStream is) throws XmlException, IOException {
/* 274 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(is, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 277 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(is, Extensionconfig.type, options);
/*     */     }
/*     */     public static Extensionconfig parse(Reader r) throws XmlException, IOException {
/* 280 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(r, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 283 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(r, Extensionconfig.type, options);
/*     */     }
/*     */     public static Extensionconfig parse(XMLStreamReader sr) throws XmlException {
/* 286 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(sr, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 289 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(sr, Extensionconfig.type, options);
/*     */     }
/*     */     public static Extensionconfig parse(Node node) throws XmlException {
/* 292 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(node, Extensionconfig.type, null);
/*     */     }
/*     */     public static Extensionconfig parse(Node node, XmlOptions options) throws XmlException {
/* 295 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(node, Extensionconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Extensionconfig parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 299 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(xis, Extensionconfig.type, null);
/*     */     }
/*     */     
/*     */     public static Extensionconfig parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 303 */       return (Extensionconfig)XmlBeans.getContextTypeLoader().parse(xis, Extensionconfig.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 307 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Extensionconfig.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 311 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Extensionconfig.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\Extensionconfig.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */