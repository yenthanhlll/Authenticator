/*    */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.values.JavaStringHolderEx;
/*    */ import org.apache.xmlbeans.impl.xb.xmlconfig.JavaName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaNameImpl
/*    */   extends JavaStringHolderEx
/*    */   implements JavaName
/*    */ {
/*    */   public JavaNameImpl(SchemaType sType) {
/* 19 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected JavaNameImpl(SchemaType sType, boolean b) {
/* 24 */     super(sType, b);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\JavaNameImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */