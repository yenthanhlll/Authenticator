/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.TestCase;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.TestsDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestsDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements TestsDocument
/*     */ {
/*     */   public TestsDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName TESTS$0 = new QName("http://www.bea.com/2003/05/xmlbean/ltgfmt", "tests");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestsDocument.Tests getTests() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       TestsDocument.Tests target = null;
/*  36 */       target = (TestsDocument.Tests)get_store().find_element_user(TESTS$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTests(TestsDocument.Tests tests) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       TestsDocument.Tests target = null;
/*  54 */       target = (TestsDocument.Tests)get_store().find_element_user(TESTS$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (TestsDocument.Tests)get_store().add_element_user(TESTS$0);
/*     */       }
/*  59 */       target.set((XmlObject)tests);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestsDocument.Tests addNewTests() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       TestsDocument.Tests target = null;
/*  72 */       target = (TestsDocument.Tests)get_store().add_element_user(TESTS$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TestsImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements TestsDocument.Tests
/*     */   {
/*     */     public TestsImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName TEST$0 = new QName("http://www.bea.com/2003/05/xmlbean/ltgfmt", "test");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TestCase[] getTestArray() {
/*  98 */       synchronized (monitor()) {
/*     */         
/* 100 */         check_orphaned();
/* 101 */         List targetList = new ArrayList();
/* 102 */         get_store().find_all_element_users(TEST$0, targetList);
/* 103 */         TestCase[] result = new TestCase[targetList.size()];
/* 104 */         targetList.toArray((Object[])result);
/* 105 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TestCase getTestArray(int i) {
/* 114 */       synchronized (monitor()) {
/*     */         
/* 116 */         check_orphaned();
/* 117 */         TestCase target = null;
/* 118 */         target = (TestCase)get_store().find_element_user(TEST$0, i);
/* 119 */         if (target == null)
/*     */         {
/* 121 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 123 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfTestArray() {
/* 132 */       synchronized (monitor()) {
/*     */         
/* 134 */         check_orphaned();
/* 135 */         return get_store().count_elements(TEST$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setTestArray(TestCase[] testArray) {
/* 144 */       synchronized (monitor()) {
/*     */         
/* 146 */         check_orphaned();
/* 147 */         arraySetterHelper((XmlObject[])testArray, TEST$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setTestArray(int i, TestCase test) {
/* 156 */       synchronized (monitor()) {
/*     */         
/* 158 */         check_orphaned();
/* 159 */         TestCase target = null;
/* 160 */         target = (TestCase)get_store().find_element_user(TEST$0, i);
/* 161 */         if (target == null)
/*     */         {
/* 163 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 165 */         target.set((XmlObject)test);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TestCase insertNewTest(int i) {
/* 174 */       synchronized (monitor()) {
/*     */         
/* 176 */         check_orphaned();
/* 177 */         TestCase target = null;
/* 178 */         target = (TestCase)get_store().insert_element_user(TEST$0, i);
/* 179 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TestCase addNewTest() {
/* 188 */       synchronized (monitor()) {
/*     */         
/* 190 */         check_orphaned();
/* 191 */         TestCase target = null;
/* 192 */         target = (TestCase)get_store().add_element_user(TEST$0);
/* 193 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeTest(int i) {
/* 202 */       synchronized (monitor()) {
/*     */         
/* 204 */         check_orphaned();
/* 205 */         get_store().remove_element(TEST$0, i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\impl\TestsDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */