/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Nsconfig extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Nsconfig == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Nsconfig = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Nsconfig")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Nsconfig).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("nsconfigaebatype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getPackage();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetPackage();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetPackage();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPackage(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetPackage(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetPackage();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getPrefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetPrefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetPrefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPrefix(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetPrefix(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetPrefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getSuffix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetSuffix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetSuffix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSuffix(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetSuffix(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetSuffix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getUri();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamespaceList xgetUri();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetUri();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setUri(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetUri(NamespaceList paramNamespaceList);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetUri();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List getUriprefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamespacePrefixList xgetUriprefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetUriprefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setUriprefix(List paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetUriprefix(NamespacePrefixList paramNamespacePrefixList);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetUriprefix();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Nsconfig newInstance() {
/* 179 */       return (Nsconfig)XmlBeans.getContextTypeLoader().newInstance(Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig newInstance(XmlOptions options) {
/* 182 */       return (Nsconfig)XmlBeans.getContextTypeLoader().newInstance(Nsconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Nsconfig parse(String xmlAsString) throws XmlException {
/* 186 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 189 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Nsconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Nsconfig parse(File file) throws XmlException, IOException {
/* 193 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(file, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(File file, XmlOptions options) throws XmlException, IOException {
/* 196 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(file, Nsconfig.type, options);
/*     */     }
/*     */     public static Nsconfig parse(URL u) throws XmlException, IOException {
/* 199 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(u, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 202 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(u, Nsconfig.type, options);
/*     */     }
/*     */     public static Nsconfig parse(InputStream is) throws XmlException, IOException {
/* 205 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(is, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 208 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(is, Nsconfig.type, options);
/*     */     }
/*     */     public static Nsconfig parse(Reader r) throws XmlException, IOException {
/* 211 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(r, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 214 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(r, Nsconfig.type, options);
/*     */     }
/*     */     public static Nsconfig parse(XMLStreamReader sr) throws XmlException {
/* 217 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(sr, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 220 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(sr, Nsconfig.type, options);
/*     */     }
/*     */     public static Nsconfig parse(Node node) throws XmlException {
/* 223 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(node, Nsconfig.type, null);
/*     */     }
/*     */     public static Nsconfig parse(Node node, XmlOptions options) throws XmlException {
/* 226 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(node, Nsconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Nsconfig parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 230 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(xis, Nsconfig.type, null);
/*     */     }
/*     */     
/*     */     public static Nsconfig parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 234 */       return (Nsconfig)XmlBeans.getContextTypeLoader().parse(xis, Nsconfig.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 238 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Nsconfig.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 242 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Nsconfig.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\Nsconfig.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */