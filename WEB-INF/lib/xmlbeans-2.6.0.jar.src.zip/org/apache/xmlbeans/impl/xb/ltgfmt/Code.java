/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Code extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$ltgfmt$Code == null) ? (null.class$org$apache$xmlbeans$impl$xb$ltgfmt$Code = null.class$("org.apache.xmlbeans.impl.xb.ltgfmt.Code")) : null.class$org$apache$xmlbeans$impl$xb$ltgfmt$Code).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("codef72ftype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlToken xgetID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetID();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setID(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetID(XmlToken paramXmlToken);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetID();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Code newInstance() {
/*  59 */       return (Code)XmlBeans.getContextTypeLoader().newInstance(Code.type, null);
/*     */     }
/*     */     public static Code newInstance(XmlOptions options) {
/*  62 */       return (Code)XmlBeans.getContextTypeLoader().newInstance(Code.type, options);
/*     */     }
/*     */     
/*     */     public static Code parse(String xmlAsString) throws XmlException {
/*  66 */       return (Code)XmlBeans.getContextTypeLoader().parse(xmlAsString, Code.type, null);
/*     */     }
/*     */     public static Code parse(String xmlAsString, XmlOptions options) throws XmlException {
/*  69 */       return (Code)XmlBeans.getContextTypeLoader().parse(xmlAsString, Code.type, options);
/*     */     }
/*     */     
/*     */     public static Code parse(File file) throws XmlException, IOException {
/*  73 */       return (Code)XmlBeans.getContextTypeLoader().parse(file, Code.type, null);
/*     */     }
/*     */     public static Code parse(File file, XmlOptions options) throws XmlException, IOException {
/*  76 */       return (Code)XmlBeans.getContextTypeLoader().parse(file, Code.type, options);
/*     */     }
/*     */     public static Code parse(URL u) throws XmlException, IOException {
/*  79 */       return (Code)XmlBeans.getContextTypeLoader().parse(u, Code.type, null);
/*     */     }
/*     */     public static Code parse(URL u, XmlOptions options) throws XmlException, IOException {
/*  82 */       return (Code)XmlBeans.getContextTypeLoader().parse(u, Code.type, options);
/*     */     }
/*     */     public static Code parse(InputStream is) throws XmlException, IOException {
/*  85 */       return (Code)XmlBeans.getContextTypeLoader().parse(is, Code.type, null);
/*     */     }
/*     */     public static Code parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/*  88 */       return (Code)XmlBeans.getContextTypeLoader().parse(is, Code.type, options);
/*     */     }
/*     */     public static Code parse(Reader r) throws XmlException, IOException {
/*  91 */       return (Code)XmlBeans.getContextTypeLoader().parse(r, Code.type, null);
/*     */     }
/*     */     public static Code parse(Reader r, XmlOptions options) throws XmlException, IOException {
/*  94 */       return (Code)XmlBeans.getContextTypeLoader().parse(r, Code.type, options);
/*     */     }
/*     */     public static Code parse(XMLStreamReader sr) throws XmlException {
/*  97 */       return (Code)XmlBeans.getContextTypeLoader().parse(sr, Code.type, null);
/*     */     }
/*     */     public static Code parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 100 */       return (Code)XmlBeans.getContextTypeLoader().parse(sr, Code.type, options);
/*     */     }
/*     */     public static Code parse(Node node) throws XmlException {
/* 103 */       return (Code)XmlBeans.getContextTypeLoader().parse(node, Code.type, null);
/*     */     }
/*     */     public static Code parse(Node node, XmlOptions options) throws XmlException {
/* 106 */       return (Code)XmlBeans.getContextTypeLoader().parse(node, Code.type, options);
/*     */     }
/*     */     
/*     */     public static Code parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 110 */       return (Code)XmlBeans.getContextTypeLoader().parse(xis, Code.type, null);
/*     */     }
/*     */     
/*     */     public static Code parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 114 */       return (Code)XmlBeans.getContextTypeLoader().parse(xis, Code.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 118 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Code.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 122 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Code.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\Code.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */