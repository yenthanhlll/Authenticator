/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlBoolean;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexContentDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ComplexRestrictionType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ExtensionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComplexContentDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements ComplexContentDocument
/*     */ {
/*     */   public ComplexContentDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName COMPLEXCONTENT$0 = new QName("http://www.w3.org/2001/XMLSchema", "complexContent");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComplexContentDocument.ComplexContent getComplexContent() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       ComplexContentDocument.ComplexContent target = null;
/*  36 */       target = (ComplexContentDocument.ComplexContent)get_store().find_element_user(COMPLEXCONTENT$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComplexContent(ComplexContentDocument.ComplexContent complexContent) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       ComplexContentDocument.ComplexContent target = null;
/*  54 */       target = (ComplexContentDocument.ComplexContent)get_store().find_element_user(COMPLEXCONTENT$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (ComplexContentDocument.ComplexContent)get_store().add_element_user(COMPLEXCONTENT$0);
/*     */       }
/*  59 */       target.set((XmlObject)complexContent);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComplexContentDocument.ComplexContent addNewComplexContent() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       ComplexContentDocument.ComplexContent target = null;
/*  72 */       target = (ComplexContentDocument.ComplexContent)get_store().add_element_user(COMPLEXCONTENT$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ComplexContentImpl
/*     */     extends AnnotatedImpl
/*     */     implements ComplexContentDocument.ComplexContent
/*     */   {
/*     */     public ComplexContentImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName RESTRICTION$0 = new QName("http://www.w3.org/2001/XMLSchema", "restriction");
/*     */     
/*  91 */     private static final QName EXTENSION$2 = new QName("http://www.w3.org/2001/XMLSchema", "extension");
/*     */     
/*  93 */     private static final QName MIXED$4 = new QName("", "mixed");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ComplexRestrictionType getRestriction() {
/* 102 */       synchronized (monitor()) {
/*     */         
/* 104 */         check_orphaned();
/* 105 */         ComplexRestrictionType target = null;
/* 106 */         target = (ComplexRestrictionType)get_store().find_element_user(RESTRICTION$0, 0);
/* 107 */         if (target == null)
/*     */         {
/* 109 */           return null;
/*     */         }
/* 111 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetRestriction() {
/* 120 */       synchronized (monitor()) {
/*     */         
/* 122 */         check_orphaned();
/* 123 */         return (get_store().count_elements(RESTRICTION$0) != 0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setRestriction(ComplexRestrictionType restriction) {
/* 132 */       synchronized (monitor()) {
/*     */         
/* 134 */         check_orphaned();
/* 135 */         ComplexRestrictionType target = null;
/* 136 */         target = (ComplexRestrictionType)get_store().find_element_user(RESTRICTION$0, 0);
/* 137 */         if (target == null)
/*     */         {
/* 139 */           target = (ComplexRestrictionType)get_store().add_element_user(RESTRICTION$0);
/*     */         }
/* 141 */         target.set((XmlObject)restriction);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ComplexRestrictionType addNewRestriction() {
/* 150 */       synchronized (monitor()) {
/*     */         
/* 152 */         check_orphaned();
/* 153 */         ComplexRestrictionType target = null;
/* 154 */         target = (ComplexRestrictionType)get_store().add_element_user(RESTRICTION$0);
/* 155 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetRestriction() {
/* 164 */       synchronized (monitor()) {
/*     */         
/* 166 */         check_orphaned();
/* 167 */         get_store().remove_element(RESTRICTION$0, 0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExtensionType getExtension() {
/* 176 */       synchronized (monitor()) {
/*     */         
/* 178 */         check_orphaned();
/* 179 */         ExtensionType target = null;
/* 180 */         target = (ExtensionType)get_store().find_element_user(EXTENSION$2, 0);
/* 181 */         if (target == null)
/*     */         {
/* 183 */           return null;
/*     */         }
/* 185 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetExtension() {
/* 194 */       synchronized (monitor()) {
/*     */         
/* 196 */         check_orphaned();
/* 197 */         return (get_store().count_elements(EXTENSION$2) != 0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setExtension(ExtensionType extension) {
/* 206 */       synchronized (monitor()) {
/*     */         
/* 208 */         check_orphaned();
/* 209 */         ExtensionType target = null;
/* 210 */         target = (ExtensionType)get_store().find_element_user(EXTENSION$2, 0);
/* 211 */         if (target == null)
/*     */         {
/* 213 */           target = (ExtensionType)get_store().add_element_user(EXTENSION$2);
/*     */         }
/* 215 */         target.set((XmlObject)extension);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExtensionType addNewExtension() {
/* 224 */       synchronized (monitor()) {
/*     */         
/* 226 */         check_orphaned();
/* 227 */         ExtensionType target = null;
/* 228 */         target = (ExtensionType)get_store().add_element_user(EXTENSION$2);
/* 229 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetExtension() {
/* 238 */       synchronized (monitor()) {
/*     */         
/* 240 */         check_orphaned();
/* 241 */         get_store().remove_element(EXTENSION$2, 0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean getMixed() {
/* 250 */       synchronized (monitor()) {
/*     */         
/* 252 */         check_orphaned();
/* 253 */         SimpleValue target = null;
/* 254 */         target = (SimpleValue)get_store().find_attribute_user(MIXED$4);
/* 255 */         if (target == null)
/*     */         {
/* 257 */           return false;
/*     */         }
/* 259 */         return target.getBooleanValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlBoolean xgetMixed() {
/* 268 */       synchronized (monitor()) {
/*     */         
/* 270 */         check_orphaned();
/* 271 */         XmlBoolean target = null;
/* 272 */         target = (XmlBoolean)get_store().find_attribute_user(MIXED$4);
/* 273 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetMixed() {
/* 282 */       synchronized (monitor()) {
/*     */         
/* 284 */         check_orphaned();
/* 285 */         return (get_store().find_attribute_user(MIXED$4) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setMixed(boolean mixed) {
/* 294 */       synchronized (monitor()) {
/*     */         
/* 296 */         check_orphaned();
/* 297 */         SimpleValue target = null;
/* 298 */         target = (SimpleValue)get_store().find_attribute_user(MIXED$4);
/* 299 */         if (target == null)
/*     */         {
/* 301 */           target = (SimpleValue)get_store().add_attribute_user(MIXED$4);
/*     */         }
/* 303 */         target.setBooleanValue(mixed);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetMixed(XmlBoolean mixed) {
/* 312 */       synchronized (monitor()) {
/*     */         
/* 314 */         check_orphaned();
/* 315 */         XmlBoolean target = null;
/* 316 */         target = (XmlBoolean)get_store().find_attribute_user(MIXED$4);
/* 317 */         if (target == null)
/*     */         {
/* 319 */           target = (XmlBoolean)get_store().add_attribute_user(MIXED$4);
/*     */         }
/* 321 */         target.set((XmlObject)mixed);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetMixed() {
/* 330 */       synchronized (monitor()) {
/*     */         
/* 332 */         check_orphaned();
/* 333 */         get_store().remove_attribute(MIXED$4);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\ComplexContentDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */