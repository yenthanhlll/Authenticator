/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlNCName;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Attribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroup;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AttributeGroupRef;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Wildcard;
/*     */ 
/*     */ public class AttributeGroupImpl
/*     */   extends AnnotatedImpl implements AttributeGroup {
/*     */   public AttributeGroupImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName ATTRIBUTE$0 = new QName("http://www.w3.org/2001/XMLSchema", "attribute");
/*     */   
/*  24 */   private static final QName ATTRIBUTEGROUP$2 = new QName("http://www.w3.org/2001/XMLSchema", "attributeGroup");
/*     */   
/*  26 */   private static final QName ANYATTRIBUTE$4 = new QName("http://www.w3.org/2001/XMLSchema", "anyAttribute");
/*     */   
/*  28 */   private static final QName NAME$6 = new QName("", "name");
/*     */   
/*  30 */   private static final QName REF$8 = new QName("", "ref");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute[] getAttributeArray() {
/*  39 */     synchronized (monitor()) {
/*     */       
/*  41 */       check_orphaned();
/*  42 */       List targetList = new ArrayList();
/*  43 */       get_store().find_all_element_users(ATTRIBUTE$0, targetList);
/*  44 */       Attribute[] result = new Attribute[targetList.size()];
/*  45 */       targetList.toArray((Object[])result);
/*  46 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute getAttributeArray(int i) {
/*  55 */     synchronized (monitor()) {
/*     */       
/*  57 */       check_orphaned();
/*  58 */       Attribute target = null;
/*  59 */       target = (Attribute)get_store().find_element_user(ATTRIBUTE$0, i);
/*  60 */       if (target == null)
/*     */       {
/*  62 */         throw new IndexOutOfBoundsException();
/*     */       }
/*  64 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOfAttributeArray() {
/*  73 */     synchronized (monitor()) {
/*     */       
/*  75 */       check_orphaned();
/*  76 */       return get_store().count_elements(ATTRIBUTE$0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeArray(Attribute[] attributeArray) {
/*  85 */     synchronized (monitor()) {
/*     */       
/*  87 */       check_orphaned();
/*  88 */       arraySetterHelper((XmlObject[])attributeArray, ATTRIBUTE$0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeArray(int i, Attribute attribute) {
/*  97 */     synchronized (monitor()) {
/*     */       
/*  99 */       check_orphaned();
/* 100 */       Attribute target = null;
/* 101 */       target = (Attribute)get_store().find_element_user(ATTRIBUTE$0, i);
/* 102 */       if (target == null)
/*     */       {
/* 104 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 106 */       target.set((XmlObject)attribute);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute insertNewAttribute(int i) {
/* 115 */     synchronized (monitor()) {
/*     */       
/* 117 */       check_orphaned();
/* 118 */       Attribute target = null;
/* 119 */       target = (Attribute)get_store().insert_element_user(ATTRIBUTE$0, i);
/* 120 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute addNewAttribute() {
/* 129 */     synchronized (monitor()) {
/*     */       
/* 131 */       check_orphaned();
/* 132 */       Attribute target = null;
/* 133 */       target = (Attribute)get_store().add_element_user(ATTRIBUTE$0);
/* 134 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(int i) {
/* 143 */     synchronized (monitor()) {
/*     */       
/* 145 */       check_orphaned();
/* 146 */       get_store().remove_element(ATTRIBUTE$0, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef[] getAttributeGroupArray() {
/* 155 */     synchronized (monitor()) {
/*     */       
/* 157 */       check_orphaned();
/* 158 */       List targetList = new ArrayList();
/* 159 */       get_store().find_all_element_users(ATTRIBUTEGROUP$2, targetList);
/* 160 */       AttributeGroupRef[] result = new AttributeGroupRef[targetList.size()];
/* 161 */       targetList.toArray((Object[])result);
/* 162 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef getAttributeGroupArray(int i) {
/* 171 */     synchronized (monitor()) {
/*     */       
/* 173 */       check_orphaned();
/* 174 */       AttributeGroupRef target = null;
/* 175 */       target = (AttributeGroupRef)get_store().find_element_user(ATTRIBUTEGROUP$2, i);
/* 176 */       if (target == null)
/*     */       {
/* 178 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 180 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeOfAttributeGroupArray() {
/* 189 */     synchronized (monitor()) {
/*     */       
/* 191 */       check_orphaned();
/* 192 */       return get_store().count_elements(ATTRIBUTEGROUP$2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeGroupArray(AttributeGroupRef[] attributeGroupArray) {
/* 201 */     synchronized (monitor()) {
/*     */       
/* 203 */       check_orphaned();
/* 204 */       arraySetterHelper((XmlObject[])attributeGroupArray, ATTRIBUTEGROUP$2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributeGroupArray(int i, AttributeGroupRef attributeGroup) {
/* 213 */     synchronized (monitor()) {
/*     */       
/* 215 */       check_orphaned();
/* 216 */       AttributeGroupRef target = null;
/* 217 */       target = (AttributeGroupRef)get_store().find_element_user(ATTRIBUTEGROUP$2, i);
/* 218 */       if (target == null)
/*     */       {
/* 220 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 222 */       target.set((XmlObject)attributeGroup);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef insertNewAttributeGroup(int i) {
/* 231 */     synchronized (monitor()) {
/*     */       
/* 233 */       check_orphaned();
/* 234 */       AttributeGroupRef target = null;
/* 235 */       target = (AttributeGroupRef)get_store().insert_element_user(ATTRIBUTEGROUP$2, i);
/* 236 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeGroupRef addNewAttributeGroup() {
/* 245 */     synchronized (monitor()) {
/*     */       
/* 247 */       check_orphaned();
/* 248 */       AttributeGroupRef target = null;
/* 249 */       target = (AttributeGroupRef)get_store().add_element_user(ATTRIBUTEGROUP$2);
/* 250 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttributeGroup(int i) {
/* 259 */     synchronized (monitor()) {
/*     */       
/* 261 */       check_orphaned();
/* 262 */       get_store().remove_element(ATTRIBUTEGROUP$2, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Wildcard getAnyAttribute() {
/* 271 */     synchronized (monitor()) {
/*     */       
/* 273 */       check_orphaned();
/* 274 */       Wildcard target = null;
/* 275 */       target = (Wildcard)get_store().find_element_user(ANYATTRIBUTE$4, 0);
/* 276 */       if (target == null)
/*     */       {
/* 278 */         return null;
/*     */       }
/* 280 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetAnyAttribute() {
/* 289 */     synchronized (monitor()) {
/*     */       
/* 291 */       check_orphaned();
/* 292 */       return (get_store().count_elements(ANYATTRIBUTE$4) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnyAttribute(Wildcard anyAttribute) {
/* 301 */     synchronized (monitor()) {
/*     */       
/* 303 */       check_orphaned();
/* 304 */       Wildcard target = null;
/* 305 */       target = (Wildcard)get_store().find_element_user(ANYATTRIBUTE$4, 0);
/* 306 */       if (target == null)
/*     */       {
/* 308 */         target = (Wildcard)get_store().add_element_user(ANYATTRIBUTE$4);
/*     */       }
/* 310 */       target.set((XmlObject)anyAttribute);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Wildcard addNewAnyAttribute() {
/* 319 */     synchronized (monitor()) {
/*     */       
/* 321 */       check_orphaned();
/* 322 */       Wildcard target = null;
/* 323 */       target = (Wildcard)get_store().add_element_user(ANYATTRIBUTE$4);
/* 324 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetAnyAttribute() {
/* 333 */     synchronized (monitor()) {
/*     */       
/* 335 */       check_orphaned();
/* 336 */       get_store().remove_element(ANYATTRIBUTE$4, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 345 */     synchronized (monitor()) {
/*     */       
/* 347 */       check_orphaned();
/* 348 */       SimpleValue target = null;
/* 349 */       target = (SimpleValue)get_store().find_attribute_user(NAME$6);
/* 350 */       if (target == null)
/*     */       {
/* 352 */         return null;
/*     */       }
/* 354 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlNCName xgetName() {
/* 363 */     synchronized (monitor()) {
/*     */       
/* 365 */       check_orphaned();
/* 366 */       XmlNCName target = null;
/* 367 */       target = (XmlNCName)get_store().find_attribute_user(NAME$6);
/* 368 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetName() {
/* 377 */     synchronized (monitor()) {
/*     */       
/* 379 */       check_orphaned();
/* 380 */       return (get_store().find_attribute_user(NAME$6) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 389 */     synchronized (monitor()) {
/*     */       
/* 391 */       check_orphaned();
/* 392 */       SimpleValue target = null;
/* 393 */       target = (SimpleValue)get_store().find_attribute_user(NAME$6);
/* 394 */       if (target == null)
/*     */       {
/* 396 */         target = (SimpleValue)get_store().add_attribute_user(NAME$6);
/*     */       }
/* 398 */       target.setStringValue(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetName(XmlNCName name) {
/* 407 */     synchronized (monitor()) {
/*     */       
/* 409 */       check_orphaned();
/* 410 */       XmlNCName target = null;
/* 411 */       target = (XmlNCName)get_store().find_attribute_user(NAME$6);
/* 412 */       if (target == null)
/*     */       {
/* 414 */         target = (XmlNCName)get_store().add_attribute_user(NAME$6);
/*     */       }
/* 416 */       target.set((XmlObject)name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetName() {
/* 425 */     synchronized (monitor()) {
/*     */       
/* 427 */       check_orphaned();
/* 428 */       get_store().remove_attribute(NAME$6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getRef() {
/* 437 */     synchronized (monitor()) {
/*     */       
/* 439 */       check_orphaned();
/* 440 */       SimpleValue target = null;
/* 441 */       target = (SimpleValue)get_store().find_attribute_user(REF$8);
/* 442 */       if (target == null)
/*     */       {
/* 444 */         return null;
/*     */       }
/* 446 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetRef() {
/* 455 */     synchronized (monitor()) {
/*     */       
/* 457 */       check_orphaned();
/* 458 */       XmlQName target = null;
/* 459 */       target = (XmlQName)get_store().find_attribute_user(REF$8);
/* 460 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetRef() {
/* 469 */     synchronized (monitor()) {
/*     */       
/* 471 */       check_orphaned();
/* 472 */       return (get_store().find_attribute_user(REF$8) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRef(QName ref) {
/* 481 */     synchronized (monitor()) {
/*     */       
/* 483 */       check_orphaned();
/* 484 */       SimpleValue target = null;
/* 485 */       target = (SimpleValue)get_store().find_attribute_user(REF$8);
/* 486 */       if (target == null)
/*     */       {
/* 488 */         target = (SimpleValue)get_store().add_attribute_user(REF$8);
/*     */       }
/* 490 */       target.setQNameValue(ref);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetRef(XmlQName ref) {
/* 499 */     synchronized (monitor()) {
/*     */       
/* 501 */       check_orphaned();
/* 502 */       XmlQName target = null;
/* 503 */       target = (XmlQName)get_store().find_attribute_user(REF$8);
/* 504 */       if (target == null)
/*     */       {
/* 506 */         target = (XmlQName)get_store().add_attribute_user(REF$8);
/*     */       }
/* 508 */       target.set((XmlObject)ref);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetRef() {
/* 517 */     synchronized (monitor()) {
/*     */       
/* 519 */       check_orphaned();
/* 520 */       get_store().remove_attribute(REF$8);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AttributeGroupImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */