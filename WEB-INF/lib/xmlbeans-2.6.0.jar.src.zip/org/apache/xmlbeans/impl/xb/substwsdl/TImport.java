/*     */ package org.apache.xmlbeans.impl.xb.substwsdl;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface TImport extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$substwsdl$TImport == null) ? (null.class$org$apache$xmlbeans$impl$xb$substwsdl$TImport = null.class$("org.apache.xmlbeans.impl.xb.substwsdl.TImport")) : null.class$org$apache$xmlbeans$impl$xb$substwsdl$TImport).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("timport22datype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI xgetNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setNamespace(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetNamespace(XmlAnyURI paramXmlAnyURI);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getLocation();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI xgetLocation();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setLocation(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetLocation(XmlAnyURI paramXmlAnyURI);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static TImport newInstance() {
/*  69 */       return (TImport)XmlBeans.getContextTypeLoader().newInstance(TImport.type, null);
/*     */     }
/*     */     public static TImport newInstance(XmlOptions options) {
/*  72 */       return (TImport)XmlBeans.getContextTypeLoader().newInstance(TImport.type, options);
/*     */     }
/*     */     
/*     */     public static TImport parse(String xmlAsString) throws XmlException {
/*  76 */       return (TImport)XmlBeans.getContextTypeLoader().parse(xmlAsString, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(String xmlAsString, XmlOptions options) throws XmlException {
/*  79 */       return (TImport)XmlBeans.getContextTypeLoader().parse(xmlAsString, TImport.type, options);
/*     */     }
/*     */     
/*     */     public static TImport parse(File file) throws XmlException, IOException {
/*  83 */       return (TImport)XmlBeans.getContextTypeLoader().parse(file, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(File file, XmlOptions options) throws XmlException, IOException {
/*  86 */       return (TImport)XmlBeans.getContextTypeLoader().parse(file, TImport.type, options);
/*     */     }
/*     */     public static TImport parse(URL u) throws XmlException, IOException {
/*  89 */       return (TImport)XmlBeans.getContextTypeLoader().parse(u, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(URL u, XmlOptions options) throws XmlException, IOException {
/*  92 */       return (TImport)XmlBeans.getContextTypeLoader().parse(u, TImport.type, options);
/*     */     }
/*     */     public static TImport parse(InputStream is) throws XmlException, IOException {
/*  95 */       return (TImport)XmlBeans.getContextTypeLoader().parse(is, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/*  98 */       return (TImport)XmlBeans.getContextTypeLoader().parse(is, TImport.type, options);
/*     */     }
/*     */     public static TImport parse(Reader r) throws XmlException, IOException {
/* 101 */       return (TImport)XmlBeans.getContextTypeLoader().parse(r, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 104 */       return (TImport)XmlBeans.getContextTypeLoader().parse(r, TImport.type, options);
/*     */     }
/*     */     public static TImport parse(XMLStreamReader sr) throws XmlException {
/* 107 */       return (TImport)XmlBeans.getContextTypeLoader().parse(sr, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 110 */       return (TImport)XmlBeans.getContextTypeLoader().parse(sr, TImport.type, options);
/*     */     }
/*     */     public static TImport parse(Node node) throws XmlException {
/* 113 */       return (TImport)XmlBeans.getContextTypeLoader().parse(node, TImport.type, null);
/*     */     }
/*     */     public static TImport parse(Node node, XmlOptions options) throws XmlException {
/* 116 */       return (TImport)XmlBeans.getContextTypeLoader().parse(node, TImport.type, options);
/*     */     }
/*     */     
/*     */     public static TImport parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 120 */       return (TImport)XmlBeans.getContextTypeLoader().parse(xis, TImport.type, null);
/*     */     }
/*     */     
/*     */     public static TImport parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 124 */       return (TImport)XmlBeans.getContextTypeLoader().parse(xis, TImport.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 128 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, TImport.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 132 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, TImport.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\substwsdl\TImport.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */