/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.DerivationControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DerivationControlImpl
/*    */   extends JavaStringEnumerationHolderEx
/*    */   implements DerivationControl
/*    */ {
/*    */   public DerivationControlImpl(SchemaType sType) {
/* 19 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected DerivationControlImpl(SchemaType sType, boolean b) {
/* 24 */     super(sType, b);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\DerivationControlImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */