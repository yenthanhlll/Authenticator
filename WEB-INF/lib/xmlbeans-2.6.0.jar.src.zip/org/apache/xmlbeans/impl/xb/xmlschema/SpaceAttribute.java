/*     */ package org.apache.xmlbeans.impl.xb.xmlschema;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlNCName;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface SpaceAttribute extends XmlObject {
/*  19 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlschema$SpaceAttribute == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlschema$SpaceAttribute = null.class$("org.apache.xmlbeans.impl.xb.xmlschema.SpaceAttribute")) : null.class$org$apache$xmlbeans$impl$xb$xmlschema$SpaceAttribute).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLLANG").resolveHandle("space9344attrtypetype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Space.Enum getSpace();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Space xgetSpace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetSpace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSpace(Space.Enum paramEnum);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetSpace(Space paramSpace);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetSpace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Space
/*     */     extends XmlNCName
/*     */   {
/*  59 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((SpaceAttribute.null.class$org$apache$xmlbeans$impl$xb$xmlschema$SpaceAttribute$Space == null) ? (SpaceAttribute.null.class$org$apache$xmlbeans$impl$xb$xmlschema$SpaceAttribute$Space = SpaceAttribute.null.class$("org.apache.xmlbeans.impl.xb.xmlschema.SpaceAttribute$Space")) : SpaceAttribute.null.class$org$apache$xmlbeans$impl$xb$xmlschema$SpaceAttribute$Space).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLLANG").resolveHandle("spaceb986attrtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     public static final Enum DEFAULT = Enum.forString("default");
/*  66 */     public static final Enum PRESERVE = Enum.forString("preserve");
/*     */ 
/*     */     
/*     */     public static final int INT_DEFAULT = 1;
/*     */ 
/*     */     
/*     */     public static final int INT_PRESERVE = 2;
/*     */ 
/*     */ 
/*     */     
/*     */     StringEnumAbstractBase enumValue();
/*     */ 
/*     */ 
/*     */     
/*     */     void set(StringEnumAbstractBase param1StringEnumAbstractBase);
/*     */ 
/*     */     
/*     */     public static final class Enum
/*     */       extends StringEnumAbstractBase
/*     */     {
/*     */       static final int INT_DEFAULT = 1;
/*     */       
/*     */       static final int INT_PRESERVE = 2;
/*     */ 
/*     */       
/*     */       public static Enum forString(String s) {
/*  92 */         return (Enum)table.forString(s);
/*     */       }
/*     */ 
/*     */       
/*     */       public static Enum forInt(int i) {
/*  97 */         return (Enum)table.forInt(i);
/*     */       }
/*     */       private Enum(String s, int i) {
/* 100 */         super(s, i);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 105 */       public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("default", 1), new Enum("preserve", 2) });
/*     */ 
/*     */ 
/*     */       
/*     */       private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private Object readResolve() {
/* 115 */         return forInt(intValue());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static SpaceAttribute.Space newValue(Object obj) {
/* 126 */         return (SpaceAttribute.Space)SpaceAttribute.Space.type.newValue(obj);
/*     */       }
/*     */       public static SpaceAttribute.Space newInstance() {
/* 129 */         return (SpaceAttribute.Space)XmlBeans.getContextTypeLoader().newInstance(SpaceAttribute.Space.type, null);
/*     */       }
/*     */       public static SpaceAttribute.Space newInstance(XmlOptions options) {
/* 132 */         return (SpaceAttribute.Space)XmlBeans.getContextTypeLoader().newInstance(SpaceAttribute.Space.type, options);
/*     */       } }
/*     */   } public static final class Enum extends StringEnumAbstractBase { static final int INT_DEFAULT = 1; static final int INT_PRESERVE = 2; public static Enum forString(String s) {
/*     */       return (Enum)table.forString(s);
/*     */     } public static Enum forInt(int i) {
/*     */       return (Enum)table.forInt(i);
/*     */     } private Enum(String s, int i) {
/*     */       super(s, i);
/*     */     }
/*     */     public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("default", 1), new Enum("preserve", 2) }); private static final long serialVersionUID = 1L;
/*     */     private Object readResolve() {
/*     */       return forInt(intValue());
/*     */     } }
/*     */   public static final class Factory { public static SpaceAttribute newInstance() {
/* 146 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().newInstance(SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute newInstance(XmlOptions options) {
/* 149 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().newInstance(SpaceAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static SpaceAttribute parse(String xmlAsString) throws XmlException {
/* 153 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(xmlAsString, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 156 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(xmlAsString, SpaceAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static SpaceAttribute parse(File file) throws XmlException, IOException {
/* 160 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(file, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(File file, XmlOptions options) throws XmlException, IOException {
/* 163 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(file, SpaceAttribute.type, options);
/*     */     }
/*     */     public static SpaceAttribute parse(URL u) throws XmlException, IOException {
/* 166 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(u, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 169 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(u, SpaceAttribute.type, options);
/*     */     }
/*     */     public static SpaceAttribute parse(InputStream is) throws XmlException, IOException {
/* 172 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(is, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 175 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(is, SpaceAttribute.type, options);
/*     */     }
/*     */     public static SpaceAttribute parse(Reader r) throws XmlException, IOException {
/* 178 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(r, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 181 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(r, SpaceAttribute.type, options);
/*     */     }
/*     */     public static SpaceAttribute parse(XMLStreamReader sr) throws XmlException {
/* 184 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(sr, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 187 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(sr, SpaceAttribute.type, options);
/*     */     }
/*     */     public static SpaceAttribute parse(Node node) throws XmlException {
/* 190 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(node, SpaceAttribute.type, null);
/*     */     }
/*     */     public static SpaceAttribute parse(Node node, XmlOptions options) throws XmlException {
/* 193 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(node, SpaceAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static SpaceAttribute parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 197 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(xis, SpaceAttribute.type, null);
/*     */     }
/*     */     
/*     */     public static SpaceAttribute parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 201 */       return (SpaceAttribute)XmlBeans.getContextTypeLoader().parse(xis, SpaceAttribute.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 205 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, SpaceAttribute.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 209 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, SpaceAttribute.type, options);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlschema\SpaceAttribute.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */