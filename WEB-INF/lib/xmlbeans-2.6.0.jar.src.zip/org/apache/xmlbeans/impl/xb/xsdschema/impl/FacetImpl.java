/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBoolean;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.Facet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FacetImpl
/*     */   extends AnnotatedImpl
/*     */   implements Facet
/*     */ {
/*     */   public FacetImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName VALUE$0 = new QName("", "value");
/*     */   
/*  24 */   private static final QName FIXED$2 = new QName("", "fixed");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnySimpleType getValue() {
/*  33 */     synchronized (monitor()) {
/*     */       
/*  35 */       check_orphaned();
/*  36 */       XmlAnySimpleType target = null;
/*  37 */       target = (XmlAnySimpleType)get_store().find_attribute_user(VALUE$0);
/*  38 */       if (target == null)
/*     */       {
/*  40 */         return null;
/*     */       }
/*  42 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(XmlAnySimpleType value) {
/*  51 */     synchronized (monitor()) {
/*     */       
/*  53 */       check_orphaned();
/*  54 */       XmlAnySimpleType target = null;
/*  55 */       target = (XmlAnySimpleType)get_store().find_attribute_user(VALUE$0);
/*  56 */       if (target == null)
/*     */       {
/*  58 */         target = (XmlAnySimpleType)get_store().add_attribute_user(VALUE$0);
/*     */       }
/*  60 */       target.set((XmlObject)value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnySimpleType addNewValue() {
/*  69 */     synchronized (monitor()) {
/*     */       
/*  71 */       check_orphaned();
/*  72 */       XmlAnySimpleType target = null;
/*  73 */       target = (XmlAnySimpleType)get_store().add_attribute_user(VALUE$0);
/*  74 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFixed() {
/*  83 */     synchronized (monitor()) {
/*     */       
/*  85 */       check_orphaned();
/*  86 */       SimpleValue target = null;
/*  87 */       target = (SimpleValue)get_store().find_attribute_user(FIXED$2);
/*  88 */       if (target == null)
/*     */       {
/*  90 */         target = (SimpleValue)get_default_attribute_value(FIXED$2);
/*     */       }
/*  92 */       if (target == null)
/*     */       {
/*  94 */         return false;
/*     */       }
/*  96 */       return target.getBooleanValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlBoolean xgetFixed() {
/* 105 */     synchronized (monitor()) {
/*     */       
/* 107 */       check_orphaned();
/* 108 */       XmlBoolean target = null;
/* 109 */       target = (XmlBoolean)get_store().find_attribute_user(FIXED$2);
/* 110 */       if (target == null)
/*     */       {
/* 112 */         target = (XmlBoolean)get_default_attribute_value(FIXED$2);
/*     */       }
/* 114 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetFixed() {
/* 123 */     synchronized (monitor()) {
/*     */       
/* 125 */       check_orphaned();
/* 126 */       return (get_store().find_attribute_user(FIXED$2) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFixed(boolean fixed) {
/* 135 */     synchronized (monitor()) {
/*     */       
/* 137 */       check_orphaned();
/* 138 */       SimpleValue target = null;
/* 139 */       target = (SimpleValue)get_store().find_attribute_user(FIXED$2);
/* 140 */       if (target == null)
/*     */       {
/* 142 */         target = (SimpleValue)get_store().add_attribute_user(FIXED$2);
/*     */       }
/* 144 */       target.setBooleanValue(fixed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetFixed(XmlBoolean fixed) {
/* 153 */     synchronized (monitor()) {
/*     */       
/* 155 */       check_orphaned();
/* 156 */       XmlBoolean target = null;
/* 157 */       target = (XmlBoolean)get_store().find_attribute_user(FIXED$2);
/* 158 */       if (target == null)
/*     */       {
/* 160 */         target = (XmlBoolean)get_store().add_attribute_user(FIXED$2);
/*     */       }
/* 162 */       target.set((XmlObject)fixed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetFixed() {
/* 171 */     synchronized (monitor()) {
/*     */       
/* 173 */       check_orphaned();
/* 174 */       get_store().remove_attribute(FIXED$2);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\FacetImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */