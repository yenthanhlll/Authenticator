/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Qnameconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Qnametargetlist;
/*     */ 
/*     */ public class QnameconfigImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements Qnameconfig
/*     */ {
/*     */   public QnameconfigImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName NAME$0 = new QName("", "name");
/*     */   
/*  24 */   private static final QName JAVANAME$2 = new QName("", "javaname");
/*     */   
/*  26 */   private static final QName TARGET$4 = new QName("", "target");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getName() {
/*  35 */     synchronized (monitor()) {
/*     */       
/*  37 */       check_orphaned();
/*  38 */       SimpleValue target = null;
/*  39 */       target = (SimpleValue)get_store().find_attribute_user(NAME$0);
/*  40 */       if (target == null)
/*     */       {
/*  42 */         return null;
/*     */       }
/*  44 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetName() {
/*  53 */     synchronized (monitor()) {
/*     */       
/*  55 */       check_orphaned();
/*  56 */       XmlQName target = null;
/*  57 */       target = (XmlQName)get_store().find_attribute_user(NAME$0);
/*  58 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetName() {
/*  67 */     synchronized (monitor()) {
/*     */       
/*  69 */       check_orphaned();
/*  70 */       return (get_store().find_attribute_user(NAME$0) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(QName name) {
/*  79 */     synchronized (monitor()) {
/*     */       
/*  81 */       check_orphaned();
/*  82 */       SimpleValue target = null;
/*  83 */       target = (SimpleValue)get_store().find_attribute_user(NAME$0);
/*  84 */       if (target == null)
/*     */       {
/*  86 */         target = (SimpleValue)get_store().add_attribute_user(NAME$0);
/*     */       }
/*  88 */       target.setQNameValue(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetName(XmlQName name) {
/*  97 */     synchronized (monitor()) {
/*     */       
/*  99 */       check_orphaned();
/* 100 */       XmlQName target = null;
/* 101 */       target = (XmlQName)get_store().find_attribute_user(NAME$0);
/* 102 */       if (target == null)
/*     */       {
/* 104 */         target = (XmlQName)get_store().add_attribute_user(NAME$0);
/*     */       }
/* 106 */       target.set((XmlObject)name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetName() {
/* 115 */     synchronized (monitor()) {
/*     */       
/* 117 */       check_orphaned();
/* 118 */       get_store().remove_attribute(NAME$0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaname() {
/* 127 */     synchronized (monitor()) {
/*     */       
/* 129 */       check_orphaned();
/* 130 */       SimpleValue target = null;
/* 131 */       target = (SimpleValue)get_store().find_attribute_user(JAVANAME$2);
/* 132 */       if (target == null)
/*     */       {
/* 134 */         return null;
/*     */       }
/* 136 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetJavaname() {
/* 145 */     synchronized (monitor()) {
/*     */       
/* 147 */       check_orphaned();
/* 148 */       XmlString target = null;
/* 149 */       target = (XmlString)get_store().find_attribute_user(JAVANAME$2);
/* 150 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetJavaname() {
/* 159 */     synchronized (monitor()) {
/*     */       
/* 161 */       check_orphaned();
/* 162 */       return (get_store().find_attribute_user(JAVANAME$2) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaname(String javaname) {
/* 171 */     synchronized (monitor()) {
/*     */       
/* 173 */       check_orphaned();
/* 174 */       SimpleValue target = null;
/* 175 */       target = (SimpleValue)get_store().find_attribute_user(JAVANAME$2);
/* 176 */       if (target == null)
/*     */       {
/* 178 */         target = (SimpleValue)get_store().add_attribute_user(JAVANAME$2);
/*     */       }
/* 180 */       target.setStringValue(javaname);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetJavaname(XmlString javaname) {
/* 189 */     synchronized (monitor()) {
/*     */       
/* 191 */       check_orphaned();
/* 192 */       XmlString target = null;
/* 193 */       target = (XmlString)get_store().find_attribute_user(JAVANAME$2);
/* 194 */       if (target == null)
/*     */       {
/* 196 */         target = (XmlString)get_store().add_attribute_user(JAVANAME$2);
/*     */       }
/* 198 */       target.set((XmlObject)javaname);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetJavaname() {
/* 207 */     synchronized (monitor()) {
/*     */       
/* 209 */       check_orphaned();
/* 210 */       get_store().remove_attribute(JAVANAME$2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getTarget() {
/* 219 */     synchronized (monitor()) {
/*     */       
/* 221 */       check_orphaned();
/* 222 */       SimpleValue target = null;
/* 223 */       target = (SimpleValue)get_store().find_attribute_user(TARGET$4);
/* 224 */       if (target == null)
/*     */       {
/* 226 */         target = (SimpleValue)get_default_attribute_value(TARGET$4);
/*     */       }
/* 228 */       if (target == null)
/*     */       {
/* 230 */         return null;
/*     */       }
/* 232 */       return target.getListValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Qnametargetlist xgetTarget() {
/* 241 */     synchronized (monitor()) {
/*     */       
/* 243 */       check_orphaned();
/* 244 */       Qnametargetlist target = null;
/* 245 */       target = (Qnametargetlist)get_store().find_attribute_user(TARGET$4);
/* 246 */       if (target == null)
/*     */       {
/* 248 */         target = (Qnametargetlist)get_default_attribute_value(TARGET$4);
/*     */       }
/* 250 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetTarget() {
/* 259 */     synchronized (monitor()) {
/*     */       
/* 261 */       check_orphaned();
/* 262 */       return (get_store().find_attribute_user(TARGET$4) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(List targetValue) {
/* 271 */     synchronized (monitor()) {
/*     */       
/* 273 */       check_orphaned();
/* 274 */       SimpleValue target = null;
/* 275 */       target = (SimpleValue)get_store().find_attribute_user(TARGET$4);
/* 276 */       if (target == null)
/*     */       {
/* 278 */         target = (SimpleValue)get_store().add_attribute_user(TARGET$4);
/*     */       }
/* 280 */       target.setListValue(targetValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetTarget(Qnametargetlist targetValue) {
/* 289 */     synchronized (monitor()) {
/*     */       
/* 291 */       check_orphaned();
/* 292 */       Qnametargetlist target = null;
/* 293 */       target = (Qnametargetlist)get_store().find_attribute_user(TARGET$4);
/* 294 */       if (target == null)
/*     */       {
/* 296 */         target = (Qnametargetlist)get_store().add_attribute_user(TARGET$4);
/*     */       }
/* 298 */       target.set((XmlObject)targetValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetTarget() {
/* 307 */     synchronized (monitor()) {
/*     */       
/* 309 */       check_orphaned();
/* 310 */       get_store().remove_attribute(TARGET$4);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\QnameconfigImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */