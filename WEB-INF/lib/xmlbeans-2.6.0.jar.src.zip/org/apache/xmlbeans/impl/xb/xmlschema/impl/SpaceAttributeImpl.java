/*     */ package org.apache.xmlbeans.impl.xb.xmlschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlschema.SpaceAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpaceAttributeImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements SpaceAttribute
/*     */ {
/*     */   public SpaceAttributeImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName SPACE$0 = new QName("http://www.w3.org/XML/1998/namespace", "space");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpaceAttribute.Space.Enum getSpace() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       SimpleValue target = null;
/*  36 */       target = (SimpleValue)get_store().find_attribute_user(SPACE$0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         target = (SimpleValue)get_default_attribute_value(SPACE$0);
/*     */       }
/*  41 */       if (target == null)
/*     */       {
/*  43 */         return null;
/*     */       }
/*  45 */       return (SpaceAttribute.Space.Enum)target.getEnumValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpaceAttribute.Space xgetSpace() {
/*  54 */     synchronized (monitor()) {
/*     */       
/*  56 */       check_orphaned();
/*  57 */       SpaceAttribute.Space target = null;
/*  58 */       target = (SpaceAttribute.Space)get_store().find_attribute_user(SPACE$0);
/*  59 */       if (target == null)
/*     */       {
/*  61 */         target = (SpaceAttribute.Space)get_default_attribute_value(SPACE$0);
/*     */       }
/*  63 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetSpace() {
/*  72 */     synchronized (monitor()) {
/*     */       
/*  74 */       check_orphaned();
/*  75 */       return (get_store().find_attribute_user(SPACE$0) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpace(SpaceAttribute.Space.Enum space) {
/*  84 */     synchronized (monitor()) {
/*     */       
/*  86 */       check_orphaned();
/*  87 */       SimpleValue target = null;
/*  88 */       target = (SimpleValue)get_store().find_attribute_user(SPACE$0);
/*  89 */       if (target == null)
/*     */       {
/*  91 */         target = (SimpleValue)get_store().add_attribute_user(SPACE$0);
/*     */       }
/*  93 */       target.setEnumValue((StringEnumAbstractBase)space);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetSpace(SpaceAttribute.Space space) {
/* 102 */     synchronized (monitor()) {
/*     */       
/* 104 */       check_orphaned();
/* 105 */       SpaceAttribute.Space target = null;
/* 106 */       target = (SpaceAttribute.Space)get_store().find_attribute_user(SPACE$0);
/* 107 */       if (target == null)
/*     */       {
/* 109 */         target = (SpaceAttribute.Space)get_store().add_attribute_user(SPACE$0);
/*     */       }
/* 111 */       target.set((XmlObject)space);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSpace() {
/* 120 */     synchronized (monitor()) {
/*     */       
/* 122 */       check_orphaned();
/* 123 */       get_store().remove_attribute(SPACE$0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SpaceImpl
/*     */     extends JavaStringEnumerationHolderEx
/*     */     implements SpaceAttribute.Space
/*     */   {
/*     */     public SpaceImpl(SchemaType sType) {
/* 136 */       super(sType, false);
/*     */     }
/*     */ 
/*     */     
/*     */     protected SpaceImpl(SchemaType sType, boolean b) {
/* 141 */       super(sType, b);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlschema\impl\SpaceAttributeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */