/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.FormChoice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormChoiceImpl
/*    */   extends JavaStringEnumerationHolderEx
/*    */   implements FormChoice
/*    */ {
/*    */   public FormChoiceImpl(SchemaType sType) {
/* 19 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected FormChoiceImpl(SchemaType sType, boolean b) {
/* 24 */     super(sType, b);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\FormChoiceImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */