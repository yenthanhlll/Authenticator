/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlNonNegativeInteger;
/*    */ import org.apache.xmlbeans.impl.values.JavaIntegerHolderEx;
/*    */ import org.apache.xmlbeans.impl.values.XmlUnionImpl;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.All;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.AllNNI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllImpl
/*    */   extends ExplicitGroupImpl
/*    */   implements All
/*    */ {
/*    */   public AllImpl(SchemaType sType) {
/* 19 */     super(sType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class MinOccursImpl
/*    */     extends JavaIntegerHolderEx
/*    */     implements All.MinOccurs
/*    */   {
/*    */     public MinOccursImpl(SchemaType sType) {
/* 33 */       super(sType, false);
/*    */     }
/*    */ 
/*    */     
/*    */     protected MinOccursImpl(SchemaType sType, boolean b) {
/* 38 */       super(sType, b);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class MaxOccursImpl
/*    */     extends XmlUnionImpl
/*    */     implements All.MaxOccurs, XmlNonNegativeInteger, AllNNI.Member
/*    */   {
/*    */     public MaxOccursImpl(SchemaType sType) {
/* 53 */       super(sType, false);
/*    */     }
/*    */ 
/*    */     
/*    */     protected MaxOccursImpl(SchemaType sType, boolean b) {
/* 58 */       super(sType, b);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AllImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */