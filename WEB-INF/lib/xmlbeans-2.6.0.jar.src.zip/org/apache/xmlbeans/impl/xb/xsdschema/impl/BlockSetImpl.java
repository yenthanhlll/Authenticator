/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*    */ import org.apache.xmlbeans.impl.values.XmlListImpl;
/*    */ import org.apache.xmlbeans.impl.values.XmlUnionImpl;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.BlockSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockSetImpl
/*    */   extends XmlUnionImpl
/*    */   implements BlockSet, BlockSet.Member, BlockSet.Member2
/*    */ {
/*    */   public BlockSetImpl(SchemaType sType) {
/* 21 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected BlockSetImpl(SchemaType sType, boolean b) {
/* 26 */     super(sType, b);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class MemberImpl
/*    */     extends JavaStringEnumerationHolderEx
/*    */     implements BlockSet.Member
/*    */   {
/*    */     public MemberImpl(SchemaType sType) {
/* 38 */       super(sType, false);
/*    */     }
/*    */ 
/*    */     
/*    */     protected MemberImpl(SchemaType sType, boolean b) {
/* 43 */       super(sType, b);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class MemberImpl2
/*    */     extends XmlListImpl
/*    */     implements BlockSet.Member2
/*    */   {
/*    */     public MemberImpl2(SchemaType sType) {
/* 56 */       super(sType, false);
/*    */     }
/*    */ 
/*    */     
/*    */     protected MemberImpl2(SchemaType sType, boolean b) {
/* 61 */       super(sType, b);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static class ItemImpl
/*    */       extends JavaStringEnumerationHolderEx
/*    */       implements BlockSet.Member2.Item
/*    */     {
/*    */       public ItemImpl(SchemaType sType) {
/* 73 */         super(sType, false);
/*    */       }
/*    */ 
/*    */       
/*    */       protected ItemImpl(SchemaType sType, boolean b) {
/* 78 */         super(sType, b);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\BlockSetImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */