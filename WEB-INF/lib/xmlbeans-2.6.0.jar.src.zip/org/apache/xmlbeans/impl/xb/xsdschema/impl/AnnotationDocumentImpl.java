/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlID;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AnnotationDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AppinfoDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.DocumentationDocument;
/*     */ 
/*     */ public class AnnotationDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements AnnotationDocument
/*     */ {
/*     */   public AnnotationDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName ANNOTATION$0 = new QName("http://www.w3.org/2001/XMLSchema", "annotation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationDocument.Annotation getAnnotation() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       AnnotationDocument.Annotation target = null;
/*  36 */       target = (AnnotationDocument.Annotation)get_store().find_element_user(ANNOTATION$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotation(AnnotationDocument.Annotation annotation) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       AnnotationDocument.Annotation target = null;
/*  54 */       target = (AnnotationDocument.Annotation)get_store().find_element_user(ANNOTATION$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (AnnotationDocument.Annotation)get_store().add_element_user(ANNOTATION$0);
/*     */       }
/*  59 */       target.set((XmlObject)annotation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationDocument.Annotation addNewAnnotation() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       AnnotationDocument.Annotation target = null;
/*  72 */       target = (AnnotationDocument.Annotation)get_store().add_element_user(ANNOTATION$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AnnotationImpl
/*     */     extends OpenAttrsImpl
/*     */     implements AnnotationDocument.Annotation
/*     */   {
/*     */     public AnnotationImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName APPINFO$0 = new QName("http://www.w3.org/2001/XMLSchema", "appinfo");
/*     */     
/*  91 */     private static final QName DOCUMENTATION$2 = new QName("http://www.w3.org/2001/XMLSchema", "documentation");
/*     */     
/*  93 */     private static final QName ID$4 = new QName("", "id");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AppinfoDocument.Appinfo[] getAppinfoArray() {
/* 102 */       synchronized (monitor()) {
/*     */         
/* 104 */         check_orphaned();
/* 105 */         List targetList = new ArrayList();
/* 106 */         get_store().find_all_element_users(APPINFO$0, targetList);
/* 107 */         AppinfoDocument.Appinfo[] result = new AppinfoDocument.Appinfo[targetList.size()];
/* 108 */         targetList.toArray((Object[])result);
/* 109 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AppinfoDocument.Appinfo getAppinfoArray(int i) {
/* 118 */       synchronized (monitor()) {
/*     */         
/* 120 */         check_orphaned();
/* 121 */         AppinfoDocument.Appinfo target = null;
/* 122 */         target = (AppinfoDocument.Appinfo)get_store().find_element_user(APPINFO$0, i);
/* 123 */         if (target == null)
/*     */         {
/* 125 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 127 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfAppinfoArray() {
/* 136 */       synchronized (monitor()) {
/*     */         
/* 138 */         check_orphaned();
/* 139 */         return get_store().count_elements(APPINFO$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setAppinfoArray(AppinfoDocument.Appinfo[] appinfoArray) {
/* 148 */       synchronized (monitor()) {
/*     */         
/* 150 */         check_orphaned();
/* 151 */         arraySetterHelper((XmlObject[])appinfoArray, APPINFO$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setAppinfoArray(int i, AppinfoDocument.Appinfo appinfo) {
/* 160 */       synchronized (monitor()) {
/*     */         
/* 162 */         check_orphaned();
/* 163 */         AppinfoDocument.Appinfo target = null;
/* 164 */         target = (AppinfoDocument.Appinfo)get_store().find_element_user(APPINFO$0, i);
/* 165 */         if (target == null)
/*     */         {
/* 167 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 169 */         target.set((XmlObject)appinfo);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AppinfoDocument.Appinfo insertNewAppinfo(int i) {
/* 178 */       synchronized (monitor()) {
/*     */         
/* 180 */         check_orphaned();
/* 181 */         AppinfoDocument.Appinfo target = null;
/* 182 */         target = (AppinfoDocument.Appinfo)get_store().insert_element_user(APPINFO$0, i);
/* 183 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AppinfoDocument.Appinfo addNewAppinfo() {
/* 192 */       synchronized (monitor()) {
/*     */         
/* 194 */         check_orphaned();
/* 195 */         AppinfoDocument.Appinfo target = null;
/* 196 */         target = (AppinfoDocument.Appinfo)get_store().add_element_user(APPINFO$0);
/* 197 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeAppinfo(int i) {
/* 206 */       synchronized (monitor()) {
/*     */         
/* 208 */         check_orphaned();
/* 209 */         get_store().remove_element(APPINFO$0, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DocumentationDocument.Documentation[] getDocumentationArray() {
/* 218 */       synchronized (monitor()) {
/*     */         
/* 220 */         check_orphaned();
/* 221 */         List targetList = new ArrayList();
/* 222 */         get_store().find_all_element_users(DOCUMENTATION$2, targetList);
/* 223 */         DocumentationDocument.Documentation[] result = new DocumentationDocument.Documentation[targetList.size()];
/* 224 */         targetList.toArray((Object[])result);
/* 225 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DocumentationDocument.Documentation getDocumentationArray(int i) {
/* 234 */       synchronized (monitor()) {
/*     */         
/* 236 */         check_orphaned();
/* 237 */         DocumentationDocument.Documentation target = null;
/* 238 */         target = (DocumentationDocument.Documentation)get_store().find_element_user(DOCUMENTATION$2, i);
/* 239 */         if (target == null)
/*     */         {
/* 241 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 243 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfDocumentationArray() {
/* 252 */       synchronized (monitor()) {
/*     */         
/* 254 */         check_orphaned();
/* 255 */         return get_store().count_elements(DOCUMENTATION$2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setDocumentationArray(DocumentationDocument.Documentation[] documentationArray) {
/* 264 */       synchronized (monitor()) {
/*     */         
/* 266 */         check_orphaned();
/* 267 */         arraySetterHelper((XmlObject[])documentationArray, DOCUMENTATION$2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setDocumentationArray(int i, DocumentationDocument.Documentation documentation) {
/* 276 */       synchronized (monitor()) {
/*     */         
/* 278 */         check_orphaned();
/* 279 */         DocumentationDocument.Documentation target = null;
/* 280 */         target = (DocumentationDocument.Documentation)get_store().find_element_user(DOCUMENTATION$2, i);
/* 281 */         if (target == null)
/*     */         {
/* 283 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 285 */         target.set((XmlObject)documentation);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DocumentationDocument.Documentation insertNewDocumentation(int i) {
/* 294 */       synchronized (monitor()) {
/*     */         
/* 296 */         check_orphaned();
/* 297 */         DocumentationDocument.Documentation target = null;
/* 298 */         target = (DocumentationDocument.Documentation)get_store().insert_element_user(DOCUMENTATION$2, i);
/* 299 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DocumentationDocument.Documentation addNewDocumentation() {
/* 308 */       synchronized (monitor()) {
/*     */         
/* 310 */         check_orphaned();
/* 311 */         DocumentationDocument.Documentation target = null;
/* 312 */         target = (DocumentationDocument.Documentation)get_store().add_element_user(DOCUMENTATION$2);
/* 313 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeDocumentation(int i) {
/* 322 */       synchronized (monitor()) {
/*     */         
/* 324 */         check_orphaned();
/* 325 */         get_store().remove_element(DOCUMENTATION$2, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getId() {
/* 334 */       synchronized (monitor()) {
/*     */         
/* 336 */         check_orphaned();
/* 337 */         SimpleValue target = null;
/* 338 */         target = (SimpleValue)get_store().find_attribute_user(ID$4);
/* 339 */         if (target == null)
/*     */         {
/* 341 */           return null;
/*     */         }
/* 343 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlID xgetId() {
/* 352 */       synchronized (monitor()) {
/*     */         
/* 354 */         check_orphaned();
/* 355 */         XmlID target = null;
/* 356 */         target = (XmlID)get_store().find_attribute_user(ID$4);
/* 357 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetId() {
/* 366 */       synchronized (monitor()) {
/*     */         
/* 368 */         check_orphaned();
/* 369 */         return (get_store().find_attribute_user(ID$4) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setId(String id) {
/* 378 */       synchronized (monitor()) {
/*     */         
/* 380 */         check_orphaned();
/* 381 */         SimpleValue target = null;
/* 382 */         target = (SimpleValue)get_store().find_attribute_user(ID$4);
/* 383 */         if (target == null)
/*     */         {
/* 385 */           target = (SimpleValue)get_store().add_attribute_user(ID$4);
/*     */         }
/* 387 */         target.setStringValue(id);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetId(XmlID id) {
/* 396 */       synchronized (monitor()) {
/*     */         
/* 398 */         check_orphaned();
/* 399 */         XmlID target = null;
/* 400 */         target = (XmlID)get_store().find_attribute_user(ID$4);
/* 401 */         if (target == null)
/*     */         {
/* 403 */           target = (XmlID)get_store().add_attribute_user(ID$4);
/*     */         }
/* 405 */         target.set((XmlObject)id);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetId() {
/* 414 */       synchronized (monitor()) {
/*     */         
/* 416 */         check_orphaned();
/* 417 */         get_store().remove_attribute(ID$4);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AnnotationDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */