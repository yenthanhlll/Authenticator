/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class VoidClassImpl
/*    */   extends BuiltinClassImpl
/*    */ {
/*    */   private static final String SIMPLE_NAME = "void";
/*    */   
/*    */   public static boolean isVoid(String fd) {
/* 36 */     return fd.equals("void");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VoidClassImpl(ElementContext ctx) {
/* 43 */     super(ctx);
/* 44 */     reallySetSimpleName("void");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isVoidType() {
/* 50 */     return true;
/*    */   } public boolean isAssignableFrom(JClass c) {
/* 52 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\VoidClassImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */