package org.apache.xmlbeans.impl.jam.mutable;

import org.apache.xmlbeans.impl.jam.JMember;

public interface MMember extends MAnnotatedElement, JMember {
  void setModifiers(int paramInt);
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\mutable\MMember.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */