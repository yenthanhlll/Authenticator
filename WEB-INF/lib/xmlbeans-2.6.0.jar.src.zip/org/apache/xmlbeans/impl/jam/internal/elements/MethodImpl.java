/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JParameter;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.DirectJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.QualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.UnqualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodImpl
/*     */   extends InvokableImpl
/*     */   implements MMethod
/*     */ {
/*  46 */   private JClassRef mReturnTypeRef = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodImpl(String simpleName, ClassImpl containingClass) {
/*  52 */     super(containingClass);
/*  53 */     setSimpleName(simpleName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnType(String className) {
/*  60 */     this.mReturnTypeRef = QualifiedJClassRef.create(className, (ClassImpl)getContainingClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUnqualifiedReturnType(String unqualifiedTypeName) {
/*  65 */     this.mReturnTypeRef = UnqualifiedJClassRef.create(unqualifiedTypeName, (ClassImpl)getContainingClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReturnType(JClass c) {
/*  70 */     this.mReturnTypeRef = DirectJClassRef.create(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JClass getReturnType() {
/*  77 */     if (this.mReturnTypeRef == null) {
/*  78 */       return getClassLoader().loadClass("void");
/*     */     }
/*  80 */     return this.mReturnTypeRef.getRefClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFinal() {
/*  85 */     return Modifier.isFinal(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/*  89 */     return Modifier.isStatic(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isAbstract() {
/*  93 */     return Modifier.isAbstract(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isNative() {
/*  97 */     return Modifier.isNative(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isSynchronized() {
/* 101 */     return Modifier.isSynchronized(getModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(MVisitor visitor) {
/* 107 */     visitor.visit(this);
/*     */   } public void accept(JVisitor visitor) {
/* 109 */     visitor.visit((JMethod)this);
/*     */   }
/*     */   public String getQualifiedName() {
/* 112 */     StringWriter sbuf = new StringWriter();
/* 113 */     sbuf.write(Modifier.toString(getModifiers()));
/* 114 */     sbuf.write(32);
/* 115 */     JClass returnJClass = getReturnType();
/* 116 */     if (returnJClass == null) {
/* 117 */       sbuf.write("void ");
/*     */     } else {
/* 119 */       sbuf.write(returnJClass.getQualifiedName());
/* 120 */       sbuf.write(32);
/*     */     } 
/* 122 */     sbuf.write(getSimpleName());
/* 123 */     sbuf.write(40);
/*     */     
/* 125 */     JParameter[] params = getParameters();
/* 126 */     if (params != null && params.length > 0) {
/* 127 */       for (int i = 0; i < params.length; i++) {
/* 128 */         sbuf.write(params[i].getType().getQualifiedName());
/* 129 */         if (i < params.length - 1) sbuf.write(44);
/*     */       
/*     */       } 
/*     */     }
/* 133 */     sbuf.write(41);
/*     */     
/* 135 */     JClass[] thrown = getExceptionTypes();
/* 136 */     if (thrown != null && thrown.length > 0) {
/* 137 */       sbuf.write(" throws ");
/* 138 */       for (int i = 0; i < thrown.length; i++) {
/* 139 */         sbuf.write(thrown[i].getQualifiedName());
/* 140 */         if (i < thrown.length - 1) sbuf.write(44);
/*     */       
/*     */       } 
/*     */     } 
/* 144 */     return sbuf.toString();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\MethodImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */