/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.JElement;
/*     */ import org.apache.xmlbeans.impl.jam.JPackage;
/*     */ import org.apache.xmlbeans.impl.jam.JProperty;
/*     */ import org.apache.xmlbeans.impl.jam.JSourcePosition;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.jam.internal.JamServiceContextImpl;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MSourcePosition;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementImpl
/*     */   implements Comparable, MElement
/*     */ {
/*  39 */   public static final ElementImpl[] NO_NODE = new ElementImpl[0];
/*  40 */   public static final ClassImpl[] NO_CLASS = new ClassImpl[0];
/*  41 */   public static final FieldImpl[] NO_FIELD = new FieldImpl[0];
/*  42 */   public static final ConstructorImpl[] NO_CONSTRUCTOR = new ConstructorImpl[0];
/*  43 */   public static final MethodImpl[] NO_METHOD = new MethodImpl[0];
/*  44 */   public static final ParameterImpl[] NO_PARAMETER = new ParameterImpl[0];
/*  45 */   public static final JPackage[] NO_PACKAGE = new JPackage[0];
/*  46 */   public static final AnnotationImpl[] NO_ANNOTATION = new AnnotationImpl[0];
/*     */   
/*  48 */   public static final CommentImpl[] NO_COMMENT = new CommentImpl[0];
/*  49 */   public static final JProperty[] NO_PROPERTY = new JProperty[0];
/*     */ 
/*     */   
/*     */   private ElementContext mContext;
/*     */   
/*     */   protected String mSimpleName;
/*     */   
/*  56 */   private MSourcePosition mPosition = null;
/*  57 */   private Object mArtifact = null;
/*     */ 
/*     */   
/*     */   private ElementImpl mParent;
/*     */ 
/*     */   
/*     */   protected ElementImpl(ElementImpl parent) {
/*  64 */     if (parent == null) throw new IllegalArgumentException("null ctx"); 
/*  65 */     if (parent == this) {
/*  66 */       throw new IllegalArgumentException("An element cannot be its own parent");
/*     */     }
/*  68 */     JElement check = parent.getParent();
/*  69 */     while (check != null) {
/*  70 */       if (check == this) throw new IllegalArgumentException("cycle detected"); 
/*  71 */       check = check.getParent();
/*     */     } 
/*  73 */     this.mContext = parent.getContext();
/*  74 */     this.mParent = parent;
/*     */   }
/*     */   
/*     */   protected ElementImpl(ElementContext ctx) {
/*  78 */     if (ctx == null) throw new IllegalArgumentException("null ctx"); 
/*  79 */     this.mContext = ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final JElement getParent() {
/*  85 */     return (JElement)this.mParent;
/*     */   } public String getSimpleName() {
/*  87 */     return this.mSimpleName;
/*     */   } public JSourcePosition getSourcePosition() {
/*  89 */     return (JSourcePosition)this.mPosition;
/*     */   } public Object getArtifact() {
/*  91 */     return this.mArtifact;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSimpleName(String name) {
/*  97 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  98 */     this.mSimpleName = name.trim();
/*     */   }
/*     */   
/*     */   public MSourcePosition createSourcePosition() {
/* 102 */     return this.mPosition = new SourcePositionImpl();
/*     */   }
/*     */   
/*     */   public void removeSourcePosition() {
/* 106 */     this.mPosition = null;
/*     */   }
/*     */   
/*     */   public MSourcePosition getMutableSourcePosition() {
/* 110 */     return this.mPosition;
/*     */   }
/*     */   
/*     */   public void setArtifact(Object artifact) {
/* 114 */     if (artifact == null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (this.mArtifact != null) {
/* 120 */       throw new IllegalStateException("artifact already set");
/*     */     }
/* 122 */     this.mArtifact = artifact;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JamClassLoader getClassLoader() {
/* 129 */     return this.mContext.getClassLoader();
/*     */   }
/*     */   
/*     */   public static String defaultName(int count) {
/* 133 */     return "unnamed_" + count;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 137 */     if (this == o) return true; 
/* 138 */     if (!(o instanceof ElementImpl)) return false; 
/* 139 */     ElementImpl eElement = (ElementImpl)o;
/* 140 */     String qn = getQualifiedName();
/* 141 */     if (qn == null) return false; 
/* 142 */     String oqn = eElement.getQualifiedName();
/* 143 */     if (oqn == null) return false; 
/* 144 */     return qn.equals(oqn);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 148 */     String qn = getQualifiedName();
/* 149 */     return (qn == null) ? 0 : qn.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementContext getContext() {
/* 155 */     return this.mContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 161 */     return getQualifiedName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JamLogger getLogger() {
/* 168 */     return ((JamServiceContextImpl)this.mContext).getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object o) {
/* 175 */     if (!(o instanceof JElement)) {
/* 176 */       return -1;
/*     */     }
/* 178 */     return getQualifiedName().compareTo(((JElement)o).getQualifiedName());
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\ElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */