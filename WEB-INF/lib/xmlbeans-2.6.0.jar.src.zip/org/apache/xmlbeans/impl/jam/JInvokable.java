package org.apache.xmlbeans.impl.jam;

public interface JInvokable extends JMember {
  JParameter[] getParameters();
  
  JClass[] getExceptionTypes();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\JInvokable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */