/*    */ package org.apache.xmlbeans.impl.jam.visitor;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JMethod;
/*    */ import org.apache.xmlbeans.impl.jam.JProperty;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.PropertyImpl;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyInitializer
/*    */   extends MVisitor
/*    */ {
/*    */   public void visit(MClass clazz) {
/* 38 */     addProperties(clazz, true);
/* 39 */     addProperties(clazz, false);
/*    */   }
/*    */   
/*    */   private void addProperties(MClass clazz, boolean declared) {
/* 43 */     JMethod[] methods = declared ? clazz.getDeclaredMethods() : clazz.getMethods();
/*    */     
/* 45 */     Map name2prop = new HashMap();
/* 46 */     for (int i = 0; i < methods.length; i++) {
/* 47 */       String name = methods[i].getSimpleName();
/*    */ 
/*    */ 
/*    */       
/* 51 */       if ((name.startsWith("get") && name.length() > 3) || (name.startsWith("is") && name.length() > 2)) {
/*    */         
/* 53 */         JClass typ = methods[i].getReturnType();
/*    */ 
/*    */         
/* 56 */         if (typ == null || (
/* 57 */           methods[i].getParameters()).length > 0)
/* 58 */           continue;  if (name.startsWith("get")) {
/* 59 */           name = name.substring(3);
/*    */         } else {
/* 61 */           name = name.substring(2);
/*    */         } 
/* 63 */         JProperty prop = (JProperty)name2prop.get(name);
/* 64 */         if (prop == null) {
/* 65 */           prop = declared ? clazz.addNewDeclaredProperty(name, methods[i], null) : clazz.addNewProperty(name, methods[i], null);
/*    */           
/* 67 */           name2prop.put(name, prop);
/*    */         }
/* 69 */         else if (typ.equals(prop.getType())) {
/* 70 */           ((PropertyImpl)prop).setGetter(methods[i]);
/*    */         } 
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 78 */       if (name.startsWith("set") && name.length() > 3 && (
/* 79 */         methods[i].getParameters()).length == 1) {
/* 80 */         JClass type = methods[i].getParameters()[0].getType();
/* 81 */         name = name.substring(3);
/* 82 */         JProperty prop = (JProperty)name2prop.get(name);
/* 83 */         if (prop == null) {
/* 84 */           prop = declared ? clazz.addNewDeclaredProperty(name, null, methods[i]) : clazz.addNewProperty(name, null, methods[i]);
/*    */           
/* 86 */           name2prop.put(name, prop);
/*    */         }
/* 88 */         else if (type.equals(prop.getType())) {
/*    */           
/* 90 */           ((PropertyImpl)prop).setSetter(methods[i]);
/*    */         } 
/*    */       } 
/*    */       continue;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\visitor\PropertyInitializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */