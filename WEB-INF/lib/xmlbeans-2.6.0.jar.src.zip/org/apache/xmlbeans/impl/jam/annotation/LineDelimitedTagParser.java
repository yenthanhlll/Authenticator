/*    */ package org.apache.xmlbeans.impl.jam.annotation;
/*    */ 
/*    */ import com.sun.javadoc.Tag;
/*    */ import java.io.StringWriter;
/*    */ import java.util.StringTokenizer;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineDelimitedTagParser
/*    */   extends JavadocTagParser
/*    */ {
/*    */   private static final String VALUE_QUOTE = "\"";
/*    */   private static final String LINE_DELIMS = "\n\f\r";
/*    */   
/*    */   public void parse(MAnnotatedElement target, Tag tag) {
/* 42 */     if (target == null) throw new IllegalArgumentException("null tagText"); 
/* 43 */     if (tag == null) throw new IllegalArgumentException("null tagName"); 
/* 44 */     MAnnotation[] anns = createAnnotations(target, tag);
/* 45 */     String tagText = tag.text();
/* 46 */     StringTokenizer st = new StringTokenizer(tagText, "\n\f\r");
/* 47 */     while (st.hasMoreTokens()) {
/* 48 */       String pair = st.nextToken();
/* 49 */       int eq = pair.indexOf('=');
/* 50 */       if (eq <= 0)
/* 51 */         continue;  String name = pair.substring(0, eq).trim();
/* 52 */       if (eq < pair.length() - 1) {
/* 53 */         String value = pair.substring(eq + 1).trim();
/* 54 */         if (value.startsWith("\"")) {
/* 55 */           value = parseQuotedValue(value.substring(1), st);
/*    */         }
/* 57 */         setValue(anns, name, value);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private String parseQuotedValue(String line, StringTokenizer st) {
/*    */     int endQuote;
/* 66 */     StringWriter out = new StringWriter();
/*    */     while (true) {
/* 68 */       endQuote = line.indexOf("\"");
/* 69 */       if (endQuote == -1) {
/* 70 */         out.write(line);
/* 71 */         if (!st.hasMoreTokens()) return out.toString(); 
/* 72 */         out.write(10);
/* 73 */         line = st.nextToken().trim(); continue;
/*    */       }  break;
/*    */     } 
/* 76 */     out.write(line.substring(0, endQuote).trim());
/* 77 */     return out.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\annotation\LineDelimitedTagParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */