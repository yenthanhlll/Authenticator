/*     */ package org.apache.xmlbeans.impl.jam.internal.classrefs;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnqualifiedJClassRef
/*     */   implements JClassRef
/*     */ {
/*     */   private static final boolean VERBOSE = false;
/*     */   private static final String PREFIX = "[UnqualifiedJClassRef]";
/*     */   private String mUnqualifiedClassname;
/*  37 */   private String mQualifiedClassname = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JClassRefContext mContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JClassRef create(String qualifiedClassname, JClassRefContext ctx) {
/*  48 */     throw new IllegalStateException("Unqualified names currently disabled.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UnqualifiedJClassRef(String ucname, JClassRefContext ctx) {
/*  58 */     if (ctx == null) throw new IllegalArgumentException("null ctx"); 
/*  59 */     if (ucname == null) throw new IllegalArgumentException("null ucname"); 
/*  60 */     this.mContext = ctx;
/*  61 */     this.mUnqualifiedClassname = ucname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JClass getRefClass() {
/*  71 */     return this.mContext.getClassLoader().loadClass(getQualifiedName());
/*     */   }
/*     */   public String getQualifiedName() {
/*     */     String candidateName;
/*  75 */     if (this.mQualifiedClassname != null) return this.mQualifiedClassname;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     int arrayDimensions = 0;
/*  81 */     int bracket = this.mUnqualifiedClassname.indexOf('[');
/*  82 */     if (bracket != -1) {
/*  83 */       candidateName = this.mUnqualifiedClassname.substring(0, bracket);
/*     */       do {
/*  85 */         arrayDimensions++;
/*  86 */         bracket = this.mUnqualifiedClassname.indexOf('[', bracket + 1);
/*  87 */       } while (bracket != -1);
/*     */     } else {
/*  89 */       candidateName = this.mUnqualifiedClassname;
/*     */     } 
/*     */     
/*  92 */     String name = qualifyName(candidateName);
/*  93 */     if (name == null) {
/*  94 */       throw new IllegalStateException("unable to handle unqualified java type reference '" + candidateName + " [" + this.mUnqualifiedClassname + "]'. " + "This is still partially NYI.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (arrayDimensions > 0) {
/* 102 */       StringWriter out = new StringWriter();
/* 103 */       for (int i = 0; i < arrayDimensions; ) { out.write(91); i++; }
/* 104 */        out.write(76);
/* 105 */       out.write(name);
/* 106 */       out.write(59);
/*     */       
/* 108 */       this.mQualifiedClassname = out.toString();
/*     */     } else {
/* 110 */       this.mQualifiedClassname = name;
/*     */     } 
/* 112 */     return this.mQualifiedClassname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String qualifyName(String ucname) {
/* 119 */     String out = null;
/* 120 */     if ((out = checkExplicitImport(ucname)) != null) return out; 
/* 121 */     if ((out = checkJavaLang(ucname)) != null) return out; 
/* 122 */     if ((out = checkSamePackage(ucname)) != null) return out; 
/* 123 */     if ((out = checkAlreadyQualified(ucname)) != null) return out; 
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String checkSamePackage(String ucname) {
/* 131 */     String name = this.mContext.getPackageName() + "." + ucname;
/* 132 */     JClass clazz = this.mContext.getClassLoader().loadClass(name);
/*     */ 
/*     */     
/* 135 */     return clazz.isUnresolvedType() ? null : clazz.getQualifiedName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String checkJavaLang(String ucname) {
/* 142 */     String name = "java.lang." + ucname;
/* 143 */     JClass clazz = this.mContext.getClassLoader().loadClass(name);
/*     */ 
/*     */     
/* 146 */     return clazz.isUnresolvedType() ? null : clazz.getQualifiedName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String checkAlreadyQualified(String ucname) {
/* 153 */     JClass clazz = this.mContext.getClassLoader().loadClass(ucname);
/*     */     
/* 155 */     return clazz.isUnresolvedType() ? null : clazz.getQualifiedName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String checkExplicitImport(String ucname) {
/* 164 */     String[] imports = this.mContext.getImportSpecs();
/*     */ 
/*     */     
/* 167 */     for (int i = 0; i < imports.length; i++) {
/*     */       
/* 169 */       String last = lastSegment(imports[i]);
/*     */ 
/*     */       
/* 172 */       if (last.equals(ucname)) return imports[i]; 
/*     */     } 
/* 174 */     return null;
/*     */   }
/*     */   
/*     */   private static String lastSegment(String s) {
/* 178 */     int lastDot = s.lastIndexOf(".");
/* 179 */     if (lastDot == -1) return s; 
/* 180 */     return s.substring(lastDot + 1);
/*     */   }
/*     */   
/*     */   private static String firstSegment(String s) {
/* 184 */     int lastDot = s.indexOf(".");
/* 185 */     if (lastDot == -1) return s; 
/* 186 */     return s.substring(0, lastDot);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\classrefs\UnqualifiedJClassRef.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */