/*     */ package org.apache.xmlbeans.impl.jam.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectoryScanner
/*     */ {
/*     */   private boolean mCaseSensitive = true;
/*     */   private File mRoot;
/*     */   private JamLogger mLogger;
/*  39 */   private List mIncludeList = null;
/*  40 */   private List mExcludeList = null;
/*     */   private String[] mIncludes;
/*     */   private String[] mExcludes;
/*     */   private Vector mFilesIncluded;
/*     */   private Vector mDirsIncluded;
/*     */   private boolean mIsDirty = false;
/*  46 */   private String[] mIncludedFilesCache = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectoryScanner(File dirToScan, JamLogger logger) {
/*  53 */     if (logger == null) throw new IllegalArgumentException("null logger"); 
/*  54 */     this.mLogger = logger;
/*  55 */     this.mRoot = dirToScan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void include(String pattern) {
/*  62 */     if (this.mIncludeList == null) this.mIncludeList = new ArrayList(); 
/*  63 */     this.mIncludeList.add(pattern);
/*  64 */     this.mIsDirty = true;
/*     */   }
/*     */   
/*     */   public void exclude(String pattern) {
/*  68 */     if (this.mExcludeList == null) this.mExcludeList = new ArrayList(); 
/*  69 */     this.mExcludeList.add(pattern);
/*  70 */     this.mIsDirty = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getIncludedFiles() throws IOException {
/*  79 */     if (!this.mIsDirty && this.mIncludedFilesCache != null) {
/*  80 */       return this.mIncludedFilesCache;
/*     */     }
/*  82 */     if (this.mIncludeList != null) {
/*  83 */       String[] inc = new String[this.mIncludeList.size()];
/*  84 */       this.mIncludeList.toArray((Object[])inc);
/*  85 */       setIncludes(inc);
/*     */     } else {
/*  87 */       setIncludes(null);
/*     */     } 
/*  89 */     if (this.mExcludeList != null) {
/*  90 */       String[] exc = new String[this.mExcludeList.size()];
/*  91 */       this.mExcludeList.toArray((Object[])exc);
/*  92 */       setExcludes(exc);
/*     */     } else {
/*  94 */       setExcludes(null);
/*     */     } 
/*  96 */     scan();
/*  97 */     this.mIncludedFilesCache = new String[this.mFilesIncluded.size()];
/*  98 */     this.mFilesIncluded.copyInto((Object[])this.mIncludedFilesCache);
/*  99 */     return this.mIncludedFilesCache;
/*     */   }
/*     */   
/*     */   public void setDirty() {
/* 103 */     this.mIsDirty = true;
/*     */   }
/*     */   
/*     */   public File getRoot() {
/* 107 */     return this.mRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setIncludes(String[] includes) {
/* 127 */     if (includes == null) {
/* 128 */       this.mIncludes = null;
/*     */     } else {
/* 130 */       this.mIncludes = new String[includes.length];
/* 131 */       for (int i = 0; i < includes.length; i++) {
/*     */         
/* 133 */         String pattern = includes[i].replace('/', File.separatorChar).replace('\\', File.separatorChar);
/*     */         
/* 135 */         if (pattern.endsWith(File.separator)) {
/* 136 */           pattern = pattern + "**";
/*     */         }
/* 138 */         this.mIncludes[i] = pattern;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setExcludes(String[] excludes) {
/* 157 */     if (excludes == null) {
/* 158 */       this.mExcludes = null;
/*     */     } else {
/* 160 */       this.mExcludes = new String[excludes.length];
/* 161 */       for (int i = 0; i < excludes.length; i++) {
/*     */         
/* 163 */         String pattern = excludes[i].replace('/', File.separatorChar).replace('\\', File.separatorChar);
/*     */         
/* 165 */         if (pattern.endsWith(File.separator)) {
/* 166 */           pattern = pattern + "**";
/*     */         }
/* 168 */         this.mExcludes[i] = pattern;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scan() throws IllegalStateException, IOException {
/* 184 */     if (this.mIncludes == null) {
/*     */       
/* 186 */       this.mIncludes = new String[1];
/* 187 */       this.mIncludes[0] = "**";
/*     */     } 
/* 189 */     if (this.mExcludes == null) {
/* 190 */       this.mExcludes = new String[0];
/*     */     }
/* 192 */     this.mFilesIncluded = new Vector();
/* 193 */     this.mDirsIncluded = new Vector();
/* 194 */     if (isIncluded("") && 
/* 195 */       !isExcluded("")) {
/* 196 */       this.mDirsIncluded.addElement("");
/*     */     }
/*     */     
/* 199 */     scandir(this.mRoot, "", true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scandir(File dir, String vpath, boolean fast) throws IOException {
/* 219 */     if (this.mLogger.isVerbose(this)) {
/* 220 */       this.mLogger.verbose("[DirectoryScanner] scanning dir " + dir + " for '" + vpath + "'");
/*     */     }
/* 222 */     String[] newfiles = dir.list();
/* 223 */     if (newfiles == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       throw new IOException("IO error scanning directory " + dir.getAbsolutePath());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     for (int i = 0; i < newfiles.length; i++) {
/* 262 */       String name = vpath + newfiles[i];
/* 263 */       File file = new File(dir, newfiles[i]);
/* 264 */       if (file.isDirectory()) {
/* 265 */         if (isIncluded(name) && !isExcluded(name)) {
/* 266 */           this.mDirsIncluded.addElement(name);
/* 267 */           if (this.mLogger.isVerbose(this)) this.mLogger.verbose("...including dir " + name); 
/* 268 */           scandir(file, name + File.separator, fast);
/*     */         }
/* 270 */         else if (couldHoldIncluded(name)) {
/* 271 */           scandir(file, name + File.separator, fast);
/*     */         }
/*     */       
/* 274 */       } else if (file.isFile() && 
/* 275 */         isIncluded(name)) {
/* 276 */         if (!isExcluded(name)) {
/* 277 */           this.mFilesIncluded.addElement(name);
/* 278 */           if (this.mLogger.isVerbose(this)) {
/* 279 */             this.mLogger.verbose("...including " + name + " under '" + dir);
/*     */           }
/*     */         }
/* 282 */         else if (this.mLogger.isVerbose(this)) {
/* 283 */           this.mLogger.verbose("...EXCLUDING " + name + " under '" + dir);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isIncluded(String name) {
/* 300 */     for (int i = 0; i < this.mIncludes.length; i++) {
/* 301 */       if (matchPath(this.mIncludes[i], name, this.mCaseSensitive)) {
/* 302 */         return true;
/*     */       }
/*     */     } 
/* 305 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean couldHoldIncluded(String name) {
/* 317 */     for (int i = 0; i < this.mIncludes.length; i++) {
/* 318 */       if (matchPatternStart(this.mIncludes[i], name, this.mCaseSensitive)) {
/* 319 */         return true;
/*     */       }
/*     */     } 
/* 322 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isExcluded(String name) {
/* 334 */     for (int i = 0; i < this.mExcludes.length; i++) {
/* 335 */       if (matchPath(this.mExcludes[i], name, this.mCaseSensitive)) {
/* 336 */         return true;
/*     */       }
/*     */     } 
/* 339 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchPatternStart(String pattern, String str, boolean mCaseSensitive) {
/* 407 */     if (str.startsWith(File.separator) != pattern.startsWith(File.separator))
/*     */     {
/* 409 */       return false;
/*     */     }
/* 411 */     Vector patDirs = tokenizePath(pattern);
/* 412 */     Vector strDirs = tokenizePath(str);
/* 413 */     int patIdxStart = 0;
/* 414 */     int patIdxEnd = patDirs.size() - 1;
/* 415 */     int strIdxStart = 0;
/* 416 */     int strIdxEnd = strDirs.size() - 1;
/*     */     
/* 418 */     while (patIdxStart <= patIdxEnd && strIdxStart <= strIdxEnd) {
/* 419 */       String patDir = patDirs.elementAt(patIdxStart);
/* 420 */       if (patDir.equals("**")) {
/*     */         break;
/*     */       }
/* 423 */       if (!match(patDir, strDirs.elementAt(strIdxStart), mCaseSensitive))
/*     */       {
/* 425 */         return false;
/*     */       }
/* 427 */       patIdxStart++;
/* 428 */       strIdxStart++;
/*     */     } 
/* 430 */     if (strIdxStart > strIdxEnd)
/*     */     {
/* 432 */       return true; } 
/* 433 */     if (patIdxStart > patIdxEnd)
/*     */     {
/* 435 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 439 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchPath(String pattern, String str, boolean mCaseSensitive) {
/* 478 */     if (str.startsWith(File.separator) != pattern.startsWith(File.separator))
/*     */     {
/* 480 */       return false;
/*     */     }
/* 482 */     Vector patDirs = tokenizePath(pattern);
/* 483 */     Vector strDirs = tokenizePath(str);
/* 484 */     int patIdxStart = 0;
/* 485 */     int patIdxEnd = patDirs.size() - 1;
/* 486 */     int strIdxStart = 0;
/* 487 */     int strIdxEnd = strDirs.size() - 1;
/*     */     
/* 489 */     while (patIdxStart <= patIdxEnd && strIdxStart <= strIdxEnd) {
/* 490 */       String patDir = patDirs.elementAt(patIdxStart);
/* 491 */       if (patDir.equals("**")) {
/*     */         break;
/*     */       }
/* 494 */       if (!match(patDir, strDirs.elementAt(strIdxStart), mCaseSensitive))
/*     */       {
/* 496 */         return false;
/*     */       }
/* 498 */       patIdxStart++;
/* 499 */       strIdxStart++;
/*     */     } 
/* 501 */     if (strIdxStart > strIdxEnd) {
/*     */       
/* 503 */       for (int j = patIdxStart; j <= patIdxEnd; j++) {
/* 504 */         if (!patDirs.elementAt(j).equals("**")) {
/* 505 */           return false;
/*     */         }
/*     */       } 
/* 508 */       return true;
/*     */     } 
/* 510 */     if (patIdxStart > patIdxEnd)
/*     */     {
/* 512 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 516 */     while (patIdxStart <= patIdxEnd && strIdxStart <= strIdxEnd) {
/* 517 */       String patDir = patDirs.elementAt(patIdxEnd);
/* 518 */       if (patDir.equals("**")) {
/*     */         break;
/*     */       }
/* 521 */       if (!match(patDir, strDirs.elementAt(strIdxEnd), mCaseSensitive))
/*     */       {
/* 523 */         return false;
/*     */       }
/* 525 */       patIdxEnd--;
/* 526 */       strIdxEnd--;
/*     */     } 
/* 528 */     if (strIdxStart > strIdxEnd) {
/*     */       
/* 530 */       for (int j = patIdxStart; j <= patIdxEnd; j++) {
/* 531 */         if (!patDirs.elementAt(j).equals("**")) {
/* 532 */           return false;
/*     */         }
/*     */       } 
/* 535 */       return true;
/*     */     } 
/* 537 */     while (patIdxStart != patIdxEnd && strIdxStart <= strIdxEnd) {
/* 538 */       int patIdxTmp = -1;
/* 539 */       for (int j = patIdxStart + 1; j <= patIdxEnd; j++) {
/* 540 */         if (patDirs.elementAt(j).equals("**")) {
/* 541 */           patIdxTmp = j;
/*     */           break;
/*     */         } 
/*     */       } 
/* 545 */       if (patIdxTmp == patIdxStart + 1) {
/*     */         
/* 547 */         patIdxStart++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 552 */       int patLength = patIdxTmp - patIdxStart - 1;
/* 553 */       int strLength = strIdxEnd - strIdxStart + 1;
/* 554 */       int foundIdx = -1;
/*     */       
/* 556 */       for (int k = 0; k <= strLength - patLength; ) {
/* 557 */         for (int m = 0; m < patLength; m++) {
/* 558 */           String subPat = patDirs.elementAt(patIdxStart + m + 1);
/* 559 */           String subStr = strDirs.elementAt(strIdxStart + k + m);
/* 560 */           if (!match(subPat, subStr, mCaseSensitive)) {
/*     */             k++; continue;
/*     */           } 
/*     */         } 
/* 564 */         foundIdx = strIdxStart + k;
/*     */       } 
/*     */       
/* 567 */       if (foundIdx == -1) {
/* 568 */         return false;
/*     */       }
/* 570 */       patIdxStart = patIdxTmp;
/* 571 */       strIdxStart = foundIdx + patLength;
/*     */     } 
/* 573 */     for (int i = patIdxStart; i <= patIdxEnd; i++) {
/* 574 */       if (!patDirs.elementAt(i).equals("**")) {
/* 575 */         return false;
/*     */       }
/*     */     } 
/* 578 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean match(String pattern, String str, boolean mCaseSensitive) {
/* 600 */     char[] patArr = pattern.toCharArray();
/* 601 */     char[] strArr = str.toCharArray();
/* 602 */     int patIdxStart = 0;
/* 603 */     int patIdxEnd = patArr.length - 1;
/* 604 */     int strIdxStart = 0;
/* 605 */     int strIdxEnd = strArr.length - 1;
/*     */     
/* 607 */     boolean containsStar = false; int i;
/* 608 */     for (i = 0; i < patArr.length; i++) {
/* 609 */       if (patArr[i] == '*') {
/* 610 */         containsStar = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 614 */     if (!containsStar) {
/*     */       
/* 616 */       if (patIdxEnd != strIdxEnd) {
/* 617 */         return false;
/*     */       }
/* 619 */       for (i = 0; i <= patIdxEnd; i++) {
/* 620 */         char c = patArr[i];
/* 621 */         if (c != '?') {
/* 622 */           if (mCaseSensitive && c != strArr[i]) {
/* 623 */             return false;
/*     */           }
/* 625 */           if (!mCaseSensitive && Character.toUpperCase(c) != Character.toUpperCase(strArr[i]))
/*     */           {
/* 627 */             return false;
/*     */           }
/*     */         } 
/*     */       } 
/* 631 */       return true;
/*     */     } 
/* 633 */     if (patIdxEnd == 0) {
/* 634 */       return true;
/*     */     }
/*     */     char ch;
/* 637 */     while ((ch = patArr[patIdxStart]) != '*' && strIdxStart <= strIdxEnd) {
/* 638 */       if (ch != '?') {
/* 639 */         if (mCaseSensitive && ch != strArr[strIdxStart]) {
/* 640 */           return false;
/*     */         }
/* 642 */         if (!mCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[strIdxStart]))
/*     */         {
/* 644 */           return false;
/*     */         }
/*     */       } 
/* 647 */       patIdxStart++;
/* 648 */       strIdxStart++;
/*     */     } 
/* 650 */     if (strIdxStart > strIdxEnd) {
/*     */ 
/*     */       
/* 653 */       for (i = patIdxStart; i <= patIdxEnd; i++) {
/* 654 */         if (patArr[i] != '*') {
/* 655 */           return false;
/*     */         }
/*     */       } 
/* 658 */       return true;
/*     */     } 
/*     */     
/* 661 */     while ((ch = patArr[patIdxEnd]) != '*' && strIdxStart <= strIdxEnd) {
/* 662 */       if (ch != '?') {
/* 663 */         if (mCaseSensitive && ch != strArr[strIdxEnd]) {
/* 664 */           return false;
/*     */         }
/* 666 */         if (!mCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[strIdxEnd]))
/*     */         {
/* 668 */           return false;
/*     */         }
/*     */       } 
/* 671 */       patIdxEnd--;
/* 672 */       strIdxEnd--;
/*     */     } 
/* 674 */     if (strIdxStart > strIdxEnd) {
/*     */ 
/*     */       
/* 677 */       for (i = patIdxStart; i <= patIdxEnd; i++) {
/* 678 */         if (patArr[i] != '*') {
/* 679 */           return false;
/*     */         }
/*     */       } 
/* 682 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 686 */     while (patIdxStart != patIdxEnd && strIdxStart <= strIdxEnd) {
/* 687 */       int patIdxTmp = -1;
/* 688 */       for (int j = patIdxStart + 1; j <= patIdxEnd; j++) {
/* 689 */         if (patArr[j] == '*') {
/* 690 */           patIdxTmp = j;
/*     */           break;
/*     */         } 
/*     */       } 
/* 694 */       if (patIdxTmp == patIdxStart + 1) {
/*     */         
/* 696 */         patIdxStart++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 701 */       int patLength = patIdxTmp - patIdxStart - 1;
/* 702 */       int strLength = strIdxEnd - strIdxStart + 1;
/* 703 */       int foundIdx = -1;
/*     */       int k;
/* 705 */       label117: for (k = 0; k <= strLength - patLength; ) {
/* 706 */         for (int m = 0; m < patLength; m++) {
/* 707 */           ch = patArr[patIdxStart + m + 1];
/* 708 */           if (ch != '?') {
/* 709 */             if (mCaseSensitive && ch != strArr[strIdxStart + k + m]) {
/*     */               k++; continue;
/*     */             } 
/* 712 */             if (!mCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[strIdxStart + k + m])) {
/*     */               continue label117;
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 718 */         foundIdx = strIdxStart + k;
/*     */       } 
/*     */       
/* 721 */       if (foundIdx == -1) {
/* 722 */         return false;
/*     */       }
/* 724 */       patIdxStart = patIdxTmp;
/* 725 */       strIdxStart = foundIdx + patLength;
/*     */     } 
/*     */ 
/*     */     
/* 729 */     for (i = patIdxStart; i <= patIdxEnd; i++) {
/* 730 */       if (patArr[i] != '*') {
/* 731 */         return false;
/*     */       }
/*     */     } 
/* 734 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Vector tokenizePath(String path) {
/* 746 */     Vector ret = new Vector();
/* 747 */     StringTokenizer st = new StringTokenizer(path, File.separator);
/* 748 */     while (st.hasMoreTokens()) {
/* 749 */       ret.addElement(st.nextToken());
/*     */     }
/* 751 */     return ret;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\DirectoryScanner.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */