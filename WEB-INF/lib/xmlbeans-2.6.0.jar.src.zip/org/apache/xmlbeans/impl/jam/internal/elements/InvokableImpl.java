/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JParameter;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.DirectJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.QualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.UnqualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MInvokable;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InvokableImpl
/*     */   extends MemberImpl
/*     */   implements MInvokable
/*     */ {
/*  40 */   private List mExceptionClassRefs = null;
/*  41 */   private List mParameters = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InvokableImpl(ClassImpl containingClass) {
/*  47 */     super(containingClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addException(JClass exceptionClass) {
/*  54 */     if (exceptionClass == null) {
/*  55 */       throw new IllegalArgumentException("null exception class");
/*     */     }
/*  57 */     if (this.mExceptionClassRefs == null) this.mExceptionClassRefs = new ArrayList(); 
/*  58 */     this.mExceptionClassRefs.add(DirectJClassRef.create(exceptionClass));
/*     */   }
/*     */   
/*     */   public void addException(String qcname) {
/*  62 */     if (qcname == null) throw new IllegalArgumentException("null qcname"); 
/*  63 */     if (this.mExceptionClassRefs == null) this.mExceptionClassRefs = new ArrayList(); 
/*  64 */     this.mExceptionClassRefs.add(QualifiedJClassRef.create(qcname, (ClassImpl)getContainingClass()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addUnqualifiedException(String ucname) {
/*  69 */     if (ucname == null) throw new IllegalArgumentException("null qcname"); 
/*  70 */     if (this.mExceptionClassRefs == null) this.mExceptionClassRefs = new ArrayList(); 
/*  71 */     this.mExceptionClassRefs.add(UnqualifiedJClassRef.create(ucname, (ClassImpl)getContainingClass()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeException(String exceptionClassName) {
/*  76 */     if (exceptionClassName == null) {
/*  77 */       throw new IllegalArgumentException("null classname");
/*     */     }
/*  79 */     if (this.mExceptionClassRefs != null) {
/*  80 */       this.mExceptionClassRefs.remove(exceptionClassName);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeException(JClass exceptionClass) {
/*  85 */     removeException(exceptionClass.getQualifiedName());
/*     */   }
/*     */   
/*     */   public MParameter addNewParameter() {
/*  89 */     if (this.mParameters == null) this.mParameters = new ArrayList(); 
/*  90 */     MParameter param = new ParameterImpl(defaultName(this.mParameters.size()), this, "java.lang.Object");
/*     */     
/*  92 */     this.mParameters.add(param);
/*  93 */     return param;
/*     */   }
/*     */   
/*     */   public void removeParameter(MParameter parameter) {
/*  97 */     if (this.mParameters != null) this.mParameters.remove(parameter); 
/*     */   }
/*     */   
/*     */   public MParameter[] getMutableParameters() {
/* 101 */     if (this.mParameters == null || this.mParameters.size() == 0) {
/* 102 */       return new MParameter[0];
/*     */     }
/* 104 */     MParameter[] out = new MParameter[this.mParameters.size()];
/* 105 */     this.mParameters.toArray((Object[])out);
/* 106 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JParameter[] getParameters() {
/* 114 */     return (JParameter[])getMutableParameters();
/*     */   }
/*     */   
/*     */   public JClass[] getExceptionTypes() {
/* 118 */     if (this.mExceptionClassRefs == null || this.mExceptionClassRefs.size() == 0) {
/* 119 */       return new JClass[0];
/*     */     }
/* 121 */     JClass[] out = new JClass[this.mExceptionClassRefs.size()];
/* 122 */     for (int i = 0; i < out.length; i++) {
/* 123 */       out[i] = ((JClassRef)this.mExceptionClassRefs.get(i)).getRefClass();
/*     */     }
/* 125 */     return out;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getQualifiedName() {
/* 130 */     StringWriter out = new StringWriter();
/* 131 */     out.write(getContainingClass().getQualifiedName());
/* 132 */     out.write(46);
/* 133 */     out.write(getSimpleName());
/* 134 */     out.write(40);
/* 135 */     JParameter[] params = getParameters();
/* 136 */     for (int i = 0; i < params.length; i++) {
/* 137 */       out.write(params[i].getType().getQualifiedName());
/* 138 */       if (i < params.length - 1) out.write(", "); 
/*     */     } 
/* 140 */     out.write(41);
/* 141 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnqualifiedThrows(List classnames) {
/* 149 */     if (classnames == null || classnames.size() == 0) {
/* 150 */       this.mExceptionClassRefs = null;
/*     */       return;
/*     */     } 
/* 153 */     this.mExceptionClassRefs = new ArrayList(classnames.size());
/* 154 */     for (int i = 0; i < classnames.size(); i++)
/* 155 */       this.mExceptionClassRefs.add(UnqualifiedJClassRef.create(classnames.get(i), (ClassImpl)getContainingClass())); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\InvokableImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */