/*    */ package org.apache.xmlbeans.impl.jam.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.AnnotationValueImpl;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAnnotationProxy
/*    */   extends AnnotationProxy
/*    */ {
/* 42 */   private List mValues = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JAnnotationValue[] getValues() {
/* 53 */     JAnnotationValue[] out = new JAnnotationValue[this.mValues.size()];
/* 54 */     this.mValues.toArray((Object[])out);
/* 55 */     return out;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(String name, Object value, JClass type) {
/* 67 */     if (name == null) throw new IllegalArgumentException("null name"); 
/* 68 */     if (type == null) throw new IllegalArgumentException("null type"); 
/* 69 */     if (value == null) throw new IllegalArgumentException("null value"); 
/* 70 */     name = name.trim();
/* 71 */     this.mValues.add(new AnnotationValueImpl((ElementContext)getLogger(), name, value, type));
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\annotation\DefaultAnnotationProxy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */