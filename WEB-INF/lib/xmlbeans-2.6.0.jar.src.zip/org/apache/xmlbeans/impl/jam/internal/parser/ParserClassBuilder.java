/*     */ package org.apache.xmlbeans.impl.jam.internal.parser;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassPopulator;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamServiceContext;
/*     */ import org.apache.xmlbeans.impl.jam.provider.ResourcePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserClassBuilder
/*     */   extends JamClassBuilder
/*     */   implements JamClassPopulator
/*     */ {
/*     */   private static final boolean VERBOSE = false;
/*     */   private ResourcePath mSourcePath;
/*     */   private boolean mVerbose = false;
/*  55 */   private PrintWriter mOut = new PrintWriter(System.out);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserClassBuilder(JamServiceContext jsp) {
/*  63 */     this.mSourcePath = jsp.getInputSourcepath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MClass build(String pkg, String name) {
/*  71 */     if (pkg == null) throw new IllegalArgumentException("null pkg"); 
/*  72 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  73 */     String filespec = pkg.replace('.', File.separatorChar) + File.separatorChar + name + ".java";
/*     */     
/*  75 */     if (name.indexOf(".") != -1) {
/*  76 */       throw new IllegalArgumentException("inner classes are NYI at the moment");
/*     */     }
/*  78 */     InputStream in = this.mSourcePath.findInPath(filespec);
/*  79 */     if (in == null) {
/*  80 */       if (this.mVerbose) {
/*  81 */         this.mOut.println("[ParserClassBuilder] could not find " + filespec);
/*     */       }
/*  83 */       return null;
/*     */     } 
/*  85 */     if (this.mVerbose) {
/*  86 */       this.mOut.println("[ParserClassBuilder] loading class " + pkg + "  " + name);
/*  87 */       this.mOut.println("[ParserClassBuilder] from file " + filespec);
/*     */     } 
/*     */     
/*  90 */     Reader rin = new InputStreamReader(in);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 104 */       rin.close();
/* 105 */     } catch (IOException ohwell) {
/* 106 */       ohwell.printStackTrace();
/*     */     } 
/*     */     
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populate(MClass m) {
/* 116 */     throw new IllegalStateException("NYI");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MClass[] parse(Reader in, JamClassLoader loader) throws Exception {
/* 123 */     if (in == null) throw new IllegalArgumentException("null in"); 
/* 124 */     if (loader == null) throw new IllegalArgumentException("null loader");
/*     */ 
/*     */     
/* 127 */     throw new IllegalStateException("temporarily NI");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ParserClassBuilder() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] files) {
/* 141 */     (new MainTool()).process(files);
/*     */   }
/*     */   
/*     */   static class MainTool {
/* 145 */     private List mFailures = new ArrayList();
/* 146 */     private int mCount = 0;
/* 147 */     private PrintWriter mOut = new PrintWriter(System.out);
/* 148 */     private long mStartTime = System.currentTimeMillis();
/*     */     
/*     */     public void process(String[] files) {
/*     */       try {
/* 152 */         for (int i = 0; i < files.length; i++) {
/* 153 */           File input = new File(files[i]);
/* 154 */           parse(new ParserClassBuilder(), input);
/*     */         } 
/* 156 */       } catch (Exception e) {
/* 157 */         e.printStackTrace();
/*     */       } 
/* 159 */       this.mOut.println("\n\n\n");
/* 160 */       int fails = this.mFailures.size();
/* 161 */       if (fails != 0) {
/* 162 */         this.mOut.println("The following files failed to parse:");
/* 163 */         for (int i = 0; i < fails; i++) {
/* 164 */           this.mOut.println(((File)this.mFailures.get(i)).getAbsolutePath());
/*     */         }
/*     */       } 
/* 167 */       this.mOut.println(((this.mCount - fails) * 100 / this.mCount) + "% (" + (this.mCount - fails) + "/" + this.mCount + ") " + "of input java files successfully parsed.");
/*     */ 
/*     */       
/* 170 */       this.mOut.println("Total time: " + ((System.currentTimeMillis() - this.mStartTime) / 1000L) + " seconds.");
/*     */ 
/*     */       
/* 173 */       this.mOut.flush();
/* 174 */       System.out.flush();
/* 175 */       System.err.flush();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void parse(ParserClassBuilder parser, File input) throws Exception {
/* 181 */       System.gc();
/* 182 */       if (input.isDirectory()) {
/*     */         
/* 184 */         File[] files = input.listFiles();
/* 185 */         for (int i = 0; i < files.length; i++) {
/* 186 */           parse(parser, files[i]);
/*     */         }
/*     */       } else {
/* 189 */         if (!input.getName().endsWith(".java")) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 195 */         this.mCount++;
/* 196 */         MClass[] results = null;
/*     */         try {
/* 198 */           results = ParserClassBuilder.parse(new FileReader(input), null);
/* 199 */           if (results == null) {
/* 200 */             this.mOut.println("[error, parser result is null]");
/* 201 */             addFailure(input);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 210 */         catch (Throwable e) {
/* 211 */           e.printStackTrace(this.mOut);
/* 212 */           addFailure(input);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void addFailure(File file) {
/* 218 */       this.mFailures.add(file);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\parser\ParserClassBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */