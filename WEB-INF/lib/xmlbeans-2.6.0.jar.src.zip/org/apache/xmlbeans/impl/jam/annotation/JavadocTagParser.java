/*     */ package org.apache.xmlbeans.impl.jam.annotation;
/*     */ 
/*     */ import com.sun.javadoc.SourcePosition;
/*     */ import com.sun.javadoc.Tag;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MSourcePosition;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamServiceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavadocTagParser
/*     */ {
/*  36 */   private JamServiceContext mContext = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mAddSingleValueMembers = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAddSingleValueMembers(boolean b) {
/*  54 */     this.mAddSingleValueMembers = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(JamServiceContext ctx) {
/*  62 */     if (ctx == null) throw new IllegalArgumentException("null logger"); 
/*  63 */     if (this.mContext != null) throw new IllegalStateException("JavadocTagParser.init() called twice");
/*     */     
/*  65 */     this.mContext = ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void parse(MAnnotatedElement paramMAnnotatedElement, Tag paramTag);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MAnnotation[] createAnnotations(MAnnotatedElement target, Tag tag) {
/*  77 */     String tagName = tag.name().trim().substring(1);
/*     */     
/*  79 */     MAnnotation current = target.getMutableAnnotation(tagName);
/*  80 */     if (current == null) {
/*  81 */       current = target.findOrCreateAnnotation(tagName);
/*  82 */       setPosition(current, tag);
/*     */     } 
/*  84 */     MAnnotation literal = target.addLiteralAnnotation(tagName);
/*  85 */     setPosition(literal, tag);
/*  86 */     MAnnotation[] out = { literal, current };
/*  87 */     if (this.mAddSingleValueMembers) setSingleValueText(out, tag); 
/*  88 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValue(MAnnotation[] anns, String memberName, String value) {
/*  97 */     value = value.trim();
/*  98 */     memberName = memberName.trim();
/*  99 */     for (int i = 0; i < anns.length; i++) {
/* 100 */       if (anns[i].getValue(memberName) == null)
/*     */       {
/* 102 */         anns[i].setSimpleValue(memberName, value, getStringType()); } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected JamLogger getLogger() {
/* 107 */     return this.mContext.getLogger();
/*     */   }
/*     */   protected JClass getStringType() {
/* 110 */     return ((ElementContext)this.mContext).getClassLoader().loadClass("java.lang.String");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSingleValueText(MAnnotation[] targets, Tag tag) {
/* 118 */     String tagText = tag.text();
/* 119 */     for (int i = 0; i < targets.length; i++) {
/* 120 */       targets[i].setSimpleValue("value", tagText, getStringType());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setPosition(MAnnotation target, Tag tag) {
/* 130 */     SourcePosition pos = tag.position();
/* 131 */     if (pos != null) {
/* 132 */       MSourcePosition mpos = target.createSourcePosition();
/* 133 */       mpos.setLine(pos.line());
/* 134 */       mpos.setColumn(pos.column());
/* 135 */       if (pos.file() != null) mpos.setSourceURI(pos.file().toURI()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\annotation\JavadocTagParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */