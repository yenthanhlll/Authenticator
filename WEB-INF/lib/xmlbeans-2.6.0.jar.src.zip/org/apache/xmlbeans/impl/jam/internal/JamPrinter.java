/*     */ package org.apache.xmlbeans.impl.jam.internal;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.JElement;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JamPrinter
/*     */ {
/*     */   private static final String INDENT = "  ";
/*     */   
/*     */   public static JamPrinter newInstance() {
/*  41 */     return new JamPrinter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(JElement root, PrintWriter out) {
/*  53 */     print(root, 0, out);
/*     */   }
/*     */   
/*     */   public void print(JamClassIterator iter, PrintWriter out) {
/*  57 */     while (iter.hasNext()) {
/*  58 */       JClass clazz = iter.nextClass();
/*  59 */       out.println("------------------------------");
/*  60 */       out.println(clazz.getQualifiedName());
/*  61 */       out.println("------------------------------");
/*  62 */       print((JElement)clazz, out);
/*  63 */       out.println();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void print(JElement a, int indent, PrintWriter out) {
/*  71 */     indent(indent, out);
/*  72 */     out.print("[");
/*  73 */     out.print(getTypeKey(a));
/*  74 */     out.print("] ");
/*  75 */     if (a instanceof JMethod) {
/*  76 */       out.print(((JMethod)a).getReturnType().getFieldDescriptor());
/*  77 */       out.print(" ");
/*  78 */       out.println(a.getSimpleName());
/*     */     } else {
/*  80 */       out.println(a.getSimpleName());
/*     */     } 
/*  82 */     indent++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void print(JAnnotation[] atts, int indent, PrintWriter out) {
/*  98 */     for (int i = 0; i < atts.length; i++) {
/*  99 */       indent(indent, out);
/* 100 */       out.print("<");
/* 101 */       out.print(getTypeKey(atts[i]));
/* 102 */       out.print("> ");
/* 103 */       out.print(atts[i].getSimpleName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void indent(int indent, PrintWriter out) {
/* 108 */     for (int i = 0; i < indent; ) { out.print("  "); i++; }
/*     */   
/*     */   }
/*     */   private String getTypeKey(Object o) {
/* 112 */     if (o == null) return "[?UNKNOWN!]"; 
/* 113 */     String type = o.getClass().getName();
/* 114 */     int lastDot = type.lastIndexOf(".");
/* 115 */     if (lastDot != -1 && lastDot + 1 < type.length()) {
/* 116 */       type = type.substring(lastDot + 1);
/*     */     }
/* 118 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JElement[] getChildrenFor(JElement parent) {
/* 125 */     Collection list = new ArrayList();
/* 126 */     if (parent instanceof JClass) {
/* 127 */       list.addAll(Arrays.asList(((JClass)parent).getDeclaredFields()));
/* 128 */       list.addAll(Arrays.asList(((JClass)parent).getDeclaredMethods()));
/* 129 */       list.addAll(Arrays.asList(((JClass)parent).getConstructors()));
/* 130 */       list.addAll(Arrays.asList(((JClass)parent).getClasses()));
/* 131 */     } else if (parent instanceof JConstructor) {
/* 132 */       list.addAll(Arrays.asList(((JConstructor)parent).getParameters()));
/* 133 */     } else if (parent instanceof JMethod) {
/* 134 */       list.addAll(Arrays.asList(((JMethod)parent).getParameters()));
/*     */     } 
/* 136 */     JElement[] out = new JElement[list.size()];
/* 137 */     list.toArray((Object[])out);
/* 138 */     return out;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\JamPrinter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */