/*     */ package org.apache.xmlbeans.impl.jam.annotation;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.AnnotationValueImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypedAnnotationProxyBase
/*     */   extends AnnotationProxy
/*     */ {
/*  45 */   private List mValues = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, Object value, JClass type) {
/*  67 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  68 */     if (value == null) throw new IllegalArgumentException("null value");
/*     */ 
/*     */     
/*  71 */     if (this.mValues == null) this.mValues = new ArrayList(); 
/*  72 */     this.mValues.add(new AnnotationValueImpl((ElementContext)this.mContext, name, value, type));
/*     */ 
/*     */     
/*  75 */     Method m = getSetterFor(name, value.getClass());
/*  76 */     if (m == null)
/*     */       return;  try {
/*  78 */       m.invoke(this, new Object[] { value });
/*  79 */     } catch (IllegalAccessException e) {
/*  80 */       getLogger().warning(e);
/*  81 */     } catch (InvocationTargetException e) {
/*  82 */       getLogger().warning(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JAnnotationValue[] getValues() {
/*  97 */     if (this.mValues == null) return new JAnnotationValue[0]; 
/*  98 */     JAnnotationValue[] out = new JAnnotationValue[this.mValues.size()];
/*  99 */     this.mValues.toArray((Object[])out);
/* 100 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getSetterFor(String memberName, Class valueType) {
/*     */     try {
/* 115 */       return getClass().getMethod("set" + memberName, new Class[] { valueType });
/*     */     }
/* 117 */     catch (NoSuchMethodException nsme) {
/* 118 */       getLogger().warning(nsme);
/* 119 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\annotation\TypedAnnotationProxyBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */