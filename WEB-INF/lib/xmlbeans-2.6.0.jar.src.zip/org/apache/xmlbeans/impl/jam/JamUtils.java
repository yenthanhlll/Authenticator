/*     */ package org.apache.xmlbeans.impl.jam;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JamUtils
/*     */ {
/*     */   public static final JamUtils getInstance() {
/*  40 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*  44 */   private static final JamUtils INSTANCE = new JamUtils();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethodOn(JMethod method, Class containedin) throws NoSuchMethodException, ClassNotFoundException {
/*  65 */     if (containedin == null) throw new IllegalArgumentException("null class"); 
/*  66 */     if (method == null) throw new IllegalArgumentException("null method"); 
/*  67 */     Class[] types = null;
/*  68 */     JParameter[] params = method.getParameters();
/*  69 */     if (params != null && params.length > 0) {
/*  70 */       types = new Class[params.length];
/*  71 */       for (int i = 0; i < types.length; i++) {
/*  72 */         types[i] = loadClass(params[i].getType(), containedin.getClassLoader());
/*     */       }
/*     */     } 
/*  75 */     return containedin.getMethod(method.getSimpleName(), types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constructor getConstructorOn(JConstructor ctor, Class containedin) throws NoSuchMethodException, ClassNotFoundException {
/*  93 */     if (containedin == null) throw new IllegalArgumentException("null class"); 
/*  94 */     if (ctor == null) throw new IllegalArgumentException("null ctor"); 
/*  95 */     Class[] types = null;
/*  96 */     JParameter[] params = ctor.getParameters();
/*  97 */     if (params != null && params.length > 0) {
/*  98 */       types = new Class[params.length];
/*  99 */       for (int i = 0; i < types.length; i++) {
/* 100 */         types[i] = loadClass(params[i].getType(), containedin.getClassLoader());
/*     */       }
/*     */     } 
/* 103 */     return containedin.getConstructor(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Field getFieldOn(JField field, Class containedin) throws NoSuchFieldException {
/* 118 */     if (containedin == null) throw new IllegalArgumentException("null class"); 
/* 119 */     if (field == null) throw new IllegalArgumentException("null field"); 
/* 120 */     return containedin.getField(field.getSimpleName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class loadClass(JClass clazz, ClassLoader inThisClassloader) throws ClassNotFoundException {
/* 133 */     return inThisClassloader.loadClass(clazz.getQualifiedName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void placeInSourceOrder(JElement[] elements) {
/* 141 */     if (elements == null) throw new IllegalArgumentException("null elements"); 
/* 142 */     Arrays.sort(elements, SOURCE_POSITION_COMPARATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private static Comparator SOURCE_POSITION_COMPARATOR = new Comparator()
/*     */     {
/*     */       public int compare(Object o, Object o1) {
/* 151 */         JSourcePosition p1 = ((JElement)o).getSourcePosition();
/* 152 */         JSourcePosition p2 = ((JElement)o1).getSourcePosition();
/* 153 */         if (p1 == null) return (p2 == null) ? 0 : -1; 
/* 154 */         if (p2 == null) return 1; 
/* 155 */         return (p1.getLine() < p2.getLine()) ? -1 : ((p1.getLine() > p2.getLine()) ? 1 : 0);
/*     */       }
/*     */     };
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\JamUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */