/*     */ package org.apache.xmlbeans.impl.jam.visitor;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JComment;
/*     */ import org.apache.xmlbeans.impl.jam.JConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.JField;
/*     */ import org.apache.xmlbeans.impl.jam.JInvokable;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JPackage;
/*     */ import org.apache.xmlbeans.impl.jam.JParameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TraversingJVisitor
/*     */   extends JVisitor
/*     */ {
/*     */   private JVisitor mDelegate;
/*     */   
/*     */   public TraversingJVisitor(JVisitor jv) {
/*  61 */     if (jv == null) throw new IllegalArgumentException("null jv"); 
/*  62 */     this.mDelegate = jv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(JPackage pkg) {
/*  69 */     pkg.accept(this.mDelegate);
/*  70 */     JClass[] c = pkg.getClasses();
/*  71 */     for (int i = 0; i < c.length; ) { visit(c[i]); i++; }
/*  72 */      visitAnnotations((JAnnotatedElement)pkg);
/*  73 */     visitComment((JAnnotatedElement)pkg);
/*     */   }
/*     */   
/*     */   public void visit(JClass clazz) {
/*  77 */     clazz.accept(this.mDelegate);
/*     */     
/*  79 */     JField[] f = clazz.getDeclaredFields(); int i;
/*  80 */     for (i = 0; i < f.length; ) { visit(f[i]); i++; }
/*     */     
/*  82 */     JConstructor[] c = clazz.getConstructors();
/*  83 */     for (i = 0; i < c.length; ) { visit(c[i]); i++; }
/*     */     
/*  85 */     JMethod[] m = clazz.getMethods();
/*  86 */     for (i = 0; i < m.length; ) { visit(m[i]); i++; }
/*     */     
/*  88 */     visitAnnotations((JAnnotatedElement)clazz);
/*  89 */     visitComment((JAnnotatedElement)clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(JField field) {
/*  96 */     field.accept(this.mDelegate);
/*  97 */     visitAnnotations((JAnnotatedElement)field);
/*  98 */     visitComment((JAnnotatedElement)field);
/*     */   }
/*     */   
/*     */   public void visit(JConstructor ctor) {
/* 102 */     ctor.accept(this.mDelegate);
/* 103 */     visitParameters((JInvokable)ctor);
/* 104 */     visitAnnotations((JAnnotatedElement)ctor);
/* 105 */     visitComment((JAnnotatedElement)ctor);
/*     */   }
/*     */   
/*     */   public void visit(JMethod method) {
/* 109 */     method.accept(this.mDelegate);
/* 110 */     visitParameters((JInvokable)method);
/* 111 */     visitAnnotations((JAnnotatedElement)method);
/* 112 */     visitComment((JAnnotatedElement)method);
/*     */   }
/*     */   
/*     */   public void visit(JParameter param) {
/* 116 */     param.accept(this.mDelegate);
/* 117 */     visitAnnotations((JAnnotatedElement)param);
/* 118 */     visitComment((JAnnotatedElement)param);
/*     */   }
/*     */   public void visit(JAnnotation ann) {
/* 121 */     ann.accept(this.mDelegate);
/*     */   } public void visit(JComment comment) {
/* 123 */     comment.accept(this.mDelegate);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void visitParameters(JInvokable iv) {
/* 129 */     JParameter[] p = iv.getParameters();
/* 130 */     for (int i = 0; i < p.length; ) { visit(p[i]); i++; }
/*     */   
/*     */   }
/*     */   private void visitAnnotations(JAnnotatedElement ae) {
/* 134 */     JAnnotation[] anns = ae.getAnnotations();
/* 135 */     for (int i = 0; i < anns.length; ) { visit(anns[i]); i++; }
/*     */   
/*     */   }
/*     */   private void visitComment(JAnnotatedElement e) {
/* 139 */     JComment c = e.getComment();
/* 140 */     if (c != null) visit(c); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\visitor\TraversingJVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */