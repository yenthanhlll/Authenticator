/*     */ package org.apache.xmlbeans.impl.jam.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.jam.JamServiceParams;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.AnnotationProxy;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.DefaultAnnotationProxy;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.JavadocTagParser;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.WhitespaceDelimitedTagParser;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.provider.CompositeJamClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamServiceContext;
/*     */ import org.apache.xmlbeans.impl.jam.provider.ResourcePath;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.CompositeMVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.PropertyInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JamServiceContextImpl
/*     */   extends JamLoggerImpl
/*     */   implements JamServiceContext, JamServiceParams, ElementContext
/*     */ {
/*     */   private static final char INNER_CLASS_SEPARATOR = '$';
/*     */   private boolean m14WarningsEnabled = false;
/*  66 */   private Properties mProperties = null;
/*  67 */   private Map mSourceRoot2Scanner = null;
/*  68 */   private Map mClassRoot2Scanner = null;
/*     */ 
/*     */   
/*  71 */   private List mClasspath = null;
/*  72 */   private List mSourcepath = null;
/*  73 */   private List mToolClasspath = null;
/*     */   
/*  75 */   private List mIncludeClasses = null;
/*  76 */   private List mExcludeClasses = null;
/*     */ 
/*     */   
/*     */   private boolean mUseSystemClasspath = true;
/*     */ 
/*     */   
/*  82 */   private JavadocTagParser mTagParser = null;
/*  83 */   private MVisitor mCommentInitializer = null;
/*  84 */   private MVisitor mPropertyInitializer = (MVisitor)new PropertyInitializer();
/*  85 */   private List mOtherInitializers = null;
/*  86 */   private List mUnstructuredSourceFiles = null;
/*  87 */   private List mClassLoaders = null;
/*  88 */   private List mBaseBuilders = null;
/*     */   
/*  90 */   private JamClassLoader mLoader = null;
/*     */   
/*     */   private static final String PREFIX = "[JamServiceContextImpl] ";
/*     */ 
/*     */   
/*     */   public void setClassLoader(JamClassLoader loader) {
/*  96 */     this.mLoader = loader;
/*     */   }
/*     */   
/*     */   public JamClassBuilder getBaseBuilder() {
/* 100 */     if (this.mBaseBuilders == null || this.mBaseBuilders.size() == 0) {
/* 101 */       return null;
/*     */     }
/* 103 */     if (this.mBaseBuilders.size() == 1) {
/* 104 */       return this.mBaseBuilders.get(0);
/*     */     }
/* 106 */     JamClassBuilder[] comp = new JamClassBuilder[this.mBaseBuilders.size()];
/* 107 */     this.mBaseBuilders.toArray((Object[])comp);
/* 108 */     return (JamClassBuilder)new CompositeJamClassBuilder(comp);
/*     */   }
/*     */   
/*     */   public JavadocTagParser getTagParser() {
/* 112 */     if (this.mTagParser == null) {
/* 113 */       this.mTagParser = (JavadocTagParser)new WhitespaceDelimitedTagParser();
/* 114 */       this.mTagParser.init(this);
/*     */     } 
/* 116 */     return this.mTagParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAllClassnames() throws IOException {
/* 133 */     Set all = new HashSet();
/* 134 */     if (this.mIncludeClasses != null) all.addAll(this.mIncludeClasses); 
/* 135 */     for (Iterator i = getAllDirectoryScanners(); i.hasNext(); ) {
/* 136 */       DirectoryScanner ds = i.next();
/* 137 */       String[] files = ds.getIncludedFiles();
/* 138 */       for (int j = 0; j < files.length; j++) {
/*     */ 
/*     */ 
/*     */         
/* 142 */         if (files[j].indexOf('$') == -1) {
/* 143 */           all.add(filename2classname(files[j]));
/*     */         }
/*     */       } 
/*     */     } 
/* 147 */     if (this.mExcludeClasses != null) all.removeAll(this.mExcludeClasses); 
/* 148 */     String[] out = new String[all.size()];
/* 149 */     all.toArray(out);
/* 150 */     return out;
/*     */   }
/*     */   public JamLogger getLogger() {
/* 153 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File[] getSourceFiles() throws IOException {
/* 172 */     Set set = new HashSet();
/* 173 */     if (this.mSourceRoot2Scanner != null) {
/* 174 */       for (Iterator i = this.mSourceRoot2Scanner.values().iterator(); i.hasNext(); ) {
/* 175 */         DirectoryScanner ds = i.next();
/* 176 */         if (isVerbose(this)) {
/* 177 */           verbose("[JamServiceContextImpl]  checking scanner for dir" + ds.getRoot());
/*     */         }
/* 179 */         String[] files = ds.getIncludedFiles();
/* 180 */         for (int j = 0; j < files.length; j++) {
/* 181 */           if (isVerbose(this)) {
/* 182 */             verbose("[JamServiceContextImpl]  ...including a source file " + files[j]);
/*     */           }
/* 184 */           set.add(new File(ds.getRoot(), files[j]));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 191 */     if (this.mUnstructuredSourceFiles != null) {
/* 192 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] adding " + this.mUnstructuredSourceFiles.size() + " other source files");
/*     */       
/* 194 */       set.addAll(this.mUnstructuredSourceFiles);
/*     */     } 
/* 196 */     File[] out = new File[set.size()];
/* 197 */     set.toArray(out);
/* 198 */     return out;
/*     */   }
/*     */   
/*     */   public File[] getUnstructuredSourceFiles() {
/* 202 */     if (this.mUnstructuredSourceFiles == null) return null; 
/* 203 */     File[] out = new File[this.mUnstructuredSourceFiles.size()];
/* 204 */     this.mUnstructuredSourceFiles.toArray((Object[])out);
/* 205 */     return out;
/*     */   }
/*     */   
/*     */   public ResourcePath getInputClasspath() {
/* 209 */     return createJPath(this.mClasspath);
/*     */   } public ResourcePath getInputSourcepath() {
/* 211 */     return createJPath(this.mSourcepath);
/*     */   } public ResourcePath getToolClasspath() {
/* 213 */     return createJPath(this.mToolClasspath);
/*     */   }
/*     */   public String getProperty(String name) {
/* 216 */     return (this.mProperties == null) ? null : this.mProperties.getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public MVisitor getInitializer() {
/* 221 */     List initers = new ArrayList();
/*     */ 
/*     */     
/* 224 */     if (this.mCommentInitializer != null) initers.add(this.mCommentInitializer);
/*     */ 
/*     */     
/* 227 */     if (this.mPropertyInitializer != null) initers.add(this.mPropertyInitializer); 
/* 228 */     if (this.mOtherInitializers != null) initers.addAll(this.mOtherInitializers);
/*     */     
/* 230 */     MVisitor[] inits = new MVisitor[initers.size()];
/* 231 */     initers.toArray(inits);
/* 232 */     return (MVisitor)new CompositeMVisitor(inits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addClassBuilder(JamClassBuilder builder) {
/* 239 */     if (this.mBaseBuilders == null) this.mBaseBuilders = new ArrayList(); 
/* 240 */     this.mBaseBuilders.add(builder);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCommentInitializer(MVisitor initializer) {
/* 245 */     this.mCommentInitializer = initializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertyInitializer(MVisitor initializer) {
/* 250 */     this.mPropertyInitializer = initializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addInitializer(MVisitor initializer) {
/* 255 */     if (this.mOtherInitializers == null) this.mOtherInitializers = new ArrayList(); 
/* 256 */     this.mOtherInitializers.add(initializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJavadocTagParser(JavadocTagParser tp) {
/* 261 */     this.mTagParser = tp;
/* 262 */     tp.init(this);
/*     */   }
/*     */   
/*     */   public void includeSourceFile(File file) {
/* 266 */     if (file == null) throw new IllegalArgumentException("null file"); 
/* 267 */     file = file.getAbsoluteFile();
/* 268 */     if (isVerbose(this)) verbose("[JamServiceContextImpl] adding source "); 
/* 269 */     if (!file.exists()) throw new IllegalArgumentException(file + " does not exist"); 
/* 270 */     if (file.isDirectory()) throw new IllegalArgumentException(file + " cannot be included as a source file because it is a directory.");
/*     */     
/* 272 */     if (this.mUnstructuredSourceFiles == null) {
/* 273 */       this.mUnstructuredSourceFiles = new ArrayList();
/*     */     }
/* 275 */     this.mUnstructuredSourceFiles.add(file.getAbsoluteFile());
/*     */   }
/*     */   
/*     */   public void includeSourcePattern(File[] sourcepath, String pattern) {
/* 279 */     if (sourcepath == null) throw new IllegalArgumentException("null sourcepath"); 
/* 280 */     if (sourcepath.length == 0) throw new IllegalArgumentException("empty sourcepath"); 
/* 281 */     if (pattern == null) throw new IllegalArgumentException("null pattern"); 
/* 282 */     pattern = pattern.trim();
/* 283 */     if (pattern.length() == 0) throw new IllegalArgumentException("empty pattern"); 
/* 284 */     for (int i = 0; i < sourcepath.length; i++) {
/* 285 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] including '" + pattern + "' under " + sourcepath[i]); 
/* 286 */       addSourcepath(sourcepath[i]);
/* 287 */       getSourceScanner(sourcepath[i]).include(pattern);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void includeClassPattern(File[] classpath, String pattern) {
/* 292 */     if (classpath == null) throw new IllegalArgumentException("null classpath"); 
/* 293 */     if (classpath.length == 0) throw new IllegalArgumentException("empty classpath"); 
/* 294 */     if (pattern == null) throw new IllegalArgumentException("null pattern"); 
/* 295 */     pattern = pattern.trim();
/* 296 */     if (pattern.length() == 0) throw new IllegalArgumentException("empty pattern"); 
/* 297 */     for (int i = 0; i < classpath.length; i++) {
/* 298 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] including '" + pattern + "' under " + classpath[i]); 
/* 299 */       addClasspath(classpath[i]);
/* 300 */       getClassScanner(classpath[i]).include(pattern);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void excludeSourcePattern(File[] sourcepath, String pattern) {
/* 305 */     if (sourcepath == null) throw new IllegalArgumentException("null sourcepath"); 
/* 306 */     if (sourcepath.length == 0) throw new IllegalArgumentException("empty sourcepath"); 
/* 307 */     if (pattern == null) throw new IllegalArgumentException("null pattern"); 
/* 308 */     pattern = pattern.trim();
/* 309 */     if (pattern.length() == 0) throw new IllegalArgumentException("empty pattern"); 
/* 310 */     for (int i = 0; i < sourcepath.length; i++) {
/* 311 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] EXCLUDING '" + pattern + "' under " + sourcepath[i]); 
/* 312 */       addSourcepath(sourcepath[i]);
/* 313 */       getSourceScanner(sourcepath[i]).exclude(pattern);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void excludeClassPattern(File[] classpath, String pattern) {
/* 318 */     if (classpath == null) throw new IllegalArgumentException("null classpath"); 
/* 319 */     if (classpath.length == 0) throw new IllegalArgumentException("empty classpath"); 
/* 320 */     if (pattern == null) throw new IllegalArgumentException("null pattern"); 
/* 321 */     pattern = pattern.trim();
/* 322 */     if (pattern.length() == 0) throw new IllegalArgumentException("empty pattern"); 
/* 323 */     for (int i = 0; i < classpath.length; i++) {
/* 324 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] EXCLUDING '" + pattern + "' under " + classpath[i]); 
/* 325 */       addClasspath(classpath[i]);
/* 326 */       getClassScanner(classpath[i]).exclude(pattern);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void includeSourceFile(File[] sourcepath, File sourceFile) {
/* 331 */     File root = getPathRootForFile(sourcepath, sourceFile);
/* 332 */     includeSourcePattern(new File[] { root }, source2pattern(root, sourceFile));
/*     */   }
/*     */   
/*     */   public void excludeSourceFile(File[] sourcepath, File sourceFile) {
/* 336 */     File root = getPathRootForFile(sourcepath, sourceFile);
/* 337 */     excludeSourcePattern(new File[] { root }, source2pattern(root, sourceFile));
/*     */   }
/*     */   
/*     */   public void includeClassFile(File[] classpath, File classFile) {
/* 341 */     File root = getPathRootForFile(classpath, classFile);
/* 342 */     includeClassPattern(new File[] { root }, source2pattern(root, classFile));
/*     */   }
/*     */   
/*     */   public void excludeClassFile(File[] classpath, File classFile) {
/* 346 */     File root = getPathRootForFile(classpath, classFile);
/* 347 */     excludeClassPattern(new File[] { root }, source2pattern(root, classFile));
/*     */   }
/*     */   
/*     */   public void includeClass(String qualifiedClassname) {
/* 351 */     if (this.mIncludeClasses == null) this.mIncludeClasses = new ArrayList(); 
/* 352 */     this.mIncludeClasses.add(qualifiedClassname);
/*     */   }
/*     */   
/*     */   public void excludeClass(String qualifiedClassname) {
/* 356 */     if (this.mExcludeClasses == null) this.mExcludeClasses = new ArrayList(); 
/* 357 */     this.mExcludeClasses.add(qualifiedClassname);
/*     */   }
/*     */   
/*     */   public void addClasspath(File classpathElement) {
/* 361 */     if (this.mClasspath == null) {
/* 362 */       this.mClasspath = new ArrayList();
/*     */     }
/* 364 */     else if (this.mClasspath.contains(classpathElement)) {
/*     */       return;
/* 366 */     }  this.mClasspath.add(classpathElement);
/*     */   }
/*     */   
/*     */   public void setLoggerWriter(PrintWriter out) {
/* 370 */     setOut(out);
/*     */   }
/*     */   
/*     */   public void setJamLogger(JamLogger logger) {
/* 374 */     throw new IllegalStateException("NYI");
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSourcepath(File sourcepathElement) {
/* 379 */     if (this.mSourcepath == null) {
/* 380 */       this.mSourcepath = new ArrayList();
/*     */     }
/* 382 */     else if (this.mSourcepath.contains(sourcepathElement)) {
/*     */       return;
/* 384 */     }  this.mSourcepath.add(sourcepathElement);
/*     */   }
/*     */   
/*     */   public void addToolClasspath(File classpathElement) {
/* 388 */     if (this.mToolClasspath == null) {
/* 389 */       this.mToolClasspath = new ArrayList();
/*     */     }
/* 391 */     else if (this.mToolClasspath.contains(classpathElement)) {
/*     */       return;
/* 393 */     }  this.mToolClasspath.add(classpathElement);
/*     */   }
/*     */   
/*     */   public void setProperty(String name, String value) {
/* 397 */     if (this.mProperties == null) this.mProperties = new Properties(); 
/* 398 */     this.mProperties.setProperty(name, value);
/*     */   }
/*     */   
/*     */   public void set14WarningsEnabled(boolean b) {
/* 402 */     this.m14WarningsEnabled = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentClassLoader(JamClassLoader loader) {
/* 410 */     throw new IllegalStateException("NYI");
/*     */   }
/*     */   
/*     */   public void setUseSystemClasspath(boolean use) {
/* 414 */     this.mUseSystemClasspath = use;
/*     */   }
/*     */   
/*     */   public void addClassLoader(ClassLoader cl) {
/* 418 */     if (this.mClassLoaders == null) this.mClassLoaders = new ArrayList(); 
/* 419 */     this.mClassLoaders.add(cl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader[] getReflectionClassLoaders() {
/* 428 */     if (this.mClassLoaders == null) {
/* 429 */       if (this.mUseSystemClasspath) {
/* 430 */         return new ClassLoader[] { ClassLoader.getSystemClassLoader() };
/*     */       }
/* 432 */       return new ClassLoader[0];
/*     */     } 
/*     */     
/* 435 */     ClassLoader[] out = new ClassLoader[this.mClassLoaders.size() + (this.mUseSystemClasspath ? 1 : 0)];
/*     */     
/* 437 */     for (int i = 0; i < this.mClassLoaders.size(); i++) {
/* 438 */       out[i] = this.mClassLoaders.get(i);
/*     */     }
/* 440 */     if (this.mUseSystemClasspath) {
/* 441 */       out[out.length - 1] = ClassLoader.getSystemClassLoader();
/*     */     }
/* 443 */     return out;
/*     */   }
/*     */   
/*     */   public boolean is14WarningsEnabled() {
/* 447 */     return this.m14WarningsEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public JamClassLoader getClassLoader() {
/* 452 */     return this.mLoader;
/*     */   }
/*     */   public AnnotationProxy createAnnotationProxy(String jsr175typename) {
/* 455 */     DefaultAnnotationProxy defaultAnnotationProxy = new DefaultAnnotationProxy();
/* 456 */     defaultAnnotationProxy.init(this);
/* 457 */     return (AnnotationProxy)defaultAnnotationProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getPathRootForFile(File[] sourcepath, File sourceFile) {
/* 466 */     if (sourcepath == null) throw new IllegalArgumentException("null sourcepath"); 
/* 467 */     if (sourcepath.length == 0) throw new IllegalArgumentException("empty sourcepath"); 
/* 468 */     if (sourceFile == null) throw new IllegalArgumentException("null sourceFile"); 
/* 469 */     sourceFile = sourceFile.getAbsoluteFile();
/* 470 */     if (isVerbose(this)) verbose("[JamServiceContextImpl] Getting root for " + sourceFile + "..."); 
/* 471 */     for (int i = 0; i < sourcepath.length; i++) {
/* 472 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] ...looking in " + sourcepath[i]); 
/* 473 */       if (isContainingDir(sourcepath[i].getAbsoluteFile(), sourceFile)) {
/* 474 */         if (isVerbose(this)) verbose("[JamServiceContextImpl] ...found it!"); 
/* 475 */         return sourcepath[i].getAbsoluteFile();
/*     */       } 
/*     */     } 
/* 478 */     throw new IllegalArgumentException(sourceFile + " is not in the given path.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isContainingDir(File dir, File file) {
/* 485 */     if (isVerbose(this)) verbose("[JamServiceContextImpl] ... ...isContainingDir " + dir + "  " + file); 
/* 486 */     if (file == null) return false; 
/* 487 */     if (dir.equals(file)) {
/* 488 */       if (isVerbose(this)) verbose("[JamServiceContextImpl] ... ...yes!"); 
/* 489 */       return true;
/*     */     } 
/* 491 */     return isContainingDir(dir, file.getParentFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String source2pattern(File root, File sourceFile) {
/* 499 */     if (isVerbose(this)) verbose("[JamServiceContextImpl] source2pattern " + root + "  " + sourceFile);
/*     */     
/* 501 */     String r = root.getAbsolutePath();
/* 502 */     String s = sourceFile.getAbsolutePath();
/* 503 */     if (isVerbose(this)) {
/* 504 */       verbose("[JamServiceContextImpl] source2pattern returning " + s.substring(r.length() + 1));
/*     */     }
/* 506 */     return s.substring(r.length() + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String filename2classname(String filename) {
/* 515 */     int extDot = filename.lastIndexOf('.');
/* 516 */     if (extDot != -1) filename = filename.substring(0, extDot); 
/* 517 */     filename = filename.replace('/', '.');
/* 518 */     filename = filename.replace('\\', '.');
/* 519 */     return filename;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator getAllDirectoryScanners() {
/* 527 */     Collection out = new ArrayList();
/* 528 */     if (this.mSourceRoot2Scanner != null) {
/* 529 */       out.addAll(this.mSourceRoot2Scanner.values());
/*     */     }
/* 531 */     if (this.mClassRoot2Scanner != null) {
/* 532 */       out.addAll(this.mClassRoot2Scanner.values());
/*     */     }
/* 534 */     return out.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResourcePath createJPath(Collection filelist) {
/* 542 */     if (filelist == null || filelist.size() == 0) return null; 
/* 543 */     File[] files = new File[filelist.size()];
/* 544 */     filelist.toArray((Object[])files);
/* 545 */     return ResourcePath.forFiles(files);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DirectoryScanner getSourceScanner(File srcRoot) {
/* 553 */     if (this.mSourceRoot2Scanner == null) this.mSourceRoot2Scanner = new HashMap(); 
/* 554 */     DirectoryScanner out = (DirectoryScanner)this.mSourceRoot2Scanner.get(srcRoot);
/* 555 */     if (out == null) {
/* 556 */       this.mSourceRoot2Scanner.put(srcRoot, out = new DirectoryScanner(srcRoot, this));
/*     */     }
/* 558 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DirectoryScanner getClassScanner(File clsRoot) {
/* 566 */     if (this.mClassRoot2Scanner == null) this.mClassRoot2Scanner = new HashMap(); 
/* 567 */     DirectoryScanner out = (DirectoryScanner)this.mClassRoot2Scanner.get(clsRoot);
/* 568 */     if (out == null) {
/* 569 */       this.mClassRoot2Scanner.put(clsRoot, out = new DirectoryScanner(clsRoot, this));
/*     */     }
/* 571 */     return out;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\JamServiceContextImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */