/*     */ package org.apache.xmlbeans.impl.jam.annotation;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamServiceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotationProxy
/*     */ {
/*     */   public static final String SINGLE_MEMBER_NAME = "value";
/*     */   private static final String DEFAULT_NVPAIR_DELIMS = "\n\r";
/*     */   protected JamServiceContext mContext;
/*     */   
/*     */   public void init(JamServiceContext ctx) {
/*  64 */     if (ctx == null) throw new IllegalArgumentException("null logger"); 
/*  65 */     this.mContext = ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setValue(String paramString, Object paramObject, JClass paramJClass);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JAnnotationValue[] getValues();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JAnnotationValue getValue(String named) {
/*  83 */     if (named == null) throw new IllegalArgumentException("null name");
/*     */     
/*  85 */     named = named.trim();
/*  86 */     JAnnotationValue[] values = getValues();
/*  87 */     for (int i = 0; i < values.length; i++) {
/*     */       
/*  89 */       if (named.equals(values[i].getName())) return values[i]; 
/*     */     } 
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JamLogger getLogger() {
/* 101 */     return this.mContext.getLogger();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\annotation\AnnotationProxy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */