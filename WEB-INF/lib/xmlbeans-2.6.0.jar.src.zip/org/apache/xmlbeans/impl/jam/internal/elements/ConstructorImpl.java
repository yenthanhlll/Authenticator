/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import java.io.StringWriter;
/*    */ import java.lang.reflect.Modifier;
/*    */ import org.apache.xmlbeans.impl.jam.JConstructor;
/*    */ import org.apache.xmlbeans.impl.jam.JParameter;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*    */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*    */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConstructorImpl
/*    */   extends InvokableImpl
/*    */   implements MConstructor
/*    */ {
/*    */   ConstructorImpl(ClassImpl containingClass) {
/* 36 */     super(containingClass);
/* 37 */     setSimpleName(containingClass.getSimpleName());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(MVisitor visitor) {
/* 43 */     visitor.visit(this);
/*    */   } public void accept(JVisitor visitor) {
/* 45 */     visitor.visit((JConstructor)this);
/*    */   }
/*    */   public String getQualifiedName() {
/* 48 */     StringWriter sbuf = new StringWriter();
/* 49 */     sbuf.write(Modifier.toString(getModifiers()));
/* 50 */     sbuf.write(32);
/* 51 */     sbuf.write(getSimpleName());
/* 52 */     sbuf.write(40);
/*    */     
/* 54 */     JParameter[] params = getParameters();
/* 55 */     if (params != null && params.length > 0) {
/* 56 */       for (int i = 0; i < params.length; i++) {
/* 57 */         sbuf.write(params[i].getType().getQualifiedName());
/* 58 */         if (i < params.length - 1) sbuf.write(44);
/*    */       
/*    */       } 
/*    */     }
/* 62 */     sbuf.write(41);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 76 */     return sbuf.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\ConstructorImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */