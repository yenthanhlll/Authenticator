/*    */ package org.apache.xmlbeans.impl.jam.internal.javadoc;
/*    */ 
/*    */ import com.sun.javadoc.ClassDoc;
/*    */ import com.sun.javadoc.ExecutableMemberDoc;
/*    */ import com.sun.javadoc.Parameter;
/*    */ import com.sun.javadoc.ProgramElementDoc;
/*    */ import org.apache.xmlbeans.impl.jam.internal.TigerDelegate;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavadocTigerDelegate
/*    */   extends TigerDelegate
/*    */ {
/*    */   private static final String JAVADOC_DELEGATE_IMPL = "org.apache.xmlbeans.impl.jam.internal.javadoc.JavadocTigerDelegateImpl_150";
/*    */   public static final String ANNOTATION_DEFAULTS_DISABLED_PROPERTY = "ANNOTATION_DEFAULTS_DISABLED_PROPERTY";
/*    */   
/*    */   public static JavadocTigerDelegate create(JamLogger logger) {
/* 52 */     if (!isTigerJavadocAvailable(logger)) return null;
/*    */     
/*    */     try {
/* 55 */       JavadocTigerDelegate out = (JavadocTigerDelegate)Class.forName("org.apache.xmlbeans.impl.jam.internal.javadoc.JavadocTigerDelegateImpl_150").newInstance();
/*    */       
/* 57 */       out.init(logger);
/* 58 */       return out;
/* 59 */     } catch (ClassNotFoundException e) {
/* 60 */       issue14BuildWarning(e, logger);
/* 61 */     } catch (IllegalAccessException e) {
/* 62 */       logger.error(e);
/* 63 */     } catch (InstantiationException e) {
/* 64 */       logger.error(e);
/*    */     } 
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static JavadocTigerDelegate create(ElementContext ctx) {
/* 74 */     if (!isTigerJavadocAvailable(ctx.getLogger())) return null;
/*    */     
/*    */     try {
/* 77 */       JavadocTigerDelegate out = (JavadocTigerDelegate)Class.forName("org.apache.xmlbeans.impl.jam.internal.javadoc.JavadocTigerDelegateImpl_150").newInstance();
/*    */       
/* 79 */       out.init(ctx);
/* 80 */       return out;
/* 81 */     } catch (ClassNotFoundException e) {
/* 82 */       ctx.getLogger().error(e);
/* 83 */     } catch (IllegalAccessException e) {
/* 84 */       ctx.getLogger().error(e);
/* 85 */     } catch (InstantiationException e) {
/* 86 */       ctx.getLogger().error(e);
/*    */     } 
/* 88 */     return null;
/*    */   }
/*    */   
/*    */   public abstract boolean isEnum(ClassDoc paramClassDoc);
/*    */   
/*    */   public abstract void init(JamLogger paramJamLogger);
/*    */   
/*    */   public abstract void populateAnnotationTypeIfNecessary(ClassDoc paramClassDoc, MClass paramMClass, JavadocClassBuilder paramJavadocClassBuilder);
/*    */   
/*    */   public abstract void extractAnnotations(MAnnotatedElement paramMAnnotatedElement, ProgramElementDoc paramProgramElementDoc);
/*    */   
/*    */   public abstract void extractAnnotations(MAnnotatedElement paramMAnnotatedElement, ExecutableMemberDoc paramExecutableMemberDoc, Parameter paramParameter);
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\javadoc\JavadocTigerDelegate.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */