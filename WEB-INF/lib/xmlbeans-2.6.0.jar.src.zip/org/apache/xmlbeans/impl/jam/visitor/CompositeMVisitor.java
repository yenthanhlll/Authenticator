/*    */ package org.apache.xmlbeans.impl.jam.visitor;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MComment;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MPackage;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeMVisitor
/*    */   extends MVisitor
/*    */ {
/*    */   private MVisitor[] mVisitors;
/*    */   
/*    */   public CompositeMVisitor(MVisitor[] visitors) {
/* 42 */     if (visitors == null) throw new IllegalArgumentException("null visitors"); 
/* 43 */     this.mVisitors = visitors;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(MPackage pkg) {
/* 50 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(pkg); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MClass clazz) {
/* 54 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(clazz); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MConstructor ctor) {
/* 58 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(ctor); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MField field) {
/* 62 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(field); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MMethod method) {
/* 66 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(method); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MParameter param) {
/* 70 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(param); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MAnnotation ann) {
/* 74 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(ann); i++; }
/*    */   
/*    */   }
/*    */   public void visit(MComment comment) {
/* 78 */     for (int i = 0; i < this.mVisitors.length; ) { this.mVisitors[i].visit(comment); i++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\visitor\CompositeMVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */