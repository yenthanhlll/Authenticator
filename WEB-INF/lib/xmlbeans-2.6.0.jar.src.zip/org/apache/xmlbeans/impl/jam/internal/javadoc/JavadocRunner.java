/*     */ package org.apache.xmlbeans.impl.jam.internal.javadoc;
/*     */ 
/*     */ import com.sun.javadoc.Doclet;
/*     */ import com.sun.javadoc.RootDoc;
/*     */ import com.sun.tools.javadoc.Main;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocRunner
/*     */   extends Doclet
/*     */ {
/*     */   private static final String JAVADOC_RUNNER_150 = "org.apache.xmlbeans.impl.jam.internal.javadoc.JavadocRunner_150";
/*     */   
/*     */   public static JavadocRunner newInstance() {
/*     */     try {
/*  54 */       Class.forName("com.sun.javadoc.AnnotationDesc");
/*  55 */     } catch (ClassNotFoundException e) {
/*  56 */       return new JavadocRunner();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  61 */     try { Class onefive = Class.forName("org.apache.xmlbeans.impl.jam.internal.javadoc.JavadocRunner_150");
/*  62 */       return (JavadocRunner)onefive.newInstance(); }
/*  63 */     catch (ClassNotFoundException cnfe) {  }
/*  64 */     catch (IllegalAccessException e) {  }
/*  65 */     catch (InstantiationException e) {}
/*     */     
/*  67 */     return new JavadocRunner();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized RootDoc run(File[] files, PrintWriter out, String sourcePath, String classPath, String[] javadocArgs, JamLogger logger) throws IOException, FileNotFoundException {
/*     */     PrintWriter spewWriter;
/*  90 */     if (files == null || files.length == 0) {
/*  91 */       throw new FileNotFoundException("No input files found.");
/*     */     }
/*  93 */     List argList = new ArrayList();
/*  94 */     if (javadocArgs != null) {
/*  95 */       argList.addAll(Arrays.asList(javadocArgs));
/*     */     }
/*  97 */     argList.add("-private");
/*  98 */     if (sourcePath != null) {
/*  99 */       argList.add("-sourcepath");
/* 100 */       argList.add(sourcePath);
/*     */     } 
/* 102 */     if (classPath != null) {
/* 103 */       argList.add("-classpath");
/* 104 */       argList.add(classPath);
/* 105 */       argList.add("-docletpath");
/* 106 */       argList.add(classPath);
/*     */     } 
/* 108 */     for (int i = 0; i < files.length; i++) {
/* 109 */       argList.add(files[i].toString());
/* 110 */       if (out != null) out.println(files[i].toString()); 
/*     */     } 
/* 112 */     String[] args = new String[argList.size()];
/* 113 */     argList.toArray(args);
/*     */ 
/*     */ 
/*     */     
/* 117 */     StringWriter spew = null;
/* 118 */     if (out == null) {
/* 119 */       spewWriter = new PrintWriter(spew = new StringWriter());
/*     */     } else {
/* 121 */       spewWriter = out;
/*     */     } 
/* 123 */     ClassLoader originalCCL = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 125 */       JavadocResults.prepare();
/* 126 */       if (logger.isVerbose(this)) {
/* 127 */         logger.verbose("Invoking javadoc.  Command line equivalent is: ");
/* 128 */         StringWriter sw = new StringWriter();
/* 129 */         sw.write("javadoc ");
/* 130 */         for (int j = 0; j < args.length; j++) {
/* 131 */           sw.write("'");
/* 132 */           sw.write(args[j]);
/* 133 */           sw.write("' ");
/*     */         } 
/* 135 */         logger.verbose("  " + sw.toString());
/*     */       } 
/* 137 */       int result = Main.execute("JAM", spewWriter, spewWriter, spewWriter, getClass().getName(), args);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       RootDoc root = JavadocResults.getRoot();
/* 144 */       if (result != 0 || root == null) {
/* 145 */         spewWriter.flush();
/* 146 */         if (JavadocClassloadingException.isClassloadingProblemPresent()) {
/* 147 */           throw new JavadocClassloadingException();
/*     */         }
/* 149 */         throw new RuntimeException("Unknown javadoc problem: result=" + result + ", root=" + root + ":\n" + ((spew == null) ? "" : spew.toString()));
/*     */       } 
/*     */ 
/*     */       
/* 153 */       return root;
/* 154 */     } catch (RuntimeException e) {
/* 155 */       throw e;
/*     */     } finally {
/*     */       
/* 158 */       Thread.currentThread().setContextClassLoader(originalCCL);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean start(RootDoc root) {
/* 166 */     JavadocResults.setRoot(root);
/* 167 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\javadoc\JavadocRunner.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */