/*     */ package org.apache.xmlbeans.impl.jam.annotation;
/*     */ 
/*     */ import com.sun.javadoc.Tag;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WhitespaceDelimitedTagParser
/*     */   extends JavadocTagParser
/*     */ {
/*     */   public void parse(MAnnotatedElement target, Tag tag) {
/*  34 */     MAnnotation[] anns = createAnnotations(target, tag);
/*  35 */     String tagText = tag.text();
/*  36 */     if (tagText == null)
/*  37 */       return;  tagText = tagText.trim();
/*  38 */     if (tagText.length() == 0)
/*  39 */       return;  Properties props = new Properties();
/*  40 */     parseAssignments(props, tagText);
/*  41 */     if (props.size() > 0) {
/*  42 */       Enumeration names = props.propertyNames();
/*  43 */       while (names.hasMoreElements()) {
/*  44 */         String name = (String)names.nextElement();
/*  45 */         setValue(anns, name, props.getProperty(name));
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  51 */       setSingleValueText(anns, tag);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAssignments(Properties out, String line) {
/*  74 */     getLogger().verbose("PARSING LINE " + line, this);
/*  75 */     String originalLine = line;
/*  76 */     line = removeComments(line);
/*  77 */     while (null != line && -1 != line.indexOf("=")) {
/*  78 */       int keyStart = -1;
/*  79 */       int keyEnd = -1;
/*  80 */       int ind = 0;
/*     */       
/*  82 */       char c = line.charAt(ind);
/*  83 */       while (isBlank(c)) {
/*  84 */         ind++;
/*  85 */         c = line.charAt(ind);
/*     */       } 
/*  87 */       keyStart = ind;
/*  88 */       for (; isLegal(line.charAt(ind)); ind++);
/*  89 */       keyEnd = ind;
/*  90 */       String key = line.substring(keyStart, keyEnd);
/*  91 */       ind = line.indexOf("=");
/*  92 */       if (ind == -1) {
/*     */         return;
/*     */       }
/*     */       
/*  96 */       ind++;
/*     */       
/*     */       try {
/*  99 */         c = line.charAt(ind);
/*     */       }
/* 101 */       catch (StringIndexOutOfBoundsException ex) {
/* 102 */         ex.printStackTrace();
/*     */       } 
/* 104 */       while (isBlank(c)) {
/* 105 */         ind++;
/* 106 */         c = line.charAt(ind);
/*     */       } 
/*     */ 
/*     */       
/* 110 */       int valueStart = -1;
/* 111 */       int valueEnd = -1;
/* 112 */       if (c == '"') {
/* 113 */         valueStart = ++ind;
/* 114 */         while ('"' != line.charAt(ind)) {
/* 115 */           ind++;
/* 116 */           if (ind >= line.length()) {
/* 117 */             getLogger().verbose("missing double quotes on line " + line, this);
/*     */           }
/*     */         } 
/* 120 */         valueEnd = ind;
/*     */       } else {
/*     */         
/* 123 */         valueStart = ind++;
/* 124 */         for (; ind < line.length() && isLegal(line.charAt(ind)); ind++);
/* 125 */         valueEnd = ind;
/*     */       } 
/* 127 */       String value = line.substring(valueStart, valueEnd);
/* 128 */       if (ind < line.length()) {
/* 129 */         line = line.substring(ind + 1);
/*     */       } else {
/*     */         
/* 132 */         line = null;
/*     */       } 
/* 134 */       getLogger().verbose("SETTING KEY:" + key + " VALUE:" + value, this);
/* 135 */       out.setProperty(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String removeComments(String value) {
/* 145 */     String result = "";
/* 146 */     int size = value.length();
/* 147 */     String current = value;
/*     */     
/* 149 */     int currentIndex = 0;
/*     */     
/* 151 */     int beginning = current.indexOf("//");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     int doubleQuotesIndex = current.indexOf("\"");
/* 157 */     if (-1 != doubleQuotesIndex && doubleQuotesIndex < beginning) {
/*     */       
/* 159 */       result = value;
/*     */     } else {
/*     */       
/* 162 */       while (currentIndex < size && beginning != -1) {
/* 163 */         beginning = value.indexOf("//", currentIndex);
/* 164 */         if (-1 != beginning) {
/* 165 */           if (beginning > 0 && value.charAt(beginning - 1) == ':') {
/*     */ 
/*     */ 
/*     */             
/* 169 */             currentIndex = beginning + 2;
/*     */             continue;
/*     */           } 
/* 172 */           int end = value.indexOf('\n', beginning);
/* 173 */           if (-1 == end) end = size;
/*     */ 
/*     */           
/* 176 */           result = result + value.substring(currentIndex, beginning).trim() + "\n";
/* 177 */           current = value.substring(end);
/* 178 */           currentIndex = end;
/*     */         } 
/*     */       } 
/* 181 */       result = result + current;
/*     */     } 
/*     */     
/* 184 */     return result.trim();
/*     */   }
/*     */   
/*     */   private boolean isBlank(char c) {
/* 188 */     return (c == ' ' || c == '\t' || c == '\n');
/*     */   }
/*     */   
/*     */   private boolean isLegal(char c) {
/* 192 */     return (!isBlank(c) && c != '=');
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\annotation\WhitespaceDelimitedTagParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */