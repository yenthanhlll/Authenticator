/*    */ package org.apache.xmlbeans.impl.jam.internal;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedClassBuilder
/*    */   extends JamClassBuilder
/*    */ {
/* 38 */   private Map mQcname2jclass = null;
/* 39 */   private List mClassNames = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MClass build(String packageName, String className) {
/* 50 */     if (this.mQcname2jclass == null) return null; 
/* 51 */     if (packageName.trim().length() > 0) {
/* 52 */       className = packageName + '.' + className;
/*    */     }
/* 54 */     return (MClass)this.mQcname2jclass.get(className);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MClass createClassToBuild(String packageName, String className, String[] importSpecs) {
/*    */     String qualifiedName;
/* 64 */     if (packageName.trim().length() > 0) {
/* 65 */       qualifiedName = packageName + '.' + className;
/*    */     } else {
/* 67 */       qualifiedName = className;
/*    */     } 
/*    */     
/* 70 */     if (this.mQcname2jclass != null) {
/* 71 */       MClass mClass = (MClass)this.mQcname2jclass.get(qualifiedName);
/* 72 */       if (mClass != null) return mClass; 
/*    */     } else {
/* 74 */       this.mQcname2jclass = new HashMap();
/*    */     } 
/* 76 */     MClass out = super.createClassToBuild(packageName, className, importSpecs);
/* 77 */     this.mQcname2jclass.put(qualifiedName, out);
/* 78 */     this.mClassNames.add(qualifiedName);
/* 79 */     return out;
/*    */   }
/*    */   
/*    */   public String[] getClassNames() {
/* 83 */     String[] out = new String[this.mClassNames.size()];
/* 84 */     this.mClassNames.toArray((Object[])out);
/* 85 */     return out;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\CachedClassBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */