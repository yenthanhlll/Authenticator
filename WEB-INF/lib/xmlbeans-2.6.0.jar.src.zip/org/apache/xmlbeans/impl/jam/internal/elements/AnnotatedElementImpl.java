/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JComment;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.AnnotationProxy;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MComment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotatedElementImpl
/*     */   extends ElementImpl
/*     */   implements MAnnotatedElement
/*     */ {
/*  26 */   private Map mName2Annotation = null;
/*  27 */   private MComment mComment = null;
/*  28 */   private List mAllAnnotations = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedElementImpl(ElementContext ctx) {
/*  33 */     super(ctx);
/*     */   } protected AnnotatedElementImpl(ElementImpl parent) {
/*  35 */     super(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JAnnotation[] getAnnotations() {
/*  41 */     return (JAnnotation[])getMutableAnnotations();
/*     */   }
/*     */   
/*     */   public JAnnotation getAnnotation(Class proxyClass) {
/*  45 */     return (JAnnotation)getMutableAnnotation(proxyClass.getName());
/*     */   }
/*     */   
/*     */   public JAnnotation getAnnotation(String named) {
/*  49 */     return (JAnnotation)getMutableAnnotation(named);
/*     */   }
/*     */   
/*     */   public JAnnotationValue getAnnotationValue(String valueId) {
/*  53 */     if (this.mName2Annotation == null) return null; 
/*  54 */     valueId = valueId.trim();
/*     */     
/*  56 */     int delim = valueId.indexOf('@');
/*  57 */     if (delim == -1 || delim == valueId.length() - 1) {
/*  58 */       JAnnotation jAnnotation = getAnnotation(valueId);
/*  59 */       if (jAnnotation == null) return null; 
/*  60 */       return jAnnotation.getValue("value");
/*     */     } 
/*  62 */     JAnnotation ann = getAnnotation(valueId.substring(0, delim));
/*  63 */     if (ann == null) return null;
/*     */     
/*  65 */     return ann.getValue(valueId.substring(delim + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAnnotationProxy(Class proxyClass) {
/*  71 */     return getEditableProxy(proxyClass);
/*     */   }
/*     */   public JComment getComment() {
/*  74 */     return (JComment)getMutableComment();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JAnnotation[] getAllJavadocTags() {
/*  80 */     if (this.mAllAnnotations == null) return (JAnnotation[])NO_ANNOTATION; 
/*  81 */     JAnnotation[] out = new JAnnotation[this.mAllAnnotations.size()];
/*  82 */     this.mAllAnnotations.toArray((Object[])out);
/*  83 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationProxy getEditableProxy(Class proxyClass) {
/* 107 */     if (this.mName2Annotation == null) return null; 
/* 108 */     MAnnotation out = getMutableAnnotation(proxyClass.getName());
/* 109 */     return (out == null) ? null : (AnnotationProxy)out.getProxy();
/*     */   }
/*     */   
/*     */   public void removeAnnotation(MAnnotation ann) {
/* 113 */     if (this.mName2Annotation != null) this.mName2Annotation.values().remove(ann); 
/*     */   }
/*     */   
/*     */   public MAnnotation[] getMutableAnnotations() {
/* 117 */     if (this.mName2Annotation == null) return new MAnnotation[0]; 
/* 118 */     MAnnotation[] out = new MAnnotation[this.mName2Annotation.values().size()];
/* 119 */     this.mName2Annotation.values().toArray((Object[])out);
/* 120 */     return out;
/*     */   }
/*     */   
/*     */   public MAnnotation getMutableAnnotation(String named) {
/* 124 */     if (this.mName2Annotation == null) return null; 
/* 125 */     named = named.trim();
/* 126 */     return (MAnnotation)this.mName2Annotation.get(named);
/*     */   }
/*     */ 
/*     */   
/*     */   public MAnnotation findOrCreateAnnotation(String annotationName) {
/* 131 */     MAnnotation ann = getMutableAnnotation(annotationName);
/* 132 */     if (ann != null) return ann; 
/* 133 */     AnnotationProxy proxy = getContext().createAnnotationProxy(annotationName);
/*     */     
/* 135 */     ann = new AnnotationImpl(getContext(), proxy, annotationName);
/* 136 */     if (this.mName2Annotation == null) {
/* 137 */       this.mName2Annotation = new HashMap();
/*     */     }
/* 139 */     this.mName2Annotation.put(ann.getQualifiedName(), ann);
/* 140 */     return ann;
/*     */   }
/*     */   
/*     */   public MAnnotation addLiteralAnnotation(String annName) {
/* 144 */     if (annName == null) throw new IllegalArgumentException("null tagname"); 
/* 145 */     annName = annName.trim();
/*     */ 
/*     */ 
/*     */     
/* 149 */     AnnotationProxy proxy = getContext().createAnnotationProxy(annName);
/* 150 */     MAnnotation ann = new AnnotationImpl(getContext(), proxy, annName);
/* 151 */     if (this.mAllAnnotations == null) this.mAllAnnotations = new ArrayList(); 
/* 152 */     this.mAllAnnotations.add(ann);
/*     */ 
/*     */     
/* 155 */     if (getMutableAnnotation(annName) == null) {
/* 156 */       if (this.mName2Annotation == null) this.mName2Annotation = new HashMap(); 
/* 157 */       this.mName2Annotation.put(annName, ann);
/*     */     } 
/* 159 */     return ann;
/*     */   }
/*     */   public MComment getMutableComment() {
/* 162 */     return this.mComment;
/*     */   } public MComment createComment() {
/* 164 */     return this.mComment = new CommentImpl(this);
/*     */   } public void removeComment() {
/* 166 */     this.mComment = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addAnnotation(JAnnotation ann) {
/* 174 */     if (this.mName2Annotation == null) {
/* 175 */       this.mName2Annotation = new HashMap();
/* 176 */       this.mName2Annotation.put(ann.getQualifiedName(), ann);
/*     */     }
/* 178 */     else if (this.mName2Annotation.get(ann.getQualifiedName()) == null) {
/* 179 */       this.mName2Annotation.put(ann.getQualifiedName(), ann);
/*     */     } 
/*     */     
/* 182 */     if (this.mAllAnnotations == null) this.mAllAnnotations = new ArrayList(); 
/* 183 */     this.mAllAnnotations.add(ann);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MAnnotation addAnnotationForProxy(Class proxyClass, AnnotationProxy proxy) {
/* 199 */     String annotationName = proxyClass.getName();
/* 200 */     MAnnotation ann = getMutableAnnotation(annotationName);
/* 201 */     if (ann != null) return ann; 
/* 202 */     ann = new AnnotationImpl(getContext(), proxy, annotationName);
/* 203 */     if (this.mName2Annotation == null) {
/* 204 */       this.mName2Annotation = new HashMap();
/*     */     }
/* 206 */     this.mName2Annotation.put(ann.getQualifiedName(), ann);
/* 207 */     return ann;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\AnnotatedElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */