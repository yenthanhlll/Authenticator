/*    */ package org.apache.xmlbeans.impl.jam.internal.javadoc;
/*    */ 
/*    */ import com.sun.javadoc.ClassDoc;
/*    */ import com.sun.javadoc.ExecutableMemberDoc;
/*    */ import com.sun.javadoc.Parameter;
/*    */ import com.sun.javadoc.ProgramElementDoc;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavadocTigerDelegateImpl_150
/*    */   extends JavadocTigerDelegate
/*    */ {
/*    */   public void init(ElementContext ctx) {}
/*    */   
/*    */   public void init(JamLogger logger) {}
/*    */   
/*    */   public void populateAnnotationTypeIfNecessary(ClassDoc cd, MClass clazz, JavadocClassBuilder builder) {}
/*    */   
/*    */   public void extractAnnotations(MAnnotatedElement dest, ProgramElementDoc src) {}
/*    */   
/*    */   public void extractAnnotations(MAnnotatedElement dest, ExecutableMemberDoc method, Parameter src) {}
/*    */   
/*    */   public boolean isEnum(ClassDoc cd) {
/* 63 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\javadoc\JavadocTigerDelegateImpl_150.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */