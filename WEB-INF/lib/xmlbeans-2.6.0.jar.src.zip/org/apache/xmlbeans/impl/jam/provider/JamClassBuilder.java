/*     */ package org.apache.xmlbeans.impl.jam.provider;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JamClassBuilder
/*     */ {
/*  34 */   private ElementContext mContext = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ElementContext ctx) {
/*  47 */     if (this.mContext != null) {
/*  48 */       throw new IllegalStateException("init called more than once");
/*     */     }
/*  50 */     if (ctx == null) throw new IllegalArgumentException("null ctx"); 
/*  51 */     this.mContext = ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract MClass build(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MClass createClassToBuild(String packageName, String className, String[] importSpecs, JamClassPopulator pop) {
/* 100 */     if (this.mContext == null) throw new IllegalStateException("init not called"); 
/* 101 */     if (packageName == null) throw new IllegalArgumentException("null pkg"); 
/* 102 */     if (className == null) throw new IllegalArgumentException("null class"); 
/* 103 */     if (pop == null) throw new IllegalArgumentException("null pop"); 
/* 104 */     assertInitialized();
/* 105 */     className = className.replace('.', '$');
/* 106 */     ClassImpl out = new ClassImpl(packageName, className, this.mContext, importSpecs, pop);
/* 107 */     return (MClass)out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MClass createClassToBuild(String packageName, String className, String[] importSpecs) {
/* 127 */     if (this.mContext == null) throw new IllegalStateException("init not called"); 
/* 128 */     if (packageName == null) throw new IllegalArgumentException("null pkg"); 
/* 129 */     if (className == null) throw new IllegalArgumentException("null class"); 
/* 130 */     assertInitialized();
/* 131 */     className = className.replace('.', '$');
/* 132 */     ClassImpl out = new ClassImpl(packageName, className, this.mContext, importSpecs);
/* 133 */     return (MClass)out;
/*     */   }
/*     */   protected JamLogger getLogger() {
/* 136 */     return (JamLogger)this.mContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void assertInitialized() {
/* 143 */     if (this.mContext == null)
/* 144 */       throw new IllegalStateException(this + " not yet initialized."); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\provider\JamClassBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */