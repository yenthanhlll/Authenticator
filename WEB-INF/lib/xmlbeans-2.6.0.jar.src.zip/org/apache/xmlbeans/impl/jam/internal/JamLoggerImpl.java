/*     */ package org.apache.xmlbeans.impl.jam.internal;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JamLoggerImpl
/*     */   implements JamLogger
/*     */ {
/*     */   private boolean mShowWarnings = true;
/*  33 */   private Set mVerboseClasses = null;
/*  34 */   private PrintWriter mOut = new PrintWriter(System.out, true);
/*     */   
/*     */   protected void setOut(PrintWriter out) {
/*  37 */     this.mOut = out;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVerbose(Object o) {
/*  43 */     if (this.mVerboseClasses == null) return false; 
/*  44 */     Iterator i = this.mVerboseClasses.iterator();
/*  45 */     while (i.hasNext()) {
/*  46 */       Class c = i.next();
/*  47 */       if (c.isAssignableFrom(o.getClass())) return true; 
/*     */     } 
/*  49 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isVerbose(Class aClass) {
/*  53 */     if (this.mVerboseClasses == null) return false; 
/*  54 */     Iterator i = this.mVerboseClasses.iterator();
/*  55 */     while (i.hasNext()) {
/*  56 */       Class c = i.next();
/*  57 */       if (c.isAssignableFrom(aClass)) return true; 
/*     */     } 
/*  59 */     return false;
/*     */   }
/*     */   
/*     */   public void setVerbose(Class c) {
/*  63 */     if (c == null) throw new IllegalArgumentException(); 
/*  64 */     if (this.mVerboseClasses == null) this.mVerboseClasses = new HashSet(); 
/*  65 */     this.mVerboseClasses.add(c);
/*     */   }
/*     */   
/*     */   public void setShowWarnings(boolean b) {
/*  69 */     this.mShowWarnings = b;
/*     */   }
/*     */   
/*     */   public void verbose(String msg, Object o) {
/*  73 */     if (isVerbose(o)) verbose(msg); 
/*     */   }
/*     */   
/*     */   public void verbose(Throwable t, Object o) {
/*  77 */     if (isVerbose(o)) verbose(t); 
/*     */   }
/*     */   
/*     */   public void verbose(String msg) {
/*  81 */     printVerbosePrefix();
/*  82 */     this.mOut.println(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void verbose(Throwable t) {
/*  87 */     printVerbosePrefix();
/*  88 */     this.mOut.println();
/*  89 */     t.printStackTrace(this.mOut);
/*     */   }
/*     */   
/*     */   public void warning(Throwable t) {
/*  93 */     if (this.mShowWarnings) {
/*  94 */       this.mOut.println("[JAM] Warning: unexpected exception thrown: ");
/*  95 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void warning(String w) {
/* 100 */     if (this.mShowWarnings) {
/*     */       
/* 102 */       this.mOut.print("[JAM] Warning: ");
/* 103 */       this.mOut.println(w);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void error(Throwable t) {
/* 108 */     this.mOut.println("[JAM] Error: unexpected exception thrown: ");
/* 109 */     t.printStackTrace(this.mOut);
/*     */   }
/*     */   
/*     */   public void error(String msg) {
/* 113 */     this.mOut.print("[JAM] Error: ");
/* 114 */     this.mOut.println(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerbose(boolean v) {
/* 120 */     setVerbose(Object.class);
/*     */   } public boolean isVerbose() {
/* 122 */     return (this.mVerboseClasses != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void printVerbosePrefix() {
/* 128 */     StackTraceElement[] st = (new Exception()).getStackTrace();
/* 129 */     this.mOut.println("[JAM] Verbose: ");
/* 130 */     this.mOut.print('(');
/* 131 */     this.mOut.print(shortName(st[2].getClassName()));
/* 132 */     this.mOut.print('.');
/* 133 */     this.mOut.print(st[2].getMethodName());
/* 134 */     this.mOut.print(':');
/* 135 */     this.mOut.print(st[2].getLineNumber());
/* 136 */     this.mOut.print(")  ");
/*     */   }
/*     */   
/*     */   private static String shortName(String className) {
/* 140 */     int index = className.lastIndexOf('.');
/*     */     
/* 142 */     if (index != -1) {
/* 143 */       className = className.substring(index + 1, className.length());
/*     */     }
/*     */     
/* 146 */     return className;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\JamLoggerImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */