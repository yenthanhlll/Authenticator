/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JPackage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnresolvedClassImpl
/*    */   extends BuiltinClassImpl
/*    */ {
/*    */   private String mPackageName;
/*    */   
/*    */   public UnresolvedClassImpl(String packageName, String simpleName, ElementContext ctx) {
/* 40 */     super(ctx);
/* 41 */     if (packageName == null) throw new IllegalArgumentException("null pkg"); 
/* 42 */     this.mPackageName = packageName;
/* 43 */     reallySetSimpleName(simpleName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getQualifiedName() {
/* 50 */     return ((this.mPackageName.length() > 0) ? (this.mPackageName + '.') : "") + this.mSimpleName;
/*    */   }
/*    */   
/*    */   public String getFieldDescriptor() {
/* 54 */     return getQualifiedName();
/*    */   } public JPackage getContainingPackage() {
/* 56 */     return null;
/*    */   } public boolean isAssignableFrom(JClass c) {
/* 58 */     return false;
/*    */   } public boolean isUnresolvedType() {
/* 60 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\UnresolvedClassImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */