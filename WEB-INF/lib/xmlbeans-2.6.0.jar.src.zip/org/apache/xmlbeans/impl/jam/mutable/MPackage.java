package org.apache.xmlbeans.impl.jam.mutable;

import org.apache.xmlbeans.impl.jam.JPackage;

public interface MPackage extends JPackage, MAnnotatedElement {
  MClass[] getMutableClasses();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\mutable\MPackage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */