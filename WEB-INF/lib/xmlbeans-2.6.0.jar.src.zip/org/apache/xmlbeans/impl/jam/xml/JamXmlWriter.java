/*     */ package org.apache.xmlbeans.impl.jam.xml;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JComment;
/*     */ import org.apache.xmlbeans.impl.jam.JConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.JField;
/*     */ import org.apache.xmlbeans.impl.jam.JInvokable;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JParameter;
/*     */ import org.apache.xmlbeans.impl.jam.JSourcePosition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JamXmlWriter
/*     */   implements JamXmlElements
/*     */ {
/*     */   private XMLStreamWriter mOut;
/*     */   private boolean mInBody = false;
/*     */   private boolean mWriteSourceURI = false;
/*     */   
/*     */   public JamXmlWriter(Writer out) throws XMLStreamException {
/*  50 */     if (out == null) throw new IllegalArgumentException("null out"); 
/*  51 */     this.mOut = XMLOutputFactory.newInstance().createXMLStreamWriter(out);
/*     */   }
/*     */   
/*     */   public JamXmlWriter(XMLStreamWriter out) {
/*  55 */     if (out == null) throw new IllegalArgumentException("null out"); 
/*  56 */     this.mOut = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void begin() throws XMLStreamException {
/*  64 */     if (this.mInBody) throw new XMLStreamException("begin() already called"); 
/*  65 */     this.mOut.writeStartElement("jam-service");
/*  66 */     this.mInBody = true;
/*     */   }
/*     */   
/*     */   public void end() throws XMLStreamException {
/*  70 */     if (!this.mInBody) throw new XMLStreamException("begin() never called"); 
/*  71 */     this.mOut.writeEndElement();
/*  72 */     this.mInBody = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(JClass clazz) throws XMLStreamException {
/*  87 */     assertStarted();
/*  88 */     this.mOut.writeStartElement("class");
/*  89 */     writeValueElement("name", clazz.getFieldDescriptor());
/*  90 */     writeValueElement("is-interface", clazz.isInterface());
/*  91 */     writeModifiers(clazz.getModifiers());
/*  92 */     JClass sc = clazz.getSuperclass();
/*  93 */     if (sc != null) writeValueElement("superclass", sc.getFieldDescriptor()); 
/*  94 */     writeClassList("interface", clazz.getInterfaces());
/*     */     
/*  96 */     JField[] f = clazz.getDeclaredFields(); int i;
/*  97 */     for (i = 0; i < f.length; ) { write(f[i]); i++; }
/*     */     
/*  99 */     JConstructor[] c = clazz.getConstructors();
/* 100 */     for (i = 0; i < c.length; ) { write(c[i]); i++; }
/*     */     
/* 102 */     JMethod[] m = clazz.getDeclaredMethods();
/* 103 */     for (i = 0; i < m.length; ) { write(m[i]); i++; }
/*     */ 
/*     */     
/* 106 */     writeAnnotatedElement((JAnnotatedElement)clazz);
/* 107 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void write(JMethod method) throws XMLStreamException {
/* 115 */     this.mOut.writeStartElement("method");
/* 116 */     writeValueElement("name", method.getSimpleName());
/* 117 */     writeValueElement("return-type", method.getReturnType().getFieldDescriptor());
/*     */     
/* 119 */     writeInvokable((JInvokable)method);
/* 120 */     this.mOut.writeEndElement();
/*     */   }
/*     */   
/*     */   private void write(JConstructor ctor) throws XMLStreamException {
/* 124 */     this.mOut.writeStartElement("constructor");
/* 125 */     writeInvokable((JInvokable)ctor);
/* 126 */     this.mOut.writeEndElement();
/*     */   }
/*     */   
/*     */   private void write(JField field) throws XMLStreamException {
/* 130 */     this.mOut.writeStartElement("field");
/* 131 */     writeValueElement("name", field.getSimpleName());
/* 132 */     writeModifiers(field.getModifiers());
/* 133 */     writeValueElement("type", field.getType().getFieldDescriptor());
/* 134 */     writeAnnotatedElement((JAnnotatedElement)field);
/* 135 */     this.mOut.writeEndElement();
/*     */   }
/*     */   
/*     */   private void writeInvokable(JInvokable ji) throws XMLStreamException {
/* 139 */     writeModifiers(ji.getModifiers());
/* 140 */     JParameter[] params = ji.getParameters();
/* 141 */     for (int i = 0; i < params.length; i++) {
/* 142 */       this.mOut.writeStartElement("parameter");
/* 143 */       writeValueElement("name", params[i].getSimpleName());
/* 144 */       writeValueElement("type", params[i].getType().getFieldDescriptor());
/* 145 */       writeAnnotatedElement((JAnnotatedElement)params[i]);
/* 146 */       this.mOut.writeEndElement();
/*     */     } 
/* 148 */     writeAnnotatedElement((JAnnotatedElement)ji);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeClassList(String elementName, JClass[] clazzes) throws XMLStreamException {
/* 154 */     for (int i = 0; i < clazzes.length; i++) {
/* 155 */       this.mOut.writeStartElement(elementName);
/* 156 */       this.mOut.writeCharacters(clazzes[i].getFieldDescriptor());
/* 157 */       this.mOut.writeEndElement();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeModifiers(int mods) throws XMLStreamException {
/* 162 */     this.mOut.writeStartElement("modifiers");
/* 163 */     this.mOut.writeCharacters(String.valueOf(mods));
/* 164 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeValueElement(String elementName, boolean b) throws XMLStreamException {
/* 170 */     this.mOut.writeStartElement(elementName);
/* 171 */     this.mOut.writeCharacters(String.valueOf(b));
/* 172 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeValueElement(String elementName, int x) throws XMLStreamException {
/* 178 */     this.mOut.writeStartElement(elementName);
/* 179 */     this.mOut.writeCharacters(String.valueOf(x));
/* 180 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeValueElement(String elementName, String val) throws XMLStreamException {
/* 186 */     this.mOut.writeStartElement(elementName);
/* 187 */     this.mOut.writeCharacters(val);
/* 188 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeValueElement(String elementName, String[] vals) throws XMLStreamException {
/* 194 */     for (int i = 0; i < vals.length; ) { writeValueElement(elementName, vals[i]); i++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeAnnotatedElement(JAnnotatedElement ae) throws XMLStreamException {
/* 201 */     JAnnotation[] anns = ae.getAnnotations();
/* 202 */     for (int i = 0; i < anns.length; i++) {
/* 203 */       writeAnnotation(anns[i]);
/*     */     }
/* 205 */     JComment jc = ae.getComment();
/* 206 */     if (jc != null) {
/* 207 */       String text = jc.getText();
/* 208 */       if (text != null) {
/* 209 */         text = text.trim();
/* 210 */         if (text.length() > 0) {
/* 211 */           this.mOut.writeStartElement("comment");
/* 212 */           this.mOut.writeCData(jc.getText());
/* 213 */           this.mOut.writeEndElement();
/*     */         } 
/*     */       } 
/*     */     } 
/* 217 */     JSourcePosition pos = ae.getSourcePosition();
/* 218 */     if (pos != null) {
/* 219 */       this.mOut.writeStartElement("source-position");
/* 220 */       if (pos.getLine() != -1) {
/* 221 */         writeValueElement("line", pos.getLine());
/*     */       }
/* 223 */       if (pos.getColumn() != -1) {
/* 224 */         writeValueElement("column", pos.getColumn());
/*     */       }
/* 226 */       if (this.mWriteSourceURI && pos.getSourceURI() != null)
/* 227 */         writeValueElement("source-uri", pos.getSourceURI().toString()); 
/* 228 */       this.mOut.writeEndElement();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeAnnotation(JAnnotation ann) throws XMLStreamException {
/* 233 */     this.mOut.writeStartElement("annotation");
/* 234 */     writeValueElement("name", ann.getQualifiedName());
/* 235 */     JAnnotationValue[] values = ann.getValues();
/* 236 */     for (int i = 0; i < values.length; i++) {
/* 237 */       writeAnnotationValue(values[i]);
/*     */     }
/* 239 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeAnnotationValue(JAnnotationValue val) throws XMLStreamException {
/* 245 */     this.mOut.writeStartElement("annotation-value");
/* 246 */     writeValueElement("name", val.getName());
/* 247 */     writeValueElement("type", val.getType().getFieldDescriptor());
/* 248 */     if (val.getType().isArrayType()) {
/* 249 */       writeValueElement("value", val.asStringArray());
/*     */     } else {
/* 251 */       writeValueElement("value", val.asString());
/*     */     } 
/*     */     
/* 254 */     this.mOut.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertStarted() throws XMLStreamException {
/* 266 */     if (!this.mInBody) throw new XMLStreamException("begin() not called"); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\xml\JamXmlWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */