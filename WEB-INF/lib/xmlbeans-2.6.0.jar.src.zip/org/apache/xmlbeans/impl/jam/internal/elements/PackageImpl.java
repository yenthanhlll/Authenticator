/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JPackage;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MPackage;
/*    */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*    */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageImpl
/*    */   extends AnnotatedElementImpl
/*    */   implements MPackage
/*    */ {
/* 40 */   private List mRootClasses = new ArrayList();
/*    */ 
/*    */   
/*    */   private String mName;
/*    */ 
/*    */   
/*    */   public PackageImpl(ElementContext ctx, String name) {
/* 47 */     super(ctx);
/* 48 */     this.mName = name;
/* 49 */     int lastDot = this.mName.lastIndexOf('.');
/* 50 */     setSimpleName((lastDot == -1) ? this.mName : this.mName.substring(lastDot + 1));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getQualifiedName() {
/* 56 */     return this.mName;
/*    */   } public void accept(MVisitor visitor) {
/* 58 */     visitor.visit(this);
/*    */   } public void accept(JVisitor visitor) {
/* 60 */     visitor.visit((JPackage)this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JClass[] getClasses() {
/* 66 */     JClass[] out = new JClass[this.mRootClasses.size()];
/* 67 */     this.mRootClasses.toArray((Object[])out);
/* 68 */     return out;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MClass[] getMutableClasses() {
/* 75 */     MClass[] out = new MClass[this.mRootClasses.size()];
/* 76 */     this.mRootClasses.toArray((Object[])out);
/* 77 */     return out;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\PackageImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */