/*     */ package org.apache.xmlbeans.impl.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.Filer;
/*     */ import repackage.Repackager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilerImpl
/*     */   implements Filer
/*     */ {
/*     */   private File classdir;
/*     */   private File srcdir;
/*     */   private Repackager repackager;
/*     */   private boolean verbose;
/*     */   private List sourceFiles;
/*     */   private boolean incrSrcGen;
/*     */   private Set seenTypes;
/*     */   private static final Charset CHARSET;
/*     */   
/*     */   static {
/*  56 */     Charset temp = null;
/*     */     
/*     */     try {
/*  59 */       temp = Charset.forName(System.getProperty("file.encoding"));
/*     */     }
/*  61 */     catch (Exception e) {}
/*  62 */     CHARSET = temp;
/*     */   }
/*     */ 
/*     */   
/*     */   public FilerImpl(File classdir, File srcdir, Repackager repackager, boolean verbose, boolean incrSrcGen) {
/*  67 */     this.classdir = classdir;
/*  68 */     this.srcdir = srcdir;
/*  69 */     this.repackager = repackager;
/*  70 */     this.verbose = verbose;
/*  71 */     this.sourceFiles = (this.sourceFiles != null) ? this.sourceFiles : new ArrayList();
/*  72 */     this.incrSrcGen = incrSrcGen;
/*  73 */     if (this.incrSrcGen) {
/*  74 */       this.seenTypes = new HashSet();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream createBinaryFile(String typename) throws IOException {
/*  86 */     if (this.verbose) {
/*  87 */       System.err.println("created binary: " + typename);
/*     */     }
/*     */     
/*  90 */     File source = new File(this.classdir, typename);
/*  91 */     source.getParentFile().mkdirs();
/*     */     
/*  93 */     return new FileOutputStream(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer createSourceFile(String typename) throws IOException {
/* 105 */     if (this.incrSrcGen) {
/* 106 */       this.seenTypes.add(typename);
/*     */     }
/* 108 */     if (typename.indexOf('$') > 0)
/*     */     {
/* 110 */       typename = typename.substring(0, typename.lastIndexOf('.')) + "." + typename.substring(typename.indexOf('$') + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 115 */     String filename = typename.replace('.', File.separatorChar) + ".java";
/*     */     
/* 117 */     File sourcefile = new File(this.srcdir, filename);
/* 118 */     sourcefile.getParentFile().mkdirs();
/* 119 */     if (this.verbose) {
/* 120 */       System.err.println("created source: " + sourcefile.getAbsolutePath());
/*     */     }
/* 122 */     this.sourceFiles.add(sourcefile);
/*     */     
/* 124 */     if (this.incrSrcGen && sourcefile.exists())
/*     */     {
/*     */ 
/*     */       
/* 128 */       return new IncrFileWriter(sourcefile, this.repackager);
/*     */     }
/*     */ 
/*     */     
/* 132 */     return (this.repackager == null) ? writerForFile(sourcefile) : new RepackagingWriter(sourcefile, this.repackager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getSourceFiles() {
/* 140 */     return new ArrayList(this.sourceFiles);
/*     */   }
/*     */ 
/*     */   
/*     */   public Repackager getRepackager() {
/* 145 */     return this.repackager;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Writer writerForFile(File f) throws IOException {
/* 150 */     if (CHARSET == null) {
/* 151 */       return new FileWriter(f);
/*     */     }
/* 153 */     FileOutputStream fileStream = new FileOutputStream(f);
/* 154 */     CharsetEncoder ce = CHARSET.newEncoder();
/* 155 */     ce.onUnmappableCharacter(CodingErrorAction.REPORT);
/* 156 */     return new OutputStreamWriter(fileStream, ce);
/*     */   }
/*     */   
/*     */   static class IncrFileWriter
/*     */     extends StringWriter
/*     */   {
/*     */     private File _file;
/*     */     private Repackager _repackager;
/*     */     
/*     */     public IncrFileWriter(File file, Repackager repackager) {
/* 166 */       this._file = file;
/* 167 */       this._repackager = repackager;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 172 */       super.close();
/*     */ 
/*     */       
/* 175 */       StringBuffer sb = (this._repackager != null) ? this._repackager.repackage(getBuffer()) : getBuffer();
/*     */ 
/*     */       
/* 178 */       String str = sb.toString();
/* 179 */       List diffs = new ArrayList();
/* 180 */       StringReader sReader = new StringReader(str);
/* 181 */       FileReader fReader = new FileReader(this._file);
/*     */ 
/*     */       
/*     */       try {
/* 185 */         Diff.readersAsText(sReader, "<generated>", fReader, this._file.getName(), diffs);
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 190 */         sReader.close();
/* 191 */         fReader.close();
/*     */       } 
/*     */       
/* 194 */       if (diffs.size() > 0) {
/*     */ 
/*     */ 
/*     */         
/* 198 */         Writer fw = FilerImpl.writerForFile(this._file);
/*     */         try {
/* 200 */           fw.write(str);
/*     */         } finally {
/* 202 */           fw.close();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class RepackagingWriter extends StringWriter {
/*     */     private File _file;
/*     */     private Repackager _repackager;
/*     */     
/*     */     public RepackagingWriter(File file, Repackager repackager) {
/* 213 */       this._file = file;
/* 214 */       this._repackager = repackager;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 219 */       super.close();
/*     */       
/* 221 */       Writer fw = FilerImpl.writerForFile(this._file);
/*     */       try {
/* 223 */         fw.write(this._repackager.repackage(getBuffer()).toString());
/*     */       } finally {
/* 225 */         fw.close();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\imp\\util\FilerImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */