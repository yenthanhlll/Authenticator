/*     */ package org.apache.xmlbeans.impl.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64
/*     */ {
/*     */   private static final int BASELENGTH = 255;
/*     */   private static final int LOOKUPLENGTH = 64;
/*     */   private static final int TWENTYFOURBITGROUP = 24;
/*     */   private static final int EIGHTBIT = 8;
/*     */   private static final int SIXTEENBIT = 16;
/*     */   private static final int FOURBYTE = 4;
/*     */   private static final int SIGN = -128;
/*     */   private static final byte PAD = 61;
/*     */   private static final boolean fDebug = false;
/*  47 */   private static byte[] base64Alphabet = new byte[255];
/*  48 */   private static byte[] lookUpBase64Alphabet = new byte[64];
/*     */   
/*     */   static {
/*     */     int i;
/*  52 */     for (i = 0; i < 255; i++) {
/*  53 */       base64Alphabet[i] = -1;
/*     */     }
/*  55 */     for (i = 90; i >= 65; i--) {
/*  56 */       base64Alphabet[i] = (byte)(i - 65);
/*     */     }
/*  58 */     for (i = 122; i >= 97; i--) {
/*  59 */       base64Alphabet[i] = (byte)(i - 97 + 26);
/*     */     }
/*     */     
/*  62 */     for (i = 57; i >= 48; i--) {
/*  63 */       base64Alphabet[i] = (byte)(i - 48 + 52);
/*     */     }
/*     */     
/*  66 */     base64Alphabet[43] = 62;
/*  67 */     base64Alphabet[47] = 63;
/*     */     
/*  69 */     for (i = 0; i <= 25; i++)
/*  70 */       lookUpBase64Alphabet[i] = (byte)(65 + i); 
/*     */     int j;
/*  72 */     for (i = 26, j = 0; i <= 51; i++, j++) {
/*  73 */       lookUpBase64Alphabet[i] = (byte)(97 + j);
/*     */     }
/*  75 */     for (i = 52, j = 0; i <= 61; i++, j++)
/*  76 */       lookUpBase64Alphabet[i] = (byte)(48 + j); 
/*  77 */     lookUpBase64Alphabet[62] = 43;
/*  78 */     lookUpBase64Alphabet[63] = 47;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean isWhiteSpace(byte octect) {
/*  83 */     return (octect == 32 || octect == 13 || octect == 10 || octect == 9);
/*     */   }
/*     */   
/*     */   protected static boolean isPad(byte octect) {
/*  87 */     return (octect == 61);
/*     */   }
/*     */   
/*     */   protected static boolean isData(byte octect) {
/*  91 */     return (base64Alphabet[octect] != -1);
/*     */   }
/*     */   
/*     */   protected static boolean isBase64(byte octect) {
/*  95 */     return (isWhiteSpace(octect) || isPad(octect) || isData(octect));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encode(byte[] binaryData) {
/* 106 */     if (binaryData == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     int lengthDataBits = binaryData.length * 8;
/* 110 */     int fewerThan24bits = lengthDataBits % 24;
/* 111 */     int numberTriplets = lengthDataBits / 24;
/* 112 */     byte[] encodedData = null;
/*     */     
/* 114 */     if (fewerThan24bits != 0) {
/* 115 */       encodedData = new byte[(numberTriplets + 1) * 4];
/*     */     } else {
/* 117 */       encodedData = new byte[numberTriplets * 4];
/*     */     } 
/* 119 */     byte k = 0, l = 0, b1 = 0, b2 = 0, b3 = 0;
/*     */     
/* 121 */     int encodedIndex = 0;
/* 122 */     int dataIndex = 0;
/* 123 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/* 127 */     for (i = 0; i < numberTriplets; i++) {
/*     */       
/* 129 */       dataIndex = i * 3;
/* 130 */       b1 = binaryData[dataIndex];
/* 131 */       b2 = binaryData[dataIndex + 1];
/* 132 */       b3 = binaryData[dataIndex + 2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       l = (byte)(b2 & 0xF);
/* 139 */       k = (byte)(b1 & 0x3);
/*     */       
/* 141 */       encodedIndex = i * 4;
/* 142 */       byte val1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 144 */       byte val2 = ((b2 & Byte.MIN_VALUE) == 0) ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 145 */       byte val3 = ((b3 & Byte.MIN_VALUE) == 0) ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */       
/* 147 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 154 */       encodedData[encodedIndex + 1] = lookUpBase64Alphabet[val2 | k << 4];
/* 155 */       encodedData[encodedIndex + 2] = lookUpBase64Alphabet[l << 2 | val3];
/* 156 */       encodedData[encodedIndex + 3] = lookUpBase64Alphabet[b3 & 0x3F];
/*     */     } 
/*     */ 
/*     */     
/* 160 */     dataIndex = i * 3;
/* 161 */     encodedIndex = i * 4;
/* 162 */     if (fewerThan24bits == 8) {
/* 163 */       b1 = binaryData[dataIndex];
/* 164 */       k = (byte)(b1 & 0x3);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 169 */       byte val1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 170 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 171 */       encodedData[encodedIndex + 1] = lookUpBase64Alphabet[k << 4];
/* 172 */       encodedData[encodedIndex + 2] = 61;
/* 173 */       encodedData[encodedIndex + 3] = 61;
/* 174 */     } else if (fewerThan24bits == 16) {
/*     */       
/* 176 */       b1 = binaryData[dataIndex];
/* 177 */       b2 = binaryData[dataIndex + 1];
/* 178 */       l = (byte)(b2 & 0xF);
/* 179 */       k = (byte)(b1 & 0x3);
/*     */       
/* 181 */       byte val1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 182 */       byte val2 = ((b2 & Byte.MIN_VALUE) == 0) ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 184 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 185 */       encodedData[encodedIndex + 1] = lookUpBase64Alphabet[val2 | k << 4];
/* 186 */       encodedData[encodedIndex + 2] = lookUpBase64Alphabet[l << 2];
/* 187 */       encodedData[encodedIndex + 3] = 61;
/*     */     } 
/*     */     
/* 190 */     return encodedData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(byte[] base64Data) {
/* 201 */     if (base64Data == null) {
/* 202 */       return null;
/*     */     }
/*     */     
/* 205 */     base64Data = removeWhiteSpace(base64Data);
/*     */     
/* 207 */     if (base64Data.length % 4 != 0) {
/* 208 */       return null;
/*     */     }
/*     */     
/* 211 */     int numberQuadruple = base64Data.length / 4;
/*     */     
/* 213 */     if (numberQuadruple == 0) {
/* 214 */       return new byte[0];
/*     */     }
/* 216 */     byte[] decodedData = null;
/* 217 */     byte b1 = 0, b2 = 0, b3 = 0, b4 = 0;
/* 218 */     byte d1 = 0, d2 = 0, d3 = 0, d4 = 0;
/*     */ 
/*     */ 
/*     */     
/* 222 */     int i = 0;
/* 223 */     int encodedIndex = 0;
/* 224 */     int dataIndex = 0;
/* 225 */     decodedData = new byte[numberQuadruple * 3];
/*     */     
/* 227 */     for (; i < numberQuadruple - 1; i++) {
/*     */       
/* 229 */       if (!isData(d1 = base64Data[dataIndex++]) || !isData(d2 = base64Data[dataIndex++]) || !isData(d3 = base64Data[dataIndex++]) || !isData(d4 = base64Data[dataIndex++]))
/*     */       {
/*     */ 
/*     */         
/* 233 */         return null;
/*     */       }
/* 235 */       b1 = base64Alphabet[d1];
/* 236 */       b2 = base64Alphabet[d2];
/* 237 */       b3 = base64Alphabet[d3];
/* 238 */       b4 = base64Alphabet[d4];
/*     */       
/* 240 */       decodedData[encodedIndex++] = (byte)(b1 << 2 | b2 >> 4);
/* 241 */       decodedData[encodedIndex++] = (byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF);
/* 242 */       decodedData[encodedIndex++] = (byte)(b3 << 6 | b4);
/*     */     } 
/*     */     
/* 245 */     if (!isData(d1 = base64Data[dataIndex++]) || !isData(d2 = base64Data[dataIndex++]))
/*     */     {
/* 247 */       return null;
/*     */     }
/*     */     
/* 250 */     b1 = base64Alphabet[d1];
/* 251 */     b2 = base64Alphabet[d2];
/*     */     
/* 253 */     d3 = base64Data[dataIndex++];
/* 254 */     d4 = base64Data[dataIndex++];
/* 255 */     if (!isData(d3) || !isData(d4)) {
/*     */       
/* 257 */       if (isPad(d3) && isPad(d4)) {
/* 258 */         if ((b2 & 0xF) != 0)
/* 259 */           return null; 
/* 260 */         byte[] tmp = new byte[i * 3 + 1];
/* 261 */         System.arraycopy(decodedData, 0, tmp, 0, i * 3);
/* 262 */         tmp[encodedIndex] = (byte)(b1 << 2 | b2 >> 4);
/* 263 */         return tmp;
/* 264 */       }  if (!isPad(d3) && isPad(d4)) {
/* 265 */         b3 = base64Alphabet[d3];
/* 266 */         if ((b3 & 0x3) != 0)
/* 267 */           return null; 
/* 268 */         byte[] tmp = new byte[i * 3 + 2];
/* 269 */         System.arraycopy(decodedData, 0, tmp, 0, i * 3);
/* 270 */         tmp[encodedIndex++] = (byte)(b1 << 2 | b2 >> 4);
/* 271 */         tmp[encodedIndex] = (byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF);
/* 272 */         return tmp;
/*     */       } 
/* 274 */       return null;
/*     */     } 
/*     */     
/* 277 */     b3 = base64Alphabet[d3];
/* 278 */     b4 = base64Alphabet[d4];
/* 279 */     decodedData[encodedIndex++] = (byte)(b1 << 2 | b2 >> 4);
/* 280 */     decodedData[encodedIndex++] = (byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF);
/* 281 */     decodedData[encodedIndex++] = (byte)(b3 << 6 | b4);
/*     */ 
/*     */ 
/*     */     
/* 285 */     return decodedData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static byte[] removeWhiteSpace(byte[] data) {
/* 336 */     if (data == null) {
/* 337 */       return null;
/*     */     }
/*     */     
/* 340 */     int newSize = 0;
/* 341 */     int len = data.length;
/* 342 */     for (int i = 0; i < len; i++) {
/* 343 */       if (!isWhiteSpace(data[i])) {
/* 344 */         newSize++;
/*     */       }
/*     */     } 
/*     */     
/* 348 */     if (newSize == len) {
/* 349 */       return data;
/*     */     }
/*     */     
/* 352 */     byte[] newArray = new byte[newSize];
/*     */     
/* 354 */     int j = 0;
/* 355 */     for (int k = 0; k < len; k++) {
/* 356 */       if (!isWhiteSpace(data[k]))
/* 357 */         newArray[j++] = data[k]; 
/*     */     } 
/* 359 */     return newArray;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\imp\\util\Base64.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */