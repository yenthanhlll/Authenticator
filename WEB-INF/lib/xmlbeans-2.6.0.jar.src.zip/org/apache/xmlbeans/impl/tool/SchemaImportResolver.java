/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ImportDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.IncludeDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SchemaImportResolver
/*     */ {
/*     */   public abstract SchemaResource lookupResource(String paramString1, String paramString2);
/*     */   
/*     */   public abstract void reportActualNamespace(SchemaResource paramSchemaResource, String paramString);
/*     */   
/*     */   protected final void resolveImports(SchemaResource[] resources) {
/*  69 */     LinkedList queueOfResources = new LinkedList(Arrays.asList((Object[])resources));
/*  70 */     LinkedList queueOfLocators = new LinkedList();
/*  71 */     Set seenResources = new HashSet();
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       SchemaResource nextResource;
/*     */ 
/*     */       
/*  78 */       if (!queueOfResources.isEmpty()) {
/*     */ 
/*     */         
/*  81 */         nextResource = queueOfResources.removeFirst();
/*     */       }
/*  83 */       else if (!queueOfLocators.isEmpty()) {
/*     */ 
/*     */         
/*  86 */         SchemaLocator locator = queueOfLocators.removeFirst();
/*  87 */         nextResource = lookupResource(locator.namespace, locator.schemaLocation);
/*  88 */         if (nextResource == null) {
/*     */           continue;
/*     */         }
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  98 */       if (seenResources.contains(nextResource))
/*     */         continue; 
/* 100 */       seenResources.add(nextResource);
/*     */ 
/*     */       
/* 103 */       SchemaDocument.Schema schema = nextResource.getSchema();
/* 104 */       if (schema == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 108 */       String actualTargetNamespace = schema.getTargetNamespace();
/* 109 */       if (actualTargetNamespace == null) {
/* 110 */         actualTargetNamespace = "";
/*     */       }
/*     */       
/* 113 */       String expectedTargetNamespace = nextResource.getNamespace();
/* 114 */       if (expectedTargetNamespace == null || !actualTargetNamespace.equals(expectedTargetNamespace))
/*     */       {
/*     */         
/* 117 */         reportActualNamespace(nextResource, actualTargetNamespace);
/*     */       }
/*     */ 
/*     */       
/* 121 */       ImportDocument.Import[] schemaImports = schema.getImportArray();
/* 122 */       for (int i = 0; i < schemaImports.length; i++)
/*     */       {
/* 124 */         queueOfLocators.add(new SchemaLocator((schemaImports[i].getNamespace() == null) ? "" : schemaImports[i].getNamespace(), schemaImports[i].getSchemaLocation()));
/*     */       }
/*     */ 
/*     */       
/* 128 */       IncludeDocument.Include[] schemaIncludes = schema.getIncludeArray();
/* 129 */       for (int j = 0; j < schemaIncludes.length; j++)
/*     */       {
/* 131 */         queueOfLocators.add(new SchemaLocator(null, schemaIncludes[j].getSchemaLocation())); } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class SchemaLocator {
/*     */     public final String namespace;
/*     */     public final String schemaLocation;
/*     */     
/*     */     public SchemaLocator(String namespace, String schemaLocation) {
/* 140 */       this.namespace = namespace;
/* 141 */       this.schemaLocation = schemaLocation;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface SchemaResource {
/*     */     SchemaDocument.Schema getSchema();
/*     */     
/*     */     String getNamespace();
/*     */     
/*     */     String getSchemaLocation();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\SchemaImportResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */