/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeHierarchyPrinter
/*     */ {
/*     */   public static void printUsage() {
/*  45 */     System.out.println("Prints the inheritance hierarchy of types defined in a schema.\n");
/*  46 */     System.out.println("Usage: xsdtree [-noanon] [-nopvr] [-noupa] [-partial] [-license] schemafile.xsd*");
/*  47 */     System.out.println("    -noanon - Don't include anonymous types in the tree.");
/*  48 */     System.out.println("    -noupa - do not enforce the unique particle attribution rule");
/*  49 */     System.out.println("    -nopvr - do not enforce the particle valid (restriction) rule");
/*  50 */     System.out.println("    -partial - Print only part of the hierarchy.");
/*  51 */     System.out.println("    -license - prints license information");
/*  52 */     System.out.println("    schemafile.xsd - File containing the schema for which to print a tree.");
/*  53 */     System.out.println();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/*     */     SchemaTypeSystem typeSystem;
/*  58 */     Set flags = new HashSet();
/*  59 */     flags.add("h");
/*  60 */     flags.add("help");
/*  61 */     flags.add("usage");
/*  62 */     flags.add("license");
/*  63 */     flags.add("version");
/*  64 */     flags.add("noanon");
/*  65 */     flags.add("noupr");
/*  66 */     flags.add("noupa");
/*  67 */     flags.add("partial");
/*     */     
/*  69 */     CommandLine cl = new CommandLine(args, flags, Collections.EMPTY_SET);
/*  70 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*     */       
/*  72 */       printUsage();
/*  73 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     String[] badopts = cl.getBadOpts();
/*  78 */     if (badopts.length > 0) {
/*     */       
/*  80 */       for (int k = 0; k < badopts.length; k++)
/*  81 */         System.out.println("Unrecognized option: " + badopts[k]); 
/*  82 */       printUsage();
/*  83 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  87 */     if (cl.getOpt("license") != null) {
/*     */       
/*  89 */       CommandLine.printLicense();
/*  90 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  94 */     if (cl.getOpt("version") != null) {
/*     */       
/*  96 */       CommandLine.printVersion();
/*  97 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 101 */     if ((cl.args()).length == 0) {
/*     */       
/* 103 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/* 107 */     boolean noanon = (cl.getOpt("noanon") != null);
/* 108 */     boolean nopvr = (cl.getOpt("nopvr") != null);
/* 109 */     boolean noupa = (cl.getOpt("noupa") != null);
/* 110 */     boolean partial = (cl.getOpt("partial") != null);
/*     */     
/* 112 */     File[] schemaFiles = cl.filesEndingWith(".xsd");
/* 113 */     File[] jarFiles = cl.filesEndingWith(".jar");
/*     */ 
/*     */     
/* 116 */     List sdocs = new ArrayList();
/* 117 */     for (int i = 0; i < schemaFiles.length; i++) {
/*     */ 
/*     */       
/*     */       try {
/* 121 */         sdocs.add(SchemaDocument.Factory.parse(schemaFiles[i], (new XmlOptions()).setLoadLineNumbers()));
/*     */ 
/*     */       
/*     */       }
/* 125 */       catch (Exception e) {
/*     */         
/* 127 */         System.err.println(schemaFiles[i] + " not loadable: " + e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 132 */     XmlObject[] schemas = sdocs.<XmlObject>toArray(new XmlObject[0]);
/*     */ 
/*     */     
/* 135 */     SchemaTypeLoader linkTo = null;
/*     */     
/* 137 */     Collection compErrors = new ArrayList();
/* 138 */     XmlOptions schemaOptions = new XmlOptions();
/* 139 */     schemaOptions.setErrorListener(compErrors);
/* 140 */     schemaOptions.setCompileDownloadUrls();
/* 141 */     if (nopvr)
/* 142 */       schemaOptions.setCompileNoPvrRule(); 
/* 143 */     if (noupa)
/* 144 */       schemaOptions.setCompileNoUpaRule(); 
/* 145 */     if (partial) {
/* 146 */       schemaOptions.put("COMPILE_PARTIAL_TYPESYSTEM");
/*     */     }
/* 148 */     if (jarFiles != null && jarFiles.length > 0) {
/* 149 */       linkTo = XmlBeans.typeLoaderForResource(XmlBeans.resourceLoaderForPath(jarFiles));
/*     */     }
/*     */     
/*     */     try {
/* 153 */       typeSystem = XmlBeans.compileXsd(schemas, linkTo, schemaOptions);
/*     */     }
/* 155 */     catch (XmlException e) {
/*     */       
/* 157 */       System.out.println("Schema invalid:" + (partial ? " couldn't recover from errors" : ""));
/* 158 */       if (compErrors.isEmpty())
/* 159 */       { System.out.println(e.getMessage()); }
/* 160 */       else { for (Iterator iterator = compErrors.iterator(); iterator.hasNext();) {
/* 161 */           System.out.println(iterator.next());
/*     */         } }
/*     */       
/*     */       return;
/*     */     } 
/* 166 */     if (partial && !compErrors.isEmpty()) {
/*     */       
/* 168 */       System.out.println("Schema invalid: partial schema type system recovered");
/* 169 */       for (Iterator iterator = compErrors.iterator(); iterator.hasNext();) {
/* 170 */         System.out.println(iterator.next());
/*     */       }
/*     */     } 
/*     */     
/* 174 */     Map prefixes = new HashMap();
/* 175 */     prefixes.put("http://www.w3.org/XML/1998/namespace", "xml");
/* 176 */     prefixes.put("http://www.w3.org/2001/XMLSchema", "xs");
/* 177 */     System.out.println("xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"");
/*     */ 
/*     */     
/* 180 */     Map childTypes = new HashMap();
/*     */ 
/*     */     
/* 183 */     List allSeenTypes = new ArrayList();
/* 184 */     allSeenTypes.addAll(Arrays.asList(typeSystem.documentTypes()));
/* 185 */     allSeenTypes.addAll(Arrays.asList(typeSystem.attributeTypes()));
/* 186 */     allSeenTypes.addAll(Arrays.asList(typeSystem.globalTypes()));
/*     */     
/* 188 */     for (int j = 0; j < allSeenTypes.size(); j++) {
/*     */       
/* 190 */       SchemaType sType = allSeenTypes.get(j);
/*     */ 
/*     */       
/* 193 */       if (!noanon) {
/* 194 */         allSeenTypes.addAll(Arrays.asList(sType.getAnonymousTypes()));
/*     */       }
/*     */       
/* 197 */       if (!sType.isDocumentType() && !sType.isAttributeType() && sType != XmlObject.type) {
/*     */ 
/*     */ 
/*     */         
/* 201 */         noteNamespace(prefixes, sType);
/*     */ 
/*     */         
/* 204 */         Collection children = (Collection)childTypes.get(sType.getBaseType());
/* 205 */         if (children == null) {
/*     */           
/* 207 */           children = new ArrayList();
/* 208 */           childTypes.put(sType.getBaseType(), children);
/*     */ 
/*     */           
/* 211 */           if (sType.getBaseType().isBuiltinType())
/* 212 */             allSeenTypes.add(sType.getBaseType()); 
/*     */         } 
/* 214 */         children.add(sType);
/*     */       } 
/*     */     } 
/*     */     
/* 218 */     List typesToPrint = new ArrayList();
/* 219 */     typesToPrint.add(XmlObject.type);
/* 220 */     StringBuffer spaces = new StringBuffer();
/* 221 */     while (!typesToPrint.isEmpty()) {
/*     */       
/* 223 */       SchemaType sType = typesToPrint.remove(typesToPrint.size() - 1);
/* 224 */       if (sType == null) {
/* 225 */         spaces.setLength(Math.max(0, spaces.length() - 2));
/*     */         continue;
/*     */       } 
/* 228 */       System.out.println(spaces + "+-" + QNameHelper.readable(sType, prefixes) + notes(sType));
/* 229 */       Collection children = (Collection)childTypes.get(sType);
/* 230 */       if (children != null && children.size() > 0) {
/*     */         
/* 232 */         spaces.append((typesToPrint.size() == 0 || typesToPrint.get(typesToPrint.size() - 1) == null) ? "  " : "| ");
/* 233 */         typesToPrint.add(null);
/* 234 */         typesToPrint.addAll(children);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String notes(SchemaType sType) {
/* 242 */     if (sType.isBuiltinType()) {
/* 243 */       return " (builtin)";
/*     */     }
/* 245 */     if (sType.isSimpleType()) {
/*     */       
/* 247 */       switch (sType.getSimpleVariety()) {
/*     */         
/*     */         case 3:
/* 250 */           return " (list)";
/*     */         case 2:
/* 252 */           return " (union)";
/*     */       } 
/* 254 */       if (sType.getEnumerationValues() != null)
/* 255 */         return " (enumeration)"; 
/* 256 */       return "";
/*     */     } 
/*     */ 
/*     */     
/* 260 */     switch (sType.getContentType()) {
/*     */       
/*     */       case 4:
/* 263 */         return " (mixed)";
/*     */       case 2:
/* 265 */         return " (complex)";
/*     */     } 
/* 267 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void noteNamespace(Map prefixes, SchemaType sType) {
/* 273 */     String namespace = QNameHelper.namespace(sType);
/* 274 */     if (namespace.equals("") || prefixes.containsKey(namespace)) {
/*     */       return;
/*     */     }
/* 277 */     String base = QNameHelper.suggestPrefix(namespace);
/* 278 */     String result = base;
/* 279 */     for (int n = 0; prefixes.containsValue(result); n++)
/*     */     {
/* 281 */       result = base + n;
/*     */     }
/*     */     
/* 284 */     prefixes.put(namespace, result);
/* 285 */     System.out.println("xmlns:" + result + "=\"" + namespace + "\"");
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\TypeHierarchyPrinter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */