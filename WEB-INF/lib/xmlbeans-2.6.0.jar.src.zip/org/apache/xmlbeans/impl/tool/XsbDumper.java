/*      */ package org.apache.xmlbeans.impl.tool;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Set;
/*      */ import java.util.zip.ZipEntry;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.soap.SOAPArrayType;
/*      */ 
/*      */ public class XsbDumper {
/*      */   private String _indent;
/*      */   private PrintStream _out;
/*      */   public static final int DATA_BABE = -629491010;
/*      */   public static final int MAJOR_VERSION = 2;
/*      */   public static final int MINOR_VERSION = 24;
/*      */   public static final int FILETYPE_SCHEMAINDEX = 1;
/*      */   public static final int FILETYPE_SCHEMATYPE = 2;
/*      */   public static final int FILETYPE_SCHEMAELEMENT = 3;
/*      */   public static final int FILETYPE_SCHEMAATTRIBUTE = 4;
/*      */   public static final int FILETYPE_SCHEMAPOINTER = 5;
/*      */   public static final int FILETYPE_SCHEMAMODELGROUP = 6;
/*      */   public static final int FILETYPE_SCHEMAATTRIBUTEGROUP = 7;
/*      */   public static final int FLAG_PART_SKIPPABLE = 1;
/*      */   public static final int FLAG_PART_FIXED = 4;
/*      */   public static final int FLAG_PART_NILLABLE = 8;
/*      */   public static final int FLAG_PART_BLOCKEXT = 16;
/*      */   public static final int FLAG_PART_BLOCKREST = 32;
/*      */   public static final int FLAG_PART_BLOCKSUBST = 64;
/*      */   public static final int FLAG_PART_ABSTRACT = 128;
/*      */   public static final int FLAG_PART_FINALEXT = 256;
/*      */   public static final int FLAG_PART_FINALREST = 512;
/*      */   public static final int FLAG_PROP_ISATTR = 1;
/*      */   public static final int FLAG_PROP_JAVASINGLETON = 2;
/*      */   public static final int FLAG_PROP_JAVAOPTIONAL = 4;
/*      */   public static final int FLAG_PROP_JAVAARRAY = 8;
/*      */   
/*      */   public static void printUsage() {
/*   42 */     System.out.println("Prints the contents of an XSB file in human-readable form.");
/*   43 */     System.out.println("An XSB file contains schema meta information needed to ");
/*   44 */     System.out.println("perform tasks such as binding and validation.");
/*   45 */     System.out.println("Usage: dumpxsb myfile.xsb");
/*   46 */     System.out.println("    myfile.xsb - Path to an XSB file.");
/*   47 */     System.out.println();
/*      */   }
/*      */   public static final int FIELD_NONE = 0; public static final int FIELD_GLOBAL = 1; public static final int FIELD_LOCALATTR = 2; public static final int FIELD_LOCALELT = 3; static final int FLAG_SIMPLE_TYPE = 1; static final int FLAG_DOCUMENT_TYPE = 2; static final int FLAG_ORDERED = 4; static final int FLAG_BOUNDED = 8; static final int FLAG_FINITE = 16; static final int FLAG_NUMERIC = 32; static final int FLAG_STRINGENUM = 64; static final int FLAG_UNION_OF_LISTS = 128; static final int FLAG_HAS_PATTERN = 256; static final int FLAG_ORDER_SENSITIVE = 512; static final int FLAG_TOTAL_ORDER = 1024; static final int FLAG_COMPILED = 2048; static final int FLAG_BLOCK_EXT = 4096; static final int FLAG_BLOCK_REST = 8192; static final int FLAG_FINAL_EXT = 16384; static final int FLAG_FINAL_REST = 32768; static final int FLAG_FINAL_UNION = 65536; static final int FLAG_FINAL_LIST = 131072; static final int FLAG_ABSTRACT = 262144; static final int FLAG_ATTRIBUTE_TYPE = 524288; DataInputStream _input; StringPool _stringPool;
/*      */   
/*      */   public static void main(String[] args) {
/*   52 */     if (args.length == 0) {
/*   53 */       printUsage();
/*   54 */       System.exit(0);
/*      */       
/*      */       return;
/*      */     } 
/*   58 */     for (int i = 0; i < args.length; i++)
/*      */     {
/*   60 */       dump(new File(args[i]), true);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static void dump(File file, boolean force) {
/*   66 */     if (file.isDirectory()) {
/*      */       
/*   68 */       File[] files = file.listFiles(new FileFilter()
/*      */           {
/*      */             public boolean accept(File file)
/*      */             {
/*   72 */               return (file.isDirectory() || (file.isFile() && file.getName().endsWith(".xsb")));
/*      */             }
/*      */           });
/*   75 */       for (int i = 0; i < files.length; i++)
/*      */       {
/*   77 */         dump(files[i], false);
/*      */       }
/*      */     }
/*   80 */     else if (file.getName().endsWith(".jar") || file.getName().endsWith(".zip")) {
/*      */       
/*   82 */       dumpZip(file);
/*      */     }
/*   84 */     else if (force || file.getName().endsWith(".xsb")) {
/*      */ 
/*      */       
/*      */       try {
/*   88 */         System.out.println(file.toString());
/*   89 */         dump(new FileInputStream(file), "  ");
/*   90 */         System.out.println();
/*      */       }
/*   92 */       catch (FileNotFoundException e) {
/*      */         
/*   94 */         System.out.println(e.toString());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void dumpZip(File file) {
/*      */     try {
/*  103 */       ZipFile zipFile = new ZipFile(file);
/*  104 */       Enumeration e = zipFile.entries();
/*  105 */       while (e.hasMoreElements()) {
/*      */         
/*  107 */         ZipEntry entry = e.nextElement();
/*  108 */         if (entry.getName().endsWith(".xsb"))
/*      */         {
/*  110 */           System.out.println(entry.getName());
/*  111 */           dump(zipFile.getInputStream(entry), "  ");
/*  112 */           System.out.println();
/*      */         }
/*      */       
/*      */       } 
/*  116 */     } catch (IOException e) {
/*      */       
/*  118 */       System.out.println(e.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void dump(InputStream input) {
/*  124 */     dump(input, "", System.out);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void dump(InputStream input, String indent) {
/*  129 */     dump(input, indent, System.out);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void dump(InputStream input, String indent, PrintStream output) {
/*  134 */     XsbDumper dumper = new XsbDumper(input, indent, output);
/*  135 */     dumper.dumpAll();
/*      */   }
/*      */ 
/*      */   
/*      */   private XsbDumper(InputStream stream, String indent, PrintStream ostream) {
/*  140 */     this._input = new DataInputStream(stream);
/*  141 */     this._indent = indent;
/*  142 */     this._out = ostream;
/*      */   }
/*      */   
/*  145 */   void flush() { this._out.flush(); }
/*  146 */   void emit(String str) { this._out.println(this._indent + str); flush(); }
/*  147 */   void emit() { this._out.println(); flush(); }
/*  148 */   void error(Exception e) { this._out.println(e.toString()); flush(); IllegalStateException e2 = new IllegalStateException(e.getMessage()); e2.initCause(e); throw e2; } void error(String str) {
/*  149 */     this._out.println(str); flush(); IllegalStateException e2 = new IllegalStateException(str); throw e2;
/*      */   }
/*      */   
/*  152 */   void indent() { this._indent += "  "; } void outdent() {
/*  153 */     this._indent = this._indent.substring(0, this._indent.length() - 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String filetypeString(int code) {
/*  169 */     switch (code) {
/*      */       case 1:
/*  171 */         return "FILETYPE_SCHEMAINDEX";
/*  172 */       case 2: return "FILETYPE_SCHEMATYPE";
/*  173 */       case 3: return "FILETYPE_SCHEMAELEMENT";
/*  174 */       case 4: return "FILETYPE_SCHEMAATTRIBUTE";
/*  175 */       case 5: return "FILETYPE_SCHEMAPOINTER";
/*  176 */       case 6: return "FILETYPE_SCHEMAMODELGROUP";
/*  177 */       case 7: return "FILETYPE_SCHEMAATTRIBUTEGROUP";
/*      */     } 
/*  179 */     return "Unknown FILETYPE (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String particleflagsString(int flags) {
/*  195 */     StringBuffer result = new StringBuffer();
/*  196 */     if ((flags & 0x1) != 0) result.append("FLAG_PART_SKIPPABLE | "); 
/*  197 */     if ((flags & 0x4) != 0) result.append("FLAG_PART_FIXED | "); 
/*  198 */     if ((flags & 0x8) != 0) result.append("FLAG_PART_NILLABLE | "); 
/*  199 */     if ((flags & 0x10) != 0) result.append("FLAG_PART_BLOCKEXT | "); 
/*  200 */     if ((flags & 0x20) != 0) result.append("FLAG_PART_BLOCKREST | "); 
/*  201 */     if ((flags & 0x40) != 0) result.append("FLAG_PART_BLOCKSUBST | "); 
/*  202 */     if ((flags & 0x80) != 0) result.append("FLAG_PART_ABSTRACT | "); 
/*  203 */     if ((flags & 0x100) != 0) result.append("FLAG_PART_FINALEXT | "); 
/*  204 */     if ((flags & 0x200) != 0) result.append("FLAG_PART_FINALREST | "); 
/*  205 */     if (result.length() == 0) result.append("0 | "); 
/*  206 */     return result.substring(0, result.length() - 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String propertyflagsString(int flags) {
/*  216 */     StringBuffer result = new StringBuffer();
/*  217 */     if ((flags & 0x1) != 0) result.append("FLAG_PROP_ISATTR | "); 
/*  218 */     if ((flags & 0x2) != 0) result.append("FLAG_PROP_JAVASINGLETON | "); 
/*  219 */     if ((flags & 0x4) != 0) result.append("FLAG_PROP_JAVAOPTIONAL | "); 
/*  220 */     if ((flags & 0x8) != 0) result.append("FLAG_PROP_JAVAARRAY | "); 
/*  221 */     if (result.length() == 0) result.append("0 | "); 
/*  222 */     return result.substring(0, result.length() - 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String containerfieldTypeString(int code) {
/*  232 */     switch (code) {
/*      */       case 0:
/*  234 */         return "FIELD_NONE";
/*  235 */       case 1: return "FIELD_GLOBAL";
/*  236 */       case 2: return "FIELD_LOCALATTR";
/*  237 */       case 3: return "FIELD_LOCALELT";
/*      */     } 
/*  239 */     return "Unknown container field type (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String typeflagsString(int flags) {
/*  267 */     StringBuffer result = new StringBuffer();
/*  268 */     if ((flags & 0x1) != 0) result.append("FLAG_SIMPLE_TYPE | "); 
/*  269 */     if ((flags & 0x2) != 0) result.append("FLAG_DOCUMENT_TYPE | "); 
/*  270 */     if ((flags & 0x80000) != 0) result.append("FLAG_ATTRIBUTE_TYPE | "); 
/*  271 */     if ((flags & 0x4) != 0) result.append("FLAG_ORDERED | "); 
/*  272 */     if ((flags & 0x8) != 0) result.append("FLAG_BOUNDED | "); 
/*  273 */     if ((flags & 0x10) != 0) result.append("FLAG_FINITE | "); 
/*  274 */     if ((flags & 0x20) != 0) result.append("FLAG_NUMERIC | "); 
/*  275 */     if ((flags & 0x40) != 0) result.append("FLAG_STRINGENUM | "); 
/*  276 */     if ((flags & 0x80) != 0) result.append("FLAG_UNION_OF_LISTS | "); 
/*  277 */     if ((flags & 0x100) != 0) result.append("FLAG_HAS_PATTERN | "); 
/*  278 */     if ((flags & 0x400) != 0) result.append("FLAG_TOTAL_ORDER | "); 
/*  279 */     if ((flags & 0x800) != 0) result.append("FLAG_COMPILED | "); 
/*  280 */     if ((flags & 0x1000) != 0) result.append("FLAG_BLOCK_EXT | "); 
/*  281 */     if ((flags & 0x2000) != 0) result.append("FLAG_BLOCK_REST | "); 
/*  282 */     if ((flags & 0x4000) != 0) result.append("FLAG_FINAL_EXT | "); 
/*  283 */     if ((flags & 0x8000) != 0) result.append("FLAG_FINAL_REST | "); 
/*  284 */     if ((flags & 0x10000) != 0) result.append("FLAG_FINAL_UNION | "); 
/*  285 */     if ((flags & 0x20000) != 0) result.append("FLAG_FINAL_LIST | "); 
/*  286 */     if ((flags & 0x40000) != 0) result.append("FLAG_ABSTRACT | "); 
/*  287 */     if (result.length() == 0) result.append("0 | "); 
/*  288 */     return result.substring(0, result.length() - 3);
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpAll() {
/*  293 */     int filetype = dumpHeader();
/*  294 */     switch (filetype) {
/*      */       
/*      */       case 1:
/*  297 */         dumpIndexData();
/*      */         return;
/*      */       case 2:
/*  300 */         dumpTypeFileData();
/*      */         break;
/*      */       case 3:
/*  303 */         dumpParticleData(true);
/*      */         break;
/*      */       case 4:
/*  306 */         dumpAttributeData(true);
/*      */         break;
/*      */       case 5:
/*  309 */         dumpPointerData();
/*      */         break;
/*      */       case 6:
/*  312 */         dumpModelGroupData();
/*      */         break;
/*      */       case 7:
/*  315 */         dumpAttributeGroupData();
/*      */         break;
/*      */     } 
/*  318 */     readEnd();
/*      */   }
/*      */ 
/*      */   
/*      */   static String hex32String(int i) {
/*  323 */     return Integer.toHexString(i);
/*      */   }
/*      */ 
/*      */   
/*      */   protected int dumpHeader() {
/*  328 */     int magic = readInt();
/*  329 */     emit("Magic cookie: " + hex32String(magic));
/*      */     
/*  331 */     if (magic != -629491010) {
/*      */       
/*  333 */       emit("Wrong magic cookie.");
/*  334 */       return 0;
/*      */     } 
/*      */     
/*  337 */     this._majorver = readShort();
/*  338 */     this._minorver = readShort();
/*  339 */     if (atLeast(2, 18, 0)) {
/*  340 */       this._releaseno = readShort();
/*      */     }
/*  342 */     emit("Major version: " + this._majorver);
/*  343 */     emit("Minor version: " + this._minorver);
/*  344 */     emit("Release number: " + this._releaseno);
/*      */     
/*  346 */     if (this._majorver != 2 || this._minorver > 24) {
/*      */       
/*  348 */       emit("Incompatible version.");
/*  349 */       return 0;
/*      */     } 
/*      */     
/*  352 */     int actualfiletype = readShort();
/*  353 */     emit("Filetype: " + filetypeString(actualfiletype));
/*      */     
/*  355 */     this._stringPool = new StringPool();
/*  356 */     this._stringPool.readFrom(this._input);
/*      */     
/*  358 */     return actualfiletype;
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpPointerData() {
/*  363 */     emit("Type system: " + readString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void dumpIndexData() {
/*  369 */     int size = readShort();
/*  370 */     emit("Handle pool (" + size + "):");
/*  371 */     indent();
/*  372 */     for (int i = 0; i < size; i++) {
/*      */       
/*  374 */       String handle = readString();
/*  375 */       int code = readShort();
/*  376 */       emit(handle + " (" + filetypeString(code) + ")");
/*      */     } 
/*  378 */     outdent();
/*      */     
/*  380 */     dumpQNameMap("Global elements");
/*      */ 
/*      */     
/*  383 */     dumpQNameMap("Global attributes");
/*      */ 
/*      */     
/*  386 */     dumpQNameMap("Model groups");
/*  387 */     dumpQNameMap("Attribute groups");
/*      */     
/*  389 */     dumpQNameMap("Identity constraints");
/*      */ 
/*      */     
/*  392 */     dumpQNameMap("Global types");
/*      */ 
/*      */     
/*  395 */     dumpQNameMap("Document types");
/*      */ 
/*      */     
/*  398 */     dumpQNameMap("Attribute types");
/*      */ 
/*      */     
/*  401 */     dumpClassnameIndex("All types by classname");
/*      */ 
/*      */     
/*  404 */     dumpStringArray("Defined namespaces");
/*      */ 
/*      */     
/*  407 */     if (atLeast(2, 15, 0)) {
/*      */       
/*  409 */       dumpQNameMap("Redefined global types");
/*  410 */       dumpQNameMap("Redfined model groups");
/*  411 */       dumpQNameMap("Redfined attribute groups");
/*      */     } 
/*      */ 
/*      */     
/*  415 */     if (atLeast(2, 19, 0)) {
/*  416 */       dumpAnnotations();
/*      */     }
/*  418 */     readEnd();
/*      */   }
/*      */ 
/*      */   
/*      */   class StringPool
/*      */   {
/*  424 */     private List intsToStrings = new ArrayList();
/*  425 */     private Map stringsToInts = new HashMap();
/*      */     private final XsbDumper this$0;
/*      */     
/*      */     StringPool() {
/*  429 */       this.intsToStrings.add(null);
/*      */     }
/*      */ 
/*      */     
/*      */     String stringForCode(int code) {
/*  434 */       if (code == 0)
/*  435 */         return null; 
/*  436 */       return this.intsToStrings.get(code);
/*      */     }
/*      */ 
/*      */     
/*      */     int codeForString(String str) {
/*  441 */       if (str == null)
/*  442 */         return 0; 
/*  443 */       Integer result = (Integer)this.stringsToInts.get(str);
/*  444 */       if (result == null) {
/*      */         
/*  446 */         result = new Integer(this.intsToStrings.size());
/*  447 */         this.intsToStrings.add(str);
/*  448 */         this.stringsToInts.put(str, result);
/*      */       } 
/*  450 */       return result.intValue();
/*      */     }
/*      */ 
/*      */     
/*      */     void readFrom(DataInputStream input) {
/*  455 */       if (this.intsToStrings.size() != 1 || this.stringsToInts.size() != 0) {
/*  456 */         throw new IllegalStateException();
/*      */       }
/*      */       
/*      */       try {
/*  460 */         int size = input.readShort();
/*  461 */         XsbDumper.this.emit("String pool (" + size + "):");
/*  462 */         XsbDumper.this.indent();
/*  463 */         for (int i = 1; i < size; i++) {
/*      */           
/*  465 */           String str = input.readUTF();
/*  466 */           int code = codeForString(str);
/*  467 */           if (code != i)
/*  468 */             throw new IllegalStateException(); 
/*  469 */           XsbDumper.this.emit(code + " = \"" + str + "\"");
/*      */         } 
/*  471 */         XsbDumper.this.outdent();
/*      */       }
/*  473 */       catch (IOException e) {
/*      */         
/*  475 */         XsbDumper.this.emit(e.toString());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readShort() {
/*      */     try {
/*  488 */       return this._input.readUnsignedShort();
/*      */     }
/*  490 */     catch (IOException e) {
/*      */       
/*  492 */       error(e);
/*  493 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int readInt() {
/*      */     try {
/*  501 */       return this._input.readInt();
/*      */     }
/*  503 */     catch (IOException e) {
/*      */       
/*  505 */       error(e);
/*  506 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   String readString() {
/*  512 */     return this._stringPool.stringForCode(readShort());
/*      */   }
/*      */ 
/*      */   
/*      */   QName readQName() {
/*  517 */     String namespace = readString();
/*  518 */     String localname = readString();
/*  519 */     if (localname == null)
/*  520 */       return null; 
/*  521 */     return new QName(namespace, localname);
/*      */   }
/*      */ 
/*      */   
/*      */   String readHandle() {
/*  526 */     return readString();
/*      */   }
/*      */ 
/*      */   
/*      */   String readType() {
/*  531 */     return readHandle();
/*      */   }
/*      */ 
/*      */   
/*      */   static String qnameString(QName qname) {
/*  536 */     if (qname == null)
/*  537 */       return "(null)"; 
/*  538 */     if (qname.getNamespaceURI() != null) {
/*  539 */       return qname.getLocalPart() + "@" + qname.getNamespaceURI();
/*      */     }
/*  541 */     return qname.getLocalPart();
/*      */   }
/*      */ 
/*      */   
/*      */   static String qnameSetString(QNameSet set) {
/*  546 */     return set.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpQNameMap(String fieldname) {
/*  551 */     int size = readShort();
/*  552 */     emit(fieldname + " (" + size + "):");
/*  553 */     indent();
/*  554 */     for (int i = 0; i < size; i++)
/*      */     {
/*  556 */       emit(qnameString(readQName()) + " = " + readHandle());
/*      */     }
/*  558 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpTypeArray(String fieldname) {
/*  563 */     int size = readShort();
/*  564 */     emit(fieldname + " (" + size + "):");
/*  565 */     indent();
/*  566 */     for (int i = 0; i < size; i++)
/*      */     {
/*  568 */       emit(i + " = " + readType());
/*      */     }
/*  570 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpClassnameIndex(String fieldname) {
/*  575 */     int size = readShort();
/*  576 */     emit(fieldname + " (" + size + "):");
/*  577 */     indent();
/*  578 */     for (int i = 0; i < size; i++)
/*      */     {
/*  580 */       emit(readString() + " = " + readType());
/*      */     }
/*  582 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpStringArray(String fieldname) {
/*  587 */     int size = readShort();
/*  588 */     emit(fieldname + " (" + size + "):");
/*  589 */     indent();
/*  590 */     for (int i = 0; i < size; i++)
/*      */     {
/*  592 */       emit(readString());
/*      */     }
/*  594 */     outdent();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void readEnd() {
/*      */     try {
/*  601 */       this._input.close();
/*      */     }
/*  603 */     catch (IOException e) {}
/*      */ 
/*      */ 
/*      */     
/*  607 */     this._input = null;
/*  608 */     this._stringPool = null;
/*      */   }
/*      */ 
/*      */   
/*      */   static String particleTypeString(int spt) {
/*  613 */     switch (spt) {
/*      */       case 1:
/*  615 */         return "ALL";
/*  616 */       case 2: return "CHOICE";
/*  617 */       case 4: return "ELEMENT";
/*  618 */       case 3: return "SEQUENCE";
/*  619 */       case 5: return "WILDCARD";
/*      */     } 
/*  621 */     return "Unknown particle type (" + spt + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static String bigIntegerString(BigInteger bigint) {
/*  627 */     if (bigint == null)
/*  628 */       return "(null)"; 
/*  629 */     return bigint.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   static String wcprocessString(int code) {
/*  634 */     switch (code) {
/*      */       case 1:
/*  636 */         return "STRICT";
/*  637 */       case 3: return "SKIP";
/*  638 */       case 2: return "LAX";
/*  639 */       case 0: return "NOT_WILDCARD";
/*      */     } 
/*  641 */     return "Unknown process type (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void dumpAnnotation() {
/*  647 */     if (!atLeast(2, 19, 0)) {
/*      */       return;
/*      */     }
/*  650 */     int n = readInt();
/*  651 */     if (n == -1)
/*      */       return; 
/*  653 */     emit("Annotation");
/*  654 */     boolean empty = true;
/*  655 */     indent();
/*  656 */     if (n > 0) {
/*      */       
/*  658 */       emit("Attributes (" + n + "):");
/*  659 */       indent();
/*  660 */       for (int i = 0; i < n; i++) {
/*      */         
/*  662 */         if (atLeast(2, 24, 0)) {
/*  663 */           emit("Name: " + qnameString(readQName()) + ", Value: " + readString() + ", ValueURI: " + readString());
/*      */         }
/*      */         else {
/*      */           
/*  667 */           emit("Name: " + qnameString(readQName()) + ", Value: " + readString());
/*      */         } 
/*      */       } 
/*  670 */       outdent();
/*  671 */       empty = false;
/*      */     } 
/*      */     
/*  674 */     n = readInt();
/*  675 */     if (n > 0) {
/*      */       
/*  677 */       emit("Documentation elements (" + n + "):");
/*  678 */       indent();
/*  679 */       for (int i = 0; i < n; i++)
/*  680 */         emit(readString()); 
/*  681 */       outdent();
/*  682 */       empty = false;
/*      */     } 
/*      */     
/*  685 */     n = readInt();
/*  686 */     if (n > 0) {
/*      */       
/*  688 */       emit("Appinfo elements (" + n + "):");
/*  689 */       indent();
/*  690 */       for (int i = 0; i < n; i++)
/*  691 */         emit(readString()); 
/*  692 */       outdent();
/*  693 */       empty = false;
/*      */     } 
/*  695 */     if (empty)
/*  696 */       emit("<empty>"); 
/*  697 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpAnnotations() {
/*  702 */     int n = readInt();
/*  703 */     if (n > 0) {
/*      */       
/*  705 */       emit("Top-level annotations (" + n + "):");
/*  706 */       indent();
/*  707 */       for (int i = 0; i < n; i++)
/*  708 */         dumpAnnotation(); 
/*  709 */       outdent();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpParticleData(boolean global) {
/*  715 */     int count, i, particleType = readShort();
/*  716 */     emit(particleTypeString(particleType) + ":");
/*  717 */     indent();
/*  718 */     int particleFlags = readShort();
/*  719 */     emit("Flags: " + particleflagsString(particleFlags));
/*      */     
/*  721 */     emit("MinOccurs: " + bigIntegerString(readBigInteger()));
/*  722 */     emit("MaxOccurs: " + bigIntegerString(readBigInteger()));
/*      */     
/*  724 */     emit("Transition: " + qnameSetString(readQNameSet()));
/*      */     
/*  726 */     switch (particleType) {
/*      */       
/*      */       case 5:
/*  729 */         emit("Wildcard set: " + qnameSetString(readQNameSet()));
/*  730 */         emit("Wildcard process: " + wcprocessString(readShort()));
/*      */         break;
/*      */       
/*      */       case 4:
/*  734 */         emit("Name: " + qnameString(readQName()));
/*  735 */         emit("Type: " + readType());
/*  736 */         emit("Default: " + readString());
/*  737 */         if (atLeast(2, 16, 0))
/*  738 */           emit("Default value: " + readXmlValueObject()); 
/*  739 */         emit("WsdlArrayType: " + SOAPArrayTypeString(readSOAPArrayType()));
/*  740 */         dumpAnnotation();
/*  741 */         if (global) {
/*      */           
/*  743 */           if (atLeast(2, 17, 0))
/*  744 */             emit("Substitution group ref: " + readHandle()); 
/*  745 */           int substGroupCount = readShort();
/*  746 */           emit("Substitution group members (" + substGroupCount + ")");
/*  747 */           indent();
/*  748 */           for (int j = 0; j < substGroupCount; j++)
/*      */           {
/*  750 */             emit(qnameString(readQName()));
/*      */           }
/*  752 */           outdent();
/*      */         } 
/*  754 */         count = readShort();
/*  755 */         emit("Identity constraints (" + count + "):");
/*  756 */         indent();
/*  757 */         for (i = 0; i < count; i++)
/*      */         {
/*  759 */           emit(readHandle());
/*      */         }
/*  761 */         outdent();
/*  762 */         if (global) {
/*  763 */           emit("Filename: " + readString());
/*      */         }
/*      */         break;
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*  769 */         dumpParticleArray("Particle children");
/*      */         break;
/*      */       
/*      */       default:
/*  773 */         error("Unrecognized schema particle type"); break;
/*      */     } 
/*  775 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpParticleArray(String fieldname) {
/*  780 */     int count = readShort();
/*  781 */     emit(fieldname + "(" + count + "):");
/*  782 */     indent();
/*  783 */     for (int i = 0; i < count; i++)
/*  784 */       dumpParticleData(false); 
/*  785 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   static String complexVarietyString(int code) {
/*  790 */     switch (code) {
/*      */       case 1:
/*  792 */         return "EMPTY_CONTENT";
/*  793 */       case 2: return "SIMPLE_CONTENT";
/*  794 */       case 3: return "ELEMENT_CONTENT";
/*  795 */       case 4: return "MIXED_CONTENT";
/*      */     } 
/*  797 */     return "Unknown complex variety (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static String simpleVarietyString(int code) {
/*  803 */     switch (code) {
/*      */       case 1:
/*  805 */         return "ATOMIC";
/*  806 */       case 3: return "LIST";
/*  807 */       case 2: return "UNION";
/*      */     } 
/*  809 */     return "Unknown simple variety (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   String facetCodeString(int code) {
/*  815 */     switch (code) {
/*      */       case 0:
/*  817 */         return "FACET_LENGTH";
/*  818 */       case 1: return "FACET_MIN_LENGTH";
/*  819 */       case 2: return "FACET_MAX_LENGTH";
/*  820 */       case 3: return "FACET_MIN_EXCLUSIVE";
/*  821 */       case 4: return "FACET_MIN_INCLUSIVE";
/*  822 */       case 5: return "FACET_MAX_INCLUSIVE";
/*  823 */       case 6: return "FACET_MAX_EXCLUSIVE";
/*  824 */       case 7: return "FACET_TOTAL_DIGITS";
/*  825 */       case 8: return "FACET_FRACTION_DIGITS";
/*      */     } 
/*  827 */     return "Unknown facet code (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   String whitespaceCodeString(int code) {
/*  833 */     switch (code) {
/*      */       case 3:
/*  835 */         return "WS_COLLAPSE";
/*  836 */       case 1: return "WS_PRESERVE";
/*  837 */       case 2: return "WS_REPLACE";
/*  838 */       case 0: return "WS_UNSPECIFIED";
/*      */     } 
/*  840 */     return "Unknown whitespace code (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   String derivationTypeString(int code) {
/*  846 */     switch (code) {
/*      */       case 0:
/*  848 */         return "DT_NOT_DERIVED";
/*  849 */       case 1: return "DT_RESTRICTION";
/*  850 */       case 2: return "DT_EXTENSION";
/*      */     } 
/*  852 */     return "Unknown derivation code (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void dumpTypeFileData() {
/*  858 */     emit("Name: " + qnameString(readQName()));
/*  859 */     emit("Outer type: " + readType());
/*  860 */     emit("Depth: " + readShort());
/*  861 */     emit("Base type: " + readType());
/*  862 */     emit("Derivation type: " + derivationTypeString(readShort()));
/*  863 */     dumpAnnotation();
/*      */     
/*  865 */     emit("Container field:");
/*  866 */     indent();
/*  867 */     int containerfieldtype = readShort();
/*  868 */     emit("Reftype: " + containerfieldTypeString(containerfieldtype));
/*  869 */     switch (containerfieldtype) {
/*      */       
/*      */       case 1:
/*  872 */         emit("Handle: " + readHandle());
/*      */         break;
/*      */       case 2:
/*  875 */         emit("Index: " + readShort());
/*      */         break;
/*      */       case 3:
/*  878 */         emit("Index: " + readShort());
/*      */         break;
/*      */     } 
/*  881 */     outdent();
/*  882 */     emit("Java class name: " + readString());
/*  883 */     emit("Java impl class name: " + readString());
/*      */     
/*  885 */     dumpTypeArray("Anonymous types");
/*      */     
/*  887 */     emit("Anonymous union member ordinal: " + readShort());
/*      */ 
/*      */     
/*  890 */     int flags = readInt();
/*  891 */     emit("Flags: " + typeflagsString(flags));
/*  892 */     boolean isComplexType = ((flags & 0x1) == 0);
/*      */     
/*  894 */     int complexVariety = 0;
/*  895 */     if (isComplexType) {
/*      */       
/*  897 */       complexVariety = readShort();
/*  898 */       emit("Complex variety: " + complexVarietyString(complexVariety));
/*      */       
/*  900 */       if (atLeast(2, 23, 0)) {
/*  901 */         emit("Content based on type: " + readType());
/*      */       }
/*  903 */       int attrCount = readShort();
/*  904 */       emit("Attribute model (" + attrCount + "):");
/*  905 */       indent();
/*  906 */       for (int i = 0; i < attrCount; i++) {
/*  907 */         dumpAttributeData(false);
/*      */       }
/*  909 */       emit("Wildcard set: " + qnameSetString(readQNameSet()));
/*  910 */       emit("Wildcard process: " + wcprocessString(readShort()));
/*  911 */       outdent();
/*      */ 
/*      */       
/*  914 */       int attrPropCount = readShort();
/*  915 */       emit("Attribute properties (" + attrPropCount + "):");
/*  916 */       indent();
/*  917 */       for (int j = 0; j < attrPropCount; j++)
/*      */       {
/*  919 */         dumpPropertyData();
/*      */       }
/*  921 */       outdent();
/*      */       
/*  923 */       if (complexVariety == 3 || complexVariety == 4) {
/*      */         
/*  925 */         emit("IsAll: " + readShort());
/*      */ 
/*      */         
/*  928 */         dumpParticleArray("Content model");
/*      */ 
/*      */         
/*  931 */         int elemPropCount = readShort();
/*  932 */         emit("Element properties (" + elemPropCount + "):");
/*  933 */         indent();
/*  934 */         for (int k = 0; k < elemPropCount; k++)
/*      */         {
/*  936 */           dumpPropertyData();
/*      */         }
/*  938 */         outdent();
/*      */       } 
/*      */     } 
/*      */     
/*  942 */     if (!isComplexType || complexVariety == 2) {
/*      */       
/*  944 */       int simpleVariety = readShort();
/*  945 */       emit("Simple type variety: " + simpleVarietyString(simpleVariety));
/*      */       
/*  947 */       boolean isStringEnum = ((flags & 0x40) != 0);
/*      */       
/*  949 */       int facetCount = readShort();
/*  950 */       emit("Facets (" + facetCount + "):");
/*  951 */       indent();
/*  952 */       for (int i = 0; i < facetCount; i++) {
/*      */         
/*  954 */         emit(facetCodeString(readShort()));
/*  955 */         emit("Value: " + readXmlValueObject());
/*  956 */         emit("Fixed: " + readShort());
/*      */       } 
/*  958 */       outdent();
/*      */       
/*  960 */       emit("Whitespace rule: " + whitespaceCodeString(readShort()));
/*      */       
/*  962 */       int patternCount = readShort();
/*  963 */       emit("Patterns (" + patternCount + "):");
/*  964 */       indent();
/*  965 */       for (int j = 0; j < patternCount; j++)
/*      */       {
/*  967 */         emit(readString());
/*      */       }
/*  969 */       outdent();
/*      */       
/*  971 */       int enumCount = readShort();
/*  972 */       emit("Enumeration values (" + enumCount + "):");
/*  973 */       indent();
/*  974 */       for (int k = 0; k < enumCount; k++)
/*      */       {
/*  976 */         emit(readXmlValueObject());
/*      */       }
/*  978 */       outdent();
/*      */       
/*  980 */       emit("Base enum type: " + readType());
/*  981 */       if (isStringEnum) {
/*      */         
/*  983 */         int seCount = readShort();
/*  984 */         emit("String enum entries (" + seCount + "):");
/*  985 */         indent();
/*  986 */         for (int m = 0; m < seCount; m++)
/*      */         {
/*  988 */           emit("\"" + readString() + "\" -> " + readShort() + " = " + readString());
/*      */         }
/*  990 */         outdent();
/*      */       } 
/*      */       
/*  993 */       switch (simpleVariety) {
/*      */         
/*      */         case 1:
/*  996 */           emit("Primitive type: " + readType());
/*  997 */           emit("Decimal size: " + readInt());
/*      */           break;
/*      */         
/*      */         case 3:
/* 1001 */           emit("List item type: " + readType());
/*      */           break;
/*      */         
/*      */         case 2:
/* 1005 */           dumpTypeArray("Union members");
/*      */           break;
/*      */         
/*      */         default:
/* 1009 */           error("Unknown simple type variety");
/*      */           break;
/*      */       } 
/*      */     } 
/* 1013 */     emit("Filename: " + readString());
/*      */   }
/*      */ 
/*      */   
/*      */   static String attruseCodeString(int code) {
/* 1018 */     switch (code) {
/*      */       case 2:
/* 1020 */         return "OPTIONAL";
/* 1021 */       case 3: return "REQUIRED";
/* 1022 */       case 1: return "PROHIBITED";
/*      */     } 
/* 1024 */     return "Unknown use code (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void dumpAttributeData(boolean global) {
/* 1030 */     emit("Name: " + qnameString(readQName()));
/* 1031 */     emit("Type: " + readType());
/* 1032 */     emit("Use: " + attruseCodeString(readShort()));
/* 1033 */     emit("Default: " + readString());
/* 1034 */     if (atLeast(2, 16, 0))
/* 1035 */       emit("Default value: " + readXmlValueObject()); 
/* 1036 */     emit("Fixed: " + readShort());
/* 1037 */     emit("WsdlArrayType: " + SOAPArrayTypeString(readSOAPArrayType()));
/* 1038 */     dumpAnnotation();
/* 1039 */     if (global)
/* 1040 */       emit("Filename: " + readString()); 
/*      */   }
/*      */   
/* 1043 */   private static final XmlOptions prettyOptions = (new XmlOptions()).setSavePrettyPrint();
/*      */ 
/*      */ 
/*      */   
/*      */   void dumpXml() {
/* 1048 */     String xml = readString();
/*      */     
/*      */     try {
/* 1051 */       emit(XmlObject.Factory.parse(xml).xmlText(prettyOptions));
/*      */     }
/* 1053 */     catch (XmlException x) {
/*      */       
/* 1055 */       emit("!!!!!! BAD XML !!!!!");
/* 1056 */       emit(xml);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void dumpModelGroupData() {
/* 1062 */     emit("Name: " + qnameString(readQName()));
/* 1063 */     emit("Target namespace: " + readString());
/* 1064 */     emit("Chameleon: " + readShort());
/* 1065 */     if (atLeast(2, 22, 0))
/* 1066 */       emit("Element form default: " + readString()); 
/* 1067 */     if (atLeast(2, 22, 0))
/* 1068 */       emit("Attribute form default: " + readString()); 
/* 1069 */     if (atLeast(2, 15, 0))
/* 1070 */       emit("Redefine: " + readShort()); 
/* 1071 */     emit("Model Group Xml: ");
/* 1072 */     dumpXml();
/* 1073 */     dumpAnnotation();
/* 1074 */     if (atLeast(2, 21, 0)) {
/* 1075 */       emit("Filename: " + readString());
/*      */     }
/*      */   }
/*      */   
/*      */   void dumpAttributeGroupData() {
/* 1080 */     emit("Name: " + qnameString(readQName()));
/* 1081 */     emit("Target namespace: " + readString());
/* 1082 */     emit("Chameleon: " + readShort());
/* 1083 */     if (atLeast(2, 22, 0))
/* 1084 */       emit("Form default: " + readString()); 
/* 1085 */     if (atLeast(2, 15, 0))
/* 1086 */       emit("Redefine: " + readShort()); 
/* 1087 */     emit("Attribute Group Xml: ");
/* 1088 */     dumpXml();
/* 1089 */     dumpAnnotation();
/* 1090 */     if (atLeast(2, 21, 0)) {
/* 1091 */       emit("Filename: " + readString());
/*      */     }
/*      */   }
/*      */   
/*      */   static String alwaysString(int code) {
/* 1096 */     switch (code) {
/*      */       case 2:
/* 1098 */         return "CONSISTENTLY";
/* 1099 */       case 0: return "NEVER";
/* 1100 */       case 1: return "VARIABLE";
/*      */     } 
/* 1102 */     return "Unknown frequency code (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static String jtcString(int code) {
/* 1108 */     switch (code) {
/*      */       case 0:
/* 1110 */         return "XML_OBJECT";
/* 1111 */       case 1: return "JAVA_BOOLEAN";
/* 1112 */       case 2: return "JAVA_FLOAT";
/* 1113 */       case 3: return "JAVA_DOUBLE";
/* 1114 */       case 4: return "JAVA_BYTE";
/* 1115 */       case 5: return "JAVA_SHORT";
/* 1116 */       case 6: return "JAVA_INT";
/* 1117 */       case 7: return "JAVA_LONG";
/*      */       case 8:
/* 1119 */         return "JAVA_BIG_DECIMAL";
/* 1120 */       case 9: return "JAVA_BIG_INTEGER";
/* 1121 */       case 10: return "JAVA_STRING";
/* 1122 */       case 11: return "JAVA_BYTE_ARRAY";
/* 1123 */       case 12: return "JAVA_GDATE";
/* 1124 */       case 13: return "JAVA_GDURATION";
/* 1125 */       case 14: return "JAVA_DATE";
/* 1126 */       case 15: return "JAVA_QNAME";
/* 1127 */       case 17: return "JAVA_CALENDAR";
/* 1128 */       case 16: return "JAVA_LIST";
/*      */       case 18:
/* 1130 */         return "JAVA_ENUM";
/* 1131 */       case 19: return "JAVA_OBJECT";
/*      */     } 
/*      */     
/* 1134 */     return "Unknown java type code (" + code + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void dumpPropertyData() {
/* 1140 */     emit("Property");
/* 1141 */     indent();
/* 1142 */     emit("Name: " + qnameString(readQName()));
/* 1143 */     emit("Type: " + readType());
/* 1144 */     int propflags = readShort();
/* 1145 */     emit("Flags: " + propertyflagsString(propflags));
/* 1146 */     emit("Container type: " + readType());
/* 1147 */     emit("Min occurances: " + bigIntegerString(readBigInteger()));
/* 1148 */     emit("Max occurances: " + bigIntegerString(readBigInteger()));
/* 1149 */     emit("Nillable: " + alwaysString(readShort()));
/* 1150 */     emit("Default: " + alwaysString(readShort()));
/* 1151 */     emit("Fixed: " + alwaysString(readShort()));
/* 1152 */     emit("Default text: " + readString());
/* 1153 */     emit("Java prop name: " + readString());
/* 1154 */     emit("Java type code: " + jtcString(readShort()));
/* 1155 */     emit("Type for java signature: " + readType());
/* 1156 */     if (atMost(2, 19, 0))
/* 1157 */       emit("Java setter delimiter: " + qnameSetString(readQNameSet())); 
/* 1158 */     if (atLeast(2, 16, 0))
/* 1159 */       emit("Default value: " + readXmlValueObject()); 
/* 1160 */     if ((propflags & 0x1) == 0 && atLeast(2, 17, 0)) {
/*      */       
/* 1162 */       int size = readShort();
/* 1163 */       emit("Accepted substitutions (" + size + "):");
/* 1164 */       for (int i = 0; i < size; i++)
/* 1165 */         emit("  Accepted name " + readQName()); 
/*      */     } 
/* 1167 */     outdent();
/*      */   }
/*      */ 
/*      */   
/*      */   String readXmlValueObject() {
/* 1172 */     String type = readType();
/* 1173 */     if (type == null) {
/* 1174 */       return "null";
/*      */     }
/* 1176 */     int btc = readShort();
/*      */     
/* 1178 */     switch (btc)
/*      */     { default:
/*      */         assert false;
/*      */       
/*      */       case 0:
/* 1183 */         value = "nil";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1222 */         return value + " (" + type + ": " + btc + ")";case 2: case 3: case 6: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20: case 21: value = readString(); return value + " (" + type + ": " + btc + ")";case 4: case 5: value = new String(HexBin.encode(readByteArray())); if (value.length() > 19) value = value.subSequence(0, 16) + "...";  return value + " (" + type + ": " + btc + ")";case 7: case 8: value = QNameHelper.pretty(readQName()); return value + " (" + type + ": " + btc + ")";case 9: case 10: break; }  String value = Double.toString(readDouble()); return value + " (" + type + ": " + btc + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   double readDouble() {
/*      */     try {
/* 1229 */       return this._input.readDouble();
/*      */     }
/* 1231 */     catch (IOException e) {
/*      */       
/* 1233 */       error(e);
/* 1234 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   String SOAPArrayTypeString(SOAPArrayType t) {
/* 1240 */     if (t == null)
/* 1241 */       return "null"; 
/* 1242 */     return QNameHelper.pretty(t.getQName()) + t.soap11DimensionString();
/*      */   }
/*      */ 
/*      */   
/*      */   SOAPArrayType readSOAPArrayType() {
/* 1247 */     QName qName = readQName();
/* 1248 */     String dimensions = readString();
/* 1249 */     if (qName == null)
/* 1250 */       return null; 
/* 1251 */     return new SOAPArrayType(qName, dimensions);
/*      */   }
/*      */ 
/*      */   
/*      */   QNameSet readQNameSet() {
/* 1256 */     int flag = readShort();
/*      */     
/* 1258 */     Set uriSet = new HashSet();
/* 1259 */     int uriCount = readShort();
/* 1260 */     for (int i = 0; i < uriCount; i++) {
/* 1261 */       uriSet.add(readString());
/*      */     }
/* 1263 */     Set qnameSet1 = new HashSet();
/* 1264 */     int qncount1 = readShort();
/* 1265 */     for (int j = 0; j < qncount1; j++) {
/* 1266 */       qnameSet1.add(readQName());
/*      */     }
/* 1268 */     Set qnameSet2 = new HashSet();
/* 1269 */     int qncount2 = readShort();
/* 1270 */     for (int k = 0; k < qncount2; k++) {
/* 1271 */       qnameSet2.add(readQName());
/*      */     }
/* 1273 */     if (flag == 1) {
/* 1274 */       return QNameSet.forSets(uriSet, null, qnameSet1, qnameSet2);
/*      */     }
/* 1276 */     return QNameSet.forSets(null, uriSet, qnameSet2, qnameSet1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] readByteArray() {
/*      */     try {
/* 1283 */       int len = this._input.readShort();
/* 1284 */       byte[] result = new byte[len];
/* 1285 */       this._input.readFully(result);
/* 1286 */       return result;
/*      */     }
/* 1288 */     catch (IOException e) {
/*      */       
/* 1290 */       error(e);
/* 1291 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   BigInteger readBigInteger() {
/* 1297 */     byte[] result = readByteArray();
/* 1298 */     if (result.length == 0)
/* 1299 */       return null; 
/* 1300 */     if (result.length == 1 && result[0] == 0)
/* 1301 */       return BigInteger.ZERO; 
/* 1302 */     if (result.length == 1 && result[0] == 1)
/* 1303 */       return BigInteger.ONE; 
/* 1304 */     return new BigInteger(result);
/*      */   }
/*      */   
/* 1307 */   static final byte[] SINGLE_ZERO_BYTE = new byte[] { 0 };
/*      */   
/*      */   private int _majorver;
/*      */   
/*      */   private int _minorver;
/*      */   private int _releaseno;
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   protected boolean atLeast(int majorver, int minorver, int releaseno) {
/* 1316 */     if (this._majorver > majorver)
/* 1317 */       return true; 
/* 1318 */     if (this._majorver < majorver)
/* 1319 */       return false; 
/* 1320 */     if (this._minorver > minorver)
/* 1321 */       return true; 
/* 1322 */     if (this._minorver < minorver)
/* 1323 */       return false; 
/* 1324 */     return (this._releaseno >= releaseno);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean atMost(int majorver, int minorver, int releaseno) {
/* 1329 */     if (this._majorver > majorver)
/* 1330 */       return false; 
/* 1331 */     if (this._majorver < majorver)
/* 1332 */       return true; 
/* 1333 */     if (this._minorver > minorver)
/* 1334 */       return false; 
/* 1335 */     if (this._minorver < minorver)
/* 1336 */       return true; 
/* 1337 */     return (this._releaseno <= releaseno);
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\XsbDumper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */