/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrettyPrinter
/*     */ {
/*     */   private static final int DEFAULT_INDENT = 2;
/*     */   
/*     */   public static void printUsage() {
/*  35 */     System.out.println("Pretty prints XML files.");
/*  36 */     System.out.println("Usage: xpretty [switches] file.xml");
/*  37 */     System.out.println("Switches:");
/*  38 */     System.out.println("    -indent #   use the given indent");
/*  39 */     System.out.println("    -license prints license information");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*     */     int indent;
/*  44 */     Set flags = new HashSet();
/*  45 */     flags.add("h");
/*  46 */     flags.add("help");
/*  47 */     flags.add("usage");
/*  48 */     flags.add("license");
/*  49 */     flags.add("version");
/*     */     
/*  51 */     CommandLine cl = new CommandLine(args, flags, Collections.singleton("indent"));
/*     */     
/*  53 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*     */       
/*  55 */       printUsage();
/*  56 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  60 */     String[] badopts = cl.getBadOpts();
/*  61 */     if (badopts.length > 0) {
/*     */       
/*  63 */       for (int j = 0; j < badopts.length; j++)
/*  64 */         System.out.println("Unrecognized option: " + badopts[j]); 
/*  65 */       printUsage();
/*  66 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     if (cl.getOpt("license") != null) {
/*     */       
/*  72 */       CommandLine.printLicense();
/*  73 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     if (cl.getOpt("version") != null) {
/*     */       
/*  79 */       CommandLine.printVersion();
/*  80 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  84 */     if ((cl.args()).length == 0) {
/*     */       
/*  86 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/*  90 */     String indentStr = cl.getOpt("indent");
/*     */     
/*  92 */     if (indentStr == null) {
/*  93 */       indent = 2;
/*     */     } else {
/*  95 */       indent = Integer.parseInt(indentStr);
/*     */     } 
/*  97 */     File[] files = cl.getFiles();
/*     */     
/*  99 */     for (int i = 0; i < files.length; i++) {
/*     */       XmlObject doc;
/*     */ 
/*     */       
/*     */       try {
/* 104 */         doc = XmlObject.Factory.parse(files[i], (new XmlOptions()).setLoadLineNumbers());
/*     */       }
/* 106 */       catch (Exception e) {
/*     */         
/* 108 */         System.err.println(files[i] + " not loadable: " + e.getMessage());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 114 */         doc.save(System.out, (new XmlOptions()).setSavePrettyPrint().setSavePrettyPrintIndent(indent));
/*     */       }
/* 116 */       catch (IOException e) {
/*     */         
/* 118 */         System.err.println("Unable to pretty print " + files[i] + ": " + e.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String indent(String xmldoc) throws IOException, XmlException {
/* 126 */     StringWriter sw = new StringWriter();
/* 127 */     XmlObject doc = XmlObject.Factory.parse(xmldoc, (new XmlOptions()).setLoadLineNumbers());
/* 128 */     doc.save(sw, (new XmlOptions()).setSavePrettyPrint().setSavePrettyPrintIndent(2));
/* 129 */     sw.close();
/* 130 */     return sw.getBuffer().toString();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\PrettyPrinter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */