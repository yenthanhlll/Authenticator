/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.impl.common.IOUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandLine
/*     */ {
/*     */   private Map _options;
/*     */   private String[] _badopts;
/*     */   private String[] _args;
/*     */   private List _files;
/*     */   private List _urls;
/*     */   private File _baseDir;
/*     */   
/*     */   public CommandLine(String[] args, Collection flags, Collection scheme) {
/*  37 */     if (flags == null || scheme == null) {
/*  38 */       throw new IllegalArgumentException("collection required (use Collections.EMPTY_SET if no options)");
/*     */     }
/*  40 */     this._options = new LinkedHashMap();
/*  41 */     ArrayList badopts = new ArrayList();
/*  42 */     ArrayList endargs = new ArrayList();
/*     */     
/*  44 */     for (int i = 0; i < args.length; i++) {
/*     */       
/*  46 */       if (args[i].indexOf('-') == 0) {
/*     */         
/*  48 */         String opt = args[i].substring(1);
/*  49 */         String val = null;
/*     */         
/*  51 */         if (flags.contains(opt)) {
/*  52 */           val = "";
/*  53 */         } else if (scheme.contains(opt)) {
/*     */           
/*  55 */           if (i + 1 < args.length) {
/*  56 */             val = args[++i];
/*     */           } else {
/*  58 */             val = "";
/*     */           } 
/*     */         } else {
/*  61 */           badopts.add(args[i]);
/*     */         } 
/*  63 */         this._options.put(opt, val);
/*     */       }
/*     */       else {
/*     */         
/*  67 */         endargs.add(args[i]);
/*     */       } 
/*     */     } 
/*     */     
/*  71 */     this._badopts = badopts.<String>toArray(new String[badopts.size()]);
/*  72 */     this._args = endargs.<String>toArray(new String[endargs.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printLicense() {
/*     */     try {
/*  79 */       IOUtil.copyCompletely(CommandLine.class.getClassLoader().getResourceAsStream("LICENSE.txt"), System.out);
/*     */     }
/*  81 */     catch (Exception e) {
/*     */       
/*  83 */       System.out.println("License available in this JAR in LICENSE.txt");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printVersion() {
/*  89 */     System.out.println(XmlBeans.getVendor() + ", " + XmlBeans.getTitle() + ".XmlBeans version " + XmlBeans.getVersion());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] args() {
/*  98 */     String[] result = new String[this._args.length];
/*  99 */     System.arraycopy(this._args, 0, result, 0, this._args.length);
/* 100 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getBadOpts() {
/* 105 */     return this._badopts;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getOpt(String opt) {
/* 110 */     return (String)this._options.get(opt);
/*     */   }
/*     */ 
/*     */   
/*     */   private static List collectFiles(File[] dirs) {
/* 115 */     List files = new ArrayList();
/* 116 */     for (int i = 0; i < dirs.length; i++) {
/*     */       
/* 118 */       File f = dirs[i];
/* 119 */       if (!f.isDirectory()) {
/*     */         
/* 121 */         files.add(f);
/*     */       }
/*     */       else {
/*     */         
/* 125 */         files.addAll(collectFiles(f.listFiles()));
/*     */       } 
/*     */     } 
/* 128 */     return files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   private static final File[] EMPTY_FILEARRAY = new File[0];
/* 135 */   private static final URL[] EMPTY_URLARRAY = new URL[0];
/*     */ 
/*     */   
/*     */   private List getFileList() {
/* 139 */     if (this._files == null) {
/*     */       
/* 141 */       String[] args = args();
/* 142 */       File[] files = new File[args.length];
/* 143 */       boolean noBaseDir = false;
/* 144 */       for (int i = 0; i < args.length; i++) {
/*     */         
/* 146 */         files[i] = new File(args[i]);
/* 147 */         if (!noBaseDir && this._baseDir == null) {
/*     */           
/* 149 */           if (files[i].isDirectory()) {
/* 150 */             this._baseDir = files[i];
/*     */           } else {
/* 152 */             this._baseDir = files[i].getParentFile();
/*     */           } 
/*     */         } else {
/*     */           
/* 156 */           URI currUri = files[i].toURI();
/*     */ 
/*     */           
/* 159 */           if (this._baseDir != null && this._baseDir.toURI().relativize(currUri).equals(currUri)) {
/*     */             
/* 161 */             this._baseDir = null;
/* 162 */             noBaseDir = true;
/*     */           } 
/*     */         } 
/*     */       } 
/* 166 */       this._files = Collections.unmodifiableList(collectFiles(files));
/*     */     } 
/* 168 */     return this._files;
/*     */   }
/*     */ 
/*     */   
/*     */   private List getUrlList() {
/* 173 */     if (this._urls == null) {
/*     */       
/* 175 */       String[] args = args();
/* 176 */       List urls = new ArrayList();
/*     */       
/* 178 */       for (int i = 0; i < args.length; i++) {
/*     */         
/* 180 */         if (looksLikeURL(args[i])) {
/*     */           
/*     */           try {
/*     */             
/* 184 */             urls.add(new URL(args[i]));
/*     */           }
/* 186 */           catch (MalformedURLException mfEx) {
/*     */             
/* 188 */             System.err.println("ignoring invalid url: " + args[i] + ": " + mfEx.getMessage());
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 193 */       this._urls = Collections.unmodifiableList(urls);
/*     */     } 
/*     */     
/* 196 */     return this._urls;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean looksLikeURL(String str) {
/* 201 */     return (str.startsWith("http:") || str.startsWith("https:") || str.startsWith("ftp:") || str.startsWith("file:"));
/*     */   }
/*     */ 
/*     */   
/*     */   public URL[] getURLs() {
/* 206 */     return (URL[])getUrlList().toArray((Object[])EMPTY_URLARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   public File[] getFiles() {
/* 211 */     return (File[])getFileList().toArray((Object[])EMPTY_FILEARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   public File getBaseDir() {
/* 216 */     return this._baseDir;
/*     */   }
/*     */ 
/*     */   
/*     */   public File[] filesEndingWith(String ext) {
/* 221 */     List result = new ArrayList();
/* 222 */     for (Iterator i = getFileList().iterator(); i.hasNext(); ) {
/*     */       
/* 224 */       File f = i.next();
/* 225 */       if (f.getName().endsWith(ext) && !looksLikeURL(f.getPath()))
/* 226 */         result.add(f); 
/*     */     } 
/* 228 */     return result.<File>toArray(EMPTY_FILEARRAY);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\CommandLine.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */