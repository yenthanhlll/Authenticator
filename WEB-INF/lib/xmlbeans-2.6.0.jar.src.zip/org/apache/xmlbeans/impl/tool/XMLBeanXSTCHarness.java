/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLBeanXSTCHarness
/*     */   implements XSTCTester.Harness
/*     */ {
/*     */   public void runTestCase(XSTCTester.TestCaseResult result) {
/*  35 */     XSTCTester.TestCase testCase = result.getTestCase();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  41 */       Collection errors = new ArrayList();
/*  42 */       boolean schemaValid = true;
/*  43 */       boolean instanceValid = true;
/*     */       
/*  45 */       if (testCase.getSchemaFile() == null) {
/*     */         return;
/*     */       }
/*     */       
/*  49 */       SchemaTypeLoader loader = null;
/*     */       
/*     */       try {
/*  52 */         XmlObject schema = XmlObject.Factory.parse(testCase.getSchemaFile(), (new XmlOptions()).setErrorListener(errors).setLoadLineNumbers());
/*  53 */         XmlObject schema2 = null;
/*  54 */         if (testCase.getResourceFile() != null)
/*  55 */           schema2 = XmlObject.Factory.parse(testCase.getResourceFile(), (new XmlOptions()).setErrorListener(errors).setLoadLineNumbers()); 
/*  56 */         (new XmlObject[1])[0] = schema; (new XmlObject[2])[0] = schema; (new XmlObject[2])[1] = schema2; XmlObject[] schemas = (schema2 == null) ? new XmlObject[1] : new XmlObject[2];
/*  57 */         SchemaTypeSystem system = XmlBeans.compileXsd(schemas, (SchemaTypeLoader)XmlBeans.getBuiltinTypeSystem(), (new XmlOptions()).setErrorListener(errors));
/*  58 */         loader = XmlBeans.typeLoaderUnion(new SchemaTypeLoader[] { (SchemaTypeLoader)system, (SchemaTypeLoader)XmlBeans.getBuiltinTypeSystem() });
/*     */       }
/*  60 */       catch (Exception e) {
/*     */         
/*  62 */         schemaValid = false;
/*  63 */         if (!(e instanceof org.apache.xmlbeans.XmlException) || errors.isEmpty()) {
/*     */           
/*  65 */           result.setCrash(true);
/*  66 */           StringWriter sw = new StringWriter();
/*  67 */           e.printStackTrace(new PrintWriter(sw));
/*  68 */           result.addSvMessages(Collections.singleton(sw.toString()));
/*     */         } 
/*     */       } 
/*     */       
/*  72 */       result.addSvMessages(errors);
/*  73 */       result.setSvActual(schemaValid);
/*  74 */       errors.clear();
/*     */       
/*  76 */       if (loader == null) {
/*     */         return;
/*     */       }
/*  79 */       if (testCase.getInstanceFile() == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/*  85 */         XmlObject instance = loader.parse(testCase.getInstanceFile(), null, (new XmlOptions()).setErrorListener(errors).setLoadLineNumbers());
/*  86 */         if (!instance.validate((new XmlOptions()).setErrorListener(errors))) {
/*  87 */           instanceValid = false;
/*     */         }
/*  89 */       } catch (Exception e) {
/*     */         
/*  91 */         instanceValid = false;
/*  92 */         if (!(e instanceof org.apache.xmlbeans.XmlException) || errors.isEmpty()) {
/*     */           
/*  94 */           result.setCrash(true);
/*  95 */           StringWriter sw = new StringWriter();
/*  96 */           e.printStackTrace(new PrintWriter(sw));
/*  97 */           result.addIvMessages(Collections.singleton(sw.toString()));
/*     */         } 
/*     */       } 
/* 100 */       result.addIvMessages(errors);
/* 101 */       result.setIvActual(instanceValid);
/*     */     } finally {}
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\XMLBeanXSTCHarness.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */