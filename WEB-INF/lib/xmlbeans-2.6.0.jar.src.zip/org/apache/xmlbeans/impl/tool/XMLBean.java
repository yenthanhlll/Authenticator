/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URI;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.Project;
/*     */ import org.apache.tools.ant.taskdefs.Jar;
/*     */ import org.apache.tools.ant.taskdefs.Javac;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import org.apache.xmlbeans.XmlError;
/*     */ import org.apache.xmlbeans.impl.common.IOUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLBean
/*     */   extends MatchingTask
/*     */ {
/*  51 */   private ArrayList schemas = new ArrayList();
/*     */   
/*     */   private Set mdefnamespaces;
/*     */   
/*     */   private Path classpath;
/*     */   
/*     */   private File destfile;
/*     */   
/*     */   private File schema;
/*     */   
/*     */   private File srcgendir;
/*     */   
/*     */   private File classgendir;
/*     */   private boolean quiet;
/*     */   private boolean verbose;
/*     */   private boolean debug;
/*     */   private boolean optimize;
/*     */   private boolean download;
/*     */   private boolean srconly;
/*     */   private boolean noupa;
/*     */   private boolean nopvr;
/*     */   private boolean noann;
/*     */   private boolean novdoc;
/*     */   private boolean noext = false;
/*     */   private boolean failonerror = true;
/*     */   private boolean fork = true;
/*     */   private boolean includeAntRuntime = true;
/*     */   private boolean noSrcRegen;
/*     */   private boolean includeJavaRuntime = false;
/*     */   private String typesystemname;
/*     */   private String forkedExecutable;
/*     */   private String compiler;
/*     */   private String debugLevel;
/*     */   private String memoryInitialSize;
/*     */   private String memoryMaximumSize;
/*     */   private String catalog;
/*     */   private String javasource;
/*  88 */   private List extensions = new ArrayList();
/*     */   
/*  90 */   private HashMap _extRouter = new HashMap(5);
/*     */   
/*     */   private static final String XSD = ".xsd";
/*     */   
/*     */   private static final String WSDL = ".wsdl";
/*     */   
/*     */   private static final String JAVA = ".java";
/*     */   
/*     */   private static final String XSDCONFIG = ".xsdconfig";
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/* 102 */     if (this.schemas.size() == 0 && this.schema == null && this.fileset.getDir(this.project) == null) {
/*     */ 
/*     */ 
/*     */       
/* 106 */       String msg = "The 'schema' or 'dir' attribute or a nested fileset is required.";
/* 107 */       if (this.failonerror) {
/* 108 */         throw new BuildException(msg);
/*     */       }
/*     */       
/* 111 */       log(msg, 0);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 116 */     this._extRouter.put(".xsd", new HashSet());
/* 117 */     this._extRouter.put(".wsdl", new HashSet());
/* 118 */     this._extRouter.put(".java", new HashSet());
/* 119 */     this._extRouter.put(".xsdconfig", new HashSet());
/*     */     
/* 121 */     File theBasedir = this.schema;
/*     */     
/* 123 */     if (this.schema != null)
/*     */     {
/* 125 */       if (this.schema.isDirectory()) {
/*     */         
/* 127 */         DirectoryScanner directoryScanner = getDirectoryScanner(this.schema);
/* 128 */         String[] paths = directoryScanner.getIncludedFiles();
/* 129 */         processPaths(paths, directoryScanner.getBasedir());
/*     */       }
/*     */       else {
/*     */         
/* 133 */         theBasedir = this.schema.getParentFile();
/* 134 */         processPaths(new String[] { this.schema.getName() }, theBasedir);
/*     */       } 
/*     */     }
/*     */     
/* 138 */     if (this.fileset.getDir(this.project) != null) {
/* 139 */       this.schemas.add(this.fileset);
/*     */     }
/* 141 */     Iterator si = this.schemas.iterator();
/* 142 */     while (si.hasNext()) {
/*     */       
/* 144 */       FileSet fs = si.next();
/* 145 */       DirectoryScanner directoryScanner = fs.getDirectoryScanner(this.project);
/* 146 */       File basedir = directoryScanner.getBasedir();
/* 147 */       String[] paths = directoryScanner.getIncludedFiles();
/*     */       
/* 149 */       processPaths(paths, basedir);
/*     */     } 
/*     */     
/* 152 */     Set xsdList = (Set)this._extRouter.get(".xsd");
/* 153 */     Set wsdlList = (Set)this._extRouter.get(".wsdl");
/*     */     
/* 155 */     if (xsdList.size() + wsdlList.size() == 0) {
/*     */       
/* 157 */       log("Could not find any xsd or wsdl files to process.", 1);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 162 */     Set javaList = (Set)this._extRouter.get(".java");
/* 163 */     Set xsdconfigList = (Set)this._extRouter.get(".xsdconfig");
/*     */     
/* 165 */     if (this.srcgendir == null && this.srconly) {
/* 166 */       this.srcgendir = this.classgendir;
/*     */     }
/* 168 */     if (this.destfile == null && this.classgendir == null && !this.srconly) {
/* 169 */       this.destfile = new File("xmltypes.jar");
/*     */     }
/* 171 */     if (this.verbose) {
/* 172 */       this.quiet = false;
/*     */     }
/*     */ 
/*     */     
/* 176 */     File[] xsdArray = (File[])xsdList.toArray((Object[])new File[xsdList.size()]);
/* 177 */     File[] wsdlArray = (File[])wsdlList.toArray((Object[])new File[wsdlList.size()]);
/* 178 */     File[] javaArray = (File[])javaList.toArray((Object[])new File[javaList.size()]);
/* 179 */     File[] xsdconfigArray = (File[])xsdconfigList.toArray((Object[])new File[xsdconfigList.size()]);
/* 180 */     ErrorLogger err = new ErrorLogger(this.verbose);
/*     */     
/* 182 */     boolean success = false;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 187 */       File tmpdir = null;
/* 188 */       if (this.srcgendir == null || this.classgendir == null)
/*     */       {
/* 190 */         tmpdir = SchemaCodeGenerator.createTempDir();
/*     */       }
/* 192 */       if (this.srcgendir == null)
/* 193 */         this.srcgendir = IOUtil.createDir(tmpdir, "src"); 
/* 194 */       if (this.classgendir == null) {
/* 195 */         this.classgendir = IOUtil.createDir(tmpdir, "classes");
/*     */       }
/*     */       
/* 198 */       if (this.classpath == null) {
/*     */         
/* 200 */         this.classpath = new Path(this.project);
/* 201 */         this.classpath.concatSystemClasspath();
/*     */       } 
/*     */ 
/*     */       
/* 205 */       Path.PathElement pathElement = this.classpath.createPathElement();
/* 206 */       pathElement.setLocation(this.classgendir);
/*     */       
/* 208 */       String[] paths = this.classpath.list();
/* 209 */       File[] cp = new File[paths.length];
/* 210 */       for (int i = 0; i < paths.length; i++) {
/* 211 */         cp[i] = new File(paths[i]);
/*     */       }
/*     */       
/* 214 */       SchemaCompiler.Parameters params = new SchemaCompiler.Parameters();
/* 215 */       params.setBaseDir(theBasedir);
/* 216 */       params.setXsdFiles(xsdArray);
/* 217 */       params.setWsdlFiles(wsdlArray);
/* 218 */       params.setJavaFiles(javaArray);
/* 219 */       params.setConfigFiles(xsdconfigArray);
/* 220 */       params.setClasspath(cp);
/* 221 */       params.setName(this.typesystemname);
/* 222 */       params.setSrcDir(this.srcgendir);
/* 223 */       params.setClassesDir(this.classgendir);
/* 224 */       params.setNojavac(true);
/* 225 */       params.setDebug(this.debug);
/* 226 */       params.setVerbose(this.verbose);
/* 227 */       params.setQuiet(this.quiet);
/* 228 */       params.setDownload(this.download);
/* 229 */       params.setExtensions(this.extensions);
/* 230 */       params.setErrorListener(err);
/* 231 */       params.setCatalogFile(this.catalog);
/* 232 */       params.setIncrementalSrcGen(this.noSrcRegen);
/* 233 */       params.setMdefNamespaces(this.mdefnamespaces);
/* 234 */       params.setNoUpa(this.noupa);
/* 235 */       params.setNoPvr(this.nopvr);
/* 236 */       params.setNoAnn(this.noann);
/* 237 */       params.setNoVDoc(this.novdoc);
/* 238 */       params.setNoExt(this.noext);
/* 239 */       params.setJavaSource(this.javasource);
/* 240 */       success = SchemaCompiler.compile(params);
/*     */       
/* 242 */       if (success && !this.srconly) {
/* 243 */         long start = System.currentTimeMillis();
/*     */ 
/*     */         
/* 246 */         Javac javac = new Javac();
/* 247 */         javac.setProject(this.project);
/* 248 */         javac.setTaskName(getTaskName());
/* 249 */         javac.setClasspath(this.classpath);
/* 250 */         if (this.compiler != null) javac.setCompiler(this.compiler); 
/* 251 */         javac.setDebug(this.debug);
/* 252 */         if (this.debugLevel != null) javac.setDebugLevel(this.debugLevel); 
/* 253 */         javac.setDestdir(this.classgendir);
/* 254 */         javac.setExecutable(this.forkedExecutable);
/* 255 */         javac.setFailonerror(this.failonerror);
/* 256 */         javac.setFork(this.fork);
/* 257 */         if (this.javasource != null) {
/*     */           
/* 259 */           javac.setSource(this.javasource);
/* 260 */           javac.setTarget(this.javasource);
/*     */         }
/*     */         else {
/*     */           
/* 264 */           javac.setSource("1.4");
/* 265 */           javac.setTarget("1.4");
/*     */         } 
/* 267 */         javac.setIncludeantruntime(this.includeAntRuntime);
/* 268 */         javac.setIncludejavaruntime(this.includeJavaRuntime);
/* 269 */         javac.setSrcdir(new Path(this.project, this.srcgendir.getAbsolutePath()));
/* 270 */         if (this.memoryInitialSize != null) javac.setMemoryInitialSize(this.memoryInitialSize); 
/* 271 */         if (this.memoryMaximumSize != null) javac.setMemoryMaximumSize(this.memoryMaximumSize); 
/* 272 */         javac.setOptimize(this.optimize);
/* 273 */         javac.setVerbose(this.verbose);
/* 274 */         javac.execute();
/*     */         
/* 276 */         long finish = System.currentTimeMillis();
/* 277 */         if (!this.quiet) {
/* 278 */           log("Time to compile code: " + ((finish - start) / 1000.0D) + " seconds");
/*     */         }
/* 280 */         if (this.destfile != null) {
/*     */ 
/*     */           
/* 283 */           Jar jar = new Jar();
/* 284 */           jar.setProject(this.project);
/* 285 */           jar.setTaskName(getTaskName());
/* 286 */           jar.setBasedir(this.classgendir);
/* 287 */           jar.setDestFile(this.destfile);
/* 288 */           jar.execute();
/*     */         } 
/*     */       } 
/*     */       
/* 292 */       if (tmpdir != null) {
/* 293 */         SchemaCodeGenerator.tryHardToDelete(tmpdir);
/*     */       }
/*     */     }
/* 296 */     catch (BuildException e) {
/*     */ 
/*     */       
/* 299 */       throw e;
/*     */     }
/* 301 */     catch (Throwable e) {
/*     */ 
/*     */       
/* 304 */       if (e instanceof InterruptedException || this.failonerror) {
/* 305 */         throw new BuildException(e);
/*     */       }
/* 307 */       log("Exception while building schemas: " + e.getMessage(), 0);
/* 308 */       StringWriter sw = new StringWriter();
/* 309 */       e.printStackTrace(new PrintWriter(sw));
/* 310 */       log(sw.toString(), 3);
/*     */     } 
/*     */     
/* 313 */     if (!success && this.failonerror) {
/* 314 */       throw new BuildException();
/*     */     }
/*     */   }
/*     */   
/*     */   private void processPaths(String[] paths, File baseDir) {
/* 319 */     for (int i = 0; i < paths.length; i++) {
/*     */       
/* 321 */       int dot = paths[i].lastIndexOf('.');
/* 322 */       if (dot > -1) {
/*     */         
/* 324 */         String path = paths[i];
/* 325 */         String possExt = path.substring(dot).toLowerCase();
/* 326 */         Set set = (Set)this._extRouter.get(possExt);
/*     */         
/* 328 */         if (set != null) {
/* 329 */           set.add(new File(baseDir, path));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addFileset(FileSet fileset) {
/* 336 */     this.schemas.add(fileset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getSchema() {
/* 343 */     return this.schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(File schema) {
/* 354 */     this.schema = schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClasspath(Path classpath) {
/* 365 */     if (this.classpath != null) {
/* 366 */       this.classpath.append(classpath);
/*     */     } else {
/* 368 */       this.classpath = classpath;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 375 */     if (this.classpath == null) {
/* 376 */       this.classpath = new Path(this.project);
/*     */     }
/* 378 */     return this.classpath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClasspathRef(Reference classpathref) {
/* 387 */     if (this.classpath == null) {
/* 388 */       this.classpath = new Path(this.project);
/*     */     }
/* 390 */     this.classpath.createPath().setRefid(classpathref);
/*     */   }
/*     */ 
/*     */   
/*     */   public Path getClasspath() {
/* 395 */     return this.classpath;
/*     */   }
/*     */ 
/*     */   
/*     */   public File getDestfile() {
/* 400 */     return this.destfile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDestfile(File destfile) {
/* 411 */     this.destfile = destfile;
/*     */   }
/*     */ 
/*     */   
/*     */   public File getSrcgendir() {
/* 416 */     return this.srcgendir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSrcgendir(File srcgendir) {
/* 426 */     this.srcgendir = srcgendir;
/*     */   }
/*     */ 
/*     */   
/*     */   public File getClassgendir() {
/* 431 */     return this.classgendir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassgendir(File classgendir) {
/* 441 */     this.classgendir = classgendir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompiler(String compiler) {
/* 451 */     this.compiler = compiler;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDownload() {
/* 456 */     return this.download;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDownload(boolean download) {
/* 467 */     this.download = download;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptimize(boolean optimize) {
/* 474 */     this.optimize = optimize;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getOptimize() {
/* 479 */     return this.optimize;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVerbose() {
/* 484 */     return this.verbose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/* 493 */     this.verbose = verbose;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isQuiet() {
/* 498 */     return this.quiet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQuiet(boolean quiet) {
/* 507 */     this.quiet = quiet;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebug() {
/* 512 */     return this.debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDebugLevel() {
/* 520 */     return this.debugLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDebugLevel(String v) {
/* 536 */     this.debugLevel = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDebug(boolean debug) {
/* 545 */     this.debug = debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFork(boolean f) {
/* 554 */     this.fork = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExecutable(String forkExec) {
/* 564 */     this.forkedExecutable = forkExec;
/*     */   }
/*     */   
/*     */   public String getExecutable() {
/* 568 */     return this.forkedExecutable;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSrconly() {
/* 573 */     return this.srconly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSrconly(boolean srconly) {
/* 583 */     this.srconly = srconly;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTypesystemname() {
/* 588 */     return this.typesystemname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Extension createExtension() {
/* 596 */     Extension e = new Extension();
/* 597 */     this.extensions.add(e);
/* 598 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreDuplicatesInNamespaces(String namespaces) {
/* 606 */     this.mdefnamespaces = new HashSet();
/* 607 */     StringTokenizer st = new StringTokenizer(namespaces, ",");
/* 608 */     while (st.hasMoreTokens()) {
/*     */       
/* 610 */       String namespace = st.nextToken().trim();
/* 611 */       this.mdefnamespaces.add(namespace);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getIgnoreDuplicatesInNamespaces() {
/* 616 */     if (this.mdefnamespaces == null) {
/* 617 */       return null;
/*     */     }
/* 619 */     StringBuffer buf = new StringBuffer();
/* 620 */     Iterator i = this.mdefnamespaces.iterator();
/* 621 */     while (i.hasNext()) {
/* 622 */       buf.append(i.next());
/* 623 */       if (i.hasNext()) {
/* 624 */         buf.append(",");
/*     */       }
/*     */     } 
/* 627 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypesystemname(String typesystemname) {
/* 639 */     this.typesystemname = typesystemname;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFailonerror() {
/* 644 */     return this.failonerror;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailonerror(boolean failonerror) {
/* 654 */     this.failonerror = failonerror;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIncludeAntRuntime() {
/* 659 */     return this.includeAntRuntime;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIncludeAntRuntime(boolean includeAntRuntime) {
/* 664 */     this.includeAntRuntime = includeAntRuntime;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIncludeJavaRuntime() {
/* 669 */     return this.includeJavaRuntime;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIncludeJavaRuntime(boolean includeJavaRuntime) {
/* 674 */     this.includeJavaRuntime = includeJavaRuntime;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoSrcRegen() {
/* 679 */     return this.noSrcRegen;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNoSrcRegen(boolean noSrcRegen) {
/* 684 */     this.noSrcRegen = noSrcRegen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemoryInitialSize() {
/* 692 */     return this.memoryInitialSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMemoryInitialSize(String memoryInitialSize) {
/* 697 */     this.memoryInitialSize = memoryInitialSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemoryMaximumSize() {
/* 705 */     return this.memoryMaximumSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMemoryMaximumSize(String memoryMaximumSize) {
/* 710 */     this.memoryMaximumSize = memoryMaximumSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoUpa(boolean noupa) {
/* 718 */     this.noupa = noupa;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoUpa() {
/* 723 */     return this.noupa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoPvr(boolean nopvr) {
/* 731 */     this.nopvr = nopvr;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoPvr() {
/* 736 */     return this.nopvr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoAnnotations(boolean noann) {
/* 744 */     this.noann = noann;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoAnnotations() {
/* 749 */     return this.noann;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoValidateDoc(boolean novdoc) {
/* 757 */     this.novdoc = novdoc;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoValidateDoc() {
/* 762 */     return this.novdoc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNoExt(boolean noext) {
/* 771 */     this.noext = noext;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoExt() {
/* 776 */     return this.noext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaSource(String javasource) {
/* 785 */     this.javasource = javasource;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getJavaSource() {
/* 790 */     return this.javasource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 796 */   private String source = null; public void setSource(String s) {
/* 797 */     this.source = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalog() {
/* 804 */     return this.catalog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(String catalog) {
/* 812 */     this.catalog = catalog;
/*     */   }
/*     */ 
/*     */   
/*     */   private static URI uriFromFile(File f) {
/* 817 */     if (f == null) {
/* 818 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 822 */       return f.getCanonicalFile().toURI();
/*     */     }
/* 824 */     catch (IOException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 830 */       return f.getAbsoluteFile().toURI();
/*     */     } 
/*     */   }
/*     */   
/*     */   public class ErrorLogger
/*     */     extends AbstractCollection {
/*     */     private boolean _noisy;
/*     */     private URI _baseURI;
/*     */     private final XMLBean this$0;
/*     */     
/*     */     public ErrorLogger(boolean noisy) {
/* 841 */       this._noisy = noisy;
/* 842 */       this._baseURI = XMLBean.uriFromFile(XMLBean.this.project.getBaseDir());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(Object o) {
/* 847 */       if (o instanceof XmlError) {
/*     */         
/* 849 */         XmlError err = (XmlError)o;
/* 850 */         if (err.getSeverity() == 0) {
/* 851 */           XMLBean.this.log(err.toString(this._baseURI), 0);
/* 852 */         } else if (err.getSeverity() == 1) {
/* 853 */           XMLBean.this.log(err.toString(this._baseURI), 1);
/* 854 */         } else if (this._noisy) {
/* 855 */           XMLBean.this.log(err.toString(this._baseURI), 2);
/*     */         } 
/* 857 */       }  return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator iterator() {
/* 862 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 867 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\XMLBean.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */