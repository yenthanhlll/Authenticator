/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.common.IOUtil;
/*     */ import org.apache.xmlbeans.impl.xb.substwsdl.DefinitionsDocument;
/*     */ import org.apache.xmlbeans.impl.xb.substwsdl.TImport;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.ImportDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.IncludeDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaCopy
/*     */ {
/*     */   public static void printUsage() {
/*  43 */     System.out.println("Copies the XML schema at the specified URL to the specified file.");
/*  44 */     System.out.println("Usage: scopy sourceurl [targetfile]");
/*  45 */     System.out.println("    sourceurl - The URL at which the schema is located.");
/*  46 */     System.out.println("    targetfile - The file to which the schema should be copied.");
/*  47 */     System.out.println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  53 */     if (args.length < 1 || args.length > 2) {
/*     */       
/*  55 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/*  59 */     URI source = null;
/*  60 */     URI target = null;
/*     */ 
/*     */     
/*     */     try {
/*  64 */       if (args[0].compareToIgnoreCase("-usage") == 0) {
/*  65 */         printUsage();
/*     */         
/*     */         return;
/*     */       } 
/*  69 */       source = new URI(args[0]);
/*  70 */       source.toURL();
/*     */     }
/*  72 */     catch (Exception e) {
/*     */       
/*  74 */       System.err.println("Badly formed URL " + source);
/*     */       
/*     */       return;
/*     */     } 
/*  78 */     if (args.length < 2) {
/*     */ 
/*     */       
/*     */       try {
/*  82 */         URI dir = (new File(".")).getCanonicalFile().toURI();
/*  83 */         String lastPart = source.getPath();
/*  84 */         lastPart = lastPart.substring(lastPart.lastIndexOf('/') + 1);
/*  85 */         target = CodeGenUtil.resolve(dir, URI.create(lastPart));
/*     */       }
/*  87 */       catch (Exception e) {
/*     */         
/*  89 */         System.err.println("Cannot canonicalize current directory");
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } else {
/*     */       try {
/*  97 */         target = new URI(args[1]);
/*  98 */         if (!target.isAbsolute()) {
/*  99 */           target = null;
/* 100 */         } else if (!target.getScheme().equals("file")) {
/* 101 */           target = null;
/*     */         } 
/* 103 */       } catch (Exception e) {
/*     */         
/* 105 */         target = null;
/*     */       } 
/*     */       
/* 108 */       if (target == null) {
/*     */         
/*     */         try {
/*     */           
/* 112 */           target = (new File(target)).getCanonicalFile().toURI();
/*     */         }
/* 114 */         catch (Exception e) {
/*     */           
/* 116 */           System.err.println("Cannot canonicalize current directory");
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */     } 
/* 122 */     Map thingsToCopy = findAllRelative(source, target);
/* 123 */     copyAll(thingsToCopy, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void copyAll(Map uriMap, boolean stdout) {
/* 128 */     for (Iterator i = uriMap.keySet().iterator(); i.hasNext(); ) {
/*     */       
/* 130 */       URI source = i.next();
/* 131 */       URI target = (URI)uriMap.get(source);
/*     */       
/*     */       try {
/* 134 */         IOUtil.copyCompletely(source, target);
/*     */       }
/* 136 */       catch (Exception e) {
/*     */         
/* 138 */         if (stdout)
/* 139 */           System.out.println("Could not copy " + source + " -> " + target); 
/*     */         continue;
/*     */       } 
/* 142 */       if (stdout) {
/* 143 */         System.out.println("Copied " + source + " -> " + target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map findAllRelative(URI source, URI target) {
/* 161 */     Map result = new LinkedHashMap();
/* 162 */     result.put(source, target);
/*     */     
/* 164 */     LinkedList process = new LinkedList();
/* 165 */     process.add(source);
/*     */     
/* 167 */     while (!process.isEmpty()) {
/*     */       
/* 169 */       URI nextSource = process.removeFirst();
/* 170 */       URI nextTarget = (URI)result.get(nextSource);
/* 171 */       Map nextResults = findRelativeInOne(nextSource, nextTarget);
/* 172 */       for (Iterator i = nextResults.keySet().iterator(); i.hasNext(); ) {
/*     */         
/* 174 */         URI newSource = i.next();
/* 175 */         if (result.containsKey(newSource))
/*     */           continue; 
/* 177 */         result.put(newSource, nextResults.get(newSource));
/* 178 */         process.add(newSource);
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     return result;
/*     */   }
/*     */   
/* 185 */   private static final XmlOptions loadOptions = (new XmlOptions()).setLoadSubstituteNamespaces(Collections.singletonMap("http://schemas.xmlsoap.org/wsdl/", "http://www.apache.org/internal/xmlbeans/wsdlsubst"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map findRelativeInOne(URI source, URI target) {
/*     */     try {
/* 194 */       URL sourceURL = source.toURL();
/* 195 */       XmlObject xobj = XmlObject.Factory.parse(sourceURL, loadOptions);
/* 196 */       XmlCursor xcur = xobj.newCursor();
/* 197 */       xcur.toFirstChild();
/*     */       
/* 199 */       Map result = new LinkedHashMap();
/*     */       
/* 201 */       if (xobj instanceof SchemaDocument) {
/* 202 */         putMappingsFromSchema(result, source, target, ((SchemaDocument)xobj).getSchema());
/* 203 */       } else if (xobj instanceof DefinitionsDocument) {
/* 204 */         putMappingsFromWsdl(result, source, target, ((DefinitionsDocument)xobj).getDefinitions());
/* 205 */       }  return result;
/*     */     }
/* 207 */     catch (Exception e) {
/*     */ 
/*     */ 
/*     */       
/* 211 */       return Collections.EMPTY_MAP;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void putNewMapping(Map result, URI origSource, URI origTarget, String literalURI) {
/*     */     try {
/* 218 */       if (literalURI == null)
/*     */         return; 
/* 220 */       URI newRelative = new URI(literalURI);
/* 221 */       if (newRelative.isAbsolute())
/*     */         return; 
/* 223 */       URI newSource = CodeGenUtil.resolve(origSource, newRelative);
/* 224 */       URI newTarget = CodeGenUtil.resolve(origTarget, newRelative);
/* 225 */       result.put(newSource, newTarget);
/*     */     }
/* 227 */     catch (URISyntaxException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void putMappingsFromSchema(Map result, URI source, URI target, SchemaDocument.Schema schema) {
/* 235 */     ImportDocument.Import[] imports = schema.getImportArray();
/* 236 */     for (int i = 0; i < imports.length; i++) {
/* 237 */       putNewMapping(result, source, target, imports[i].getSchemaLocation());
/*     */     }
/* 239 */     IncludeDocument.Include[] includes = schema.getIncludeArray();
/* 240 */     for (int j = 0; j < includes.length; j++) {
/* 241 */       putNewMapping(result, source, target, includes[j].getSchemaLocation());
/*     */     }
/*     */   }
/*     */   
/*     */   private static void putMappingsFromWsdl(Map result, URI source, URI target, DefinitionsDocument.Definitions wdoc) {
/* 246 */     XmlObject[] types = wdoc.getTypesArray();
/* 247 */     for (int i = 0; i < types.length; i++) {
/*     */       
/* 249 */       SchemaDocument.Schema[] schemas = (SchemaDocument.Schema[])types[i].selectPath("declare namespace xs='http://www.w3.org/2001/XMLSchema' xs:schema");
/* 250 */       for (int k = 0; k < schemas.length; k++) {
/* 251 */         putMappingsFromSchema(result, source, target, schemas[k]);
/*     */       }
/*     */     } 
/* 254 */     TImport[] imports = wdoc.getImportArray();
/* 255 */     for (int j = 0; j < imports.length; j++)
/* 256 */       putNewMapping(result, source, target, imports[j].getLocation()); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\SchemaCopy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */