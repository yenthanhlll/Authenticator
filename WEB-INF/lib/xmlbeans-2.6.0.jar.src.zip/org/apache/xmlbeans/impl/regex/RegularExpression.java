/*      */ package org.apache.xmlbeans.impl.regex;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.text.CharacterIterator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RegularExpression
/*      */   implements Serializable
/*      */ {
/*      */   static final boolean DEBUG = false;
/*      */   String regex;
/*      */   int options;
/*      */   int nofparen;
/*      */   Token tokentree;
/*      */   
/*      */   private synchronized void compile(Token tok) {
/*  487 */     if (this.operations != null)
/*      */       return; 
/*  489 */     this.numberOfClosures = 0;
/*  490 */     this.operations = compile(tok, null, false); } private Op compile(Token tok, Op next, boolean reverse) { Op ret; Op.UnionOp uni; int i; Token child;
/*      */     int min;
/*      */     int max;
/*      */     Token.ConditionToken ctok;
/*      */     int ref;
/*      */     Op condition;
/*      */     Op yes;
/*      */     Op no;
/*  498 */     switch (tok.type) {
/*      */       case 11:
/*  500 */         ret = Op.createDot();
/*  501 */         ret.next = next;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  648 */         return ret;case 0: ret = Op.createChar(tok.getChar()); ret.next = next; return ret;case 8: ret = Op.createAnchor(tok.getChar()); ret.next = next; return ret;case 4: case 5: ret = Op.createRange(tok); ret.next = next; return ret;case 1: ret = next; if (!reverse) { for (int j = tok.size() - 1; j >= 0; j--) ret = compile(tok.getChild(j), ret, false);  } else { for (int j = 0; j < tok.size(); j++) ret = compile(tok.getChild(j), ret, true);  }  return ret;case 2: uni = Op.createUnion(tok.size()); for (i = 0; i < tok.size(); i++) uni.addElement(compile(tok.getChild(i), next, reverse));  ret = uni; return ret;case 3: case 9: child = tok.getChild(0); min = tok.getMin(); max = tok.getMax(); if (min >= 0 && min == max) { ret = next; for (int j = 0; j < min; j++) ret = compile(child, ret, reverse);  } else { if (min > 0 && max > 0) max -= min;  if (max > 0) { ret = next; for (int j = 0; j < max; j++) { Op.ChildOp q = Op.createQuestion((tok.type == 9)); q.next = next; q.setChild(compile(child, ret, reverse)); ret = q; }  } else { Op.ChildOp op; if (tok.type == 9) { op = Op.createNonGreedyClosure(); } else if (child.getMinLength() == 0) { op = Op.createClosure(this.numberOfClosures++); } else { op = Op.createClosure(-1); }  op.next = next; op.setChild(compile(child, op, reverse)); ret = op; }  if (min > 0) for (int j = 0; j < min; j++) ret = compile(child, ret, reverse);   }  return ret;case 7: ret = next; return ret;case 10: ret = Op.createString(tok.getString()); ret.next = next; return ret;case 12: ret = Op.createBackReference(tok.getReferenceNumber()); ret.next = next; return ret;case 6: if (tok.getParenNumber() == 0) { ret = compile(tok.getChild(0), next, reverse); } else if (reverse) { next = Op.createCapture(tok.getParenNumber(), next); next = compile(tok.getChild(0), next, reverse); ret = Op.createCapture(-tok.getParenNumber(), next); } else { next = Op.createCapture(-tok.getParenNumber(), next); next = compile(tok.getChild(0), next, reverse); ret = Op.createCapture(tok.getParenNumber(), next); }  return ret;case 20: ret = Op.createLook(20, next, compile(tok.getChild(0), null, false)); return ret;case 21: ret = Op.createLook(21, next, compile(tok.getChild(0), null, false)); return ret;case 22: ret = Op.createLook(22, next, compile(tok.getChild(0), null, true)); return ret;case 23: ret = Op.createLook(23, next, compile(tok.getChild(0), null, true)); return ret;case 24: ret = Op.createIndependent(next, compile(tok.getChild(0), null, reverse)); return ret;case 25: ret = Op.createModifier(next, compile(tok.getChild(0), null, reverse), ((Token.ModifierToken)tok).getOptions(), ((Token.ModifierToken)tok).getOptionsMask()); return ret;case 26: ctok = (Token.ConditionToken)tok; ref = ctok.refNumber; condition = (ctok.condition == null) ? null : compile(ctok.condition, null, reverse); yes = compile(ctok.yes, next, reverse); no = (ctok.no == null) ? null : compile(ctok.no, next, reverse); ret = Op.createCondition(next, ref, condition, yes, no); return ret;
/*      */     } 
/*      */     throw new RuntimeException("Unknown token type: " + tok.type); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target) {
/*  660 */     return matches(target, 0, target.length, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target, int start, int end) {
/*  672 */     return matches(target, start, end, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target, Match match) {
/*  682 */     return matches(target, 0, target.length, match);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target, int start, int end, Match match) {
/*      */     int matchStart;
/*  697 */     synchronized (this) {
/*  698 */       if (this.operations == null)
/*  699 */         prepare(); 
/*  700 */       if (this.context == null)
/*  701 */         this.context = new Context(); 
/*      */     } 
/*  703 */     Context con = null;
/*  704 */     synchronized (this.context) {
/*  705 */       con = this.context.inuse ? new Context() : this.context;
/*  706 */       con.reset(target, start, end, this.numberOfClosures);
/*      */     } 
/*  708 */     if (match != null) {
/*  709 */       match.setNumberOfGroups(this.nofparen);
/*  710 */       match.setSource(target);
/*  711 */     } else if (this.hasBackReferences) {
/*  712 */       match = new Match();
/*  713 */       match.setNumberOfGroups(this.nofparen);
/*      */     } 
/*      */ 
/*      */     
/*  717 */     con.match = match;
/*      */     
/*  719 */     if (isSet(this.options, 512)) {
/*  720 */       int i = matchCharArray(con, this.operations, con.start, 1, this.options);
/*      */       
/*  722 */       if (i == con.limit) {
/*  723 */         if (con.match != null) {
/*  724 */           con.match.setBeginning(0, con.start);
/*  725 */           con.match.setEnd(0, i);
/*      */         } 
/*  727 */         con.inuse = false;
/*  728 */         return true;
/*      */       } 
/*  730 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  737 */     if (this.fixedStringOnly) {
/*      */       
/*  739 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/*  740 */       if (o >= 0) {
/*  741 */         if (con.match != null) {
/*  742 */           con.match.setBeginning(0, o);
/*  743 */           con.match.setEnd(0, o + this.fixedString.length());
/*      */         } 
/*  745 */         con.inuse = false;
/*  746 */         return true;
/*      */       } 
/*  748 */       con.inuse = false;
/*  749 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  757 */     if (this.fixedString != null) {
/*  758 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/*  759 */       if (o < 0) {
/*      */         
/*  761 */         con.inuse = false;
/*  762 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  766 */     int limit = con.limit - this.minlength;
/*      */     
/*  768 */     int matchEnd = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  773 */     if (this.operations != null && this.operations.type == 7 && (this.operations.getChild()).type == 0) {
/*      */       
/*  775 */       if (isSet(this.options, 4)) {
/*  776 */         matchStart = con.start;
/*  777 */         matchEnd = matchCharArray(con, this.operations, con.start, 1, this.options);
/*      */       } else {
/*  779 */         boolean previousIsEOL = true;
/*  780 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/*  781 */           int ch = target[matchStart];
/*  782 */           if (isEOLChar(ch)) {
/*  783 */             previousIsEOL = true;
/*      */           } else {
/*  785 */             if (previousIsEOL && 
/*  786 */               0 <= (matchEnd = matchCharArray(con, this.operations, matchStart, 1, this.options))) {
/*      */               break;
/*      */             }
/*      */             
/*  790 */             previousIsEOL = false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  799 */     else if (this.firstChar != null) {
/*      */       
/*  801 */       RangeToken range = this.firstChar;
/*  802 */       if (isSet(this.options, 2)) {
/*  803 */         range = this.firstChar.getCaseInsensitiveToken();
/*  804 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/*  805 */           int ch = target[matchStart];
/*  806 */           if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit) {
/*  807 */             ch = REUtil.composeFromSurrogates(ch, target[matchStart + 1]);
/*  808 */             if (!range.match(ch))
/*      */               continue; 
/*  810 */           } else if (!range.match(ch)) {
/*  811 */             char ch1 = Character.toUpperCase((char)ch);
/*  812 */             if (!range.match(ch1) && 
/*  813 */               !range.match(Character.toLowerCase(ch1))) {
/*      */               continue;
/*      */             }
/*      */           } 
/*  817 */           if (0 <= (matchEnd = matchCharArray(con, this.operations, matchStart, 1, this.options)))
/*      */             break; 
/*      */           continue;
/*      */         } 
/*      */       } else {
/*  822 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/*  823 */           int ch = target[matchStart];
/*  824 */           if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit)
/*  825 */             ch = REUtil.composeFromSurrogates(ch, target[matchStart + 1]); 
/*  826 */           if (range.match(ch) && 
/*  827 */             0 <= (matchEnd = matchCharArray(con, this.operations, matchStart, 1, this.options)))
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  838 */       for (matchStart = con.start; matchStart <= limit && 
/*  839 */         0 > (matchEnd = matchCharArray(con, this.operations, matchStart, 1, this.options)); matchStart++);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  844 */     if (matchEnd >= 0) {
/*  845 */       if (con.match != null) {
/*  846 */         con.match.setBeginning(0, matchStart);
/*  847 */         con.match.setEnd(0, matchEnd);
/*      */       } 
/*  849 */       con.inuse = false;
/*  850 */       return true;
/*      */     } 
/*  852 */     con.inuse = false;
/*  853 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int matchCharArray(Context con, Op op, int offset, int dx, int opts) {
/*  862 */     char[] target = con.charTarget; while (true) {
/*      */       boolean go; int after; int j; String literal; int id; int ret; int i; int refno; int before; int o2; int literallen; int k; int localopts; Op.ConditionOp cop; int n;
/*      */       int m;
/*      */       boolean matchp;
/*  866 */       if (op == null)
/*  867 */         return (isSet(opts, 512) && offset != con.limit) ? -1 : offset; 
/*  868 */       if (offset > con.limit || offset < con.start)
/*  869 */         return -1; 
/*  870 */       switch (op.type) {
/*      */         case 1:
/*  872 */           if (isSet(opts, 2)) {
/*  873 */             int ch = op.getData();
/*  874 */             if (dx > 0) {
/*  875 */               if (offset >= con.limit || !matchIgnoreCase(ch, target[offset]))
/*  876 */                 return -1; 
/*  877 */               offset++;
/*      */             } else {
/*  879 */               int o1 = offset - 1;
/*  880 */               if (o1 >= con.limit || o1 < 0 || !matchIgnoreCase(ch, target[o1]))
/*  881 */                 return -1; 
/*  882 */               offset = o1;
/*      */             } 
/*      */           } else {
/*  885 */             int ch = op.getData();
/*  886 */             if (dx > 0) {
/*  887 */               if (offset >= con.limit || ch != target[offset])
/*  888 */                 return -1; 
/*  889 */               offset++;
/*      */             } else {
/*  891 */               int o1 = offset - 1;
/*  892 */               if (o1 >= con.limit || o1 < 0 || ch != target[o1])
/*  893 */                 return -1; 
/*  894 */               offset = o1;
/*      */             } 
/*      */           } 
/*  897 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 0:
/*  901 */           if (dx > 0) {
/*  902 */             if (offset >= con.limit)
/*  903 */               return -1; 
/*  904 */             int ch = target[offset];
/*  905 */             if (isSet(opts, 4)) {
/*  906 */               if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/*  907 */                 offset++; 
/*      */             } else {
/*  909 */               if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/*  910 */                 ch = REUtil.composeFromSurrogates(ch, target[++offset]); 
/*  911 */               if (isEOLChar(ch))
/*  912 */                 return -1; 
/*      */             } 
/*  914 */             offset++;
/*      */           } else {
/*  916 */             int o1 = offset - 1;
/*  917 */             if (o1 >= con.limit || o1 < 0)
/*  918 */               return -1; 
/*  919 */             int ch = target[o1];
/*  920 */             if (isSet(opts, 4)) {
/*  921 */               if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/*  922 */                 o1--; 
/*      */             } else {
/*  924 */               if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/*  925 */                 ch = REUtil.composeFromSurrogates(target[--o1], ch); 
/*  926 */               if (!isEOLChar(ch))
/*  927 */                 return -1; 
/*      */             } 
/*  929 */             offset = o1;
/*      */           } 
/*  931 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 3:
/*      */         case 4:
/*  936 */           if (dx > 0) {
/*  937 */             if (offset >= con.limit)
/*  938 */               return -1; 
/*  939 */             int ch = target[offset];
/*  940 */             if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/*  941 */               ch = REUtil.composeFromSurrogates(ch, target[++offset]); 
/*  942 */             RangeToken tok = op.getToken();
/*  943 */             if (isSet(opts, 2))
/*  944 */             { tok = tok.getCaseInsensitiveToken();
/*  945 */               if (!tok.match(ch)) {
/*  946 */                 if (ch >= 65536) return -1; 
/*      */                 char uch;
/*  948 */                 if (!tok.match(uch = Character.toUpperCase((char)ch)) && !tok.match(Character.toLowerCase(uch)))
/*      */                 {
/*  950 */                   return -1;
/*      */                 }
/*      */               }  }
/*  953 */             else if (!tok.match(ch)) { return -1; }
/*      */             
/*  955 */             offset++;
/*      */           } else {
/*  957 */             int o1 = offset - 1;
/*  958 */             if (o1 >= con.limit || o1 < 0)
/*  959 */               return -1; 
/*  960 */             int ch = target[o1];
/*  961 */             if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/*  962 */               ch = REUtil.composeFromSurrogates(target[--o1], ch); 
/*  963 */             RangeToken tok = op.getToken();
/*  964 */             if (isSet(opts, 2))
/*  965 */             { tok = tok.getCaseInsensitiveToken();
/*  966 */               if (!tok.match(ch)) {
/*  967 */                 if (ch >= 65536) return -1; 
/*      */                 char uch;
/*  969 */                 if (!tok.match(uch = Character.toUpperCase((char)ch)) && !tok.match(Character.toLowerCase(uch)))
/*      */                 {
/*  971 */                   return -1;
/*      */                 }
/*      */               }  }
/*  974 */             else if (!tok.match(ch)) { return -1; }
/*      */             
/*  976 */             offset = o1;
/*      */           } 
/*  978 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 5:
/*  982 */           go = false;
/*  983 */           switch (op.getData()) {
/*      */             case 94:
/*  985 */               if (isSet(opts, 8)) {
/*  986 */                 if (offset != con.start && (offset <= con.start || !isEOLChar(target[offset - 1])))
/*      */                 {
/*  988 */                   return -1; }  break;
/*      */               } 
/*  990 */               if (offset != con.start) {
/*  991 */                 return -1;
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             case 64:
/*  997 */               if (offset != con.start && (offset <= con.start || !isEOLChar(target[offset - 1])))
/*      */               {
/*  999 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 36:
/* 1003 */               if (isSet(opts, 8)) {
/* 1004 */                 if (offset != con.limit && (offset >= con.limit || !isEOLChar(target[offset])))
/*      */                 {
/* 1006 */                   return -1; }  break;
/*      */               } 
/* 1008 */               if (offset != con.limit && (offset + 1 != con.limit || !isEOLChar(target[offset])) && (offset + 2 != con.limit || target[offset] != '\r' || target[offset + 1] != '\n'))
/*      */               {
/*      */ 
/*      */                 
/* 1012 */                 return -1;
/*      */               }
/*      */               break;
/*      */             
/*      */             case 65:
/* 1017 */               if (offset != con.start) return -1;
/*      */               
/*      */               break;
/*      */             case 90:
/* 1021 */               if (offset != con.limit && (offset + 1 != con.limit || !isEOLChar(target[offset])) && (offset + 2 != con.limit || target[offset] != '\r' || target[offset + 1] != '\n'))
/*      */               {
/*      */ 
/*      */                 
/* 1025 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 122:
/* 1029 */               if (offset != con.limit) return -1;
/*      */               
/*      */               break;
/*      */             case 98:
/* 1033 */               if (con.length == 0) return -1;
/*      */               
/* 1035 */               after = getWordType(target, con.start, con.limit, offset, opts);
/* 1036 */               if (after == 0) return -1; 
/* 1037 */               before = getPreviousWordType(target, con.start, con.limit, offset, opts);
/* 1038 */               if (after == before) return -1;
/*      */               
/*      */               break;
/*      */             
/*      */             case 66:
/* 1043 */               if (con.length == 0) {
/* 1044 */                 go = true;
/*      */               } else {
/* 1046 */                 after = getWordType(target, con.start, con.limit, offset, opts);
/* 1047 */                 go = (after == 0 || after == getPreviousWordType(target, con.start, con.limit, offset, opts));
/*      */               } 
/*      */               
/* 1050 */               if (!go) return -1;
/*      */               
/*      */               break;
/*      */             case 60:
/* 1054 */               if (con.length == 0 || offset == con.limit) return -1; 
/* 1055 */               if (getWordType(target, con.start, con.limit, offset, opts) != 1 || getPreviousWordType(target, con.start, con.limit, offset, opts) != 2)
/*      */               {
/* 1057 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 62:
/* 1061 */               if (con.length == 0 || offset == con.start) return -1; 
/* 1062 */               if (getWordType(target, con.start, con.limit, offset, opts) != 2 || getPreviousWordType(target, con.start, con.limit, offset, opts) != 1)
/*      */               {
/* 1064 */                 return -1; } 
/*      */               break;
/*      */           } 
/* 1067 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 16:
/* 1072 */           j = op.getData();
/* 1073 */           if (j <= 0 || j >= this.nofparen)
/* 1074 */             throw new RuntimeException("Internal Error: Reference number must be more than zero: " + j); 
/* 1075 */           if (con.match.getBeginning(j) < 0 || con.match.getEnd(j) < 0)
/*      */           {
/* 1077 */             return -1; } 
/* 1078 */           o2 = con.match.getBeginning(j);
/* 1079 */           n = con.match.getEnd(j) - o2;
/* 1080 */           if (!isSet(opts, 2)) {
/* 1081 */             if (dx > 0) {
/* 1082 */               if (!regionMatches(target, offset, con.limit, o2, n))
/* 1083 */                 return -1; 
/* 1084 */               offset += n;
/*      */             } else {
/* 1086 */               if (!regionMatches(target, offset - n, con.limit, o2, n))
/* 1087 */                 return -1; 
/* 1088 */               offset -= n;
/*      */             }
/*      */           
/* 1091 */           } else if (dx > 0) {
/* 1092 */             if (!regionMatchesIgnoreCase(target, offset, con.limit, o2, n))
/* 1093 */               return -1; 
/* 1094 */             offset += n;
/*      */           } else {
/* 1096 */             if (!regionMatchesIgnoreCase(target, offset - n, con.limit, o2, n))
/*      */             {
/* 1098 */               return -1; } 
/* 1099 */             offset -= n;
/*      */           } 
/*      */ 
/*      */           
/* 1103 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 6:
/* 1107 */           literal = op.getString();
/* 1108 */           literallen = literal.length();
/* 1109 */           if (!isSet(opts, 2)) {
/* 1110 */             if (dx > 0) {
/* 1111 */               if (!regionMatches(target, offset, con.limit, literal, literallen))
/* 1112 */                 return -1; 
/* 1113 */               offset += literallen;
/*      */             } else {
/* 1115 */               if (!regionMatches(target, offset - literallen, con.limit, literal, literallen))
/* 1116 */                 return -1; 
/* 1117 */               offset -= literallen;
/*      */             }
/*      */           
/* 1120 */           } else if (dx > 0) {
/* 1121 */             if (!regionMatchesIgnoreCase(target, offset, con.limit, literal, literallen))
/* 1122 */               return -1; 
/* 1123 */             offset += literallen;
/*      */           } else {
/* 1125 */             if (!regionMatchesIgnoreCase(target, offset - literallen, con.limit, literal, literallen))
/*      */             {
/* 1127 */               return -1; } 
/* 1128 */             offset -= literallen;
/*      */           } 
/*      */ 
/*      */           
/* 1132 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/* 1141 */           id = op.getData();
/* 1142 */           if (id >= 0) {
/* 1143 */             int previousOffset = con.offsets[id];
/* 1144 */             if (previousOffset < 0 || previousOffset != offset) {
/* 1145 */               con.offsets[id] = offset;
/*      */             } else {
/* 1147 */               con.offsets[id] = -1;
/* 1148 */               op = op.next;
/*      */               
/*      */               continue;
/*      */             } 
/*      */           } 
/* 1153 */           k = matchCharArray(con, op.getChild(), offset, dx, opts);
/* 1154 */           if (id >= 0) con.offsets[id] = -1; 
/* 1155 */           if (k >= 0) return k; 
/* 1156 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 9:
/* 1162 */           ret = matchCharArray(con, op.getChild(), offset, dx, opts);
/* 1163 */           if (ret >= 0) return ret; 
/* 1164 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 10:
/* 1171 */           ret = matchCharArray(con, op.next, offset, dx, opts);
/* 1172 */           if (ret >= 0) return ret; 
/* 1173 */           op = op.getChild();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 11:
/* 1178 */           for (i = 0; i < op.size(); i++) {
/* 1179 */             k = matchCharArray(con, op.elementAt(i), offset, dx, opts);
/*      */ 
/*      */ 
/*      */             
/* 1183 */             if (k >= 0) return k; 
/*      */           } 
/* 1185 */           return -1;
/*      */         
/*      */         case 15:
/* 1188 */           refno = op.getData();
/* 1189 */           if (con.match != null && refno > 0) {
/* 1190 */             int save = con.match.getBeginning(refno);
/* 1191 */             con.match.setBeginning(refno, offset);
/* 1192 */             int i1 = matchCharArray(con, op.next, offset, dx, opts);
/* 1193 */             if (i1 < 0) con.match.setBeginning(refno, save); 
/* 1194 */             return i1;
/* 1195 */           }  if (con.match != null && refno < 0) {
/* 1196 */             int index = -refno;
/* 1197 */             int save = con.match.getEnd(index);
/* 1198 */             con.match.setEnd(index, offset);
/* 1199 */             int i1 = matchCharArray(con, op.next, offset, dx, opts);
/* 1200 */             if (i1 < 0) con.match.setEnd(index, save); 
/* 1201 */             return i1;
/*      */           } 
/* 1203 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 20:
/* 1207 */           if (0 > matchCharArray(con, op.getChild(), offset, 1, opts)) return -1; 
/* 1208 */           op = op.next;
/*      */           continue;
/*      */         case 21:
/* 1211 */           if (0 <= matchCharArray(con, op.getChild(), offset, 1, opts)) return -1; 
/* 1212 */           op = op.next;
/*      */           continue;
/*      */         case 22:
/* 1215 */           if (0 > matchCharArray(con, op.getChild(), offset, -1, opts)) return -1; 
/* 1216 */           op = op.next;
/*      */           continue;
/*      */         case 23:
/* 1219 */           if (0 <= matchCharArray(con, op.getChild(), offset, -1, opts)) return -1; 
/* 1220 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 24:
/* 1225 */           k = matchCharArray(con, op.getChild(), offset, dx, opts);
/* 1226 */           if (k < 0) return k; 
/* 1227 */           offset = k;
/* 1228 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 25:
/* 1234 */           localopts = opts;
/* 1235 */           localopts |= op.getData();
/* 1236 */           localopts &= op.getData2() ^ 0xFFFFFFFF;
/*      */           
/* 1238 */           m = matchCharArray(con, op.getChild(), offset, dx, localopts);
/* 1239 */           if (m < 0) return m; 
/* 1240 */           offset = m;
/* 1241 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 26:
/* 1247 */           cop = (Op.ConditionOp)op;
/* 1248 */           matchp = false;
/* 1249 */           if (cop.refNumber > 0) {
/* 1250 */             if (cop.refNumber >= this.nofparen)
/* 1251 */               throw new RuntimeException("Internal Error: Reference number must be more than zero: " + cop.refNumber); 
/* 1252 */             matchp = (con.match.getBeginning(cop.refNumber) >= 0 && con.match.getEnd(cop.refNumber) >= 0);
/*      */           } else {
/*      */             
/* 1255 */             matchp = (0 <= matchCharArray(con, cop.condition, offset, dx, opts));
/*      */           } 
/*      */           
/* 1258 */           if (matchp) {
/* 1259 */             op = cop.yes; continue;
/* 1260 */           }  if (cop.no != null) {
/* 1261 */             op = cop.no; continue;
/*      */           } 
/* 1263 */           op = cop.next;
/*      */           continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/* 1269 */     throw new RuntimeException("Unknown operation type: " + op.type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int getPreviousWordType(char[] target, int begin, int end, int offset, int opts) {
/* 1276 */     int ret = getWordType(target, begin, end, --offset, opts);
/* 1277 */     while (ret == 0)
/* 1278 */       ret = getWordType(target, begin, end, --offset, opts); 
/* 1279 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int getWordType(char[] target, int begin, int end, int offset, int opts) {
/* 1284 */     if (offset < begin || offset >= end) return 2; 
/* 1285 */     return getWordType0(target[offset], opts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean regionMatches(char[] target, int offset, int limit, String part, int partlen) {
/* 1292 */     if (offset < 0) return false; 
/* 1293 */     if (limit - offset < partlen)
/* 1294 */       return false; 
/* 1295 */     int i = 0;
/* 1296 */     while (partlen-- > 0) {
/* 1297 */       if (target[offset++] != part.charAt(i++))
/* 1298 */         return false; 
/*      */     } 
/* 1300 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatches(char[] target, int offset, int limit, int offset2, int partlen) {
/* 1305 */     if (offset < 0) return false; 
/* 1306 */     if (limit - offset < partlen)
/* 1307 */       return false; 
/* 1308 */     int i = offset2;
/* 1309 */     while (partlen-- > 0) {
/* 1310 */       if (target[offset++] != target[i++])
/* 1311 */         return false; 
/*      */     } 
/* 1313 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean regionMatchesIgnoreCase(char[] target, int offset, int limit, String part, int partlen) {
/* 1321 */     if (offset < 0) return false; 
/* 1322 */     if (limit - offset < partlen)
/* 1323 */       return false; 
/* 1324 */     int i = 0;
/* 1325 */     while (partlen-- > 0) {
/* 1326 */       char ch1 = target[offset++];
/* 1327 */       char ch2 = part.charAt(i++);
/* 1328 */       if (ch1 == ch2)
/*      */         continue; 
/* 1330 */       char uch1 = Character.toUpperCase(ch1);
/* 1331 */       char uch2 = Character.toUpperCase(ch2);
/* 1332 */       if (uch1 == uch2)
/*      */         continue; 
/* 1334 */       if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
/* 1335 */         return false; 
/*      */     } 
/* 1337 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatchesIgnoreCase(char[] target, int offset, int limit, int offset2, int partlen) {
/* 1342 */     if (offset < 0) return false; 
/* 1343 */     if (limit - offset < partlen)
/* 1344 */       return false; 
/* 1345 */     int i = offset2;
/* 1346 */     while (partlen-- > 0) {
/* 1347 */       char ch1 = target[offset++];
/* 1348 */       char ch2 = target[i++];
/* 1349 */       if (ch1 == ch2)
/*      */         continue; 
/* 1351 */       char uch1 = Character.toUpperCase(ch1);
/* 1352 */       char uch2 = Character.toUpperCase(ch2);
/* 1353 */       if (uch1 == uch2)
/*      */         continue; 
/* 1355 */       if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
/* 1356 */         return false; 
/*      */     } 
/* 1358 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target) {
/* 1370 */     return matches(target, 0, target.length(), (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target, int start, int end) {
/* 1382 */     return matches(target, start, end, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target, Match match) {
/* 1392 */     return matches(target, 0, target.length(), match);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target, int start, int end, Match match) {
/*      */     int matchStart;
/* 1406 */     synchronized (this) {
/* 1407 */       if (this.operations == null)
/* 1408 */         prepare(); 
/* 1409 */       if (this.context == null)
/* 1410 */         this.context = new Context(); 
/*      */     } 
/* 1412 */     Context con = null;
/* 1413 */     synchronized (this.context) {
/* 1414 */       con = this.context.inuse ? new Context() : this.context;
/* 1415 */       con.reset(target, start, end, this.numberOfClosures);
/*      */     } 
/* 1417 */     if (match != null) {
/* 1418 */       match.setNumberOfGroups(this.nofparen);
/* 1419 */       match.setSource(target);
/* 1420 */     } else if (this.hasBackReferences) {
/* 1421 */       match = new Match();
/* 1422 */       match.setNumberOfGroups(this.nofparen);
/*      */     } 
/*      */ 
/*      */     
/* 1426 */     con.match = match;
/*      */     
/* 1428 */     if (isSet(this.options, 512)) {
/*      */ 
/*      */ 
/*      */       
/* 1432 */       int i = matchString(con, this.operations, con.start, 1, this.options);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1437 */       if (i == con.limit) {
/* 1438 */         if (con.match != null) {
/* 1439 */           con.match.setBeginning(0, con.start);
/* 1440 */           con.match.setEnd(0, i);
/*      */         } 
/* 1442 */         con.inuse = false;
/* 1443 */         return true;
/*      */       } 
/* 1445 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1452 */     if (this.fixedStringOnly) {
/*      */       
/* 1454 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 1455 */       if (o >= 0) {
/* 1456 */         if (con.match != null) {
/* 1457 */           con.match.setBeginning(0, o);
/* 1458 */           con.match.setEnd(0, o + this.fixedString.length());
/*      */         } 
/* 1460 */         con.inuse = false;
/* 1461 */         return true;
/*      */       } 
/* 1463 */       con.inuse = false;
/* 1464 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1472 */     if (this.fixedString != null) {
/* 1473 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 1474 */       if (o < 0) {
/*      */         
/* 1476 */         con.inuse = false;
/* 1477 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1481 */     int limit = con.limit - this.minlength;
/*      */     
/* 1483 */     int matchEnd = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1488 */     if (this.operations != null && this.operations.type == 7 && (this.operations.getChild()).type == 0) {
/*      */       
/* 1490 */       if (isSet(this.options, 4)) {
/* 1491 */         matchStart = con.start;
/* 1492 */         matchEnd = matchString(con, this.operations, con.start, 1, this.options);
/*      */       } else {
/* 1494 */         boolean previousIsEOL = true;
/* 1495 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1496 */           int ch = target.charAt(matchStart);
/* 1497 */           if (isEOLChar(ch)) {
/* 1498 */             previousIsEOL = true;
/*      */           } else {
/* 1500 */             if (previousIsEOL && 
/* 1501 */               0 <= (matchEnd = matchString(con, this.operations, matchStart, 1, this.options))) {
/*      */               break;
/*      */             }
/*      */             
/* 1505 */             previousIsEOL = false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1514 */     else if (this.firstChar != null) {
/*      */       
/* 1516 */       RangeToken range = this.firstChar;
/* 1517 */       if (isSet(this.options, 2)) {
/* 1518 */         range = this.firstChar.getCaseInsensitiveToken();
/* 1519 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1520 */           int ch = target.charAt(matchStart);
/* 1521 */           if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit) {
/* 1522 */             ch = REUtil.composeFromSurrogates(ch, target.charAt(matchStart + 1));
/* 1523 */             if (!range.match(ch))
/*      */               continue; 
/* 1525 */           } else if (!range.match(ch)) {
/* 1526 */             char ch1 = Character.toUpperCase((char)ch);
/* 1527 */             if (!range.match(ch1) && 
/* 1528 */               !range.match(Character.toLowerCase(ch1))) {
/*      */               continue;
/*      */             }
/*      */           } 
/* 1532 */           if (0 <= (matchEnd = matchString(con, this.operations, matchStart, 1, this.options)))
/*      */             break; 
/*      */           continue;
/*      */         } 
/*      */       } else {
/* 1537 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1538 */           int ch = target.charAt(matchStart);
/* 1539 */           if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit)
/* 1540 */             ch = REUtil.composeFromSurrogates(ch, target.charAt(matchStart + 1)); 
/* 1541 */           if (range.match(ch) && 
/* 1542 */             0 <= (matchEnd = matchString(con, this.operations, matchStart, 1, this.options)))
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1553 */       for (matchStart = con.start; matchStart <= limit && 
/* 1554 */         0 > (matchEnd = matchString(con, this.operations, matchStart, 1, this.options)); matchStart++);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1559 */     if (matchEnd >= 0) {
/* 1560 */       if (con.match != null) {
/* 1561 */         con.match.setBeginning(0, matchStart);
/* 1562 */         con.match.setEnd(0, matchEnd);
/*      */       } 
/* 1564 */       con.inuse = false;
/* 1565 */       return true;
/*      */     } 
/* 1567 */     con.inuse = false;
/* 1568 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int matchString(Context con, Op op, int offset, int dx, int opts) {
/* 1580 */     String target = con.strTarget; while (true) {
/*      */       boolean go; int after; int j; String literal; int id; int ret; int i; int refno; int before; int o2; int literallen; int k; int localopts;
/*      */       Op.ConditionOp cop;
/*      */       int n;
/*      */       int m;
/*      */       boolean matchp;
/* 1586 */       if (op == null)
/* 1587 */         return (isSet(opts, 512) && offset != con.limit) ? -1 : offset; 
/* 1588 */       if (offset > con.limit || offset < con.start)
/* 1589 */         return -1; 
/* 1590 */       switch (op.type) {
/*      */         case 1:
/* 1592 */           if (isSet(opts, 2)) {
/* 1593 */             int ch = op.getData();
/* 1594 */             if (dx > 0) {
/* 1595 */               if (offset >= con.limit || !matchIgnoreCase(ch, target.charAt(offset)))
/* 1596 */                 return -1; 
/* 1597 */               offset++;
/*      */             } else {
/* 1599 */               int o1 = offset - 1;
/* 1600 */               if (o1 >= con.limit || o1 < 0 || !matchIgnoreCase(ch, target.charAt(o1)))
/* 1601 */                 return -1; 
/* 1602 */               offset = o1;
/*      */             } 
/*      */           } else {
/* 1605 */             int ch = op.getData();
/* 1606 */             if (dx > 0) {
/* 1607 */               if (offset >= con.limit || ch != target.charAt(offset))
/* 1608 */                 return -1; 
/* 1609 */               offset++;
/*      */             } else {
/* 1611 */               int o1 = offset - 1;
/* 1612 */               if (o1 >= con.limit || o1 < 0 || ch != target.charAt(o1))
/* 1613 */                 return -1; 
/* 1614 */               offset = o1;
/*      */             } 
/*      */           } 
/* 1617 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 0:
/* 1621 */           if (dx > 0) {
/* 1622 */             if (offset >= con.limit)
/* 1623 */               return -1; 
/* 1624 */             int ch = target.charAt(offset);
/* 1625 */             if (isSet(opts, 4)) {
/* 1626 */               if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/* 1627 */                 offset++; 
/*      */             } else {
/* 1629 */               if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/* 1630 */                 ch = REUtil.composeFromSurrogates(ch, target.charAt(++offset)); 
/* 1631 */               if (isEOLChar(ch))
/* 1632 */                 return -1; 
/*      */             } 
/* 1634 */             offset++;
/*      */           } else {
/* 1636 */             int o1 = offset - 1;
/* 1637 */             if (o1 >= con.limit || o1 < 0)
/* 1638 */               return -1; 
/* 1639 */             int ch = target.charAt(o1);
/* 1640 */             if (isSet(opts, 4)) {
/* 1641 */               if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/* 1642 */                 o1--; 
/*      */             } else {
/* 1644 */               if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/* 1645 */                 ch = REUtil.composeFromSurrogates(target.charAt(--o1), ch); 
/* 1646 */               if (!isEOLChar(ch))
/* 1647 */                 return -1; 
/*      */             } 
/* 1649 */             offset = o1;
/*      */           } 
/* 1651 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 3:
/*      */         case 4:
/* 1656 */           if (dx > 0) {
/* 1657 */             if (offset >= con.limit)
/* 1658 */               return -1; 
/* 1659 */             int ch = target.charAt(offset);
/* 1660 */             if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/* 1661 */               ch = REUtil.composeFromSurrogates(ch, target.charAt(++offset)); 
/* 1662 */             RangeToken tok = op.getToken();
/* 1663 */             if (isSet(opts, 2))
/* 1664 */             { tok = tok.getCaseInsensitiveToken();
/* 1665 */               if (!tok.match(ch)) {
/* 1666 */                 if (ch >= 65536) return -1; 
/*      */                 char uch;
/* 1668 */                 if (!tok.match(uch = Character.toUpperCase((char)ch)) && !tok.match(Character.toLowerCase(uch)))
/*      */                 {
/* 1670 */                   return -1;
/*      */                 }
/*      */               }  }
/* 1673 */             else if (!tok.match(ch)) { return -1; }
/*      */             
/* 1675 */             offset++;
/*      */           } else {
/* 1677 */             int o1 = offset - 1;
/* 1678 */             if (o1 >= con.limit || o1 < 0)
/* 1679 */               return -1; 
/* 1680 */             int ch = target.charAt(o1);
/* 1681 */             if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/* 1682 */               ch = REUtil.composeFromSurrogates(target.charAt(--o1), ch); 
/* 1683 */             RangeToken tok = op.getToken();
/* 1684 */             if (isSet(opts, 2))
/* 1685 */             { tok = tok.getCaseInsensitiveToken();
/* 1686 */               if (!tok.match(ch)) {
/* 1687 */                 if (ch >= 65536) return -1; 
/*      */                 char uch;
/* 1689 */                 if (!tok.match(uch = Character.toUpperCase((char)ch)) && !tok.match(Character.toLowerCase(uch)))
/*      */                 {
/* 1691 */                   return -1;
/*      */                 }
/*      */               }  }
/* 1694 */             else if (!tok.match(ch)) { return -1; }
/*      */             
/* 1696 */             offset = o1;
/*      */           } 
/* 1698 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 5:
/* 1702 */           go = false;
/* 1703 */           switch (op.getData()) {
/*      */             case 94:
/* 1705 */               if (isSet(opts, 8)) {
/* 1706 */                 if (offset != con.start && (offset <= con.start || !isEOLChar(target.charAt(offset - 1))))
/*      */                 {
/* 1708 */                   return -1; }  break;
/*      */               } 
/* 1710 */               if (offset != con.start) {
/* 1711 */                 return -1;
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             case 64:
/* 1717 */               if (offset != con.start && (offset <= con.start || !isEOLChar(target.charAt(offset - 1))))
/*      */               {
/* 1719 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 36:
/* 1723 */               if (isSet(opts, 8)) {
/* 1724 */                 if (offset != con.limit && (offset >= con.limit || !isEOLChar(target.charAt(offset))))
/*      */                 {
/* 1726 */                   return -1; }  break;
/*      */               } 
/* 1728 */               if (offset != con.limit && (offset + 1 != con.limit || !isEOLChar(target.charAt(offset))) && (offset + 2 != con.limit || target.charAt(offset) != '\r' || target.charAt(offset + 1) != '\n'))
/*      */               {
/*      */ 
/*      */                 
/* 1732 */                 return -1;
/*      */               }
/*      */               break;
/*      */             
/*      */             case 65:
/* 1737 */               if (offset != con.start) return -1;
/*      */               
/*      */               break;
/*      */             case 90:
/* 1741 */               if (offset != con.limit && (offset + 1 != con.limit || !isEOLChar(target.charAt(offset))) && (offset + 2 != con.limit || target.charAt(offset) != '\r' || target.charAt(offset + 1) != '\n'))
/*      */               {
/*      */ 
/*      */                 
/* 1745 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 122:
/* 1749 */               if (offset != con.limit) return -1;
/*      */               
/*      */               break;
/*      */             case 98:
/* 1753 */               if (con.length == 0) return -1;
/*      */               
/* 1755 */               after = getWordType(target, con.start, con.limit, offset, opts);
/* 1756 */               if (after == 0) return -1; 
/* 1757 */               before = getPreviousWordType(target, con.start, con.limit, offset, opts);
/* 1758 */               if (after == before) return -1;
/*      */               
/*      */               break;
/*      */             
/*      */             case 66:
/* 1763 */               if (con.length == 0) {
/* 1764 */                 go = true;
/*      */               } else {
/* 1766 */                 after = getWordType(target, con.start, con.limit, offset, opts);
/* 1767 */                 go = (after == 0 || after == getPreviousWordType(target, con.start, con.limit, offset, opts));
/*      */               } 
/*      */               
/* 1770 */               if (!go) return -1;
/*      */               
/*      */               break;
/*      */             case 60:
/* 1774 */               if (con.length == 0 || offset == con.limit) return -1; 
/* 1775 */               if (getWordType(target, con.start, con.limit, offset, opts) != 1 || getPreviousWordType(target, con.start, con.limit, offset, opts) != 2)
/*      */               {
/* 1777 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 62:
/* 1781 */               if (con.length == 0 || offset == con.start) return -1; 
/* 1782 */               if (getWordType(target, con.start, con.limit, offset, opts) != 2 || getPreviousWordType(target, con.start, con.limit, offset, opts) != 1)
/*      */               {
/* 1784 */                 return -1; } 
/*      */               break;
/*      */           } 
/* 1787 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 16:
/* 1792 */           j = op.getData();
/* 1793 */           if (j <= 0 || j >= this.nofparen)
/* 1794 */             throw new RuntimeException("Internal Error: Reference number must be more than zero: " + j); 
/* 1795 */           if (con.match.getBeginning(j) < 0 || con.match.getEnd(j) < 0)
/*      */           {
/* 1797 */             return -1; } 
/* 1798 */           o2 = con.match.getBeginning(j);
/* 1799 */           n = con.match.getEnd(j) - o2;
/* 1800 */           if (!isSet(opts, 2)) {
/* 1801 */             if (dx > 0) {
/* 1802 */               if (!regionMatches(target, offset, con.limit, o2, n))
/* 1803 */                 return -1; 
/* 1804 */               offset += n;
/*      */             } else {
/* 1806 */               if (!regionMatches(target, offset - n, con.limit, o2, n))
/* 1807 */                 return -1; 
/* 1808 */               offset -= n;
/*      */             }
/*      */           
/* 1811 */           } else if (dx > 0) {
/* 1812 */             if (!regionMatchesIgnoreCase(target, offset, con.limit, o2, n))
/* 1813 */               return -1; 
/* 1814 */             offset += n;
/*      */           } else {
/* 1816 */             if (!regionMatchesIgnoreCase(target, offset - n, con.limit, o2, n))
/*      */             {
/* 1818 */               return -1; } 
/* 1819 */             offset -= n;
/*      */           } 
/*      */ 
/*      */           
/* 1823 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 6:
/* 1827 */           literal = op.getString();
/* 1828 */           literallen = literal.length();
/* 1829 */           if (!isSet(opts, 2)) {
/* 1830 */             if (dx > 0) {
/* 1831 */               if (!regionMatches(target, offset, con.limit, literal, literallen))
/* 1832 */                 return -1; 
/* 1833 */               offset += literallen;
/*      */             } else {
/* 1835 */               if (!regionMatches(target, offset - literallen, con.limit, literal, literallen))
/* 1836 */                 return -1; 
/* 1837 */               offset -= literallen;
/*      */             }
/*      */           
/* 1840 */           } else if (dx > 0) {
/* 1841 */             if (!regionMatchesIgnoreCase(target, offset, con.limit, literal, literallen))
/* 1842 */               return -1; 
/* 1843 */             offset += literallen;
/*      */           } else {
/* 1845 */             if (!regionMatchesIgnoreCase(target, offset - literallen, con.limit, literal, literallen))
/*      */             {
/* 1847 */               return -1; } 
/* 1848 */             offset -= literallen;
/*      */           } 
/*      */ 
/*      */           
/* 1852 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/* 1861 */           id = op.getData();
/* 1862 */           if (id >= 0) {
/* 1863 */             int previousOffset = con.offsets[id];
/* 1864 */             if (previousOffset < 0 || previousOffset != offset) {
/* 1865 */               con.offsets[id] = offset;
/*      */             } else {
/* 1867 */               con.offsets[id] = -1;
/* 1868 */               op = op.next;
/*      */               continue;
/*      */             } 
/*      */           } 
/* 1872 */           k = matchString(con, op.getChild(), offset, dx, opts);
/* 1873 */           if (id >= 0) con.offsets[id] = -1; 
/* 1874 */           if (k >= 0) return k; 
/* 1875 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 9:
/* 1881 */           ret = matchString(con, op.getChild(), offset, dx, opts);
/* 1882 */           if (ret >= 0) return ret; 
/* 1883 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 10:
/* 1890 */           ret = matchString(con, op.next, offset, dx, opts);
/* 1891 */           if (ret >= 0) return ret; 
/* 1892 */           op = op.getChild();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 11:
/* 1897 */           for (i = 0; i < op.size(); i++) {
/* 1898 */             k = matchString(con, op.elementAt(i), offset, dx, opts);
/*      */ 
/*      */ 
/*      */             
/* 1902 */             if (k >= 0) return k; 
/*      */           } 
/* 1904 */           return -1;
/*      */         
/*      */         case 15:
/* 1907 */           refno = op.getData();
/* 1908 */           if (con.match != null && refno > 0) {
/* 1909 */             int save = con.match.getBeginning(refno);
/* 1910 */             con.match.setBeginning(refno, offset);
/* 1911 */             int i1 = matchString(con, op.next, offset, dx, opts);
/* 1912 */             if (i1 < 0) con.match.setBeginning(refno, save); 
/* 1913 */             return i1;
/* 1914 */           }  if (con.match != null && refno < 0) {
/* 1915 */             int index = -refno;
/* 1916 */             int save = con.match.getEnd(index);
/* 1917 */             con.match.setEnd(index, offset);
/* 1918 */             int i1 = matchString(con, op.next, offset, dx, opts);
/* 1919 */             if (i1 < 0) con.match.setEnd(index, save); 
/* 1920 */             return i1;
/*      */           } 
/* 1922 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 20:
/* 1926 */           if (0 > matchString(con, op.getChild(), offset, 1, opts)) return -1; 
/* 1927 */           op = op.next;
/*      */           continue;
/*      */         case 21:
/* 1930 */           if (0 <= matchString(con, op.getChild(), offset, 1, opts)) return -1; 
/* 1931 */           op = op.next;
/*      */           continue;
/*      */         case 22:
/* 1934 */           if (0 > matchString(con, op.getChild(), offset, -1, opts)) return -1; 
/* 1935 */           op = op.next;
/*      */           continue;
/*      */         case 23:
/* 1938 */           if (0 <= matchString(con, op.getChild(), offset, -1, opts)) return -1; 
/* 1939 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 24:
/* 1944 */           k = matchString(con, op.getChild(), offset, dx, opts);
/* 1945 */           if (k < 0) return k; 
/* 1946 */           offset = k;
/* 1947 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 25:
/* 1953 */           localopts = opts;
/* 1954 */           localopts |= op.getData();
/* 1955 */           localopts &= op.getData2() ^ 0xFFFFFFFF;
/*      */           
/* 1957 */           m = matchString(con, op.getChild(), offset, dx, localopts);
/* 1958 */           if (m < 0) return m; 
/* 1959 */           offset = m;
/* 1960 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 26:
/* 1966 */           cop = (Op.ConditionOp)op;
/* 1967 */           matchp = false;
/* 1968 */           if (cop.refNumber > 0) {
/* 1969 */             if (cop.refNumber >= this.nofparen)
/* 1970 */               throw new RuntimeException("Internal Error: Reference number must be more than zero: " + cop.refNumber); 
/* 1971 */             matchp = (con.match.getBeginning(cop.refNumber) >= 0 && con.match.getEnd(cop.refNumber) >= 0);
/*      */           } else {
/*      */             
/* 1974 */             matchp = (0 <= matchString(con, cop.condition, offset, dx, opts));
/*      */           } 
/*      */           
/* 1977 */           if (matchp) {
/* 1978 */             op = cop.yes; continue;
/* 1979 */           }  if (cop.no != null) {
/* 1980 */             op = cop.no; continue;
/*      */           } 
/* 1982 */           op = cop.next;
/*      */           continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/* 1988 */     throw new RuntimeException("Unknown operation type: " + op.type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int getPreviousWordType(String target, int begin, int end, int offset, int opts) {
/* 1995 */     int ret = getWordType(target, begin, end, --offset, opts);
/* 1996 */     while (ret == 0)
/* 1997 */       ret = getWordType(target, begin, end, --offset, opts); 
/* 1998 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int getWordType(String target, int begin, int end, int offset, int opts) {
/* 2003 */     if (offset < begin || offset >= end) return 2; 
/* 2004 */     return getWordType0(target.charAt(offset), opts);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean regionMatches(String text, int offset, int limit, String part, int partlen) {
/* 2010 */     if (limit - offset < partlen) return false; 
/* 2011 */     return text.regionMatches(offset, part, 0, partlen);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatches(String text, int offset, int limit, int offset2, int partlen) {
/* 2016 */     if (limit - offset < partlen) return false; 
/* 2017 */     return text.regionMatches(offset, text, offset2, partlen);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatchesIgnoreCase(String text, int offset, int limit, String part, int partlen) {
/* 2022 */     return text.regionMatches(true, offset, part, 0, partlen);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatchesIgnoreCase(String text, int offset, int limit, int offset2, int partlen) {
/* 2027 */     if (limit - offset < partlen) return false; 
/* 2028 */     return text.regionMatches(true, offset, text, offset2, partlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(CharacterIterator target) {
/* 2043 */     return matches(target, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(CharacterIterator target, Match match) {
/* 2054 */     int matchStart, start = target.getBeginIndex();
/* 2055 */     int end = target.getEndIndex();
/*      */ 
/*      */ 
/*      */     
/* 2059 */     synchronized (this) {
/* 2060 */       if (this.operations == null)
/* 2061 */         prepare(); 
/* 2062 */       if (this.context == null)
/* 2063 */         this.context = new Context(); 
/*      */     } 
/* 2065 */     Context con = null;
/* 2066 */     synchronized (this.context) {
/* 2067 */       con = this.context.inuse ? new Context() : this.context;
/* 2068 */       con.reset(target, start, end, this.numberOfClosures);
/*      */     } 
/* 2070 */     if (match != null) {
/* 2071 */       match.setNumberOfGroups(this.nofparen);
/* 2072 */       match.setSource(target);
/* 2073 */     } else if (this.hasBackReferences) {
/* 2074 */       match = new Match();
/* 2075 */       match.setNumberOfGroups(this.nofparen);
/*      */     } 
/*      */ 
/*      */     
/* 2079 */     con.match = match;
/*      */     
/* 2081 */     if (isSet(this.options, 512)) {
/* 2082 */       int i = matchCharacterIterator(con, this.operations, con.start, 1, this.options);
/*      */       
/* 2084 */       if (i == con.limit) {
/* 2085 */         if (con.match != null) {
/* 2086 */           con.match.setBeginning(0, con.start);
/* 2087 */           con.match.setEnd(0, i);
/*      */         } 
/* 2089 */         con.inuse = false;
/* 2090 */         return true;
/*      */       } 
/* 2092 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2099 */     if (this.fixedStringOnly) {
/*      */       
/* 2101 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 2102 */       if (o >= 0) {
/* 2103 */         if (con.match != null) {
/* 2104 */           con.match.setBeginning(0, o);
/* 2105 */           con.match.setEnd(0, o + this.fixedString.length());
/*      */         } 
/* 2107 */         con.inuse = false;
/* 2108 */         return true;
/*      */       } 
/* 2110 */       con.inuse = false;
/* 2111 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2119 */     if (this.fixedString != null) {
/* 2120 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 2121 */       if (o < 0) {
/*      */         
/* 2123 */         con.inuse = false;
/* 2124 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 2128 */     int limit = con.limit - this.minlength;
/*      */     
/* 2130 */     int matchEnd = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2135 */     if (this.operations != null && this.operations.type == 7 && (this.operations.getChild()).type == 0) {
/*      */       
/* 2137 */       if (isSet(this.options, 4)) {
/* 2138 */         matchStart = con.start;
/* 2139 */         matchEnd = matchCharacterIterator(con, this.operations, con.start, 1, this.options);
/*      */       } else {
/* 2141 */         boolean previousIsEOL = true;
/* 2142 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 2143 */           int ch = target.setIndex(matchStart);
/* 2144 */           if (isEOLChar(ch)) {
/* 2145 */             previousIsEOL = true;
/*      */           } else {
/* 2147 */             if (previousIsEOL && 
/* 2148 */               0 <= (matchEnd = matchCharacterIterator(con, this.operations, matchStart, 1, this.options))) {
/*      */               break;
/*      */             }
/*      */             
/* 2152 */             previousIsEOL = false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 2161 */     else if (this.firstChar != null) {
/*      */       
/* 2163 */       RangeToken range = this.firstChar;
/* 2164 */       if (isSet(this.options, 2)) {
/* 2165 */         range = this.firstChar.getCaseInsensitiveToken();
/* 2166 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 2167 */           int ch = target.setIndex(matchStart);
/* 2168 */           if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit) {
/* 2169 */             ch = REUtil.composeFromSurrogates(ch, target.setIndex(matchStart + 1));
/* 2170 */             if (!range.match(ch))
/*      */               continue; 
/* 2172 */           } else if (!range.match(ch)) {
/* 2173 */             char ch1 = Character.toUpperCase((char)ch);
/* 2174 */             if (!range.match(ch1) && 
/* 2175 */               !range.match(Character.toLowerCase(ch1))) {
/*      */               continue;
/*      */             }
/*      */           } 
/* 2179 */           if (0 <= (matchEnd = matchCharacterIterator(con, this.operations, matchStart, 1, this.options)))
/*      */             break; 
/*      */           continue;
/*      */         } 
/*      */       } else {
/* 2184 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 2185 */           int ch = target.setIndex(matchStart);
/* 2186 */           if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit)
/* 2187 */             ch = REUtil.composeFromSurrogates(ch, target.setIndex(matchStart + 1)); 
/* 2188 */           if (range.match(ch) && 
/* 2189 */             0 <= (matchEnd = matchCharacterIterator(con, this.operations, matchStart, 1, this.options)))
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2200 */       for (matchStart = con.start; matchStart <= limit && 
/* 2201 */         0 > (matchEnd = matchCharacterIterator(con, this.operations, matchStart, 1, this.options)); matchStart++);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2206 */     if (matchEnd >= 0) {
/* 2207 */       if (con.match != null) {
/* 2208 */         con.match.setBeginning(0, matchStart);
/* 2209 */         con.match.setEnd(0, matchEnd);
/*      */       } 
/* 2211 */       con.inuse = false;
/* 2212 */       return true;
/*      */     } 
/* 2214 */     con.inuse = false;
/* 2215 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int matchCharacterIterator(Context con, Op op, int offset, int dx, int opts) {
/* 2225 */     CharacterIterator target = con.ciTarget; while (true) {
/*      */       boolean go; int after; int j; String literal; int id; int ret; int i; int refno; int before; int o2; int literallen;
/*      */       int k;
/*      */       int localopts;
/*      */       Op.ConditionOp cop;
/*      */       int n;
/*      */       int m;
/*      */       boolean matchp;
/* 2233 */       if (op == null)
/* 2234 */         return (isSet(opts, 512) && offset != con.limit) ? -1 : offset; 
/* 2235 */       if (offset > con.limit || offset < con.start)
/* 2236 */         return -1; 
/* 2237 */       switch (op.type) {
/*      */         case 1:
/* 2239 */           if (isSet(opts, 2)) {
/* 2240 */             int ch = op.getData();
/* 2241 */             if (dx > 0) {
/* 2242 */               if (offset >= con.limit || !matchIgnoreCase(ch, target.setIndex(offset)))
/* 2243 */                 return -1; 
/* 2244 */               offset++;
/*      */             } else {
/* 2246 */               int o1 = offset - 1;
/* 2247 */               if (o1 >= con.limit || o1 < 0 || !matchIgnoreCase(ch, target.setIndex(o1)))
/* 2248 */                 return -1; 
/* 2249 */               offset = o1;
/*      */             } 
/*      */           } else {
/* 2252 */             int ch = op.getData();
/* 2253 */             if (dx > 0) {
/* 2254 */               if (offset >= con.limit || ch != target.setIndex(offset))
/* 2255 */                 return -1; 
/* 2256 */               offset++;
/*      */             } else {
/* 2258 */               int o1 = offset - 1;
/* 2259 */               if (o1 >= con.limit || o1 < 0 || ch != target.setIndex(o1))
/* 2260 */                 return -1; 
/* 2261 */               offset = o1;
/*      */             } 
/*      */           } 
/* 2264 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 0:
/* 2268 */           if (dx > 0) {
/* 2269 */             if (offset >= con.limit)
/* 2270 */               return -1; 
/* 2271 */             int ch = target.setIndex(offset);
/* 2272 */             if (isSet(opts, 4)) {
/* 2273 */               if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/* 2274 */                 offset++; 
/*      */             } else {
/* 2276 */               if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/* 2277 */                 ch = REUtil.composeFromSurrogates(ch, target.setIndex(++offset)); 
/* 2278 */               if (isEOLChar(ch))
/* 2279 */                 return -1; 
/*      */             } 
/* 2281 */             offset++;
/*      */           } else {
/* 2283 */             int o1 = offset - 1;
/* 2284 */             if (o1 >= con.limit || o1 < 0)
/* 2285 */               return -1; 
/* 2286 */             int ch = target.setIndex(o1);
/* 2287 */             if (isSet(opts, 4)) {
/* 2288 */               if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/* 2289 */                 o1--; 
/*      */             } else {
/* 2291 */               if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/* 2292 */                 ch = REUtil.composeFromSurrogates(target.setIndex(--o1), ch); 
/* 2293 */               if (!isEOLChar(ch))
/* 2294 */                 return -1; 
/*      */             } 
/* 2296 */             offset = o1;
/*      */           } 
/* 2298 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 3:
/*      */         case 4:
/* 2303 */           if (dx > 0) {
/* 2304 */             if (offset >= con.limit)
/* 2305 */               return -1; 
/* 2306 */             int ch = target.setIndex(offset);
/* 2307 */             if (REUtil.isHighSurrogate(ch) && offset + 1 < con.limit)
/* 2308 */               ch = REUtil.composeFromSurrogates(ch, target.setIndex(++offset)); 
/* 2309 */             RangeToken tok = op.getToken();
/* 2310 */             if (isSet(opts, 2))
/* 2311 */             { tok = tok.getCaseInsensitiveToken();
/* 2312 */               if (!tok.match(ch)) {
/* 2313 */                 if (ch >= 65536) return -1; 
/*      */                 char uch;
/* 2315 */                 if (!tok.match(uch = Character.toUpperCase((char)ch)) && !tok.match(Character.toLowerCase(uch)))
/*      */                 {
/* 2317 */                   return -1;
/*      */                 }
/*      */               }  }
/* 2320 */             else if (!tok.match(ch)) { return -1; }
/*      */             
/* 2322 */             offset++;
/*      */           } else {
/* 2324 */             int o1 = offset - 1;
/* 2325 */             if (o1 >= con.limit || o1 < 0)
/* 2326 */               return -1; 
/* 2327 */             int ch = target.setIndex(o1);
/* 2328 */             if (REUtil.isLowSurrogate(ch) && o1 - 1 >= 0)
/* 2329 */               ch = REUtil.composeFromSurrogates(target.setIndex(--o1), ch); 
/* 2330 */             RangeToken tok = op.getToken();
/* 2331 */             if (isSet(opts, 2))
/* 2332 */             { tok = tok.getCaseInsensitiveToken();
/* 2333 */               if (!tok.match(ch)) {
/* 2334 */                 if (ch >= 65536) return -1; 
/*      */                 char uch;
/* 2336 */                 if (!tok.match(uch = Character.toUpperCase((char)ch)) && !tok.match(Character.toLowerCase(uch)))
/*      */                 {
/* 2338 */                   return -1;
/*      */                 }
/*      */               }  }
/* 2341 */             else if (!tok.match(ch)) { return -1; }
/*      */             
/* 2343 */             offset = o1;
/*      */           } 
/* 2345 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 5:
/* 2349 */           go = false;
/* 2350 */           switch (op.getData()) {
/*      */             case 94:
/* 2352 */               if (isSet(opts, 8)) {
/* 2353 */                 if (offset != con.start && (offset <= con.start || !isEOLChar(target.setIndex(offset - 1))))
/*      */                 {
/* 2355 */                   return -1; }  break;
/*      */               } 
/* 2357 */               if (offset != con.start) {
/* 2358 */                 return -1;
/*      */               }
/*      */               break;
/*      */ 
/*      */             
/*      */             case 64:
/* 2364 */               if (offset != con.start && (offset <= con.start || !isEOLChar(target.setIndex(offset - 1))))
/*      */               {
/* 2366 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 36:
/* 2370 */               if (isSet(opts, 8)) {
/* 2371 */                 if (offset != con.limit && (offset >= con.limit || !isEOLChar(target.setIndex(offset))))
/*      */                 {
/* 2373 */                   return -1; }  break;
/*      */               } 
/* 2375 */               if (offset != con.limit && (offset + 1 != con.limit || !isEOLChar(target.setIndex(offset))) && (offset + 2 != con.limit || target.setIndex(offset) != '\r' || target.setIndex(offset + 1) != '\n'))
/*      */               {
/*      */ 
/*      */                 
/* 2379 */                 return -1;
/*      */               }
/*      */               break;
/*      */             
/*      */             case 65:
/* 2384 */               if (offset != con.start) return -1;
/*      */               
/*      */               break;
/*      */             case 90:
/* 2388 */               if (offset != con.limit && (offset + 1 != con.limit || !isEOLChar(target.setIndex(offset))) && (offset + 2 != con.limit || target.setIndex(offset) != '\r' || target.setIndex(offset + 1) != '\n'))
/*      */               {
/*      */ 
/*      */                 
/* 2392 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 122:
/* 2396 */               if (offset != con.limit) return -1;
/*      */               
/*      */               break;
/*      */             case 98:
/* 2400 */               if (con.length == 0) return -1;
/*      */               
/* 2402 */               after = getWordType(target, con.start, con.limit, offset, opts);
/* 2403 */               if (after == 0) return -1; 
/* 2404 */               before = getPreviousWordType(target, con.start, con.limit, offset, opts);
/* 2405 */               if (after == before) return -1;
/*      */               
/*      */               break;
/*      */             
/*      */             case 66:
/* 2410 */               if (con.length == 0) {
/* 2411 */                 go = true;
/*      */               } else {
/* 2413 */                 after = getWordType(target, con.start, con.limit, offset, opts);
/* 2414 */                 go = (after == 0 || after == getPreviousWordType(target, con.start, con.limit, offset, opts));
/*      */               } 
/*      */               
/* 2417 */               if (!go) return -1;
/*      */               
/*      */               break;
/*      */             case 60:
/* 2421 */               if (con.length == 0 || offset == con.limit) return -1; 
/* 2422 */               if (getWordType(target, con.start, con.limit, offset, opts) != 1 || getPreviousWordType(target, con.start, con.limit, offset, opts) != 2)
/*      */               {
/* 2424 */                 return -1;
/*      */               }
/*      */               break;
/*      */             case 62:
/* 2428 */               if (con.length == 0 || offset == con.start) return -1; 
/* 2429 */               if (getWordType(target, con.start, con.limit, offset, opts) != 2 || getPreviousWordType(target, con.start, con.limit, offset, opts) != 1)
/*      */               {
/* 2431 */                 return -1; } 
/*      */               break;
/*      */           } 
/* 2434 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 16:
/* 2439 */           j = op.getData();
/* 2440 */           if (j <= 0 || j >= this.nofparen)
/* 2441 */             throw new RuntimeException("Internal Error: Reference number must be more than zero: " + j); 
/* 2442 */           if (con.match.getBeginning(j) < 0 || con.match.getEnd(j) < 0)
/*      */           {
/* 2444 */             return -1; } 
/* 2445 */           o2 = con.match.getBeginning(j);
/* 2446 */           n = con.match.getEnd(j) - o2;
/* 2447 */           if (!isSet(opts, 2)) {
/* 2448 */             if (dx > 0) {
/* 2449 */               if (!regionMatches(target, offset, con.limit, o2, n))
/* 2450 */                 return -1; 
/* 2451 */               offset += n;
/*      */             } else {
/* 2453 */               if (!regionMatches(target, offset - n, con.limit, o2, n))
/* 2454 */                 return -1; 
/* 2455 */               offset -= n;
/*      */             }
/*      */           
/* 2458 */           } else if (dx > 0) {
/* 2459 */             if (!regionMatchesIgnoreCase(target, offset, con.limit, o2, n))
/* 2460 */               return -1; 
/* 2461 */             offset += n;
/*      */           } else {
/* 2463 */             if (!regionMatchesIgnoreCase(target, offset - n, con.limit, o2, n))
/*      */             {
/* 2465 */               return -1; } 
/* 2466 */             offset -= n;
/*      */           } 
/*      */ 
/*      */           
/* 2470 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 6:
/* 2474 */           literal = op.getString();
/* 2475 */           literallen = literal.length();
/* 2476 */           if (!isSet(opts, 2)) {
/* 2477 */             if (dx > 0) {
/* 2478 */               if (!regionMatches(target, offset, con.limit, literal, literallen))
/* 2479 */                 return -1; 
/* 2480 */               offset += literallen;
/*      */             } else {
/* 2482 */               if (!regionMatches(target, offset - literallen, con.limit, literal, literallen))
/* 2483 */                 return -1; 
/* 2484 */               offset -= literallen;
/*      */             }
/*      */           
/* 2487 */           } else if (dx > 0) {
/* 2488 */             if (!regionMatchesIgnoreCase(target, offset, con.limit, literal, literallen))
/* 2489 */               return -1; 
/* 2490 */             offset += literallen;
/*      */           } else {
/* 2492 */             if (!regionMatchesIgnoreCase(target, offset - literallen, con.limit, literal, literallen))
/*      */             {
/* 2494 */               return -1; } 
/* 2495 */             offset -= literallen;
/*      */           } 
/*      */ 
/*      */           
/* 2499 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/* 2508 */           id = op.getData();
/* 2509 */           if (id >= 0) {
/* 2510 */             int previousOffset = con.offsets[id];
/* 2511 */             if (previousOffset < 0 || previousOffset != offset) {
/* 2512 */               con.offsets[id] = offset;
/*      */             } else {
/* 2514 */               con.offsets[id] = -1;
/* 2515 */               op = op.next;
/*      */               
/*      */               continue;
/*      */             } 
/*      */           } 
/* 2520 */           k = matchCharacterIterator(con, op.getChild(), offset, dx, opts);
/* 2521 */           if (id >= 0) con.offsets[id] = -1; 
/* 2522 */           if (k >= 0) return k; 
/* 2523 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 9:
/* 2529 */           ret = matchCharacterIterator(con, op.getChild(), offset, dx, opts);
/* 2530 */           if (ret >= 0) return ret; 
/* 2531 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 10:
/* 2538 */           ret = matchCharacterIterator(con, op.next, offset, dx, opts);
/* 2539 */           if (ret >= 0) return ret; 
/* 2540 */           op = op.getChild();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 11:
/* 2545 */           for (i = 0; i < op.size(); i++) {
/* 2546 */             k = matchCharacterIterator(con, op.elementAt(i), offset, dx, opts);
/*      */ 
/*      */ 
/*      */             
/* 2550 */             if (k >= 0) return k; 
/*      */           } 
/* 2552 */           return -1;
/*      */         
/*      */         case 15:
/* 2555 */           refno = op.getData();
/* 2556 */           if (con.match != null && refno > 0) {
/* 2557 */             int save = con.match.getBeginning(refno);
/* 2558 */             con.match.setBeginning(refno, offset);
/* 2559 */             int i1 = matchCharacterIterator(con, op.next, offset, dx, opts);
/* 2560 */             if (i1 < 0) con.match.setBeginning(refno, save); 
/* 2561 */             return i1;
/* 2562 */           }  if (con.match != null && refno < 0) {
/* 2563 */             int index = -refno;
/* 2564 */             int save = con.match.getEnd(index);
/* 2565 */             con.match.setEnd(index, offset);
/* 2566 */             int i1 = matchCharacterIterator(con, op.next, offset, dx, opts);
/* 2567 */             if (i1 < 0) con.match.setEnd(index, save); 
/* 2568 */             return i1;
/*      */           } 
/* 2570 */           op = op.next;
/*      */           continue;
/*      */         
/*      */         case 20:
/* 2574 */           if (0 > matchCharacterIterator(con, op.getChild(), offset, 1, opts)) return -1; 
/* 2575 */           op = op.next;
/*      */           continue;
/*      */         case 21:
/* 2578 */           if (0 <= matchCharacterIterator(con, op.getChild(), offset, 1, opts)) return -1; 
/* 2579 */           op = op.next;
/*      */           continue;
/*      */         case 22:
/* 2582 */           if (0 > matchCharacterIterator(con, op.getChild(), offset, -1, opts)) return -1; 
/* 2583 */           op = op.next;
/*      */           continue;
/*      */         case 23:
/* 2586 */           if (0 <= matchCharacterIterator(con, op.getChild(), offset, -1, opts)) return -1; 
/* 2587 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 24:
/* 2592 */           k = matchCharacterIterator(con, op.getChild(), offset, dx, opts);
/* 2593 */           if (k < 0) return k; 
/* 2594 */           offset = k;
/* 2595 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 25:
/* 2601 */           localopts = opts;
/* 2602 */           localopts |= op.getData();
/* 2603 */           localopts &= op.getData2() ^ 0xFFFFFFFF;
/*      */           
/* 2605 */           m = matchCharacterIterator(con, op.getChild(), offset, dx, localopts);
/* 2606 */           if (m < 0) return m; 
/* 2607 */           offset = m;
/* 2608 */           op = op.next;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 26:
/* 2614 */           cop = (Op.ConditionOp)op;
/* 2615 */           matchp = false;
/* 2616 */           if (cop.refNumber > 0) {
/* 2617 */             if (cop.refNumber >= this.nofparen)
/* 2618 */               throw new RuntimeException("Internal Error: Reference number must be more than zero: " + cop.refNumber); 
/* 2619 */             matchp = (con.match.getBeginning(cop.refNumber) >= 0 && con.match.getEnd(cop.refNumber) >= 0);
/*      */           } else {
/*      */             
/* 2622 */             matchp = (0 <= matchCharacterIterator(con, cop.condition, offset, dx, opts));
/*      */           } 
/*      */           
/* 2625 */           if (matchp) {
/* 2626 */             op = cop.yes; continue;
/* 2627 */           }  if (cop.no != null) {
/* 2628 */             op = cop.no; continue;
/*      */           } 
/* 2630 */           op = cop.next;
/*      */           continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/* 2636 */     throw new RuntimeException("Unknown operation type: " + op.type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int getPreviousWordType(CharacterIterator target, int begin, int end, int offset, int opts) {
/* 2643 */     int ret = getWordType(target, begin, end, --offset, opts);
/* 2644 */     while (ret == 0)
/* 2645 */       ret = getWordType(target, begin, end, --offset, opts); 
/* 2646 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int getWordType(CharacterIterator target, int begin, int end, int offset, int opts) {
/* 2651 */     if (offset < begin || offset >= end) return 2; 
/* 2652 */     return getWordType0(target.setIndex(offset), opts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean regionMatches(CharacterIterator target, int offset, int limit, String part, int partlen) {
/* 2659 */     if (offset < 0) return false; 
/* 2660 */     if (limit - offset < partlen)
/* 2661 */       return false; 
/* 2662 */     int i = 0;
/* 2663 */     while (partlen-- > 0) {
/* 2664 */       if (target.setIndex(offset++) != part.charAt(i++))
/* 2665 */         return false; 
/*      */     } 
/* 2667 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatches(CharacterIterator target, int offset, int limit, int offset2, int partlen) {
/* 2672 */     if (offset < 0) return false; 
/* 2673 */     if (limit - offset < partlen)
/* 2674 */       return false; 
/* 2675 */     int i = offset2;
/* 2676 */     while (partlen-- > 0) {
/* 2677 */       if (target.setIndex(offset++) != target.setIndex(i++))
/* 2678 */         return false; 
/*      */     } 
/* 2680 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean regionMatchesIgnoreCase(CharacterIterator target, int offset, int limit, String part, int partlen) {
/* 2688 */     if (offset < 0) return false; 
/* 2689 */     if (limit - offset < partlen)
/* 2690 */       return false; 
/* 2691 */     int i = 0;
/* 2692 */     while (partlen-- > 0) {
/* 2693 */       char ch1 = target.setIndex(offset++);
/* 2694 */       char ch2 = part.charAt(i++);
/* 2695 */       if (ch1 == ch2)
/*      */         continue; 
/* 2697 */       char uch1 = Character.toUpperCase(ch1);
/* 2698 */       char uch2 = Character.toUpperCase(ch2);
/* 2699 */       if (uch1 == uch2)
/*      */         continue; 
/* 2701 */       if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
/* 2702 */         return false; 
/*      */     } 
/* 2704 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean regionMatchesIgnoreCase(CharacterIterator target, int offset, int limit, int offset2, int partlen) {
/* 2709 */     if (offset < 0) return false; 
/* 2710 */     if (limit - offset < partlen)
/* 2711 */       return false; 
/* 2712 */     int i = offset2;
/* 2713 */     while (partlen-- > 0) {
/* 2714 */       char ch1 = target.setIndex(offset++);
/* 2715 */       char ch2 = target.setIndex(i++);
/* 2716 */       if (ch1 == ch2)
/*      */         continue; 
/* 2718 */       char uch1 = Character.toUpperCase(ch1);
/* 2719 */       char uch2 = Character.toUpperCase(ch2);
/* 2720 */       if (uch1 == uch2)
/*      */         continue; 
/* 2722 */       if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
/* 2723 */         return false; 
/*      */     } 
/* 2725 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasBackReferences = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   transient int minlength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2757 */   transient Op operations = null;
/*      */   transient int numberOfClosures;
/* 2759 */   transient Context context = null;
/* 2760 */   transient RangeToken firstChar = null;
/*      */   
/* 2762 */   transient String fixedString = null;
/*      */   transient int fixedStringOptions;
/* 2764 */   transient BMPattern fixedStringTable = null; transient boolean fixedStringOnly = false; static final int IGNORE_CASE = 2; static final int SINGLE_LINE = 4; static final int MULTIPLE_LINES = 8; static final int EXTENDED_COMMENT = 16; static final int USE_UNICODE_CATEGORY = 32; static final int UNICODE_WORD_BOUNDARY = 64; static final int PROHIBIT_HEAD_CHARACTER_OPTIMIZATION = 128; static final int PROHIBIT_FIXED_STRING_OPTIMIZATION = 256; static final int XMLSCHEMA_MODE = 512; static final int SPECIAL_COMMA = 1024; private static final int WT_IGNORE = 0;
/*      */   private static final int WT_LETTER = 1;
/*      */   private static final int WT_OTHER = 2;
/*      */   static final int LINE_FEED = 10;
/*      */   static final int CARRIAGE_RETURN = 13;
/*      */   static final int LINE_SEPARATOR = 8232;
/*      */   static final int PARAGRAPH_SEPARATOR = 8233;
/*      */   
/*      */   static final class Context { CharacterIterator ciTarget;
/*      */     String strTarget;
/*      */     char[] charTarget;
/*      */     int start;
/*      */     int limit;
/*      */     int length;
/*      */     Match match;
/*      */     boolean inuse = false;
/*      */     int[] offsets;
/*      */     
/*      */     private void resetCommon(int nofclosures) {
/* 2783 */       this.length = this.limit - this.start;
/* 2784 */       this.inuse = true;
/* 2785 */       this.match = null;
/* 2786 */       if (this.offsets == null || this.offsets.length != nofclosures)
/* 2787 */         this.offsets = new int[nofclosures]; 
/* 2788 */       for (int i = 0; i < nofclosures; ) { this.offsets[i] = -1; i++; }
/*      */     
/*      */     } void reset(CharacterIterator target, int start, int limit, int nofclosures) {
/* 2791 */       this.ciTarget = target;
/* 2792 */       this.start = start;
/* 2793 */       this.limit = limit;
/* 2794 */       resetCommon(nofclosures);
/*      */     }
/*      */     void reset(String target, int start, int limit, int nofclosures) {
/* 2797 */       this.strTarget = target;
/* 2798 */       this.start = start;
/* 2799 */       this.limit = limit;
/* 2800 */       resetCommon(nofclosures);
/*      */     }
/*      */     void reset(char[] target, int start, int limit, int nofclosures) {
/* 2803 */       this.charTarget = target;
/* 2804 */       this.start = start;
/* 2805 */       this.limit = limit;
/* 2806 */       resetCommon(nofclosures);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepare() {
/* 2815 */     compile(this.tokentree);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2825 */     this.minlength = this.tokentree.getMinLength();
/*      */     
/* 2827 */     this.firstChar = null;
/* 2828 */     if (!isSet(this.options, 128) && !isSet(this.options, 512)) {
/*      */       
/* 2830 */       RangeToken firstChar = Token.createRange();
/* 2831 */       int fresult = this.tokentree.analyzeFirstCharacter(firstChar, this.options);
/* 2832 */       if (fresult == 1) {
/* 2833 */         firstChar.compactRanges();
/* 2834 */         this.firstChar = firstChar;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2840 */     if (this.operations != null && (this.operations.type == 6 || this.operations.type == 1) && this.operations.next == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2845 */       this.fixedStringOnly = true;
/* 2846 */       if (this.operations.type == 6) {
/* 2847 */         this.fixedString = this.operations.getString();
/* 2848 */       } else if (this.operations.getData() >= 65536) {
/* 2849 */         this.fixedString = REUtil.decomposeToSurrogates(this.operations.getData());
/*      */       } else {
/* 2851 */         char[] ac = new char[1];
/* 2852 */         ac[0] = (char)this.operations.getData();
/* 2853 */         this.fixedString = new String(ac);
/*      */       } 
/* 2855 */       this.fixedStringOptions = this.options;
/* 2856 */       this.fixedStringTable = new BMPattern(this.fixedString, 256, isSet(this.fixedStringOptions, 2));
/*      */     }
/* 2858 */     else if (!isSet(this.options, 256) && !isSet(this.options, 512)) {
/*      */       
/* 2860 */       Token.FixedStringContainer container = new Token.FixedStringContainer();
/* 2861 */       this.tokentree.findFixedString(container, this.options);
/* 2862 */       this.fixedString = (container.token == null) ? null : container.token.getString();
/* 2863 */       this.fixedStringOptions = container.options;
/* 2864 */       if (this.fixedString != null && this.fixedString.length() < 2) {
/* 2865 */         this.fixedString = null;
/*      */       }
/* 2867 */       if (this.fixedString != null) {
/* 2868 */         this.fixedStringTable = new BMPattern(this.fixedString, 256, isSet(this.fixedStringOptions, 2));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean isSet(int options, int flag) {
/* 2954 */     return ((options & flag) == flag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RegularExpression(String regex) throws ParseException {
/* 2964 */     setPattern(regex, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RegularExpression(String regex, String options) throws ParseException {
/* 2975 */     setPattern(regex, options);
/*      */   }
/*      */   
/*      */   RegularExpression(String regex, Token tok, int parens, boolean hasBackReferences, int options) {
/* 2979 */     this.regex = regex;
/* 2980 */     this.tokentree = tok;
/* 2981 */     this.nofparen = parens;
/* 2982 */     this.options = options;
/* 2983 */     this.hasBackReferences = hasBackReferences;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPattern(String newPattern) throws ParseException {
/* 2990 */     setPattern(newPattern, this.options);
/*      */   }
/*      */   
/*      */   private void setPattern(String newPattern, int options) throws ParseException {
/* 2994 */     this.regex = newPattern;
/* 2995 */     this.options = options;
/* 2996 */     RegexParser rp = isSet(this.options, 512) ? new ParserForXMLSchema() : new RegexParser();
/*      */     
/* 2998 */     this.tokentree = rp.parse(this.regex, this.options);
/* 2999 */     this.nofparen = rp.parennumber;
/* 3000 */     this.hasBackReferences = rp.hasBackReferences;
/*      */     
/* 3002 */     this.operations = null;
/* 3003 */     this.context = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPattern(String newPattern, String options) throws ParseException {
/* 3009 */     setPattern(newPattern, REUtil.parseOptions(options));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPattern() {
/* 3016 */     return this.regex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 3023 */     return this.tokentree.toString(this.options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getOptions() {
/* 3035 */     return REUtil.createOptionString(this.options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 3042 */     if (obj == null) return false; 
/* 3043 */     if (!(obj instanceof RegularExpression))
/* 3044 */       return false; 
/* 3045 */     RegularExpression r = (RegularExpression)obj;
/* 3046 */     return (this.regex.equals(r.regex) && this.options == r.options);
/*      */   }
/*      */   
/*      */   boolean equals(String pattern, int options) {
/* 3050 */     return (this.regex.equals(pattern) && this.options == options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 3057 */     return (this.regex + "/" + getOptions()).hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfGroups() {
/* 3066 */     return this.nofparen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int getWordType0(char ch, int opts) {
/* 3075 */     if (!isSet(opts, 64)) {
/* 3076 */       if (isSet(opts, 32)) {
/* 3077 */         return Token.getRange("IsWord", true).match(ch) ? 1 : 2;
/*      */       }
/* 3079 */       return isWordChar(ch) ? 1 : 2;
/*      */     } 
/*      */     
/* 3082 */     switch (Character.getType(ch)) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/* 3092 */         return 1;
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 16:
/* 3097 */         return 0;
/*      */       
/*      */       case 15:
/* 3100 */         switch (ch) {
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\013':
/*      */           case '\f':
/*      */           case '\r':
/* 3106 */             return 2;
/*      */         } 
/* 3108 */         return 0;
/*      */     } 
/*      */ 
/*      */     
/* 3112 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean isEOLChar(int ch) {
/* 3124 */     return (ch == 10 || ch == 13 || ch == 8232 || ch == 8233);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean isWordChar(int ch) {
/* 3129 */     if (ch == 95) return true; 
/* 3130 */     if (ch < 48) return false; 
/* 3131 */     if (ch > 122) return false; 
/* 3132 */     if (ch <= 57) return true; 
/* 3133 */     if (ch < 65) return false; 
/* 3134 */     if (ch <= 90) return true; 
/* 3135 */     if (ch < 97) return false; 
/* 3136 */     return true;
/*      */   }
/*      */   
/*      */   private static final boolean matchIgnoreCase(int chardata, int ch) {
/* 3140 */     if (chardata == ch) return true; 
/* 3141 */     if (chardata > 65535 || ch > 65535) return false; 
/* 3142 */     char uch1 = Character.toUpperCase((char)chardata);
/* 3143 */     char uch2 = Character.toUpperCase((char)ch);
/* 3144 */     if (uch1 == uch2) return true; 
/* 3145 */     return (Character.toLowerCase(uch1) == Character.toLowerCase(uch2));
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\RegularExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */