/*     */ package org.apache.xmlbeans.impl.regex;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BMPattern
/*     */ {
/*     */   char[] pattern;
/*     */   int[] shiftTable;
/*     */   boolean ignoreCase;
/*     */   
/*     */   public BMPattern(String pat, boolean ignoreCase) {
/*  29 */     this(pat, 256, ignoreCase);
/*     */   }
/*     */   
/*     */   public BMPattern(String pat, int tableSize, boolean ignoreCase) {
/*  33 */     this.pattern = pat.toCharArray();
/*  34 */     this.shiftTable = new int[tableSize];
/*  35 */     this.ignoreCase = ignoreCase;
/*     */     
/*  37 */     int length = this.pattern.length; int i;
/*  38 */     for (i = 0; i < this.shiftTable.length; i++) {
/*  39 */       this.shiftTable[i] = length;
/*     */     }
/*  41 */     for (i = 0; i < length; i++) {
/*  42 */       char ch = this.pattern[i];
/*  43 */       int diff = length - i - 1;
/*  44 */       int index = ch % this.shiftTable.length;
/*  45 */       if (diff < this.shiftTable[index])
/*  46 */         this.shiftTable[index] = diff; 
/*  47 */       if (this.ignoreCase) {
/*  48 */         ch = Character.toUpperCase(ch);
/*  49 */         index = ch % this.shiftTable.length;
/*  50 */         if (diff < this.shiftTable[index])
/*  51 */           this.shiftTable[index] = diff; 
/*  52 */         ch = Character.toLowerCase(ch);
/*  53 */         index = ch % this.shiftTable.length;
/*  54 */         if (diff < this.shiftTable[index]) {
/*  55 */           this.shiftTable[index] = diff;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matches(CharacterIterator iterator, int start, int limit) {
/*  65 */     if (this.ignoreCase) return matchesIgnoreCase(iterator, start, limit); 
/*  66 */     int plength = this.pattern.length;
/*  67 */     if (plength == 0) return start; 
/*  68 */     int index = start + plength;
/*  69 */     while (index <= limit) {
/*  70 */       int pindex = plength;
/*  71 */       int nindex = index + 1;
/*     */       
/*     */       char ch;
/*  74 */       while ((ch = iterator.setIndex(--index)) == this.pattern[--pindex])
/*     */       
/*  76 */       { if (pindex == 0)
/*  77 */           return index; 
/*  78 */         if (pindex <= 0)
/*  79 */           break;  }  index += this.shiftTable[ch % this.shiftTable.length] + 1;
/*  80 */       if (index < nindex) index = nindex; 
/*     */     } 
/*  82 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matches(String str, int start, int limit) {
/*  90 */     if (this.ignoreCase) return matchesIgnoreCase(str, start, limit); 
/*  91 */     int plength = this.pattern.length;
/*  92 */     if (plength == 0) return start; 
/*  93 */     int index = start + plength;
/*  94 */     while (index <= limit) {
/*     */       
/*  96 */       int pindex = plength;
/*  97 */       int nindex = index + 1;
/*     */       
/*     */       char ch;
/* 100 */       while ((ch = str.charAt(--index)) == this.pattern[--pindex])
/*     */       
/* 102 */       { if (pindex == 0)
/* 103 */           return index; 
/* 104 */         if (pindex <= 0)
/* 105 */           break;  }  index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 106 */       if (index < nindex) index = nindex; 
/*     */     } 
/* 108 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matches(char[] chars, int start, int limit) {
/* 115 */     if (this.ignoreCase) return matchesIgnoreCase(chars, start, limit); 
/* 116 */     int plength = this.pattern.length;
/* 117 */     if (plength == 0) return start; 
/* 118 */     int index = start + plength;
/* 119 */     while (index <= limit) {
/*     */       
/* 121 */       int pindex = plength;
/* 122 */       int nindex = index + 1;
/*     */       
/*     */       char ch;
/* 125 */       while ((ch = chars[--index]) == this.pattern[--pindex])
/*     */       
/* 127 */       { if (pindex == 0)
/* 128 */           return index; 
/* 129 */         if (pindex <= 0)
/* 130 */           break;  }  index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 131 */       if (index < nindex) index = nindex; 
/*     */     } 
/* 133 */     return -1;
/*     */   }
/*     */   
/*     */   int matchesIgnoreCase(CharacterIterator iterator, int start, int limit) {
/* 137 */     int plength = this.pattern.length;
/* 138 */     if (plength == 0) return start; 
/* 139 */     int index = start + plength;
/* 140 */     while (index <= limit) {
/* 141 */       char ch; int pindex = plength;
/* 142 */       int nindex = index + 1;
/*     */       
/*     */       do {
/* 145 */         char ch1 = ch = iterator.setIndex(--index);
/* 146 */         char ch2 = this.pattern[--pindex];
/* 147 */         if (ch1 != ch2) {
/* 148 */           ch1 = Character.toUpperCase(ch1);
/* 149 */           ch2 = Character.toUpperCase(ch2);
/* 150 */           if (ch1 != ch2 && Character.toLowerCase(ch1) != Character.toLowerCase(ch2))
/*     */             break; 
/*     */         } 
/* 153 */         if (pindex == 0)
/* 154 */           return index; 
/* 155 */       } while (pindex > 0);
/* 156 */       index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 157 */       if (index < nindex) index = nindex; 
/*     */     } 
/* 159 */     return -1;
/*     */   }
/*     */   
/*     */   int matchesIgnoreCase(String text, int start, int limit) {
/* 163 */     int plength = this.pattern.length;
/* 164 */     if (plength == 0) return start; 
/* 165 */     int index = start + plength;
/* 166 */     while (index <= limit) {
/* 167 */       char ch; int pindex = plength;
/* 168 */       int nindex = index + 1;
/*     */       
/*     */       do {
/* 171 */         char ch1 = ch = text.charAt(--index);
/* 172 */         char ch2 = this.pattern[--pindex];
/* 173 */         if (ch1 != ch2) {
/* 174 */           ch1 = Character.toUpperCase(ch1);
/* 175 */           ch2 = Character.toUpperCase(ch2);
/* 176 */           if (ch1 != ch2 && Character.toLowerCase(ch1) != Character.toLowerCase(ch2))
/*     */             break; 
/*     */         } 
/* 179 */         if (pindex == 0)
/* 180 */           return index; 
/* 181 */       } while (pindex > 0);
/* 182 */       index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 183 */       if (index < nindex) index = nindex; 
/*     */     } 
/* 185 */     return -1;
/*     */   }
/*     */   int matchesIgnoreCase(char[] chars, int start, int limit) {
/* 188 */     int plength = this.pattern.length;
/* 189 */     if (plength == 0) return start; 
/* 190 */     int index = start + plength;
/* 191 */     while (index <= limit) {
/* 192 */       char ch; int pindex = plength;
/* 193 */       int nindex = index + 1;
/*     */       
/*     */       do {
/* 196 */         char ch1 = ch = chars[--index];
/* 197 */         char ch2 = this.pattern[--pindex];
/* 198 */         if (ch1 != ch2) {
/* 199 */           ch1 = Character.toUpperCase(ch1);
/* 200 */           ch2 = Character.toUpperCase(ch2);
/* 201 */           if (ch1 != ch2 && Character.toLowerCase(ch1) != Character.toLowerCase(ch2))
/*     */             break; 
/*     */         } 
/* 204 */         if (pindex == 0)
/* 205 */           return index; 
/* 206 */       } while (pindex > 0);
/* 207 */       index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 208 */       if (index < nindex) index = nindex; 
/*     */     } 
/* 210 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\BMPattern.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */