/*     */ package org.apache.xmlbeans.impl.regex;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Match
/*     */   implements Cloneable
/*     */ {
/*  32 */   int[] beginpos = null;
/*  33 */   int[] endpos = null;
/*  34 */   int nofgroups = 0;
/*     */   
/*  36 */   CharacterIterator ciSource = null;
/*  37 */   String strSource = null;
/*  38 */   char[] charSource = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object clone() {
/*  50 */     Match ma = new Match();
/*  51 */     if (this.nofgroups > 0) {
/*  52 */       ma.setNumberOfGroups(this.nofgroups);
/*  53 */       if (this.ciSource != null) ma.setSource(this.ciSource); 
/*  54 */       if (this.strSource != null) ma.setSource(this.strSource); 
/*  55 */       for (int i = 0; i < this.nofgroups; i++) {
/*  56 */         ma.setBeginning(i, getBeginning(i));
/*  57 */         ma.setEnd(i, getEnd(i));
/*     */       } 
/*     */     } 
/*  60 */     return ma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setNumberOfGroups(int n) {
/*  67 */     int oldn = this.nofgroups;
/*  68 */     this.nofgroups = n;
/*  69 */     if (oldn <= 0 || oldn < n || n * 2 < oldn) {
/*     */       
/*  71 */       this.beginpos = new int[n];
/*  72 */       this.endpos = new int[n];
/*     */     } 
/*  74 */     for (int i = 0; i < n; i++) {
/*  75 */       this.beginpos[i] = -1;
/*  76 */       this.endpos[i] = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSource(CharacterIterator ci) {
/*  84 */     this.ciSource = ci;
/*  85 */     this.strSource = null;
/*  86 */     this.charSource = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSource(String str) {
/*  92 */     this.ciSource = null;
/*  93 */     this.strSource = str;
/*  94 */     this.charSource = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSource(char[] chars) {
/* 100 */     this.ciSource = null;
/* 101 */     this.strSource = null;
/* 102 */     this.charSource = chars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBeginning(int index, int v) {
/* 109 */     this.beginpos[index] = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setEnd(int index, int v) {
/* 116 */     this.endpos[index] = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfGroups() {
/* 124 */     if (this.nofgroups <= 0)
/* 125 */       throw new IllegalStateException("A result is not set."); 
/* 126 */     return this.nofgroups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBeginning(int index) {
/* 135 */     if (this.beginpos == null)
/* 136 */       throw new IllegalStateException("A result is not set."); 
/* 137 */     if (index < 0 || this.nofgroups <= index) {
/* 138 */       throw new IllegalArgumentException("The parameter must be less than " + this.nofgroups + ": " + index);
/*     */     }
/* 140 */     return this.beginpos[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEnd(int index) {
/* 149 */     if (this.endpos == null)
/* 150 */       throw new IllegalStateException("A result is not set."); 
/* 151 */     if (index < 0 || this.nofgroups <= index) {
/* 152 */       throw new IllegalArgumentException("The parameter must be less than " + this.nofgroups + ": " + index);
/*     */     }
/* 154 */     return this.endpos[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCapturedText(int index) {
/*     */     String ret;
/* 163 */     if (this.beginpos == null)
/* 164 */       throw new IllegalStateException("match() has never been called."); 
/* 165 */     if (index < 0 || this.nofgroups <= index) {
/* 166 */       throw new IllegalArgumentException("The parameter must be less than " + this.nofgroups + ": " + index);
/*     */     }
/*     */     
/* 169 */     int begin = this.beginpos[index], end = this.endpos[index];
/* 170 */     if (begin < 0 || end < 0) return null; 
/* 171 */     if (this.ciSource != null) {
/* 172 */       ret = REUtil.substring(this.ciSource, begin, end);
/* 173 */     } else if (this.strSource != null) {
/* 174 */       ret = this.strSource.substring(begin, end);
/*     */     } else {
/* 176 */       ret = new String(this.charSource, begin, end - begin);
/*     */     } 
/* 178 */     return ret;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\Match.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */