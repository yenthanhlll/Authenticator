/*     */ package org.apache.xmlbeans.impl.soap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPElementFactory
/*     */ {
/*     */   private SOAPFactory sf;
/*     */   
/*     */   private SOAPElementFactory(SOAPFactory soapfactory) {
/*  40 */     this.sf = soapfactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPElement create(Name name) throws SOAPException {
/*  56 */     return this.sf.createElement(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPElement create(String localName) throws SOAPException {
/*  72 */     return this.sf.createElement(localName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPElement create(String localName, String prefix, String uri) throws SOAPException {
/*  94 */     return this.sf.createElement(localName, prefix, uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SOAPElementFactory newInstance() throws SOAPException {
/*     */     try {
/* 109 */       return new SOAPElementFactory(SOAPFactory.newInstance());
/* 110 */     } catch (Exception exception) {
/* 111 */       throw new SOAPException("Unable to create SOAP Element Factory: " + exception.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\soap\SOAPElementFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */