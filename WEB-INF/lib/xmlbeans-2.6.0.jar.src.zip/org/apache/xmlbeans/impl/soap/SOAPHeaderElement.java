package org.apache.xmlbeans.impl.soap;

public interface SOAPHeaderElement extends SOAPElement {
  void setActor(String paramString);
  
  String getActor();
  
  void setMustUnderstand(boolean paramBoolean);
  
  boolean getMustUnderstand();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\soap\SOAPHeaderElement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */