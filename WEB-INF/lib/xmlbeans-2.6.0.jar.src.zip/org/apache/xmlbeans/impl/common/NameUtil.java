/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameUtil
/*     */ {
/*     */   public static final char HYPHEN = '-';
/*     */   public static final char PERIOD = '.';
/*     */   public static final char COLON = ':';
/*     */   public static final char USCORE = '_';
/*     */   public static final char DOT = '·';
/*     */   public static final char TELEIA = '·';
/*     */   public static final char AYAH = '۝';
/*     */   public static final char ELHIZB = '۞';
/*     */   private static final boolean DEBUG = false;
/*  36 */   private static final Set javaWords = new HashSet(Arrays.asList((Object[])new String[] { "assert", "abstract", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "enum", "extends", "false", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "null", "package", "private", "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this", "threadsafe", "throw", "throws", "transient", "true", "try", "void", "volatile", "while" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private static final Set extraWords = new HashSet(Arrays.asList((Object[])new String[] { "i", "target", "org", "com" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   private static final Set javaNames = new HashSet(Arrays.asList((Object[])new String[] { "CharSequence", "Cloneable", "Comparable", "Runnable", "Boolean", "Byte", "Character", "Class", "ClassLoader", "Compiler", "Double", "Float", "InheritableThreadLocal", "Integer", "Long", "Math", "Number", "Object", "Package", "Process", "Runtime", "RuntimePermission", "SecurityManager", "Short", "StackTraceElement", "StrictMath", "String", "StringBuffer", "System", "Thread", "ThreadGroup", "ThreadLocal", "Throwable", "Void", "ArithmeticException", "ArrayIndexOutOfBoundsException", "ArrayStoreException", "ClassCastException", "ClassNotFoundException", "CloneNotSupportedException", "Exception", "IllegalAccessException", "IllegalArgumentException", "IllegalMonitorStateException", "IllegalStateException", "IllegalThreadStateException", "IndexOutOfBoundsException", "InstantiationException", "InterruptedException", "NegativeArraySizeException", "NoSuchFieldException", "NoSuchMethodException", "NullPointerException", "NumberFormatException", "RuntimeException", "SecurityException", "StringIndexOutOfBoundsException", "UnsupportedOperationException", "AbstractMethodError", "AssertionError", "ClassCircularityError", "ClassFormatError", "Error", "ExceptionInInitializerError", "IllegalAccessError", "IncompatibleClassChangeError", "InstantiationError", "InternalError", "LinkageError", "NoClassDefFoundError", "NoSuchFieldError", "NoSuchMethodError", "OutOfMemoryError", "StackOverflowError", "ThreadDeath", "UnknownError", "UnsatisfiedLinkError", "UnsupportedClassVersionError", "VerifyError", "VirtualMachineError", "BigInteger", "BigDecimal", "Enum", "Date", "GDate", "GDuration", "QName", "List", "XmlObject", "XmlCursor", "XmlBeans", "SchemaType" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String JAVA_NS_PREFIX = "java:";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String LANG_PREFIX = "java.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int START = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int PUNCT = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DIGIT = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MARK = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int UPPER = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int LOWER = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NOCASE = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidJavaIdentifier(String id) {
/* 305 */     if (id == null) {
/* 306 */       throw new IllegalArgumentException("id cannot be null");
/*     */     }
/* 308 */     int len = id.length();
/* 309 */     if (len == 0) {
/* 310 */       return false;
/*     */     }
/* 312 */     if (javaWords.contains(id)) {
/* 313 */       return false;
/*     */     }
/* 315 */     if (!Character.isJavaIdentifierStart(id.charAt(0))) {
/* 316 */       return false;
/*     */     }
/* 318 */     for (int i = 1; i < len; i++) {
/*     */       
/* 320 */       if (!Character.isJavaIdentifierPart(id.charAt(i))) {
/* 321 */         return false;
/*     */       }
/*     */     } 
/* 324 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getClassNameFromQName(QName qname) {
/* 329 */     return getClassNameFromQName(qname, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getClassNameFromQName(QName qname, boolean useJaxRpcRules) {
/* 334 */     String java_type = upperCamelCase(qname.getLocalPart(), useJaxRpcRules);
/*     */     
/* 336 */     String uri = qname.getNamespaceURI();
/* 337 */     String java_pkg = null;
/*     */     
/* 339 */     java_pkg = getPackageFromNamespace(uri, useJaxRpcRules);
/*     */     
/* 341 */     if (java_pkg != null) {
/* 342 */       return java_pkg + "." + java_type;
/*     */     }
/* 344 */     return java_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNamespaceFromPackage(Class clazz) {
/* 352 */     Class curr_clazz = clazz;
/*     */     
/* 354 */     while (curr_clazz.isArray()) {
/* 355 */       curr_clazz = curr_clazz.getComponentType();
/*     */     }
/* 357 */     String fullname = clazz.getName();
/* 358 */     int lastdot = fullname.lastIndexOf('.');
/* 359 */     String pkg_name = (lastdot < 0) ? "" : fullname.substring(0, lastdot);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 373 */     return "java:" + pkg_name;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isUriSchemeChar(char ch) {
/* 378 */     return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '-' || ch == '.' || ch == '+');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isUriAlphaChar(char ch) {
/* 386 */     return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'));
/*     */   }
/*     */ 
/*     */   
/*     */   private static int findSchemeColon(String uri) {
/* 391 */     int len = uri.length();
/* 392 */     if (len == 0)
/* 393 */       return -1; 
/* 394 */     if (!isUriAlphaChar(uri.charAt(0)))
/* 395 */       return -1; 
/*     */     int i;
/* 397 */     for (i = 1; i < len && 
/* 398 */       isUriSchemeChar(uri.charAt(i)); i++);
/*     */     
/* 400 */     if (i == len)
/* 401 */       return -1; 
/* 402 */     if (uri.charAt(i) != ':') {
/* 403 */       return -1;
/*     */     }
/* 405 */     for (; i < len && 
/* 406 */       uri.charAt(i) == ':'; i++);
/*     */ 
/*     */     
/* 409 */     return i - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String jls77String(String name) {
/* 414 */     StringBuffer buf = new StringBuffer(name);
/* 415 */     for (int i = 0; i < name.length(); i++) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 420 */       if (!Character.isJavaIdentifierPart(buf.charAt(i)) || '$' == buf.charAt(i))
/* 421 */         buf.setCharAt(i, '_'); 
/*     */     } 
/* 423 */     if (buf.length() == 0 || !Character.isJavaIdentifierStart(buf.charAt(0)))
/* 424 */       buf.insert(0, '_'); 
/* 425 */     if (isJavaReservedWord(name))
/* 426 */       buf.append('_'); 
/* 427 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List splitDNS(String dns) {
/* 435 */     List result = new ArrayList();
/*     */     
/* 437 */     int end = dns.length();
/* 438 */     int begin = dns.lastIndexOf('.');
/* 439 */     for (; begin != -1; begin--) {
/*     */       
/* 441 */       if (dns.charAt(begin) == '.') {
/* 442 */         result.add(jls77String(dns.substring(begin + 1, end)));
/* 443 */         end = begin;
/*     */       } 
/*     */     } 
/* 446 */     result.add(jls77String(dns.substring(0, end)));
/*     */ 
/*     */     
/* 449 */     if (result.size() >= 3 && ((String)result.get(result.size() - 1)).toLowerCase().equals("www"))
/*     */     {
/* 451 */       result.remove(result.size() - 1);
/*     */     }
/* 453 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String processFilename(String filename) {
/* 460 */     int i = filename.lastIndexOf('.');
/* 461 */     if (i > 0 && (i + 1 + 2 == filename.length() || i + 1 + 3 == filename.length() || filename.substring(i + 1).toLowerCase() == "html"))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 466 */       return filename.substring(0, i);
/*     */     }
/*     */     
/* 469 */     return filename;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getPackageFromNamespace(String uri) {
/* 474 */     return getPackageFromNamespace(uri, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageFromNamespace(String uri, boolean useJaxRpcRules) {
/* 480 */     if (uri == null || uri.length() == 0) {
/* 481 */       return "noNamespace";
/*     */     }
/*     */     
/* 484 */     int len = uri.length();
/* 485 */     int i = findSchemeColon(uri);
/* 486 */     List result = null;
/*     */     
/* 488 */     if (i == len - 1) {
/*     */ 
/*     */       
/* 491 */       result = new ArrayList();
/* 492 */       result.add(uri.substring(0, i));
/*     */     }
/* 494 */     else if (i >= 0 && uri.substring(0, i).equals("java")) {
/*     */       
/* 496 */       result = Arrays.asList(uri.substring(i + 1).split("\\."));
/*     */     } else {
/*     */       
/* 499 */       result = new ArrayList();
/* 500 */       label42: while (++i < len) {
/*     */         
/* 502 */         while (uri.charAt(i) == '/')
/* 503 */         { if (++i >= len)
/* 504 */             break label42;  }  int start = i; do {  }
/* 505 */         while (uri.charAt(i) != '/' && 
/* 506 */           ++i < len);
/* 507 */         int end = i;
/* 508 */         result.add(uri.substring(start, end));
/*     */       } 
/* 510 */       if (result.size() > 1) {
/* 511 */         result.set(result.size() - 1, processFilename(result.get(result.size() - 1)));
/*     */       }
/* 513 */       if (result.size() > 0) {
/*     */         
/* 515 */         List splitdns = splitDNS(result.get(0));
/* 516 */         result.remove(0);
/* 517 */         result.addAll(0, splitdns);
/*     */       } 
/*     */     } 
/*     */     
/* 521 */     StringBuffer buf = new StringBuffer();
/* 522 */     for (Iterator it = result.iterator(); it.hasNext(); ) {
/*     */       
/* 524 */       String part = nonJavaKeyword(lowerCamelCase(it.next(), useJaxRpcRules, true));
/* 525 */       if (part.length() > 0) {
/*     */         
/* 527 */         buf.append(part);
/* 528 */         buf.append('.');
/*     */       } 
/*     */     } 
/* 531 */     if (buf.length() == 0)
/* 532 */       return "noNamespace"; 
/* 533 */     if (useJaxRpcRules)
/* 534 */       return buf.substring(0, buf.length() - 1).toLowerCase(); 
/* 535 */     return buf.substring(0, buf.length() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 540 */     for (int i = 0; i < args.length; i++) {
/* 541 */       System.out.println(upperCaseUnderbar(args[i]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String upperCaseUnderbar(String xml_name) {
/* 552 */     StringBuffer buf = new StringBuffer();
/* 553 */     List words = splitWords(xml_name, false);
/*     */     
/* 555 */     int sz = words.size() - 1;
/* 556 */     if (sz >= 0 && !Character.isJavaIdentifierStart(((String)words.get(0)).charAt(0))) {
/* 557 */       buf.append("X_");
/*     */     }
/* 559 */     for (int i = 0; i < sz; i++) {
/*     */       
/* 561 */       buf.append(words.get(i));
/* 562 */       buf.append('_');
/*     */     } 
/*     */     
/* 565 */     if (sz >= 0)
/*     */     {
/* 567 */       buf.append(words.get(sz));
/*     */     }
/*     */ 
/*     */     
/* 571 */     int len = buf.length();
/* 572 */     for (int j = 0; j < len; j++) {
/*     */       
/* 574 */       char c = buf.charAt(j);
/* 575 */       buf.setCharAt(j, Character.toUpperCase(c));
/*     */     } 
/*     */     
/* 578 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String upperCamelCase(String xml_name) {
/* 589 */     return upperCamelCase(xml_name, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String upperCamelCase(String xml_name, boolean useJaxRpcRules) {
/* 598 */     StringBuffer buf = new StringBuffer();
/* 599 */     List words = splitWords(xml_name, useJaxRpcRules);
/*     */     
/* 601 */     if (words.size() > 0) {
/*     */       
/* 603 */       if (!Character.isJavaIdentifierStart(((String)words.get(0)).charAt(0))) {
/* 604 */         buf.append("X");
/*     */       }
/* 606 */       Iterator itr = words.iterator();
/* 607 */       while (itr.hasNext())
/* 608 */         buf.append(itr.next()); 
/*     */     } 
/* 610 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String lowerCamelCase(String xml_name) {
/* 624 */     return lowerCamelCase(xml_name, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String lowerCamelCase(String xml_name, boolean useJaxRpcRules, boolean fixGeneratedName) {
/* 633 */     StringBuffer buf = new StringBuffer();
/* 634 */     List words = splitWords(xml_name, useJaxRpcRules);
/*     */     
/* 636 */     if (words.size() > 0) {
/*     */       
/* 638 */       String first = ((String)words.get(0)).toLowerCase();
/* 639 */       char f = first.charAt(0);
/* 640 */       if (!Character.isJavaIdentifierStart(f) && fixGeneratedName)
/* 641 */         buf.append("x"); 
/* 642 */       buf.append(first);
/*     */       
/* 644 */       Iterator itr = words.iterator();
/* 645 */       itr.next();
/* 646 */       while (itr.hasNext())
/* 647 */         buf.append(itr.next()); 
/*     */     } 
/* 649 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String upperCaseFirstLetter(String s) {
/* 654 */     if (s.length() == 0 || Character.isUpperCase(s.charAt(0))) {
/* 655 */       return s;
/*     */     }
/* 657 */     StringBuffer buf = new StringBuffer(s);
/* 658 */     buf.setCharAt(0, Character.toUpperCase(buf.charAt(0)));
/* 659 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addCapped(List list, String str) {
/* 671 */     if (str.length() > 0) {
/* 672 */       list.add(upperCaseFirstLetter(str));
/*     */     }
/*     */   }
/*     */   
/*     */   public static List splitWords(String name, boolean useJaxRpcRules) {
/* 677 */     List list = new ArrayList();
/* 678 */     int len = name.length();
/* 679 */     int start = 0;
/* 680 */     int prefix = 0;
/* 681 */     for (int i = 0; i < len; i++) {
/*     */       
/* 683 */       int current = getCharClass(name.charAt(i), useJaxRpcRules);
/* 684 */       if (prefix != 1 && current == 1) {
/*     */         
/* 686 */         addCapped(list, name.substring(start, i));
/* 687 */         while ((current = getCharClass(name.charAt(i), useJaxRpcRules)) == 1) {
/* 688 */           if (++i >= len) return list; 
/* 689 */         }  start = i;
/*     */       }
/* 691 */       else if (((prefix == 2) ? true : false) != ((current == 2) ? true : false) || (prefix == 5 && current != 5) || isLetter(prefix) != isLetter(current)) {
/*     */ 
/*     */ 
/*     */         
/* 695 */         addCapped(list, name.substring(start, i));
/* 696 */         start = i;
/*     */       }
/* 698 */       else if (prefix == 4 && current == 5 && i > start + 1) {
/*     */         
/* 700 */         addCapped(list, name.substring(start, i - 1));
/* 701 */         start = i - 1;
/*     */       } 
/* 703 */       prefix = current;
/*     */     } 
/* 705 */     addCapped(list, name.substring(start));
/* 706 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getCharClass(char c, boolean useJaxRpcRules) {
/* 721 */     if (isPunctuation(c, useJaxRpcRules))
/* 722 */       return 1; 
/* 723 */     if (Character.isDigit(c))
/* 724 */       return 2; 
/* 725 */     if (Character.isUpperCase(c))
/* 726 */       return 4; 
/* 727 */     if (Character.isLowerCase(c))
/* 728 */       return 5; 
/* 729 */     if (Character.isLetter(c))
/* 730 */       return 6; 
/* 731 */     if (Character.isJavaIdentifierPart(c)) {
/* 732 */       return 3;
/*     */     }
/* 734 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isLetter(int state) {
/* 739 */     return (state == 4 || state == 5 || state == 6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPunctuation(char c, boolean useJaxRpcRules) {
/* 746 */     return (c == '-' || c == '.' || c == ':' || c == '·' || (c == '_' && !useJaxRpcRules) || c == '·' || c == '۝' || c == '۞');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nonJavaKeyword(String word) {
/* 763 */     if (isJavaReservedWord(word))
/* 764 */       return 'x' + word; 
/* 765 */     return word;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nonExtraKeyword(String word) {
/* 775 */     if (isExtraReservedWord(word, true))
/* 776 */       return word + "Value"; 
/* 777 */     return word;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nonJavaCommonClassName(String name) {
/* 787 */     if (isJavaCommonClassName(name))
/* 788 */       return "X" + name; 
/* 789 */     return name;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isJavaReservedWord(String word) {
/* 794 */     return isJavaReservedWord(word, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isJavaReservedWord(String word, boolean ignore_case) {
/* 799 */     if (ignore_case)
/* 800 */       word = word.toLowerCase(); 
/* 801 */     return javaWords.contains(word);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isExtraReservedWord(String word, boolean ignore_case) {
/* 806 */     if (ignore_case)
/* 807 */       word = word.toLowerCase(); 
/* 808 */     return extraWords.contains(word);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isJavaCommonClassName(String word) {
/* 813 */     return javaNames.contains(word);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\NameUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */