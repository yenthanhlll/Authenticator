/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaField;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QNameHelper
/*     */ {
/*  33 */   private static final Map WELL_KNOWN_PREFIXES = buildWKP();
/*     */ 
/*     */   
/*     */   public static XMLName getXMLName(QName qname) {
/*  37 */     if (qname == null) {
/*  38 */       return null;
/*     */     }
/*  40 */     return XMLNameHelper.forLNS(qname.getLocalPart(), qname.getNamespaceURI());
/*     */   }
/*     */ 
/*     */   
/*     */   public static QName forLNS(String localname, String uri) {
/*  45 */     if (uri == null)
/*  46 */       uri = ""; 
/*  47 */     return new QName(uri, localname);
/*     */   }
/*     */ 
/*     */   
/*     */   public static QName forLN(String localname) {
/*  52 */     return new QName("", localname);
/*     */   }
/*     */ 
/*     */   
/*     */   public static QName forPretty(String pretty, int offset) {
/*  57 */     int at = pretty.indexOf('@', offset);
/*  58 */     if (at < 0)
/*  59 */       return new QName("", pretty.substring(offset)); 
/*  60 */     return new QName(pretty.substring(at + 1), pretty.substring(offset, at));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String pretty(QName name) {
/*  65 */     if (name == null) {
/*  66 */       return "null";
/*     */     }
/*  68 */     if (name.getNamespaceURI() == null || name.getNamespaceURI().length() == 0) {
/*  69 */       return name.getLocalPart();
/*     */     }
/*  71 */     return name.getLocalPart() + "@" + name.getNamespaceURI();
/*     */   }
/*     */   
/*  74 */   private static final char[] hexdigits = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' }; public static final int MAX_NAME_LENGTH = 64;
/*     */   public static final String URI_SHA1_PREFIX = "URI_SHA_1_";
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static boolean isSafe(int c) {
/*  79 */     if (c >= 97 && c <= 122)
/*  80 */       return true; 
/*  81 */     if (c >= 65 && c <= 90)
/*  82 */       return true; 
/*  83 */     if (c >= 48 && c <= 57)
/*  84 */       return true; 
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hexsafe(String s) {
/* 111 */     StringBuffer result = new StringBuffer();
/* 112 */     for (int i = 0; i < s.length(); i++) {
/*     */       
/* 114 */       char ch = s.charAt(i);
/* 115 */       if (isSafe(ch)) {
/*     */         
/* 117 */         result.append(ch);
/*     */       }
/*     */       else {
/*     */         
/* 121 */         byte[] utf8 = null;
/*     */         
/*     */         try {
/* 124 */           utf8 = s.substring(i, i + 1).getBytes("UTF-8");
/* 125 */           for (int j = 0; j < utf8.length; j++)
/*     */           {
/* 127 */             result.append('_');
/* 128 */             result.append(hexdigits[utf8[j] >> 4 & 0xF]);
/* 129 */             result.append(hexdigits[utf8[j] & 0xF]);
/*     */           }
/*     */         
/* 132 */         } catch (UnsupportedEncodingException uee) {
/*     */ 
/*     */           
/* 135 */           result.append("_BAD_UTF8_CHAR");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 141 */     if (result.length() <= 64) {
/* 142 */       return result.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 147 */       MessageDigest md = MessageDigest.getInstance("SHA");
/* 148 */       byte[] inputBytes = null;
/*     */       
/*     */       try {
/* 151 */         inputBytes = s.getBytes("UTF-8");
/*     */       }
/* 153 */       catch (UnsupportedEncodingException uee) {
/*     */ 
/*     */         
/* 156 */         inputBytes = new byte[0];
/*     */       } 
/* 158 */       byte[] digest = md.digest(inputBytes);
/* 159 */       assert digest.length == 20;
/* 160 */       result = new StringBuffer("URI_SHA_1_");
/* 161 */       for (int j = 0; j < digest.length; j++) {
/*     */         
/* 163 */         result.append(hexdigits[digest[j] >> 4 & 0xF]);
/* 164 */         result.append(hexdigits[digest[j] & 0xF]);
/*     */       } 
/* 166 */       return result.toString();
/*     */     }
/* 168 */     catch (NoSuchAlgorithmException e) {
/*     */       
/* 170 */       throw new IllegalStateException("Using in a JDK without an SHA implementation");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String hexsafedir(QName name) {
/* 176 */     if (name.getNamespaceURI() == null || name.getNamespaceURI().length() == 0)
/* 177 */       return "_nons/" + hexsafe(name.getLocalPart()); 
/* 178 */     return hexsafe(name.getNamespaceURI()) + "/" + hexsafe(name.getLocalPart());
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map buildWKP() {
/* 183 */     Map result = new HashMap();
/* 184 */     result.put("http://www.w3.org/XML/1998/namespace", "xml");
/* 185 */     result.put("http://www.w3.org/2001/XMLSchema", "xs");
/* 186 */     result.put("http://www.w3.org/2001/XMLSchema-instance", "xsi");
/* 187 */     result.put("http://schemas.xmlsoap.org/wsdl/", "wsdl");
/* 188 */     result.put("http://schemas.xmlsoap.org/soap/encoding/", "soapenc");
/* 189 */     result.put("http://schemas.xmlsoap.org/soap/envelope/", "soapenv");
/* 190 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String readable(SchemaType sType) {
/* 195 */     return readable(sType, WELL_KNOWN_PREFIXES);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String readable(SchemaType sType, Map nsPrefix) {
/* 200 */     if (sType.getName() != null)
/*     */     {
/* 202 */       return readable(sType.getName(), nsPrefix);
/*     */     }
/*     */     
/* 205 */     if (sType.isAttributeType())
/*     */     {
/* 207 */       return "attribute type " + readable(sType.getAttributeTypeAttributeName(), nsPrefix);
/*     */     }
/*     */     
/* 210 */     if (sType.isDocumentType())
/*     */     {
/* 212 */       return "document type " + readable(sType.getDocumentElementName(), nsPrefix);
/*     */     }
/*     */     
/* 215 */     if (sType.isNoType() || sType.getOuterType() == null)
/*     */     {
/* 217 */       return "invalid type";
/*     */     }
/*     */     
/* 220 */     SchemaType outerType = sType.getOuterType();
/* 221 */     SchemaField container = sType.getContainerField();
/*     */     
/* 223 */     if (outerType.isAttributeType())
/*     */     {
/* 225 */       return "type of attribute " + readable(container.getName(), nsPrefix);
/*     */     }
/* 227 */     if (outerType.isDocumentType())
/*     */     {
/* 229 */       return "type of element " + readable(container.getName(), nsPrefix);
/*     */     }
/*     */     
/* 232 */     if (container != null) {
/*     */       
/* 234 */       if (container.isAttribute())
/*     */       {
/* 236 */         return "type of " + container.getName().getLocalPart() + " attribute in " + readable(outerType, nsPrefix);
/*     */       }
/*     */ 
/*     */       
/* 240 */       return "type of " + container.getName().getLocalPart() + " element in " + readable(outerType, nsPrefix);
/*     */     } 
/*     */ 
/*     */     
/* 244 */     if (outerType.getBaseType() == sType)
/* 245 */       return "base type of " + readable(outerType, nsPrefix); 
/* 246 */     if (outerType.getSimpleVariety() == 3)
/* 247 */       return "item type of " + readable(outerType, nsPrefix); 
/* 248 */     if (outerType.getSimpleVariety() == 2) {
/* 249 */       return "member type " + sType.getAnonymousUnionMemberOrdinal() + " of " + readable(outerType, nsPrefix);
/*     */     }
/* 251 */     return "inner type in " + readable(outerType, nsPrefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String readable(QName name) {
/* 256 */     return readable(name, WELL_KNOWN_PREFIXES);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String readable(QName name, Map prefixes) {
/* 261 */     if (name.getNamespaceURI().length() == 0)
/* 262 */       return name.getLocalPart(); 
/* 263 */     String prefix = (String)prefixes.get(name.getNamespaceURI());
/* 264 */     if (prefix != null)
/* 265 */       return prefix + ":" + name.getLocalPart(); 
/* 266 */     return name.getLocalPart() + " in namespace " + name.getNamespaceURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String suggestPrefix(String namespace) {
/* 271 */     String result = (String)WELL_KNOWN_PREFIXES.get(namespace);
/* 272 */     if (result != null) {
/* 273 */       return result;
/*     */     }
/* 275 */     int len = namespace.length();
/* 276 */     int i = namespace.lastIndexOf('/');
/* 277 */     if (i > 0 && i == namespace.length() - 1) {
/*     */       
/* 279 */       len = i;
/* 280 */       i = namespace.lastIndexOf('/', i - 1);
/*     */     } 
/*     */     
/* 283 */     i++;
/*     */     
/* 285 */     if (namespace.startsWith("www.", i))
/*     */     {
/* 287 */       i += 4;
/*     */     }
/*     */     
/* 290 */     while (i < len) {
/*     */       
/* 292 */       if (XMLChar.isNCNameStart(namespace.charAt(i)))
/*     */         break; 
/* 294 */       i++;
/*     */     } 
/*     */     
/* 297 */     for (int end = i + 1; end < len; end++) {
/*     */       
/* 299 */       if (!XMLChar.isNCName(namespace.charAt(end)) || !Character.isLetterOrDigit(namespace.charAt(end))) {
/*     */         
/* 301 */         len = end;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 307 */     if (namespace.length() >= i + 3 && startsWithXml(namespace, i)) {
/*     */       
/* 309 */       if (namespace.length() >= i + 4)
/* 310 */         return "x" + Character.toLowerCase(namespace.charAt(i + 3)); 
/* 311 */       return "ns";
/*     */     } 
/*     */     
/* 314 */     if (len - i > 4)
/*     */     {
/* 316 */       if (isVowel(namespace.charAt(i + 2)) && !isVowel(namespace.charAt(i + 3))) {
/* 317 */         len = i + 4;
/*     */       } else {
/* 319 */         len = i + 3;
/*     */       } 
/*     */     }
/* 322 */     if (len - i == 0) {
/* 323 */       return "ns";
/*     */     }
/* 325 */     return namespace.substring(i, len).toLowerCase();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean startsWithXml(String s, int i) {
/* 330 */     if (s.length() < i + 3) {
/* 331 */       return false;
/*     */     }
/* 333 */     if (s.charAt(i) != 'X' && s.charAt(i) != 'x')
/* 334 */       return false; 
/* 335 */     if (s.charAt(i + 1) != 'M' && s.charAt(i + 1) != 'm')
/* 336 */       return false; 
/* 337 */     if (s.charAt(i + 2) != 'L' && s.charAt(i + 2) != 'l') {
/* 338 */       return false;
/*     */     }
/* 340 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isVowel(char ch) {
/* 345 */     switch (ch) {
/*     */       
/*     */       case 'A':
/*     */       case 'E':
/*     */       case 'I':
/*     */       case 'O':
/*     */       case 'U':
/*     */       case 'a':
/*     */       case 'e':
/*     */       case 'i':
/*     */       case 'o':
/*     */       case 'u':
/* 357 */         return true;
/*     */     } 
/* 359 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String namespace(SchemaType sType) {
/* 365 */     while (sType != null) {
/*     */       
/* 367 */       if (sType.getName() != null)
/* 368 */         return sType.getName().getNamespaceURI(); 
/* 369 */       if (sType.getContainerField() != null && sType.getContainerField().getName().getNamespaceURI().length() > 0)
/* 370 */         return sType.getContainerField().getName().getNamespaceURI(); 
/* 371 */       sType = sType.getOuterType();
/*     */     } 
/* 373 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocalPart(String qname) {
/* 386 */     int index = qname.indexOf(':');
/*     */     
/* 388 */     return (index < 0) ? qname : qname.substring(index + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPrefixPart(String qname) {
/* 401 */     int index = qname.indexOf(':');
/*     */     
/* 403 */     return (index >= 0) ? qname.substring(0, index) : "";
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\QNameHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */