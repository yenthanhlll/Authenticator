package org.apache.xmlbeans.impl.common;

public interface XmlLocale {
  boolean sync();
  
  boolean noSync();
  
  void enter();
  
  void exit();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XmlLocale.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */