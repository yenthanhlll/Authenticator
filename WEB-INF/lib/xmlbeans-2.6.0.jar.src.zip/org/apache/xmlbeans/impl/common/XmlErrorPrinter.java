/*    */ package org.apache.xmlbeans.impl.common;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.util.AbstractCollection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import org.apache.xmlbeans.XmlError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlErrorPrinter
/*    */   extends AbstractCollection
/*    */ {
/*    */   private boolean _noisy;
/*    */   private URI _baseURI;
/*    */   
/*    */   public XmlErrorPrinter(boolean noisy, URI baseURI) {
/* 32 */     this._noisy = noisy;
/* 33 */     this._baseURI = baseURI;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean add(Object o) {
/* 38 */     if (o instanceof XmlError) {
/*    */       
/* 40 */       XmlError err = (XmlError)o;
/* 41 */       if (err.getSeverity() == 0 || err.getSeverity() == 1) {
/*    */         
/* 43 */         System.err.println(err.toString(this._baseURI));
/* 44 */       } else if (this._noisy) {
/* 45 */         System.out.println(err.toString(this._baseURI));
/*    */       } 
/* 47 */     }  return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator iterator() {
/* 52 */     return Collections.EMPTY_LIST.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 57 */     return 0;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XmlErrorPrinter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */