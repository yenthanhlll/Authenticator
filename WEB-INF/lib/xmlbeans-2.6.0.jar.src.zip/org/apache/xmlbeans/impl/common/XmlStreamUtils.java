/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XmlStreamUtils
/*     */ {
/*     */   public static String printEvent(XMLStreamReader xmlr) {
/*     */     int i, start, length;
/*     */     String target, data;
/*  27 */     StringBuffer b = new StringBuffer();
/*  28 */     b.append("EVENT:[" + xmlr.getLocation().getLineNumber() + "][" + xmlr.getLocation().getColumnNumber() + "] ");
/*     */     
/*  30 */     b.append(getName(xmlr.getEventType()));
/*  31 */     b.append(" [");
/*  32 */     switch (xmlr.getEventType()) {
/*     */       case 1:
/*  34 */         b.append("<");
/*  35 */         printName(xmlr, b);
/*  36 */         for (i = 0; i < xmlr.getNamespaceCount(); i++) {
/*  37 */           b.append(" ");
/*  38 */           String n = xmlr.getNamespacePrefix(i);
/*  39 */           if ("xmlns".equals(n)) {
/*  40 */             b.append("xmlns=\"" + xmlr.getNamespaceURI(i) + "\"");
/*     */           } else {
/*  42 */             b.append("xmlns:" + n);
/*  43 */             b.append("=\"");
/*  44 */             b.append(xmlr.getNamespaceURI(i));
/*  45 */             b.append("\"");
/*     */           } 
/*     */         } 
/*     */         
/*  49 */         for (i = 0; i < xmlr.getAttributeCount(); i++) {
/*  50 */           b.append(" ");
/*  51 */           printName(xmlr.getAttributePrefix(i), xmlr.getAttributeNamespace(i), xmlr.getAttributeLocalName(i), b);
/*     */ 
/*     */ 
/*     */           
/*  55 */           b.append("=\"");
/*  56 */           b.append(xmlr.getAttributeValue(i));
/*  57 */           b.append("\"");
/*     */         } 
/*     */         
/*  60 */         b.append(">");
/*     */         break;
/*     */       case 2:
/*  63 */         b.append("</");
/*  64 */         printName(xmlr, b);
/*  65 */         for (i = 0; i < xmlr.getNamespaceCount(); i++) {
/*  66 */           b.append(" ");
/*  67 */           String n = xmlr.getNamespacePrefix(i);
/*  68 */           if ("xmlns".equals(n)) {
/*  69 */             b.append("xmlns=\"" + xmlr.getNamespaceURI(i) + "\"");
/*     */           } else {
/*  71 */             b.append("xmlns:" + n);
/*  72 */             b.append("=\"");
/*  73 */             b.append(xmlr.getNamespaceURI(i));
/*  74 */             b.append("\"");
/*     */           } 
/*     */         } 
/*  77 */         b.append(">");
/*     */         break;
/*     */       
/*     */       case 4:
/*     */       case 6:
/*  82 */         start = xmlr.getTextStart();
/*  83 */         length = xmlr.getTextLength();
/*  84 */         b.append(new String(xmlr.getTextCharacters(), start, length));
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/*  89 */         target = xmlr.getPITarget();
/*  90 */         if (target == null) target = ""; 
/*  91 */         data = xmlr.getPIData();
/*  92 */         if (data == null) data = ""; 
/*  93 */         b.append("<?");
/*  94 */         b.append(target + " " + data);
/*  95 */         b.append("?>");
/*     */         break;
/*     */       case 12:
/*  98 */         b.append("<![CDATA[");
/*  99 */         if (xmlr.hasText())
/* 100 */           b.append(xmlr.getText()); 
/* 101 */         b.append("]]>");
/*     */         break;
/*     */       
/*     */       case 5:
/* 105 */         b.append("<!--");
/* 106 */         if (xmlr.hasText())
/* 107 */           b.append(xmlr.getText()); 
/* 108 */         b.append("-->");
/*     */         break;
/*     */       case 9:
/* 111 */         b.append(xmlr.getLocalName() + "=");
/* 112 */         if (xmlr.hasText())
/* 113 */           b.append("[" + xmlr.getText() + "]"); 
/*     */         break;
/*     */       case 7:
/* 116 */         b.append("<?xml");
/* 117 */         b.append(" version='" + xmlr.getVersion() + "'");
/* 118 */         b.append(" encoding='" + xmlr.getCharacterEncodingScheme() + "'");
/* 119 */         if (xmlr.isStandalone()) {
/* 120 */           b.append(" standalone='yes'");
/*     */         } else {
/* 122 */           b.append(" standalone='no'");
/* 123 */         }  b.append("?>");
/*     */         break;
/*     */     } 
/*     */     
/* 127 */     b.append("]");
/* 128 */     return b.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printName(String prefix, String uri, String localName, StringBuffer b) {
/* 137 */     if (uri != null && !"".equals(uri)) b.append("['" + uri + "']:"); 
/* 138 */     if (prefix != null && !"".equals(prefix)) b.append(prefix + ":"); 
/* 139 */     if (localName != null) b.append(localName);
/*     */   
/*     */   }
/*     */   
/*     */   private static void printName(XMLStreamReader xmlr, StringBuffer b) {
/* 144 */     if (xmlr.hasName()) {
/* 145 */       String prefix = xmlr.getPrefix();
/* 146 */       String uri = xmlr.getNamespaceURI();
/* 147 */       String localName = xmlr.getLocalName();
/* 148 */       printName(prefix, uri, localName, b);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getName(int eventType) {
/* 154 */     switch (eventType) {
/*     */       case 1:
/* 156 */         return "START_ELEMENT";
/*     */       case 2:
/* 158 */         return "END_ELEMENT";
/*     */       case 3:
/* 160 */         return "PROCESSING_INSTRUCTION";
/*     */       case 4:
/* 162 */         return "CHARACTERS";
/*     */       case 6:
/* 164 */         return "SPACE";
/*     */       case 5:
/* 166 */         return "COMMENT";
/*     */       case 7:
/* 168 */         return "START_DOCUMENT";
/*     */       case 8:
/* 170 */         return "END_DOCUMENT";
/*     */       case 9:
/* 172 */         return "ENTITY_REFERENCE";
/*     */       case 10:
/* 174 */         return "ATTRIBUTE";
/*     */       case 11:
/* 176 */         return "DTD";
/*     */       case 12:
/* 178 */         return "CDATA";
/*     */       case 13:
/* 180 */         return "NAMESPACE";
/*     */     } 
/* 182 */     return "UNKNOWN_EVENT_TYPE";
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getType(String val) {
/* 187 */     if (val.equals("START_ELEMENT"))
/* 188 */       return 1; 
/* 189 */     if (val.equals("SPACE"))
/* 190 */       return 6; 
/* 191 */     if (val.equals("END_ELEMENT"))
/* 192 */       return 2; 
/* 193 */     if (val.equals("PROCESSING_INSTRUCTION"))
/* 194 */       return 3; 
/* 195 */     if (val.equals("CHARACTERS"))
/* 196 */       return 4; 
/* 197 */     if (val.equals("COMMENT"))
/* 198 */       return 5; 
/* 199 */     if (val.equals("START_DOCUMENT"))
/* 200 */       return 7; 
/* 201 */     if (val.equals("END_DOCUMENT"))
/* 202 */       return 8; 
/* 203 */     if (val.equals("ATTRIBUTE"))
/* 204 */       return 10; 
/* 205 */     if (val.equals("DTD"))
/* 206 */       return 11; 
/* 207 */     if (val.equals("CDATA"))
/* 208 */       return 12; 
/* 209 */     if (val.equals("NAMESPACE"))
/* 210 */       return 13; 
/* 211 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XmlStreamUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */