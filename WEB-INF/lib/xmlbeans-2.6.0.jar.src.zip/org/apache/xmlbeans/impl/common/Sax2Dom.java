/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sax2Dom
/*     */   extends DefaultHandler
/*     */   implements ContentHandler, LexicalHandler
/*     */ {
/*     */   public static final String EMPTYSTRING = "";
/*     */   public static final String XML_PREFIX = "xml";
/*     */   public static final String XMLNS_PREFIX = "xmlns";
/*     */   public static final String XMLNS_STRING = "xmlns:";
/*     */   public static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*  45 */   private Node _root = null;
/*  46 */   private Document _document = null;
/*  47 */   private Stack _nodeStk = new Stack();
/*  48 */   private Vector _namespaceDecls = null;
/*     */ 
/*     */   
/*     */   public Sax2Dom() throws ParserConfigurationException {
/*  52 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */     
/*  54 */     this._document = factory.newDocumentBuilder().newDocument();
/*  55 */     this._root = this._document;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sax2Dom(Node root) throws ParserConfigurationException {
/*  60 */     this._root = root;
/*  61 */     if (root instanceof Document) {
/*     */       
/*  63 */       this._document = (Document)root;
/*     */     }
/*  65 */     else if (root != null) {
/*     */       
/*  67 */       this._document = root.getOwnerDocument();
/*     */     }
/*     */     else {
/*     */       
/*  71 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */       
/*  73 */       this._document = factory.newDocumentBuilder().newDocument();
/*  74 */       this._root = this._document;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getDOM() {
/*  80 */     return this._root;
/*     */   }
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/*  85 */     Node last = this._nodeStk.peek();
/*     */ 
/*     */     
/*  88 */     if (last != this._document) {
/*     */       
/*  90 */       String text = new String(ch, start, length);
/*  91 */       last.appendChild(this._document.createTextNode(text));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() {
/*  97 */     this._nodeStk.push(this._root);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() {
/* 102 */     this._nodeStk.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String namespace, String localName, String qName, Attributes attrs) {
/* 108 */     Element tmp = this._document.createElementNS(namespace, qName);
/*     */ 
/*     */     
/* 111 */     if (this._namespaceDecls != null) {
/*     */       
/* 113 */       int nDecls = this._namespaceDecls.size();
/* 114 */       for (int j = 0; j < nDecls; j++) {
/*     */         
/* 116 */         String prefix = this._namespaceDecls.elementAt(j++);
/*     */         
/* 118 */         if (prefix == null || prefix.equals("")) {
/*     */           
/* 120 */           tmp.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", this._namespaceDecls.elementAt(j));
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 125 */           tmp.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + prefix, this._namespaceDecls.elementAt(j));
/*     */         } 
/*     */       } 
/*     */       
/* 129 */       this._namespaceDecls.clear();
/*     */     } 
/*     */ 
/*     */     
/* 133 */     int nattrs = attrs.getLength();
/* 134 */     for (int i = 0; i < nattrs; i++) {
/*     */       
/* 136 */       if (attrs.getLocalName(i) == null) {
/*     */         
/* 138 */         tmp.setAttribute(attrs.getQName(i), attrs.getValue(i));
/*     */       }
/*     */       else {
/*     */         
/* 142 */         tmp.setAttributeNS(attrs.getURI(i), attrs.getQName(i), attrs.getValue(i));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 148 */     Node last = this._nodeStk.peek();
/* 149 */     last.appendChild(tmp);
/*     */ 
/*     */     
/* 152 */     this._nodeStk.push(tmp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String namespace, String localName, String qName) {
/* 157 */     this._nodeStk.pop();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) {
/* 162 */     if (this._namespaceDecls == null)
/*     */     {
/* 164 */       this._namespaceDecls = new Vector(2);
/*     */     }
/* 166 */     this._namespaceDecls.addElement(prefix);
/* 167 */     this._namespaceDecls.addElement(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) {
/* 188 */     Node last = this._nodeStk.peek();
/* 189 */     ProcessingInstruction pi = this._document.createProcessingInstruction(target, data);
/*     */     
/* 191 */     if (pi != null) last.appendChild(pi);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skippedEntity(String name) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) {
/* 216 */     Node last = this._nodeStk.peek();
/* 217 */     Comment comment = this._document.createComment(new String(ch, start, length));
/* 218 */     if (comment != null) last.appendChild(comment); 
/*     */   }
/*     */   
/*     */   public void startCDATA() {}
/*     */   
/*     */   public void endCDATA() {}
/*     */   
/*     */   public void startEntity(String name) {}
/*     */   
/*     */   public void endEntity(String name) {}
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {}
/*     */   
/*     */   public void endDTD() {}
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\Sax2Dom.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */