/*    */ package org.apache.xmlbeans.impl.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Levenshtein
/*    */ {
/*    */   private static int minimum(int a, int b, int c) {
/* 26 */     int mi = a;
/* 27 */     if (b < mi)
/* 28 */       mi = b; 
/* 29 */     if (c < mi)
/* 30 */       mi = c; 
/* 31 */     return mi;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int distance(String s, String t) {
/* 49 */     int n = s.length();
/* 50 */     int m = t.length();
/* 51 */     if (n == 0)
/* 52 */       return m; 
/* 53 */     if (m == 0)
/* 54 */       return n; 
/* 55 */     int[][] d = new int[n + 1][m + 1];
/*    */     
/*    */     int i;
/* 58 */     for (i = 0; i <= n; i++)
/* 59 */       d[i][0] = i;  int j;
/* 60 */     for (j = 0; j <= m; j++) {
/* 61 */       d[0][j] = j;
/*    */     }
/*    */     
/* 64 */     for (i = 1; i <= n; i++) {
/*    */       
/* 66 */       char s_i = s.charAt(i - 1);
/*    */ 
/*    */       
/* 69 */       for (j = 1; j <= m; j++) {
/*    */         int cost;
/* 71 */         char t_j = t.charAt(j - 1);
/*    */ 
/*    */         
/* 74 */         if (s_i == t_j) {
/* 75 */           cost = 0;
/*    */         } else {
/* 77 */           cost = 1;
/*    */         } 
/*    */         
/* 80 */         d[i][j] = minimum(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 85 */     return d[n][m];
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\Levenshtein.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */