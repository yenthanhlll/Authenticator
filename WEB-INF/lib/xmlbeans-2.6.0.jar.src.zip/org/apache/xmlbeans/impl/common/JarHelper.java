/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.JarOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarHelper
/*     */ {
/*     */   private static final int BUFFER_SIZE = 2156;
/*  40 */   private byte[] mBuffer = new byte[2156];
/*  41 */   private int mByteCount = 0;
/*     */   private boolean mVerbose = false;
/*  43 */   private String mDestJarName = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char SEP = '/';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void jarDir(File dirOrFile2Jar, File destJar) throws IOException {
/*  62 */     if (dirOrFile2Jar == null || destJar == null) {
/*  63 */       throw new IllegalArgumentException();
/*     */     }
/*  65 */     this.mDestJarName = destJar.getCanonicalPath();
/*  66 */     FileOutputStream fout = new FileOutputStream(destJar);
/*  67 */     JarOutputStream jout = new JarOutputStream(fout);
/*     */     
/*     */     try {
/*  70 */       jarDir(dirOrFile2Jar, jout, null);
/*  71 */     } catch (IOException ioe) {
/*  72 */       throw ioe;
/*     */     } finally {
/*  74 */       jout.close();
/*  75 */       fout.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unjarDir(File jarFile, File destDir) throws IOException {
/*  83 */     BufferedOutputStream dest = null;
/*  84 */     FileInputStream fis = new FileInputStream(jarFile);
/*  85 */     unjar(fis, destDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unjar(InputStream in, File destDir) throws IOException {
/*  93 */     BufferedOutputStream dest = null;
/*  94 */     JarInputStream jis = new JarInputStream(in);
/*     */     JarEntry entry;
/*  96 */     while ((entry = jis.getNextJarEntry()) != null) {
/*  97 */       if (entry.isDirectory()) {
/*  98 */         File dir = new File(destDir, entry.getName());
/*  99 */         dir.mkdir();
/* 100 */         if (entry.getTime() != -1L) dir.setLastModified(entry.getTime());
/*     */         
/*     */         continue;
/*     */       } 
/* 104 */       byte[] data = new byte[2156];
/* 105 */       File destFile = new File(destDir, entry.getName());
/* 106 */       if (this.mVerbose) {
/* 107 */         System.out.println("unjarring " + destFile + " from " + entry.getName());
/*     */       }
/* 109 */       FileOutputStream fos = new FileOutputStream(destFile);
/* 110 */       dest = new BufferedOutputStream(fos, 2156); int count;
/* 111 */       while ((count = jis.read(data, 0, 2156)) != -1) {
/* 112 */         dest.write(data, 0, count);
/*     */       }
/* 114 */       dest.flush();
/* 115 */       dest.close();
/* 116 */       if (entry.getTime() != -1L) destFile.setLastModified(entry.getTime()); 
/*     */     } 
/* 118 */     jis.close();
/*     */   }
/*     */   
/*     */   public void setVerbose(boolean b) {
/* 122 */     this.mVerbose = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void jarDir(File dirOrFile2jar, JarOutputStream jos, String path) throws IOException {
/* 134 */     if (this.mVerbose) System.out.println("checking " + dirOrFile2jar); 
/* 135 */     if (dirOrFile2jar.isDirectory()) {
/* 136 */       String[] dirList = dirOrFile2jar.list();
/* 137 */       String subPath = (path == null) ? "" : (path + dirOrFile2jar.getName() + '/');
/* 138 */       if (path != null) {
/* 139 */         JarEntry je = new JarEntry(subPath);
/* 140 */         je.setTime(dirOrFile2jar.lastModified());
/* 141 */         jos.putNextEntry(je);
/* 142 */         jos.flush();
/* 143 */         jos.closeEntry();
/*     */       } 
/* 145 */       for (int i = 0; i < dirList.length; i++) {
/* 146 */         File f = new File(dirOrFile2jar, dirList[i]);
/* 147 */         jarDir(f, jos, subPath);
/*     */       } 
/*     */     } else {
/* 150 */       if (dirOrFile2jar.getCanonicalPath().equals(this.mDestJarName)) {
/*     */         
/* 152 */         if (this.mVerbose) System.out.println("skipping " + dirOrFile2jar.getPath());
/*     */         
/*     */         return;
/*     */       } 
/* 156 */       if (this.mVerbose) System.out.println("adding " + dirOrFile2jar.getPath()); 
/* 157 */       FileInputStream fis = new FileInputStream(dirOrFile2jar);
/*     */       try {
/* 159 */         JarEntry entry = new JarEntry(path + dirOrFile2jar.getName());
/* 160 */         entry.setTime(dirOrFile2jar.lastModified());
/* 161 */         jos.putNextEntry(entry);
/* 162 */         while ((this.mByteCount = fis.read(this.mBuffer)) != -1) {
/* 163 */           jos.write(this.mBuffer, 0, this.mByteCount);
/* 164 */           if (this.mVerbose) System.out.println("wrote " + this.mByteCount + " bytes"); 
/*     */         } 
/* 166 */         jos.flush();
/* 167 */         jos.closeEntry();
/* 168 */       } catch (IOException ioe) {
/* 169 */         throw ioe;
/*     */       } finally {
/* 171 */         fis.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/* 180 */     if (args.length < 2) {
/*     */       
/* 182 */       System.err.println("Usage: JarHelper jarname.jar directory");
/*     */       
/*     */       return;
/*     */     } 
/* 186 */     JarHelper jarHelper = new JarHelper();
/* 187 */     jarHelper.mVerbose = true;
/*     */     
/* 189 */     File destJar = new File(args[0]);
/* 190 */     File dirOrFile2Jar = new File(args[1]);
/*     */     
/* 192 */     jarHelper.jarDir(dirOrFile2Jar, destJar);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\JarHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */