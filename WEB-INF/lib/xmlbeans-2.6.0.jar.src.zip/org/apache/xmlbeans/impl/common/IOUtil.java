/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.net.URI;
/*     */ import java.nio.channels.FileChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOUtil
/*     */ {
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public static void copyCompletely(InputStream input, OutputStream output) throws IOException {
/*  37 */     if (output instanceof FileOutputStream && input instanceof FileInputStream) {
/*     */       
/*     */       try {
/*     */         
/*  41 */         FileChannel target = ((FileOutputStream)output).getChannel();
/*  42 */         FileChannel source = ((FileInputStream)input).getChannel();
/*     */         
/*  44 */         source.transferTo(0L, 2147483647L, target);
/*     */         
/*  46 */         source.close();
/*  47 */         target.close();
/*     */ 
/*     */         
/*     */         return;
/*  51 */       } catch (Exception e) {}
/*     */     }
/*     */ 
/*     */     
/*  55 */     byte[] buf = new byte[8192];
/*     */     
/*     */     while (true) {
/*  58 */       int length = input.read(buf);
/*  59 */       if (length < 0)
/*     */         break; 
/*  61 */       output.write(buf, 0, length);
/*     */     } 
/*     */     
/*  64 */     try { input.close(); } catch (IOException ignore) {} 
/*  65 */     try { output.close(); } catch (IOException ignore) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyCompletely(Reader input, Writer output) throws IOException {
/*  71 */     char[] buf = new char[8192];
/*     */     
/*     */     while (true) {
/*  74 */       int length = input.read(buf);
/*  75 */       if (length < 0)
/*     */         break; 
/*  77 */       output.write(buf, 0, length);
/*     */     } 
/*     */     
/*  80 */     try { input.close(); } catch (IOException ignore) {} 
/*  81 */     try { output.close(); } catch (IOException ignore) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyCompletely(URI input, URI output) throws IOException {
/*     */     try {
/*  89 */       InputStream in = null;
/*     */       
/*     */       try {
/*  92 */         File f = new File(input);
/*  93 */         if (f.exists()) {
/*  94 */           in = new FileInputStream(f);
/*     */         }
/*  96 */       } catch (Exception notAFile) {}
/*     */ 
/*     */       
/*  99 */       File out = new File(output);
/* 100 */       File dir = out.getParentFile();
/* 101 */       dir.mkdirs();
/*     */       
/* 103 */       if (in == null) {
/* 104 */         in = input.toURL().openStream();
/*     */       }
/* 106 */       copyCompletely(in, new FileOutputStream(out));
/*     */     }
/* 108 */     catch (IllegalArgumentException e) {
/*     */       
/* 110 */       throw new IOException("Cannot copy to " + output);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static File createDir(File rootdir, String subdir) {
/* 116 */     File newdir = (subdir == null) ? rootdir : new File(rootdir, subdir);
/* 117 */     boolean created = ((newdir.exists() && newdir.isDirectory()) || newdir.mkdirs());
/* 118 */     assert created : "Could not create " + newdir.getAbsolutePath();
/* 119 */     return newdir;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\IOUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */