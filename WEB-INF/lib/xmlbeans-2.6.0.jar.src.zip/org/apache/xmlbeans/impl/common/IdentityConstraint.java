/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlError;
/*     */ import org.apache.xmlbeans.XmlID;
/*     */ import org.apache.xmlbeans.XmlIDREF;
/*     */ import org.apache.xmlbeans.XmlIDREFS;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentityConstraint
/*     */ {
/*     */   private ConstraintState _constraintStack;
/*     */   private ElementState _elementStack;
/*     */   private Collection _errorListener;
/*     */   private boolean _invalid;
/*     */   private boolean _trackIdrefs;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public IdentityConstraint(Collection errorListener, boolean trackIdrefs) {
/*  38 */     this._errorListener = errorListener;
/*  39 */     this._trackIdrefs = trackIdrefs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void element(ValidatorListener.Event e, SchemaType st, SchemaIdentityConstraint[] ics) {
/*  45 */     newState();
/*     */ 
/*     */     
/*  48 */     for (ConstraintState cs = this._constraintStack; cs != null; cs = cs._next) {
/*  49 */       cs.element(e, st);
/*     */     }
/*     */ 
/*     */     
/*  53 */     for (int i = 0; ics != null && i < ics.length; i++) {
/*  54 */       newConstraintState(ics[i], e, st);
/*     */     }
/*     */   }
/*     */   
/*     */   public void endElement(ValidatorListener.Event e) {
/*  59 */     if (this._elementStack._hasConstraints) {
/*     */       
/*  61 */       for (ConstraintState constraintState = this._constraintStack; constraintState != null && constraintState != this._elementStack._savePoint; constraintState = constraintState._next) {
/*  62 */         constraintState.remove(e);
/*     */       }
/*  64 */       this._constraintStack = this._elementStack._savePoint;
/*     */     } 
/*     */     
/*  67 */     this._elementStack = this._elementStack._next;
/*     */ 
/*     */     
/*  70 */     for (ConstraintState cs = this._constraintStack; cs != null; cs = cs._next) {
/*  71 */       cs.endElement(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void attr(ValidatorListener.Event e, QName name, SchemaType st, String value) {
/*  76 */     for (ConstraintState cs = this._constraintStack; cs != null; cs = cs._next)
/*  77 */       cs.attr(e, name, st, value); 
/*     */   }
/*     */   
/*     */   public void text(ValidatorListener.Event e, SchemaType st, String value, boolean emptyContent) {
/*  81 */     for (ConstraintState cs = this._constraintStack; cs != null; cs = cs._next)
/*  82 */       cs.text(e, st, value, emptyContent); 
/*     */   }
/*     */   
/*     */   public boolean isValid() {
/*  86 */     return !this._invalid;
/*     */   }
/*     */ 
/*     */   
/*     */   private void newConstraintState(SchemaIdentityConstraint ic, ValidatorListener.Event e, SchemaType st) {
/*  91 */     if (ic.getConstraintCategory() == 2) {
/*  92 */       new KeyrefState(ic, e, st);
/*     */     } else {
/*  94 */       new SelectorState(ic, e, st);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildIdStates() {
/* 100 */     IdState ids = new IdState();
/* 101 */     if (this._trackIdrefs)
/* 102 */       new IdRefState(ids); 
/*     */   }
/*     */   
/*     */   private void newState() {
/* 106 */     boolean firstTime = (this._elementStack == null);
/*     */     
/* 108 */     ElementState st = new ElementState();
/* 109 */     st._next = this._elementStack;
/* 110 */     this._elementStack = st;
/*     */     
/* 112 */     if (firstTime) {
/* 113 */       buildIdStates();
/*     */     }
/*     */   }
/*     */   
/*     */   private void emitError(ValidatorListener.Event event, String code, Object[] args) {
/* 118 */     this._invalid = true;
/*     */     
/* 120 */     if (this._errorListener != null) {
/*     */       
/* 122 */       assert event != null;
/*     */       
/* 124 */       this._errorListener.add(errorForEvent(code, args, 0, event));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static XmlError errorForEvent(String code, Object[] args, int severity, ValidatorListener.Event event) {
/*     */     XmlError error;
/* 130 */     XmlCursor loc = event.getLocationAsCursor();
/*     */     
/* 132 */     if (loc != null) {
/* 133 */       error = XmlError.forCursor(code, args, severity, loc);
/*     */     } else {
/*     */       
/* 136 */       Location location = event.getLocation();
/* 137 */       if (location != null) {
/*     */         
/* 139 */         error = XmlError.forLocation(code, args, severity, location.getSystemId(), location.getLineNumber(), location.getColumnNumber(), location.getCharacterOffset());
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 145 */         error = XmlError.forMessage(code, args, severity);
/*     */       } 
/*     */     } 
/* 148 */     return error;
/*     */   }
/*     */ 
/*     */   
/*     */   private void emitError(ValidatorListener.Event event, String msg) {
/* 153 */     this._invalid = true;
/*     */     
/* 155 */     if (this._errorListener != null) {
/*     */       
/* 157 */       assert event != null;
/*     */       
/* 159 */       this._errorListener.add(errorForEvent(msg, 0, event));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static XmlError errorForEvent(String msg, int severity, ValidatorListener.Event event) {
/*     */     XmlError error;
/* 165 */     XmlCursor loc = event.getLocationAsCursor();
/*     */     
/* 167 */     if (loc != null) {
/* 168 */       error = XmlError.forCursor(msg, severity, loc);
/*     */     } else {
/*     */       
/* 171 */       Location location = event.getLocation();
/* 172 */       if (location != null) {
/*     */         
/* 174 */         error = XmlError.forLocation(msg, severity, location.getSystemId(), location.getLineNumber(), location.getColumnNumber(), location.getCharacterOffset());
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 180 */         error = XmlError.forMessage(msg, severity);
/*     */       } 
/*     */     } 
/* 183 */     return error;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setSavePoint(ConstraintState cs) {
/* 188 */     if (!this._elementStack._hasConstraints) {
/* 189 */       this._elementStack._savePoint = cs;
/*     */     }
/* 191 */     this._elementStack._hasConstraints = true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static XmlObject newValue(SchemaType st, String value) {
/*     */     try {
/* 197 */       return (XmlObject)st.newValue(value);
/*     */     }
/* 199 */     catch (IllegalArgumentException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SchemaType getSimpleType(SchemaType st) {
/* 217 */     assert st.isSimpleType() || st.getContentType() == 2 : st + " does not have simple content.";
/*     */     
/* 219 */     while (!st.isSimpleType()) {
/* 220 */       st = st.getBaseType();
/*     */     }
/* 222 */     return st;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean hasSimpleContent(SchemaType st) {
/* 227 */     return (st.isSimpleType() || st.getContentType() == 2);
/*     */   }
/*     */   
/*     */   public abstract class ConstraintState {
/*     */     ConstraintState _next;
/*     */     private final IdentityConstraint this$0;
/*     */     
/*     */     ConstraintState() {
/* 235 */       IdentityConstraint.this.setSavePoint(IdentityConstraint.this._constraintStack);
/* 236 */       this._next = IdentityConstraint.this._constraintStack;
/* 237 */       IdentityConstraint.this._constraintStack = this;
/*     */     }
/*     */     
/*     */     abstract void element(ValidatorListener.Event param1Event, SchemaType param1SchemaType);
/*     */     
/*     */     abstract void endElement(ValidatorListener.Event param1Event);
/*     */     
/*     */     abstract void attr(ValidatorListener.Event param1Event, QName param1QName, SchemaType param1SchemaType, String param1String);
/*     */     
/*     */     abstract void text(ValidatorListener.Event param1Event, SchemaType param1SchemaType, String param1String, boolean param1Boolean);
/*     */     
/*     */     abstract void remove(ValidatorListener.Event param1Event); }
/*     */   
/* 250 */   public class SelectorState extends ConstraintState { Set _values = new LinkedHashSet(); SchemaIdentityConstraint _constraint; XPath.ExecutionContext _context;
/*     */     private final IdentityConstraint this$0;
/*     */     
/*     */     SelectorState(SchemaIdentityConstraint constraint, ValidatorListener.Event e, SchemaType st) {
/* 254 */       this._constraint = constraint;
/* 255 */       this._context = new XPath.ExecutionContext();
/* 256 */       this._context.init((XPath)this._constraint.getSelectorPath());
/*     */       
/* 258 */       if ((this._context.start() & 0x1) != 0) {
/* 259 */         createFieldState(e, st);
/*     */       }
/*     */     }
/*     */     
/*     */     void addFields(XmlObjectList fields, ValidatorListener.Event e) {
/* 264 */       if (this._constraint.getConstraintCategory() == 2) {
/* 265 */         this._values.add(fields);
/* 266 */       } else if (this._values.contains(fields)) {
/*     */         
/* 268 */         if (this._constraint.getConstraintCategory() == 3) {
/* 269 */           IdentityConstraint.this.emitError(e, "cvc-identity-constraint.4.1", new Object[] { fields, QNameHelper.pretty(this._constraint.getName()) });
/*     */         } else {
/*     */           
/* 272 */           IdentityConstraint.this.emitError(e, "cvc-identity-constraint.4.2.2", new Object[] { fields, QNameHelper.pretty(this._constraint.getName()) });
/*     */         } 
/*     */       } else {
/*     */         
/* 276 */         this._values.add(fields);
/*     */       } 
/*     */     }
/*     */     
/*     */     void element(ValidatorListener.Event e, SchemaType st) {
/* 281 */       if ((this._context.element(e.getName()) & 0x1) != 0) {
/* 282 */         createFieldState(e, st);
/*     */       }
/*     */     }
/*     */     
/*     */     void endElement(ValidatorListener.Event e) {
/* 287 */       this._context.end();
/*     */     }
/*     */     
/*     */     void createFieldState(ValidatorListener.Event e, SchemaType st) {
/* 291 */       new IdentityConstraint.FieldState(this, e, st);
/*     */     }
/*     */ 
/*     */     
/*     */     void remove(ValidatorListener.Event e) {
/* 296 */       for (IdentityConstraint.ConstraintState cs = this._next; cs != null; cs = cs._next) {
/*     */         
/* 298 */         if (cs instanceof IdentityConstraint.KeyrefState) {
/*     */           
/* 300 */           IdentityConstraint.KeyrefState kr = (IdentityConstraint.KeyrefState)cs;
/* 301 */           if (kr._constraint.getReferencedKey() == this._constraint)
/* 302 */             kr.addKeyValues(this._values, true); 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void attr(ValidatorListener.Event e, QName name, SchemaType st, String value) {}
/*     */     
/*     */     void text(ValidatorListener.Event e, SchemaType st, String value, boolean emptyContent) {} }
/*     */   
/*     */   public class KeyrefState extends SelectorState {
/* 312 */     Map _keyValues = new HashMap();
/* 313 */     private Object CHILD_ADDED = new Object();
/* 314 */     private Object CHILD_REMOVED = new Object();
/* 315 */     private Object SELF_ADDED = new Object(); private final IdentityConstraint this$0;
/*     */     
/*     */     KeyrefState(SchemaIdentityConstraint constraint, ValidatorListener.Event e, SchemaType st) {
/* 318 */       super(constraint, e, st);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void addKeyValues(Set values, boolean child) {
/* 327 */       for (Iterator it = values.iterator(); it.hasNext(); ) {
/*     */         
/* 329 */         Object key = it.next();
/* 330 */         Object value = this._keyValues.get(key);
/* 331 */         if (value == null) {
/* 332 */           this._keyValues.put(key, child ? this.CHILD_ADDED : this.SELF_ADDED); continue;
/* 333 */         }  if (value == this.CHILD_ADDED) {
/*     */           
/* 335 */           if (child) {
/* 336 */             this._keyValues.put(key, this.CHILD_REMOVED); continue;
/*     */           } 
/* 338 */           this._keyValues.put(key, this.SELF_ADDED); continue;
/*     */         } 
/* 340 */         if (value == this.CHILD_REMOVED)
/*     */         {
/* 342 */           if (!child) {
/* 343 */             this._keyValues.put(key, this.SELF_ADDED);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean hasKeyValue(Object key) {
/* 350 */       Object value = this._keyValues.get(key);
/* 351 */       return (value != null && value != this.CHILD_REMOVED);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void remove(ValidatorListener.Event e) {
/* 357 */       for (IdentityConstraint.ConstraintState cs = this._next; cs != null && cs != IdentityConstraint.this._elementStack._savePoint; cs = cs._next) {
/*     */         
/* 359 */         if (cs instanceof IdentityConstraint.SelectorState) {
/*     */           
/* 361 */           IdentityConstraint.SelectorState sel = (IdentityConstraint.SelectorState)cs;
/* 362 */           if (sel._constraint == this._constraint.getReferencedKey()) {
/* 363 */             addKeyValues(sel._values, false);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 369 */       for (Iterator it = this._values.iterator(); it.hasNext(); ) {
/*     */ 
/*     */         
/* 372 */         XmlObjectList fields = it.next();
/* 373 */         if (fields.unfilled() < 0 && !hasKeyValue(fields)) {
/*     */ 
/*     */           
/* 376 */           IdentityConstraint.this.emitError(e, "cvc-identity-constraint.4.3", new Object[] { fields, QNameHelper.pretty(this._constraint.getName()) });
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class FieldState
/*     */     extends ConstraintState
/*     */   {
/*     */     IdentityConstraint.SelectorState _selector;
/*     */     XPath.ExecutionContext[] _contexts;
/*     */     boolean[] _needsValue;
/*     */     XmlObjectList _value;
/*     */     private final IdentityConstraint this$0;
/*     */     
/*     */     FieldState(IdentityConstraint.SelectorState selector, ValidatorListener.Event e, SchemaType st) {
/* 394 */       this._selector = selector;
/* 395 */       SchemaIdentityConstraint ic = selector._constraint;
/*     */       
/* 397 */       int fieldCount = (ic.getFields()).length;
/* 398 */       this._contexts = new XPath.ExecutionContext[fieldCount];
/* 399 */       this._needsValue = new boolean[fieldCount];
/* 400 */       this._value = new XmlObjectList(fieldCount);
/*     */       
/* 402 */       for (int i = 0; i < fieldCount; i++) {
/*     */         
/* 404 */         this._contexts[i] = new XPath.ExecutionContext();
/* 405 */         this._contexts[i].init((XPath)ic.getFieldPath(i));
/* 406 */         if ((this._contexts[i].start() & 0x1) != 0)
/*     */         {
/*     */ 
/*     */           
/* 410 */           if (!IdentityConstraint.hasSimpleContent(st)) {
/*     */             
/* 412 */             IdentityConstraint.this.emitError(e, "Identity constraint field must have simple content");
/*     */           } else {
/* 414 */             this._needsValue[i] = true;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void element(ValidatorListener.Event e, SchemaType st) {
/*     */       int i;
/* 422 */       for (i = 0; i < this._contexts.length; i++) {
/* 423 */         if (this._needsValue[i]) {
/*     */ 
/*     */           
/* 426 */           IdentityConstraint.this.emitError(e, "Identity constraint field must have simple content");
/* 427 */           this._needsValue[i] = false;
/*     */         } 
/*     */       } 
/*     */       
/* 431 */       for (i = 0; i < this._contexts.length; i++) {
/* 432 */         if ((this._contexts[i].element(e.getName()) & 0x1) != 0)
/*     */         {
/* 434 */           if (!IdentityConstraint.hasSimpleContent(st)) {
/*     */             
/* 436 */             IdentityConstraint.this.emitError(e, "Identity constraint field must have simple content");
/*     */           } else {
/* 438 */             this._needsValue[i] = true;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void attr(ValidatorListener.Event e, QName name, SchemaType st, String value) {
/* 446 */       if (value == null)
/*     */         return; 
/* 448 */       for (int i = 0; i < this._contexts.length; i++) {
/* 449 */         if (this._contexts[i].attr(name)) {
/* 450 */           XmlObject o = IdentityConstraint.newValue(st, value);
/*     */ 
/*     */           
/* 453 */           if (o == null)
/*     */             return; 
/* 455 */           boolean set = this._value.set(o, i);
/*     */ 
/*     */           
/* 458 */           if (!set) {
/* 459 */             IdentityConstraint.this.emitError(e, "Multiple instances of field with xpath: '" + this._selector._constraint.getFields()[i] + "' for a selector");
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void text(ValidatorListener.Event e, SchemaType st, String value, boolean emptyContent) {
/* 470 */       if (value == null && !emptyContent)
/*     */         return; 
/* 472 */       for (int i = 0; i < this._contexts.length; i++) {
/* 473 */         if (this._needsValue[i]) {
/*     */           
/* 475 */           if (emptyContent || !IdentityConstraint.hasSimpleContent(st)) {
/*     */ 
/*     */             
/* 478 */             IdentityConstraint.this.emitError(e, "Identity constraint field must have simple content");
/*     */             
/*     */             return;
/*     */           } 
/* 482 */           SchemaType simpleType = IdentityConstraint.getSimpleType(st);
/* 483 */           XmlObject o = IdentityConstraint.newValue(simpleType, value);
/*     */ 
/*     */           
/* 486 */           if (o == null)
/*     */             return; 
/* 488 */           boolean set = this._value.set(o, i);
/*     */ 
/*     */           
/* 491 */           if (!set) {
/* 492 */             IdentityConstraint.this.emitError(e, "Multiple instances of field with xpath: '" + this._selector._constraint.getFields()[i] + "' for a selector");
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void endElement(ValidatorListener.Event e) {
/* 502 */       for (int i = 0; i < this._needsValue.length; i++) {
/*     */         
/* 504 */         this._contexts[i].end();
/* 505 */         this._needsValue[i] = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void remove(ValidatorListener.Event e) {
/* 513 */       if (this._selector._constraint.getConstraintCategory() == 1 && this._value.unfilled() >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 518 */         IdentityConstraint.this.emitError(e, "Key " + QNameHelper.pretty(this._selector._constraint.getName()) + " is missing field with xpath: '" + this._selector._constraint.getFields()[this._value.unfilled()] + "'");
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 523 */         this._selector.addFields(this._value, e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public class IdState
/*     */     extends ConstraintState
/*     */   {
/* 531 */     Set _values = new LinkedHashSet();
/*     */     
/*     */     private final IdentityConstraint this$0;
/*     */ 
/*     */     
/*     */     void attr(ValidatorListener.Event e, QName name, SchemaType st, String value) {
/* 537 */       handleValue(e, st, value);
/*     */     }
/*     */ 
/*     */     
/*     */     void text(ValidatorListener.Event e, SchemaType st, String value, boolean emptyContent) {
/* 542 */       if (emptyContent) {
/*     */         return;
/*     */       }
/* 545 */       handleValue(e, st, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void handleValue(ValidatorListener.Event e, SchemaType st, String value) {
/* 552 */       if (value == null)
/*     */         return; 
/* 554 */       if (st == null || st.isNoType()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 560 */       if (XmlID.type.isAssignableFrom(st)) {
/*     */         
/* 562 */         XmlObjectList xmlValue = new XmlObjectList(1);
/* 563 */         XmlObject o = IdentityConstraint.newValue(XmlID.type, value);
/*     */ 
/*     */         
/* 566 */         if (o == null)
/*     */           return; 
/* 568 */         xmlValue.set(o, 0);
/*     */         
/* 570 */         if (this._values.contains(xmlValue)) {
/* 571 */           IdentityConstraint.this.emitError(e, "cvc-id.2", new Object[] { value });
/*     */         } else {
/* 573 */           this._values.add(xmlValue);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     void element(ValidatorListener.Event e, SchemaType st) {}
/*     */     
/*     */     void endElement(ValidatorListener.Event e) {}
/*     */     
/*     */     void remove(ValidatorListener.Event e) {} }
/*     */   
/*     */   public class IdRefState extends ConstraintState {
/*     */     IdentityConstraint.IdState _ids;
/*     */     List _values;
/*     */     private final IdentityConstraint this$0;
/*     */     
/*     */     IdRefState(IdentityConstraint.IdState ids) {
/* 590 */       this._ids = ids;
/* 591 */       this._values = new ArrayList();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void handleValue(ValidatorListener.Event e, SchemaType st, String value) {
/* 597 */       if (value == null)
/*     */         return; 
/* 599 */       if (st == null || st.isNoType()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 604 */       if (XmlIDREFS.type.isAssignableFrom(st)) {
/*     */         
/* 606 */         XmlIDREFS lv = (XmlIDREFS)IdentityConstraint.newValue(XmlIDREFS.type, value);
/*     */ 
/*     */         
/* 609 */         if (lv == null)
/*     */           return; 
/* 611 */         List l = lv.xgetListValue();
/*     */ 
/*     */         
/* 614 */         for (int i = 0; i < l.size(); i++)
/*     */         {
/* 616 */           XmlObjectList xmlValue = new XmlObjectList(1);
/* 617 */           XmlIDREF idref = l.get(i);
/* 618 */           xmlValue.set((XmlObject)idref, 0);
/* 619 */           this._values.add(xmlValue);
/*     */         }
/*     */       
/* 622 */       } else if (XmlIDREF.type.isAssignableFrom(st)) {
/*     */         
/* 624 */         XmlObjectList xmlValue = new XmlObjectList(1);
/* 625 */         XmlIDREF idref = (XmlIDREF)st.newValue(value);
/*     */ 
/*     */         
/* 628 */         if (idref == null)
/*     */           return; 
/* 630 */         xmlValue.set((XmlObject)idref, 0);
/* 631 */         this._values.add(xmlValue);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void attr(ValidatorListener.Event e, QName name, SchemaType st, String value) {
/* 637 */       handleValue(e, st, value);
/*     */     }
/*     */     
/*     */     void text(ValidatorListener.Event e, SchemaType st, String value, boolean emptyContent) {
/* 641 */       if (emptyContent) {
/*     */         return;
/*     */       }
/* 644 */       handleValue(e, st, value);
/*     */     }
/*     */ 
/*     */     
/*     */     void remove(ValidatorListener.Event e) {
/* 649 */       for (Iterator it = this._values.iterator(); it.hasNext(); ) {
/*     */         
/* 651 */         Object o = it.next();
/* 652 */         if (!this._ids._values.contains(o))
/*     */         {
/*     */           
/* 655 */           IdentityConstraint.this.emitError(e, "ID not found for IDRef value '" + o + "'");
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     void element(ValidatorListener.Event e, SchemaType st) {}
/*     */     
/*     */     void endElement(ValidatorListener.Event e) {}
/*     */   }
/*     */   
/*     */   private static class ElementState {
/*     */     ElementState _next;
/*     */     boolean _hasConstraints;
/*     */     IdentityConstraint.ConstraintState _savePoint;
/*     */     
/*     */     private ElementState() {}
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\IdentityConstraint.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */