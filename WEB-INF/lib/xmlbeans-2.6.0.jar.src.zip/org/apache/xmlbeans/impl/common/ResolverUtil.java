/*    */ package org.apache.xmlbeans.impl.common;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.xmlbeans.SystemProperties;
/*    */ import org.xml.sax.EntityResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverUtil
/*    */ {
/* 30 */   private static EntityResolver _entityResolver = null;
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     try {
/* 36 */       String erClassName = SystemProperties.getProperty("xmlbean.entityResolver");
/* 37 */       if (erClassName != null) {
/* 38 */         Object o = Class.forName(erClassName).newInstance();
/* 39 */         _entityResolver = (EntityResolver)o;
/*    */       }
/*    */     
/* 42 */     } catch (Exception e) {
/*    */       
/* 44 */       _entityResolver = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static EntityResolver getGlobalEntityResolver() {
/* 50 */     return _entityResolver;
/*    */   }
/*    */ 
/*    */   
/*    */   public static EntityResolver resolverForCatalog(String catalogFile) {
/* 55 */     if (catalogFile == null) {
/* 56 */       return null;
/*    */     }
/*    */     
/*    */     try {
/* 60 */       Class cmClass = Class.forName("org.apache.xml.resolver.CatalogManager");
/* 61 */       Constructor cstrCm = cmClass.getConstructor(new Class[0]);
/* 62 */       Object cmObj = cstrCm.newInstance(new Object[0]);
/* 63 */       Method cmMethod = cmClass.getMethod("setCatalogFiles", new Class[] { String.class });
/* 64 */       cmMethod.invoke(cmObj, (Object[])new String[] { catalogFile });
/*    */       
/* 66 */       Class crClass = Class.forName("org.apache.xml.resolver.tools.CatalogResolver");
/* 67 */       Constructor cstrCr = crClass.getConstructor(new Class[] { cmClass });
/* 68 */       Object crObj = cstrCr.newInstance(new Object[] { cmObj });
/*    */       
/* 70 */       return (EntityResolver)crObj;
/*    */     }
/* 72 */     catch (Exception e) {
/*    */       
/* 74 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\ResolverUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */