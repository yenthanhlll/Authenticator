/*      */ package org.apache.xmlbeans.impl.validator;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.GDate;
/*      */ import org.apache.xmlbeans.GDateSpecification;
/*      */ import org.apache.xmlbeans.GDuration;
/*      */ import org.apache.xmlbeans.GDurationSpecification;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.SchemaAttributeModel;
/*      */ import org.apache.xmlbeans.SchemaField;
/*      */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*      */ import org.apache.xmlbeans.SchemaLocalElement;
/*      */ import org.apache.xmlbeans.SchemaParticle;
/*      */ import org.apache.xmlbeans.SchemaProperty;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeLoader;
/*      */ import org.apache.xmlbeans.SimpleValue;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.XmlQName;
/*      */ import org.apache.xmlbeans.XmlString;
/*      */ import org.apache.xmlbeans.XmlValidationError;
/*      */ import org.apache.xmlbeans.impl.common.IdentityConstraint;
/*      */ import org.apache.xmlbeans.impl.common.InvalidLexicalValueException;
/*      */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*      */ import org.apache.xmlbeans.impl.common.ValidatorListener;
/*      */ import org.apache.xmlbeans.impl.common.XmlWhitespace;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeImpl;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeVisitorImpl;
/*      */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*      */ import org.apache.xmlbeans.impl.values.JavaBase64HolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaBooleanHolder;
/*      */ import org.apache.xmlbeans.impl.values.JavaBooleanHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaDecimalHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaDoubleHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaFloatHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaHexBinaryHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaNotationHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaQNameHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.JavaUriHolderEx;
/*      */ import org.apache.xmlbeans.impl.values.NamespaceContext;
/*      */ import org.apache.xmlbeans.impl.values.XmlDateImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlDurationImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlListImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlQNameImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlValueOutOfRangeException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Validator
/*      */   implements ValidatorListener
/*      */ {
/*      */   private LinkedList _visitorPool;
/*      */   private boolean _invalid;
/*      */   private SchemaType _rootType;
/*      */   private SchemaField _rootField;
/*      */   private SchemaTypeLoader _globalTypes;
/*      */   private State _stateStack;
/*      */   private int _errorState;
/*      */   private Collection _errorListener;
/*      */   private boolean _treatLaxAsSkip;
/*      */   private boolean _strict;
/*      */   private ValidatorVC _vc;
/*      */   private int _suspendErrors;
/*      */   private IdentityConstraint _constraintEngine;
/*      */   private int _eatContent;
/*      */   private SchemaLocalElement _localElement;
/*      */   private SchemaParticle _wildcardElement;
/*      */   private SchemaLocalAttribute _localAttribute;
/*      */   private SchemaAttributeModel _wildcardAttribute;
/*      */   private SchemaType _unionType;
/*      */   private String _stringValue;
/*      */   private BigDecimal _decimalValue;
/*      */   private boolean _booleanValue;
/*      */   private float _floatValue;
/*      */   private double _doubleValue;
/*      */   private QName _qnameValue;
/*      */   private GDate _gdateValue;
/*      */   private GDuration _gdurationValue;
/*      */   private byte[] _byteArrayValue;
/*      */   private List _listValue;
/*      */   private List _listTypes;
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   private class ValidatorVC
/*      */     implements ValidationContext
/*      */   {
/*      */     ValidatorListener.Event _event;
/*      */     private final Validator this$0;
/*      */     
/*      */     private ValidatorVC() {}
/*      */     
/*      */     public void invalid(String message) {
/*      */       Validator.this.emitError(this._event, message, null, null, null, 1001, null);
/*      */     }
/*      */     
/*      */     public void invalid(String code, Object[] args) {
/*      */       Validator.this.emitError(this._event, code, args, null, null, null, 1001, null);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isValid() {
/*      */     return (!this._invalid && this._constraintEngine.isValid());
/*      */   }
/*      */   
/*      */   private void emitError(ValidatorListener.Event event, String message, QName offendingQName, SchemaType expectedSchemaType, List expectedQNames, int errorType, SchemaType badSchemaType) {
/*      */     emitError(event, message, null, null, 0, null, offendingQName, expectedSchemaType, expectedQNames, errorType, badSchemaType);
/*      */   }
/*      */   
/*      */   private void emitError(ValidatorListener.Event event, String code, Object[] args, QName offendingQName, SchemaType expectedSchemaType, List expectedQNames, int errorType, SchemaType badSchemaType) {
/*      */     emitError(event, null, code, args, 0, null, offendingQName, expectedSchemaType, expectedQNames, errorType, badSchemaType);
/*      */   }
/*      */   
/*      */   private void emitError(ValidatorListener.Event event, String message, String code, Object[] args, int severity, QName fieldName, QName offendingQName, SchemaType expectedSchemaType, List expectedQNames, int errorType, SchemaType badSchemaType) {
/*      */     this._errorState++;
/*      */     if (this._suspendErrors == 0) {
/*      */       if (severity == 0)
/*      */         this._invalid = true; 
/*      */       if (this._errorListener != null) {
/*      */         XmlValidationError xmlValidationError;
/*      */         assert event != null;
/*      */         XmlCursor curs = event.getLocationAsCursor();
/*      */         if (curs != null) {
/*      */           xmlValidationError = XmlValidationError.forCursorWithDetails(message, code, args, severity, curs, fieldName, offendingQName, expectedSchemaType, expectedQNames, errorType, badSchemaType);
/*      */         } else {
/*      */           xmlValidationError = XmlValidationError.forLocationWithDetails(message, code, args, severity, event.getLocation(), fieldName, offendingQName, expectedSchemaType, expectedQNames, errorType, badSchemaType);
/*      */         } 
/*      */         this._errorListener.add(xmlValidationError);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void emitFieldError(ValidatorListener.Event event, String code, Object[] args, QName offendingQName, SchemaType expectedSchemaType, List expectedQNames, int errorType, SchemaType badSchemaType) {
/*      */     emitFieldError(event, null, code, args, 0, offendingQName, expectedSchemaType, expectedQNames, errorType, badSchemaType);
/*      */   }
/*      */   
/*      */   private void emitFieldError(ValidatorListener.Event event, String message, String code, Object[] args, int severity, QName offendingQName, SchemaType expectedSchemaType, List expectedQNames, int errorType, SchemaType badSchemaType) {
/*      */     QName fieldName = null;
/*      */     if (this._stateStack != null && this._stateStack._field != null)
/*      */       fieldName = this._stateStack._field.getName(); 
/*      */     emitError(event, message, code, args, severity, fieldName, offendingQName, expectedSchemaType, expectedQNames, errorType, badSchemaType);
/*      */   }
/*      */   
/*      */   public void nextEvent(int kind, ValidatorListener.Event event) {
/*      */     resetValues();
/*      */     if (this._eatContent > 0) {
/*      */       switch (kind) {
/*      */         case 2:
/*      */           this._eatContent--;
/*      */           break;
/*      */         case 1:
/*      */           this._eatContent++;
/*      */           break;
/*      */       } 
/*      */     } else {
/*      */       assert kind == 1 || kind == 4 || kind == 2 || kind == 3 || kind == 5;
/*      */       switch (kind) {
/*      */         case 1:
/*      */           beginEvent(event);
/*      */           break;
/*      */         case 4:
/*      */           attrEvent(event);
/*      */           break;
/*      */         case 5:
/*      */           endAttrsEvent(event);
/*      */           break;
/*      */         case 3:
/*      */           textEvent(event);
/*      */           break;
/*      */         case 2:
/*      */           endEvent(event);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void beginEvent(ValidatorListener.Event event) {
/*      */     this._localElement = null;
/*      */     this._wildcardElement = null;
/*      */     State state = topState();
/*      */     SchemaType elementType = null;
/*      */     SchemaField elementField = null;
/*      */     if (state == null) {
/*      */       elementType = this._rootType;
/*      */       elementField = this._rootField;
/*      */     } else {
/*      */       QName name = event.getName();
/*      */       assert name != null;
/*      */       state._isEmpty = false;
/*      */       if (state._isNil) {
/*      */         emitFieldError(event, "cvc-elt.3.2.1", null, state._field.getName(), state._type, null, 4, state._type);
/*      */         this._eatContent = 1;
/*      */         return;
/*      */       } 
/*      */       if (!state._isNil && state._field != null && state._field.isFixed())
/*      */         emitFieldError(event, "cvc-elt.5.2.2.1", new Object[] { QNameHelper.pretty(state._field.getName()) }, state._field.getName(), state._type, null, 2, state._type); 
/*      */       if (!state.visit(name)) {
/*      */         findDetailedErrorBegin(event, state, name);
/*      */         this._eatContent = 1;
/*      */         return;
/*      */       } 
/*      */       SchemaParticle currentParticle = state.currentParticle();
/*      */       this._wildcardElement = currentParticle;
/*      */       if (currentParticle.getParticleType() == 5) {
/*      */         QNameSet elemWildcardSet = currentParticle.getWildcardSet();
/*      */         if (!elemWildcardSet.contains(name)) {
/*      */           emitFieldError(event, "cvc-particle.1.3", new Object[] { QNameHelper.pretty(name) }, name, null, null, 2, state._type);
/*      */           this._eatContent = 1;
/*      */           return;
/*      */         } 
/*      */         int wildcardProcess = currentParticle.getWildcardProcess();
/*      */         if (wildcardProcess == 3 || (wildcardProcess == 2 && this._treatLaxAsSkip)) {
/*      */           this._eatContent = 1;
/*      */           return;
/*      */         } 
/*      */         this._localElement = (SchemaLocalElement)this._globalTypes.findElement(name);
/*      */         SchemaLocalElement schemaLocalElement = this._localElement;
/*      */         if (schemaLocalElement == null) {
/*      */           if (wildcardProcess == 1)
/*      */             emitFieldError(event, "cvc-assess-elt.1.1.1.3.2", new Object[] { QNameHelper.pretty(name) }, name, state._type, null, 2, state._type); 
/*      */           this._eatContent = 1;
/*      */           return;
/*      */         } 
/*      */       } else {
/*      */         assert currentParticle.getParticleType() == 4;
/*      */         if (!currentParticle.getName().equals(name)) {
/*      */           if (((SchemaLocalElement)currentParticle).blockSubstitution()) {
/*      */             emitFieldError(event, "cvc-particle.2.3.3a", new Object[] { QNameHelper.pretty(name) }, name, state._type, null, 2, state._type);
/*      */             this._eatContent = 1;
/*      */             return;
/*      */           } 
/*      */           SchemaGlobalElement newField = this._globalTypes.findElement(name);
/*      */           assert newField != null;
/*      */           if (newField != null) {
/*      */             SchemaGlobalElement schemaGlobalElement = newField;
/*      */             this._localElement = (SchemaLocalElement)newField;
/*      */           } 
/*      */         } else {
/*      */           elementField = (SchemaField)currentParticle;
/*      */         } 
/*      */       } 
/*      */       elementType = elementField.getType();
/*      */     } 
/*      */     assert elementType != null;
/*      */     if (elementType.isNoType()) {
/*      */       emitFieldError(event, "cvc-elt.1", null, event.getName(), null, null, 3, null);
/*      */       this._eatContent = 1;
/*      */     } 
/*      */     SchemaType xsiType = null;
/*      */     String value = event.getXsiType();
/*      */     if (value != null) {
/*      */       int originalErrorState = this._errorState;
/*      */       this._suspendErrors++;
/*      */       try {
/*      */         this._vc._event = null;
/*      */         xsiType = this._globalTypes.findType(XmlQNameImpl.validateLexical(value, this._vc, (PrefixResolver)event));
/*      */       } catch (Throwable t) {
/*      */         this._errorState++;
/*      */       } finally {
/*      */         this._suspendErrors--;
/*      */       } 
/*      */       if (originalErrorState != this._errorState) {
/*      */         emitFieldError(event, "cvc-elt.4.1", new Object[] { value }, event.getName(), xsiType, null, 3, state._type);
/*      */         this._eatContent = 1;
/*      */         return;
/*      */       } 
/*      */       if (xsiType == null) {
/*      */         emitFieldError(event, "cvc-elt.4.2", new Object[] { value }, event.getName(), null, null, 3, null);
/*      */         this._eatContent = 1;
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     if (xsiType != null && !xsiType.equals(elementType)) {
/*      */       if (!elementType.isAssignableFrom(xsiType)) {
/*      */         emitFieldError(event, "cvc-elt.4.3a", new Object[] { xsiType, elementType }, event.getName(), elementType, null, 3, (state == null) ? null : state._type);
/*      */         this._eatContent = 1;
/*      */         return;
/*      */       } 
/*      */       if (elementType.blockExtension())
/*      */         for (SchemaType t = xsiType; !t.equals(elementType); t = t.getBaseType()) {
/*      */           if (t.getDerivationType() == 2) {
/*      */             emitFieldError(event, "cvc-elt.4.3b", new Object[] { xsiType, elementType }, event.getName(), elementType, null, 3, (state == null) ? null : state._type);
/*      */             this._eatContent = 1;
/*      */             return;
/*      */           } 
/*      */         }  
/*      */       if (elementType.blockRestriction())
/*      */         for (SchemaType t = xsiType; !t.equals(elementType); t = t.getBaseType()) {
/*      */           if (t.getDerivationType() == 1) {
/*      */             emitFieldError(event, "cvc-elt.4.3c", new Object[] { xsiType, elementType }, event.getName(), elementType, null, 3, (state == null) ? null : state._type);
/*      */             this._eatContent = 1;
/*      */             return;
/*      */           } 
/*      */         }  
/*      */       if (elementField instanceof SchemaLocalElement) {
/*      */         SchemaLocalElement sle = (SchemaLocalElement)elementField;
/*      */         this._localElement = sle;
/*      */         if (sle.blockExtension() || sle.blockRestriction())
/*      */           for (SchemaType t = xsiType; !t.equals(elementType); t = t.getBaseType()) {
/*      */             if ((t.getDerivationType() == 1 && sle.blockRestriction()) || (t.getDerivationType() == 2 && sle.blockExtension())) {
/*      */               emitFieldError(event, "cvc-elt.4.3d", new Object[] { xsiType, QNameHelper.pretty(sle.getName()) }, sle.getName(), null, null, 3, null);
/*      */               this._eatContent = 1;
/*      */               return;
/*      */             } 
/*      */           }  
/*      */       } 
/*      */       elementType = xsiType;
/*      */     } 
/*      */     if (elementField instanceof SchemaLocalElement) {
/*      */       SchemaLocalElement sle = (SchemaLocalElement)elementField;
/*      */       this._localElement = sle;
/*      */       if (sle.isAbstract()) {
/*      */         emitError(event, "cvc-elt.2", new Object[] { QNameHelper.pretty(sle.getName()) }, sle.getName(), null, null, 3, null);
/*      */         this._eatContent = 1;
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     if (elementType != null && elementType.isAbstract()) {
/*      */       emitError(event, "cvc-elt.2", new Object[] { elementType }, event.getName(), elementType, null, 3, (state == null) ? null : state._type);
/*      */       this._eatContent = 1;
/*      */       return;
/*      */     } 
/*      */     boolean isNil = false;
/*      */     boolean hasNil = false;
/*      */     String nilValue = event.getXsiNil();
/*      */     if (nilValue != null) {
/*      */       this._vc._event = event;
/*      */       isNil = JavaBooleanHolder.validateLexical(nilValue, this._vc);
/*      */       hasNil = true;
/*      */     } 
/*      */     if (hasNil && (elementField == null || !elementField.isNillable())) {
/*      */       emitFieldError(event, "cvc-elt.3.1", null, (elementField == null) ? null : elementField.getName(), elementType, null, 3, (state == null) ? null : state._type);
/*      */       this._eatContent = 1;
/*      */       return;
/*      */     } 
/*      */     if (isNil && elementField != null && elementField.isFixed())
/*      */       emitFieldError(event, "cvc-elt.3.2.2", null, (elementField == null) ? null : elementField.getName(), elementType, null, 3, (state == null) ? null : state._type); 
/*      */     newState(elementType, elementField, isNil);
/*      */     this._constraintEngine.element(event, elementType, (elementField instanceof SchemaLocalElement) ? ((SchemaLocalElement)elementField).getIdentityConstraints() : null);
/*      */   }
/*      */   
/*      */   public Validator(SchemaType type, SchemaField field, SchemaTypeLoader globalLoader, XmlOptions options, Collection defaultErrorListener) {
/* 1105 */     this._visitorPool = new LinkedList(); options = XmlOptions.maskNull(options); this._errorListener = (Collection)options.get("ERROR_LISTENER"); this._treatLaxAsSkip = options.hasOption("VALIDATE_TREAT_LAX_AS_SKIP"); this._strict = options.hasOption("VALIDATE_STRICT"); if (this._errorListener == null) this._errorListener = defaultErrorListener;  this._constraintEngine = new IdentityConstraint(this._errorListener, type.isDocumentType()); this._globalTypes = globalLoader; this._rootType = type; this._rootField = field; this._vc = new ValidatorVC();
/*      */   }
/*      */   private void attrEvent(ValidatorListener.Event event) { QName attrName = event.getName(); State state = topState(); if (state._attrs == null) state._attrs = new HashSet();  if (state._attrs.contains(attrName)) { emitFieldError(event, "uniqattspec", new Object[] { QNameHelper.pretty(attrName) }, attrName, null, null, 1000, state._type); return; }  state._attrs.add(attrName); if (!state._canHaveAttrs) { emitFieldError(event, "cvc-complex-type.3.2.1", new Object[] { QNameHelper.pretty(attrName) }, attrName, null, null, 1000, state._type); return; }  SchemaLocalAttribute attrSchema = (state._attrModel == null) ? null : state._attrModel.getAttribute(attrName); if (attrSchema != null) { this._localAttribute = attrSchema; if (attrSchema.getUse() == 1) { emitFieldError(event, "cvc-complex-type.prohibited-attribute", new Object[] { QNameHelper.pretty(attrName) }, attrName, null, null, 1000, state._type); return; }  String str = validateSimpleType(attrSchema.getType(), (SchemaField)attrSchema, event, false, false); this._constraintEngine.attr(event, attrName, attrSchema.getType(), str); return; }  int wildcardProcess = state._attrModel.getWildcardProcess(); this._wildcardAttribute = state._attrModel; if (wildcardProcess == 0) { emitFieldError(event, "cvc-complex-type.3.2.1", new Object[] { QNameHelper.pretty(attrName) }, attrName, null, null, 1000, state._type); return; }  QNameSet attrWildcardSet = state._attrModel.getWildcardSet(); if (!attrWildcardSet.contains(attrName)) { emitFieldError(event, "cvc-complex-type.3.2.2", new Object[] { QNameHelper.pretty(attrName) }, attrName, null, null, 1000, state._type); return; }  if (wildcardProcess == 3 || (wildcardProcess == 2 && this._treatLaxAsSkip)) return;  SchemaGlobalAttribute schemaGlobalAttribute = this._globalTypes.findAttribute(attrName); this._localAttribute = (SchemaLocalAttribute)schemaGlobalAttribute; if (schemaGlobalAttribute == null) { if (wildcardProcess == 2) return;  assert wildcardProcess == 1; emitFieldError(event, "cvc-assess-attr.1.2", new Object[] { QNameHelper.pretty(attrName) }, attrName, null, null, 1000, state._type); return; }  String value = validateSimpleType(schemaGlobalAttribute.getType(), (SchemaField)schemaGlobalAttribute, event, false, false); this._constraintEngine.attr(event, attrName, schemaGlobalAttribute.getType(), value); }
/*      */   private void endAttrsEvent(ValidatorListener.Event event) { State state = topState(); if (state._attrModel != null) { SchemaLocalAttribute[] attrs = state._attrModel.getAttributes(); for (int i = 0; i < attrs.length; i++) { SchemaLocalAttribute sla = attrs[i]; if (state._attrs == null || !state._attrs.contains(sla.getName())) if (sla.getUse() == 3) { emitFieldError(event, "cvc-complex-type.4", new Object[] { QNameHelper.pretty(sla.getName()) }, sla.getName(), null, null, 1000, state._type); } else if (sla.isDefault() || sla.isFixed()) { this._constraintEngine.attr(event, sla.getName(), sla.getType(), sla.getDefaultText()); }   }  }  }
/* 1109 */   private void endEvent(ValidatorListener.Event event) { this._localElement = null; this._wildcardElement = null; State state = topState(); if (!state._isNil) { if (!state.end()) findDetailedErrorEnd(event, state);  if (state._isEmpty) handleText(event, true, state._field);  }  popState(event); this._constraintEngine.endElement(event); } private void textEvent(ValidatorListener.Event event) { State state = topState(); if (state._isNil) { emitFieldError(event, "cvc-elt.3.2.1", null, state._field.getName(), state._type, null, 4, state._type); } else { handleText(event, false, state._field); }  state._isEmpty = false; } private void poolVisitor(SchemaTypeVisitorImpl visitor) { this._visitorPool.add(visitor); }
/*      */   private void handleText(ValidatorListener.Event event, boolean emptyContent, SchemaField field) { State state = topState(); if (!state._sawText) if (state._hasSimpleContent) { String value = validateSimpleType(state._type, field, event, emptyContent, true); this._constraintEngine.text(event, state._type, value, false); } else if (state._canHaveMixedContent) { String value = validateSimpleType(XmlString.type, field, event, emptyContent, true); this._constraintEngine.text(event, XmlString.type, value, false); } else if (emptyContent) { this._constraintEngine.text(event, state._type, null, true); } else { this._constraintEngine.text(event, state._type, "", false); }   if (!emptyContent && !state._canHaveMixedContent && !event.textIsWhitespace() && !state._hasSimpleContent) if (field instanceof SchemaLocalElement) { SchemaLocalElement e = (SchemaLocalElement)field; assert state._type.getContentType() == 1 || state._type.getContentType() == 3; String errorCode = (state._type.getContentType() == 1) ? "cvc-complex-type.2.1" : "cvc-complex-type.2.3"; emitError(event, errorCode, new Object[] { QNameHelper.pretty(e.getName()) }, e.getName(), field.getType(), null, 3, null); } else { emitError(event, "Can't have mixed content", event.getName(), state._type, null, 3, null); }   if (!emptyContent)
/*      */       state._sawText = true;  }
/*      */   private void findDetailedErrorBegin(ValidatorListener.Event event, State state, QName qName) { ArrayList expectedNames = new ArrayList(); ArrayList optionalNames = new ArrayList(); SchemaProperty[] eltProperties = state._type.getElementProperties(); for (int ii = 0; ii < eltProperties.length; ii++) { SchemaProperty sProp = eltProperties[ii]; if (state.test(sProp.getName()))
/*      */         if (0 == BigInteger.ZERO.compareTo(sProp.getMinOccurs())) { optionalNames.add(sProp.getName()); } else { expectedNames.add(sProp.getName()); }   }  List names = (expectedNames.size() > 0) ? expectedNames : optionalNames; if (names.size() > 0) { StringBuffer buf = new StringBuffer(); for (Iterator iter = names.iterator(); iter.hasNext(); ) { QName qname = iter.next(); buf.append(QNameHelper.pretty(qname)); if (iter.hasNext())
/* 1114 */           buf.append(" ");  }  emitFieldError(event, "cvc-complex-type.2.4a", new Object[] { new Integer(names.size()), buf.toString(), QNameHelper.pretty(qName) }, qName, null, names, 1, state._type); } else { emitFieldError(event, "cvc-complex-type.2.4b", new Object[] { QNameHelper.pretty(qName) }, qName, null, null, 1, state._type); }  } private SchemaTypeVisitorImpl initVisitor(SchemaParticle particle) { if (this._visitorPool.isEmpty()) {
/* 1115 */       return new SchemaTypeVisitorImpl(particle);
/*      */     }
/* 1117 */     SchemaTypeVisitorImpl result = this._visitorPool.removeLast();
/*      */ 
/*      */     
/* 1120 */     result.init(particle);
/*      */     
/* 1122 */     return result; } private void findDetailedErrorEnd(ValidatorListener.Event event, State state) { SchemaProperty[] eltProperties = state._type.getElementProperties(); ArrayList expectedNames = new ArrayList(); ArrayList optionalNames = new ArrayList(); for (int ii = 0; ii < eltProperties.length; ii++) { SchemaProperty sProp = eltProperties[ii]; if (state.test(sProp.getName())) if (0 == BigInteger.ZERO.compareTo(sProp.getMinOccurs())) { optionalNames.add(sProp.getName()); } else { expectedNames.add(sProp.getName()); }   }  List names = (expectedNames.size() > 0) ? expectedNames : optionalNames; if (names.size() > 0) { StringBuffer buf = new StringBuffer(); for (Iterator iter = names.iterator(); iter.hasNext(); ) { QName qname = iter.next(); buf.append(QNameHelper.pretty(qname)); if (iter.hasNext()) buf.append(" ");  }  emitFieldError(event, "cvc-complex-type.2.4c", new Object[] { new Integer(names.size()), buf.toString() }, null, null, names, 1, state._type); } else { emitFieldError(event, "cvc-complex-type.2.4d", null, null, null, null, 2, state._type); }  } private final class State {
/*      */     SchemaType _type; SchemaField _field; boolean _canHaveAttrs; boolean _canHaveMixedContent; boolean _hasSimpleContent; boolean _sawText; boolean _isEmpty; boolean _isNil; SchemaTypeVisitorImpl _visitor; boolean _canHaveElements; SchemaAttributeModel _attrModel; HashSet _attrs; State _next; static final boolean $assertionsDisabled; private final Validator this$0; private State() {} boolean visit(QName name) { return (this._canHaveElements && this._visitor.visit(name)); } boolean test(QName name) { return (this._canHaveElements && this._visitor.testValid(name)); }
/*      */     boolean end() { return (!this._canHaveElements || this._visitor.visit(null)); }
/*      */     SchemaParticle currentParticle() { assert this._visitor != null; return this._visitor.currentParticle(); } }
/*      */   private boolean derivedFromInteger(SchemaType type) { int btc = type.getBuiltinTypeCode(); while (btc == 0) { type = type.getBaseType(); btc = type.getBuiltinTypeCode(); }  return (btc >= 22 && btc <= 34); }
/* 1127 */   private State topState() { return this._stateStack; } private void newState(SchemaType type, SchemaField field, boolean isNil) { State state = new State(); state._type = type; state._field = field; state._isEmpty = true; state._isNil = isNil; if (type.isSimpleType()) { state._hasSimpleContent = true; } else { SchemaParticle particle; state._canHaveAttrs = true; state._attrModel = type.getAttributeModel(); switch (type.getContentType()) { case 1:
/*      */           break;
/*      */         case 2:
/*      */           state._hasSimpleContent = true; break;
/*      */         case 4:
/*      */           state._canHaveMixedContent = true;
/*      */         case 3:
/*      */           particle = type.getContentModel(); state._canHaveElements = (particle != null); if (state._canHaveElements)
/*      */             state._visitor = initVisitor(particle);  break;
/*      */         default:
/*      */           throw new RuntimeException("Unexpected content type"); }  }
/*      */      pushState(state); }
/*      */   private void popState(ValidatorListener.Event e) { if (this._stateStack._visitor != null) { poolVisitor(this._stateStack._visitor); this._stateStack._visitor = null; }
/*      */      this._stateStack = this._stateStack._next; }
/*      */   private void pushState(State state) { state._next = this._stateStack; this._stateStack = state; }
/* 1142 */   private String validateSimpleType(SchemaType type, SchemaField field, ValidatorListener.Event event, boolean emptyContent, boolean canApplyDefault) { if (!type.isSimpleType() && type.getContentType() != 2) {
/*      */       assert false;
/*      */ 
/*      */ 
/*      */       
/* 1147 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1154 */     if (type.isNoType()) {
/*      */       
/* 1156 */       emitError(event, field.isAttribute() ? "cvc-attribute.1" : "cvc-elt.1", null, field.getName(), type, null, 3, null);
/*      */ 
/*      */       
/* 1159 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1165 */     String value = "";
/*      */     
/* 1167 */     if (!emptyContent) {
/*      */       
/* 1169 */       int wsr = type.getWhiteSpaceRule();
/* 1170 */       value = (wsr == 1) ? event.getText() : event.getText(wsr);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1175 */     if (value.length() == 0 && canApplyDefault && field != null && (field.isDefault() || field.isFixed())) {
/*      */ 
/*      */       
/* 1178 */       if (XmlQName.type.isAssignableFrom(type)) {
/*      */ 
/*      */         
/* 1181 */         emitError(event, "Default QName values are unsupported for " + QNameHelper.readable(type) + " - ignoring.", null, null, 2, field.getName(), null, type, null, 3, null);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1186 */         return null;
/*      */       } 
/*      */       
/* 1189 */       String defaultValue = XmlWhitespace.collapse(field.getDefaultText(), type.getWhiteSpaceRule());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1195 */       return validateSimpleType(type, defaultValue, event) ? defaultValue : null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1202 */     if (!validateSimpleType(type, value, event)) {
/* 1203 */       return null;
/*      */     }
/* 1205 */     if (field != null && field.isFixed()) {
/*      */ 
/*      */       
/* 1208 */       String fixedValue = XmlWhitespace.collapse(field.getDefaultText(), type.getWhiteSpaceRule());
/*      */ 
/*      */ 
/*      */       
/* 1212 */       if (!validateSimpleType(type, fixedValue, event)) {
/* 1213 */         return null;
/*      */       }
/* 1215 */       XmlAnySimpleType xmlAnySimpleType1 = type.newValue(value);
/* 1216 */       XmlAnySimpleType xmlAnySimpleType2 = type.newValue(fixedValue);
/*      */       
/* 1218 */       if (!xmlAnySimpleType1.valueEquals((XmlObject)xmlAnySimpleType2)) {
/*      */ 
/*      */         
/* 1221 */         if (field.isAttribute()) {
/*      */ 
/*      */           
/* 1224 */           emitError(event, "cvc-attribute.4", new Object[] { value, fixedValue, QNameHelper.pretty(event.getName()) }, null, field.getType(), null, 3, null);
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1230 */           String errorCode = null;
/*      */ 
/*      */           
/* 1233 */           if (field.getType().getContentType() == 4) {
/* 1234 */             errorCode = "cvc-elt.5.2.2.2.1";
/* 1235 */           } else if (type.isSimpleType()) {
/* 1236 */             errorCode = "cvc-elt.5.2.2.2.2";
/*      */           } else {
/* 1238 */             assert false : "Element with fixed may not be EMPTY or ELEMENT_ONLY";
/*      */           } 
/* 1240 */           emitError(event, errorCode, new Object[] { value, fixedValue }, field.getName(), field.getType(), null, 3, null);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1245 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/* 1249 */     return value; }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean validateSimpleType(SchemaType type, String value, ValidatorListener.Event event)
/*      */   {
/* 1255 */     if (!type.isSimpleType() && type.getContentType() != 2) {
/*      */       assert false;
/*      */ 
/*      */       
/* 1259 */       throw new RuntimeException("Not a simple type");
/*      */     } 
/*      */     
/* 1262 */     int retState = this._errorState;
/*      */     
/* 1264 */     switch (type.getSimpleVariety()) {
/*      */       case 1:
/* 1266 */         validateAtomicType(type, value, event); break;
/* 1267 */       case 2: validateUnionType(type, value, event); break;
/* 1268 */       case 3: validateListType(type, value, event); break;
/*      */       default:
/* 1270 */         throw new RuntimeException("Unexpected simple variety");
/*      */     } 
/*      */     
/* 1273 */     return (retState == this._errorState); } private void validateAtomicType(SchemaType type, String value, ValidatorListener.Event event) {
/*      */     float f;
/*      */     double d1;
/*      */     QName qName1;
/*      */     GDate gDate;
/*      */     GDuration d;
/*      */     byte[] v;
/*      */     QName n;
/* 1281 */     assert type.getSimpleVariety() == 1;
/*      */ 
/*      */     
/* 1284 */     int errorState = this._errorState;
/* 1285 */     this._vc._event = event;
/*      */     
/* 1287 */     switch (type.getPrimitiveType().getBuiltinTypeCode()) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1292 */         this._stringValue = value;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 12:
/* 1297 */         JavaStringEnumerationHolderEx.validateLexical(value, type, this._vc);
/* 1298 */         this._stringValue = value;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 11:
/* 1303 */         JavaDecimalHolderEx.validateLexical(value, type, this._vc);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1308 */         if (derivedFromInteger(type) && value.lastIndexOf('.') >= 0)
/*      */         {
/* 1310 */           this._vc.invalid("integer", new Object[] { value });
/*      */         }
/*      */         
/* 1313 */         if (errorState == this._errorState) {
/*      */           
/* 1315 */           this._decimalValue = new BigDecimal(value);
/* 1316 */           JavaDecimalHolderEx.validateValue(this._decimalValue, type, this._vc);
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1323 */         this._booleanValue = JavaBooleanHolderEx.validateLexical(value, type, this._vc);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 9:
/* 1328 */         f = JavaFloatHolderEx.validateLexical(value, type, this._vc);
/*      */ 
/*      */         
/* 1331 */         if (errorState == this._errorState) {
/* 1332 */           JavaFloatHolderEx.validateValue(f, type, this._vc);
/*      */         }
/* 1334 */         this._floatValue = f;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 10:
/* 1339 */         d1 = JavaDoubleHolderEx.validateLexical(value, type, this._vc);
/*      */ 
/*      */         
/* 1342 */         if (errorState == this._errorState) {
/* 1343 */           JavaDoubleHolderEx.validateValue(d1, type, this._vc);
/*      */         }
/* 1345 */         this._doubleValue = d1;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 7:
/* 1350 */         qName1 = JavaQNameHolderEx.validateLexical(value, type, this._vc, (PrefixResolver)event);
/*      */ 
/*      */ 
/*      */         
/* 1354 */         if (errorState == this._errorState) {
/* 1355 */           JavaQNameHolderEx.validateValue(qName1, type, this._vc);
/*      */         }
/* 1357 */         this._qnameValue = qName1;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 6:
/* 1362 */         JavaUriHolderEx.validateLexical(value, type, this._vc);
/*      */         
/* 1364 */         if (this._strict) {
/*      */           
/*      */           try {
/*      */             
/* 1368 */             XsTypeConverter.lexAnyURI(value);
/*      */           }
/* 1370 */           catch (InvalidLexicalValueException ilve) {
/*      */             
/* 1372 */             this._vc.invalid("anyURI", new Object[] { value });
/*      */           } 
/*      */         }
/* 1375 */         this._stringValue = value;
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 21:
/* 1381 */         if (this._strict && value.length() == 6 && value.charAt(4) == '-' && value.charAt(5) == '-')
/*      */         {
/* 1383 */           this._vc.invalid("date", new Object[] { value });
/*      */         }
/*      */ 
/*      */       
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/* 1394 */         gDate = XmlDateImpl.validateLexical(value, type, this._vc);
/*      */         
/* 1396 */         if (gDate != null) {
/* 1397 */           XmlDateImpl.validateValue((GDateSpecification)gDate, type, this._vc);
/*      */         }
/* 1399 */         this._gdateValue = gDate;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 13:
/* 1404 */         d = XmlDurationImpl.validateLexical(value, type, this._vc);
/*      */         
/* 1406 */         if (d != null) {
/* 1407 */           XmlDurationImpl.validateValue((GDurationSpecification)d, type, this._vc);
/*      */         }
/* 1409 */         this._gdurationValue = d;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 4:
/* 1414 */         v = JavaBase64HolderEx.validateLexical(value, type, this._vc);
/*      */ 
/*      */         
/* 1417 */         if (v != null) {
/* 1418 */           JavaBase64HolderEx.validateValue(v, type, this._vc);
/*      */         }
/* 1420 */         this._byteArrayValue = v;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 5:
/* 1425 */         v = JavaHexBinaryHolderEx.validateLexical(value, type, this._vc);
/*      */ 
/*      */         
/* 1428 */         if (v != null) {
/* 1429 */           JavaHexBinaryHolderEx.validateValue(v, type, this._vc);
/*      */         }
/* 1431 */         this._byteArrayValue = v;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 8:
/* 1436 */         n = JavaNotationHolderEx.validateLexical(value, type, this._vc, (PrefixResolver)event);
/*      */ 
/*      */ 
/*      */         
/* 1440 */         if (errorState == this._errorState) {
/* 1441 */           JavaNotationHolderEx.validateValue(n, type, this._vc);
/*      */         }
/* 1443 */         this._qnameValue = n;
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1448 */     throw new RuntimeException("Unexpected primitive type code");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateListType(SchemaType type, String value, ValidatorListener.Event event) {
/* 1455 */     int errorState = this._errorState;
/*      */     
/* 1457 */     if (!type.matchPatternFacet(value))
/*      */     {
/* 1459 */       emitError(event, "cvc-datatype-valid.1.1", new Object[] { "list", value, QNameHelper.readable(type) }, null, type, null, 2000, null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1464 */     String[] items = XmlListImpl.split_list(value);
/*      */ 
/*      */     
/*      */     XmlAnySimpleType xmlAnySimpleType;
/*      */     
/* 1469 */     if ((xmlAnySimpleType = type.getFacet(0)) != null) {
/*      */       int j;
/* 1471 */       if ((j = ((SimpleValue)xmlAnySimpleType).getIntValue()) != items.length)
/*      */       {
/*      */         
/* 1474 */         emitError(event, "cvc-length-valid.2", new Object[] { value, new Integer(items.length), new Integer(j), QNameHelper.readable(type) }, null, type, null, 2000, null);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1480 */     if ((xmlAnySimpleType = type.getFacet(1)) != null) {
/*      */       int j;
/* 1482 */       if ((j = ((SimpleValue)xmlAnySimpleType).getIntValue()) > items.length)
/*      */       {
/*      */         
/* 1485 */         emitError(event, "cvc-length-valid.2", new Object[] { value, new Integer(items.length), new Integer(j), QNameHelper.readable(type) }, null, type, null, 2000, null);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1491 */     if ((xmlAnySimpleType = type.getFacet(2)) != null) {
/*      */       int j;
/* 1493 */       if ((j = ((SimpleValue)xmlAnySimpleType).getIntValue()) < items.length)
/*      */       {
/*      */         
/* 1496 */         emitError(event, "cvc-length-valid.2", new Object[] { value, new Integer(items.length), new Integer(j), QNameHelper.readable(type) }, null, type, null, 2000, null);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1502 */     SchemaType itemType = type.getListItemType();
/* 1503 */     this._listValue = new ArrayList();
/* 1504 */     this._listTypes = new ArrayList();
/*      */     
/* 1506 */     for (int i = 0; i < items.length; i++) {
/*      */       
/* 1508 */       validateSimpleType(itemType, items[i], event);
/*      */       
/* 1510 */       addToList(itemType);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1516 */     if (errorState == this._errorState)
/*      */     {
/* 1518 */       if (type.getEnumerationValues() != null) {
/*      */ 
/*      */ 
/*      */         
/* 1522 */         NamespaceContext.push(new NamespaceContext((PrefixResolver)event));
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1527 */           XmlAnySimpleType xmlAnySimpleType1 = ((SchemaTypeImpl)type).newValidatingValue(value);
/*      */         }
/* 1529 */         catch (XmlValueOutOfRangeException e) {
/*      */ 
/*      */           
/* 1532 */           emitError(event, "cvc-enumeration-valid", new Object[] { "list", value, QNameHelper.readable(type) }, null, type, null, 2000, null);
/*      */         
/*      */         }
/*      */         finally {
/*      */ 
/*      */           
/* 1538 */           NamespaceContext.pop();
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateUnionType(SchemaType type, String value, ValidatorListener.Event event) {
/* 1550 */     if (!type.matchPatternFacet(value))
/*      */     {
/*      */       
/* 1553 */       emitError(event, "cvc-datatype-valid.1.1", new Object[] { "union", value, QNameHelper.readable(type) }, null, type, null, 3000, null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1558 */     int currentWsr = 1;
/* 1559 */     String currentValue = value;
/*      */     
/* 1561 */     SchemaType[] types = type.getUnionMemberTypes();
/*      */     
/* 1563 */     int originalState = this._errorState;
/*      */     
/*      */     int i;
/* 1566 */     for (i = 0; i < types.length; i++) {
/*      */       
/* 1568 */       int memberWsr = types[i].getWhiteSpaceRule();
/*      */       
/* 1570 */       if (memberWsr == 0) {
/* 1571 */         memberWsr = 1;
/*      */       }
/* 1573 */       if (memberWsr != currentWsr) {
/*      */         
/* 1575 */         currentWsr = memberWsr;
/* 1576 */         currentValue = XmlWhitespace.collapse(value, currentWsr);
/*      */       } 
/*      */       
/* 1579 */       int originalErrorState = this._errorState;
/*      */       
/* 1581 */       this._suspendErrors++;
/*      */ 
/*      */       
/*      */       try {
/* 1585 */         validateSimpleType(types[i], currentValue, event);
/*      */       }
/*      */       finally {
/*      */         
/* 1589 */         this._suspendErrors--;
/*      */       } 
/*      */       
/* 1592 */       if (originalErrorState == this._errorState) {
/*      */         
/* 1594 */         this._unionType = types[i];
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1599 */     this._errorState = originalState;
/*      */     
/* 1601 */     if (i >= types.length) {
/*      */ 
/*      */       
/* 1604 */       emitError(event, "cvc-datatype-valid.1.2.3", new Object[] { value, QNameHelper.readable(type) }, null, type, null, 3000, null);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1610 */       XmlAnySimpleType[] arrayOfXmlAnySimpleType = type.getEnumerationValues();
/*      */       
/* 1612 */       if (arrayOfXmlAnySimpleType != null) {
/*      */ 
/*      */ 
/*      */         
/* 1616 */         NamespaceContext.push(new NamespaceContext((PrefixResolver)event));
/*      */ 
/*      */         
/*      */         try {
/* 1620 */           XmlAnySimpleType xmlAnySimpleType = type.newValue(value);
/*      */           
/* 1622 */           for (i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/*      */             
/* 1624 */             if (xmlAnySimpleType.valueEquals((XmlObject)arrayOfXmlAnySimpleType[i])) {
/*      */               break;
/*      */             }
/*      */           } 
/* 1628 */           if (i >= arrayOfXmlAnySimpleType.length)
/*      */           {
/*      */             
/* 1631 */             emitError(event, "cvc-enumeration-valid", new Object[] { "union", value, QNameHelper.readable(type) }, null, type, null, 3000, null);
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 1636 */         catch (XmlValueOutOfRangeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1641 */           emitError(event, "cvc-enumeration-valid", new Object[] { "union", value, QNameHelper.readable(type) }, null, type, null, 3000, null);
/*      */         
/*      */         }
/*      */         finally {
/*      */ 
/*      */           
/* 1647 */           NamespaceContext.pop();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void addToList(SchemaType type) {
/* 1655 */     if (type.getSimpleVariety() != 1 && type.getSimpleVariety() != 2) {
/*      */       return;
/*      */     }
/*      */     
/* 1659 */     if ((type.getUnionMemberTypes()).length > 0 && getUnionType() != null) {
/*      */       
/* 1661 */       type = getUnionType();
/* 1662 */       this._unionType = null;
/*      */     } 
/*      */     
/* 1665 */     this._listTypes.add(type);
/*      */     
/* 1667 */     if (type.getPrimitiveType() == null) {
/*      */ 
/*      */ 
/*      */       
/* 1671 */       this._listValue.add(null);
/*      */       
/*      */       return;
/*      */     } 
/* 1675 */     switch (type.getPrimitiveType().getBuiltinTypeCode()) {
/*      */ 
/*      */       
/*      */       case 2:
/* 1679 */         this._listValue.add(this._stringValue);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 12:
/* 1684 */         this._listValue.add(this._stringValue);
/* 1685 */         this._stringValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 11:
/* 1690 */         this._listValue.add(this._decimalValue);
/* 1691 */         this._decimalValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 3:
/* 1696 */         this._listValue.add(this._booleanValue ? Boolean.TRUE : Boolean.FALSE);
/* 1697 */         this._booleanValue = false;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 9:
/* 1702 */         this._listValue.add(new Float(this._floatValue));
/* 1703 */         this._floatValue = 0.0F;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 10:
/* 1708 */         this._listValue.add(new Double(this._doubleValue));
/* 1709 */         this._doubleValue = 0.0D;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 7:
/* 1714 */         this._listValue.add(this._qnameValue);
/* 1715 */         this._qnameValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 6:
/* 1720 */         this._listTypes.add(this._stringValue);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/* 1732 */         this._listValue.add(this._gdateValue);
/* 1733 */         this._gdateValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 13:
/* 1738 */         this._listValue.add(this._gdurationValue);
/* 1739 */         this._gdurationValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 4:
/* 1744 */         this._listValue.add(this._byteArrayValue);
/* 1745 */         this._byteArrayValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 5:
/* 1750 */         this._listValue.add(this._byteArrayValue);
/* 1751 */         this._byteArrayValue = null;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 8:
/* 1756 */         this._listValue.add(this._qnameValue);
/* 1757 */         this._qnameValue = null;
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1762 */     throw new RuntimeException("Unexpected primitive type code");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resetValues() {
/* 1805 */     this._localAttribute = null;
/* 1806 */     this._wildcardAttribute = null;
/* 1807 */     this._stringValue = null;
/* 1808 */     this._decimalValue = null;
/* 1809 */     this._booleanValue = false;
/* 1810 */     this._floatValue = 0.0F;
/* 1811 */     this._doubleValue = 0.0D;
/* 1812 */     this._qnameValue = null;
/* 1813 */     this._gdateValue = null;
/* 1814 */     this._gdurationValue = null;
/* 1815 */     this._byteArrayValue = null;
/* 1816 */     this._listValue = null;
/* 1817 */     this._listTypes = null;
/* 1818 */     this._unionType = null;
/* 1819 */     this._localAttribute = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaType getCurrentElementSchemaType() {
/* 1833 */     State state = topState();
/* 1834 */     if (state != null) {
/* 1835 */       return state._type;
/*      */     }
/* 1837 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaLocalElement getCurrentElement() {
/* 1845 */     if (this._localElement != null) {
/* 1846 */       return this._localElement;
/*      */     }
/*      */ 
/*      */     
/* 1850 */     if (this._eatContent > 0) {
/* 1851 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1855 */     if (this._stateStack != null && this._stateStack._field instanceof SchemaLocalElement) {
/* 1856 */       return (SchemaLocalElement)this._stateStack._field;
/*      */     }
/* 1858 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaParticle getCurrentWildcardElement() {
/* 1867 */     return this._wildcardElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaLocalAttribute getCurrentAttribute() {
/* 1876 */     return this._localAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaAttributeModel getCurrentWildcardAttribute() {
/* 1884 */     return this._wildcardAttribute;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getStringValue() {
/* 1889 */     return this._stringValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getDecimalValue() {
/* 1894 */     return this._decimalValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBooleanValue() {
/* 1899 */     return this._booleanValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloatValue() {
/* 1904 */     return this._floatValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDoubleValue() {
/* 1909 */     return this._doubleValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getQNameValue() {
/* 1914 */     return this._qnameValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public GDate getGDateValue() {
/* 1919 */     return this._gdateValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public GDuration getGDurationValue() {
/* 1924 */     return this._gdurationValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getByteArrayValue() {
/* 1929 */     return this._byteArrayValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public List getListValue() {
/* 1934 */     return this._listValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public List getListTypes() {
/* 1939 */     return this._listTypes;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType getUnionType() {
/* 1944 */     return this._unionType;
/*      */   }
/*      */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\validator\Validator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */