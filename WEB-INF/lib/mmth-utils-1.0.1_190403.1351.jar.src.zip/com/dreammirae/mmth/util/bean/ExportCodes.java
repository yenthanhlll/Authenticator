/*     */ package com.dreammirae.mmth.util.bean;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.ArrayUtils;
/*     */ 
/*     */ 
/*     */ public class ExportCodes
/*     */ {
/*     */   private final List<Element> elements;
/*     */   
/*     */   public ExportCodes() {
/*  13 */     this.elements = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public ExportCodes(int size) {
/*  17 */     this.elements = new ArrayList<>(size);
/*     */   }
/*     */   
/*     */   public void addElement(int id, String code) {
/*  21 */     this.elements.add(new Element(id, code, null));
/*     */   }
/*     */   
/*     */   public void addElement(int id, String code, String key) {
/*  25 */     this.elements.add(new Element(id, code, key));
/*     */   }
/*     */   
/*     */   public String getCode(int id) {
/*  29 */     Element e = getElement(id);
/*  30 */     if (e == null)
/*  31 */       return null; 
/*  32 */     return e.code;
/*     */   }
/*     */   
/*     */   public String getKey(int id) {
/*  36 */     Element e = getElement(id);
/*  37 */     if (e == null)
/*  38 */       return null; 
/*  39 */     return e.key;
/*     */   }
/*     */   
/*     */   public int getId(String code, int... excludeIds) {
/*  43 */     for (Element element : this.elements) {
/*  44 */       if (element.code.equalsIgnoreCase(code) && !ArrayUtils.contains(excludeIds, element.id))
/*  45 */         return element.id; 
/*     */     } 
/*  47 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean isValidId(int id, int... excludeIds) {
/*  51 */     for (Element element : this.elements) {
/*  52 */       int eid = element.id;
/*  53 */       if (!ArrayUtils.contains(excludeIds, eid) && eid == id)
/*  54 */         return true; 
/*     */     } 
/*  56 */     return false;
/*     */   }
/*     */   
/*     */   public List<String> getCodeList(int... excludeIds) {
/*  60 */     List<String> result = new ArrayList<>(this.elements.size());
/*  61 */     for (Element e : this.elements) {
/*  62 */       if (!ArrayUtils.contains(excludeIds, e.id))
/*  63 */         result.add(e.code); 
/*     */     } 
/*  65 */     return result;
/*     */   }
/*     */   
/*     */   private Element getElement(int id) {
/*  69 */     for (Element element : this.elements) {
/*  70 */       if (element.id == id)
/*  71 */         return element; 
/*     */     } 
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   public int size() {
/*  77 */     return this.elements.size();
/*     */   }
/*     */   
/*     */   public int getId(int index) {
/*  81 */     return ((Element)this.elements.get(index)).id;
/*     */   }
/*     */   
/*     */   public List<KeyValuePair<Integer, String>> getIdKeys(int... excludeIds) {
/*  85 */     List<KeyValuePair<Integer, String>> result = new ArrayList<>(this.elements.size());
/*  86 */     for (Element e : this.elements) {
/*  87 */       if (!ArrayUtils.contains(excludeIds, e.id))
/*  88 */         result.add(new KeyValuePair<>(Integer.valueOf(e.id), e.key)); 
/*     */     } 
/*  90 */     return result;
/*     */   }
/*     */   
/*     */   public List<KeyValuePair<Integer, String>> getIdCodes(int... excludeIds) {
/*  94 */     List<KeyValuePair<Integer, String>> result = new ArrayList<>(this.elements.size());
/*  95 */     for (Element e : this.elements) {
/*  96 */       if (!ArrayUtils.contains(excludeIds, e.id))
/*  97 */         result.add(new KeyValuePair<>(Integer.valueOf(e.id), e.code)); 
/*     */     } 
/*  99 */     return result;
/*     */   }
/*     */   
/*     */   class Element
/*     */   {
/*     */     final int id;
/*     */     final String code;
/*     */     final String key;
/*     */     
/*     */     Element(int id, String code, String key) {
/* 109 */       this.id = id;
/* 110 */       this.code = code;
/* 111 */       this.key = key;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\bean\ExportCodes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */