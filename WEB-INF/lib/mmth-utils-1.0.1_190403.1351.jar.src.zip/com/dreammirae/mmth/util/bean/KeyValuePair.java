/*    */ package com.dreammirae.mmth.util.bean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyValuePair<K, V>
/*    */ {
/*    */   private K key;
/*    */   private V value;
/*    */   
/*    */   public KeyValuePair() {}
/*    */   
/*    */   public KeyValuePair(K key, V value) {
/* 14 */     this.key = key;
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public K getKey() {
/* 19 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(K key) {
/* 23 */     this.key = key;
/*    */   }
/*    */   
/*    */   public V getValue() {
/* 27 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(V value) {
/* 31 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 36 */     return "KeyValuePair [key=" + this.key + ", value=" + this.value + "]";
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\bean\KeyValuePair.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */