/*    */ package com.dreammirae.mmth.util.bean;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.SerializationUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Tuple<E1, E2>
/*    */   implements Serializable {
/*    */   private E1 element1;
/*    */   private E2 element2;
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int version = 1;
/*    */   
/*    */   public Tuple() {}
/*    */   
/*    */   public Tuple(E1 element1, E2 element2) {
/* 19 */     this.element1 = element1;
/* 20 */     this.element2 = element2;
/*    */   }
/*    */   
/*    */   public E1 getElement1() {
/* 24 */     return this.element1;
/*    */   }
/*    */   
/*    */   public void setElement1(E1 element1) {
/* 28 */     this.element1 = element1;
/*    */   }
/*    */   
/*    */   public E2 getElement2() {
/* 32 */     return this.element2;
/*    */   }
/*    */   
/*    */   public void setElement2(E2 element2) {
/* 36 */     this.element2 = element2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 44 */     int prime = 31;
/* 45 */     int result = 1;
/* 46 */     result = 31 * result + ((this.element1 == null) ? 0 : this.element1.hashCode());
/* 47 */     result = 31 * result + ((this.element2 == null) ? 0 : this.element2.hashCode());
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 56 */     if (this == obj)
/* 57 */       return true; 
/* 58 */     if (obj == null)
/* 59 */       return false; 
/* 60 */     if (getClass() != obj.getClass())
/* 61 */       return false; 
/* 62 */     Tuple<?, ?> other = (Tuple<?, ?>)obj;
/* 63 */     if (this.element1 == null) {
/* 64 */       if (other.element1 != null)
/* 65 */         return false; 
/* 66 */     } else if (!this.element1.equals(other.element1)) {
/* 67 */       return false;
/* 68 */     }  if (this.element2 == null) {
/* 69 */       if (other.element2 != null)
/* 70 */         return false; 
/* 71 */     } else if (!this.element2.equals(other.element2)) {
/* 72 */       return false;
/* 73 */     }  return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 83 */     out.writeInt(1);
/* 84 */     SerializationUtils.writeSafeObject(out, this.element1);
/* 85 */     SerializationUtils.writeSafeObject(out, this.element2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 91 */     int ver = in.readInt();
/*    */     
/* 93 */     if (ver == 1) {
/* 94 */       this.element1 = (E1)SerializationUtils.readSafeObject(in);
/* 95 */       this.element2 = (E2)SerializationUtils.readSafeObject(in);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\bean\Tuple.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */