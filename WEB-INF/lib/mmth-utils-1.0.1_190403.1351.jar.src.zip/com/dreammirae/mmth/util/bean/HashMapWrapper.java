/*     */ package com.dreammirae.mmth.util.bean;
/*     */ 
/*     */ import com.dreammirae.mmth.util.io.BeanMapperUtils;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HashMapWrapper
/*     */   extends HashMap<String, Object>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public HashMapWrapper() {}
/*     */   
/*     */   public HashMapWrapper(int initialCapacity, float loadFactor) {
/*  17 */     super(initialCapacity, loadFactor);
/*     */   }
/*     */   
/*     */   public HashMapWrapper(int initialCapacity) {
/*  21 */     super(initialCapacity);
/*     */   }
/*     */   
/*     */   public HashMapWrapper(Map<? extends String, ? extends Object> m) {
/*  25 */     super(m);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> T convertToObject(HashMapWrapper data, Class<T> clazz) throws Exception {
/*  30 */     return (T)BeanMapperUtils.mapToBean(data, clazz);
/*     */   }
/*     */   
/*     */   public static HashMapWrapper convertFromObject(Object obj) throws Exception {
/*  34 */     Map<String, Object> map = BeanMapperUtils.beanToMap(obj);
/*  35 */     return new HashMapWrapper(map);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T get(String key, Class<T> clazz) {
/*  41 */     Object val = get(key);
/*     */     
/*  43 */     if (val instanceof Boolean && (
/*  44 */       boolean.class.equals(clazz) || Boolean.class.equals(clazz))) {
/*  45 */       return (val == null) ? (T)Boolean.FALSE : (T)Boolean.class.cast(val);
/*     */     }
/*     */ 
/*     */     
/*  49 */     if (val instanceof Character && (
/*  50 */       char.class.equals(clazz) || Character.class.equals(clazz))) {
/*  51 */       return (val == null) ? (T)Character.valueOf(' ') : (T)Character.class.cast(val);
/*     */     }
/*     */ 
/*     */     
/*  55 */     if (val instanceof Number) {
/*     */       
/*  57 */       Number numVal = (Number)val;
/*     */       
/*  59 */       if (byte.class.equals(clazz) || Byte.class.equals(clazz)) {
/*  60 */         return (T)Byte.valueOf(numVal.byteValue());
/*     */       }
/*     */       
/*  63 */       if (short.class.equals(clazz) || Short.class.equals(clazz)) {
/*  64 */         return (T)Short.valueOf(numVal.shortValue());
/*     */       }
/*     */       
/*  67 */       if (int.class.equals(clazz) || Integer.class.equals(clazz)) {
/*  68 */         return (T)Integer.valueOf(numVal.intValue());
/*     */       }
/*     */       
/*  71 */       if (long.class.equals(clazz) || Long.class.equals(clazz)) {
/*  72 */         return (T)Long.valueOf(numVal.longValue());
/*     */       }
/*     */       
/*  75 */       if (float.class.equals(clazz) || Float.class.equals(clazz)) {
/*  76 */         return (T)Float.valueOf(numVal.floatValue());
/*     */       }
/*     */       
/*  79 */       if (double.class.equals(clazz) || Double.class.equals(clazz)) {
/*  80 */         return (T)Double.valueOf(numVal.doubleValue());
/*     */       }
/*     */     } 
/*     */     
/*  84 */     if (val == null) {
/*  85 */       if (boolean.class.equals(clazz) || Boolean.class.equals(clazz))
/*  86 */         return (T)Boolean.FALSE; 
/*  87 */       if (char.class.equals(clazz) || Character.class.equals(clazz))
/*  88 */         return (T)Character.valueOf(' '); 
/*  89 */       if (byte.class.equals(clazz) || byte[].class.equals(clazz))
/*  90 */         return (T)Byte.valueOf((byte)0); 
/*  91 */       if (short.class.equals(clazz) || Short.class.equals(clazz))
/*  92 */         return (T)Short.valueOf((short)0); 
/*  93 */       if (int.class.equals(clazz) || Integer.class.equals(clazz))
/*  94 */         return (T)Integer.valueOf(0); 
/*  95 */       if (long.class.equals(clazz) || Long.class.equals(clazz))
/*  96 */         return (T)Long.valueOf(0L); 
/*  97 */       if (float.class.equals(clazz) || Float.class.equals(clazz))
/*  98 */         return (T)Float.valueOf(0.0F); 
/*  99 */       if (double.class.equals(clazz) || Double.class.equals(clazz)) {
/* 100 */         return (T)Double.valueOf(0.0D);
/*     */       }
/* 102 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     return clazz.cast(val);
/*     */   }
/*     */   
/*     */   public void set(String key, Object value) {
/* 110 */     put(key, value);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\bean\HashMapWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */