/*     */ package com.dreammirae.mmth.util.io;
/*     */ 
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.PropertyResourceBundle;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalResoureBundleWrapper
/*     */ {
/*     */   private final ResourceBundle bundle;
/*     */   
/*     */   public ExternalResoureBundleWrapper(String basePath, String bundleName) {
/*  27 */     this(new File(basePath), bundleName);
/*     */   }
/*     */ 
/*     */   
/*     */   public ExternalResoureBundleWrapper(File baseDir, String bundleName) {
/*  32 */     if (!baseDir.isDirectory()) {
/*  33 */       throw new IllegalArgumentException("Base dir must be exists.");
/*     */     }
/*     */     
/*  36 */     if (StringUtils.isEmpty(bundleName)) {
/*  37 */       throw new IllegalArgumentException("bundleName is required.");
/*     */     }
/*     */     
/*  40 */     this.bundle = ResourceBundle.getBundle(bundleName, Locale.getDefault(), new ExteranlSourceControl(baseDir));
/*     */     
/*  42 */     if (this.bundle == null) {
/*  43 */       throw new IllegalArgumentException("Can not load ResourceBundle. bundleName=" + bundleName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/*  49 */     return this.bundle.getLocale();
/*     */   }
/*     */   
/*     */   public Enumeration<String> getKeys() {
/*  53 */     return this.bundle.getKeys();
/*     */   }
/*     */   
/*     */   public boolean containsKey(String key) {
/*  57 */     return this.bundle.containsKey(key);
/*     */   }
/*     */   
/*     */   public Set<String> keySet() {
/*  61 */     return this.bundle.keySet();
/*     */   }
/*     */   
/*     */   public String getString(String key) {
/*     */     try {
/*  66 */       return this.bundle.getString(key);
/*  67 */     } catch (Exception e) {
/*  68 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ExteranlSourceControl
/*     */     extends ResourceBundle.Control
/*     */   {
/*     */     private final File base;
/*     */ 
/*     */ 
/*     */     
/*     */     private ExteranlSourceControl(File base) {
/*  83 */       this.base = base;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload) throws IllegalAccessException, InstantiationException, IOException {
/*  90 */       if (!format.equals("java.properties")) {
/*  91 */         return null;
/*     */       }
/*     */       
/*  94 */       String bundleName = toBundleName(baseName, locale);
/*  95 */       String resourceName = toResourceName(bundleName, "properties");
/*     */       
/*  97 */       InputStreamReader reader = null;
/*  98 */       FileInputStream fis = null;
/*     */       try {
/* 100 */         File bundleFile = new File(this.base, resourceName);
/*     */         
/* 102 */         if (bundleFile.isFile()) {
/* 103 */           fis = new FileInputStream(bundleFile);
/* 104 */           reader = new InputStreamReader(fis, Charset.forName("UTF-8"));
/*     */           
/* 106 */           return new PropertyResourceBundle(reader);
/*     */         } 
/*     */         
/* 109 */         return null;
/*     */       } finally {
/* 111 */         Closer.close(reader);
/* 112 */         Closer.close(fis);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\ExternalResoureBundleWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */