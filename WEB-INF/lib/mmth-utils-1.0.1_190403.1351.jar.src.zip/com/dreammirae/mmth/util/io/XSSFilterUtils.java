/*     */ package com.dreammirae.mmth.util.io;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ 
/*     */ public final class XSSFilterUtils
/*     */ {
/*  10 */   private static final Pattern[] PATTERN_SCRIPTS = new Pattern[] { Pattern.compile("<script>(.*?)</script>", 2), Pattern.compile("<iframe>(.*?)</iframe>", 2), Pattern.compile("<embed>(.*?)</embed>", 2), Pattern.compile("src[\r\n]*=[\r\n]*\\'(.*?)\\'", 42), Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", 42), Pattern.compile("</script>", 2), Pattern.compile("<script(.*?)>", 42), Pattern.compile("</iframe>", 2), Pattern.compile("<iframe(.*?)>", 42), Pattern.compile("</embed>", 2), Pattern.compile("<embed(.*?)>", 42), Pattern.compile("eval\\((.*?)\\)", 42), Pattern.compile("expression\\((.*?)\\)", 42), Pattern.compile("javascript:", 2), Pattern.compile("vbscript:", 2), Pattern.compile("onload(.*?)=", 42), Pattern.compile("FSCommand", 42), Pattern.compile("onAbort", 42), Pattern.compile("onActivate", 42), Pattern.compile("onAfterPrint", 42), Pattern.compile("onAfterUpdate", 42), Pattern.compile("onBeforeActivate", 42), Pattern.compile("onBeforeCopy", 42), Pattern.compile("onBeforeCut", 42), Pattern.compile("onBeforeDeactivate", 42), Pattern.compile("onBeforeEditFocus", 42), Pattern.compile("onBeforePaste", 42), Pattern.compile("onBeforePrint", 42), Pattern.compile("onBeforeUnload", 42), Pattern.compile("onBeforeUpdate", 42), Pattern.compile("onBegin", 42), Pattern.compile("onBlur", 42), Pattern.compile("onBounce", 42), Pattern.compile("onCellChange", 42), Pattern.compile("onChange", 42), Pattern.compile("onClick", 42), Pattern.compile("onContextMenu", 42), Pattern.compile("onControlSelect", 42), Pattern.compile("onCopy", 42), Pattern.compile("onCut", 42), Pattern.compile("onDataAvailable", 42), Pattern.compile("onDataSetChanged", 42), Pattern.compile("onDataSetComplete", 42), Pattern.compile("onDblClick", 42), Pattern.compile("onDeactivate", 42), Pattern.compile("onDrag", 42), Pattern.compile("onDragEnd", 42), Pattern.compile("onDragLeave", 42), Pattern.compile("onDragEnter", 42), Pattern.compile("onDragOver", 42), Pattern.compile("onDragDrop", 42), Pattern.compile("onDragStart", 42), Pattern.compile("onDrop", 42), Pattern.compile("onEnd", 42), Pattern.compile("onError", 42), Pattern.compile("onErrorUpdate", 42), Pattern.compile("onFilterChange", 42), Pattern.compile("onFinish", 42), Pattern.compile("onFocus", 42), Pattern.compile("onFocusIn", 42), Pattern.compile("onFocusOut", 42), Pattern.compile("onHashChange", 42), Pattern.compile("onHelp", 42), Pattern.compile("onInput", 42), Pattern.compile("onKeyDown", 42), Pattern.compile("onKeyPress", 42), Pattern.compile("onKeyUp", 42), Pattern.compile("onLayoutComplete", 42), Pattern.compile("onLoad", 42), Pattern.compile("onLoseCapture", 42), Pattern.compile("onMediaComplete", 42), Pattern.compile("onMediaError", 42), Pattern.compile("onMessage", 42), Pattern.compile("onMouseDown", 42), Pattern.compile("onMouseEnter", 42), Pattern.compile("onMouseLeave", 42), Pattern.compile("onMouseMove", 42), Pattern.compile("onMouseOut", 42), Pattern.compile("onMouseOver", 42), Pattern.compile("onMouseUp", 42), Pattern.compile("onMouseWheel", 42), Pattern.compile("onMove", 42), Pattern.compile("onMoveEnd", 42), Pattern.compile("onMoveStart", 42), Pattern.compile("onOffline", 42), Pattern.compile("onOnline", 42), Pattern.compile("onOutOfSync", 42), Pattern.compile("onPaste", 42), Pattern.compile("onPause", 42), Pattern.compile("onPopState", 42), Pattern.compile("onProgress", 42), Pattern.compile("onPropertyChange", 42), Pattern.compile("onReadyStateChange", 42), Pattern.compile("onRedo", 42), Pattern.compile("onRepeat", 42), Pattern.compile("onReset", 42), Pattern.compile("onResize", 42), Pattern.compile("onResizeEnd", 42), Pattern.compile("onResizeStart", 42), Pattern.compile("onResume", 42), Pattern.compile("onReverse", 42), Pattern.compile("onRowsEnter", 42), Pattern.compile("onRowExit", 42), Pattern.compile("onRowDelete", 42), Pattern.compile("onRowInserted", 42), Pattern.compile("onScroll", 42), Pattern.compile("onSeek", 42), Pattern.compile("onSelect", 42), Pattern.compile("onSelectionChange", 42), Pattern.compile("onSelectStart", 42), Pattern.compile("onStart", 42), Pattern.compile("onStop", 42), Pattern.compile("onStorage", 42), Pattern.compile("onSyncRestored", 42), Pattern.compile("onSubmit", 42), Pattern.compile("onTimeError", 42), Pattern.compile("onTrackChange", 42), Pattern.compile("onUndo", 42), Pattern.compile("onUnload", 42), Pattern.compile("onURLFlip", 42), Pattern.compile("seekSegmentTime", 42), Pattern.compile("alert", 42), Pattern.compile("document", 42) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void filterOutXss(HttpServletRequest request) throws IllegalArgumentException {
/* 157 */     if (request == null) {
/*     */       return;
/*     */     }
/*     */     
/* 161 */     Enumeration<String> en = request.getParameterNames();
/*     */     
/* 163 */     while (en.hasMoreElements()) {
/* 164 */       String paramName = en.nextElement();
/* 165 */       String value = request.getParameter(paramName);
/* 166 */       validateXss(paramName, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void validateXss(String paramName, String value) throws IllegalArgumentException {
/* 172 */     for (Pattern pattern : PATTERN_SCRIPTS) {
/*     */       
/* 174 */       if (pattern.matcher(value).matches())
/* 175 */         throw new IllegalArgumentException("The parameter value is invalid. paramName=" + paramName + ", paramValue=" + value); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\XSSFilterUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */