/*     */ package com.dreammirae.mmth.util.io;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EndianUtils
/*     */ {
/*     */   public static byte[] short2Bytes(short num) {
/*  12 */     byte[] bytes = new byte[2];
/*  13 */     bytes[0] = (byte)(num >> 8 & 0xFF);
/*  14 */     bytes[1] = (byte)(num & 0xFF);
/*  15 */     return bytes;
/*     */   }
/*     */   
/*     */   public static byte[] short2Bytes_ByLittleEndian(short num) {
/*  19 */     byte[] bytes = new byte[2];
/*  20 */     bytes[0] = (byte)(num & 0xFF);
/*  21 */     bytes[1] = (byte)(num >> 8 & 0xFF);
/*  22 */     return bytes;
/*     */   }
/*     */   
/*     */   public static byte[] int2Bytes(int num) {
/*  26 */     byte[] bytes = new byte[4];
/*  27 */     bytes[0] = (byte)(num >> 24 & 0xFF);
/*  28 */     bytes[1] = (byte)(num >> 16 & 0xFF);
/*  29 */     bytes[2] = (byte)(num >> 8 & 0xFF);
/*  30 */     bytes[3] = (byte)(num & 0xFF);
/*  31 */     return bytes;
/*     */   }
/*     */   
/*     */   public static byte[] int2Bytes_ByLittleEndian(int num) {
/*  35 */     byte[] bytes = new byte[4];
/*  36 */     bytes[0] = (byte)(num & 0xFF);
/*  37 */     bytes[1] = (byte)(num >> 8 & 0xFF);
/*  38 */     bytes[2] = (byte)(num >> 16 & 0xFF);
/*  39 */     bytes[3] = (byte)(num >> 24 & 0xFF);
/*  40 */     return bytes;
/*     */   }
/*     */   
/*     */   public static byte[] long2Bytes(long num) {
/*  44 */     byte[] bytes = new byte[8];
/*  45 */     bytes[0] = (byte)(int)(num >> 56L & 0xFFL);
/*  46 */     bytes[1] = (byte)(int)(num >> 48L & 0xFFL);
/*  47 */     bytes[2] = (byte)(int)(num >> 40L & 0xFFL);
/*  48 */     bytes[3] = (byte)(int)(num >> 32L & 0xFFL);
/*  49 */     bytes[4] = (byte)(int)(num >> 24L & 0xFFL);
/*  50 */     bytes[5] = (byte)(int)(num >> 16L & 0xFFL);
/*  51 */     bytes[6] = (byte)(int)(num >> 8L & 0xFFL);
/*  52 */     bytes[7] = (byte)(int)(num & 0xFFL);
/*  53 */     return bytes;
/*     */   }
/*     */   
/*     */   public static byte[] long2Bytes_ByLittleEndian(long num) {
/*  57 */     byte[] bytes = new byte[8];
/*  58 */     bytes[0] = (byte)(int)(num & 0xFFL);
/*  59 */     bytes[1] = (byte)(int)(num >> 8L & 0xFFL);
/*  60 */     bytes[2] = (byte)(int)(num >> 16L & 0xFFL);
/*  61 */     bytes[3] = (byte)(int)(num >> 24L & 0xFFL);
/*  62 */     bytes[4] = (byte)(int)(num >> 32L & 0xFFL);
/*  63 */     bytes[5] = (byte)(int)(num >> 40L & 0xFFL);
/*  64 */     bytes[6] = (byte)(int)(num >> 48L & 0xFFL);
/*  65 */     bytes[7] = (byte)(int)(num >> 56L & 0xFFL);
/*  66 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toBit8(byte[] b, int offset, int position) {
/*  84 */     validateArg(b, offset, 1);
/*     */     
/*  86 */     if (position < 0 || position > 7) {
/*  87 */       throw new IllegalArgumentException("Position must be between 0 and 7.");
/*     */     }
/*     */     
/*  90 */     byte tmp = b[offset];
/*  91 */     return tmp >> position & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toBit16(byte[] b, int offset, int position) {
/* 108 */     if (position < 0 || position > 15) {
/* 109 */       throw new IllegalArgumentException("Position must be between 0 and 15.");
/*     */     }
/*     */     
/* 112 */     int tmp = toInt16(b, offset);
/* 113 */     return tmp >> position & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toBit16_ByLittleEndian(byte[] b, int offset, int position) {
/* 130 */     if (position < 0 || position > 15) {
/* 131 */       throw new IllegalArgumentException("Position must be between 0 and 15.");
/*     */     }
/* 133 */     int tmp = toInt16_ByLittleEndian(b, offset);
/* 134 */     return tmp >> position & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt8(byte[] b, int offset) {
/* 149 */     validateArg(b, offset, 1);
/*     */     
/* 151 */     return b[offset];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toUInt8(byte[] b, int offset) {
/* 166 */     validateArg(b, offset, 1);
/*     */     
/* 168 */     return b[offset] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt16(byte[] b, int offset) {
/* 183 */     validateArg(b, offset, 2);
/*     */     
/* 185 */     byte low = b[offset];
/* 186 */     byte high = b[offset + 1];
/*     */     
/* 188 */     return (short)(low << 8 & 0xFF00 | high & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toUInt16(byte[] b, int offset) {
/* 203 */     validateArg(b, offset, 2);
/*     */     
/* 205 */     byte low = b[offset];
/* 206 */     byte high = b[offset + 1];
/*     */     
/* 208 */     return low << 8 & 0xFF00 | high & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt16_ByLittleEndian(byte[] b, int offset) {
/* 223 */     validateArg(b, offset, 2);
/*     */     
/* 225 */     byte low = b[offset];
/* 226 */     byte high = b[offset + 1];
/*     */     
/* 228 */     return (short)(high << 8 & 0xFF00 | low & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toUInt16_ByLittleEndian(byte[] b, int offset) {
/* 243 */     validateArg(b, offset, 2);
/*     */     
/* 245 */     byte low = b[offset];
/* 246 */     byte high = b[offset + 1];
/*     */     
/* 248 */     return high << 8 & 0xFF00 | low & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt32(byte[] b, int offset) {
/* 263 */     validateArg(b, offset, 4);
/*     */     
/* 265 */     byte b0 = b[offset];
/* 266 */     byte b1 = b[offset + 1];
/* 267 */     byte b2 = b[offset + 2];
/* 268 */     byte b3 = b[offset + 3];
/*     */     
/* 270 */     return b0 << 24 & 0xFF000000 | b1 << 16 & 0xFF0000 | b2 << 8 & 0xFF00 | b3 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toUInt32(byte[] b, int offset) {
/* 285 */     validateArg(b, offset, 4);
/*     */     
/* 287 */     byte b0 = b[offset];
/* 288 */     byte b1 = b[offset + 1];
/* 289 */     byte b2 = b[offset + 2];
/* 290 */     byte b3 = b[offset + 3];
/*     */     
/* 292 */     return (b0 << 24) & 0xFF000000L | (b1 << 16) & 0xFF0000L | (b2 << 8) & 0xFF00L | b3 & 0xFFL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt32_ByLittleEndian(byte[] b, int offset) {
/* 307 */     validateArg(b, offset, 4);
/*     */     
/* 309 */     byte b0 = b[offset];
/* 310 */     byte b1 = b[offset + 1];
/* 311 */     byte b2 = b[offset + 2];
/* 312 */     byte b3 = b[offset + 3];
/*     */     
/* 314 */     return b3 << 24 & 0xFF000000 | b2 << 16 & 0xFF0000 | b1 << 8 & 0xFF00 | b0 & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toUInt32_ByLittleEndian(byte[] b, int offset) {
/* 329 */     validateArg(b, offset, 4);
/*     */     
/* 331 */     byte b0 = b[offset];
/* 332 */     byte b1 = b[offset + 1];
/* 333 */     byte b2 = b[offset + 2];
/* 334 */     byte b3 = b[offset + 3];
/*     */     
/* 336 */     return (b3 << 24) & 0xFF000000L | (b2 << 16) & 0xFF0000L | (b1 << 8) & 0xFF00L | b0 & 0xFFL;
/*     */   }
/*     */   
/*     */   public static long toInt64(byte[] b, int offset) {
/* 340 */     long low = toInt32(b, offset);
/* 341 */     long high = toInt32(b, offset + 4);
/* 342 */     return (low << 32L) + (0xFFFFFFFFL & high);
/*     */   }
/*     */ 
/*     */   
/*     */   public static long toInt64_ByLittleEndian(byte[] b, int offset) {
/* 347 */     long low = toInt32_ByLittleEndian(b, offset);
/* 348 */     long high = toInt32_ByLittleEndian(b, offset + 4);
/*     */     
/* 350 */     return (high << 32L) + (0xFFFFFFFFL & low);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void validateArg(byte[] b, int offset, int baseLen) {
/* 355 */     if (b == null) {
/* 356 */       throw new IllegalArgumentException("Byte array must not be null");
/*     */     }
/*     */     
/* 359 */     int len = b.length;
/*     */     
/* 361 */     if (len < baseLen) {
/* 362 */       throw new IllegalArgumentException("Byte array length must be at least " + baseLen + ".");
/*     */     }
/*     */     
/* 365 */     if (offset < 0) {
/* 366 */       throw new IllegalArgumentException("Offset must be positive value.");
/*     */     }
/*     */     
/* 369 */     if (offset + baseLen > len)
/* 370 */       throw new IllegalArgumentException("Offset must not exceed " + (len - baseLen) + "."); 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\EndianUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */