/*     */ package com.dreammirae.mmth.util.io;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HexUtils
/*     */ {
/*   8 */   private static final char[] DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(byte[] bytes) {
/*  16 */     if (bytes == null || bytes.length == 0) {
/*  17 */       return "";
/*     */     }
/*     */     
/*  20 */     StringBuilder sb = new StringBuilder(bytes.length << 1);
/*  21 */     for (byte b : bytes) {
/*  22 */       sb.append(DIGITS[(0xF0 & b) >>> 4]).append(DIGITS[0xF & b]);
/*     */     }
/*  24 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHexString(byte[] bytes, int offset, int len) {
/*  29 */     if (bytes == null || bytes.length == 0) {
/*  30 */       return "";
/*     */     }
/*  32 */     int endIdx = offset + len;
/*  33 */     if (bytes.length < endIdx) {
/*  34 */       return "";
/*     */     }
/*     */     
/*  37 */     StringBuilder sb = new StringBuilder(len << 1);
/*     */     
/*     */     try {
/*  40 */       for (int i = offset; i < endIdx; i++) {
/*  41 */         sb.append(DIGITS[(0xF0 & bytes[i]) >>> 4]).append(DIGITS[0xF & bytes[i]]);
/*     */       }
/*     */       
/*  44 */       return sb.toString();
/*     */     } finally {
/*  46 */       sb.setLength(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(byte b) {
/*  55 */     char[] digits = { DIGITS[(0xF0 & b) >>> 4], DIGITS[0xF & b] };
/*     */     
/*  57 */     return new String(digits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(short b) {
/*  65 */     char[] digits = { DIGITS[(0xF000 & b) >>> 12], DIGITS[(0xF00 & b) >>> 8], DIGITS[(0xF0 & b) >>> 4], DIGITS[0xF & b] };
/*     */ 
/*     */     
/*  68 */     return new String(digits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(int b) {
/*  76 */     char[] digits = { DIGITS[(0xF0000000 & b) >>> 28], DIGITS[(0xF000000 & b) >>> 24], DIGITS[(0xF00000 & b) >>> 20], DIGITS[(0xF0000 & b) >>> 16], DIGITS[(0xF000 & b) >>> 12], DIGITS[(0xF00 & b) >>> 8], DIGITS[(0xF0 & b) >>> 4], DIGITS[0xF & b] };
/*     */ 
/*     */ 
/*     */     
/*  80 */     return new String(digits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(long b) {
/*  88 */     char[] digits = new char[16];
/*     */     
/*  90 */     int shift = 0;
/*  91 */     for (int i = 15; i >= 0; i--) {
/*  92 */       digits[i] = DIGITS[(int)(b >>> shift) & 0xF];
/*  93 */       shift += 4;
/*     */     } 
/*     */     
/*  96 */     return new String(digits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] fromHexString(String hex) throws NumberFormatException {
/* 104 */     int len = hex.length();
/*     */     
/* 106 */     if ((len & 0x1) != 0) {
/* 107 */       throw new NumberFormatException("Odd number of characters.");
/*     */     }
/*     */     
/* 110 */     byte[] out = new byte[len >> 1];
/*     */ 
/*     */     
/* 113 */     for (int i = 0, j = 0; j < len; i++) {
/* 114 */       int cvt = toDigit(hex.charAt(j++)) << 4 | toDigit(hex.charAt(j++));
/* 115 */       out[i] = (byte)(cvt & 0xFF);
/*     */     } 
/*     */     
/* 118 */     return out;
/*     */   }
/*     */   
/*     */   private static int toDigit(char ch) throws NumberFormatException {
/* 122 */     int digit = Character.digit(ch, 16);
/* 123 */     if (digit == -1) {
/* 124 */       throw new NumberFormatException("Illegal hexadecimal character " + ch);
/*     */     }
/* 126 */     return digit;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\HexUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */