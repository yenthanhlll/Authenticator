/*     */ package com.dreammirae.mmth.util.io;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SerializationUtils
/*     */ {
/*  24 */   private static final boolean EXIST = Boolean.TRUE.booleanValue();
/*  25 */   private static final boolean EMPTY = Boolean.FALSE.booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSafeUTF(ObjectOutputStream out, String utf) throws IOException {
/*  40 */     if (utf == null) {
/*  41 */       out.writeBoolean(EMPTY);
/*     */     } else {
/*  43 */       out.writeBoolean(EXIST);
/*  44 */       out.writeUTF(utf);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String readSafeUTF(ObjectInputStream in) throws IOException {
/*  59 */     boolean exists = in.readBoolean();
/*  60 */     if (exists)
/*  61 */       return in.readUTF(); 
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String readSafeUTF(ObjectInputStream in, String defaultValue) throws IOException {
/*  79 */     String utf = readSafeUTF(in);
/*     */     
/*  81 */     if (utf == null) {
/*  82 */       return defaultValue;
/*     */     }
/*  84 */     return utf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSafeObject(ObjectOutputStream out, Object obj) throws IOException {
/*  99 */     if (obj == null) {
/* 100 */       out.writeBoolean(EMPTY);
/*     */     } else {
/* 102 */       out.writeBoolean(EXIST);
/* 103 */       out.writeObject(obj);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSafeLong(ObjectOutputStream out, Long obj) throws IOException {
/* 119 */     if (obj == null) {
/* 120 */       out.writeBoolean(EMPTY);
/*     */     } else {
/* 122 */       out.writeBoolean(EXIST);
/* 123 */       out.writeLong(obj.longValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long readSafeLong(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 138 */     boolean exists = in.readBoolean();
/*     */     
/* 140 */     if (exists) {
/* 141 */       return Long.valueOf(in.readLong());
/*     */     }
/*     */     
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSafeInteger(ObjectOutputStream out, Integer obj) throws IOException {
/* 159 */     if (obj == null) {
/* 160 */       out.writeBoolean(EMPTY);
/*     */     } else {
/* 162 */       out.writeBoolean(EXIST);
/* 163 */       out.writeInt(obj.intValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer readSafeInt(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 178 */     boolean exists = in.readBoolean();
/*     */     
/* 180 */     if (exists) {
/* 181 */       return Integer.valueOf(in.readInt());
/*     */     }
/*     */     
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSafeShort(ObjectOutputStream out, Short obj) throws IOException {
/* 199 */     if (obj == null) {
/* 200 */       out.writeBoolean(EMPTY);
/*     */     } else {
/* 202 */       out.writeBoolean(EXIST);
/* 203 */       out.writeShort(obj.shortValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Short readSafeShort(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 218 */     boolean exists = in.readBoolean();
/*     */     
/* 220 */     if (exists) {
/* 221 */       return Short.valueOf(in.readShort());
/*     */     }
/*     */     
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSafeByte(ObjectOutputStream out, Byte obj) throws IOException {
/* 239 */     if (obj == null) {
/* 240 */       out.writeBoolean(EMPTY);
/*     */     } else {
/* 242 */       out.writeBoolean(EXIST);
/* 243 */       out.writeByte(obj.byteValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Byte readSafeByte(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 258 */     boolean exists = in.readBoolean();
/*     */     
/* 260 */     if (exists) {
/* 261 */       return Byte.valueOf(in.readByte());
/*     */     }
/*     */     
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T readSafeObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 279 */     boolean exists = in.readBoolean();
/*     */     
/* 281 */     if (exists) {
/*     */       
/* 283 */       T obj = (T)in.readObject();
/* 284 */       return obj;
/*     */     } 
/*     */     
/* 287 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] serializeObject(Object object) throws IOException {
/* 307 */     if (object == null) {
/* 308 */       throw new IllegalArgumentException("The object must not be null");
/*     */     }
/*     */     
/* 311 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 312 */     ObjectOutputStream oos = null;
/*     */     
/*     */     try {
/* 315 */       oos = new ObjectOutputStream(bos);
/* 316 */       oos.writeObject(object);
/* 317 */       return bos.toByteArray();
/* 318 */     } catch (IOException e) {
/* 319 */       throw new IOException("Error while serializaing to byte-array", e);
/*     */     } finally {
/* 321 */       closeOutputStream(oos);
/* 322 */       closeOutputStream(bos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T deserializeObject(byte[] bytes) throws IOException, ClassNotFoundException {
/* 344 */     if (bytes == null) {
/* 345 */       throw new IllegalArgumentException("The byte[] must not be null");
/*     */     }
/*     */     
/* 348 */     ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
/*     */     try {
/* 350 */       return (T)deserializeObject(bis);
/*     */     } finally {
/* 352 */       closeInputStream(bis);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T deserializeObject(InputStream is) throws IOException, ClassNotFoundException {
/* 373 */     if (is == null) {
/* 374 */       throw new IllegalArgumentException("The InputStream must not be null");
/*     */     }
/*     */     
/* 377 */     ObjectInputStream ois = null;
/*     */ 
/*     */     
/*     */     try {
/* 381 */       int len = is.available();
/* 382 */       byte[] bytes = new byte[len];
/* 383 */       is.read(bytes, 0, len);
/*     */       
/* 385 */       ois = new ObjectInputStream(new ByteArrayInputStream(bytes));
/*     */ 
/*     */       
/* 388 */       T obj = (T)ois.readObject();
/* 389 */       return obj;
/* 390 */     } catch (ClassCastException e) {
/* 391 */       throw new ClassCastException("Error deserializing object from byte-array. Cause  = " + e.getMessage());
/* 392 */     } catch (ClassNotFoundException e) {
/* 393 */       throw new ClassNotFoundException("Error deserializing object from byte-array", e);
/* 394 */     } catch (IOException e) {
/* 395 */       throw new IOException("Error deserializing object from byte-array", e);
/*     */     } finally {
/* 397 */       closeInputStream(ois);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static ByteArrayInputStream serializeObjectToInputStream(Object object) throws IOException {
/* 403 */     if (object == null) {
/* 404 */       throw new IllegalArgumentException("The object must not be null");
/*     */     }
/* 406 */     return new ByteArrayInputStream(serializeObject(object));
/*     */   }
/*     */   
/*     */   public static Object deserializeObjectInContext(InputStream is) throws IOException, ClassNotFoundException {
/* 410 */     return deserializeObjectWithClassLoader(is, Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object deserializeObjectWithClassLoader(InputStream is, ClassLoader classLoader) throws IOException, ClassNotFoundException {
/* 415 */     if (is == null) {
/* 416 */       throw new IllegalArgumentException("The InputStream must not be null");
/*     */     }
/*     */     
/* 419 */     ClassLoaderObjectInputStream cloIs = null;
/*     */     try {
/* 421 */       cloIs = new ClassLoaderObjectInputStream(is, classLoader);
/* 422 */       return cloIs.readObject();
/*     */     } finally {
/* 424 */       closeInputStream(cloIs);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] imgToRawBytes(File file) throws FileNotFoundException, IOException {
/* 438 */     FileInputStream fis = null;
/*     */     try {
/* 440 */       byte[] image = new byte[(int)file.length()];
/* 441 */       fis = new FileInputStream(file);
/* 442 */       fis.read(image);
/* 443 */       return image;
/*     */     } finally {
/* 445 */       closeInputStream(fis);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] imgToRawBytes(String path) throws FileNotFoundException, IOException {
/* 459 */     File file = new File(path.trim());
/* 460 */     return imgToRawBytes(file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean writeRawBytesToImage(byte[] rawData, String imgFilePath) throws IOException {
/* 475 */     boolean retVal = false;
/*     */     
/* 477 */     if (rawData == null || rawData.length == 0 || imgFilePath == null) {
/* 478 */       return retVal;
/*     */     }
/*     */     
/* 481 */     FileOutputStream fos = null;
/*     */ 
/*     */     
/*     */     try {
/* 485 */       fos = new FileOutputStream(imgFilePath, false);
/* 486 */       fos.write(rawData);
/*     */       
/* 488 */       fos.flush();
/* 489 */       retVal = true;
/* 490 */     } catch (IOException e) {
/* 491 */       retVal = false;
/*     */     } finally {
/* 493 */       closeOutputStream(fos);
/*     */     } 
/*     */     
/* 496 */     return retVal;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void closeOutputStream(OutputStream os) {
/* 501 */     Closer.close(os);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void closeInputStream(InputStream is) {
/* 506 */     Closer.close(is);
/*     */   }
/*     */   
/*     */   private static class ClassLoaderObjectInputStream
/*     */     extends ObjectInputStream {
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */     public ClassLoaderObjectInputStream(InputStream in, ClassLoader classLoader) throws IOException {
/* 514 */       this.classLoader = classLoader;
/*     */     }
/*     */     
/*     */     protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException {
/* 518 */       String name = desc.getName();
/*     */       try {
/* 520 */         return Class.forName(name, false, this.classLoader);
/* 521 */       } catch (ClassNotFoundException ex) {
/* 522 */         return super.resolveClass(desc);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\SerializationUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */