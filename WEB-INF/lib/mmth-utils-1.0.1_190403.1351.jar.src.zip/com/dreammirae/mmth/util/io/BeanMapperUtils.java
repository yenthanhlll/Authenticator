/*    */ package com.dreammirae.mmth.util.io;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BeanMapperUtils
/*    */ {
/*    */   public static <T> Map<String, T> beanToMap(Object obj) throws Exception {
/* 24 */     if (obj == null) {
/* 25 */       throw new IllegalArgumentException("The parameter obj not be null.");
/*    */     }
/*    */     
/* 28 */     Map<String, T> map = new HashMap<>();
/*    */     
/* 30 */     Field[] fields = obj.getClass().getDeclaredFields();
/*    */     
/* 32 */     for (Field field : fields) {
/* 33 */       field.setAccessible(true);
/*    */       
/*    */       try {
/* 36 */         T val = (T)field.get(obj);
/* 37 */         if (val != null) {
/* 38 */           map.put(field.getName(), val);
/*    */         }
/* 40 */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 41 */         throw e;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 46 */     return map;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T mapToBean(Map<String, ?> map, Class<T> clazz) throws Exception {
/* 60 */     T obj = clazz.newInstance();
/*    */     
/* 62 */     for (Map.Entry<String, ?> entry : map.entrySet()) {
/* 63 */       Field field = obj.getClass().getDeclaredField(entry.getKey());
/*    */       
/* 65 */       if (field != null) {
/* 66 */         field.setAccessible(true);
/* 67 */         field.set(obj, entry.getValue());
/*    */       } 
/*    */     } 
/*    */     
/* 71 */     return obj;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\BeanMapperUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */