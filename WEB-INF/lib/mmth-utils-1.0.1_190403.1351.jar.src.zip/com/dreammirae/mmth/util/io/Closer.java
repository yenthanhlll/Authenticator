/*     */ package com.dreammirae.mmth.util.io;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.Flushable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Closer
/*     */ {
/*     */   public static void close(ResultSet resultSet) {
/*  55 */     if (resultSet != null) {
/*     */       try {
/*  57 */         resultSet.close();
/*  58 */       } catch (SQLException sQLException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Statement statement) {
/*  72 */     if (statement != null) {
/*     */       try {
/*  74 */         statement.close();
/*  75 */       } catch (SQLException sQLException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Connection connection) {
/*  89 */     if (connection != null) {
/*     */       try {
/*  91 */         connection.close();
/*  92 */       } catch (SQLException sQLException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(ServerSocket serverSocket) {
/* 106 */     if (serverSocket != null) {
/*     */       try {
/* 108 */         serverSocket.close();
/* 109 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Socket socket) {
/* 123 */     if (socket != null) {
/*     */       try {
/* 125 */         socket.close();
/* 126 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(InputStream inputStream) {
/* 140 */     if (inputStream != null) {
/*     */       try {
/* 142 */         inputStream.close();
/* 143 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(OutputStream outputStream) {
/* 157 */     if (outputStream != null) {
/* 158 */       flush(outputStream);
/*     */       try {
/* 160 */         outputStream.close();
/* 161 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Reader reader) {
/* 175 */     if (reader != null) {
/*     */       try {
/* 177 */         reader.close();
/* 178 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Writer writer) {
/* 192 */     if (writer != null) {
/* 193 */       flush(writer);
/*     */       try {
/* 195 */         writer.close();
/* 196 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(JarFile jarFile) {
/* 210 */     if (jarFile != null) {
/*     */       try {
/* 212 */         jarFile.close();
/* 213 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Closeable closeable) {
/* 227 */     if (closeable == null) {
/*     */       return;
/*     */     }
/* 230 */     flush(closeable);
/*     */     try {
/* 232 */       closeable.close();
/* 233 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void close(Object object) {
/* 245 */     flush(object);
/* 246 */     if (object == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 250 */       Method closeMethod = object.getClass().getMethod("close", new Class[0]);
/* 251 */       closeMethod.invoke(object, new Object[0]);
/* 252 */     } catch (SecurityException securityException) {
/*     */     
/* 254 */     } catch (NoSuchMethodException noSuchMethodException) {
/*     */     
/* 256 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */     
/* 258 */     } catch (IllegalAccessException illegalAccessException) {
/*     */     
/* 260 */     } catch (InvocationTargetException invocationTargetException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void flush(Flushable flushable) {
/* 273 */     if (flushable != null) {
/*     */       try {
/* 275 */         flushable.flush();
/* 276 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void flush(Object object) {
/* 290 */     if (object == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 294 */       Method flushMethod = object.getClass().getMethod("flush", new Class[0]);
/* 295 */       flushMethod.invoke(object, new Object[0]);
/* 296 */     } catch (SecurityException securityException) {
/*     */     
/* 298 */     } catch (NoSuchMethodException noSuchMethodException) {
/*     */     
/* 300 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */     
/* 302 */     } catch (IllegalAccessException illegalAccessException) {
/*     */     
/* 304 */     } catch (InvocationTargetException invocationTargetException) {}
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\io\Closer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */