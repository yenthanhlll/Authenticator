/*    */ package com.dreammirae.mmth.util.img;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.Closer;
/*    */ import java.awt.Container;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Insets;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.swing.JEditorPane;
/*    */ import javax.swing.SwingUtilities;
/*    */ import javax.swing.text.Document;
/*    */ import javax.swing.text.html.HTMLDocument;
/*    */ import javax.swing.text.html.HTMLEditorKit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PngUtils
/*    */ {
/*    */   private static final String IMG_FORMAT_NAME = "PNG";
/*    */   private static final String IMG_CONTENT_TYPE = "text/html; charset=UTF-8";
/*    */   
/*    */   public static byte[] createImgToBytes(String contents, int width, int height) throws Exception {
/* 26 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*    */     
/*    */     try {
/* 29 */       BufferedImage img = createImgWithHTML(contents, width, height);
/* 30 */       ImageIO.write(img, "PNG", bos);
/* 31 */       bos.flush();
/* 32 */       return bos.toByteArray();
/*    */     } finally {
/* 34 */       Closer.close(bos);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static BufferedImage createImgWithHTML(String contents, int width, int height) throws Exception {
/* 39 */     JEditorPane pane = new JEditorPane();
/* 40 */     Kit kit = new Kit();
/* 41 */     pane.setEditorKit(kit);
/* 42 */     pane.setEditable(false);
/* 43 */     pane.setMargin(new Insets(0, 0, 0, 0));
/* 44 */     pane.setContentType("text/html; charset=UTF-8");
/* 45 */     pane.setText(contents);
/* 46 */     BufferedImage image = new BufferedImage(width, height, 1);
/* 47 */     Graphics g = image.createGraphics();
/* 48 */     Container c = new Container();
/* 49 */     SwingUtilities.paintComponent(g, pane, c, 0, 0, width, height);
/* 50 */     g.dispose();
/* 51 */     return image;
/*    */   }
/*    */   
/*    */   public static BufferedImage resizeImg(BufferedImage originalImage, int width, int height, int type) {
/* 55 */     BufferedImage resizedImage = new BufferedImage(width, height, type);
/* 56 */     Graphics2D g = resizedImage.createGraphics();
/* 57 */     g.drawImage(originalImage, 0, 0, width, height, null);
/* 58 */     g.dispose();
/* 59 */     return resizedImage;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Kit
/*    */     extends HTMLEditorKit
/*    */   {
/*    */     public Document createDefaultDocument() {
/* 81 */       HTMLDocument doc = (HTMLDocument)super.createDefaultDocument();
/* 82 */       doc.setTokenThreshold(2147483647);
/* 83 */       doc.setAsynchronousLoadPriority(-1);
/* 84 */       return doc;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\img\PngUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */