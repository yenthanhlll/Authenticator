/*     */ package com.dreammirae.mmth.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utf8Properties
/*     */   extends Properties
/*     */ {
/*     */   private static final long serialVersionUID = 5907218757225133892L;
/*     */   public static final String ENCODING = "UTF-8";
/*     */   private static final String COMMENT = "#!";
/*     */   private static final String keyValueSeparators = "=: \t\r\n\f";
/*     */   
/*     */   public Utf8Properties() {
/*  48 */     this((Properties)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Utf8Properties(Properties defaults) {
/*  59 */     this.defaults = defaults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void load(InputStream inStream) throws IOException {
/*  77 */     BufferedReader in = new BufferedReader(new InputStreamReader(inStream, "UTF-8"));
/*  78 */     String line = in.readLine();
/*     */     
/*  80 */     while (line != null) {
/*  81 */       line = removeWhiteSpaces(line);
/*  82 */       if (!line.equals("") && "#!".indexOf(line.charAt(0)) == -1) {
/*     */         
/*  84 */         String property = line;
/*     */         
/*  86 */         while (continueLine(line)) {
/*  87 */           property = property.substring(0, property.length() - 1);
/*  88 */           line = in.readLine();
/*  89 */           property = property + line;
/*     */         } 
/*     */ 
/*     */         
/*  93 */         if (!property.equals("")) {
/*  94 */           int endOfKey = 0;
/*     */           
/*  96 */           while (endOfKey < property.length() && "=: \t\r\n\f".indexOf(property.charAt(endOfKey)) == -1) {
/*  97 */             endOfKey++;
/*     */           }
/*  99 */           String key = property.substring(0, endOfKey);
/* 100 */           String value = property.substring(endOfKey + 1, property.length());
/*     */           
/* 102 */           key = loadConversion(key);
/* 103 */           value = loadConversion(removeWhiteSpaces(value));
/*     */           
/* 105 */           put(key, value);
/*     */         } 
/*     */       } 
/* 108 */       line = in.readLine();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeWhiteSpaces(String line) {
/* 120 */     int index = 0;
/* 121 */     while (index < line.length() && "=: \t\r\n\f".indexOf(line.charAt(index)) != -1) {
/* 122 */       index++;
/*     */     }
/* 124 */     return line.substring(index, line.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String loadConversion(String line) {
/* 136 */     StringBuffer val = new StringBuffer(line.length());
/*     */     
/* 138 */     int index = 0;
/*     */ 
/*     */ 
/*     */     
/* 142 */     for (; index < line.length(); index++) {
/* 143 */       char currentChar = line.charAt(index);
/* 144 */       if (currentChar == '\\') {
/* 145 */         int value, i; index++;
/* 146 */         currentChar = line.charAt(index);
/* 147 */         switch (currentChar) {
/*     */           case 't':
/* 149 */             currentChar = '\t';
/*     */             break;
/*     */           case 'r':
/* 152 */             currentChar = '\r';
/*     */             break;
/*     */           case 'n':
/* 155 */             currentChar = '\n';
/*     */             break;
/*     */           case 'f':
/* 158 */             currentChar = '\f';
/*     */             break;
/*     */           case 'u':
/* 161 */             index++;
/*     */             
/* 163 */             value = 0;
/* 164 */             for (i = 0; i < 4; i++) {
/* 165 */               currentChar = line.charAt(index++);
/*     */               
/* 167 */               switch (currentChar) {
/*     */                 case '0':
/*     */                 case '1':
/*     */                 case '2':
/*     */                 case '3':
/*     */                 case '4':
/*     */                 case '5':
/*     */                 case '6':
/*     */                 case '7':
/*     */                 case '8':
/*     */                 case '9':
/* 178 */                   value = (value << 4) + currentChar - 48;
/*     */                   break;
/*     */                 case 'a':
/*     */                 case 'b':
/*     */                 case 'c':
/*     */                 case 'd':
/*     */                 case 'e':
/*     */                 case 'f':
/* 186 */                   value = (value << 4) + 10 + currentChar - 97;
/*     */                   break;
/*     */                 case 'A':
/*     */                 case 'B':
/*     */                 case 'C':
/*     */                 case 'D':
/*     */                 case 'E':
/*     */                 case 'F':
/* 194 */                   value = (value << 4) + 10 + currentChar - 65;
/*     */                   break;
/*     */                 default:
/* 197 */                   throw new IllegalArgumentException("Malformed \\uxxxx encoding.");
/*     */               } 
/*     */ 
/*     */             
/*     */             } 
/* 202 */             index--;
/* 203 */             currentChar = (char)value;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 208 */       val.append(currentChar);
/*     */     } 
/*     */     
/* 211 */     return val.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String storeConversion(String line) {
/* 223 */     int length = line.length();
/* 224 */     StringBuffer outBuffer = new StringBuffer(length * 2);
/*     */     
/* 226 */     for (int i = 0; i < length; i++) {
/* 227 */       char currentChar = line.charAt(i);
/* 228 */       switch (currentChar) {
/*     */         case '\\':
/* 230 */           outBuffer.append('\\');
/* 231 */           outBuffer.append('\\');
/*     */           break;
/*     */         case '\t':
/* 234 */           outBuffer.append('\\');
/* 235 */           outBuffer.append('t');
/*     */           break;
/*     */         case '\n':
/* 238 */           outBuffer.append('\\');
/* 239 */           outBuffer.append('n');
/*     */           break;
/*     */         case '\r':
/* 242 */           outBuffer.append('\\');
/* 243 */           outBuffer.append('r');
/*     */           break;
/*     */         case '\f':
/* 246 */           outBuffer.append('\\');
/* 247 */           outBuffer.append('f');
/*     */           break;
/*     */         default:
/* 250 */           outBuffer.append(currentChar);
/*     */           break;
/*     */       } 
/*     */     } 
/* 254 */     return outBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean continueLine(String line) {
/* 267 */     if (line != null && !line.equals("")) {
/* 268 */       return (line.charAt(line.length() - 1) == '\\');
/*     */     }
/* 270 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(OutputStream out, String header) throws IOException {
/* 284 */     BufferedWriter output = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"));
/* 285 */     if (header != null) {
/* 286 */       output.write("#" + header);
/* 287 */       output.newLine();
/*     */     } 
/* 289 */     output.write("#" + new Date());
/* 290 */     output.newLine();
/*     */ 
/*     */     
/* 293 */     synchronized (this) {
/* 294 */       Enumeration<?> e = keys();
/* 295 */       while (e.hasMoreElements()) {
/* 296 */         String key = storeConversion((String)e.nextElement());
/* 297 */         String val = storeConversion((String)get(key));
/*     */         
/* 299 */         output.write(key + "=" + val);
/* 300 */         output.newLine();
/*     */       } 
/*     */     } 
/* 303 */     output.flush();
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\Utf8Properties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */