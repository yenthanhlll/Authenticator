/*    */ package com.dreammirae.mmth.util;
/*    */ 
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.Query;
/*    */ import javax.management.QueryExp;
/*    */ 
/*    */ 
/*    */ public final class EndPointUtils
/*    */ {
/*    */   public static List<String> getMyEndPoints() {
/* 17 */     List<String> endPoints = new ArrayList<>();
/*    */     
/*    */     try {
/* 20 */       MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
/*    */       
/* 22 */       QueryExp subQuery1 = Query.match(Query.attr("protocol"), Query.value("HTTP/1.1"));
/* 23 */       QueryExp subQuery2 = Query.anySubString(Query.attr("protocol"), Query.value("Http11"));
/*    */       
/* 25 */       QueryExp query = Query.or(subQuery1, subQuery2);
/*    */       
/* 27 */       Set<ObjectName> objs = mbs.queryNames(new ObjectName("*:type=Connector,*"), query);
/*    */       
/* 29 */       String[] myHosts = IPv4AddressUtils.myIpWithLoopback();
/*    */       
/* 31 */       for (Iterator<ObjectName> i = objs.iterator(); i.hasNext(); ) {
/* 32 */         ObjectName obj = i.next();
/* 33 */         String port = obj.getKeyProperty("port");
/*    */         
/* 35 */         for (String host : myHosts) {
/* 36 */           String ep = host + ":" + port;
/* 37 */           endPoints.add(ep);
/*    */         }
/*    */       
/*    */       } 
/* 41 */     } catch (Throwable e) {
/* 42 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 45 */     return endPoints;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\EndPointUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */