/*     */ package com.dreammirae.mmth.util;
/*     */ 
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import java.nio.charset.Charset;
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringUtils
/*     */ {
/*     */   private static final String STR_ELLIPSIS = "...";
/*  19 */   private static final int LEN_ELLIPSIS = "...".length();
/*  20 */   private static final Charset CS_UTF8 = Charset.forName("UTF-8");
/*     */   private static final double MULTIPLIER_B64 = 1.3333333333333333D;
/*     */   
/*     */   public static boolean isEmpty(String str) {
/*  24 */     return (str == null || trim(str).length() == 0);
/*     */   }
/*     */   
/*     */   public static String trim(String str) {
/*  28 */     return (str == null) ? null : str.trim();
/*     */   }
/*     */   
/*     */   public static String concat(Object[] params) {
/*  32 */     StringBuilder sb = new StringBuilder(255);
/*     */     
/*  34 */     for (Object obj : params) {
/*  35 */       sb.append(obj);
/*     */     }
/*     */     
/*  38 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String ellipsis(String text, int limit) {
/*  43 */     if (limit < 5) {
/*  44 */       throw new IllegalArgumentException("The text length limit must be greater than 5.");
/*     */     }
/*     */     
/*  47 */     if (isEmpty(text)) {
/*  48 */       return "";
/*     */     }
/*     */     
/*  51 */     int orgLen = text.length();
/*     */     
/*  53 */     if (orgLen <= limit) {
/*  54 */       return text;
/*     */     }
/*     */     
/*  57 */     return text.substring(0, limit - LEN_ELLIPSIS).concat("...");
/*     */   }
/*     */ 
/*     */   
/*     */   public static String utf82Hex(String utf8) {
/*  62 */     if (isEmpty(utf8)) {
/*  63 */       return "";
/*     */     }
/*     */     
/*  66 */     byte[] bytes = utf8.getBytes(CS_UTF8);
/*  67 */     return HexUtils.toHexString(bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String hex2Utf8(String hex) {
/*  72 */     if (isEmpty(hex)) {
/*  73 */       return "";
/*     */     }
/*     */     
/*  76 */     byte[] bytes = HexUtils.fromHexString(hex);
/*  77 */     return new String(bytes, CS_UTF8);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String trimUTF8(String utf8, int realLimit, boolean toBase64) {
/*  82 */     if (isEmpty(utf8)) {
/*  83 */       return "";
/*     */     }
/*     */     
/*  86 */     if (toBase64) {
/*  87 */       return utf8ToBase64(utf8, realLimit);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  94 */       byte[] bytes = utf8.getBytes(CS_UTF8);
/*     */       
/*  96 */       if (bytes.length <= realLimit) {
/*  97 */         return utf8;
/*     */       }
/*     */       
/* 100 */       String newUtf = new String(bytes, 0, realLimit - LEN_ELLIPSIS, CS_UTF8);
/* 101 */       return newUtf.substring(0, newUtf.length() - 1).concat("...");
/*     */     } finally {
/*     */       
/* 104 */       byte[] bytes = null;
/* 105 */       String newUtf = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String utf8ToBase64(String utf8, int realLimit) {
/* 111 */     if (isEmpty(utf8)) {
/* 112 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 119 */       byte[] bytes = utf8.getBytes(CS_UTF8);
/*     */       
/* 121 */       int b64Bytes = (int)Math.ceil(bytes.length * 1.3333333333333333D);
/*     */       
/* 123 */       if (b64Bytes <= realLimit) {
/* 124 */         return new String(Base64.encodeBase64URLSafe(bytes), CS_UTF8);
/*     */       }
/*     */       
/* 127 */       int regacy = (int)Math.ceil((b64Bytes - realLimit) / 1.3333333333333333D);
/*     */       
/* 129 */       String newUtf = new String(bytes, 0, bytes.length - regacy - LEN_ELLIPSIS, CS_UTF8);
/* 130 */       bytes = newUtf.substring(0, newUtf.length() - 1).concat("...").getBytes(CS_UTF8);
/*     */       
/* 132 */       return new String(Base64.encodeBase64URLSafe(bytes), CS_UTF8);
/*     */     } finally {
/* 134 */       byte[] bytes = null;
/* 135 */       String newUtf = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String ifEmpty(String srcVal, String defaultVal) {
/* 147 */     if (isEmpty(srcVal)) {
/* 148 */       return defaultVal;
/*     */     }
/* 150 */     return srcVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nullOrNot(Object src, String opt1, String opt2) {
/* 162 */     if (src == null) {
/* 163 */       return opt1;
/*     */     }
/*     */     
/* 166 */     return opt2;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\StringUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */