/*     */ package com.dreammirae.mmth.util;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IPv4AddressUtils
/*     */ {
/*     */   private static final String IPADDRESS_PATTERN = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
/*  14 */   private static String[] local_ips = null;
/*     */   
/*     */   public static boolean ipWhiteListCheck(String allowedIp, String remoteIp) throws RuntimeException {
/*  17 */     String[] remoteIpParts = remoteIp.split("\\.");
/*  18 */     if (remoteIpParts.length != 4)
/*  19 */       throw new RuntimeException("Invalid remote IP address: " + remoteIp); 
/*  20 */     return ipWhiteListCheckImpl(allowedIp, remoteIp, remoteIpParts);
/*     */   }
/*     */   
/*     */   public static boolean ipWhiteListCheck(String[] allowedIps, String remoteIp) throws RuntimeException {
/*  24 */     String[] remoteIpParts = remoteIp.split("\\.");
/*  25 */     if (remoteIpParts.length != 4) {
/*  26 */       throw new RuntimeException("Invalid remote IP address: " + remoteIp);
/*     */     }
/*  28 */     for (int i = 0; i < allowedIps.length; i++) {
/*  29 */       if (ipWhiteListCheckImpl(allowedIps[i], remoteIp, remoteIpParts)) {
/*  30 */         return true;
/*     */       }
/*     */     } 
/*  33 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean ipWhiteListCheckImpl(String allowedIp, String remoteIp, String[] remoteIpParts) throws RuntimeException {
/*  38 */     String[] allowedIpParts = allowedIp.split("\\.");
/*  39 */     if (allowedIpParts.length != 4) {
/*  40 */       throw new RuntimeException("Invalid allowed IP address: " + allowedIp);
/*     */     }
/*  42 */     return (validateIpPart(allowedIpParts[0], remoteIpParts[0], allowedIp, remoteIp) && validateIpPart(allowedIpParts[1], remoteIpParts[1], allowedIp, remoteIp) && validateIpPart(allowedIpParts[2], remoteIpParts[2], allowedIp, remoteIp) && validateIpPart(allowedIpParts[3], remoteIpParts[3], allowedIp, remoteIp));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean validateIpPart(String allowed, String remote, String allowedIp, String remoteIp) throws RuntimeException {
/*  50 */     if ("*".equals(allowed)) {
/*  51 */       return true;
/*     */     }
/*  53 */     int dash = allowed.indexOf('-');
/*     */     try {
/*  55 */       if (dash == -1) {
/*  56 */         return (Integer.parseInt(allowed) == Integer.parseInt(remote));
/*     */       }
/*  58 */       int from = Integer.parseInt(allowed.substring(0, dash));
/*  59 */       int to = Integer.parseInt(allowed.substring(dash + 1));
/*  60 */       int rem = Integer.parseInt(remote);
/*     */       
/*  62 */       return (from <= rem && rem <= to);
/*  63 */     } catch (NumberFormatException numberFormatException) {
/*     */       
/*  65 */       throw new RuntimeException("Integer parsing error. allowed=" + allowedIp + ", remote=" + remoteIp);
/*     */     } 
/*     */   }
/*     */   public static String checkIpMask(String ip) {
/*  69 */     String[] ipParts = ip.split("\\.");
/*  70 */     if (ipParts.length != 4) {
/*  71 */       return "IP address must have 4 parts";
/*     */     }
/*  73 */     String message = checkIpMaskPart(ipParts[0]);
/*  74 */     if (message != null)
/*  75 */       return message; 
/*  76 */     message = checkIpMaskPart(ipParts[1]);
/*  77 */     if (message != null)
/*  78 */       return message; 
/*  79 */     message = checkIpMaskPart(ipParts[2]);
/*  80 */     if (message != null)
/*  81 */       return message; 
/*  82 */     message = checkIpMaskPart(ipParts[3]);
/*  83 */     if (message != null) {
/*  84 */       return message;
/*     */     }
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   private static String checkIpMaskPart(String part) {
/*  90 */     if ("*".equals(part)) {
/*  91 */       return null;
/*     */     }
/*  93 */     int dash = part.indexOf('-');
/*     */     try {
/*  95 */       if (dash == -1) {
/*  96 */         int value = Integer.parseInt(part);
/*  97 */         if (value < 0 || value > 255)
/*  98 */           return "Value out of range in '" + part + "'"; 
/*     */       } else {
/* 100 */         int from = Integer.parseInt(part.substring(0, dash));
/* 101 */         if (from < 0 || from > 255) {
/* 102 */           return "'From' value out of range in '" + part + "'";
/*     */         }
/* 104 */         int to = Integer.parseInt(part.substring(dash + 1));
/* 105 */         if (to < 0 || to > 255) {
/* 106 */           return "'To' value out of range in '" + part + "'";
/*     */         }
/* 108 */         if (from > to)
/* 109 */           return "'From' value is greater than 'To' value in '" + part + "'"; 
/*     */       } 
/* 111 */     } catch (NumberFormatException e) {
/* 112 */       return "Integer parsing error in '" + part + "'";
/*     */     } 
/*     */     
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   public static byte[] toIpAddress(String addr) throws IllegalArgumentException {
/* 119 */     if (addr == null) {
/* 120 */       throw new IllegalArgumentException("Invalid address: (null)");
/*     */     }
/* 122 */     String[] parts = addr.split("\\.");
/* 123 */     if (parts.length != 4) {
/* 124 */       throw new IllegalArgumentException("IP address must have 4 parts");
/*     */     }
/* 126 */     byte[] ip = new byte[4];
/* 127 */     for (int i = 0; i < 4; i++) {
/*     */       try {
/* 129 */         int part = Integer.parseInt(parts[i]);
/* 130 */         if (part < 0 || part > 255)
/* 131 */           throw new IllegalArgumentException("Value out of range in '" + parts[i] + "'"); 
/* 132 */         ip[i] = (byte)part;
/* 133 */       } catch (NumberFormatException e) {
/* 134 */         throw new IllegalArgumentException("Integer parsing error in '" + parts[i] + "'");
/*     */       } 
/*     */     } 
/*     */     
/* 138 */     return ip;
/*     */   }
/*     */   
/*     */   public static String toIpString(byte[] b) throws IllegalArgumentException {
/* 142 */     if (b == null || b.length != 4) {
/* 143 */       throw new IllegalArgumentException("IP address must have 4 parts");
/*     */     }
/* 145 */     StringBuilder sb = new StringBuilder();
/* 146 */     sb.append(b[0] & 0xFF);
/* 147 */     for (int i = 1; i < b.length; i++)
/* 148 */       sb.append('.').append(b[i] & 0xFF); 
/* 149 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] myIps() {
/* 154 */     if (local_ips == null) {
/*     */       
/*     */       try {
/* 157 */         Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
/* 158 */         List<String> localIp = new ArrayList<>();
/* 159 */         while (en.hasMoreElements()) {
/* 160 */           NetworkInterface iface = en.nextElement();
/*     */           
/* 162 */           if (iface.isLoopback() || !iface.isUp()) {
/*     */             continue;
/*     */           }
/* 165 */           Enumeration<InetAddress> addresses = iface.getInetAddresses();
/*     */           
/* 167 */           while (addresses.hasMoreElements()) {
/* 168 */             InetAddress addr = addresses.nextElement();
/* 169 */             String ip = addr.getHostAddress();
/* 170 */             System.out.println("Local Address INFO === " + iface.getDisplayName() + " :: " + ip);
/*     */             
/* 172 */             if (ip.matches("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$")) {
/* 173 */               localIp.add(ip);
/*     */             }
/*     */           } 
/*     */         } 
/* 177 */         local_ips = localIp.<String>toArray(new String[0]);
/*     */       }
/* 179 */       catch (Exception e) {
/* 180 */         local_ips = new String[0];
/*     */       } 
/*     */     }
/*     */     
/* 184 */     return local_ips;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] myIpWithLoopback() {
/*     */     try {
/* 190 */       Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
/* 191 */       List<String> localIp = new ArrayList<>();
/* 192 */       while (en.hasMoreElements()) {
/* 193 */         NetworkInterface iface = en.nextElement();
/*     */         
/* 195 */         Enumeration<InetAddress> addresses = iface.getInetAddresses();
/*     */         
/* 197 */         while (addresses.hasMoreElements()) {
/* 198 */           InetAddress addr = addresses.nextElement();
/* 199 */           String ip = addr.getHostAddress();
/* 200 */           System.out.println("Local Address INFO === " + iface.getDisplayName() + " :: " + ip);
/*     */           
/* 202 */           if (ip.matches("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$")) {
/* 203 */             localIp.add(ip);
/*     */           }
/*     */         } 
/*     */       } 
/* 207 */       return localIp.<String>toArray(new String[0]);
/*     */     }
/* 209 */     catch (Exception e) {
/* 210 */       return new String[0];
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\IPv4AddressUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */