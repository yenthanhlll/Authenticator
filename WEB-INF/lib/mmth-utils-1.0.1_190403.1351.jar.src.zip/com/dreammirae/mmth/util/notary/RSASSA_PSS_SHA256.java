/*     */ package com.dreammirae.mmth.util.notary;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.spec.RSAPublicKeySpec;
/*     */ import org.bouncycastle.asn1.ASN1InputStream;
/*     */ import org.bouncycastle.asn1.ASN1Integer;
/*     */ import org.bouncycastle.asn1.ASN1ObjectIdentifier;
/*     */ import org.bouncycastle.asn1.ASN1Primitive;
/*     */ import org.bouncycastle.asn1.ASN1Sequence;
/*     */ import org.bouncycastle.asn1.DERBitString;
/*     */ import org.bouncycastle.asn1.DEROctetString;
/*     */ import org.bouncycastle.crypto.CryptoException;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RSASSA_PSS_SHA256
/*     */ {
/*     */   public static final String RSA_OID = "1.2.840.113549.1.1.1";
/*  39 */   private static final Provider BC = (Provider)new BouncyCastleProvider();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PublicKey getPublicKeyfromRaw(byte[] raw) throws CryptoException {
/*  53 */     if (raw == null || raw.length < 257) {
/*  54 */       throw new CryptoException("Raw 바이트 배열로부터 공개키 생성시 에러가 발생함");
/*     */     }
/*  56 */     byte[] nArr = new byte[256];
/*  57 */     byte[] eArr = new byte[raw.length - 256];
/*     */     
/*  59 */     System.arraycopy(raw, 0, nArr, 0, nArr.length);
/*  60 */     System.arraycopy(raw, nArr.length, eArr, 0, eArr.length);
/*     */     
/*  62 */     BigInteger n = new BigInteger(1, nArr);
/*  63 */     BigInteger e = new BigInteger(1, eArr);
/*     */     
/*  65 */     RSAPublicKeySpec rsaSpec = new RSAPublicKeySpec(n, e);
/*     */     
/*  67 */     PublicKey rsaPubKey = null;
/*     */     try {
/*  69 */       KeyFactory kf = KeyFactory.getInstance("RSA", BC);
/*     */       
/*  71 */       rsaPubKey = kf.generatePublic(rsaSpec);
/*  72 */     } catch (Exception e1) {
/*  73 */       throw new CryptoException("Raw 바이트 배열로부터 공개키 생성시 에러가 발생함", e1);
/*     */     } 
/*     */     
/*  76 */     return rsaPubKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PublicKey getPublicKeyfromDer(byte[] derEncoded) throws CryptoException {
/*  89 */     ASN1Sequence asn1 = null;
/*     */     try {
/*  91 */       asn1 = (ASN1Sequence)ASN1Primitive.fromByteArray(derEncoded);
/*  92 */     } catch (Exception exception) {
/*  93 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 공개키 생성시 에러가 발생함", exception);
/*     */     } 
/*     */     
/*  96 */     BigInteger n = ((ASN1Integer)asn1.getObjectAt(0)).getPositiveValue();
/*  97 */     BigInteger e = ((ASN1Integer)asn1.getObjectAt(1)).getPositiveValue();
/*     */     
/*  99 */     RSAPublicKeySpec rsaSpec = new RSAPublicKeySpec(n, e);
/*     */     
/* 101 */     PublicKey rsaPubKey = null;
/*     */     try {
/* 103 */       KeyFactory kf = KeyFactory.getInstance("RSA", BC);
/*     */       
/* 105 */       rsaPubKey = kf.generatePublic(rsaSpec);
/* 106 */     } catch (Exception e1) {
/* 107 */       throw new CryptoException("Raw 바이트 배열로부터 공개키 생성시 에러가 발생함", e1);
/*     */     } 
/*     */     
/* 110 */     return rsaPubKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getRawPublicKey(byte[] derEncoded) throws CryptoException {
/* 124 */     ASN1Sequence asn1 = null;
/*     */     try {
/* 126 */       asn1 = (ASN1Sequence)ASN1Primitive.fromByteArray(derEncoded);
/* 127 */     } catch (Exception exception) {
/* 128 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함", exception);
/*     */     } 
/*     */     
/* 131 */     if (asn1.getObjectAt(0) instanceof ASN1Sequence && asn1.getObjectAt(1) instanceof DERBitString)
/* 132 */     { ASN1Sequence algId = (ASN1Sequence)asn1.getObjectAt(0);
/*     */       
/* 134 */       if (algId.getObjectAt(0) instanceof ASN1ObjectIdentifier) {
/* 135 */         if (!((ASN1ObjectIdentifier)algId.getObjectAt(0)).toString().equals("1.2.840.113549.1.1.1"))
/* 136 */           throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함"); 
/*     */       } else {
/* 138 */         throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함");
/*     */       }  }
/* 140 */     else { throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함"); }
/*     */     
/* 142 */     DERBitString ne = (DERBitString)asn1.getObjectAt(1);
/*     */     
/* 144 */     ASN1InputStream aIn = new ASN1InputStream(ne.getBytes());
/* 145 */     Object obj = null;
/*     */     try {
/* 147 */       obj = aIn.readObject();
/* 148 */     } catch (IOException iOException) {
/* 149 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함", iOException);
/*     */     } finally {
/*     */       try {
/* 152 */         aIn.close();
/* 153 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 157 */     if (obj instanceof ASN1Sequence && ((ASN1Sequence)obj).size() == 2) {
/* 158 */       if (!(((ASN1Sequence)obj).getObjectAt(0) instanceof ASN1Integer) || !(((ASN1Sequence)obj).getObjectAt(1) instanceof ASN1Integer))
/* 159 */         throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함"); 
/*     */     } else {
/* 161 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함");
/*     */     } 
/* 163 */     BigInteger n = ((ASN1Integer)((ASN1Sequence)obj).getObjectAt(0)).getPositiveValue();
/* 164 */     BigInteger e = ((ASN1Integer)((ASN1Sequence)obj).getObjectAt(1)).getPositiveValue();
/*     */     
/* 166 */     byte[] nArr = n.toByteArray();
/* 167 */     byte[] eArr = e.toByteArray();
/*     */     
/* 169 */     byte[] raw = new byte[256 + eArr.length];
/*     */     
/* 171 */     if (nArr.length == 257 && nArr[0] == 0) {
/* 172 */       System.arraycopy(nArr, 1, raw, 0, 256);
/* 173 */       System.arraycopy(eArr, 0, raw, 256, eArr.length);
/*     */     } else {
/* 175 */       System.arraycopy(nArr, 0, raw, 0, 256);
/* 176 */       System.arraycopy(eArr, 0, raw, 256, eArr.length);
/*     */     } 
/*     */     
/* 179 */     return raw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getDerPublicKey(byte[] derEncoded) throws CryptoException {
/* 194 */     ASN1Sequence asn1 = null;
/*     */     try {
/* 196 */       asn1 = (ASN1Sequence)ASN1Primitive.fromByteArray(derEncoded);
/* 197 */     } catch (Exception e) {
/* 198 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Der 공개키 생성시 에러가 발생함", e);
/*     */     } 
/*     */     
/* 201 */     if (asn1.getObjectAt(0) instanceof ASN1Sequence && asn1.getObjectAt(1) instanceof DERBitString)
/* 202 */     { ASN1Sequence algId = (ASN1Sequence)asn1.getObjectAt(0);
/*     */       
/* 204 */       if (algId.getObjectAt(0) instanceof ASN1ObjectIdentifier) {
/* 205 */         if (!((ASN1ObjectIdentifier)algId.getObjectAt(0)).toString().equals("1.2.840.113549.1.1.1"))
/* 206 */           throw new CryptoException("DER 인코딩된 바이트 배열로부터 Der 공개키 생성시 에러가 발생함"); 
/*     */       } else {
/* 208 */         throw new CryptoException("DER 인코딩된 바이트 배열로부터 Der 공개키 생성시 에러가 발생함");
/*     */       }  }
/* 210 */     else { throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함"); }
/*     */     
/* 212 */     DERBitString ne = (DERBitString)asn1.getObjectAt(1);
/*     */     
/* 214 */     ASN1InputStream aIn = new ASN1InputStream(ne.getBytes());
/* 215 */     Object obj = null;
/*     */     try {
/* 217 */       obj = aIn.readObject();
/* 218 */     } catch (IOException e) {
/* 219 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함", e);
/*     */     } finally {
/*     */       try {
/* 222 */         aIn.close();
/* 223 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 227 */     byte[] der = null;
/*     */     try {
/* 229 */       der = ((ASN1Sequence)obj).getEncoded();
/* 230 */     } catch (IOException e1) {
/* 231 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함", e1);
/*     */     } 
/*     */     
/* 234 */     return der;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getRawSignature(byte[] derEncoded) throws CryptoException {
/* 248 */     DEROctetString sign = null;
/*     */     try {
/* 250 */       sign = (DEROctetString)ASN1Primitive.fromByteArray(derEncoded);
/* 251 */     } catch (IOException e) {
/* 252 */       throw new CryptoException("DER인코딩된 서명 값으로부터 Raw 서명 값 생성 중 에러가 발생함", e);
/*     */     } 
/*     */     
/* 255 */     return sign.getOctets();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean verify(byte[] data, byte[] sign, PublicKey publicKey) throws CryptoException {
/*     */     try {
/* 275 */       Signature signature = Signature.getInstance("SHA256withRSA/PSS", BC);
/*     */       
/* 277 */       signature.initVerify(publicKey);
/* 278 */       signature.update(data);
/*     */       
/* 280 */       return signature.verify(sign);
/* 281 */     } catch (Exception e) {
/* 282 */       throw new CryptoException("서명 검증시 에러가 발생함", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean verify(byte[] data, byte[] sign, X509Certificate certificate) throws CryptoException {
/*     */     try {
/* 303 */       Signature signature = Signature.getInstance("SHA256withRSA/PSS", BC);
/* 304 */       signature.initVerify(certificate);
/* 305 */       signature.update(data);
/*     */       
/* 307 */       return signature.verify(sign);
/* 308 */     } catch (Exception e) {
/* 309 */       throw new CryptoException("서명 검증시 에러가 발생함", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\RSASSA_PSS_SHA256.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */