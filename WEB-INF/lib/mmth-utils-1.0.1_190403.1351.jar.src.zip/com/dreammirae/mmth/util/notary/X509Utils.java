/*    */ package com.dreammirae.mmth.util.notary;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.security.Provider;
/*    */ import java.security.cert.CertificateException;
/*    */ import java.security.cert.CertificateFactory;
/*    */ import java.security.cert.X509Certificate;
/*    */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class X509Utils
/*    */ {
/* 24 */   private static final Provider BC = (Provider)new BouncyCastleProvider();
/*    */   
/*    */   public static X509Certificate parseDer(byte[] derEncodedCert) throws CertificateException {
/* 27 */     return parseDer(new ByteArrayInputStream(derEncodedCert));
/*    */   }
/*    */   
/*    */   public static X509Certificate parseDer(InputStream is) throws CertificateException {
/* 31 */     return (X509Certificate)CertificateFactory.getInstance("X.509", BC).generateCertificate(is);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\X509Utils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */