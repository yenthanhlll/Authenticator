/*    */ package com.dreammirae.mmth.util.notary;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.InvalidKeyException;
/*    */ import java.security.InvalidParameterException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.spec.InvalidKeySpecException;
/*    */ import javax.crypto.Mac;
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.crypto.SecretKeyFactory;
/*    */ import javax.crypto.spec.PBEKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMAC
/*    */ {
/*    */   private static final String SECRET_KEY_FACTORY = "PBEWithMD5AndDES";
/*    */   private static final String MAC_INSTANCE_NAME = "HmacSHA256";
/*    */   
/*    */   public static byte[] sign(String toSign, String secret) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, UnsupportedEncodingException {
/* 22 */     validateParameters(toSign, secret);
/*    */     
/* 24 */     String pwd = secret;
/* 25 */     PBEKeySpec keySpec = new PBEKeySpec(pwd.toCharArray());
/* 26 */     SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/* 27 */     SecretKey pwdKey = kf.generateSecret(keySpec);
/*    */     
/* 29 */     Mac mac = Mac.getInstance("HmacSHA256");
/* 30 */     mac.init(pwdKey);
/* 31 */     byte[] text = toSign.getBytes(CryptoConstants.CRYPTO_CHARSET);
/* 32 */     byte[] signatureBytes = mac.doFinal(text);
/*    */     
/* 34 */     return signatureBytes;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] sign(byte[] toSign, String secret) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, UnsupportedEncodingException {
/* 40 */     String pwd = secret;
/* 41 */     PBEKeySpec keySpec = new PBEKeySpec(pwd.toCharArray());
/* 42 */     SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
/* 43 */     SecretKey pwdKey = kf.generateSecret(keySpec);
/*    */     
/* 45 */     Mac mac = Mac.getInstance("HmacSHA256");
/* 46 */     mac.init(pwdKey);
/* 47 */     byte[] text = toSign;
/* 48 */     byte[] signatureBytes = mac.doFinal(text);
/*    */     
/* 50 */     return signatureBytes;
/*    */   }
/*    */   
/*    */   private static void validateParameters(String toSign, String secret) {
/* 54 */     if (toSign == null || toSign.isEmpty()) {
/* 55 */       throw new InvalidParameterException("Empty string for signing");
/*    */     }
/* 57 */     if (secret == null || secret.isEmpty())
/* 58 */       throw new InvalidParameterException("Empty secret for signing"); 
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\HMAC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */