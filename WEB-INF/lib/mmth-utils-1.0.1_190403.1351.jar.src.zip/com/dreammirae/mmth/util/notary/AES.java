/*    */ package com.dreammirae.mmth.util.notary;
/*    */ 
/*    */ import java.security.Key;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ public class AES
/*    */ {
/*    */   public static byte[] aesCbc(byte[] key, byte[] iv, byte[] input, int opmode) {
/* 12 */     byte[] output = null;
/*    */     try {
/* 14 */       Key aeskey = new SecretKeySpec(key, "AES");
/* 15 */       IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
/* 16 */       Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 17 */       cipher.init(opmode, aeskey, ivParameterSpec);
/* 18 */       output = cipher.doFinal(input);
/* 19 */     } catch (Throwable e) {
/* 20 */       e.printStackTrace();
/*    */     } 
/* 22 */     return output;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\AES.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */