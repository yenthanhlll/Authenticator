/*    */ package com.dreammirae.mmth.util.notary;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.HexUtils;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ 
/*    */ public class SHA
/*    */ {
/*    */   private static final String ALG_SHA1 = "SHA-1";
/*    */   private static final String ALG_SHA256 = "SHA-256";
/*    */   
/*    */   public static String sha1(String base) {
/* 14 */     return sha2Hex(base, "SHA-1");
/*    */   }
/*    */   
/*    */   public static byte[] sha1Raw(String base) {
/* 18 */     return sha(base, "SHA-1");
/*    */   }
/*    */   
/*    */   public static String sha256(String base) {
/* 22 */     return sha2Hex(base, "SHA-256");
/*    */   }
/*    */   
/*    */   public static byte[] sha1(byte[] base) {
/*    */     try {
/* 27 */       return sha(base, "SHA-1");
/* 28 */     } catch (NoSuchAlgorithmException e) {
/* 29 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static byte[] sha256(byte[] base) {
/*    */     try {
/* 35 */       return sha(base, "SHA-256");
/* 36 */     } catch (NoSuchAlgorithmException e) {
/* 37 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static byte[] sha256Raw(String base) {
/* 42 */     return sha(base, "SHA-256");
/*    */   }
/*    */ 
/*    */   
/*    */   public static String sha2Hex(String base, String alg) {
/* 47 */     if (base == null || base.length() == 0) {
/* 48 */       throw new RuntimeException("hash 대상 메시지는 필수입니다.");
/*    */     }
/*    */     
/*    */     try {
/* 52 */       MessageDigest digest = MessageDigest.getInstance(alg);
/* 53 */       byte[] hash = digest.digest(base.getBytes(CryptoConstants.CRYPTO_CHARSET));
/* 54 */       return HexUtils.toHexString(hash);
/* 55 */     } catch (Exception ex) {
/* 56 */       throw new RuntimeException(ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static byte[] sha(String base, String alg) {
/* 62 */     if (base == null || base.length() == 0) {
/* 63 */       throw new RuntimeException("hash 대상 메시지는 필수입니다.");
/*    */     }
/*    */     
/*    */     try {
/* 67 */       MessageDigest digest = MessageDigest.getInstance(alg);
/* 68 */       return digest.digest(base.getBytes(CryptoConstants.CRYPTO_CHARSET));
/*    */     }
/* 70 */     catch (Exception ex) {
/* 71 */       throw new RuntimeException(ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static byte[] sha(byte[] base, String alg) throws NoSuchAlgorithmException {
/* 77 */     MessageDigest digest = MessageDigest.getInstance(alg);
/* 78 */     return digest.digest(base);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\SHA.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */