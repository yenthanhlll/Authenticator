/*     */ package com.dreammirae.mmth.util.notary;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.spec.KeySpec;
/*     */ import org.bouncycastle.asn1.ASN1Encodable;
/*     */ import org.bouncycastle.asn1.ASN1EncodableVector;
/*     */ import org.bouncycastle.asn1.ASN1Integer;
/*     */ import org.bouncycastle.asn1.ASN1ObjectIdentifier;
/*     */ import org.bouncycastle.asn1.ASN1Primitive;
/*     */ import org.bouncycastle.asn1.ASN1Sequence;
/*     */ import org.bouncycastle.asn1.DERBitString;
/*     */ import org.bouncycastle.asn1.DERSequence;
/*     */ import org.bouncycastle.crypto.CryptoException;
/*     */ import org.bouncycastle.jce.ECNamedCurveTable;
/*     */ import org.bouncycastle.jce.interfaces.ECPublicKey;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec;
/*     */ import org.bouncycastle.jce.spec.ECParameterSpec;
/*     */ import org.bouncycastle.jce.spec.ECPublicKeySpec;
/*     */ import org.bouncycastle.math.ec.ECPoint;
/*     */ 
/*     */ public class SECP256R1
/*     */ {
/*  29 */   private static final Provider BC = (Provider)new BouncyCastleProvider();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ECPublicKey_OID = "1.2.840.10045.2.1";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String Prime256v1_OID = "1.2.840.10045.3.1.7";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PublicKey getPublicKeyfromRaw(byte[] raw) throws CryptoException {
/*     */     KeyFactory kf;
/*  48 */     if (raw == null || raw[0] != 4) {
/*  49 */       throw new CryptoException("Raw 바이트 배열로부터 공개키 생성시 에러가 발생함");
/*     */     }
/*     */     
/*     */     try {
/*  53 */       kf = KeyFactory.getInstance("ECDSA", BC);
/*  54 */     } catch (Exception e) {
/*  55 */       throw new CryptoException("Raw 바이트 배열로부터 공개키 생성시 에러가 발생함", e);
/*     */     } 
/*     */     
/*  58 */     ECNamedCurveParameterSpec eCNamedCurveParameterSpec = ECNamedCurveTable.getParameterSpec("secp256r1");
/*     */     
/*  60 */     ECPoint point = eCNamedCurveParameterSpec.getCurve().decodePoint(raw);
/*  61 */     ECPublicKeySpec pubSpec = new ECPublicKeySpec(point, (ECParameterSpec)eCNamedCurveParameterSpec);
/*     */     
/*  63 */     ECPublicKey ecPublicKey = null;
/*     */     try {
/*  65 */       ecPublicKey = (ECPublicKey)kf.generatePublic((KeySpec)pubSpec);
/*  66 */     } catch (Exception e) {
/*  67 */       throw new CryptoException("Raw 바이트 배열로부터 공개키 생성시 에러가 발생함", e);
/*     */     } 
/*     */     
/*  70 */     return (PublicKey)ecPublicKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getRawPublicKey(byte[] derEncoded) throws CryptoException {
/*  86 */     ASN1Sequence asn1 = null;
/*     */     try {
/*  88 */       asn1 = (ASN1Sequence)ASN1Primitive.fromByteArray(derEncoded);
/*  89 */     } catch (Exception e) {
/*  90 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함", e);
/*     */     } 
/*     */     
/*  93 */     if (asn1.getObjectAt(0) instanceof ASN1Sequence && asn1.getObjectAt(1) instanceof DERBitString) {
/*     */       
/*  95 */       ASN1Sequence algId = (ASN1Sequence)asn1.getObjectAt(0);
/*     */       
/*  97 */       if (algId.getObjectAt(0) instanceof ASN1ObjectIdentifier) {
/*  98 */         if (!((ASN1ObjectIdentifier)algId.getObjectAt(0)).toString().equals("1.2.840.10045.2.1"))
/*     */         {
/* 100 */           throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함");
/*     */         }
/* 102 */         if (!((ASN1ObjectIdentifier)algId.getObjectAt(1)).toString().equals("1.2.840.10045.3.1.7"))
/*     */         {
/* 104 */           throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함");
/*     */         }
/*     */       } else {
/* 107 */         throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함");
/*     */       } 
/*     */     } else {
/* 110 */       throw new CryptoException("DER 인코딩된 바이트 배열로부터 Raw 공개키 생성시 에러가 발생함");
/*     */     } 
/* 112 */     DERBitString ne = (DERBitString)asn1.getObjectAt(1);
/*     */     
/* 114 */     byte[] raw = ne.getBytes();
/*     */     
/* 116 */     return raw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean verify(byte[] data, byte[] sign, PublicKey publicKey) throws CryptoException {
/*     */     try {
/* 139 */       Signature signature = Signature.getInstance("SHA256withECDSA", BC);
/*     */ 
/*     */ 
/*     */       
/* 143 */       signature.initVerify(publicKey);
/* 144 */       signature.update(data);
/*     */       
/* 146 */       return signature.verify(sign);
/* 147 */     } catch (Exception e) {
/* 148 */       throw new CryptoException("서명 검증시 에러가 발생함", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getDEREncodedSignature(byte[] raw) throws CryptoException {
/* 164 */     if (raw == null || raw.length < 64) {
/* 165 */       throw new CryptoException("raw bytes length must be greater than 64.");
/*     */     }
/* 167 */     byte[] rArr = new byte[32];
/* 168 */     byte[] sArr = new byte[32];
/*     */     
/* 170 */     System.arraycopy(raw, 0, rArr, 0, rArr.length);
/* 171 */     System.arraycopy(raw, 32, sArr, 0, sArr.length);
/*     */     
/* 173 */     BigInteger r = new BigInteger(1, rArr);
/* 174 */     BigInteger s = new BigInteger(1, sArr);
/*     */     
/* 176 */     ASN1EncodableVector v = new ASN1EncodableVector();
/*     */     
/* 178 */     v.add((ASN1Encodable)new ASN1Integer(r));
/* 179 */     v.add((ASN1Encodable)new ASN1Integer(s));
/*     */     
/* 181 */     byte[] derEncoded = null;
/*     */     try {
/* 183 */       derEncoded = (new DERSequence(v)).getEncoded("DER");
/* 184 */     } catch (IOException e) {
/* 185 */       throw new CryptoException("Raw 서명으로부터 DER 인코딩된 서명 생성시 에러 발생", e);
/*     */     } 
/*     */     
/* 188 */     return derEncoded;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\SECP256R1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */