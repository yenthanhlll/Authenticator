/*     */ package com.dreammirae.mmth.util.notary;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ import org.apache.commons.codec.binary.Hex;
/*     */ 
/*     */ 
/*     */ public class TransportNotary
/*     */ {
/*     */   private static final String NOTARY_SECRET_KEY = "MIRAE-MMTH-PUBLISH-SERVICE";
/*     */   private static final String DELIMITER = ".";
/*     */   private static final byte STX = 35;
/*     */   private static final byte ETX = 94;
/*  16 */   private static final Random TR_RANDOM = new Random();
/*     */   
/*     */   private static final int LEN_RELOCATED_OFFSET = 1;
/*  19 */   private static final Charset UTF8_CS = Charset.forName("UTF-8");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String generateNotaryData(String shareKey) {
/*  25 */     if (shareKey == null || shareKey.length() < 1 || shareKey.length() > 64) {
/*  26 */       throw new IllegalArgumentException("shareKey length must be between 1 and 64.");
/*     */     }
/*     */ 
/*     */     
/*  30 */     String shareKeyToHex = Hex.encodeHexString(shareKey.getBytes(UTF8_CS));
/*     */     
/*  32 */     String target = shareKeyToHex + "." + Hex.encodeHexString(generateRandomBytes());
/*     */ 
/*     */     
/*     */     try {
/*  36 */       byte[] data = target.getBytes(UTF8_CS);
/*  37 */       byte[] relocateData = relocate(data);
/*     */ 
/*     */       
/*  40 */       byte[] signing = HMAC.sign(data, "MIRAE-MMTH-PUBLISH-SERVICE");
/*     */       
/*  42 */       int signLen = signing.length;
/*  43 */       int dataLen = relocateData.length;
/*     */ 
/*     */       
/*  46 */       int totLen = 2 + signLen + 1 + dataLen + 1;
/*     */ 
/*     */       
/*  49 */       byte[] returnData = new byte[totLen];
/*  50 */       returnData[0] = 35;
/*  51 */       returnData[1] = (byte)(signLen & 0xFF);
/*  52 */       System.arraycopy(signing, 0, returnData, 2, signLen);
/*  53 */       returnData[2 + signLen] = (byte)(dataLen & 0xFF);
/*  54 */       System.arraycopy(relocateData, 0, returnData, 2 + signLen + 1, dataLen);
/*  55 */       returnData[totLen - 1] = 94;
/*     */       
/*  57 */       return Base64.encodeBase64URLSafeString(returnData);
/*     */     }
/*  59 */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  64 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean verifyNotaryData(String shareKey, String notaryData) {
/*  70 */     if (shareKey == null || shareKey.length() < 1 || shareKey.length() > 64) {
/*  71 */       throw new IllegalArgumentException("shareKey length must be between 1 and 64.");
/*     */     }
/*     */     
/*     */     try {
/*  75 */       byte[] notaryDataBytes = Base64.decodeBase64(notaryData);
/*  76 */       int totLen = notaryDataBytes.length;
/*     */       
/*  78 */       int idx = 0;
/*  79 */       if (notaryDataBytes[idx] != 35 || notaryDataBytes[totLen - 1] != 94) {
/*  80 */         return false;
/*     */       }
/*     */ 
/*     */       
/*  84 */       int signLen = notaryDataBytes[++idx] & 0xFF;
/*  85 */       byte[] signning = new byte[signLen];
/*  86 */       System.arraycopy(notaryDataBytes, ++idx, signning, 0, signLen);
/*  87 */       idx += signLen;
/*     */ 
/*     */       
/*  90 */       int relocDataLen = notaryDataBytes[idx] & 0xFF;
/*  91 */       byte[] relocData = new byte[relocDataLen];
/*  92 */       System.arraycopy(notaryDataBytes, ++idx, relocData, 0, relocDataLen);
/*     */ 
/*     */       
/*  95 */       byte[] targetData = getTargetData(relocData);
/*     */       
/*  97 */       return MessageDigest.isEqual(signning, HMAC.sign(targetData, "MIRAE-MMTH-PUBLISH-SERVICE"));
/*  98 */     } catch (Exception e) {
/*  99 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] generateRandomBytes() {
/* 105 */     long num = System.currentTimeMillis();
/*     */     
/* 107 */     byte[] rd = new byte[8];
/* 108 */     TR_RANDOM.nextBytes(rd);
/*     */     
/* 110 */     byte[] bytes = new byte[8];
/* 111 */     bytes[0] = (byte)(int)((num ^ rd[0]) & 0xFFL);
/* 112 */     bytes[1] = (byte)(int)((num >> 8L ^ rd[1]) & 0xFFL);
/* 113 */     bytes[2] = (byte)(int)((num >> 16L ^ rd[2]) & 0xFFL);
/* 114 */     bytes[3] = (byte)(int)((num >> 24L ^ rd[3]) & 0xFFL);
/* 115 */     bytes[4] = (byte)(int)((num >> 32L ^ rd[4]) & 0xFFL);
/* 116 */     bytes[5] = (byte)(int)((num >> 40L ^ rd[5]) & 0xFFL);
/* 117 */     bytes[6] = (byte)(int)((num >> 48L ^ rd[6]) & 0xFFL);
/* 118 */     bytes[7] = (byte)(int)((num >> 56L ^ rd[7]) & 0xFFL);
/*     */     
/* 120 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] relocate(byte[] data) {
/* 125 */     int len = data.length;
/* 126 */     int newLen = len + 1;
/* 127 */     int offset = randomOffset(len);
/* 128 */     int firstLen = len - offset;
/*     */     
/* 130 */     byte[] relocData = new byte[newLen];
/*     */     
/* 132 */     System.arraycopy(data, offset, relocData, 0, firstLen);
/*     */     
/* 134 */     if (firstLen != len) {
/* 135 */       int secLen = len - firstLen;
/* 136 */       System.arraycopy(data, 0, relocData, firstLen, secLen);
/*     */     } 
/*     */     
/* 139 */     relocData[newLen - 1] = (byte)offset;
/*     */     
/* 141 */     return relocData;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] getTargetData(byte[] relocated) {
/* 146 */     int newLen = relocated.length;
/* 147 */     int len = newLen - 1;
/* 148 */     int offset = relocated[len] & 0xFF;
/*     */     
/* 150 */     byte[] data = new byte[len];
/* 151 */     int idx = len - offset;
/*     */     
/* 153 */     System.arraycopy(relocated, 0, data, offset, len - offset);
/* 154 */     System.arraycopy(relocated, idx, data, 0, offset);
/*     */     
/* 156 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int randomOffset(int limit) {
/* 161 */     if (limit < 1) {
/* 162 */       return 0;
/*     */     }
/*     */     
/* 165 */     int rnd = TR_RANDOM.nextInt(limit);
/*     */     
/* 167 */     if (rnd >= limit) {
/* 168 */       return 0;
/*     */     }
/*     */     
/* 171 */     return rnd;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 175 */     String str = "ljw_kdh_suy";
/* 176 */     str = SHA.sha1(str);
/* 177 */     System.out.println(str);
/* 178 */     str = generateNotaryData("0C1AEB0DCD1D011BCE940BCF2C9778144D03110B");
/* 179 */     System.out.println(str);
/* 180 */     System.out.println(verifyNotaryData("0C1AEB0DCD1D011BCE940BCF2C9778144D03110B", str));
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\TransportNotary.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */