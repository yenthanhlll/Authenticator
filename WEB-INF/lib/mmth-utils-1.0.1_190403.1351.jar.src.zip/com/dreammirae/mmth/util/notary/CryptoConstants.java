/*    */ package com.dreammirae.mmth.util.notary;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface CryptoConstants
/*    */ {
/* 10 */   public static final Charset CRYPTO_CHARSET = Charset.forName("UTF-8");
/*    */   public static final String ALG_ECDSA = "ECDSA";
/*    */   public static final String ALG_RSA = "RSA";
/*    */   public static final String NAMED_CURVES_ECDSA_SECP256K1 = "secp256k1";
/*    */   public static final String NAMED_CURVES_ECDSA_SECP256R1 = "secp256r1";
/*    */   public static final String SIG_ALG_RSASSA_PSS = "SHA256withRSA/PSS";
/*    */   public static final String SIG_ALG_SHA256withECDSA = "SHA256withECDSA";
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\notary\CryptoConstants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */