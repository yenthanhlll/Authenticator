package com.dreammirae.mmth.util.db;

public interface ExternalTransactionTemplate {
  void execute();
}


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\db\ExternalTransactionTemplate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */