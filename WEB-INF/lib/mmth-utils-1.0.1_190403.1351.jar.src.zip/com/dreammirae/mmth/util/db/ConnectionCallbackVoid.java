/*    */ package com.dreammirae.mmth.util.db;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.jdbc.core.ConnectionCallback;
/*    */ 
/*    */ public abstract class ConnectionCallbackVoid
/*    */   implements ConnectionCallback<Void> {
/*    */   public abstract void doInConnetion(Connection paramConnection) throws SQLException, DataAccessException;
/*    */   
/*    */   public Void doInConnection(Connection con) throws SQLException, DataAccessException {
/* 13 */     doInConnetion(con);
/* 14 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\db\ConnectionCallbackVoid.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */