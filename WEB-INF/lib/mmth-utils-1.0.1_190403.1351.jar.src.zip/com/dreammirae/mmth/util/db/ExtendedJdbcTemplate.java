/*     */ package com.dreammirae.mmth.util.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.ParameterDisposer;
/*     */ import org.springframework.jdbc.core.PreparedStatementCallback;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.RowMapperResultSetExtractor;
/*     */ import org.springframework.jdbc.support.GeneratedKeyHolder;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ public class ExtendedJdbcTemplate
/*     */   extends JdbcTemplate
/*     */ {
/*     */   public static final int SUPPORTED_DB_HSQL = 1;
/*     */   public static final int SUPPORTED_DB_ORACLE = 2;
/*     */   public static final int SUPPORTED_DB_POSTGRESQL = 3;
/*     */   public static final int SUPPORTED_DB_TIBERO = 4;
/*     */   public static final int SUPPORTED_DB_MYSQL = 5;
/*  32 */   private static final String[] DEFAULT_KEY_COLUMN_NAMES = new String[] { "id" };
/*     */   
/*     */   private final String[] generatedKeyNames;
/*     */   
/*     */   public ExtendedJdbcTemplate(int supportedDBType) {
/*  37 */     if (1 == supportedDBType || 5 == supportedDBType) {
/*  38 */       this.generatedKeyNames = null;
/*     */     } else {
/*  40 */       this.generatedKeyNames = DEFAULT_KEY_COLUMN_NAMES;
/*     */     } 
/*     */     
/*  43 */     setMaxRows(1024);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int update(PreparedStatementCreator psc, final PreparedStatementSetter pss) throws DataAccessException {
/*  49 */     this.logger.debug("Executing prepared SQL update");
/*     */     
/*  51 */     return ((Integer)execute(psc, new PreparedStatementCallback<Integer>()
/*     */         {
/*     */           public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*     */             try {
/*  55 */               if (pss != null) {
/*  56 */                 pss.setValues(ps);
/*     */               }
/*  58 */               int rows = ps.executeUpdate();
/*  59 */               if (ExtendedJdbcTemplate.this.logger.isDebugEnabled()) {
/*  60 */                 ExtendedJdbcTemplate.this.logger.debug("SQL update affected " + rows + " rows");
/*     */               }
/*  62 */               return Integer.valueOf(rows);
/*     */             } finally {
/*  64 */               if (pss instanceof ParameterDisposer) {
/*  65 */                 ((ParameterDisposer)pss).cleanupParameters();
/*     */               }
/*     */             } 
/*     */           }
/*     */         })).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update(PreparedStatementCreator psc, final PreparedStatementSetter pss, final KeyHolder generatedKeyHolder) throws DataAccessException {
/*  84 */     Assert.notNull(generatedKeyHolder, "KeyHolder must not be null");
/*  85 */     this.logger.debug("Executing SQL update and returning generated keys");
/*     */     
/*  87 */     return ((Integer)execute(psc, new PreparedStatementCallback<Integer>()
/*     */         {
/*     */           public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException
/*     */           {
/*  91 */             if (pss != null) {
/*  92 */               pss.setValues(ps);
/*     */             }
/*     */             
/*  95 */             int rows = ps.executeUpdate();
/*     */             
/*  97 */             List<Map<String, Object>> generatedKeys = generatedKeyHolder.getKeyList();
/*  98 */             generatedKeys.clear();
/*  99 */             ResultSet keys = ps.getGeneratedKeys();
/* 100 */             if (keys != null) {
/*     */               try {
/* 102 */                 RowMapperResultSetExtractor<Map<String, Object>> rse = new RowMapperResultSetExtractor(ExtendedJdbcTemplate.this.getColumnMapRowMapper(), 1);
/*     */                 
/* 104 */                 generatedKeys.addAll(rse.extractData(keys));
/*     */               } finally {
/* 106 */                 JdbcUtils.closeResultSet(keys);
/*     */               } 
/*     */             }
/* 109 */             if (ExtendedJdbcTemplate.this.logger.isDebugEnabled()) {
/* 110 */               ExtendedJdbcTemplate.this.logger.debug("SQL update affected " + rows + " rows and returned " + generatedKeys.size() + " keys");
/*     */             }
/*     */             
/* 113 */             return Integer.valueOf(rows);
/*     */           }
/*     */         })).intValue();
/*     */   }
/*     */   
/*     */   public int doInsertAndReturnIntKey(String sql, Object[] params, int[] paramTypes) {
/* 119 */     GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
/* 120 */     update(new GenKeyPreparedStatementCreator(sql, this.generatedKeyNames), newArgTypePreparedStatementSetter(params, paramTypes), (KeyHolder)keyHolder);
/*     */     
/* 122 */     return keyHolder.getKey().intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int doInsertAndReturnIntKey(String sql, Object[] params) {
/* 127 */     GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
/* 128 */     update(new GenKeyPreparedStatementCreator(sql, this.generatedKeyNames), newArgPreparedStatementSetter(params), (KeyHolder)keyHolder);
/*     */     
/* 130 */     return keyHolder.getKey().intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public long doInsertAndReturnLongKey(String sql, Object[] params, int[] paramTypes) {
/* 135 */     GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
/* 136 */     update(new GenKeyPreparedStatementCreator(sql, this.generatedKeyNames), newArgTypePreparedStatementSetter(params, paramTypes), (KeyHolder)keyHolder);
/*     */     
/* 138 */     return keyHolder.getKey().longValue();
/*     */   }
/*     */   
/*     */   public long doInsertAndReturnLongKey(String sql, Object[] params) {
/* 142 */     GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
/* 143 */     update(new GenKeyPreparedStatementCreator(sql, this.generatedKeyNames), newArgPreparedStatementSetter(params), (KeyHolder)keyHolder);
/*     */     
/* 145 */     return keyHolder.getKey().longValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> List<T> queryForList(String sql, Object[] params, RowMapper<T> rowMapper) {
/* 150 */     return query(sql, params, rowMapper);
/*     */   }
/*     */   
/*     */   public <T> List<T> queryForList(String sql, RowMapper<T> rowMapper) {
/* 154 */     return query(sql, rowMapper);
/*     */   }
/*     */   
/*     */   class GenKeyPreparedStatementCreator
/*     */     implements PreparedStatementCreator {
/*     */     private String sql;
/*     */     private String[] generatedKeyNames;
/*     */     
/*     */     public GenKeyPreparedStatementCreator(String sql, String[] generatedKeyNames) {
/* 163 */       this.sql = sql;
/* 164 */       this.generatedKeyNames = generatedKeyNames;
/*     */     }
/*     */ 
/*     */     
/*     */     public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/* 169 */       PreparedStatement ps = null;
/*     */       
/*     */       try {
/* 172 */         if (this.generatedKeyNames != null) {
/* 173 */           ps = con.prepareStatement(this.sql, this.generatedKeyNames);
/*     */         } else {
/* 175 */           ps = con.prepareStatement(this.sql, 1);
/*     */         } 
/* 177 */       } catch (AbstractMethodError e) {
/* 178 */         throw new SQLException("The JDBC driver does not support retrieval of auto-generated keys", e);
/*     */       } 
/* 180 */       return ps;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\db\ExtendedJdbcTemplate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */