/*     */ package com.dreammirae.mmth.util.cert;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.cert.CRLException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509CRL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.directory.Attribute;
/*     */ import javax.naming.directory.Attributes;
/*     */ import javax.naming.directory.DirContext;
/*     */ import javax.naming.directory.InitialDirContext;
/*     */ import org.bouncycastle.asn1.ASN1InputStream;
/*     */ import org.bouncycastle.asn1.ASN1Primitive;
/*     */ import org.bouncycastle.asn1.DERIA5String;
/*     */ import org.bouncycastle.asn1.DEROctetString;
/*     */ import org.bouncycastle.asn1.x509.CRLDistPoint;
/*     */ import org.bouncycastle.asn1.x509.DistributionPoint;
/*     */ import org.bouncycastle.asn1.x509.DistributionPointName;
/*     */ import org.bouncycastle.asn1.x509.Extension;
/*     */ import org.bouncycastle.asn1.x509.GeneralName;
/*     */ import org.bouncycastle.asn1.x509.GeneralNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRLVerifier
/*     */ {
/*     */   public static void verifyCertificateCRLs(X509Certificate cert) throws CertificateVerificationException {
/*     */     try {
/*  39 */       List<String> crlDistPoints = getCrlDistributionPoints(cert);
/*  40 */       for (String crlDP : crlDistPoints) {
/*  41 */         X509CRL crl = downloadCRL(crlDP);
/*  42 */         if (crl.isRevoked(cert)) {
/*  43 */           throw new CertificateVerificationException("The certificate is revoked by CRL: " + crlDP);
/*     */         }
/*     */       } 
/*  46 */     } catch (Exception ex) {
/*  47 */       if (ex instanceof CertificateVerificationException) {
/*  48 */         throw (CertificateVerificationException)ex;
/*     */       }
/*  50 */       throw new CertificateVerificationException("Can not verify CRL for certificate: " + cert.getSubjectX500Principal());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static X509CRL downloadCRL(String crlURL) throws IOException, CertificateException, CRLException, CertificateVerificationException, NamingException {
/*  61 */     if (crlURL.startsWith("http://") || crlURL.startsWith("https://") || crlURL.startsWith("ftp://")) {
/*  62 */       X509CRL crl = downloadCRLFromWeb(crlURL);
/*  63 */       return crl;
/*  64 */     }  if (crlURL.startsWith("ldap://")) {
/*  65 */       X509CRL crl = downloadCRLFromLDAP(crlURL);
/*  66 */       return crl;
/*     */     } 
/*  68 */     throw new CertificateVerificationException("Can not download CRL from certificate distribution point: " + crlURL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static X509CRL downloadCRLFromLDAP(String ldapURL) throws CertificateException, NamingException, CRLException, CertificateVerificationException {
/*  75 */     Hashtable<String, String> env = new Hashtable<>();
/*  76 */     env.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
/*  77 */     env.put("java.naming.provider.url", ldapURL);
/*     */     
/*  79 */     DirContext ctx = new InitialDirContext(env);
/*  80 */     Attributes avals = ctx.getAttributes("");
/*  81 */     Attribute aval = avals.get("certificateRevocationList;binary");
/*  82 */     byte[] val = (byte[])aval.get();
/*  83 */     if (val == null || val.length == 0) {
/*  84 */       throw new CertificateVerificationException("Can not download CRL from: " + ldapURL);
/*     */     }
/*  86 */     InputStream inStream = new ByteArrayInputStream(val);
/*  87 */     CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*  88 */     X509CRL crl = (X509CRL)cf.generateCRL(inStream);
/*  89 */     return crl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static X509CRL downloadCRLFromWeb(String crlURL) throws MalformedURLException, IOException, CertificateException, CRLException {
/*  98 */     URL url = new URL(crlURL);
/*  99 */     InputStream crlStream = url.openStream();
/*     */     try {
/* 101 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 102 */       X509CRL crl = (X509CRL)cf.generateCRL(crlStream);
/* 103 */       return crl;
/*     */     } finally {
/* 105 */       crlStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getCrlDistributionPoints(X509Certificate cert) throws CertificateParsingException, IOException {
/* 117 */     byte[] crldpExt = cert.getExtensionValue(Extension.cRLDistributionPoints.getId());
/* 118 */     if (crldpExt == null) {
/* 119 */       List<String> emptyList = new ArrayList<>();
/* 120 */       return emptyList;
/*     */     } 
/* 122 */     ASN1InputStream oAsnInStream = new ASN1InputStream(new ByteArrayInputStream(crldpExt));
/* 123 */     ASN1Primitive aSN1Primitive1 = oAsnInStream.readObject();
/* 124 */     DEROctetString dosCrlDP = (DEROctetString)aSN1Primitive1;
/* 125 */     byte[] crldpExtOctets = dosCrlDP.getOctets();
/* 126 */     ASN1InputStream oAsnInStream2 = new ASN1InputStream(new ByteArrayInputStream(crldpExtOctets));
/* 127 */     ASN1Primitive aSN1Primitive2 = oAsnInStream2.readObject();
/* 128 */     CRLDistPoint distPoint = CRLDistPoint.getInstance(aSN1Primitive2);
/* 129 */     List<String> crlUrls = new ArrayList<>();
/* 130 */     for (DistributionPoint dp : distPoint.getDistributionPoints()) {
/* 131 */       DistributionPointName dpn = dp.getDistributionPoint();
/*     */       
/* 133 */       if (dpn != null && 
/* 134 */         dpn.getType() == 0) {
/* 135 */         GeneralName[] genNames = GeneralNames.getInstance(dpn.getName()).getNames();
/*     */         
/* 137 */         for (int j = 0; j < genNames.length; j++) {
/* 138 */           if (genNames[j].getTagNo() == 6) {
/* 139 */             String url = DERIA5String.getInstance(genNames[j].getName()).getString();
/* 140 */             crlUrls.add(url);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 146 */     return crlUrls;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\cert\CRLVerifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */