/*    */ package com.dreammirae.mmth.util.cert;
/*    */ 
/*    */ public class CertificateVerificationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public CertificateVerificationException() {}
/*    */   
/*    */   public CertificateVerificationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 11 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */   
/*    */   public CertificateVerificationException(String message, Throwable cause) {
/* 15 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public CertificateVerificationException(String message) {
/* 19 */     super(message);
/*    */   }
/*    */   
/*    */   public CertificateVerificationException(Throwable cause) {
/* 23 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\cert\CertificateVerificationException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */