/*     */ package com.dreammirae.mmth.util.cert;
/*     */ 
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.CertPathBuilder;
/*     */ import java.security.cert.CertPathBuilderException;
/*     */ import java.security.cert.CertStore;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CollectionCertStoreParameters;
/*     */ import java.security.cert.PKIXBuilderParameters;
/*     */ import java.security.cert.PKIXCertPathBuilderResult;
/*     */ import java.security.cert.TrustAnchor;
/*     */ import java.security.cert.X509CertSelector;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ 
/*     */ 
/*     */ public final class CertificateVerifier
/*     */ {
/*  27 */   private static final Provider BC = (Provider)new BouncyCastleProvider();
/*     */ 
/*     */   
/*     */   public static PKIXCertPathBuilderResult verifyCertificate(X509Certificate cert, Set<X509Certificate> additionalCerts) throws CertificateVerificationException {
/*     */     try {
/*  32 */       if (isSelfSigned(cert)) {
/*  33 */         throw new CertificateVerificationException("The certificate is self-signed.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  39 */       Set<X509Certificate> trustedRootCerts = new HashSet<>();
/*  40 */       Set<X509Certificate> intermediateCerts = new HashSet<>();
/*  41 */       for (X509Certificate additionalCert : additionalCerts) {
/*  42 */         if (isSelfSigned(additionalCert)) {
/*  43 */           trustedRootCerts.add(additionalCert); continue;
/*     */         } 
/*  45 */         intermediateCerts.add(additionalCert);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  50 */       PKIXCertPathBuilderResult verifiedCertChain = verifyCertificate(cert, trustedRootCerts, intermediateCerts);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  55 */       CRLVerifier.verifyCertificateCRLs(cert);
/*     */ 
/*     */       
/*  58 */       return verifiedCertChain;
/*  59 */     } catch (CertPathBuilderException certPathEx) {
/*  60 */       throw new CertificateVerificationException("Error building certification path: " + cert.getSubjectX500Principal(), certPathEx);
/*     */     
/*     */     }
/*  63 */     catch (CertificateVerificationException cvex) {
/*  64 */       throw cvex;
/*  65 */     } catch (Exception ex) {
/*  66 */       throw new CertificateVerificationException("Error verifying the certificate: " + cert.getSubjectX500Principal(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSelfSigned(X509Certificate cert) throws CertificateException, NoSuchAlgorithmException, NoSuchProviderException {
/*     */     try {
/*  80 */       PublicKey key = cert.getPublicKey();
/*  81 */       cert.verify(key);
/*  82 */       return true;
/*  83 */     } catch (SignatureException sigEx) {
/*     */       
/*  85 */       return false;
/*  86 */     } catch (InvalidKeyException keyEx) {
/*     */       
/*  88 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static PKIXCertPathBuilderResult verifyCertificate(X509Certificate cert, Set<X509Certificate> trustedRootCerts, Set<X509Certificate> intermediateCerts) throws GeneralSecurityException {
/*  96 */     X509CertSelector selector = new X509CertSelector();
/*  97 */     selector.setCertificate(cert);
/*     */ 
/*     */     
/* 100 */     Set<TrustAnchor> trustAnchors = new HashSet<>();
/* 101 */     for (X509Certificate trustedRootCert : trustedRootCerts) {
/* 102 */       trustAnchors.add(new TrustAnchor(trustedRootCert, null));
/*     */     }
/*     */ 
/*     */     
/* 106 */     PKIXBuilderParameters pkixParams = new PKIXBuilderParameters(trustAnchors, selector);
/*     */ 
/*     */ 
/*     */     
/* 110 */     pkixParams.setRevocationEnabled(false);
/*     */ 
/*     */     
/* 113 */     CertStore intermediateCertStore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(intermediateCerts), BC);
/*     */     
/* 115 */     pkixParams.addCertStore(intermediateCertStore);
/*     */ 
/*     */     
/* 118 */     CertPathBuilder builder = CertPathBuilder.getInstance("PKIX", BC);
/* 119 */     PKIXCertPathBuilderResult result = (PKIXCertPathBuilderResult)builder.build(pkixParams);
/*     */     
/* 121 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\cert\CertificateVerifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */