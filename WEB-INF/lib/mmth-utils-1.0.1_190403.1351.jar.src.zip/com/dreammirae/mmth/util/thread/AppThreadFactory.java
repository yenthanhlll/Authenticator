/*    */ package com.dreammirae.mmth.util.thread;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppThreadFactory
/*    */   implements ThreadFactory
/*    */ {
/*    */   private final String threadName;
/*    */   private boolean doThreadDebug = false;
/*    */   
/*    */   public AppThreadFactory(String thdName) {
/* 14 */     this.threadName = thdName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Thread newThread(Runnable runnable) {
/* 22 */     return makeAppThread(runnable, this.threadName);
/*    */   }
/*    */   
/*    */   private AppThread makeAppThread(Runnable runnable, String threadName) {
/* 26 */     AppThread myThread = new AppThread(runnable, threadName);
/* 27 */     AppThread.setDebug(this.doThreadDebug);
/* 28 */     return myThread;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getDoThreadDebug() {
/* 35 */     return this.doThreadDebug;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDoThreadDebug(boolean doThreadDebug) {
/* 42 */     this.doThreadDebug = doThreadDebug;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getThreadName() {
/* 49 */     return this.threadName;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\thread\AppThreadFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */