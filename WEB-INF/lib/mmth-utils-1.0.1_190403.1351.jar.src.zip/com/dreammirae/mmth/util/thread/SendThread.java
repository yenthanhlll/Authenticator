/*    */ package com.dreammirae.mmth.util.thread;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public abstract class SendThread
/*    */   extends Thread implements ILifecycle {
/*  8 */   private static final Logger LOG = LoggerFactory.getLogger(SendThread.class);
/*    */ 
/*    */   
/*    */   private boolean isRunning;
/*    */ 
/*    */ 
/*    */   
/*    */   public SendThread(String threadName) {
/* 16 */     super(threadName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize() {
/* 23 */     start();
/* 24 */     this.isRunning = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void terminate() {
/* 31 */     this.isRunning = false;
/* 32 */     notify();
/*    */   }
/*    */   
/*    */   protected boolean isRunning() {
/* 36 */     return this.isRunning;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void joinTermination() {
/*    */     try {
/* 44 */       join(500L);
/* 45 */     } catch (InterruptedException interruptedException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     try {
/* 53 */       runImpl();
/* 54 */     } catch (Exception e) {
/* 55 */       LOG.error("SendThread " + getName() + " failed with an exception", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void waitImpl(long time) {
/* 64 */     synchronized (this) {
/*    */       try {
/* 66 */         wait(time);
/* 67 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void runImpl();
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\thread\SendThread.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */