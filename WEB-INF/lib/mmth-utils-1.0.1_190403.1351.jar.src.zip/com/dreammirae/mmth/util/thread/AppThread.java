/*    */ package com.dreammirae.mmth.util.thread;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class AppThread
/*    */   extends Thread
/*    */ {
/* 10 */   private static final Logger LOG = LoggerFactory.getLogger(AppThread.class);
/*    */   
/*    */   public static final String DEFAULT_NAME = "MMTH_appThread";
/*    */   private static volatile boolean debugLifecycle = false;
/* 14 */   private static final AtomicInteger created = new AtomicInteger();
/* 15 */   private static final AtomicInteger alive = new AtomicInteger();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AppThread(Runnable r) {
/* 21 */     this(r, "MMTH_appThread");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AppThread(Runnable runnable, String threadName) {
/* 28 */     super(runnable, threadName + "-" + created.incrementAndGet());
/* 29 */     setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
/*    */           public void uncaughtException(Thread t, Throwable e) {
/* 31 */             AppThread.LOG.warn("UNCAUGHT in thread " + t.getName(), e);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 39 */     boolean debug = debugLifecycle;
/* 40 */     if (debug) LOG.debug("Created " + getName()); 
/*    */     try {
/* 42 */       alive.incrementAndGet();
/* 43 */       super.run();
/*    */     } finally {
/* 45 */       alive.decrementAndGet();
/* 46 */       if (debug) LOG.debug("Exiting " + getName()); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static int getThreadsCreated() {
/* 51 */     return created.get();
/*    */   }
/*    */   
/*    */   public static int getThreadsAlive() {
/* 55 */     return alive.get();
/*    */   }
/*    */   
/*    */   public static boolean getDebug() {
/* 59 */     return debugLifecycle;
/*    */   }
/*    */   
/*    */   public static void setDebug(boolean b) {
/* 63 */     debugLifecycle = b;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\thread\AppThread.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */