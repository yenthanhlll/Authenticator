/*    */ package com.dreammirae.mmth.util.thread;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MessageExecutor
/*    */   extends Thread
/*    */ {
/* 14 */   private static final Logger LOG = LoggerFactory.getLogger(MessageExecutor.class);
/*    */   
/*    */   private static final long DEFAULT_WAIT_AND_SEE_TS = 60000L;
/*    */   
/*    */   private volatile boolean waitAndSee;
/*    */   
/*    */   private volatile boolean stopRunning;
/*    */   
/* 22 */   private long waitAndSeeTs = 60000L;
/*    */   
/*    */   public MessageExecutor(String threadName) {
/* 25 */     super(threadName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setWaitAndSeeTs(long waitAndSeeTs) {
/* 30 */     this.waitAndSeeTs = waitAndSeeTs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     do {
/*    */       try {
/* 39 */         runImp();
/* 40 */       } catch (Exception e) {
/* 41 */         LOG.warn("Error occured. ThreadName=" + getName(), e);
/*    */       } 
/*    */       
/* 44 */       if (this.stopRunning) {
/*    */         break;
/*    */       }
/*    */ 
/*    */       
/* 49 */       waitImp(this.waitAndSeeTs);
/*    */     }
/* 51 */     while (!this.stopRunning);
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract void runImp();
/*    */   
/*    */   private void waitImp(long timeout) {
/* 58 */     synchronized (this) {
/*    */       try {
/* 60 */         this.waitAndSee = true;
/* 61 */         wait(timeout);
/* 62 */       } catch (InterruptedException interruptedException) {}
/*    */ 
/*    */ 
/*    */       
/* 66 */       if (LOG.isDebugEnabled()) {
/* 67 */         LOG.debug("Time to wake up.");
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   protected boolean isStopRunning() {
/* 73 */     return this.stopRunning;
/*    */   }
/*    */   
/*    */   public synchronized void wakeUp() {
/* 77 */     if (!this.waitAndSee) {
/*    */       return;
/*    */     }
/*    */     
/* 81 */     notify();
/*    */   }
/*    */   
/*    */   public void stopRunning() {
/* 85 */     this.stopRunning = true;
/* 86 */     wakeUp();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\thread\MessageExecutor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */