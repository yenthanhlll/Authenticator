/*    */ package com.dreammirae.mmth.util.thread;
/*    */ 
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ThreadMonitor
/*    */   implements Runnable
/*    */ {
/* 10 */   private static final Logger LOG = LoggerFactory.getLogger(ThreadMonitor.class);
/*    */   
/*    */   private final ThreadPoolExecutor executor;
/*    */   private final long delay;
/*    */   private volatile boolean run = true;
/*    */   
/*    */   public ThreadMonitor(ThreadPoolExecutor executor, long delay) {
/* 17 */     this.executor = executor;
/* 18 */     this.delay = delay;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 23 */     while (this.run) {
/* 24 */       LOG.info(String.format("[monitor] [%d/%d] Active: %d, Completed: %d, Task: %d, isShutdown: %s, isTerminated: %s", new Object[] { Integer.valueOf(this.executor.getPoolSize()), Integer.valueOf(this.executor.getCorePoolSize()), Integer.valueOf(this.executor.getActiveCount()), Long.valueOf(this.executor.getCompletedTaskCount()), Long.valueOf(this.executor.getTaskCount()), Boolean.valueOf(this.executor.isShutdown()), Boolean.valueOf(this.executor.isTerminated()) }));
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       try {
/* 30 */         Thread.sleep(this.delay);
/* 31 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void shutdown() {
/* 39 */     this.run = false;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmt\\util\thread\ThreadMonitor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */