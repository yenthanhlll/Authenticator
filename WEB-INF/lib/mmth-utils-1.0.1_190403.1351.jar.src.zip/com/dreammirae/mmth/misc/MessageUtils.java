/*    */ package com.dreammirae.mmth.misc;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import java.util.Locale;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.support.ResourceBundleMessageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageUtils
/*    */ {
/* 13 */   private static ResourceBundleMessageSource messageSource = null;
/*    */   static {
/* 15 */     messageSource = new ResourceBundleMessageSource();
/* 16 */     messageSource.setDefaultEncoding(SysEnvCommon.UTF8_CS.displayName());
/*    */     
/*    */     try {
/* 19 */       URL url = MessageUtils.class.getClassLoader().getResource("countryCode");
/* 20 */       File f = new File(url.toURI());
/* 21 */       if (f.exists()) {
/* 22 */         messageSource.setBasenames(new String[] { "messages/messages", "countryCode/ISO_3166_1" });
/*    */       } else {
/* 24 */         messageSource.setBasename("messages/messages");
/*    */       } 
/* 26 */     } catch (Exception e) {
/* 27 */       messageSource.setBasename("messages/messages");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getMessage(I18nMessage message, Locale locale) {
/* 35 */     MessageSource bundle = getMessageSource();
/*    */     
/* 37 */     if (bundle != null) {
/* 38 */       return I18nMessage.generateMessage(bundle, message, locale);
/*    */     }
/*    */     
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   public static MessageSource getMessageSource() {
/* 45 */     return (MessageSource)messageSource;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmth\misc\MessageUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */