/*    */ package com.dreammirae.mmth.misc;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ import org.springframework.stereotype.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Component
/*    */ public class I18nMessageSerializer
/*    */   extends JsonSerializer<I18nMessage>
/*    */ {
/*    */   @Autowired
/*    */   private MessageSource messageSource;
/*    */   
/*    */   public void serialize(I18nMessage message, JsonGenerator jsonGen, SerializerProvider provider) throws IOException {
/* 23 */     jsonGen.writeString(I18nMessage.generateMessage(this.messageSource, message, LocaleContextHolder.getLocale()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<I18nMessage> handledType() {
/* 28 */     return I18nMessage.class;
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmth\misc\I18nMessageSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */