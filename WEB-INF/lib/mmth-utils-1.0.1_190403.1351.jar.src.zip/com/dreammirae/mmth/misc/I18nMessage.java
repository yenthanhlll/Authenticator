/*    */ package com.dreammirae.mmth.misc;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*    */ import java.util.Locale;
/*    */ import org.springframework.context.MessageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JsonSerialize(using = I18nMessageSerializer.class)
/*    */ public class I18nMessage
/*    */ {
/*    */   private String messageKey;
/*    */   private Object[] args;
/*    */   
/*    */   public I18nMessage(String messageKey) {
/* 16 */     this.messageKey = messageKey;
/*    */   }
/*    */   
/*    */   public I18nMessage(String messageKey, Object... args) {
/* 20 */     this.messageKey = messageKey;
/* 21 */     this.args = args;
/*    */   }
/*    */   
/*    */   public String getMessageKey() {
/* 25 */     return this.messageKey;
/*    */   }
/*    */   
/*    */   public Object[] getArgs() {
/* 29 */     return this.args;
/*    */   }
/*    */ 
/*    */   
/*    */   public static String generateMessage(MessageSource messageSource, I18nMessage message, Locale locale) {
/* 34 */     Object[] newArgs = i18nArgs(messageSource, message.getArgs(), locale);
/* 35 */     return messageSource.getMessage(message.getMessageKey(), newArgs, locale);
/*    */   }
/*    */ 
/*    */   
/*    */   private static Object[] i18nArgs(MessageSource messageSource, Object[] args, Locale locale) {
/* 40 */     if (args == null || args.length < 1) {
/* 41 */       return null;
/*    */     }
/*    */     
/* 44 */     Object[] newArgs = new Object[args.length];
/*    */     
/* 46 */     for (int i = 0; i < args.length; i++) {
/*    */       
/* 48 */       Object obj = args[i];
/*    */       
/* 50 */       if (obj instanceof I18nMessage) {
/* 51 */         obj = getMessage(messageSource, (I18nMessage)obj, locale);
/*    */       }
/*    */       
/* 54 */       newArgs[i] = obj;
/*    */     } 
/*    */     
/* 57 */     return newArgs;
/*    */   }
/*    */ 
/*    */   
/*    */   private static String getMessage(MessageSource messageSource, I18nMessage i18n, Locale locale) {
/* 62 */     if (i18n.getArgs() == null) {
/* 63 */       return messageSource.getMessage(i18n.getMessageKey(), null, locale);
/*    */     }
/*    */     
/* 66 */     Object[] args = i18n.getArgs();
/* 67 */     Object[] newArgs = new Object[args.length];
/*    */     
/* 69 */     for (int i = 0; i < args.length; i++) {
/*    */       
/* 71 */       Object obj = args[i];
/*    */       
/* 73 */       if (obj instanceof I18nMessage) {
/* 74 */         obj = getMessage(messageSource, (I18nMessage)obj, locale);
/*    */       }
/*    */       
/* 77 */       newArgs[i] = obj;
/*    */     } 
/*    */     
/* 80 */     return messageSource.getMessage(i18n.getMessageKey(), newArgs, locale);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmth\misc\I18nMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */