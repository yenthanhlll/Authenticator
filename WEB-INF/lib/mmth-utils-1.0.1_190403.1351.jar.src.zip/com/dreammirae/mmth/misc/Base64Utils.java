/*    */ package com.dreammirae.mmth.misc;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.codec.binary.Base64;
/*    */ 
/*    */ 
/*    */ public final class Base64Utils
/*    */ {
/*  9 */   private static final Pattern P_HEX = Pattern.compile("^[0-9a-fA-F]+$");
/*    */   
/*    */   public static boolean isBase64(String encData) {
/* 12 */     boolean check = Base64.isBase64(encData);
/*    */     
/* 14 */     if (check && 
/* 15 */       P_HEX.matcher(encData).matches()) {
/* 16 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 20 */     return check;
/*    */   }
/*    */   
/*    */   public static String encodeUrl(String data) {
/* 24 */     return Base64.encodeBase64URLSafeString(SysEnvCommon.getUtf8Bytes(data));
/*    */   }
/*    */   
/*    */   public static String encodeUrl(byte[] data) {
/* 28 */     return Base64.encodeBase64URLSafeString(data);
/*    */   }
/*    */   
/*    */   public static String encode(String data) {
/* 32 */     return Base64.encodeBase64String(SysEnvCommon.getUtf8Bytes(data));
/*    */   }
/*    */   
/*    */   public static String encode(byte[] data) {
/* 36 */     return Base64.encodeBase64String(data);
/*    */   }
/*    */   
/*    */   public static byte[] encodeUrlRaw(String data) {
/* 40 */     return encodeUrlRaw(SysEnvCommon.getUtf8Bytes(data));
/*    */   }
/*    */   
/*    */   public static byte[] encodeUrlRaw(byte[] data) {
/* 44 */     return SysEnvCommon.getUtf8Bytes(Base64.encodeBase64URLSafeString(data));
/*    */   }
/*    */   
/*    */   public static byte[] encodeRaw(String data) {
/* 48 */     return encodeRaw(SysEnvCommon.getUtf8Bytes(data));
/*    */   }
/*    */   
/*    */   public static byte[] encodeRaw(byte[] data) {
/* 52 */     return Base64.encodeBase64(data);
/*    */   }
/*    */   
/*    */   public static String decode(String encData) {
/* 56 */     return SysEnvCommon.toUtf8(Base64.decodeBase64(encData));
/*    */   }
/*    */   
/*    */   public static String decode(byte[] encData) {
/* 60 */     return SysEnvCommon.toUtf8(Base64.decodeBase64(encData));
/*    */   }
/*    */   
/*    */   public static byte[] decodeRaw(String encData) {
/* 64 */     return Base64.decodeBase64(encData);
/*    */   }
/*    */   
/*    */   public static byte[] decodeRaw(byte[] encData) {
/* 68 */     return Base64.decodeBase64(encData);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmth\misc\Base64Utils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */