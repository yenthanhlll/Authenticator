/*     */ package com.dreammirae.mmth.misc;
/*     */ 
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.EndianUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.security.crypto.bcrypt.BCrypt;
/*     */ import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
/*     */ import org.springframework.security.crypto.encrypt.Encryptors;
/*     */ import org.springframework.security.crypto.encrypt.TextEncryptor;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SysEnvCommon
/*     */ {
/*  20 */   private static final byte[] RANDOM_ID_SUFFIX = new byte[] { 77, 77, 84, 72 };
/*  21 */   private static final Random COMMONS_RANDOM = new Random();
/*     */   
/*     */   private static final int LEN_TID_RANDOM = 4;
/*     */   
/*     */   private static final int LEN_TID_SUFFIX = 4;
/*     */   private static final int LEN_MILLIS = 8;
/*     */   private static final int LEN_TID = 16;
/*  28 */   public static final Charset UTF8_CS = Charset.forName("UTF-8");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ENC_PASSWORD = "MMTH_CRYPTO_SYMM";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ENC_SALT = "27418991fc927f24";
/*     */ 
/*     */   
/*  39 */   private static final TextEncryptor encryptor = Encryptors.text("MMTH_CRYPTO_SYMM", "27418991fc927f24");
/*     */ 
/*     */   
/*  42 */   private static final PasswordEncoder PWD_ENCODER = (PasswordEncoder)new BCryptPasswordEncoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encPassword(String rawPwd) {
/*  51 */     return PWD_ENCODER.encode(rawPwd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean passwordMatches(String rawPwd, String encPwd) {
/*  62 */     return PWD_ENCODER.matches(rawPwd, encPwd);
/*     */   }
/*     */   
/*     */   public static PasswordEncoder getPwdEncoder() {
/*  66 */     return PWD_ENCODER;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String encryptText(String rawText) {
/*  71 */     if (StringUtils.isEmpty(rawText)) {
/*  72 */       throw new IllegalArgumentException("Arg [rawText] is not null or empty");
/*     */     }
/*     */     
/*  75 */     return encryptor.encrypt(rawText);
/*     */   }
/*     */   
/*     */   public static String decryptText(String encText) {
/*  79 */     if (StringUtils.isEmpty(encText)) {
/*  80 */       throw new IllegalArgumentException("Arg [encText] is not null or empty");
/*     */     }
/*     */     
/*  83 */     return encryptor.decrypt(encText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String generateTID() {
/*  98 */     byte[] current = currentMillisBytes();
/*  99 */     byte[] random = randomBytes(4);
/*     */     
/* 101 */     byte[] result = new byte[16];
/* 102 */     System.arraycopy(current, 0, result, 0, 8);
/* 103 */     System.arraycopy(RANDOM_ID_SUFFIX, 0, result, 8, 4);
/* 104 */     System.arraycopy(random, 0, result, 12, 4);
/*     */     
/* 106 */     return HexUtils.toHexString(result);
/*     */   }
/*     */   
/*     */   public static String generateChallenge() {
/* 110 */     return BCrypt.gensalt();
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] randomBytes(int size) {
/* 115 */     if (size < 1) {
/* 116 */       return new byte[0];
/*     */     }
/*     */     
/* 119 */     byte[] rd = new byte[size];
/* 120 */     COMMONS_RANDOM.nextBytes(rd);
/* 121 */     return rd;
/*     */   }
/*     */   
/*     */   public static byte[] currentMillisBytes() {
/* 125 */     return EndianUtils.long2Bytes_ByLittleEndian(System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   public static void setSysEnvProperty(String key, Object value) {
/* 129 */     SYS_ENV_PROP.put(key, value);
/*     */   }
/*     */   
/*     */   public static Object getSysEnvProperty(String key) {
/* 133 */     return SYS_ENV_PROP.get(key);
/*     */   }
/*     */   
/*     */   public static boolean applyEnvCaseInsensitive() {
/* 137 */     Object obj = SYS_ENV_PROP.get("rpCtx.case.insensitive");
/*     */     
/* 139 */     if (obj instanceof Boolean) {
/* 140 */       return ((Boolean)obj).booleanValue();
/*     */     }
/*     */     
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   public static void setEnvIgnoreCase(Boolean flag) {
/* 147 */     SYS_ENV_PROP.put("rpCtx.case.insensitive", flag);
/*     */   }
/*     */   
/*     */   public static String[] getEnvCaseInsensitiveKeys() {
/* 151 */     Object obj = SYS_ENV_PROP.get("rpCtx.case.insensitive.keys");
/*     */     
/* 153 */     if (obj.getClass().equals(String[].class)) {
/* 154 */       return (String[])obj;
/*     */     }
/*     */     
/* 157 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean isCaseInsensitiveKey(String key) {
/* 161 */     String[] keys = getEnvCaseInsensitiveKeys();
/*     */     
/* 163 */     if (keys == null) {
/* 164 */       return false;
/*     */     }
/*     */     
/* 167 */     for (String comp : keys) {
/*     */       
/* 169 */       if (comp.equalsIgnoreCase(key)) {
/* 170 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 175 */     return false;
/*     */   }
/*     */   
/*     */   public static void setEnvIgnoreCaseKeys(String[] values) {
/* 179 */     SYS_ENV_PROP.put("rpCtx.case.insensitive.keys", values);
/*     */   }
/*     */   
/*     */   public static String getPublishServiceApiKey() {
/* 183 */     Object obj = SYS_ENV_PROP.get("publish.sync.serviceApiKey");
/*     */     
/* 185 */     if (obj instanceof String) {
/* 186 */       return (String)obj;
/*     */     }
/*     */     
/* 189 */     return null;
/*     */   }
/*     */   
/*     */   public static void setPublishServiceApiKey(String values) {
/* 193 */     SYS_ENV_PROP.put("publish.sync.serviceApiKey", values);
/*     */   }
/*     */   
/*     */   public static String getPublishHttpApiHeaderKey() {
/* 197 */     Object obj = SYS_ENV_PROP.get("publish.sync.httpApiHeaderKey");
/*     */     
/* 199 */     if (obj instanceof String) {
/* 200 */       return (String)obj;
/*     */     }
/*     */     
/* 203 */     return null;
/*     */   }
/*     */   
/*     */   public static void setPublishHttpApiHeaderKey(String values) {
/* 207 */     SYS_ENV_PROP.put("publish.sync.httpApiHeaderKey", values);
/*     */   }
/*     */ 
/*     */   
/* 211 */   private static final Map<String, Object> SYS_ENV_PROP = new ConcurrentHashMap<>(16);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SYS_PROP_CASE_INSENSITIVE = "rpCtx.case.insensitive";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SYS_PROP_CASE_INSENSITIVE_KEYS = "rpCtx.case.insensitive.keys";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SYS_PROP_SERVICE_API_KEY = "publish.sync.serviceApiKey";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SYS_PROP_HEADER_PUBLISH_SERVICE = "publish.sync.httpApiHeaderKey";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getUtf8Bytes(String data) {
/* 234 */     return data.getBytes(UTF8_CS);
/*     */   }
/*     */   
/*     */   public static String toUtf8(byte[] bytes) {
/* 238 */     return new String(bytes, UTF8_CS);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 242 */     System.out.println(encryptText("jdbc:oracle:thin:@192.168.1.132:1521:XE"));
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-utils-1.0.1_190403.1351.jar!\com\dreammirae\mmth\misc\SysEnvCommon.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */