/*     */ package com.dreammirae.mmth.authentication.issuecode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IssueCodeUtil
/*     */ {
/*     */   public static IssueCodeResult isValid(String data, String issueCode, long expiredDuration, int maxFailCnt) {
/*  40 */     IssueCodeData ad = IssueCodeData.fromDB(data);
/*  41 */     IssueCodeResult result = new IssueCodeResult();
/*     */ 
/*     */     
/*  44 */     if (isExpired(ad.getGenTime(), expiredDuration)) {
/*  45 */       result.setStatus(IssueCodeStatusCode.EXPIRED);
/*  46 */       return result;
/*     */     } 
/*     */ 
/*     */     
/*  50 */     if (ad.getFailCnt() >= maxFailCnt) {
/*  51 */       result.setStatus(IssueCodeStatusCode.EXCEED_FAIL_CNT);
/*  52 */       result.setFailCnt(ad.getFailCnt());
/*  53 */       return result;
/*     */     } 
/*     */ 
/*     */     
/*  57 */     if (ad.getIssueCode().equals(issueCode)) {
/*  58 */       result.setStatus(IssueCodeStatusCode.OK);
/*  59 */       return result;
/*     */     } 
/*     */ 
/*     */     
/*  63 */     ad.setFailCnt(ad.getFailCnt() + 1);
/*     */     
/*  65 */     result.setNewData(ad.toString());
/*  66 */     result.setFailCnt(ad.getFailCnt());
/*     */     
/*  68 */     if (ad.getFailCnt() >= maxFailCnt) {
/*     */       
/*  70 */       result.setStatus(IssueCodeStatusCode.EXCEED_FAIL_CNT);
/*     */     } else {
/*     */       
/*  73 */       result.setStatus(IssueCodeStatusCode.FAIL);
/*     */     } 
/*     */     
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   private static boolean isExpired(long genTime, long expiredDuration) {
/*  80 */     return (genTime + expiredDuration < System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getIssueCode(String data) {
/*  90 */     IssueCodeData icd = IssueCodeData.fromDB(data);
/*  91 */     return (icd == null) ? "" : icd.getIssueCode();
/*     */   }
/*     */   
/*     */   public static int getFailCnt(String data) {
/*  95 */     IssueCodeData icd = IssueCodeData.fromDB(data);
/*  96 */     return (icd == null) ? 0 : icd.getFailCnt();
/*     */   }
/*     */   
/*     */   public static long getGenTime(String data) {
/* 100 */     IssueCodeData icd = IssueCodeData.fromDB(data);
/* 101 */     return (icd == null) ? 0L : icd.getGenTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String genIssueCodeData() {
/* 122 */     IssueCodeData regData = IssueCodeData.generateIssueCodeData();
/* 123 */     return IssueCodeData.toDB(regData);
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\issuecode\IssueCodeUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */