/*    */ package com.dreammirae.mmth.authentication.issuecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IssueCodeResult
/*    */ {
/*    */   private IssueCodeStatusCode status;
/*    */   private String newData;
/*    */   private int failCnt;
/*    */   
/*    */   public IssueCodeStatusCode getStatus() {
/* 20 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(IssueCodeStatusCode status) {
/* 24 */     this.status = status;
/*    */   }
/*    */   
/*    */   public String getNewData() {
/* 28 */     return this.newData;
/*    */   }
/*    */   
/*    */   public void setNewData(String newData) {
/* 32 */     this.newData = newData;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFailCnt() {
/* 39 */     return this.failCnt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFailCnt(int failCnt) {
/* 46 */     this.failCnt = failCnt;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     StringBuilder builder = new StringBuilder(127);
/* 52 */     builder.append("IssueCodeResult [status=").append(this.status).append(", newData=").append(this.newData).append("]");
/* 53 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\issuecode\IssueCodeResult.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */