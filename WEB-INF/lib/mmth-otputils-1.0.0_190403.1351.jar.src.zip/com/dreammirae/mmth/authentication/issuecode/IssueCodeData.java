/*     */ package com.dreammirae.mmth.authentication.issuecode;
/*     */ 
/*     */ import com.dreammirae.gt.otp.hmac.HmacImpl;
/*     */ import com.dreammirae.mmth.authentication.otp.OTPDataUtils;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.EndianUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IssueCodeData
/*     */ {
/*     */   private String issueCode;
/*     */   private String rndHex;
/*     */   private long genTime;
/*     */   private int failCnt;
/*     */   private static final String DELIMITER = ",";
/*     */   private static final String ISSUE_CODE_EMPTY = "";
/*     */   private static final String ISSUE_CODE_PADDING = "0";
/*     */   private static final int ISSUE_CODE_DIGIT = 5;
/*     */   private static final int MSG_LENGTH = 10;
/*     */   private static final int KEY_LENGTH = 10;
/*     */   private static final int DATA_HEX_LENGTH = 40;
/*     */   
/*     */   public String getIssueCode() {
/*  35 */     return this.issueCode;
/*     */   }
/*     */   
/*     */   public void setIssueCode(String issueCode) {
/*  39 */     this.issueCode = issueCode;
/*     */   }
/*     */   
/*     */   public String getRndHex() {
/*  43 */     return this.rndHex;
/*     */   }
/*     */   
/*     */   public void setRndHex(String rndHex) {
/*  47 */     this.rndHex = rndHex;
/*     */   }
/*     */   
/*     */   public long getGenTime() {
/*  51 */     return this.genTime;
/*     */   }
/*     */   
/*     */   public void setGenTime(long genTime) {
/*  55 */     this.genTime = genTime;
/*     */   }
/*     */   
/*     */   public int getFailCnt() {
/*  59 */     return this.failCnt;
/*     */   }
/*     */   
/*     */   public void setFailCnt(int failCnt) {
/*  63 */     this.failCnt = failCnt;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  68 */     return toDB(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDB(IssueCodeData data) {
/*  88 */     StringBuilder sb = new StringBuilder();
/*  89 */     sb.append(data.getRndHex()).append(",").append(HexUtils.toHexString(data.getGenTime())).append(",").append(HexUtils.toHexString(data.getFailCnt()));
/*     */ 
/*     */     
/*  92 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static IssueCodeData fromDB(String db) {
/*  97 */     if (StringUtils.isEmpty(db)) {
/*  98 */       return null;
/*     */     }
/*     */     
/* 101 */     if (db.length() < 40) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     String[] tmp = db.split(",");
/*     */     
/*     */     try {
/* 108 */       IssueCodeData data = new IssueCodeData();
/* 109 */       data.setRndHex(tmp[0]);
/* 110 */       data.setIssueCode(calc(data.getRndHex()));
/* 111 */       data.setGenTime(EndianUtils.toInt64(HexUtils.fromHexString(tmp[1]), 0));
/* 112 */       data.setFailCnt(EndianUtils.toInt32(HexUtils.fromHexString(tmp[2]), 0));
/* 113 */       return data;
/* 114 */     } catch (Exception e) {
/* 115 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static IssueCodeData generateIssueCodeData() {
/* 121 */     IssueCodeData data = new IssueCodeData();
/* 122 */     byte[] rndBytes = OTPDataUtils.secureRandomBytes(20);
/* 123 */     data.setRndHex(HexUtils.toHexString(rndBytes));
/* 124 */     data.setIssueCode(calc(data.getRndHex()));
/* 125 */     data.setGenTime(System.currentTimeMillis());
/* 126 */     data.setFailCnt(0);
/* 127 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String calc(String hex) {
/* 133 */     if (StringUtils.isEmpty(hex)) {
/* 134 */       return "";
/*     */     }
/*     */     
/* 137 */     if (hex.length() < 40) {
/* 138 */       return "";
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 143 */       byte[] tmp = HexUtils.fromHexString(hex);
/*     */       
/* 145 */       byte[] key = new byte[10];
/* 146 */       byte[] msg = new byte[10];
/*     */       
/* 148 */       System.arraycopy(tmp, 0, key, 0, 10);
/* 149 */       System.arraycopy(tmp, 10, msg, 0, 10);
/*     */       
/* 151 */       HmacImpl hmacImpl = new HmacImpl();
/* 152 */       byte[] hash = hmacImpl.hmac(key, msg);
/*     */ 
/*     */       
/* 155 */       int offset = hash[hash.length - 1] & 0xF;
/*     */       
/* 157 */       int binary = toPositive(hash, offset);
/*     */ 
/*     */       
/* 160 */       int issueCodeNum = binary % 100000;
/* 161 */       String issueCode = Integer.toString(issueCodeNum);
/*     */       
/* 163 */       while (issueCode.length() < 5) {
/* 164 */         issueCode = "0" + issueCode;
/*     */       }
/*     */       
/* 167 */       return issueCode;
/*     */     }
/* 169 */     catch (Exception e) {
/* 170 */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int toPositive(byte[] hash, int offset) {
/* 175 */     return (hash[offset] & Byte.MAX_VALUE) << 24 | (hash[offset + 1] & 0xFF) << 16 | (hash[offset + 2] & 0xFF) << 8 | hash[offset + 3] & 0xFF;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\issuecode\IssueCodeData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */