/*   */ package com.dreammirae.mmth.authentication.issuecode;
/*   */ 
/*   */ public enum IssueCodeStatusCode
/*   */ {
/* 5 */   OK,
/* 6 */   EXPIRED,
/* 7 */   FAIL,
/* 8 */   EXCEED_FAIL_CNT;
/*   */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\issuecode\IssueCodeStatusCode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */