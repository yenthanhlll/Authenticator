/*    */ package com.dreammirae.mmth.authentication.otp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OTPDataException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public OTPDataException() {}
/*    */   
/*    */   public OTPDataException(String message, Throwable cause) {
/* 18 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public OTPDataException(String message) {
/* 22 */     super(message);
/*    */   }
/*    */   
/*    */   public OTPDataException(Throwable cause) {
/* 26 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\otp\OTPDataException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */