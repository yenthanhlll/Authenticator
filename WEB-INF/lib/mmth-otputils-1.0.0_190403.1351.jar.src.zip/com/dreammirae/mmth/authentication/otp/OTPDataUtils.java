/*     */ package com.dreammirae.mmth.authentication.otp;
/*     */ 
/*     */ import com.dreammirae.mmth.misc.Base64Utils;
/*     */ import com.dreammirae.mmth.misc.SysEnvCommon;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.notary.AES;
/*     */ import com.dreammirae.mmth.util.notary.HMAC;
/*     */ import com.dreammirae.mmth.util.notary.RSASSA_PSS_SHA256;
/*     */ import com.dreammirae.mmth.util.notary.SHA;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import java.util.Random;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.bouncycastle.crypto.CryptoException;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OTPDataUtils
/*     */ {
/*  29 */   private static final Logger LOG = LoggerFactory.getLogger(OTPDataUtils.class);
/*     */   
/*  31 */   private static final Provider BC = (Provider)new BouncyCastleProvider();
/*     */   
/*     */   private static final int LEN_SYMM_KEY = 16;
/*     */   
/*     */   private static final int LEN_AES_IV = 16;
/*     */   
/*     */   private static final int LEN_RANDOM_SYMM_KEY = 32;
/*     */   
/*     */   private static final int LEN_RND_SEED_KEY_OFFSET_PADDING = 2;
/*     */   
/*     */   private static final int LEN_KEY_A = 10;
/*     */   private static final int LEN_KEY_B = 10;
/*     */   private static final int LEN_KEY_AB = 20;
/*     */   private static final int LEN_FIRST_CHALLENGE = 32;
/*     */   private static final int LEN_SECOND_CHALLENGE = 29;
/*     */   private static final int LEN_OTP_CHALLENGE = 61;
/*     */   private static final String SECRET_KEY_ALG = "HmacSHA256";
/*  48 */   private static final int[] DIGITS_POWER = new int[] { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };
/*     */ 
/*     */   
/*     */   private static final int OTP_DIGIT = 6;
/*     */ 
/*     */   
/*     */   private static final char OTP_PADDING = '0';
/*     */   
/*     */   private static final String CIPHER_TRANSFORMATION = "RSA/None/NoPadding";
/*     */   
/*  58 */   private static Random randomGen = new Random();
/*     */ 
/*     */   
/*     */   private static SecureRandom secureRandom;
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] secureRandomBytes(int length) {
/*  66 */     if (length < 0) {
/*  67 */       throw new IllegalArgumentException("length must be positive number.");
/*     */     }
/*     */     
/*  70 */     byte[] buffer = new byte[length];
/*     */     
/*  72 */     if (secureRandom == null) {
/*     */       
/*     */       try {
/*  75 */         secureRandom = SecureRandom.getInstance("SHA1PRNG");
/*  76 */       } catch (NoSuchAlgorithmException e) {
/*  77 */         throw new IllegalArgumentException("SecureRandom not instanced", e);
/*     */       } 
/*     */     }
/*     */     
/*  81 */     secureRandom.nextBytes(buffer);
/*     */     
/*  83 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OTPDataLocator generateOtpData(String encTokenData, byte[] otpChallenge, byte[] pubkeyDerEncoded, byte[] tid, boolean includeKeyA, byte[] tokenId) throws OTPDataException {
/* 110 */     byte[] tokenData = null;
/*     */ 
/*     */     
/*     */     try {
/* 114 */       tokenData = TokenDataUtils.decryptTokenData(encTokenData);
/* 115 */     } catch (TokenDataException e) {
/* 116 */       throw new OTPDataException("Failed to decrypt token data...", e);
/*     */     } 
/*     */ 
/*     */     
/* 120 */     OTPDataLocator loc = new OTPDataLocator();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 125 */       byte[] otpKeyA = null;
/*     */       
/* 127 */       if (includeKeyA) {
/* 128 */         otpKeyA = getOTPKeyA(tokenData);
/*     */       } else {
/* 130 */         otpKeyA = randomBytes(10);
/*     */       } 
/*     */ 
/*     */       
/* 134 */       byte[] otpKeyB = genOTPKeyB(tokenData, otpChallenge);
/*     */ 
/*     */       
/* 137 */       byte[] otpData = getOTPData(otpKeyA, otpKeyB, otpChallenge);
/*     */ 
/*     */       
/* 140 */       byte[] symmetricKey = secureRandomBytes(16);
/* 141 */       byte[] aes_iv = secureRandomBytes(16);
/*     */ 
/*     */       
/* 144 */       loc.setEncData(AES.aesCbc(symmetricKey, aes_iv, otpData, 1));
/*     */ 
/*     */       
/* 147 */       if (tid != null) {
/* 148 */         loc.setEncTid(AES.aesCbc(symmetricKey, aes_iv, tid, 1));
/*     */       }
/*     */       
/* 151 */       if (tokenId != null) {
/* 152 */         loc.setEncToken(AES.aesCbc(symmetricKey, aes_iv, tokenId, 1));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 157 */       byte[] randomSymmetricKey = new byte[32];
/*     */       
/* 159 */       System.arraycopy(symmetricKey, 0, randomSymmetricKey, 0, 16);
/* 160 */       System.arraycopy(aes_iv, 0, randomSymmetricKey, 16, 16);
/*     */ 
/*     */       
/* 163 */       Cipher cipher = getCipherInstance(pubkeyDerEncoded, 1);
/* 164 */       loc.setEncKey(cipher.doFinal(randomSymmetricKey));
/*     */ 
/*     */       
/* 167 */       if (includeKeyA) {
/* 168 */         byte[] otpKey = new byte[20];
/* 169 */         System.arraycopy(otpKeyA, 0, otpKey, 0, 10);
/* 170 */         System.arraycopy(otpKeyB, 0, otpKey, 10, 10);
/* 171 */         String otp = genOTPCodeWithKey(otpKey, otpChallenge);
/* 172 */         loc.setEncOtp(AES.aesCbc(symmetricKey, aes_iv, Base64Utils.encodeRaw(otp), 1));
/*     */       } 
/*     */       
/* 175 */       if (LOG.isDebugEnabled()) {
/* 176 */         LOG.debug("\r\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\r\n%\tOTP DATA = " + HexUtils.toHexString(otpData) + "\r\n" + "%\tRANDOM KEY = " + HexUtils.toHexString(randomSymmetricKey) + "\r\n" + "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       return loc;
/*     */     }
/* 184 */     catch (Exception e) {
/* 185 */       throw new OTPDataException("Could not generate OTP data ...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] genOtpChallenge(byte[] firstChallenge, byte[] secondChallenge) throws OTPDataException {
/* 201 */     if (firstChallenge == null || firstChallenge.length != 32) {
/* 202 */       throw new OTPDataException("First challenge data is invalid.");
/*     */     }
/*     */     
/* 205 */     if (secondChallenge == null || secondChallenge.length != 29) {
/* 206 */       throw new OTPDataException("Second challenge data is invalid.");
/*     */     }
/*     */     
/* 209 */     byte[] serverChallenge = new byte[61];
/*     */     
/* 211 */     System.arraycopy(firstChallenge, 0, serverChallenge, 0, 32);
/* 212 */     System.arraycopy(secondChallenge, 0, serverChallenge, 32, 29);
/*     */     
/* 214 */     return serverChallenge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String genOTPCode(byte[] tokenData, byte[] otpChallenge) throws OTPAuthnException {
/*     */     try {
/* 231 */       byte[] otpKey = genOTPKeyAB(tokenData, otpChallenge);
/* 232 */       return genOTPCodeWithKey(otpKey, otpChallenge);
/*     */     }
/* 234 */     catch (Exception e) {
/* 235 */       throw new OTPAuthnException("Failed to generate OTP code ...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decryptOTPCode(String encOtpNum, byte[] tokenData) throws OTPAuthnException {
/*     */     try {
/* 243 */       byte[] encOtpBytes = HexUtils.fromHexString(encOtpNum);
/*     */ 
/*     */       
/* 246 */       byte[] keyA = getOTPKeyA(tokenData);
/*     */ 
/*     */       
/* 249 */       byte[] hashKeyA = SHA.sha256(keyA);
/*     */ 
/*     */       
/* 252 */       byte[] symmKey = new byte[16];
/* 253 */       System.arraycopy(hashKeyA, 0, symmKey, 0, 16);
/*     */ 
/*     */       
/* 256 */       byte[] iv = new byte[16];
/* 257 */       System.arraycopy(hashKeyA, 16, iv, 0, 16);
/*     */ 
/*     */       
/* 260 */       byte[] decOtpNum = AES.aesCbc(symmKey, iv, encOtpBytes, 2);
/*     */ 
/*     */       
/* 263 */       return new String(decOtpNum, SysEnvCommon.UTF8_CS);
/* 264 */     } catch (Exception e) {
/* 265 */       throw new OTPAuthnException("Failed to decrypt OTP code ...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encryptOTPCode(String otpNum, byte[] tokenData) throws OTPDataException {
/*     */     try {
/* 273 */       byte[] otpBytes = otpNum.getBytes(SysEnvCommon.UTF8_CS);
/*     */ 
/*     */       
/* 276 */       byte[] keyA = getOTPKeyA(tokenData);
/*     */ 
/*     */       
/* 279 */       byte[] hashKeyA = SHA.sha256(keyA);
/*     */ 
/*     */ 
/*     */       
/* 283 */       byte[] symmKey = new byte[16];
/* 284 */       System.arraycopy(hashKeyA, 0, symmKey, 0, 16);
/*     */ 
/*     */ 
/*     */       
/* 288 */       byte[] iv = new byte[16];
/* 289 */       System.arraycopy(hashKeyA, 16, iv, 0, 16);
/*     */ 
/*     */ 
/*     */       
/* 293 */       byte[] encOtpNum = AES.aesCbc(symmKey, iv, otpBytes, 1);
/*     */       
/* 295 */       return HexUtils.toHexString(encOtpNum);
/* 296 */     } catch (Exception e) {
/* 297 */       throw new OTPDataException("Failed to encrypt OTP code ...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toDecRNDSeedKey(byte[] encRNDSeedKey, byte[] pubkeyDerEncoded) throws Exception {
/* 318 */     Cipher cipher = getCipherInstance(pubkeyDerEncoded, 2);
/* 319 */     return cipher.doFinal(encRNDSeedKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toEncRNDSeedKey(byte[] rndSeedKey, byte[] baseChallenge, byte[] rndChallenge) throws Exception {
/* 335 */     int lenBaseChallenge = baseChallenge.length;
/* 336 */     int lenRndChallenge = rndChallenge.length;
/*     */ 
/*     */     
/* 339 */     byte[] key = new byte[lenBaseChallenge + lenRndChallenge];
/* 340 */     System.arraycopy(baseChallenge, 0, key, 0, lenBaseChallenge);
/* 341 */     System.arraycopy(rndChallenge, 0, key, lenBaseChallenge, lenRndChallenge);
/*     */     
/* 343 */     byte[] encKey = SHA.sha256(key);
/*     */     
/* 345 */     byte[] symmetricKey = new byte[16];
/* 346 */     byte[] aes_iv = new byte[16];
/*     */     
/* 348 */     System.arraycopy(encKey, 0, symmetricKey, 0, 16);
/* 349 */     System.arraycopy(encKey, 16, aes_iv, 0, 16);
/*     */     
/* 351 */     byte[] encRndSeedKey = AES.aesCbc(symmetricKey, aes_iv, rndSeedKey, 1);
/* 352 */     byte[] newRelocationData = relocationEncRndSeedKey(encRndSeedKey);
/*     */     
/* 354 */     if (LOG.isDebugEnabled()) {
/* 355 */       LOG.debug("\r\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\r\n%\tRND SEED KEY = " + HexUtils.toHexString(rndSeedKey) + "\r\n" + "%\tBASE CHALLENGE = " + HexUtils.toHexString(baseChallenge) + "\r\n" + "%\tRND CHALLENGE = " + HexUtils.toHexString(rndChallenge) + "\r\n" + "%\tENC KEY  = " + HexUtils.toHexString(encKey) + "\r\n" + "%\tRND SEED KEY ENC = " + HexUtils.toHexString(encRndSeedKey) + "\r\n" + "%\tRND SEED KEY ENC RELOCATION = " + HexUtils.toHexString(newRelocationData) + "\r\n" + "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 365 */     return newRelocationData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String genOTPCodeWithKey(byte[] otpKey, byte[] otpChallenge) throws Exception {
/*     */     String otpCode;
/* 381 */     SecretKeySpec signingKey = new SecretKeySpec(otpKey, "HmacSHA256");
/* 382 */     Mac mac = Mac.getInstance("HmacSHA256", BC);
/* 383 */     mac.init(signingKey);
/* 384 */     byte[] hash = mac.doFinal(otpChallenge);
/*     */     
/* 386 */     int offset = (hash[hash.length - 1] & Byte.MAX_VALUE) % 28;
/*     */     
/* 388 */     int binary = (hash[offset] & Byte.MAX_VALUE) << 24 | (hash[offset + 1] & 0xFF) << 16 | (hash[offset + 2] & 0xFF) << 8 | hash[offset + 3] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     int otp = binary % DIGITS_POWER[6];
/*     */     
/* 395 */     String otpCodeTmp = String.valueOf(otp);
/* 396 */     int charSize = otpCodeTmp.length();
/*     */ 
/*     */     
/* 399 */     if (charSize < 6) {
/*     */ 
/*     */       
/* 402 */       char[] returnOtp = new char[6];
/* 403 */       char[] otpChars = String.valueOf(otp).toCharArray();
/* 404 */       int padCnt = 6 - charSize;
/* 405 */       Arrays.fill(returnOtp, 0, padCnt, '0');
/* 406 */       System.arraycopy(otpChars, 0, returnOtp, padCnt, charSize);
/* 407 */       otpCode = new String(returnOtp);
/*     */     } else {
/* 409 */       otpCode = otpCodeTmp;
/*     */     } 
/*     */     
/* 412 */     return otpCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getOTPKeyA(byte[] tokenData) {
/* 420 */     byte[] otpKeyA = new byte[10];
/* 421 */     System.arraycopy(tokenData, 0, otpKeyA, 0, 10);
/* 422 */     return otpKeyA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] genOTPKeyB(byte[] tokenData, byte[] otpChallenge) throws Exception {
/* 430 */     byte[] otpKeyB = new byte[10];
/*     */ 
/*     */     
/* 433 */     byte[] signature = HMAC.sign(HexUtils.toHexString(tokenData), HexUtils.toHexString(otpChallenge));
/*     */     
/* 435 */     System.arraycopy(signature, 0, otpKeyB, 0, 10);
/*     */     
/* 437 */     return otpKeyB;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] genOTPKeyAB(byte[] tokenData, byte[] otpChallenge) throws Exception {
/* 442 */     byte[] otpKey = new byte[20];
/*     */ 
/*     */     
/* 445 */     System.arraycopy(tokenData, 0, otpKey, 0, 10);
/*     */ 
/*     */     
/* 448 */     byte[] signature = HMAC.sign(HexUtils.toHexString(tokenData), HexUtils.toHexString(otpChallenge));
/* 449 */     System.arraycopy(signature, 0, otpKey, 10, 10);
/*     */     
/* 451 */     return otpKey;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] getOTPData(byte[] keyA, byte[] keyB, byte[] otpChallenge) {
/* 456 */     byte[] data = new byte[81];
/*     */     
/* 458 */     System.arraycopy(keyA, 0, data, 0, 10);
/* 459 */     System.arraycopy(keyB, 0, data, 10, 10);
/* 460 */     System.arraycopy(otpChallenge, 0, data, 20, 61);
/*     */     
/* 462 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] randomBytes(int size) {
/* 467 */     if (size < 1) {
/* 468 */       return new byte[0];
/*     */     }
/*     */     
/* 471 */     byte[] rd = new byte[size];
/* 472 */     randomGen.nextBytes(rd);
/* 473 */     return rd;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] relocationEncRndSeedKey(byte[] encRndSeedKey) {
/* 478 */     int len = encRndSeedKey.length;
/* 479 */     int offset = randomOffset(len);
/* 480 */     int firstLen = len - offset;
/*     */ 
/*     */     
/* 483 */     int lenNewData = len + 2;
/* 484 */     byte[] relocationData = new byte[lenNewData];
/*     */     
/* 486 */     System.arraycopy(encRndSeedKey, offset, relocationData, 0, firstLen);
/*     */     
/* 488 */     if (firstLen != len) {
/* 489 */       int secLen = len - firstLen;
/* 490 */       System.arraycopy(encRndSeedKey, 0, relocationData, firstLen, secLen);
/*     */     } 
/*     */     
/* 493 */     relocationData[lenNewData - 2] = (byte)(len & 0xFF);
/* 494 */     relocationData[lenNewData - 1] = (byte)(offset & 0xFF);
/*     */     
/* 496 */     if (LOG.isDebugEnabled()) {
/* 497 */       LOG.debug("RND Seed Key length = " + len);
/* 498 */       LOG.debug("RND Seed Key offset = " + offset);
/*     */     } 
/*     */ 
/*     */     
/* 502 */     return relocationData;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int randomOffset(int limit) {
/* 508 */     if (limit < 1) {
/* 509 */       return 0;
/*     */     }
/*     */     
/* 512 */     int rnd = randomGen.nextInt(limit);
/*     */     
/* 514 */     if (rnd >= limit) {
/* 515 */       return 0;
/*     */     }
/*     */     
/* 518 */     return rnd;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Cipher getCipherInstance(byte[] pubkeyDerEncoded, int mode) throws Exception {
/* 523 */     PublicKey pubKey = getPublicKeyInstance(pubkeyDerEncoded);
/* 524 */     Cipher cipher = Cipher.getInstance("RSA/None/NoPadding", BC);
/* 525 */     cipher.init(mode, pubKey);
/* 526 */     return cipher;
/*     */   }
/*     */   
/*     */   private static PublicKey getPublicKeyInstance(byte[] pubkeyDerEncoded) throws CryptoException {
/* 530 */     byte[] pubKeyBytesRaw = RSASSA_PSS_SHA256.getRawPublicKey(pubkeyDerEncoded);
/* 531 */     PublicKey otpPubKey = RSASSA_PSS_SHA256.getPublicKeyfromRaw(pubKeyBytesRaw);
/* 532 */     return otpPubKey;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\otp\OTPDataUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */