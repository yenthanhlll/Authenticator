/*     */ package com.dreammirae.mmth.authentication.otp;
/*     */ 
/*     */ import com.dreammirae.gt.otp.Core;
/*     */ import com.dreammirae.mmth.util.StringUtils;
/*     */ import com.dreammirae.mmth.util.io.HexUtils;
/*     */ import com.dreammirae.mmth.util.notary.SHA;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenDataUtils
/*     */ {
/*  22 */   private static final Logger LOG = LoggerFactory.getLogger(TokenDataUtils.class);
/*     */ 
/*     */   
/*     */   private static final int LEN_TOKEN_DATA = 32;
/*     */ 
/*     */   
/*     */   private static final int LEN_TOKEN_DATA_SHA1 = 20;
/*     */ 
/*     */   
/*     */   private static final int LEN_TOKEN_DATA_RND = 12;
/*     */   
/*  33 */   private static Core otpCore = Core.getInstance();
/*  34 */   private static byte[] masterKey = otpCore.getSeedEncKey("biotp", "5D7C2360C4DEBA6A3ACDFC4118BE923C");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SecureRandom secureRandom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] encryptData(byte[] orgTokenData) throws TokenDataException {
/*  49 */     if (orgTokenData == null || orgTokenData.length < 1) {
/*  50 */       throw new TokenDataException("The original data can not null.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  55 */       byte[] encTokenData = otpCore.ENCRYPT(null, null, masterKey, null, orgTokenData);
/*     */       
/*  57 */       if (LOG.isDebugEnabled()) {
/*  58 */         LOG.debug("== TokenData = " + HexUtils.toHexString(orgTokenData));
/*  59 */         LOG.debug("== ENC(TokenData) = " + HexUtils.toHexString(encTokenData));
/*     */       } 
/*     */       
/*  62 */       return encTokenData;
/*     */     }
/*  64 */     catch (Exception e) {
/*  65 */       LOG.error("Failed to encrypt TokenData...", e);
/*  66 */       throw new TokenDataException("Failed to encrypt TokenData...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encryptTokenData(byte[] orgTokenData) throws TokenDataException {
/*     */     try {
/*  80 */       byte[] encTokenData = encryptData(orgTokenData);
/*  81 */       return HexUtils.toHexString(encTokenData);
/*  82 */     } catch (TokenDataException e) {
/*  83 */       throw e;
/*  84 */     } catch (Exception e) {
/*  85 */       LOG.error("Failed to encrypt TokenData...", e);
/*  86 */       throw new TokenDataException("Failed to encrypt TokenData...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] decryptData(byte[] encTokenData) throws TokenDataException {
/* 101 */     if (encTokenData == null || encTokenData.length < 1) {
/* 102 */       throw new TokenDataException("The original data can not null.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 107 */       byte[] decTokenData = otpCore.DECRYPT(null, null, masterKey, null, encTokenData);
/*     */       
/* 109 */       if (LOG.isDebugEnabled()) {
/* 110 */         LOG.debug("== ENC(TokenData) = " + HexUtils.toHexString(encTokenData));
/* 111 */         LOG.debug("== TokenData = " + HexUtils.toHexString(decTokenData));
/*     */       } 
/*     */       
/* 114 */       return decTokenData;
/*     */     }
/* 116 */     catch (Exception e) {
/* 117 */       LOG.error("Failed to decrypt TokenData...", e);
/* 118 */       throw new TokenDataException("Failed to decrypt TokenData...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decryptTokenData(String encTokenData) throws TokenDataException {
/* 133 */     if (StringUtils.isEmpty(encTokenData)) {
/* 134 */       throw new TokenDataException("The original data can not null.");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 139 */       byte[] encTokenDataBytes = HexUtils.fromHexString(encTokenData);
/* 140 */       return decryptData(encTokenDataBytes);
/*     */     }
/* 142 */     catch (TokenDataException e) {
/* 143 */       throw e;
/* 144 */     } catch (Exception e) {
/* 145 */       LOG.error("Failed to decrypt TokenData...", e);
/* 146 */       throw new TokenDataException("Failed to decrypt TokenData...", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String updateEncTokenData(String oldEncTokenData) throws TokenDataException {
/* 161 */     byte[] oldTokenData = decryptTokenData(oldEncTokenData);
/*     */     
/* 163 */     byte[] newTokenData = new byte[32];
/* 164 */     byte[] hash = SHA.sha1(oldTokenData);
/* 165 */     byte[] randBytes = secureRandomBytes(12);
/*     */     
/* 167 */     System.arraycopy(hash, 0, newTokenData, 0, 20);
/* 168 */     System.arraycopy(randBytes, 0, newTokenData, 20, 12);
/*     */     
/* 170 */     return encryptTokenData(newTokenData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] secureRandomBytes(int length) {
/* 179 */     if (length < 0) {
/* 180 */       throw new IllegalArgumentException("length must be positive number.");
/*     */     }
/*     */     
/* 183 */     byte[] buffer = new byte[length];
/*     */     
/* 185 */     if (secureRandom == null) {
/*     */       try {
/* 187 */         secureRandom = SecureRandom.getInstance("SHA1PRNG");
/* 188 */       } catch (NoSuchAlgorithmException e) {
/* 189 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */     
/* 193 */     secureRandom.nextBytes(buffer);
/*     */     
/* 195 */     return buffer;
/*     */   }
/*     */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\otp\TokenDataUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */