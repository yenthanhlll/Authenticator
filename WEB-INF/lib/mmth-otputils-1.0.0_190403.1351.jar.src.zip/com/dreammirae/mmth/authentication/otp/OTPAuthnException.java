/*    */ package com.dreammirae.mmth.authentication.otp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OTPAuthnException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public OTPAuthnException() {}
/*    */   
/*    */   public OTPAuthnException(String message, Throwable cause) {
/* 18 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public OTPAuthnException(String message) {
/* 22 */     super(message);
/*    */   }
/*    */   
/*    */   public OTPAuthnException(Throwable cause) {
/* 26 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\otp\OTPAuthnException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */