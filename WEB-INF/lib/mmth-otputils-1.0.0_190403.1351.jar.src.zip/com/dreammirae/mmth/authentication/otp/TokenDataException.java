/*    */ package com.dreammirae.mmth.authentication.otp;
/*    */ 
/*    */ 
/*    */ public class TokenDataException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public TokenDataException() {}
/*    */   
/*    */   public TokenDataException(String message, Throwable cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public TokenDataException(String message) {
/* 16 */     super(message);
/*    */   }
/*    */   
/*    */   public TokenDataException(Throwable cause) {
/* 20 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\otp\TokenDataException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */