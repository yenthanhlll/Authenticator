/*    */ package com.dreammirae.mmth.authentication.otp;
/*    */ 
/*    */ import com.dreammirae.mmth.util.io.HexUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OTPDataLocator
/*    */ {
/*    */   private byte[] encKey;
/*    */   private byte[] encData;
/*    */   private byte[] encTid;
/*    */   private byte[] encToken;
/*    */   private byte[] encOtp;
/*    */   
/*    */   public byte[] getEncKey() {
/* 18 */     return this.encKey;
/*    */   }
/*    */   
/*    */   public void setEncKey(byte[] encKey) {
/* 22 */     this.encKey = encKey;
/*    */   }
/*    */   
/*    */   public byte[] getEncData() {
/* 26 */     return this.encData;
/*    */   }
/*    */   
/*    */   public void setEncData(byte[] encData) {
/* 30 */     this.encData = encData;
/*    */   }
/*    */   
/*    */   public byte[] getEncTid() {
/* 34 */     return this.encTid;
/*    */   }
/*    */   
/*    */   public void setEncTid(byte[] encTid) {
/* 38 */     this.encTid = encTid;
/*    */   }
/*    */   
/*    */   public byte[] getEncToken() {
/* 42 */     return this.encToken;
/*    */   }
/*    */   
/*    */   public void setEncToken(byte[] encToken) {
/* 46 */     this.encToken = encToken;
/*    */   }
/*    */   
/*    */   public byte[] getEncOtp() {
/* 50 */     return this.encOtp;
/*    */   }
/*    */   
/*    */   public void setEncOtp(byte[] encOtp) {
/* 54 */     this.encOtp = encOtp;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     StringBuilder builder = new StringBuilder();
/* 60 */     builder.append("OtpDataLocator [encKey=").append(HexUtils.toHexString(this.encKey)).append(", encData=").append(HexUtils.toHexString(this.encData)).append(", encTid=").append(HexUtils.toHexString(this.encTid)).append("]");
/*    */     
/* 62 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Authenticator\Authenticator-main\ROOT.jar!\WEB-INF\lib\mmth-otputils-1.0.0_190403.1351.jar!\com\dreammirae\mmth\authentication\otp\OTPDataLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */